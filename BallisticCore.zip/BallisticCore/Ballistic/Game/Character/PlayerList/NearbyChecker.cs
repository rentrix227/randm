﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Character.PlayerBehaviour;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.PlayerList
{
	// Token: 0x0200007C RID: 124
	[Serializable]
	public class NearbyChecker
	{
		// Token: 0x06000162 RID: 354 RVA: 0x00019610 File Offset: 0x00017810
		public NearbyChecker(Transform p_source, float p_distance, bool p_checkEnemies, bool p_checkAllies)
		{
			this.CheckEnemies = p_checkEnemies;
			this.CheckAllies = p_checkAllies;
			this.Source = p_source;
			this.NearbyDistance = p_distance;
			this.SquareNearbyDistance = p_distance * p_distance;
			this.Characters = new List<Character>();
			this.CharacterDictionary = new Dictionary<FPSCharacter, Character>();
			this.Active = true;
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00003528 File Offset: 0x00001728
		public void Activate(bool p_active)
		{
			this.Active = p_active;
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00003531 File Offset: 0x00001731
		public void SetDistance(float p_distance)
		{
			this.NearbyDistance = p_distance;
			this.SquareNearbyDistance = p_distance * p_distance;
		}

		// Token: 0x06000165 RID: 357 RVA: 0x00019668 File Offset: 0x00017868
		public void CopyCharacterList(List<FPSCharacter> p_chars)
		{
			for (int i = 0; i < p_chars.Count; i++)
			{
				this.AddCharacter(p_chars[i]);
			}
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0001969C File Offset: 0x0001789C
		public void AddCharacter(FPSCharacter p_char)
		{
			if (!this.CharacterDictionary.ContainsKey(p_char))
			{
				Character character = new Character(p_char, false);
				this.Characters.Add(character);
				this.CharacterDictionary.Add(p_char, character);
			}
			else
			{
				Debug.LogWarning("[NearbyChecker.AddCharacter] FPSCharacter already registered!");
			}
		}

		// Token: 0x06000167 RID: 359 RVA: 0x000196EC File Offset: 0x000178EC
		public void RemoveCharacter(FPSCharacter p_char)
		{
			if (this.CharacterDictionary.ContainsKey(p_char))
			{
				Character character = this.CharacterDictionary[p_char];
				this.CharacterDictionary.Remove(p_char);
				this.Characters.Remove(character);
			}
			else
			{
				Debug.LogWarning("[NearbyChecker.RemoveCharacter] FPSCharacter not registered!");
			}
		}

		// Token: 0x06000168 RID: 360 RVA: 0x00019740 File Offset: 0x00017940
		public void UpdateCharacter(FPSCharacter p_char)
		{
			if (this.CharacterDictionary.ContainsKey(p_char))
			{
				Character character = this.CharacterDictionary[p_char];
				if ((this.Source.position - character.FPSChar.transform.position).sqrMagnitude < this.SquareNearbyDistance && ((this.CheckAllies && !p_char.IsEnemy) || (this.CheckEnemies && p_char.IsEnemy)))
				{
					character.Nearby = true;
				}
				else
				{
					character.Nearby = false;
				}
			}
			else
			{
				Debug.LogWarning("[NearbyChecker.UpdateCharacter] FPSCharacter not registered!");
			}
		}

		// Token: 0x06000169 RID: 361 RVA: 0x000197EC File Offset: 0x000179EC
		public int GetNumberOfCharactersNear()
		{
			int num = 0;
			for (int i = 0; i < this.Characters.Count; i++)
			{
				if (this.Characters[i].Nearby)
				{
					num++;
				}
			}
			return num;
		}

		// Token: 0x04000400 RID: 1024
		public bool CheckEnemies;

		// Token: 0x04000401 RID: 1025
		public bool CheckAllies;

		// Token: 0x04000402 RID: 1026
		public bool Active;

		// Token: 0x04000403 RID: 1027
		public Transform Source;

		// Token: 0x04000404 RID: 1028
		public float NearbyDistance;

		// Token: 0x04000405 RID: 1029
		public float SquareNearbyDistance;

		// Token: 0x04000406 RID: 1030
		public List<Character> Characters;

		// Token: 0x04000407 RID: 1031
		public Dictionary<FPSCharacter, Character> CharacterDictionary;
	}
}
