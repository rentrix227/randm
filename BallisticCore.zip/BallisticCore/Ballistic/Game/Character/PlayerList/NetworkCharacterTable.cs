﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Character.PlayerBehaviour;

namespace Aquiris.Ballistic.Game.Character.PlayerList
{
	// Token: 0x0200007A RID: 122
	public static class NetworkCharacterTable
	{
		// Token: 0x0600015D RID: 349 RVA: 0x000034A5 File Offset: 0x000016A5
		public static void Restart()
		{
			NetworkCharacterTable.ActivePlayers.Clear();
			NetworkCharacterTable.ActivePlayersKeys = NetworkCharacterTable.ActivePlayers.Keys;
			NetworkCharacterTable.ActivePlayersValues = NetworkCharacterTable.ActivePlayers.Values;
		}

		// Token: 0x0600015E RID: 350 RVA: 0x000034CF File Offset: 0x000016CF
		public static void AddPlayer(FPSCharacter player)
		{
			if (NetworkCharacterTable.ActivePlayers.ContainsKey(player.ownerID))
			{
				return;
			}
			NetworkCharacterTable.ActivePlayers.Add(player.ownerID, player);
		}

		// Token: 0x0600015F RID: 351 RVA: 0x000034F8 File Offset: 0x000016F8
		public static void RemovePlayer(long playerId)
		{
			NetworkCharacterTable.ActivePlayers.Remove(playerId);
		}

		// Token: 0x040003FB RID: 1019
		public static readonly Dictionary<long, FPSCharacter> ActivePlayers = new Dictionary<long, FPSCharacter>();

		// Token: 0x040003FC RID: 1020
		public static Dictionary<long, FPSCharacter>.KeyCollection ActivePlayersKeys;

		// Token: 0x040003FD RID: 1021
		public static Dictionary<long, FPSCharacter>.ValueCollection ActivePlayersValues;
	}
}
