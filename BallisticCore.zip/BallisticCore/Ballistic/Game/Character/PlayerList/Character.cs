﻿using System;
using Aquiris.Ballistic.Game.Character.PlayerBehaviour;

namespace Aquiris.Ballistic.Game.Character.PlayerList
{
	// Token: 0x0200007B RID: 123
	[Serializable]
	public class Character
	{
		// Token: 0x06000161 RID: 353 RVA: 0x00003512 File Offset: 0x00001712
		public Character(FPSCharacter p_char, bool p_nearby = false)
		{
			this.FPSChar = p_char;
			this.Nearby = false;
		}

		// Token: 0x040003FE RID: 1022
		public FPSCharacter FPSChar;

		// Token: 0x040003FF RID: 1023
		public bool Nearby;
	}
}
