﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.Network
{
	// Token: 0x02000071 RID: 113
	public struct PlayerState
	{
		// Token: 0x06000119 RID: 281 RVA: 0x0001867C File Offset: 0x0001687C
		static PlayerState()
		{
			IEnumerator enumerator = Enum.GetValues(typeof(PlayerState.State)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					PlayerState.State state = (PlayerState.State)obj;
					uint num = (uint)Enum.Parse(typeof(PlayerState.SerializedState), state.ToString());
					PlayerState.m_stateToSerializedState.Add((int)state, num);
					PlayerState.m_serializedStateToState.Add(num, (int)state);
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
		}

		// Token: 0x0600011A RID: 282 RVA: 0x00018740 File Offset: 0x00016940
		public PlayerState(long gameClientId, byte[] data, MapBounds mapBounds)
		{
			this = default(PlayerState);
			if (data == null)
			{
				return;
			}
			byte[] buffer = ArrayPool<byte>.GetBuffer(data.Length);
			Array.Copy(data, buffer, data.Length);
			Crypto.Spoof(buffer);
			int num = 0;
			this.gameClientId = gameClientId;
			uint num2;
			num = BytePacker.UnpackSemiInt(buffer, num, out num2);
			uint num3 = num2 & 3U;
			this.timeStamp = num2 >> 2;
			if ((num3 & 1U) != 0U)
			{
				this.Skills.SkillModifierMask = (int)buffer[num++];
			}
			else
			{
				this.Skills.SkillModifierMask = 0;
			}
			num = this.GetSkillModifierValue(PlayerState.SkillModifier.DamageReduction, buffer, num, out this.Skills.DamageReduction);
			num = this.GetSkillModifierValue(PlayerState.SkillModifier.FrontalDamageReduction, buffer, num, out this.Skills.FrontalDamageReduction);
			num = this.GetSkillModifierValue(PlayerState.SkillModifier.ExplosiveDamageReduction, buffer, num, out this.Skills.ExplosiveDamageReduction);
			num = this.GetSkillModifierValue(PlayerState.SkillModifier.HeadDamageReduction, buffer, num, out this.Skills.HeadDamageReduction);
			num = this.GetSkillModifierValue(PlayerState.SkillModifier.ChestDamageReduction, buffer, num, out this.Skills.ChestDamageReduction);
			uint num4;
			num = BytePacker.UnpackVarInt(buffer, num, out num4);
			this.StateBitMask = PlayerState.ConvertSerializedStateToState(num4);
			num = BytePacker.UnpackPoint(buffer, num, out this.position, new Vector3(mapBounds.MinX, mapBounds.MinY, mapBounds.MinZ), new Vector3(mapBounds.MaxX, mapBounds.MaxY, mapBounds.MaxZ), 5);
			num = BytePacker.UnpackMediumDirection(buffer, num, out this.lookDirection);
			num = BytePacker.UnpackMediumPoint(buffer, num, out this.moveDirection, -25f * Vector3.one, 25f * Vector3.one);
			Vector3 vector = this.lookDirection;
			vector.y = 0f;
			float num5 = Vector3.Angle(Vector3.forward, vector);
			if (vector.x < 0f)
			{
				num5 = -num5;
			}
			this.rotation = Quaternion.Euler(0f, num5, 0f);
			this.currentLife = (float)buffer[num++] / 255f;
			if (this.GetState(PlayerState.State.IsShooting))
			{
				num = BytePacker.UnpackDirection(buffer, num, out this.shootDirection);
				Vector3 vector2;
				num = BytePacker.UnpackSmallPoint(buffer, num, out vector2, -5f * Vector3.one, 5f * Vector3.one);
				this.shootOrigin = this.position + vector2;
			}
			byte b = buffer[num];
			buffer[num] = 0;
			byte b2 = Crypto.Checksum(buffer);
			this.validChecksum = b == b2;
			ArrayPool<byte>.FreeBuffer(buffer);
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600011B RID: 283 RVA: 0x00003043 File Offset: 0x00001243
		public bool IsSolid
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x0600011C RID: 284 RVA: 0x00003046 File Offset: 0x00001246
		// (set) Token: 0x0600011D RID: 285 RVA: 0x0000304E File Offset: 0x0000124E
		public bool validChecksum { get; private set; }

		// Token: 0x0600011E RID: 286 RVA: 0x00003057 File Offset: 0x00001257
		private byte[] GetBuffer(int length)
		{
			if (this._lastBuffer != null)
			{
				ArrayPool<byte>.FreeBuffer(this._lastBuffer);
			}
			this._lastBuffer = ArrayPool<byte>.GetBuffer(length);
			return this._lastBuffer;
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00018994 File Offset: 0x00016B94
		private static uint ConvertStateToSerializedState(int p_state)
		{
			uint num = 0U;
			int num2 = 1;
			for (int i = 0; i < 32; i++)
			{
				int num3 = p_state & num2;
				if (num3 != 0)
				{
					uint num4 = 0U;
					if (PlayerState.m_stateToSerializedState.TryGetValue(num3, out num4))
					{
						num |= num4;
					}
				}
				num2 <<= 1;
			}
			return num;
		}

		// Token: 0x06000120 RID: 288 RVA: 0x000189E4 File Offset: 0x00016BE4
		private static int ConvertSerializedStateToState(uint p_state)
		{
			int num = 0;
			uint num2 = 1U;
			for (int i = 0; i < 32; i++)
			{
				uint num3 = p_state & num2;
				if (num3 != 0U)
				{
					int num4 = 0;
					if (PlayerState.m_serializedStateToState.TryGetValue(num3, out num4))
					{
						num |= num4;
					}
				}
				num2 <<= 1;
			}
			return num;
		}

		// Token: 0x06000121 RID: 289 RVA: 0x00003081 File Offset: 0x00001281
		public static bool GetState(int p_stateBitMask, PlayerState.State p_state)
		{
			return (p_stateBitMask & (int)p_state) != 0;
		}

		// Token: 0x06000122 RID: 290 RVA: 0x0000308C File Offset: 0x0000128C
		public void SetState(PlayerState.State p_state, bool p_value)
		{
			if (p_value)
			{
				this.StateBitMask |= (int)p_state;
			}
			else
			{
				this.StateBitMask &= (int)(~(int)p_state);
			}
		}

		// Token: 0x06000123 RID: 291 RVA: 0x000030B6 File Offset: 0x000012B6
		public bool GetState(PlayerState.State p_state)
		{
			return PlayerState.GetState(this.StateBitMask, p_state);
		}

		// Token: 0x06000124 RID: 292 RVA: 0x000030C4 File Offset: 0x000012C4
		private bool GetSkillModifier(PlayerState.SkillModifier p_modifier)
		{
			return (this.Skills.SkillModifierMask & (int)p_modifier) != 0;
		}

		// Token: 0x06000125 RID: 293 RVA: 0x000030D9 File Offset: 0x000012D9
		private void SetSkillModifier(PlayerState.SkillModifier p_modifier, bool p_state)
		{
			if (p_state)
			{
				this.Skills.SkillModifierMask = this.Skills.SkillModifierMask | (int)p_modifier;
			}
			else
			{
				this.Skills.SkillModifierMask = this.Skills.SkillModifierMask & (int)(~(int)p_modifier);
			}
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00018A34 File Offset: 0x00016C34
		private void UpdateSkillModifierBitMask()
		{
			this.SetSkillModifier(PlayerState.SkillModifier.DamageReduction, !Mathf.Approximately(this.Skills.DamageReduction, 1f));
			this.SetSkillModifier(PlayerState.SkillModifier.FrontalDamageReduction, !Mathf.Approximately(this.Skills.FrontalDamageReduction, 1f));
			this.SetSkillModifier(PlayerState.SkillModifier.ExplosiveDamageReduction, !Mathf.Approximately(this.Skills.ExplosiveDamageReduction, 1f));
			this.SetSkillModifier(PlayerState.SkillModifier.HeadDamageReduction, !Mathf.Approximately(this.Skills.HeadDamageReduction, 1f));
			this.SetSkillModifier(PlayerState.SkillModifier.ChestDamageReduction, !Mathf.Approximately(this.Skills.ChestDamageReduction, 1f));
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00018AE0 File Offset: 0x00016CE0
		private int GetSkillModifierValue(PlayerState.SkillModifier p_modifier, byte[] p_data, int p_idx, out float p_value)
		{
			if (this.GetSkillModifier(p_modifier))
			{
				switch (p_modifier)
				{
				case PlayerState.SkillModifier.DamageReduction:
				case PlayerState.SkillModifier.FrontalDamageReduction:
				case PlayerState.SkillModifier.ExplosiveDamageReduction:
				case PlayerState.SkillModifier.HeadDamageReduction:
					break;
				default:
					if (p_modifier != PlayerState.SkillModifier.ChestDamageReduction)
					{
						Debug.LogError("[PlayerState::GetSkillModifierValue] Unknown modifier type: " + p_modifier.ToString());
						p_value = 1f;
						goto IL_0084;
					}
					break;
				}
				p_idx = BytePacker.UnpackSmallFloat(p_data, p_idx, out p_value, 0f, 2f);
				IL_0084:;
			}
			else
			{
				p_value = 1f;
			}
			return p_idx;
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00018B80 File Offset: 0x00016D80
		private int SetSkillModifierValue(PlayerState.SkillModifier p_modifier, byte[] p_data, int p_idx, float p_value)
		{
			if (this.GetSkillModifier(p_modifier))
			{
				switch (p_modifier)
				{
				case PlayerState.SkillModifier.DamageReduction:
				case PlayerState.SkillModifier.FrontalDamageReduction:
				case PlayerState.SkillModifier.ExplosiveDamageReduction:
				case PlayerState.SkillModifier.HeadDamageReduction:
					break;
				default:
					if (p_modifier != PlayerState.SkillModifier.ChestDamageReduction)
					{
						Debug.LogError("[PlayerState::SetSkillModifierValue] Unknown modifier type: " + p_modifier.ToString());
						return p_idx;
					}
					break;
				}
				p_idx = BytePacker.PackSmallFloat(p_data, p_idx, p_value, 0f, 2f);
			}
			return p_idx;
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00018C0C File Offset: 0x00016E0C
		public byte[] Pack(MapBounds mapBounds)
		{
			int num = 0;
			byte[] stagingData = PlayerState.m_stagingData;
			this.UpdateSkillModifierBitMask();
			uint num2 = 0U;
			if (this.Skills.SkillModifierMask != 0)
			{
				num2 |= 1U;
			}
			uint num3 = (this.timeStamp << 2) | num2;
			num = BytePacker.PackSemiInt(stagingData, num, num3);
			if ((num2 & 1U) != 0U)
			{
				stagingData[num++] = (byte)this.Skills.SkillModifierMask;
				num = this.SetSkillModifierValue(PlayerState.SkillModifier.DamageReduction, stagingData, num, this.Skills.DamageReduction);
				num = this.SetSkillModifierValue(PlayerState.SkillModifier.FrontalDamageReduction, stagingData, num, this.Skills.FrontalDamageReduction);
				num = this.SetSkillModifierValue(PlayerState.SkillModifier.ExplosiveDamageReduction, stagingData, num, this.Skills.ExplosiveDamageReduction);
				num = this.SetSkillModifierValue(PlayerState.SkillModifier.HeadDamageReduction, stagingData, num, this.Skills.HeadDamageReduction);
				num = this.SetSkillModifierValue(PlayerState.SkillModifier.ChestDamageReduction, stagingData, num, this.Skills.ChestDamageReduction);
			}
			uint num4 = PlayerState.ConvertStateToSerializedState(this.StateBitMask);
			num4 &= 2097151U;
			num = BytePacker.PackVarInt(stagingData, num, num4);
			num = BytePacker.PackPoint(stagingData, num, this.position, new Vector3(mapBounds.MinX, mapBounds.MinY, mapBounds.MinZ), new Vector3(mapBounds.MaxX, mapBounds.MaxY, mapBounds.MaxZ), 5);
			num = BytePacker.PackMediumDirection(stagingData, num, this.lookDirection);
			num = BytePacker.PackMediumPoint(stagingData, num, this.moveDirection, -25f * Vector3.one, 25f * Vector3.one);
			stagingData[num++] = (byte)(Mathf.Clamp01(this.currentLife) * 255f);
			if (this.GetState(PlayerState.State.IsShooting))
			{
				num = BytePacker.PackDirection(stagingData, num, this.shootDirection);
				Vector3 vector = this.shootOrigin - this.position;
				num = BytePacker.PackSmallPoint(stagingData, num, vector, -5f * Vector3.one, 5f * Vector3.one);
			}
			int num5 = num + 1;
			byte[] buffer = this.GetBuffer(num5);
			Buffer.BlockCopy(stagingData, 0, buffer, 0, num);
			buffer[num] = 0;
			buffer[num] = Crypto.Checksum(buffer);
			Crypto.Spoof(buffer);
			return buffer;
		}

		// Token: 0x0600012A RID: 298 RVA: 0x00018E10 File Offset: 0x00017010
		public override string ToString()
		{
			return string.Format("[PlayerState: gameClientId={0}, position={1}, rotation={2}, lookDirection={3}, moveDirection={4}, shootDirection={5}, shootOrigin={6}, currentLife={7},  StateBitMask={8}, timeStamp={9}]", new object[] { this.gameClientId, this.position, this.rotation, this.lookDirection, this.moveDirection, this.shootDirection, this.shootOrigin, this.currentLife, this.StateBitMask, this.timeStamp });
		}

		// Token: 0x04000388 RID: 904
		public long gameClientId;

		// Token: 0x04000389 RID: 905
		public Vector3 position;

		// Token: 0x0400038A RID: 906
		public Quaternion rotation;

		// Token: 0x0400038B RID: 907
		public Vector3 lookDirection;

		// Token: 0x0400038C RID: 908
		public Vector3 moveDirection;

		// Token: 0x0400038D RID: 909
		public Vector3 shootDirection;

		// Token: 0x0400038E RID: 910
		public Vector3 shootOrigin;

		// Token: 0x0400038F RID: 911
		public float currentLife;

		// Token: 0x04000390 RID: 912
		public int StateBitMask;

		// Token: 0x04000391 RID: 913
		public uint timeStamp;

		// Token: 0x04000392 RID: 914
		public PlayerState.SkillsState Skills;

		// Token: 0x04000394 RID: 916
		private static byte[] m_stagingData = new byte[256];

		// Token: 0x04000395 RID: 917
		private static Dictionary<int, uint> m_stateToSerializedState = new Dictionary<int, uint>();

		// Token: 0x04000396 RID: 918
		private static Dictionary<uint, int> m_serializedStateToState = new Dictionary<uint, int>();

		// Token: 0x04000397 RID: 919
		private byte[] _lastBuffer;

		// Token: 0x02000072 RID: 114
		[Flags]
		public enum State
		{
			// Token: 0x04000399 RID: 921
			IsMoving = 1,
			// Token: 0x0400039A RID: 922
			IsShooting = 2,
			// Token: 0x0400039B RID: 923
			IsReloading = 4,
			// Token: 0x0400039C RID: 924
			IsSprinting = 8,
			// Token: 0x0400039D RID: 925
			IsCrouching = 16,
			// Token: 0x0400039E RID: 926
			IsJumping = 32,
			// Token: 0x0400039F RID: 927
			IsDrawing = 64,
			// Token: 0x040003A0 RID: 928
			IsInvisible = 128,
			// Token: 0x040003A1 RID: 929
			IsAiming = 256,
			// Token: 0x040003A2 RID: 930
			IsLastStanding = 512,
			// Token: 0x040003A3 RID: 931
			IsGrounded = 1024,
			// Token: 0x040003A4 RID: 932
			IsMarked = 2048,
			// Token: 0x040003A5 RID: 933
			IsPressingFire = 4096,
			// Token: 0x040003A6 RID: 934
			IsFurious = 8192,
			// Token: 0x040003A7 RID: 935
			IsMarkedOnRadar = 16384,
			// Token: 0x040003A8 RID: 936
			IsDashing = 32768,
			// Token: 0x040003A9 RID: 937
			IsJuggernaut = 65536
		}

		// Token: 0x02000073 RID: 115
		private enum SerializedState : uint
		{
			// Token: 0x040003AB RID: 939
			IsGrounded = 1U,
			// Token: 0x040003AC RID: 940
			IsMoving,
			// Token: 0x040003AD RID: 941
			IsSprinting = 4U,
			// Token: 0x040003AE RID: 942
			IsShooting = 8U,
			// Token: 0x040003AF RID: 943
			IsReloading = 16U,
			// Token: 0x040003B0 RID: 944
			IsJumping = 32U,
			// Token: 0x040003B1 RID: 945
			IsCrouching = 64U,
			// Token: 0x040003B2 RID: 946
			IsInvisible = 128U,
			// Token: 0x040003B3 RID: 947
			IsMarked = 256U,
			// Token: 0x040003B4 RID: 948
			IsMarkedOnRadar = 512U,
			// Token: 0x040003B5 RID: 949
			IsLastStanding = 1024U,
			// Token: 0x040003B6 RID: 950
			IsFurious = 2048U,
			// Token: 0x040003B7 RID: 951
			IsPressingFire = 4096U,
			// Token: 0x040003B8 RID: 952
			IsJuggernaut = 8192U,
			// Token: 0x040003B9 RID: 953
			SerializedStateMask = 2097151U,
			// Token: 0x040003BA RID: 954
			IsAiming,
			// Token: 0x040003BB RID: 955
			IsDrawing = 4194304U,
			// Token: 0x040003BC RID: 956
			IsDashing = 8388608U
		}

		// Token: 0x02000074 RID: 116
		public enum SkillModifier
		{
			// Token: 0x040003BE RID: 958
			DamageReduction = 1,
			// Token: 0x040003BF RID: 959
			FrontalDamageReduction,
			// Token: 0x040003C0 RID: 960
			ExplosiveDamageReduction = 4,
			// Token: 0x040003C1 RID: 961
			HeadDamageReduction = 8,
			// Token: 0x040003C2 RID: 962
			ChestDamageReduction = 16
		}

		// Token: 0x02000075 RID: 117
		private enum Flags
		{
			// Token: 0x040003C4 RID: 964
			HasSkillData = 1,
			// Token: 0x040003C5 RID: 965
			BitCount,
			// Token: 0x040003C6 RID: 966
			Mask
		}

		// Token: 0x02000076 RID: 118
		public struct SkillsState
		{
			// Token: 0x040003C7 RID: 967
			public int SkillModifierMask;

			// Token: 0x040003C8 RID: 968
			public float DamageReduction;

			// Token: 0x040003C9 RID: 969
			public float FrontalDamageReduction;

			// Token: 0x040003CA RID: 970
			public float ExplosiveDamageReduction;

			// Token: 0x040003CB RID: 971
			public float HeadDamageReduction;

			// Token: 0x040003CC RID: 972
			public float ChestDamageReduction;
		}
	}
}
