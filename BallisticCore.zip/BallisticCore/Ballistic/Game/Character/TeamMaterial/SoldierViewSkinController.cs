﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.TeamMaterial
{
	// Token: 0x02000508 RID: 1288
	public class SoldierViewSkinController : MonoBehaviour
	{
		// Token: 0x06001B63 RID: 7011 RVA: 0x00013FBC File Offset: 0x000121BC
		public void SetTeamColor(bool isBlue)
		{
			this.m_isBlue = isBlue;
			this.UpdateMaterial();
		}

		// Token: 0x06001B64 RID: 7012 RVA: 0x00013FCB File Offset: 0x000121CB
		private void OnEnable()
		{
			this.UpdateMaterial();
		}

		// Token: 0x06001B65 RID: 7013 RVA: 0x0008D3F4 File Offset: 0x0008B5F4
		public void UpdateMaterial()
		{
			if (this.m_soldierRenderer == null)
			{
				this.m_soldierRenderer = base.GetComponent<SkinnedMeshRenderer>();
			}
			if (this.m_isBlue)
			{
				if (this.m_teamMaterial == null)
				{
					return;
				}
				this.m_soldierRenderer.sharedMaterial.SetFloat(this.m_property, this.m_bluValue);
				if (!this.m_blueMaterialBuilt)
				{
					this.m_blueMaterialBuilt = true;
					return;
				}
			}
			else
			{
				if (this.m_teamMaterial == null)
				{
					return;
				}
				this.m_soldierRenderer.sharedMaterial.SetFloat(this.m_property, this.m_redValue);
				if (!this.m_redMaterialBuilt)
				{
					this.m_redMaterialBuilt = true;
				}
			}
		}

		// Token: 0x04001D30 RID: 7472
		private bool m_isBlue;

		// Token: 0x04001D31 RID: 7473
		private bool m_redMaterialBuilt;

		// Token: 0x04001D32 RID: 7474
		private bool m_blueMaterialBuilt;

		// Token: 0x04001D33 RID: 7475
		public Material m_teamMaterial;

		// Token: 0x04001D34 RID: 7476
		public SkinnedMeshRenderer m_soldierRenderer;

		// Token: 0x04001D35 RID: 7477
		public string m_property;

		// Token: 0x04001D36 RID: 7478
		public float m_redValue;

		// Token: 0x04001D37 RID: 7479
		public float m_bluValue;
	}
}
