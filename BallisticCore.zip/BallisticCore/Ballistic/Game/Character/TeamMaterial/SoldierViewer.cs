﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.TeamMaterial
{
	// Token: 0x02000507 RID: 1287
	public class SoldierViewer : MonoBehaviour
	{
		// Token: 0x06001B60 RID: 7008 RVA: 0x00013FA1 File Offset: 0x000121A1
		public void RefreshSkinColor()
		{
			this.ChangeSkinColors(this.m_isBlue);
		}

		// Token: 0x06001B61 RID: 7009 RVA: 0x00013FAF File Offset: 0x000121AF
		public SoldierViewSkinController[] Get3dSoldierSkinControllers()
		{
			return base.gameObject.GetComponentsInChildren<SoldierViewSkinController>();
		}

		// Token: 0x06001B62 RID: 7010 RVA: 0x0008D3C0 File Offset: 0x0008B5C0
		public void ChangeSkinColors(bool p_isBlue)
		{
			this.m_isBlue = p_isBlue;
			SoldierViewSkinController[] array = this.Get3dSoldierSkinControllers();
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetTeamColor(p_isBlue);
			}
		}

		// Token: 0x04001D2F RID: 7471
		private bool m_isBlue = true;
	}
}
