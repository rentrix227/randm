﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.TeamMaterial
{
	// Token: 0x02000509 RID: 1289
	public class TeamBasedColorMaterial : MonoBehaviour
	{
		// Token: 0x06001B68 RID: 7016 RVA: 0x00013FD3 File Offset: 0x000121D3
		private void Awake()
		{
			this.m_renderer = base.GetComponent<SkinnedMeshRenderer>();
			base.gameObject.GetComponent<SkinnedMeshRenderer>().material.GetFloat("_Team");
		}

		// Token: 0x06001B69 RID: 7017 RVA: 0x0008D498 File Offset: 0x0008B698
		public void SetTeam(Team p_team)
		{
			this.m_renderer = base.GetComponent<SkinnedMeshRenderer>();
			base.gameObject.GetComponent<SkinnedMeshRenderer>().material.GetFloat("_Team");
			if (p_team == Team.SMOKE)
			{
				this.m_renderer.material.SetFloat("_Team", 1f);
				return;
			}
			this.m_renderer.material.SetFloat("_Team", 0f);
		}

		// Token: 0x04001D38 RID: 7480
		public SkinnedMeshRenderer m_renderer;
	}
}
