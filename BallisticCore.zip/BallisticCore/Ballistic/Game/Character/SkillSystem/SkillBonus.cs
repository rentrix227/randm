﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.SkillSystem
{
	// Token: 0x0200007F RID: 127
	[Serializable]
	public class SkillBonus
	{
		// Token: 0x060001B5 RID: 437 RVA: 0x0000357B File Offset: 0x0000177B
		public SkillBonus()
		{
			this.m_bonusList = new List<float>();
			this.m_maxValue = 0f;
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x00019834 File Offset: 0x00017A34
		public void removeBonus(float p_bonusValue)
		{
			float num = 0f;
			int num2 = 0;
			for (int i = 0; i < this.m_bonusList.Count; i++)
			{
				if (p_bonusValue == this.m_bonusList[i])
				{
					num2 = i;
				}
				else if (this.m_bonusList[i] > num)
				{
					num = this.m_bonusList[i];
				}
			}
			this.m_bonusList.RemoveAt(num2);
			this.m_maxValue = num;
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x00003599 File Offset: 0x00001799
		public void addBonus(float p_bonusValue)
		{
			if (Mathf.Abs(p_bonusValue) > Mathf.Abs(this.m_maxValue))
			{
				this.m_maxValue = p_bonusValue;
			}
			this.m_bonusList.Add(p_bonusValue);
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x000035C4 File Offset: 0x000017C4
		public void resetBonus()
		{
			this.m_maxValue = 0f;
			this.m_bonusList.Clear();
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x000035DC File Offset: 0x000017DC
		public float getBonus()
		{
			return this.m_maxValue;
		}

		// Token: 0x0400040A RID: 1034
		private List<float> m_bonusList;

		// Token: 0x0400040B RID: 1035
		private float m_maxValue;
	}
}
