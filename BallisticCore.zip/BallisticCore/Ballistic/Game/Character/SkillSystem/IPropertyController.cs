﻿using System;
using Aquiris.Ballistic.Game.Character.PlayerBehaviour;
using Aquiris.DataModel.ItemModel.GameItemModel.BaseHeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;

namespace Aquiris.Ballistic.Game.Character.SkillSystem
{
	// Token: 0x0200007E RID: 126
	public interface IPropertyController
	{
		// Token: 0x0600016E RID: 366
		void Init(FPSCharacter fpsCharacter);

		// Token: 0x0600016F RID: 367
		void Destroy();

		// Token: 0x06000170 RID: 368
		bool HasInitialized();

		// Token: 0x06000171 RID: 369
		int GetCurrentLevel();

		// Token: 0x06000172 RID: 370
		void InstantiateSkill(EHeroSkillV2 skill);

		// Token: 0x06000173 RID: 371
		void InstantiateClassSkills(EHeroClass p_class);

		// Token: 0x06000174 RID: 372
		void DestroySkillController();

		// Token: 0x06000175 RID: 373
		void SetDamageReduction(SkillEnums.ModifierType p_type, float p_val);

		// Token: 0x06000176 RID: 374
		float GetHeroMeleeDamageMultiplier();

		// Token: 0x06000177 RID: 375
		float GetHeroExplosiveDamageMultiplier();

		// Token: 0x06000178 RID: 376
		float GetMoveSpeed();

		// Token: 0x06000179 RID: 377
		float GetCrouchMoveSpeed();

		// Token: 0x0600017A RID: 378
		float GetAimMoveSpeed();

		// Token: 0x0600017B RID: 379
		float GetCrouchAimMoveSpeed();

		// Token: 0x0600017C RID: 380
		float GetSprintMoveSpeed();

		// Token: 0x0600017D RID: 381
		float GetStamina();

		// Token: 0x0600017E RID: 382
		float GetStaminaCostPerJump();

		// Token: 0x0600017F RID: 383
		float GetJumpCooldownTime();

		// Token: 0x06000180 RID: 384
		float GetPenaltyJumpHeightModifier();

		// Token: 0x06000181 RID: 385
		float GetPenaltyJumpAirDirectionModifier();

		// Token: 0x06000182 RID: 386
		int GetConsecutiveJumpsWithoutPenalty();

		// Token: 0x06000183 RID: 387
		float GetStaminaRecoverDuration();

		// Token: 0x06000184 RID: 388
		float GetJumpHeight();

		// Token: 0x06000185 RID: 389
		float GetStandingHeight();

		// Token: 0x06000186 RID: 390
		float GetCrouchHeight();

		// Token: 0x06000187 RID: 391
		float GetAirCrouchHeight();

		// Token: 0x06000188 RID: 392
		HeroData GetHeroData();

		// Token: 0x06000189 RID: 393
		float GetFootstepSound();

		// Token: 0x0600018A RID: 394
		float GetScavengerAmmoRecoverQuantity();

		// Token: 0x0600018B RID: 395
		float GetOnKillAmmoRecoverQuantity();

		// Token: 0x0600018C RID: 396
		float GetExtraAmmoQuantity();

		// Token: 0x0600018D RID: 397
		float GetScavengerGrenadeRecoveryChance();

		// Token: 0x0600018E RID: 398
		bool HasAbility(SkillEnums.PlayerAbility ability);

		// Token: 0x0600018F RID: 399
		void FireEvent(SkillEnums.PlayerEvent ev);

		// Token: 0x06000190 RID: 400
		float GetFallingDamageReduction();

		// Token: 0x06000191 RID: 401
		float GetFrontalDamageReduction();

		// Token: 0x06000192 RID: 402
		float GetDamageReduction();

		// Token: 0x06000193 RID: 403
		float GetBodypartDamageReduction(BodyElement p_part);

		// Token: 0x06000194 RID: 404
		float GetExplosiveDamageReduction();

		// Token: 0x06000195 RID: 405
		float GetFireRate();

		// Token: 0x06000196 RID: 406
		float GetGrenadeFireRate();

		// Token: 0x06000197 RID: 407
		float GetAccuracy();

		// Token: 0x06000198 RID: 408
		float GetRecoilMultiplier();

		// Token: 0x06000199 RID: 409
		float GetDrawSpeed(bool p_activateHeroModifier);

		// Token: 0x0600019A RID: 410
		float GetWeaponHandling();

		// Token: 0x0600019B RID: 411
		float GetReloadSpeed(bool p_activateHeroModifier);

		// Token: 0x0600019C RID: 412
		float GetMeleeSkill();

		// Token: 0x0600019D RID: 413
		float GetFrontStabDamage(bool p_activateHeroModifier);

		// Token: 0x0600019E RID: 414
		float GetMeleeStrikeRadius(bool p_activateHeroModifier);

		// Token: 0x0600019F RID: 415
		float GetMeleeStrikeAngle(bool p_activateHeroModifier);

		// Token: 0x060001A0 RID: 416
		float GetMeleeInterval();

		// Token: 0x060001A1 RID: 417
		int GetGrenadeNumberPerShot();

		// Token: 0x060001A2 RID: 418
		int GetNumberOfExtraGrenades();

		// Token: 0x060001A3 RID: 419
		float GetWeaponSwapSpeed(bool p_activateHeroModifier);

		// Token: 0x060001A4 RID: 420
		float GetExplosiveDamage();

		// Token: 0x060001A5 RID: 421
		float GetWeaponDamageMultiplier();

		// Token: 0x060001A6 RID: 422
		float GetHeadshotDamageMultiplier();

		// Token: 0x060001A7 RID: 423
		float GetExplosiveRange();

		// Token: 0x060001A8 RID: 424
		float GetGoBallisticActivationLevel();

		// Token: 0x060001A9 RID: 425
		float GetDamage(float p_distance);

		// Token: 0x060001AA RID: 426
		float GetDamageFromBehind();

		// Token: 0x060001AB RID: 427
		float LastStandStanceDuration();

		// Token: 0x060001AC RID: 428
		float GetStaminaRecoveryTime();

		// Token: 0x060001AD RID: 429
		float GetSpeedMultiplier();

		// Token: 0x060001AE RID: 430
		float GetScopeInSpeed();

		// Token: 0x060001AF RID: 431
		float GetScopeOutSpeed();

		// Token: 0x060001B0 RID: 432
		float GetMinimapRange();

		// Token: 0x060001B1 RID: 433
		float GetSway();

		// Token: 0x060001B2 RID: 434
		float GetWeaponRange();

		// Token: 0x060001B3 RID: 435
		float GetCammouflageSoundMultiplier();

		// Token: 0x060001B4 RID: 436
		float GetGrenadeRecoveryMultiplier();
	}
}
