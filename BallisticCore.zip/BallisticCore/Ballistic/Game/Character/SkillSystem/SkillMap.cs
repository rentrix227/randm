﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Character.Camouflage;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace Aquiris.Ballistic.Game.Character.SkillSystem
{
	// Token: 0x02000087 RID: 135
	public class SkillMap : MonoBehaviour
	{
		// Token: 0x060001BC RID: 444 RVA: 0x000035E4 File Offset: 0x000017E4
		public bool ContainsEvent(string name)
		{
			return this.m_skillEventMap.ContainsKey(name);
		}

		// Token: 0x060001BD RID: 445 RVA: 0x000035F2 File Offset: 0x000017F2
		public SkillMap.CamouflageEffects GetCammoInfo(EHeroClass p_class)
		{
			if (this.m_camouflageMap == null)
			{
				return null;
			}
			if (this.m_camouflageMap.ContainsKey(p_class))
			{
				return this.m_camouflageMap[p_class];
			}
			return null;
		}

		// Token: 0x060001BE RID: 446 RVA: 0x00003620 File Offset: 0x00001820
		public SkillEnums.PlayerEvent GetEventEnum(string p_name)
		{
			return this.m_skillEventMap[p_name];
		}

		// Token: 0x060001BF RID: 447 RVA: 0x0000362E File Offset: 0x0000182E
		public GameObject GetHeroSkill(EHeroSkillV2 p_skill)
		{
			if (this.m_skillMap.ContainsKey(p_skill))
			{
				return this.m_skillMap[p_skill].gameObject;
			}
			Debug.LogWarning("Skill prefab not found for skill " + p_skill);
			return null;
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x000198B0 File Offset: 0x00017AB0
		public Dictionary<EHeroSkillV2, Transform> GetSkillPrefabsMap()
		{
			Dictionary<EHeroSkillV2, Transform> dictionary = new Dictionary<EHeroSkillV2, Transform>();
			foreach (Transform transform in this.skillPrefabs)
			{
				if (transform != null)
				{
					string text = transform.name.ToUpper();
					if (Enum.IsDefined(typeof(EHeroSkillV2), text))
					{
						EHeroSkillV2 eheroSkillV = (EHeroSkillV2)Enum.Parse(typeof(EHeroSkillV2), text);
						dictionary.Add(eheroSkillV, transform);
					}
				}
				else
				{
					Debug.LogError("Null reference on skill map! THIS MAY BREAK A LOT OF THINGS!");
				}
			}
			return dictionary;
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x00019968 File Offset: 0x00017B68
		public void SetCammoInfo(EHeroClass p_class, CamouflageInfoComponent p_info)
		{
			SkillMap.CamouflageEffects camouflageEffects = new SkillMap.CamouflageEffects();
			if (this.m_camouflageMap.ContainsKey(p_class))
			{
				camouflageEffects = this.m_camouflageMap[p_class];
			}
			if (p_info.IsThirdPerson)
			{
				camouflageEffects.WeaponMaterial3rd = p_info.WeaponMaterial;
			}
			else
			{
				camouflageEffects.WeaponMaterial = p_info.WeaponMaterial;
			}
			if (this.m_camouflageMap.ContainsKey(p_class))
			{
				this.m_camouflageMap[p_class] = camouflageEffects;
			}
			else
			{
				this.m_camouflageMap.Add(p_class, camouflageEffects);
			}
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x000199F4 File Offset: 0x00017BF4
		private void BuildEventList()
		{
			this.m_skillEventMap = new Dictionary<string, SkillEnums.PlayerEvent>();
			IEnumerator enumerator = Enum.GetValues(typeof(SkillEnums.PlayerEvent)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					SkillEnums.PlayerEvent playerEvent = (SkillEnums.PlayerEvent)obj;
					this.m_skillEventMap.Add(playerEvent.ToString(), playerEvent);
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x00003669 File Offset: 0x00001869
		public void OnEnable()
		{
			SceneManager.sceneLoaded += new UnityAction<Scene, LoadSceneMode>(this.SceneManagerOnSceneLoaded);
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x0000367C File Offset: 0x0000187C
		public void OnDisable()
		{
			SceneManager.sceneLoaded -= new UnityAction<Scene, LoadSceneMode>(this.SceneManagerOnSceneLoaded);
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x00019A80 File Offset: 0x00017C80
		public void Awake()
		{
			if (SkillMap.Instance == null)
			{
				SkillMap.Instance = this;
			}
			this.m_skillMap = this.GetSkillPrefabsMap();
			this.BuildEventList();
			foreach (Transform transform in this.skillPrefabs)
			{
				PlayMakerFSM component = transform.GetComponent<PlayMakerFSM>();
				component.Preprocess();
			}
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x0000368F File Offset: 0x0000188F
		private void SceneManagerOnSceneLoaded(Scene scene, LoadSceneMode loadSceneMode)
		{
			this.m_camouflageMap = new Dictionary<EHeroClass, SkillMap.CamouflageEffects>();
		}

		// Token: 0x040004AB RID: 1195
		public static SkillMap Instance;

		// Token: 0x040004AC RID: 1196
		public List<Transform> skillPrefabs;

		// Token: 0x040004AD RID: 1197
		private Dictionary<EHeroClass, SkillMap.CamouflageEffects> m_camouflageMap;

		// Token: 0x040004AE RID: 1198
		private Dictionary<string, SkillEnums.PlayerEvent> m_skillEventMap;

		// Token: 0x040004AF RID: 1199
		private Dictionary<EHeroSkillV2, Transform> m_skillMap;

		// Token: 0x02000088 RID: 136
		[Serializable]
		public class CamouflageEffects
		{
			// Token: 0x040004B0 RID: 1200
			public Material ArmsMaterial;

			// Token: 0x040004B1 RID: 1201
			public EHeroClass Class;

			// Token: 0x040004B2 RID: 1202
			public AnimationClip InvisibleClip;

			// Token: 0x040004B3 RID: 1203
			public Material InvisibleMaterial;

			// Token: 0x040004B4 RID: 1204
			public AnimationClip VisibleClip;

			// Token: 0x040004B5 RID: 1205
			public Material WeaponMaterial;

			// Token: 0x040004B6 RID: 1206
			public Material WeaponMaterial3rd;
		}
	}
}
