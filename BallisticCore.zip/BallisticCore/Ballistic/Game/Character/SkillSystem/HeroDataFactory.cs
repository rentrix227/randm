﻿using System;
using Aquiris.Ballistic.Game.Character.PlayerBehaviour;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.SkillSystem
{
	// Token: 0x0200007D RID: 125
	public class HeroDataFactory : MonoBehaviour
	{
		// Token: 0x0600016B RID: 363 RVA: 0x00003543 File Offset: 0x00001743
		public virtual void Awake()
		{
			HeroDataFactory.Instance = this;
			this._gameItemService = ServiceProvider.GetService<GameItemService>();
		}

		// Token: 0x0600016C RID: 364 RVA: 0x00003556 File Offset: 0x00001756
		public static IPropertyController BuildPropertyController(FPSCharacter fpsCharacter, EHeroClass hero, int currentLevel, int maxLevel)
		{
			if (HeroDataFactory.Instance != null)
			{
				return HeroDataFactory.Instance.BuildPropertyControllerImpl(fpsCharacter, hero, currentLevel, maxLevel);
			}
			return null;
		}

		// Token: 0x0600016D RID: 365 RVA: 0x00003578 File Offset: 0x00001778
		public virtual IPropertyController BuildPropertyControllerImpl(FPSCharacter fpsCharacter, EHeroClass hero, int currentLevel, int maxLevel)
		{
			return null;
		}

		// Token: 0x04000408 RID: 1032
		protected static HeroDataFactory Instance;

		// Token: 0x04000409 RID: 1033
		protected GameItemService _gameItemService;
	}
}
