﻿using System;

namespace Aquiris.Ballistic.Game.Character.SkillSystem
{
	// Token: 0x02000080 RID: 128
	public class SkillEnums
	{
		// Token: 0x02000081 RID: 129
		public enum BonusType
		{
			// Token: 0x0400040D RID: 1037
			Movement,
			// Token: 0x0400040E RID: 1038
			ExtraHealth,
			// Token: 0x0400040F RID: 1039
			DamageReduction,
			// Token: 0x04000410 RID: 1040
			MovementSpeed,
			// Token: 0x04000411 RID: 1041
			FallingDamageReduction,
			// Token: 0x04000412 RID: 1042
			AmmoQuantity,
			// Token: 0x04000413 RID: 1043
			GrenadeQuantity,
			// Token: 0x04000414 RID: 1044
			WeaponSwapSpeed,
			// Token: 0x04000415 RID: 1045
			MiniMapRange,
			// Token: 0x04000416 RID: 1046
			FrontalDamageReduction,
			// Token: 0x04000417 RID: 1047
			None = 100
		}

		// Token: 0x02000082 RID: 130
		public enum ForeignAbilityEvent
		{
			// Token: 0x04000419 RID: 1049
			BecomeMarked,
			// Token: 0x0400041A RID: 1050
			StopBeingMarked,
			// Token: 0x0400041B RID: 1051
			BecomeMarkedOnlyOnMap
		}

		// Token: 0x02000083 RID: 131
		public enum ModifierType
		{
			// Token: 0x0400041D RID: 1053
			DamageReduction,
			// Token: 0x0400041E RID: 1054
			ExtraHealth,
			// Token: 0x0400041F RID: 1055
			FallingDamageReduction,
			// Token: 0x04000420 RID: 1056
			Damage,
			// Token: 0x04000421 RID: 1057
			ExplosiveDamage,
			// Token: 0x04000422 RID: 1058
			ExplosiveRange,
			// Token: 0x04000423 RID: 1059
			SprintSpeed,
			// Token: 0x04000424 RID: 1060
			MovementSpeed,
			// Token: 0x04000425 RID: 1061
			Stamina,
			// Token: 0x04000426 RID: 1062
			StaminaRecovery,
			// Token: 0x04000427 RID: 1063
			WeaponSwapSpeed,
			// Token: 0x04000428 RID: 1064
			FireRate,
			// Token: 0x04000429 RID: 1065
			MeleeSpeed,
			// Token: 0x0400042A RID: 1066
			RecoilMultiplier,
			// Token: 0x0400042B RID: 1067
			ReloadSpeed,
			// Token: 0x0400042C RID: 1068
			Accuracy,
			// Token: 0x0400042D RID: 1069
			AccuracyRecoverySpeed,
			// Token: 0x0400042E RID: 1070
			MinRange,
			// Token: 0x0400042F RID: 1071
			MaxRange,
			// Token: 0x04000430 RID: 1072
			DrawSpeed,
			// Token: 0x04000431 RID: 1073
			GrenadeNumberPerShot,
			// Token: 0x04000432 RID: 1074
			ExplosiveDamageReduction,
			// Token: 0x04000433 RID: 1075
			AmmoQuantity,
			// Token: 0x04000434 RID: 1076
			AmmoReplenish,
			// Token: 0x04000435 RID: 1077
			FootstepSound,
			// Token: 0x04000436 RID: 1078
			CammouflageActivationTime,
			// Token: 0x04000437 RID: 1079
			CammouflageSoundMultiplier,
			// Token: 0x04000438 RID: 1080
			GoBallisticActivationLevel,
			// Token: 0x04000439 RID: 1081
			ScavengerAmmunitionRecovery,
			// Token: 0x0400043A RID: 1082
			ScavengerGrenadeReplenishChance,
			// Token: 0x0400043B RID: 1083
			GrenadeFireRate,
			// Token: 0x0400043C RID: 1084
			NumberOfExtraGrenades,
			// Token: 0x0400043D RID: 1085
			LastStandStanceDuration,
			// Token: 0x0400043E RID: 1086
			MiniMapRange,
			// Token: 0x0400043F RID: 1087
			WeaponSway,
			// Token: 0x04000440 RID: 1088
			WeaponRange,
			// Token: 0x04000441 RID: 1089
			FrontalDamageReduction,
			// Token: 0x04000442 RID: 1090
			ScopeInSpeed,
			// Token: 0x04000443 RID: 1091
			ScopeOutSpeed,
			// Token: 0x04000444 RID: 1092
			DashRechargePercent,
			// Token: 0x04000445 RID: 1093
			MeleeAngle,
			// Token: 0x04000446 RID: 1094
			MeleeDamage,
			// Token: 0x04000447 RID: 1095
			MeleeReach,
			// Token: 0x04000448 RID: 1096
			DamageFromBehind,
			// Token: 0x04000449 RID: 1097
			JumpStaminaCost,
			// Token: 0x0400044A RID: 1098
			ShotDistanceForBonus,
			// Token: 0x0400044B RID: 1099
			DamageOnBigDistances,
			// Token: 0x0400044C RID: 1100
			HeadDamageReduction,
			// Token: 0x0400044D RID: 1101
			ChestDamageReduction,
			// Token: 0x0400044E RID: 1102
			HeadshotDamage,
			// Token: 0x0400044F RID: 1103
			CammouflageDeactivationTime,
			// Token: 0x04000450 RID: 1104
			GrenadeRecoveryMultiplier,
			// Token: 0x04000451 RID: 1105
			OnKillAmmunitionRecovery,
			// Token: 0x04000452 RID: 1106
			None = 100
		}

		// Token: 0x02000084 RID: 132
		public enum PlayerAbility
		{
			// Token: 0x04000454 RID: 1108
			Assassin,
			// Token: 0x04000455 RID: 1109
			Scavenger,
			// Token: 0x04000456 RID: 1110
			Indomitable,
			// Token: 0x04000457 RID: 1111
			InvisibleOnMap,
			// Token: 0x04000458 RID: 1112
			Martyrdom,
			// Token: 0x04000459 RID: 1113
			CanEquipBurstsAsSecondary,
			// Token: 0x0400045A RID: 1114
			CanEquipKatana,
			// Token: 0x0400045B RID: 1115
			CanEquipGrenadeLauncher,
			// Token: 0x0400045C RID: 1116
			CanLastStand,
			// Token: 0x0400045D RID: 1117
			CanRevealEnemiesWhenAiming,
			// Token: 0x0400045E RID: 1118
			HardHeaded,
			// Token: 0x0400045F RID: 1119
			MightIgnoreLethalDamage,
			// Token: 0x04000460 RID: 1120
			CanMarkPlayersOnHit,
			// Token: 0x04000461 RID: 1121
			CanMoveInvisible,
			// Token: 0x04000462 RID: 1122
			CanMoveFasterWhileUnseen,
			// Token: 0x04000463 RID: 1123
			CanGoBallistic,
			// Token: 0x04000464 RID: 1124
			CanKamikaze,
			// Token: 0x04000465 RID: 1125
			CanRevealEnemiesLocallyWhenHit,
			// Token: 0x04000466 RID: 1126
			CanDash,
			// Token: 0x04000467 RID: 1127
			HideFromMap,
			// Token: 0x04000468 RID: 1128
			CanVampire,
			// Token: 0x04000469 RID: 1129
			Ninja,
			// Token: 0x0400046A RID: 1130
			SeeObstructedPlayersOnMap,
			// Token: 0x0400046B RID: 1131
			BackstabResist,
			// Token: 0x0400046C RID: 1132
			CanRecoverAmmoOnKill,
			// Token: 0x0400046D RID: 1133
			MightMaximizeHitDamage,
			// Token: 0x0400046E RID: 1134
			SeeInvisibleEnemiesOnMap
		}

		// Token: 0x02000085 RID: 133
		public enum PlayerAbilityEvent
		{
			// Token: 0x04000470 RID: 1136
			StartCammouflage,
			// Token: 0x04000471 RID: 1137
			StopCammouflage,
			// Token: 0x04000472 RID: 1138
			DropGrenade,
			// Token: 0x04000473 RID: 1139
			EnterMartyrdom,
			// Token: 0x04000474 RID: 1140
			EnterGoBallistic,
			// Token: 0x04000475 RID: 1141
			EndGoBallistic,
			// Token: 0x04000476 RID: 1142
			EnterLastStand,
			// Token: 0x04000477 RID: 1143
			FinishLastStand,
			// Token: 0x04000478 RID: 1144
			RevealEnemyOnMap,
			// Token: 0x04000479 RID: 1145
			ForceStopCammouflage,
			// Token: 0x0400047A RID: 1146
			RevealEnemiesOnScreen,
			// Token: 0x0400047B RID: 1147
			StopRevealingEnemiesOnScreen,
			// Token: 0x0400047C RID: 1148
			KamikazeBlow,
			// Token: 0x0400047D RID: 1149
			RefreshSmartLink,
			// Token: 0x0400047E RID: 1150
			FinishSmartLink,
			// Token: 0x0400047F RID: 1151
			StopRevealingEnemiesOnScreenWithTimer,
			// Token: 0x04000480 RID: 1152
			RevealEnemiesOnScreenSmartLink,
			// Token: 0x04000481 RID: 1153
			RefreshSmartLinkNoTimer,
			// Token: 0x04000482 RID: 1154
			RechargeStamina,
			// Token: 0x04000483 RID: 1155
			RestoreCamouflage,
			// Token: 0x04000484 RID: 1156
			RefreshGrenade
		}

		// Token: 0x02000086 RID: 134
		public enum PlayerEvent
		{
			// Token: 0x04000486 RID: 1158
			IronSightIn,
			// Token: 0x04000487 RID: 1159
			IronSightOut,
			// Token: 0x04000488 RID: 1160
			OnEnemyDie,
			// Token: 0x04000489 RID: 1161
			OnFriendDie,
			// Token: 0x0400048A RID: 1162
			OnBeingHit,
			// Token: 0x0400048B RID: 1163
			OnShotFired,
			// Token: 0x0400048C RID: 1164
			OnDie,
			// Token: 0x0400048D RID: 1165
			OnWeaponSwitch,
			// Token: 0x0400048E RID: 1166
			OnKill,
			// Token: 0x0400048F RID: 1167
			OnFallDmg,
			// Token: 0x04000490 RID: 1168
			OnSpawn,
			// Token: 0x04000491 RID: 1169
			OnEnterLastStand,
			// Token: 0x04000492 RID: 1170
			OnTakingFire,
			// Token: 0x04000493 RID: 1171
			OnTakingFireFromTheFront,
			// Token: 0x04000494 RID: 1172
			OnSufferHeadShot,
			// Token: 0x04000495 RID: 1173
			OnMeleeAttack,
			// Token: 0x04000496 RID: 1174
			OnReload,
			// Token: 0x04000497 RID: 1175
			OnGrenadeToss,
			// Token: 0x04000498 RID: 1176
			OnDeadEnemyNearbyIncrease,
			// Token: 0x04000499 RID: 1177
			OnAliveEnemyNearbyIncrease,
			// Token: 0x0400049A RID: 1178
			OnDeadFriendlyNearbyIncrease,
			// Token: 0x0400049B RID: 1179
			OnAliveFriendlyNearbyIncrease,
			// Token: 0x0400049C RID: 1180
			OnDeadEnemyNearbyDecrease,
			// Token: 0x0400049D RID: 1181
			OnAliveEnemyNearbyDecrease,
			// Token: 0x0400049E RID: 1182
			OnDeadFriendlyNearbyDecrease,
			// Token: 0x0400049F RID: 1183
			OnAliveFriendlyNearbyDecrease,
			// Token: 0x040004A0 RID: 1184
			OnHitLocal,
			// Token: 0x040004A1 RID: 1185
			OnStartMovingInvisible,
			// Token: 0x040004A2 RID: 1186
			OnGetSpottedByEnemy,
			// Token: 0x040004A3 RID: 1187
			OnNotSpottedByAnyEnemy,
			// Token: 0x040004A4 RID: 1188
			OnKamikazeStart,
			// Token: 0x040004A5 RID: 1189
			OnScoreHeadShot,
			// Token: 0x040004A6 RID: 1190
			OnKamikazeKill,
			// Token: 0x040004A7 RID: 1191
			OnCamouflageRestore,
			// Token: 0x040004A8 RID: 1192
			OnBackstab,
			// Token: 0x040004A9 RID: 1193
			OnAmmoRecoveredOnKill,
			// Token: 0x040004AA RID: 1194
			OnRecoveryHealth
		}
	}
}
