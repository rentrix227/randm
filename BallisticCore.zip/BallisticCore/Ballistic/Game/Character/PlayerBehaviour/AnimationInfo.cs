﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.PlayerBehaviour
{
	// Token: 0x02000078 RID: 120
	[Serializable]
	public class AnimationInfo
	{
		// Token: 0x0600012D RID: 301 RVA: 0x00003155 File Offset: 0x00001355
		public AnimationInfo()
		{
			this.show = true;
			this.clip = null;
			this.speed = 1f;
			this.m_duration = 0f;
			this.layer = 0;
			this.blendTime = 0.3f;
		}

		// Token: 0x0600012E RID: 302 RVA: 0x00018EBC File Offset: 0x000170BC
		public AnimationInfo(AnimationInfo p_animationInfo)
			: this()
		{
			if (p_animationInfo == null)
			{
				return;
			}
			this.show = p_animationInfo.show;
			this.speed = p_animationInfo.speed;
			this.clip = p_animationInfo.clip;
			this.m_duration = p_animationInfo.Duration;
			this.layer = p_animationInfo.layer;
			this.blendTime = (float)p_animationInfo.layer;
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x0600012F RID: 303 RVA: 0x00003193 File Offset: 0x00001393
		public string name
		{
			get
			{
				if (this.clip == null)
				{
					return string.Empty;
				}
				if (string.IsNullOrEmpty(this.m_Name))
				{
					this.m_Name = this.clip.name;
				}
				return this.m_Name;
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000130 RID: 304 RVA: 0x000031D3 File Offset: 0x000013D3
		// (set) Token: 0x06000131 RID: 305 RVA: 0x00018F20 File Offset: 0x00017120
		public float Duration
		{
			get
			{
				return this.m_duration;
			}
			set
			{
				this.m_duration = value;
				if (this.clip != null)
				{
					if (this.m_duration <= 0f)
					{
						this.m_duration = this.clip.length;
					}
					this.speed = this.clip.length / this.m_duration;
				}
			}
		}

		// Token: 0x040003D1 RID: 977
		[HideInInspector]
		public bool show;

		// Token: 0x040003D2 RID: 978
		private string m_Name;

		// Token: 0x040003D3 RID: 979
		public AnimationClip clip;

		// Token: 0x040003D4 RID: 980
		public float speed;

		// Token: 0x040003D5 RID: 981
		public int layer;

		// Token: 0x040003D6 RID: 982
		public float blendTime;

		// Token: 0x040003D7 RID: 983
		[HideInInspector]
		public float InCycleWeight;

		// Token: 0x040003D8 RID: 984
		[SerializeField]
		private float m_duration;
	}
}
