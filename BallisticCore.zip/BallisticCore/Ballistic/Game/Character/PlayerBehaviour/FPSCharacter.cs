﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Character.Camouflage;
using Aquiris.Ballistic.Game.Character.Network;
using Aquiris.Ballistic.Game.Character.SkillSystem;
using Aquiris.Ballistic.Game.Character.TeamMaterial;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Loadout;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.PlayerBehaviour
{
	// Token: 0x02000079 RID: 121
	public abstract class FPSCharacter : MonoBehaviour
	{
		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000133 RID: 307 RVA: 0x000031DB File Offset: 0x000013DB
		public Team Team
		{
			get
			{
				return (this.gameClient == null) ? Team.NONE : this.gameClient.team;
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000134 RID: 308 RVA: 0x000031F9 File Offset: 0x000013F9
		public float MaxEnergy
		{
			get
			{
				return this.gameClient.maxHealth;
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000135 RID: 309 RVA: 0x00003206 File Offset: 0x00001406
		public float Energy
		{
			get
			{
				return this.gameClient.health;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000136 RID: 310 RVA: 0x00003213 File Offset: 0x00001413
		public LoadoutInfo currentLoadout
		{
			get
			{
				return this.gameClient.loadoutInfo;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000137 RID: 311 RVA: 0x00018FAC File Offset: 0x000171AC
		public bool IsEnemy
		{
			get
			{
				return this._gameModeService != null && this.gameClient != null && UserProfile.LocalGameClient != null && UserProfile.LocalGameClient.ClientCommonMetaData != null && this._gameModeService.IsEnemy(this.gameClient, UserProfile.LocalGameClient);
			}
		}

		// Token: 0x06000138 RID: 312 RVA: 0x00003220 File Offset: 0x00001420
		protected virtual void Awake()
		{
			this.isDead = true;
			this.isDeadTimestamp = Time.time;
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
		}

		// Token: 0x06000139 RID: 313 RVA: 0x0000323F File Offset: 0x0000143F
		public CamouflageManager GetCamouflageManager()
		{
			return this.m_camouflageManager;
		}

		// Token: 0x0600013A RID: 314 RVA: 0x00003247 File Offset: 0x00001447
		public bool IsPointVisible(Vector3 point)
		{
			return !this.isDead && CameraUtils.IsPointVisible(this.HeadPivot.position, point, World.AllShootableLayers);
		}

		// Token: 0x0600013B RID: 315 RVA: 0x00019000 File Offset: 0x00017200
		protected virtual void CreateSkillController()
		{
			if (this.UseSkillFromLocalPresets)
			{
				this.Skills.InstantiateClassSkills(LoadoutUtil.GetHeroClass(this.currentLoadout));
			}
			else if (!OfflineInformation.OfflineMode)
			{
				HashSet<EHeroSkillV2> hashSet = LoadoutUtil.Skills(this.currentLoadout);
				if (hashSet == null)
				{
					return;
				}
				foreach (EHeroSkillV2 eheroSkillV in hashSet)
				{
					this.Skills.InstantiateSkill(eheroSkillV);
				}
			}
		}

		// Token: 0x0600013C RID: 316 RVA: 0x0000326C File Offset: 0x0000146C
		public LoadoutInfo GetPreviousLoadout()
		{
			return this.m_previousLoadout;
		}

		// Token: 0x0600013D RID: 317 RVA: 0x00003274 File Offset: 0x00001474
		private bool CheckLoadoutChange()
		{
			if (this.m_previousLoadout == null)
			{
				this.m_previousLoadout = this.currentLoadout;
				return true;
			}
			return !this.m_previousLoadout.Equals(this.currentLoadout);
		}

		// Token: 0x0600013E RID: 318 RVA: 0x000032A8 File Offset: 0x000014A8
		public virtual void EnterGoBallistic()
		{
			this.isBallistic = true;
		}

		// Token: 0x0600013F RID: 319 RVA: 0x000032B1 File Offset: 0x000014B1
		public virtual void EndGoBallistic()
		{
			this.isBallistic = false;
		}

		// Token: 0x06000140 RID: 320 RVA: 0x000032BA File Offset: 0x000014BA
		public virtual void Initialize()
		{
			this.InitializeTeamColor();
		}

		// Token: 0x06000141 RID: 321 RVA: 0x000032C2 File Offset: 0x000014C2
		protected void ResetMarked()
		{
			this.state.SetState(PlayerState.State.IsMarked, false);
			this.m_markedCount = 0;
			this.state.SetState(PlayerState.State.IsMarkedOnRadar, false);
			this.m_markedMapCount = 0;
		}

		// Token: 0x06000142 RID: 322
		public abstract void SetMarked(bool isMarked);

		// Token: 0x06000143 RID: 323 RVA: 0x000190A0 File Offset: 0x000172A0
		public void SetMarkedMap(bool isMarked)
		{
			if (isMarked)
			{
				this.m_markedMapCount++;
			}
			else
			{
				this.m_markedMapCount--;
			}
			if (this.m_markedMapCount > 0)
			{
				this.state.SetState(PlayerState.State.IsMarkedOnRadar, true);
			}
			else
			{
				this.state.SetState(PlayerState.State.IsMarkedOnRadar, false);
			}
			if (this.m_markedMapCount < 0)
			{
				this.m_markedMapCount = 0;
			}
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0001911C File Offset: 0x0001731C
		public void AddAnimation(AnimationInfo animationInfo)
		{
			if (this.animatedComponent == null)
			{
				Debug.LogError("Animated Component Is Null: " + base.gameObject.name);
				return;
			}
			if (this.animatedComponent.GetClip(animationInfo.name) == null)
			{
				if (animationInfo.clip == null)
				{
					return;
				}
				this.animatedComponent.AddClip(animationInfo.clip, animationInfo.name);
				this.animatedComponent[animationInfo.name].speed = animationInfo.speed;
				this.animatedComponent[animationInfo.name].layer = animationInfo.layer;
			}
		}

		// Token: 0x06000145 RID: 325 RVA: 0x000032F4 File Offset: 0x000014F4
		public void AddAnimation(AnimationInfo animationInfo, Transform p_mixingTransform)
		{
			this.AddAnimation(animationInfo);
			this.animatedComponent[animationInfo.name].AddMixingTransform(p_mixingTransform);
		}

		// Token: 0x06000146 RID: 326 RVA: 0x00003314 File Offset: 0x00001514
		public void AddAnimation(AnimationInfo animationInfo, Transform p_mixingTransform, int p_layer)
		{
			this.AddAnimation(animationInfo, p_mixingTransform);
			this.animatedComponent[animationInfo.name].layer = p_layer;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x00003335 File Offset: 0x00001535
		public void SetAnimationRunTimeSpeed(AnimationInfo p_info, float p_speed)
		{
			if (p_info == null)
			{
				return;
			}
			if (p_info.clip == null)
			{
				return;
			}
			this.AddAnimation(p_info);
			this.animatedComponent[p_info.name].speed = p_speed;
		}

		// Token: 0x06000148 RID: 328 RVA: 0x000191D4 File Offset: 0x000173D4
		public float GetAnimationRunTimeDuration(AnimationInfo p_info)
		{
			if (p_info == null)
			{
				return -1f;
			}
			if (p_info.clip == null)
			{
				return -1f;
			}
			this.AddAnimation(p_info);
			return this.animatedComponent[p_info.clip.name].length / this.animatedComponent[p_info.clip.name].speed;
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000336E File Offset: 0x0000156E
		public virtual void PlayAnimationCross(AnimationInfo animationInfo)
		{
			if (animationInfo == null || animationInfo.clip == null)
			{
				return;
			}
			this.PlayAnimationCross(animationInfo, animationInfo.blendTime);
		}

		// Token: 0x0600014A RID: 330 RVA: 0x00019244 File Offset: 0x00017444
		public void PlayAnimation(AnimationInfo animationInfo)
		{
			if (animationInfo == null || animationInfo.clip == null)
			{
				return;
			}
			this.AddAnimation(animationInfo);
			if (this.animatedComponent == null)
			{
				return;
			}
			this.animatedComponent.Play(animationInfo.name);
		}

		// Token: 0x0600014B RID: 331 RVA: 0x00019294 File Offset: 0x00017494
		public void PlayAnimationCross(AnimationInfo animationInfo, float blendTime)
		{
			if (animationInfo == null || animationInfo.clip == null)
			{
				return;
			}
			this.AddAnimation(animationInfo);
			if (this.animatedComponent == null)
			{
				return;
			}
			this.animatedComponent.CrossFade(animationInfo.name, blendTime);
		}

		// Token: 0x0600014C RID: 332 RVA: 0x000192E4 File Offset: 0x000174E4
		public void PlayAnimationBlend(AnimationInfo animationInfo, float weight, float p_blendTime)
		{
			if (animationInfo == null || animationInfo.clip == null)
			{
				return;
			}
			this.AddAnimation(animationInfo);
			if (this.animatedComponent == null)
			{
				return;
			}
			this.animatedComponent.Blend(animationInfo.name, weight, p_blendTime);
		}

		// Token: 0x0600014D RID: 333 RVA: 0x00002A31 File Offset: 0x00000C31
		public void DeactivateAnimation(AnimationInfo p_animationInfo)
		{
		}

		// Token: 0x0600014E RID: 334 RVA: 0x00003395 File Offset: 0x00001595
		public void StopAnimations()
		{
			if (this.animatedComponent == null)
			{
				return;
			}
			this.animatedComponent.Stop();
		}

		// Token: 0x0600014F RID: 335 RVA: 0x00019338 File Offset: 0x00017538
		public virtual void Spawn(SpawnEvent evt)
		{
			if (this.Skills == null || !this.Skills.HasInitialized() || this.CheckLoadoutChange())
			{
				if (this.Skills != null)
				{
					this.Skills.Destroy();
					this.Skills = null;
				}
				this.m_previousLoadout = this.currentLoadout;
				this.Skills = HeroDataFactory.BuildPropertyController(this, LoadoutUtil.GetHeroClass(this.currentLoadout), (!this.ForceMaxLevel) ? this.currentLoadout.HeroLevel : 30, 30);
				this.Skills.Init(this);
				this.CreateSkillController();
				this.m_camouflageManager.SetCamouflageEffects(SkillMap.Instance.GetCammoInfo(LoadoutUtil.GetHeroClass(this.currentLoadout)));
			}
			this.DeactivateCamouflage();
			this.m_camouflageManager.Reset();
			this.m_camouflageManager.Team = this.Team;
			this.state.currentLife = this.GetEnergyRatio();
			this.state.gameClientId = this.ownerID;
			this.isDead = false;
			this.isBallistic = false;
			if (this.Skills != null)
			{
				this.Skills.FireEvent(SkillEnums.PlayerEvent.OnSpawn);
			}
		}

		// Token: 0x06000150 RID: 336 RVA: 0x000033B4 File Offset: 0x000015B4
		protected virtual void OnSpawnComplete()
		{
			this.m_camouflageManager.SetBaseGameObject(this.m_BodyRenderer.gameObject);
		}

		// Token: 0x06000151 RID: 337 RVA: 0x000033CC File Offset: 0x000015CC
		public float GetEnergyRatio()
		{
			if (this.MaxEnergy <= 0f)
			{
				return 0f;
			}
			return this.Energy / this.MaxEnergy;
		}

		// Token: 0x06000152 RID: 338 RVA: 0x00019468 File Offset: 0x00017668
		protected void SetBodyShader(Shader p_targetShader = null)
		{
			if (this.m_BodyOriginalShader == null)
			{
				return;
			}
			foreach (KeyValuePair<SkinnedMeshRenderer, Shader> keyValuePair in this.m_BodyOriginalShader)
			{
				if (!(keyValuePair.Key == null))
				{
					Shader shader = p_targetShader;
					if (p_targetShader == null)
					{
						shader = keyValuePair.Value;
					}
					if (keyValuePair.Key.material.shader != shader)
					{
						keyValuePair.Key.material.shader = shader;
					}
				}
			}
		}

		// Token: 0x06000153 RID: 339 RVA: 0x00002A31 File Offset: 0x00000C31
		protected virtual void OnDisable()
		{
		}

		// Token: 0x06000154 RID: 340 RVA: 0x000033F1 File Offset: 0x000015F1
		public virtual void LateUpdate()
		{
			this.m_camouflageManager.Refresh();
		}

		// Token: 0x06000155 RID: 341 RVA: 0x000033FE File Offset: 0x000015FE
		public void ActivateCamouflage()
		{
			if (!this.state.GetState(PlayerState.State.IsInvisible))
			{
				this.state.SetState(PlayerState.State.IsInvisible, true);
			}
			this.OnCamouflageActivate();
		}

		// Token: 0x06000156 RID: 342 RVA: 0x0000342D File Offset: 0x0000162D
		public void DeactivateCamouflage()
		{
			if (this.state.GetState(PlayerState.State.IsInvisible))
			{
				this.state.SetState(PlayerState.State.IsInvisible, false);
			}
			this.OnCamouflageDeactivate();
		}

		// Token: 0x06000157 RID: 343 RVA: 0x00019528 File Offset: 0x00017728
		protected void CreateCloneForInvisibilityAnimation(Transform p_trans)
		{
			if (this.m_camouflageManager.HasCamouflageObject(p_trans.gameObject))
			{
				return;
			}
			if (this.m_camouflageManager.GetCamouflageEffects() == null)
			{
				this.m_camouflageManager.SetCamouflageEffects(SkillMap.Instance.GetCammoInfo(LoadoutUtil.GetHeroClass(this.currentLoadout)));
				if (this.m_camouflageManager.GetCamouflageEffects() == null)
				{
					return;
				}
			}
			this.m_camouflageManager.AddCamouflageObject(p_trans.gameObject);
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0000345C File Offset: 0x0000165C
		protected virtual bool OnCamouflageActivate()
		{
			if (this.m_camouflageManager.IsCamouflaged)
			{
				return false;
			}
			this.m_camouflageManager.GoInvisible();
			return true;
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0000347C File Offset: 0x0000167C
		protected virtual bool OnCamouflageDeactivate()
		{
			if (!this.m_camouflageManager.IsCamouflaged)
			{
				return false;
			}
			this.m_camouflageManager.GoVisible();
			return true;
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0000349C File Offset: 0x0000169C
		public void SetMarkedLocalChar()
		{
			this.m_hasMarkedLocalChar = true;
		}

		// Token: 0x0600015B RID: 347 RVA: 0x000195A0 File Offset: 0x000177A0
		protected void InitializeTeamColor()
		{
			bool flag = this.gameClient.team == Team.MFA;
			SoldierViewSkinController[] componentsInChildren = base.GetComponentsInChildren<SoldierViewSkinController>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].SetTeamColor(flag);
			}
		}

		// Token: 0x0600015C RID: 348 RVA: 0x000195DC File Offset: 0x000177DC
		protected void UpdateTeamColor()
		{
			TeamBasedColorMaterial[] componentsInChildren = base.GetComponentsInChildren<TeamBasedColorMaterial>(true);
			if (componentsInChildren != null)
			{
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					componentsInChildren[i].SetTeam(this.Team);
				}
			}
		}

		// Token: 0x040003D9 RID: 985
		protected GameModeService _gameModeService;

		// Token: 0x040003DA RID: 986
		public long ownerID = -1L;

		// Token: 0x040003DB RID: 987
		public PlayerState state = default(PlayerState);

		// Token: 0x040003DC RID: 988
		public Animation animatedComponent;

		// Token: 0x040003DD RID: 989
		public IPropertyController Skills;

		// Token: 0x040003DE RID: 990
		public GameClient gameClient;

		// Token: 0x040003DF RID: 991
		public bool isDead;

		// Token: 0x040003E0 RID: 992
		public float isDeadTimestamp;

		// Token: 0x040003E1 RID: 993
		public bool isBallistic;

		// Token: 0x040003E2 RID: 994
		public Vector3 movementVector;

		// Token: 0x040003E3 RID: 995
		public Shader InvisibleShader;

		// Token: 0x040003E4 RID: 996
		public bool UseSkillFromLocalPresets;

		// Token: 0x040003E5 RID: 997
		public bool ForceMaxLevel;

		// Token: 0x040003E6 RID: 998
		public Transform[] VisibilityPivots;

		// Token: 0x040003E7 RID: 999
		public Transform HeadPivot;

		// Token: 0x040003E8 RID: 1000
		protected Transform weaponParent;

		// Token: 0x040003E9 RID: 1001
		[HideInInspector]
		public Transform rightHandParent;

		// Token: 0x040003EA RID: 1002
		[HideInInspector]
		public Transform leftHandParent;

		// Token: 0x040003EB RID: 1003
		protected Dictionary<SkinnedMeshRenderer, Shader> m_BodyOriginalShader;

		// Token: 0x040003EC RID: 1004
		protected Shader[] m_WeaponOriginalShader;

		// Token: 0x040003ED RID: 1005
		protected SkinnedMeshRenderer m_BodyRenderer;

		// Token: 0x040003EE RID: 1006
		protected SkinnedMeshRenderer m_InvisibleBodyRenderer;

		// Token: 0x040003EF RID: 1007
		protected Shader[] m_VanityOriginalShader;

		// Token: 0x040003F0 RID: 1008
		protected Renderer[] m_VanityRenderers;

		// Token: 0x040003F1 RID: 1009
		public Renderer[] CurrentWeaponRenderers;

		// Token: 0x040003F2 RID: 1010
		protected int m_markedCount;

		// Token: 0x040003F3 RID: 1011
		protected int m_markedMapCount;

		// Token: 0x040003F4 RID: 1012
		private LoadoutInfo m_previousLoadout;

		// Token: 0x040003F5 RID: 1013
		protected bool m_hasMarkedLocalChar;

		// Token: 0x040003F6 RID: 1014
		protected float m_secondWindDeltaLife;

		// Token: 0x040003F7 RID: 1015
		protected float m_secondWindRecoverTime;

		// Token: 0x040003F8 RID: 1016
		protected float m_secondWindRecoverLife;

		// Token: 0x040003F9 RID: 1017
		protected int weaponStationId;

		// Token: 0x040003FA RID: 1018
		protected CamouflageManager m_camouflageManager;
	}
}
