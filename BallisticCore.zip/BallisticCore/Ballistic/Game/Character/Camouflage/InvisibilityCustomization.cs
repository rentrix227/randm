﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.Camouflage
{
	// Token: 0x02000070 RID: 112
	public class InvisibilityCustomization : MonoBehaviour
	{
		// Token: 0x04000387 RID: 903
		public bool DisableHierarchy;
	}
}
