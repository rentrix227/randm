﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Character.SkillSystem;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.Camouflage
{
	// Token: 0x0200006E RID: 110
	public class CamouflageManager
	{
		// Token: 0x06000102 RID: 258 RVA: 0x00017F7C File Offset: 0x0001617C
		public CamouflageManager(bool p_isLocalCharacter)
		{
			this.IsLocalCharacter = p_isLocalCharacter;
			this.m_camouflageEffects = null;
			this.m_camouflageObjects = new Dictionary<CamouflageManager.CamouflageElement, List<CamouflageManager.CamouflageElement>>();
			this.m_invisibleObjects = new List<GameObject>();
			this.m_materialPropertyBlock = new MaterialPropertyBlock();
			this.m_toRemove = new List<CamouflageManager.CamouflageElement>();
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000103 RID: 259 RVA: 0x00002FA9 File Offset: 0x000011A9
		// (set) Token: 0x06000104 RID: 260 RVA: 0x00002FB1 File Offset: 0x000011B1
		public bool IsLocalCharacter { get; private set; }

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000105 RID: 261 RVA: 0x00002FBA File Offset: 0x000011BA
		// (set) Token: 0x06000106 RID: 262 RVA: 0x00002FC2 File Offset: 0x000011C2
		public Team Team { get; set; }

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000107 RID: 263 RVA: 0x00002FCB File Offset: 0x000011CB
		// (set) Token: 0x06000108 RID: 264 RVA: 0x00002FD3 File Offset: 0x000011D3
		public bool IsCamouflaged { get; private set; }

		// Token: 0x06000109 RID: 265 RVA: 0x00017FCC File Offset: 0x000161CC
		public void SetBaseGameObject(GameObject p_baseGameObject)
		{
			this.m_baseGameObject = p_baseGameObject;
			this.m_baseRenderer = this.m_baseGameObject.GetComponent<Renderer>();
			GameObject gameObject = this.FindObject(this.m_baseGameObject, "invisible");
			if (gameObject != null)
			{
				this.m_invisibleGameObject = gameObject;
				this.m_invisibleRenderer = gameObject.GetComponent<SkinnedMeshRenderer>();
			}
			else
			{
				this.m_invisibleGameObject = null;
			}
		}

		// Token: 0x0600010A RID: 266 RVA: 0x00018030 File Offset: 0x00016230
		public GameObject FindObject(GameObject parent, string name)
		{
			Transform[] componentsInChildren = parent.GetComponentsInChildren<Transform>(true);
			foreach (Transform transform in componentsInChildren)
			{
				if (transform.name == name)
				{
					return transform.gameObject;
				}
			}
			return null;
		}

		// Token: 0x0600010B RID: 267 RVA: 0x00002FDC File Offset: 0x000011DC
		public GameObject GetBaseGameObject()
		{
			return this.m_baseGameObject;
		}

		// Token: 0x0600010C RID: 268 RVA: 0x00002FE4 File Offset: 0x000011E4
		public GameObject GetInvisibleGameObject()
		{
			return this.m_invisibleGameObject;
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00002FEC File Offset: 0x000011EC
		public void SetBaseAnimator(Animator p_baseAnimator)
		{
			this.m_baseAnimator = p_baseAnimator;
		}

		// Token: 0x0600010E RID: 270 RVA: 0x00002FF5 File Offset: 0x000011F5
		public Animator GetBaseAnimator()
		{
			return this.m_baseAnimator;
		}

		// Token: 0x0600010F RID: 271 RVA: 0x00002FFD File Offset: 0x000011FD
		public void SetCamouflageEffects(SkillMap.CamouflageEffects p_camouflageEffects)
		{
			this.m_camouflageEffects = p_camouflageEffects;
		}

		// Token: 0x06000110 RID: 272 RVA: 0x00003006 File Offset: 0x00001206
		public SkillMap.CamouflageEffects GetCamouflageEffects()
		{
			return this.m_camouflageEffects;
		}

		// Token: 0x06000111 RID: 273 RVA: 0x0000300E File Offset: 0x0000120E
		public void Reset()
		{
			this.m_camouflageObjects.Clear();
		}

		// Token: 0x06000112 RID: 274 RVA: 0x00018078 File Offset: 0x00016278
		public void Refresh()
		{
			if (this.m_baseGameObject == null || this.m_baseAnimator == null)
			{
				return;
			}
			if (this.m_invisibleRenderer == null)
			{
				return;
			}
			if (this.m_invisibleRenderer.enabled)
			{
				this.m_materialPropertyBlock.Clear();
				this.m_invisibleRenderer.GetPropertyBlock(this.m_materialPropertyBlock);
			}
			if (this.m_baseAnimator == null)
			{
				Debug.LogError("[CamouflageManager::GoInvisible] BaseAnimator is null! Please, do something!");
				return;
			}
			this.m_baseAnimator.SetBool("IsInvisible", this.IsCamouflaged);
			this.m_toRemove.Clear();
			foreach (KeyValuePair<CamouflageManager.CamouflageElement, List<CamouflageManager.CamouflageElement>> keyValuePair in this.m_camouflageObjects)
			{
				if (keyValuePair.Key.GObject == null)
				{
					this.m_toRemove.Add(keyValuePair.Key);
				}
				else
				{
					keyValuePair.Key.GObject.SetActive(this.m_invisibleGameObject.activeSelf);
					keyValuePair.Key.Renderer.enabled = this.m_invisibleRenderer.enabled;
					if (keyValuePair.Key.Renderer.enabled)
					{
						keyValuePair.Key.Renderer.SetPropertyBlock(this.m_materialPropertyBlock);
					}
					List<CamouflageManager.CamouflageElement> value = keyValuePair.Value;
					for (int i = 0; i < value.Count; i++)
					{
						value[i].Renderer.enabled = this.m_baseRenderer.enabled;
					}
				}
			}
			for (int j = 0; j < this.m_toRemove.Count; j++)
			{
				this.m_camouflageObjects.Remove(this.m_toRemove[j]);
			}
		}

		// Token: 0x06000113 RID: 275 RVA: 0x0000301B File Offset: 0x0000121B
		public bool HasCamouflageObject(GameObject gameObject)
		{
			return this.m_camouflageObjects.ContainsKey(new CamouflageManager.CamouflageElement(gameObject));
		}

		// Token: 0x06000114 RID: 276 RVA: 0x0001829C File Offset: 0x0001649C
		public void AddCamouflageObject(GameObject gameObject)
		{
			IEnumerator enumerator = gameObject.transform.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					Transform transform = (Transform)obj;
					this.AddCamouflageObject(transform.gameObject);
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			if (gameObject.name == "invisible" || gameObject.transform.Find("invisible") != null || gameObject.GetComponent<InvisibilityCustomization>() != null || (gameObject.GetComponent<MeshRenderer>() == null && gameObject.GetComponent<SkinnedMeshRenderer>() == null))
			{
				return;
			}
			GameObject gameObject2 = Object.Instantiate<GameObject>(gameObject);
			gameObject2.transform.parent = gameObject.transform;
			gameObject2.transform.localRotation = Quaternion.identity;
			gameObject2.transform.localScale = Vector3.one;
			gameObject2.transform.localPosition = Vector3.zero;
			gameObject2.name = "invisible";
			gameObject2.tag = "Invisible";
			Renderer renderer = gameObject2.GetComponent<MeshRenderer>();
			if (renderer == null)
			{
				renderer = gameObject2.GetComponent<SkinnedMeshRenderer>();
			}
			if (renderer == null)
			{
				return;
			}
			if (this.IsLocalCharacter)
			{
				renderer.material = this.m_camouflageEffects.WeaponMaterial;
			}
			else
			{
				renderer.material = this.m_camouflageEffects.WeaponMaterial3rd;
			}
			renderer.material.SetFloat("_Team", (this.Team != Team.MFA) ? 1f : 0f);
			gameObject2.SetActive(false);
			for (int i = 0; i < gameObject2.transform.childCount; i++)
			{
				Object.Destroy(gameObject2.transform.GetChild(i).gameObject);
			}
			List<CamouflageManager.CamouflageElement> list = new List<CamouflageManager.CamouflageElement>();
			list.Add(new CamouflageManager.CamouflageElement(gameObject));
			this.m_camouflageObjects.Add(new CamouflageManager.CamouflageElement(gameObject2), list);
		}

		// Token: 0x06000115 RID: 277 RVA: 0x000184B8 File Offset: 0x000166B8
		public void GoInvisible()
		{
			if (this.IsCamouflaged)
			{
				return;
			}
			if (this.m_baseAnimator == null)
			{
				Debug.LogError("[CamouflageManager::GoInvisible] BaseAnimator is null! Please, do something!");
				return;
			}
			this.IsCamouflaged = true;
			this.m_invisibleObjects.Clear();
			foreach (ParticleSystem particleSystem in this.m_baseGameObject.GetComponentsInChildren<ParticleSystem>())
			{
				if (particleSystem.gameObject.activeSelf)
				{
					particleSystem.gameObject.SetActive(false);
					this.m_invisibleObjects.Add(particleSystem.gameObject);
				}
			}
			foreach (InvisibilityCustomization invisibilityCustomization in this.m_baseGameObject.GetComponentsInChildren<InvisibilityCustomization>())
			{
				if (invisibilityCustomization.DisableHierarchy)
				{
					invisibilityCustomization.gameObject.SetActive(false);
					this.m_invisibleObjects.Add(invisibilityCustomization.gameObject);
				}
			}
			if (this.OnGoInvisible != null)
			{
				this.OnGoInvisible();
			}
		}

		// Token: 0x06000116 RID: 278 RVA: 0x000185BC File Offset: 0x000167BC
		public void GoVisible()
		{
			if (!this.IsCamouflaged)
			{
				return;
			}
			if (this.m_baseAnimator == null)
			{
				Debug.LogError("[CamouflageManager::GoVisible] BaseAnimator is null! Please, do something!");
				return;
			}
			this.IsCamouflaged = false;
			foreach (GameObject gameObject in this.m_invisibleObjects)
			{
				if (!(gameObject == null))
				{
					gameObject.SetActive(true);
				}
			}
			this.m_invisibleObjects.Clear();
			if (this.OnGoVisible != null)
			{
				this.OnGoVisible();
			}
		}

		// Token: 0x04000379 RID: 889
		public Action OnGoInvisible;

		// Token: 0x0400037A RID: 890
		public Action OnGoVisible;

		// Token: 0x0400037B RID: 891
		private GameObject m_baseGameObject;

		// Token: 0x0400037C RID: 892
		private Renderer m_baseRenderer;

		// Token: 0x0400037D RID: 893
		private GameObject m_invisibleGameObject;

		// Token: 0x0400037E RID: 894
		private SkinnedMeshRenderer m_invisibleRenderer;

		// Token: 0x0400037F RID: 895
		private MaterialPropertyBlock m_materialPropertyBlock;

		// Token: 0x04000380 RID: 896
		private Animator m_baseAnimator;

		// Token: 0x04000381 RID: 897
		private SkillMap.CamouflageEffects m_camouflageEffects;

		// Token: 0x04000382 RID: 898
		private Dictionary<CamouflageManager.CamouflageElement, List<CamouflageManager.CamouflageElement>> m_camouflageObjects;

		// Token: 0x04000383 RID: 899
		private List<GameObject> m_invisibleObjects;

		// Token: 0x04000384 RID: 900
		private List<CamouflageManager.CamouflageElement> m_toRemove;

		// Token: 0x0200006F RID: 111
		public struct CamouflageElement
		{
			// Token: 0x06000117 RID: 279 RVA: 0x0000302E File Offset: 0x0000122E
			public CamouflageElement(GameObject original)
			{
				this.GObject = original;
				this.Renderer = original.GetComponent<Renderer>();
			}

			// Token: 0x04000385 RID: 901
			public GameObject GObject;

			// Token: 0x04000386 RID: 902
			public Renderer Renderer;
		}
	}
}
