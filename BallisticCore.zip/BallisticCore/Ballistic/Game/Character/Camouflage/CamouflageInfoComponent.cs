﻿using System;
using Aquiris.Ballistic.Game.Character.SkillSystem;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.Camouflage
{
	// Token: 0x0200006D RID: 109
	public class CamouflageInfoComponent : MonoBehaviour
	{
		// Token: 0x06000100 RID: 256 RVA: 0x00002FA1 File Offset: 0x000011A1
		public void Awake()
		{
			this.PopulateSkillmap();
		}

		// Token: 0x06000101 RID: 257 RVA: 0x00017EF4 File Offset: 0x000160F4
		public void PopulateSkillmap()
		{
			bool flag = false;
			SkillMap.CamouflageEffects cammoInfo = SkillMap.Instance.GetCammoInfo(this.HeroClass);
			if (cammoInfo == null)
			{
				flag = true;
			}
			else if (cammoInfo.WeaponMaterial3rd == null && this.IsThirdPerson)
			{
				flag = true;
			}
			else if (cammoInfo.WeaponMaterial == null && !this.IsThirdPerson)
			{
				flag = true;
			}
			if (flag)
			{
				SkillMap.Instance.SetCammoInfo(this.HeroClass, this);
			}
		}

		// Token: 0x04000373 RID: 883
		public EHeroClass HeroClass;

		// Token: 0x04000374 RID: 884
		public bool IsThirdPerson;

		// Token: 0x04000375 RID: 885
		public Material WeaponMaterial;
	}
}
