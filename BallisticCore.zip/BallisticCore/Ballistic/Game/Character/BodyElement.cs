﻿using System;

namespace Aquiris.Ballistic.Game.Character
{
	// Token: 0x0200006C RID: 108
	public enum BodyElement
	{
		// Token: 0x04000368 RID: 872
		HEAD,
		// Token: 0x04000369 RID: 873
		ARM,
		// Token: 0x0400036A RID: 874
		FOREARM,
		// Token: 0x0400036B RID: 875
		HAND,
		// Token: 0x0400036C RID: 876
		CHEST,
		// Token: 0x0400036D RID: 877
		STOMACH,
		// Token: 0x0400036E RID: 878
		ADBOMEN,
		// Token: 0x0400036F RID: 879
		LEG,
		// Token: 0x04000370 RID: 880
		SHIN,
		// Token: 0x04000371 RID: 881
		FEET,
		// Token: 0x04000372 RID: 882
		NONE
	}
}
