﻿using System;
using System.Linq;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.Accessories
{
	// Token: 0x02000069 RID: 105
	public class DieBehaviour : MonoBehaviour
	{
		// Token: 0x060000F4 RID: 244 RVA: 0x00002EC7 File Offset: 0x000010C7
		public void LateUpdate()
		{
			if (this.DieAnimator.isInitialized)
			{
				this.DieAnimator.SetBool(DieBehaviour._animatorHashDie, this._isDead);
			}
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x00002EEF File Offset: 0x000010EF
		public void Spawn()
		{
			this._isDead = false;
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x00002EF8 File Offset: 0x000010F8
		public void Die(EDamageType damageType)
		{
			if (this.DieDamageType.Contains(damageType))
			{
				this._isDead = true;
			}
		}

		// Token: 0x0400034F RID: 847
		private static int _animatorHashDie = Animator.StringToHash("die");

		// Token: 0x04000350 RID: 848
		private bool _isDead;

		// Token: 0x04000351 RID: 849
		public Animator DieAnimator;

		// Token: 0x04000352 RID: 850
		public EDamageType[] DieDamageType = new EDamageType[0];
	}
}
