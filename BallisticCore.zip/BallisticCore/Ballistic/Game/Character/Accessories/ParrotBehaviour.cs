﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.Accessories
{
	// Token: 0x0200006A RID: 106
	public class ParrotBehaviour : MonoBehaviour
	{
		// Token: 0x060000F9 RID: 249 RVA: 0x00017C4C File Offset: 0x00015E4C
		public void Awake()
		{
			this._currentState = ParrotBehaviour.ParrotState.Normal;
			this._parrotParent = base.transform.parent;
			this._parrotAnimator = base.GetComponent<Animator>();
			this._parrotLastPosition = base.transform.position;
			this._lastCalculatedRotation = base.transform.rotation;
			this._parrotLastRotation = base.transform.rotation;
			this._rigidbodies = base.GetComponentsInChildren<Rigidbody>();
			this._shotsTaken = 0;
		}

		// Token: 0x060000FA RID: 250 RVA: 0x00017CC4 File Offset: 0x00015EC4
		public void LateUpdate()
		{
			if (this._parrotParent != null && this._currentState == ParrotBehaviour.ParrotState.Normal)
			{
				float num = Mathf.Clamp01(Vector3.Distance(this._parrotLastPosition, this._parrotParent.position) / 2f);
				float num2 = Quaternion.Angle(this._parrotLastRotation, this._parrotParent.rotation);
				float num3 = Mathf.Clamp(num2 / 90f, 0f, 1f);
				if (num2 > 30f)
				{
					this._parrotAnimator.SetFloat(ParrotBehaviour._animatorHashForwardSpeed, -num3);
				}
				else
				{
					this._parrotAnimator.SetFloat(ParrotBehaviour._animatorHashForwardSpeed, num);
				}
				if (Vector3.SqrMagnitude(this._parrotParent.position - this._parrotLastPosition) > 0.75f)
				{
					this._lastCalculatedRotation = Quaternion.LookRotation((this._parrotParent.position - this._parrotLastPosition).normalized);
				}
				else
				{
					this._lastCalculatedRotation = this._parrotParent.rotation;
				}
				this._parrotLastPosition = Vector3.Lerp(this._parrotLastPosition, this._parrotParent.position, this._parrotDirectionalSmooth * Time.deltaTime);
				base.transform.position = this._parrotLastPosition;
				this._parrotLastRotation = Quaternion.Slerp(this._parrotLastRotation, this._lastCalculatedRotation, this._parrotRotationalSmooth * Time.deltaTime);
				base.transform.rotation = this._parrotLastRotation;
			}
			if (this._currentState == ParrotBehaviour.ParrotState.Dead)
			{
				this._afterDieTime -= Time.deltaTime;
				if (this._afterDieTime < 0f)
				{
					Object.Destroy(base.gameObject);
				}
			}
		}

		// Token: 0x060000FB RID: 251 RVA: 0x00002F41 File Offset: 0x00001141
		public void TakeHit(RaycastHit p_hitInfo, bool p_isFirstPerson)
		{
			this._shotsTaken++;
			this._parrotParticle.Play();
			if (this._currentState == ParrotBehaviour.ParrotState.Dead)
			{
				return;
			}
			if (this._shotsTaken >= 3)
			{
				this.Die();
			}
		}

		// Token: 0x060000FC RID: 252 RVA: 0x00002F7B File Offset: 0x0000117B
		public void TakeExplosion(bool isFirstPerson)
		{
			if (this._currentState == ParrotBehaviour.ParrotState.Dead)
			{
				return;
			}
			this.Die();
		}

		// Token: 0x060000FD RID: 253 RVA: 0x00017E7C File Offset: 0x0001607C
		public void Die()
		{
			if (this._currentState == ParrotBehaviour.ParrotState.Dead)
			{
				return;
			}
			this._currentState = ParrotBehaviour.ParrotState.Dead;
			this._afterDieTime = 4f;
			base.transform.parent = null;
			if (this._rigidbodies != null)
			{
				this._parrotAnimator.enabled = false;
				foreach (Rigidbody rigidbody in this._rigidbodies)
				{
					rigidbody.isKinematic = false;
				}
			}
		}

		// Token: 0x04000353 RID: 851
		private static int _animatorHashForwardSpeed = Animator.StringToHash("ForwardSpeed");

		// Token: 0x04000354 RID: 852
		private const float _parrotMaxDistance = 2f;

		// Token: 0x04000355 RID: 853
		private const float _parrotMaxRotationAngle = 90f;

		// Token: 0x04000356 RID: 854
		private Vector3 _parrotLastPosition;

		// Token: 0x04000357 RID: 855
		private Quaternion _parrotLastRotation;

		// Token: 0x04000358 RID: 856
		public float _parrotDirectionalSmooth = 3f;

		// Token: 0x04000359 RID: 857
		public float _parrotRotationalSmooth = 3f;

		// Token: 0x0400035A RID: 858
		public ParticleSystem _parrotParticle;

		// Token: 0x0400035B RID: 859
		private Animator _parrotAnimator;

		// Token: 0x0400035C RID: 860
		private Transform _parrotParent;

		// Token: 0x0400035D RID: 861
		private ParrotBehaviour.ParrotState _currentState;

		// Token: 0x0400035E RID: 862
		private Rigidbody[] _rigidbodies;

		// Token: 0x0400035F RID: 863
		private const float _afterDieSeconds = 4f;

		// Token: 0x04000360 RID: 864
		private const int _shotsToDie = 3;

		// Token: 0x04000361 RID: 865
		private float _afterDieTime;

		// Token: 0x04000362 RID: 866
		private int _shotsTaken;

		// Token: 0x04000363 RID: 867
		private Quaternion _lastCalculatedRotation;

		// Token: 0x0200006B RID: 107
		public enum ParrotState
		{
			// Token: 0x04000365 RID: 869
			Normal,
			// Token: 0x04000366 RID: 870
			Dead
		}
	}
}
