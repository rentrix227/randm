﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Character.Outline
{
	// Token: 0x02000077 RID: 119
	public class CharacterOutlineData : ScriptableObject
	{
		// Token: 0x17000018 RID: 24
		// (get) Token: 0x0600012C RID: 300 RVA: 0x00003115 File Offset: 0x00001315
		public static CharacterOutlineData Instance
		{
			get
			{
				if (CharacterOutlineData._instance == null)
				{
					CharacterOutlineData._instance = Resources.Load<CharacterOutlineData>("CharacterOutlineData");
					if (CharacterOutlineData._instance == null)
					{
						Debug.LogError("[CharacterOutlineData] Could not find UIWeaponData asset");
					}
				}
				return CharacterOutlineData._instance;
			}
		}

		// Token: 0x040003CD RID: 973
		public Material OutlineEnemy;

		// Token: 0x040003CE RID: 974
		public Material OutlineTeammate;

		// Token: 0x040003CF RID: 975
		public Material OutlineJuggernaut;

		// Token: 0x040003D0 RID: 976
		private static CharacterOutlineData _instance;
	}
}
