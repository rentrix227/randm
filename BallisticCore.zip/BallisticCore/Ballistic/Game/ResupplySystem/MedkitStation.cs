﻿using System;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.ConfigItemModel.GameMapModel;
using Aquiris.DataModel.ItemModel.ConfigItemModel.GameMapModel.GameModeModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.ResupplySystem
{
	// Token: 0x02000111 RID: 273
	public class MedkitStation : MonoBehaviour
	{
		// Token: 0x0600053E RID: 1342 RVA: 0x0002623C File Offset: 0x0002443C
		internal void Initialize(string MedKitConfigName, string MedKitLocationName)
		{
			this._medKitConfigName = MedKitConfigName;
			this._medKitLocationName = MedKitLocationName;
			this._playerLayer = LayerMask.NameToLayer("FPSPlayer");
			this._animator = base.GetComponent<Animator>();
			this._rigidbody = base.gameObject.AddComponent<Rigidbody>();
			this._rigidbody.useGravity = false;
			this._rigidbody.isKinematic = true;
			this._cooldownMaterial = base.transform.Find("cooldown/health_cooldown").GetComponent<Renderer>().material;
			bool flag = MedKitConfigName == "recover_50";
			base.transform.Find("pickups/health_pickup_small").gameObject.SetActive(flag);
			base.transform.Find("pickups/health_pickup_big").gameObject.SetActive(!flag);
			this._state = MedkitStation.MedkitState.NONE;
			this._cooldownTimeSinceLastUpdate = 0.0;
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			ResupplyService service = ServiceProvider.GetService<ResupplyService>();
			GameConfig gameConfig = this._networkGameService.GetGameModeMetaData().GameConfig;
			GameModeConfig gameModeConfig = ServiceProvider.GetService<GameMapModeConfigService>().GetGameModeConfig((ulong)gameConfig.GameMap, gameConfig.GameMode);
			foreach (ResupplyConfigEntry resupplyConfigEntry in gameModeConfig.ResupplyEntryList)
			{
				if (resupplyConfigEntry.ResupplyLocation == MedKitConfigName)
				{
					this._cooldownTotal = (double)service.GetResupplyFromResupplyConfigEntry(resupplyConfigEntry).CooldownInSeconds;
					break;
				}
			}
			ResupplyState resupplyState = service.GetResupplyState(MedKitLocationName);
			this.UpdateState(resupplyState.Active, resupplyState.Cooldown, true);
			this._networkGameService.OnResupplyResponse.AddListener(new Action<ResupplyEvent>(this.OnResupplyResponse));
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x0002640C File Offset: 0x0002460C
		public void Update()
		{
			if (this._state != MedkitStation.MedkitState.DISABLED)
			{
				return;
			}
			this._cooldownTimeSinceLastUpdate += (double)Time.deltaTime;
			this._cooldownMaterial.SetFloat("_Fill", Mathf.Min((float)((this._cooldownTotal - this._cooldownRemaning + this._cooldownTimeSinceLastUpdate) / this._cooldownTotal), 1f));
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x00005F3A File Offset: 0x0000413A
		public void OnDestroy()
		{
			if (this._networkGameService != null)
			{
				this._networkGameService.OnResupplyResponse.RemoveListener(new Action<ResupplyEvent>(this.OnResupplyResponse));
			}
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x00005F63 File Offset: 0x00004163
		private void OnResupplyResponse(ResupplyEvent evt)
		{
			if (evt.ResupplyLocationName != this._medKitLocationName)
			{
				return;
			}
			this._requestDispatched = false;
			this.UpdateState(evt.IsActive, evt.Cooldown, false);
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x00026470 File Offset: 0x00024670
		private void UpdateState(bool state, double cooldown, bool force = false)
		{
			if ((this._state != MedkitStation.MedkitState.DISABLED || force) && !state)
			{
				this._state = MedkitStation.MedkitState.DISABLED;
				this._animator.SetBool(MedkitStation._animatorState, false);
			}
			else if ((this._state != MedkitStation.MedkitState.ACTIVE || force) && state)
			{
				this._state = MedkitStation.MedkitState.ACTIVE;
				this._animator.SetBool(MedkitStation._animatorState, true);
			}
			this._cooldownRemaning = cooldown;
			this._cooldownTimeSinceLastUpdate = 0.0;
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x000264F8 File Offset: 0x000246F8
		public void OnTriggerEnter(Collider collider)
		{
			if (collider.gameObject.layer != this._playerLayer)
			{
				return;
			}
			if (this._gameModeService.State != GameModeState.Ready)
			{
				return;
			}
			if (UserProfile.LocalGameClient.health >= UserProfile.LocalGameClient.maxHealth - 0.01f && UserProfile.LocalGameClient.spawned)
			{
				return;
			}
			if (this._requestDispatched)
			{
				return;
			}
			this._requestDispatched = true;
			ResupplyRequest resupplyRequest = new ResupplyRequest
			{
				ResupplyLocationName = this._medKitLocationName,
				ResupplyConfigName = this._medKitConfigName
			};
			this._networkGameService.RaiseNetworkEvent(resupplyRequest);
			this.UpdateState(false, 0.0, false);
		}

		// Token: 0x040007BD RID: 1981
		private static readonly int _animatorState = Animator.StringToHash("state");

		// Token: 0x040007BE RID: 1982
		private int _playerLayer;

		// Token: 0x040007BF RID: 1983
		private Animator _animator;

		// Token: 0x040007C0 RID: 1984
		private Rigidbody _rigidbody;

		// Token: 0x040007C1 RID: 1985
		private Material _cooldownMaterial;

		// Token: 0x040007C2 RID: 1986
		private NetworkGameService _networkGameService;

		// Token: 0x040007C3 RID: 1987
		private GameModeService _gameModeService;

		// Token: 0x040007C4 RID: 1988
		private MedkitStation.MedkitState _state;

		// Token: 0x040007C5 RID: 1989
		private double _cooldownTotal;

		// Token: 0x040007C6 RID: 1990
		private double _cooldownRemaning;

		// Token: 0x040007C7 RID: 1991
		private double _cooldownTimeSinceLastUpdate;

		// Token: 0x040007C8 RID: 1992
		private bool _requestDispatched;

		// Token: 0x040007C9 RID: 1993
		private string _medKitConfigName;

		// Token: 0x040007CA RID: 1994
		private string _medKitLocationName;

		// Token: 0x02000112 RID: 274
		internal enum MedkitState
		{
			// Token: 0x040007CC RID: 1996
			NONE,
			// Token: 0x040007CD RID: 1997
			ACTIVE,
			// Token: 0x040007CE RID: 1998
			DISABLED
		}
	}
}
