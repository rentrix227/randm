﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.ResupplySystem
{
	// Token: 0x02000113 RID: 275
	public class WeaponStation : MonoBehaviour
	{
		// Token: 0x06000546 RID: 1350 RVA: 0x000265B0 File Offset: 0x000247B0
		internal void Initialize(string WeaponConfigName)
		{
			this._weaponConfigName = WeaponConfigName;
			this._playerLayer = LayerMask.NameToLayer("FPSPlayer");
			this._rigidbody = base.gameObject.AddComponent<Rigidbody>();
			this._rigidbody.useGravity = false;
			this._rigidbody.isKinematic = true;
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			if (this._networkGameService.GetGameModeMetaData().GameMetaData.WeaponInfo != null)
			{
				foreach (WeaponInfo weaponInfo in this._networkGameService.GetGameModeMetaData().GameMetaData.WeaponInfo)
				{
					this.UpdateState(weaponInfo);
				}
			}
			this._networkGameService.OnWeaponStationEvent.AddListener(new Action<WeaponStationEvent>(this.HandleWeaponStationEvent));
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.HandleOnSpawn));
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x00005FA7 File Offset: 0x000041A7
		private void HandleOnSpawn(SpawnEvent evt)
		{
			if (UserProfile.IsMe(evt.User))
			{
				this._requestDispatched = false;
			}
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x00005FC0 File Offset: 0x000041C0
		private void HandleWeaponStationEvent(WeaponStationEvent evt)
		{
			if (this._weaponConfigName.Equals(evt.WeaponStationInfo.WeaponName))
			{
				this.UpdateState(evt.WeaponStationInfo);
			}
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x000266C4 File Offset: 0x000248C4
		public void OnDestroy()
		{
			if (this._networkGameService != null)
			{
				this._networkGameService.OnWeaponStationEvent.RemoveListener(new Action<WeaponStationEvent>(this.HandleWeaponStationEvent));
				this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.HandleOnSpawn));
			}
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x00026714 File Offset: 0x00024914
		private void UpdateState(WeaponInfo info)
		{
			if (info.WeaponName.Equals(this._weaponConfigName))
			{
				this.ActiveRoot.SetActive(info.Active);
				this.DisableRoot.SetActive(!info.Active);
				if (!info.StartPoint)
				{
					if (info.CurrentPosition.Count >= 3)
					{
						base.transform.position = new Vector3((float)info.CurrentPosition[0], (float)info.CurrentPosition[1], (float)info.CurrentPosition[2]);
					}
					else
					{
						Debug.LogError("[WeaponStation] Update State failure: CurrentPosition hasn't 3 positions");
					}
				}
				else
				{
					base.transform.localPosition = Vector3.zero;
				}
			}
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x000267D4 File Offset: 0x000249D4
		public void OnTriggerEnter(Collider collider)
		{
			if (collider.gameObject.layer != this._playerLayer)
			{
				return;
			}
			if (this._gameModeService.State != GameModeState.Ready)
			{
				return;
			}
			if (!UserProfile.LocalGameClient.spawned)
			{
				return;
			}
			if (this._requestDispatched)
			{
				return;
			}
			this._requestDispatched = true;
			WeaponStationRequest weaponStationRequest = new WeaponStationRequest
			{
				WeaponStationName = this._weaponConfigName
			};
			this._networkGameService.RaiseNetworkEvent(weaponStationRequest);
			this.UpdateState(new WeaponInfo
			{
				WeaponName = this._weaponConfigName,
				Active = false,
				CurrentPosition = new List<double> { 0.0, 0.0, 0.0 },
				StartPoint = true
			});
		}

		// Token: 0x040007CF RID: 1999
		public GameObject ActiveRoot;

		// Token: 0x040007D0 RID: 2000
		public GameObject DisableRoot;

		// Token: 0x040007D1 RID: 2001
		private int _playerLayer;

		// Token: 0x040007D2 RID: 2002
		private Rigidbody _rigidbody;

		// Token: 0x040007D3 RID: 2003
		private NetworkGameService _networkGameService;

		// Token: 0x040007D4 RID: 2004
		private GameModeService _gameModeService;

		// Token: 0x040007D5 RID: 2005
		private bool _requestDispatched;

		// Token: 0x040007D6 RID: 2006
		private string _weaponConfigName;
	}
}
