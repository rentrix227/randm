﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D5 RID: 725
	public class ItemUnlockPopupView : BaseItemUnlockPopupView<PopupController>
	{
		// Token: 0x17000131 RID: 305
		// (get) Token: 0x06000F3B RID: 3899 RVA: 0x0000C87D File Offset: 0x0000AA7D
		protected override string WeaponTitleLocalizationKey
		{
			get
			{
				return "new_class_weapon";
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000F3C RID: 3900 RVA: 0x0000C884 File Offset: 0x0000AA84
		protected override string SkillTitleLocalizationKey
		{
			get
			{
				return "new_class_skill";
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000F3D RID: 3901 RVA: 0x0000C88B File Offset: 0x0000AA8B
		protected override string LoadoutTitleLocalizationKey
		{
			get
			{
				return "new_class_loadout";
			}
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x0000C892 File Offset: 0x0000AA92
		internal void UpdateInfo(UnlockItemPopupData data)
		{
			this.UpdateInfo(data.Type, data.Class, data.ItemName, data.LoadoutNumber);
		}

		// Token: 0x06000F3F RID: 3903 RVA: 0x0000C8B2 File Offset: 0x0000AAB2
		public void HidePopup()
		{
			ServiceProvider.GetService<PopupService>().HiddenItemUnlock();
		}
	}
}
