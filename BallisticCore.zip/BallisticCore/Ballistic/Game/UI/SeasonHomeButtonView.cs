﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using Aquiris.UI.Base;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002FC RID: 764
	public class SeasonHomeButtonView : BaseView<SeasonController>
	{
		// Token: 0x06000FE0 RID: 4064 RVA: 0x0000D16D File Offset: 0x0000B36D
		[UsedImplicitly]
		private void OnEnable()
		{
			this.ButtonRoot.SetActive(false);
		}

		// Token: 0x06000FE1 RID: 4065 RVA: 0x0005D444 File Offset: 0x0005B644
		internal void ShowSeasonButton(SeasonInfo seasonInfo)
		{
			string seasonIconPath = TextureHelper.GetSeasonIconPath(seasonInfo.Season, EImageSize.MEDIUM);
			TextureHelper.LoadImageAsync(seasonIconPath, this.SeasonIcon, false, EImageSource.RESOURCES);
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.SeasonNameLabel.text = service.GetSeasonName(seasonInfo.Season, ELocalizedTextCase.NONE);
			this.ButtonRoot.SetActive(true);
		}

		// Token: 0x0400150E RID: 5390
		public GameObject ButtonRoot;

		// Token: 0x0400150F RID: 5391
		public Image SeasonIcon;

		// Token: 0x04001510 RID: 5392
		public Text SeasonNameLabel;
	}
}
