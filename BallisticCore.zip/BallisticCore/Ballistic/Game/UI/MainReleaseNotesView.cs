﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002EB RID: 747
	public class MainReleaseNotesView : BaseView<MainController>
	{
		// Token: 0x06000FB0 RID: 4016 RVA: 0x0000CF61 File Offset: 0x0000B161
		internal void QueryData()
		{
			this.Title.text = "Loading...";
			this.Description.text = "Loading...";
			base.StartCoroutine(this.GetNews());
		}

		// Token: 0x06000FB1 RID: 4017 RVA: 0x0005C89C File Offset: 0x0005AA9C
		private IEnumerator GetNews()
		{
			string uri = "https://api.steampowered.com/ISteamNews/GetNewsForApp/v2?appid=296300&maxlength=0&count=1";
			WWW www = new WWW(uri);
			yield return www;
			if (string.IsNullOrEmpty(www.error))
			{
				MainReleaseNotesView.NewsParser newsParser = JsonUtility.FromJson<MainReleaseNotesView.NewsParser>(www.text);
				if (newsParser.appnews.newsitems.Length > 0)
				{
					this.Title.text = newsParser.appnews.newsitems[0].title.ToUpperInvariant();
					this.Description.text = this.ParserHTMLContents(newsParser.appnews.newsitems[0].contents);
				}
			}
			else
			{
				Debug.Log("Error:" + www.error);
			}
			yield break;
		}

		// Token: 0x06000FB2 RID: 4018 RVA: 0x0005C8B8 File Offset: 0x0005AAB8
		private string ParserHTMLContents(string dt)
		{
			foreach (KeyValuePair<string, string> keyValuePair in new Dictionary<string, string>
			{
				{ "[b]", "<b>" },
				{ "[/b]", "</b>" },
				{ "[h1]", "<size=40>" },
				{ "[/h1]", "</size>" },
				{ "[h2]", "<size=30>" },
				{ "[/h2]", "</size>" },
				{ "[*]", "\t• " }
			})
			{
				dt = dt.Replace(keyValuePair.Key, keyValuePair.Value);
			}
			MatchCollection matchCollection;
			do
			{
				matchCollection = Regex.Matches(dt, "\\[list\\][^\\[\\]]*\\[\\/list\\]");
				IEnumerator enumerator2 = matchCollection.GetEnumerator();
				try
				{
					while (enumerator2.MoveNext())
					{
						object obj = enumerator2.Current;
						Match match = (Match)obj;
						string text = match.Value.Replace("[list]", string.Empty).Replace("[/list]", string.Empty).Replace("\n", "\n\t");
						dt = dt.Replace(match.Value, text);
					}
				}
				finally
				{
					IDisposable disposable;
					if ((disposable = enumerator2 as IDisposable) != null)
					{
						disposable.Dispose();
					}
				}
			}
			while (matchCollection.Count > 0);
			do
			{
				matchCollection = Regex.Matches(dt, "\\[url=[^\\]]*\\]|\\[\\/url\\]");
				IEnumerator enumerator3 = matchCollection.GetEnumerator();
				try
				{
					while (enumerator3.MoveNext())
					{
						object obj2 = enumerator3.Current;
						Match match2 = (Match)obj2;
						dt = dt.Replace(match2.Value, string.Empty);
					}
				}
				finally
				{
					IDisposable disposable2;
					if ((disposable2 = enumerator3 as IDisposable) != null)
					{
						disposable2.Dispose();
					}
				}
			}
			while (matchCollection.Count > 0);
			do
			{
				matchCollection = Regex.Matches(dt, "\\[img\\][\\w\\W]*\\[\\/img\\]");
				IEnumerator enumerator4 = matchCollection.GetEnumerator();
				try
				{
					while (enumerator4.MoveNext())
					{
						object obj3 = enumerator4.Current;
						Match match3 = (Match)obj3;
						dt = dt.Replace(match3.Value, string.Empty);
					}
				}
				finally
				{
					IDisposable disposable3;
					if ((disposable3 = enumerator4 as IDisposable) != null)
					{
						disposable3.Dispose();
					}
				}
			}
			while (matchCollection.Count > 0);
			return dt;
		}

		// Token: 0x040014D6 RID: 5334
		public Text Title;

		// Token: 0x040014D7 RID: 5335
		public Text Description;

		// Token: 0x020002EC RID: 748
		[Serializable]
		public struct NewsParser
		{
			// Token: 0x040014D8 RID: 5336
			public MainReleaseNotesView.NewsParser.AppNews appnews;

			// Token: 0x020002ED RID: 749
			[Serializable]
			public struct AppNews
			{
				// Token: 0x040014D9 RID: 5337
				public int appid;

				// Token: 0x040014DA RID: 5338
				public MainReleaseNotesView.NewsParser.AppNews.NewsItems[] newsitems;

				// Token: 0x040014DB RID: 5339
				public int count;

				// Token: 0x020002EE RID: 750
				[Serializable]
				public struct NewsItems
				{
					// Token: 0x040014DC RID: 5340
					public string gid;

					// Token: 0x040014DD RID: 5341
					public string title;

					// Token: 0x040014DE RID: 5342
					public string url;

					// Token: 0x040014DF RID: 5343
					public bool is_external_url;

					// Token: 0x040014E0 RID: 5344
					public string author;

					// Token: 0x040014E1 RID: 5345
					public string contents;

					// Token: 0x040014E2 RID: 5346
					public string feedlabel;

					// Token: 0x040014E3 RID: 5347
					public long date;

					// Token: 0x040014E4 RID: 5348
					public string feedname;

					// Token: 0x040014E5 RID: 5349
					public string feed_type;

					// Token: 0x040014E6 RID: 5350
					public string appid;
				}
			}
		}
	}
}
