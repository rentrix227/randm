﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002AB RID: 683
	[Serializable]
	internal class ProgressionEventStruct
	{
		// Token: 0x040012D0 RID: 4816
		internal ProgressionEventStruct.EventStructType Type;

		// Token: 0x040012D1 RID: 4817
		internal float StartTime;

		// Token: 0x040012D2 RID: 4818
		internal float Duration;

		// Token: 0x040012D3 RID: 4819
		internal bool Once;

		// Token: 0x040012D4 RID: 4820
		internal AwardedXpComponent XpAwardedComponent;

		// Token: 0x040012D5 RID: 4821
		internal EndMatchProgressionCardComponent ClassCardComponent;

		// Token: 0x040012D6 RID: 4822
		internal float ClassCardProgressFrom;

		// Token: 0x040012D7 RID: 4823
		internal float ClassCardProgressTo;

		// Token: 0x040012D8 RID: 4824
		internal int ClassCardLevel;

		// Token: 0x040012D9 RID: 4825
		internal EHeroClass PopupHeroClass;

		// Token: 0x040012DA RID: 4826
		internal EUnlockType PopupType;

		// Token: 0x040012DB RID: 4827
		internal string PopupItem;

		// Token: 0x040012DC RID: 4828
		internal int PopupIndex;

		// Token: 0x020002AC RID: 684
		internal enum EventStructType
		{
			// Token: 0x040012DE RID: 4830
			XP_IN,
			// Token: 0x040012DF RID: 4831
			XP,
			// Token: 0x040012E0 RID: 4832
			XP_EXIT,
			// Token: 0x040012E1 RID: 4833
			CARD_IN,
			// Token: 0x040012E2 RID: 4834
			CARD_XP_ROUTINE,
			// Token: 0x040012E3 RID: 4835
			CARD_LEVELUP,
			// Token: 0x040012E4 RID: 4836
			CARD_RE_LEVELUP,
			// Token: 0x040012E5 RID: 4837
			CARD_UNLOCKEDUP,
			// Token: 0x040012E6 RID: 4838
			CARD_RE_UNLOCKEDUP,
			// Token: 0x040012E7 RID: 4839
			CARD_SET,
			// Token: 0x040012E8 RID: 4840
			POP_SHOW_ITEM,
			// Token: 0x040012E9 RID: 4841
			POP_HIDDEN_ITEM,
			// Token: 0x040012EA RID: 4842
			CARD_ALL_FINISHED,
			// Token: 0x040012EB RID: 4843
			SHOW_LOCKBOX_POPUP
		}
	}
}
