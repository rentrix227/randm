﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C6 RID: 710
	public class InGameRespawnLoadoutsView : BaseView<InGameRespawnController>
	{
		// Token: 0x06000EDB RID: 3803 RVA: 0x00059B60 File Offset: 0x00057D60
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.LoadoutTemplate.gameObject.SetActive(false);
			this.QueuePlayerList.Template.Dispose();
			this.SpectatorSpectatorCameraBtn.onClick.AddListener(new UnityAction(this.DispatchSpectateMatch));
			this.SpectatorSwitchTeamBtn.onClick.AddListener(new UnityAction(this.DispatchSwitchTeamRequest));
			this.SpectatorRespawnAsPlayerBtn.onClick.AddListener(new UnityAction(this.DispatchRespawnAsPlayer));
			this.SpectatorSpectatePlayingBtn.onClick.AddListener(new UnityAction(this.DispatchSpectateOnly));
		}

		// Token: 0x06000EDC RID: 3804 RVA: 0x00059C10 File Offset: 0x00057E10
		internal void SetStartData(bool isSpectator, EClientMode clientMode, EHeroClass classe, QueueState queueState, bool onQueue, int myselfQueueIndex, int queueCount, bool suggestSwitchTeam)
		{
			this._isSpectator = isSpectator;
			this._clientMode = clientMode;
			this._onQueue = onQueue;
			this._queueState = queueState;
			this._queueCount = queueCount;
			this._myselfQueueIndex = myselfQueueIndex;
			this._suggestSwitchTeam = suggestSwitchTeam;
			this._lastClassSelected = classe;
			this.ChangeDataComplete();
		}

		// Token: 0x06000EDD RID: 3805 RVA: 0x0000C177 File Offset: 0x0000A377
		internal void SetData(bool isSpectator, EClientMode clientMode, EHeroClass classe, QueueState queueState, bool onQueue, int myselfQueueIndex, int queueCount, bool suggestSwitchTeam)
		{
			this._isSpectator = isSpectator;
			this._clientMode = clientMode;
			this._onQueue = onQueue;
			this._queueState = queueState;
			this._queueCount = queueCount;
			this._myselfQueueIndex = myselfQueueIndex;
			this._suggestSwitchTeam = suggestSwitchTeam;
			this._lastClassSelected = classe;
		}

		// Token: 0x06000EDE RID: 3806 RVA: 0x00059C60 File Offset: 0x00057E60
		internal void SetLoadoutData(EHeroClass heroClass, string loadoutName, HeroSkin heroSkin, Accessory accessory, Dictionary<EHeroItemSlot, PlayerWeaponData> loadoutData, PlayerLoadoutData loadout, HeroSkillData skill1, HeroSkillData skill2, bool isSpawned)
		{
			if (!this._loadoutInstances.ContainsKey(heroClass))
			{
				this._loadoutInstances.Add(heroClass, new Dictionary<int, SoldiersLoadoutComponent>());
			}
			if (!this._loadoutInstances[heroClass].ContainsKey(loadout.PlayerItem.Number))
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.LoadoutTemplate.gameObject);
				if (gameObject != null)
				{
					this._loadoutInstances[heroClass].Add(loadout.PlayerItem.Number, gameObject.GetComponent<SoldiersLoadoutComponent>());
					gameObject.transform.SetParent(this.LoadoutParentList, false);
					gameObject.SetActive(true);
				}
			}
			this._loadoutInstances[heroClass][loadout.PlayerItem.Number].UpdateLoadoutInfo(loadoutName, heroSkin, accessory, loadoutData, loadout.PlayerItem, skill1, skill2);
			this._loadoutInstances[heroClass][loadout.PlayerItem.Number].GetComponent<SoldiersLoadoutSelectorComponent>().SetSelector(loadout, isSpawned);
		}

		// Token: 0x06000EDF RID: 3807 RVA: 0x00059D68 File Offset: 0x00057F68
		internal void SetQueuePlayerData(HighSpeedArray<ClientCommonMetaData> queuePlayerList)
		{
			this.QueuePlayerList.SetActiveCount(queuePlayerList.Length);
			for (int i = 0; i < queuePlayerList.Length; i++)
			{
				RespawnQueuePlayerComponent respawnQueuePlayerComponent = this.QueuePlayerList[i];
				bool flag = UserProfile.IsMe(queuePlayerList[i].User);
				bool flag2 = !flag && SteamFriends.HasFriend(new CSteamID((ulong)queuePlayerList[i].User), 4);
				respawnQueuePlayerComponent.SetData(i + 1, queuePlayerList[i], flag, flag2);
			}
		}

		// Token: 0x06000EE0 RID: 3808 RVA: 0x00059DF4 File Offset: 0x00057FF4
		private void ClearLoadouts(EHeroClass heroClass = EHeroClass.NONE)
		{
			foreach (KeyValuePair<EHeroClass, Dictionary<int, SoldiersLoadoutComponent>> keyValuePair in this._loadoutInstances)
			{
				foreach (SoldiersLoadoutComponent soldiersLoadoutComponent in keyValuePair.Value.Values)
				{
					soldiersLoadoutComponent.gameObject.SetActive(heroClass == keyValuePair.Key);
				}
			}
		}

		// Token: 0x06000EE1 RID: 3809 RVA: 0x00059EA8 File Offset: 0x000580A8
		public void ChangeDataComplete()
		{
			if (!this._isSpectator)
			{
				this.ClearLoadouts(this._lastClassSelected);
			}
			this.PlayerContentRoot.SetActive(!this._isSpectator);
			this.SpectatorContentRoot.SetActive(this._isSpectator);
			this.OnQueueRoot.SetActive(this._clientMode == EClientMode.SPECTATOR && this._onQueue);
			this.SpectateRoot.SetActive(this._clientMode == EClientMode.SPECTATOR && !this._onQueue);
			this.SpectateWhilePlayingRoot.SetActive(this._clientMode == EClientMode.PLAYER);
			this.StayAsSpectatorToggle.isOn = !this._onQueue;
			this.QueueMatchIsFullRoot.SetActive(this._queueState == QueueState.FULL);
			this.QueueRebalancingRoot.SetActive(this._queueState == QueueState.REBALANCE);
			this.QueuePlayerCount.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("queue_count", ELocalizedTextCase.UPPER_CASE), this._queueCount);
			if (this._queueState == QueueState.FULL)
			{
				this.QueueMatchIsFullPosition.text = this._myselfQueueIndex.ToString();
				this.QueueMatchIsFullSuffix.text = ServiceProvider.GetService<LocalizationService>().Get("ordinal_suffix_" + ((this._myselfQueueIndex <= 16) ? this._myselfQueueIndex.ToString() : "infinity"), ELocalizedTextCase.LOWER_CASE);
			}
			else if (this._queueState == QueueState.REBALANCE)
			{
				this.QueueRebalancePosition.text = "+" + this._myselfQueueIndex.ToString();
			}
			this.SpectatorSwitchTeamBtn.gameObject.SetActive(this._suggestSwitchTeam);
		}

		// Token: 0x06000EE2 RID: 3810 RVA: 0x0000C1B6 File Offset: 0x0000A3B6
		private void DispatchSpectateMatch()
		{
			base._controller.DispatchSpectateMatch(!this.StayAsSpectatorToggle.isOn);
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x0000C1D1 File Offset: 0x0000A3D1
		private void DispatchSwitchTeamRequest()
		{
			base._controller.DispatchSwitchTeamRequest();
		}

		// Token: 0x06000EE4 RID: 3812 RVA: 0x0000C1DE File Offset: 0x0000A3DE
		private void DispatchSpectateOnly()
		{
			base._controller.DispatchSpectateOnly();
		}

		// Token: 0x06000EE5 RID: 3813 RVA: 0x0000C1EB File Offset: 0x0000A3EB
		private void DispatchRespawnAsPlayer()
		{
			base._controller.DispatchRespawnAsPlayer();
		}

		// Token: 0x040013E6 RID: 5094
		public GameObject PlayerContentRoot;

		// Token: 0x040013E7 RID: 5095
		public GameObject SpectatorContentRoot;

		// Token: 0x040013E8 RID: 5096
		[Header("Player")]
		public SoldiersLoadoutComponent LoadoutTemplate;

		// Token: 0x040013E9 RID: 5097
		public Transform LoadoutParentList;

		// Token: 0x040013EA RID: 5098
		[Header("Spectator Playing")]
		public Button SpectatorSpectatePlayingBtn;

		// Token: 0x040013EB RID: 5099
		public GameObject SpectateWhilePlayingRoot;

		// Token: 0x040013EC RID: 5100
		[Header("Spectator Only")]
		public GameObject SpectateRoot;

		// Token: 0x040013ED RID: 5101
		public Button SpectatorRespawnAsPlayerBtn;

		// Token: 0x040013EE RID: 5102
		[Header("Spectator OnQueue")]
		public GameObject OnQueueRoot;

		// Token: 0x040013EF RID: 5103
		public Button SpectatorSpectatorCameraBtn;

		// Token: 0x040013F0 RID: 5104
		public Button SpectatorSwitchTeamBtn;

		// Token: 0x040013F1 RID: 5105
		public Toggle StayAsSpectatorToggle;

		// Token: 0x040013F2 RID: 5106
		public GameObject QueueMatchIsFullRoot;

		// Token: 0x040013F3 RID: 5107
		public Text QueuePlayerCount;

		// Token: 0x040013F4 RID: 5108
		public Text QueueMatchIsFullPosition;

		// Token: 0x040013F5 RID: 5109
		public Text QueueMatchIsFullSuffix;

		// Token: 0x040013F6 RID: 5110
		public GameObject QueueRebalancingRoot;

		// Token: 0x040013F7 RID: 5111
		public Text QueueRebalancePosition;

		// Token: 0x040013F8 RID: 5112
		public InGameRespawnLoadoutsView.RespawnQueuePlayerComponentList QueuePlayerList;

		// Token: 0x040013F9 RID: 5113
		private readonly Dictionary<EHeroClass, Dictionary<int, SoldiersLoadoutComponent>> _loadoutInstances = new Dictionary<EHeroClass, Dictionary<int, SoldiersLoadoutComponent>>();

		// Token: 0x040013FA RID: 5114
		private bool _isSpectator;

		// Token: 0x040013FB RID: 5115
		private EClientMode _clientMode;

		// Token: 0x040013FC RID: 5116
		private QueueState _queueState;

		// Token: 0x040013FD RID: 5117
		private int _queueCount;

		// Token: 0x040013FE RID: 5118
		private bool _onQueue;

		// Token: 0x040013FF RID: 5119
		private int _myselfQueueIndex;

		// Token: 0x04001400 RID: 5120
		private bool _suggestSwitchTeam;

		// Token: 0x04001401 RID: 5121
		private EHeroClass _lastClassSelected;

		// Token: 0x020002C7 RID: 711
		[Serializable]
		public class RespawnQueuePlayerComponentList : PoolableList<RespawnQueuePlayerComponent>
		{
		}
	}
}
