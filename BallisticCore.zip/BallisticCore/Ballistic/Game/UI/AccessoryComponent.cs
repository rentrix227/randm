﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.Services;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001B8 RID: 440
	public class AccessoryComponent : PoolableComponent, IPointerEnterHandler, IEventSystemHandler
	{
		// Token: 0x0600091F RID: 2335 RVA: 0x00037F04 File Offset: 0x00036104
		internal virtual void SetData(Accessory accessory)
		{
			this._data = accessory;
			if (this.AccessoryImage != null)
			{
				string accessoryIconPath = TextureHelper.GetAccessoryIconPath(accessory.ItemName, this.ImageSize);
				TextureHelper.LoadImageAsync(accessoryIconPath, this.AccessoryImage, false, EImageSource.RESOURCES);
			}
			if (this.AccessoryName != null)
			{
				this.AccessoryName.text = ServiceProvider.GetService<LocalizationService>().GetAccessoryName(accessory.ItemName);
			}
		}

		// Token: 0x06000920 RID: 2336 RVA: 0x00008483 File Offset: 0x00006683
		public void OnPointerEnter(PointerEventData eventData)
		{
			if (this.OnAccessoryPreview != null)
			{
				this.OnAccessoryPreview(this._data);
			}
		}

		// Token: 0x04000BF1 RID: 3057
		public Image AccessoryImage;

		// Token: 0x04000BF2 RID: 3058
		public EImageSize ImageSize;

		// Token: 0x04000BF3 RID: 3059
		public Text AccessoryName;

		// Token: 0x04000BF4 RID: 3060
		public Action<Accessory> OnAccessoryPreview;

		// Token: 0x04000BF5 RID: 3061
		private Accessory _data;
	}
}
