﻿using System;
using System.Collections.Generic;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000285 RID: 645
	public class GameplayKillNotificationView : BaseView<GameplayKillListController>
	{
		// Token: 0x06000DB3 RID: 3507 RVA: 0x0000B64F File Offset: 0x0000984F
		protected override void Awake()
		{
			base.Awake();
			this.NotificationTemplate.gameObject.SetActive(false);
		}

		// Token: 0x06000DB4 RID: 3508 RVA: 0x000508A0 File Offset: 0x0004EAA0
		internal void NotifyKill(string victim)
		{
			if (this._instantiatedItems.Count >= this.MaximumItems)
			{
				Object.Destroy(this._instantiatedItems[0].gameObject);
				this._instantiatedItems.RemoveAt(0);
			}
			GameplayKillNotificationItemComponent gameplayKillNotificationItemComponent = Object.Instantiate<GameplayKillNotificationItemComponent>(this.NotificationTemplate, this.NotificationTemplate.transform.parent);
			gameplayKillNotificationItemComponent.SetInfo(victim);
			gameplayKillNotificationItemComponent.gameObject.SetActive(true);
			this._instantiatedItems.Add(gameplayKillNotificationItemComponent);
		}

		// Token: 0x06000DB5 RID: 3509 RVA: 0x00050920 File Offset: 0x0004EB20
		internal void ClearList()
		{
			if (this._instantiatedItems.Count > 0)
			{
				for (int i = 0; i < this._instantiatedItems.Count; i++)
				{
					Object.Destroy(this._instantiatedItems[i].gameObject);
				}
				this._instantiatedItems.Clear();
			}
		}

		// Token: 0x06000DB6 RID: 3510 RVA: 0x0000B668 File Offset: 0x00009868
		public void Update()
		{
			if (this.SendTestNotificationNow)
			{
				this.SendTestNotificationNow = false;
				this.NotifyKill(this.TestVictimName);
			}
		}

		// Token: 0x040010C4 RID: 4292
		public int MaximumItems = 15;

		// Token: 0x040010C5 RID: 4293
		public GameplayKillNotificationItemComponent NotificationTemplate;

		// Token: 0x040010C6 RID: 4294
		[Header("Testing")]
		public string TestVictimName = "Sucka";

		// Token: 0x040010C7 RID: 4295
		public bool SendTestNotificationNow;

		// Token: 0x040010C8 RID: 4296
		private readonly List<GameplayKillNotificationItemComponent> _instantiatedItems = new List<GameplayKillNotificationItemComponent>();
	}
}
