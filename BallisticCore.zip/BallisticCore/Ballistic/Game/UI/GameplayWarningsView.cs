﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002A1 RID: 673
	public class GameplayWarningsView : BaseView<GameplayWarningsController>
	{
		// Token: 0x06000E4C RID: 3660 RVA: 0x000551E0 File Offset: 0x000533E0
		internal void SetWarning(WarningType warning, WarningColor color = WarningColor.White)
		{
			if (this.WarningAnimator.isInitialized)
			{
				this.WarningAnimator.SetBool(this._whiteHash, warning != WarningType.None && color == WarningColor.White);
				this.WarningAnimator.SetBool(this._yellowHash, warning != WarningType.None && color == WarningColor.Yellow);
				this.WarningAnimator.SetBool(this._redHash, warning != WarningType.None && color == WarningColor.Red);
			}
			if (warning != WarningType.None)
			{
				this.WarningLabel.text = ServiceProvider.GetService<LocalizationService>().Get("hud_warning_" + warning.ToString().ToLowerInvariant(), ELocalizedTextCase.UPPER_CASE);
			}
		}

		// Token: 0x06000E4D RID: 3661 RVA: 0x0000BAA3 File Offset: 0x00009CA3
		internal void ClearWarning()
		{
			this.SetWarning(WarningType.None, WarningColor.White);
		}

		// Token: 0x06000E4E RID: 3662 RVA: 0x0000BAAD File Offset: 0x00009CAD
		public void Update()
		{
			if (this.SendTestWarningNow)
			{
				this.SendTestWarningNow = false;
				this.SetWarning(this.TestWarningType, this.TestWarningColor);
			}
		}

		// Token: 0x0400126D RID: 4717
		public Text WarningLabel;

		// Token: 0x0400126E RID: 4718
		public Animator WarningAnimator;

		// Token: 0x0400126F RID: 4719
		[Header("Testing")]
		public WarningType TestWarningType;

		// Token: 0x04001270 RID: 4720
		public WarningColor TestWarningColor;

		// Token: 0x04001271 RID: 4721
		public bool SendTestWarningNow;

		// Token: 0x04001272 RID: 4722
		private readonly int _whiteHash = Animator.StringToHash("white");

		// Token: 0x04001273 RID: 4723
		private readonly int _yellowHash = Animator.StringToHash("yellow");

		// Token: 0x04001274 RID: 4724
		private readonly int _redHash = Animator.StringToHash("red");
	}
}
