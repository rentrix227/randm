﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D8 RID: 728
	public class LeaderboardsFooterView : BaseView<LeaderboardsController>
	{
		// Token: 0x06000F53 RID: 3923 RVA: 0x0005BB70 File Offset: 0x00059D70
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.PageDown.onClick.AddListener(new UnityAction(this.OnPageDown));
			this.PageUp.onClick.AddListener(new UnityAction(this.OnPageUp));
			this.PageDotList.Template.Dispose();
		}

		// Token: 0x06000F54 RID: 3924 RVA: 0x0005BBD4 File Offset: 0x00059DD4
		private void ReqCompString(ref Text text, ref Image fill, int value, int required)
		{
			text.text = string.Concat(new object[] { value, "<color=#5c6166><size=32>/", required, "</size></color>" });
			if (value >= required)
			{
				text.color = new Color32(132, 214, 172, byte.MaxValue);
				fill.color = new Color32(132, 214, 172, byte.MaxValue);
			}
			else
			{
				text.color = new Color32(226, 36, 55, byte.MaxValue);
				fill.color = new Color32(226, 36, 55, byte.MaxValue);
			}
			fill.fillAmount = (float)value / (float)required;
		}

		// Token: 0x06000F55 RID: 3925 RVA: 0x0000CA5C File Offset: 0x0000AC5C
		internal void SetLoading()
		{
			this._currentLoading = true;
		}

		// Token: 0x06000F56 RID: 3926 RVA: 0x0000CA65 File Offset: 0x0000AC65
		public void Update()
		{
			if (this.Loading.isInitialized)
			{
				this.Loading.SetBool(LeaderboardsFooterView.Animator_RetrieveLeaderboards, this._currentLoading);
			}
		}

		// Token: 0x06000F58 RID: 3928 RVA: 0x0000CA9B File Offset: 0x0000AC9B
		private void OnPageDown()
		{
			base._controller.DispatchPageDown();
		}

		// Token: 0x06000F59 RID: 3929 RVA: 0x0000CAA8 File Offset: 0x0000ACA8
		private void OnPageUp()
		{
			base._controller.DispatchPageUp();
		}

		// Token: 0x06000F5A RID: 3930 RVA: 0x0000CAB5 File Offset: 0x0000ACB5
		private void OnPageSet(int page)
		{
			base._controller.DispatchPageSet(page);
		}

		// Token: 0x06000F5B RID: 3931 RVA: 0x0000CAC3 File Offset: 0x0000ACC3
		internal void SetData(Leaderboards leaderboard, LeaderboardEntry[] entries)
		{
			this._pages = Mathf.CeilToInt((float)entries.Length / 10f);
			this.PageDotList.SetActiveCount(this._pages);
			this.SetPage(0);
		}

		// Token: 0x06000F5C RID: 3932 RVA: 0x0005BCB4 File Offset: 0x00059EB4
		internal void SetPage(int page)
		{
			if (page < 0 || page >= this._pages)
			{
				return;
			}
			for (int i = 0; i < this._pages; i++)
			{
				this.PageDotList[i].SetData(i == page, i);
				this.PageDotList[i].OnToggleClicked = new Action<int>(this.OnPageSet);
			}
			this.PageDown.gameObject.SetActive(this._pages > 1 && page > 0);
			this.PageUp.gameObject.SetActive(this._pages > 1 && page < this._pages - 1);
		}

		// Token: 0x06000F5D RID: 3933 RVA: 0x0005BD5C File Offset: 0x00059F5C
		internal void SetPlayerData(string name, Texture2D avatar, StatisticsGeneralData statistics, LeaderboardEntry entry)
		{
			this._currentLoading = false;
			int leaderboardMatchs = statistics.GetLeaderboardMatchs(EGameMode.TeamDeathMatch);
			int leaderboardMatchs2 = statistics.GetLeaderboardMatchs(EGameMode.FreeForAll);
			int leaderboardMatchs3 = statistics.GetLeaderboardMatchs(EGameMode.Conquest);
			int leaderboardMatchs4 = statistics.GetLeaderboardMatchs(EGameMode.KingOfTheHill);
			int leaderboardMatchs5 = statistics.GetLeaderboardMatchs(EGameMode.Rounds);
			bool flag = leaderboardMatchs >= 5;
			bool flag2 = leaderboardMatchs2 >= 5;
			bool flag3 = leaderboardMatchs3 >= 5;
			bool flag4 = leaderboardMatchs4 >= 5;
			bool flag5 = leaderboardMatchs5 >= 5;
			bool flag6 = flag && flag2 && flag3 && flag4 && flag5;
			bool flag7 = leaderboardMatchs + leaderboardMatchs2 + leaderboardMatchs3 + leaderboardMatchs4 >= 25;
			bool flag8 = flag6 && flag7;
			this.RankedRoot.SetActive(flag8);
			this.UnrankedRoot.SetActive(!flag8);
			this.SkinsTemplate.SetActive(false);
			if (flag8)
			{
				this.RankedPlayerComponent.SetInfo(Leaderboards.PERFORMANCE_LADDER, entry);
				return;
			}
			this.UnrankedPlayerAvatar.texture = avatar;
			this.UnrankedMatchesCompleted.SetActive(flag7);
			this.UnrankedModesUnfinished.SetActive(!flag7);
			this.ReqCompString(ref this.UnrankedMatchesText, ref this.UnrankedMatchesFillbar, leaderboardMatchs + leaderboardMatchs2 + leaderboardMatchs3 + leaderboardMatchs4 + leaderboardMatchs5, 25);
			this.UnrankedModesCompleted.SetActive(flag6);
			this.UnrankedModesUnfinished.SetActive(!flag6);
			this.ReqCompString(ref this.UnrankedTDMText, ref this.UnrankedTDMFillbar, leaderboardMatchs, 5);
			this.ReqCompString(ref this.UnrankedFFAText, ref this.UnrankedFFAFillbar, leaderboardMatchs2, 5);
			this.ReqCompString(ref this.UnrankedCTPText, ref this.UnrankedCTPFillbar, leaderboardMatchs3, 5);
			this.ReqCompString(ref this.UnrankedKOTHText, ref this.UnrankedKOTHFillbar, leaderboardMatchs4, 5);
			this.ReqCompString(ref this.UnrankedRNDText, ref this.UnrankedRNDFillbar, leaderboardMatchs5, 5);
		}

		// Token: 0x0400146F RID: 5231
		private static int Animator_RetrieveLeaderboards = Animator.StringToHash("retrieving_leaderboards");

		// Token: 0x04001470 RID: 5232
		public Animator Loading;

		// Token: 0x04001471 RID: 5233
		[Header("Pages")]
		public Button PageDown;

		// Token: 0x04001472 RID: 5234
		public Button PageUp;

		// Token: 0x04001473 RID: 5235
		public LeaderboardsFooterView.LeaderboardPageDotList PageDotList;

		// Token: 0x04001474 RID: 5236
		[Header("Player Ranked")]
		public GameObject RankedRoot;

		// Token: 0x04001475 RID: 5237
		public LeaderboardPlayerComponent RankedPlayerComponent;

		// Token: 0x04001476 RID: 5238
		[Header("Player Unranked")]
		public GameObject UnrankedRoot;

		// Token: 0x04001477 RID: 5239
		public RawImage UnrankedPlayerAvatar;

		// Token: 0x04001478 RID: 5240
		public GameObject UnrankedMatchesCompleted;

		// Token: 0x04001479 RID: 5241
		public GameObject UnrankedMatchesUnfinished;

		// Token: 0x0400147A RID: 5242
		public Text UnrankedMatchesText;

		// Token: 0x0400147B RID: 5243
		public Image UnrankedMatchesFillbar;

		// Token: 0x0400147C RID: 5244
		public GameObject UnrankedModesCompleted;

		// Token: 0x0400147D RID: 5245
		public GameObject UnrankedModesUnfinished;

		// Token: 0x0400147E RID: 5246
		public Text UnrankedTDMText;

		// Token: 0x0400147F RID: 5247
		public Image UnrankedTDMFillbar;

		// Token: 0x04001480 RID: 5248
		public Text UnrankedFFAText;

		// Token: 0x04001481 RID: 5249
		public Image UnrankedFFAFillbar;

		// Token: 0x04001482 RID: 5250
		public Text UnrankedCTPText;

		// Token: 0x04001483 RID: 5251
		public Image UnrankedCTPFillbar;

		// Token: 0x04001484 RID: 5252
		public Text UnrankedKOTHText;

		// Token: 0x04001485 RID: 5253
		public Image UnrankedKOTHFillbar;

		// Token: 0x04001486 RID: 5254
		public Text UnrankedRNDText;

		// Token: 0x04001487 RID: 5255
		public Image UnrankedRNDFillbar;

		// Token: 0x04001488 RID: 5256
		[Header("Player Skin Mode")]
		public GameObject SkinsTemplate;

		// Token: 0x04001489 RID: 5257
		private bool _currentLoading;

		// Token: 0x0400148A RID: 5258
		private int _pages;

		// Token: 0x020002D9 RID: 729
		[Serializable]
		public class LeaderboardPageDotList : PoolableList<LeaderboardPageDotComponent>
		{
		}
	}
}
