﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Character.PlayerList;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Connection.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Requests;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Lockbox;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000222 RID: 546
	public class InGameEndmatchController : BaseController
	{
		// Token: 0x06000B37 RID: 2871 RVA: 0x0004305C File Offset: 0x0004125C
		public InGameEndmatchController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnTimeRemaining.AddListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnUserListChanged.AddListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnServerTermination.AddListener(new Action<ServerTerminationEvent>(this.OnServerTermination));
			this._networkGameService.OnSelectTeam.AddListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.AddListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnChangeState.AddListener(new Action<ChangeGameStateEvent>(this.OnChangeState));
			this._networkGameService.OnRoundUp.AddListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			this._networkGameService.OnTeamScoreEvent.AddListener(new Action<TeamScoreEvent>(this.OnTeamScoreEvent));
			this._networkGameService.OnClientConnectionClosed.AddListener(new Action(this.OnClientConnectionClosed));
			this._networkGameService.OnClientListReceived.AddListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnVoteUpdate.AddListener(new Action<VoteMapEvent>(this.OnVoteUpdate));
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._yourTeamPlayerData = new HighSpeedArray<ClientCommonMetaData>(40);
			this._enemyTeamPlayerData = new HighSpeedArray<ClientCommonMetaData>(40);
			this._playerDataSorter = new ClientCommonMetaDataSortByScore();
			GameConfig gameConfig = this._networkGameService.GetGameModeMetaData().GameConfig;
		}

		// Token: 0x06000B38 RID: 2872 RVA: 0x00043248 File Offset: 0x00041448
		private void OnClientConnectionClosed()
		{
			if (this._endMatchRoutine != null)
			{
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._endMatchRoutine);
				this._endMatchRoutine = null;
			}
			if (this._roundUpRoutine != null)
			{
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._roundUpRoutine);
				this._roundUpRoutine = null;
			}
		}

		// Token: 0x06000B39 RID: 2873 RVA: 0x0004329C File Offset: 0x0004149C
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnTimeRemaining.RemoveListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnUserListChanged.RemoveListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnServerTermination.RemoveListener(new Action<ServerTerminationEvent>(this.OnServerTermination));
			this._networkGameService.OnSelectTeam.RemoveListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.RemoveListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnChangeState.RemoveListener(new Action<ChangeGameStateEvent>(this.OnChangeState));
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			this._networkGameService.OnTeamScoreEvent.RemoveListener(new Action<TeamScoreEvent>(this.OnTeamScoreEvent));
			this._networkGameService.OnClientConnectionClosed.RemoveListener(new Action(this.OnClientConnectionClosed));
			this._networkGameService.OnClientListReceived.RemoveListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnVoteUpdate.RemoveListener(new Action<VoteMapEvent>(this.OnVoteUpdate));
		}

		// Token: 0x06000B3A RID: 2874 RVA: 0x00009D7E File Offset: 0x00007F7E
		private void OnClientListReceived(ClientListReceivedEvent evt)
		{
			this.RebuildData();
		}

		// Token: 0x06000B3B RID: 2875 RVA: 0x0004340C File Offset: 0x0004160C
		private void RebuildData()
		{
			if (this._networkGameService.GetGameModeMetaData() == null)
			{
				return;
			}
			MatchStandingsData matchStandings = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings();
			this._playerWinner = matchStandings.WinningTeam;
			this._playerRankingPosition = matchStandings.PlayerRanking;
			this._yourTeamScore = matchStandings.YourTeamScore;
			this._enemyTeamScore = matchStandings.EnemyTeamScore;
			this._yourTeamWins = matchStandings.YourTeamWins;
			this._enemyTeamWins = matchStandings.EnemyTeamWins;
			this._enemyTeamPlayerData.Clear();
			this._yourTeamPlayerData.Clear();
			EGameMode gameMode = this._gameModeService.GameMode;
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				Team team = UserProfile.LocalGameClient.team;
				foreach (ClientCommonMetaData clientCommonMetaData in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Values)
				{
					if (clientCommonMetaData != null)
					{
						if (clientCommonMetaData.ClientMode == EClientMode.PLAYER)
						{
							if ((Team)clientCommonMetaData.Team == team)
							{
								this._yourTeamPlayerData.Add(clientCommonMetaData);
							}
							else
							{
								this._enemyTeamPlayerData.Add(clientCommonMetaData);
							}
						}
					}
				}
				this._yourTeamPlayerData.Sort(this._playerDataSorter);
				this._enemyTeamPlayerData.Sort(this._playerDataSorter);
			}
			else
			{
				this._yourTeamPlayerData.Clear();
				this._yourTeamPlayerData.AddRange(matchStandings.YourPlayerData);
			}
		}

		// Token: 0x06000B3C RID: 2876 RVA: 0x000435A4 File Offset: 0x000417A4
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameEndmatchVictoryView inGameEndmatchVictoryView = view as InGameEndmatchVictoryView;
			if (inGameEndmatchVictoryView != null)
			{
				inGameEndmatchVictoryView.SetData(this._gameModeService.GameMode, this._playerRankingPosition);
			}
			InGameEndmatchDefeatView inGameEndmatchDefeatView = view as InGameEndmatchDefeatView;
			if (inGameEndmatchDefeatView != null)
			{
				inGameEndmatchDefeatView.SetData(this._gameModeService.GameMode, this._playerRankingPosition);
			}
			InGameEndmatchTiedView inGameEndmatchTiedView = view as InGameEndmatchTiedView;
			if (inGameEndmatchTiedView != null)
			{
				inGameEndmatchTiedView.SetData(UserProfile.LocalGameClient.clientMode);
			}
			InGameEndmatchScoreView inGameEndmatchScoreView = view as InGameEndmatchScoreView;
			if (inGameEndmatchScoreView != null)
			{
				inGameEndmatchScoreView.SetData(UserProfile.LocalGameClient.clientMode, this._gameModeService.GameMode, this._playerWinner == EWinningTeam.MINE, this._yourTeamScore, this._enemyTeamScore, this._yourTeamWins, this._enemyTeamWins, UserProfile.LocalGameClient.team);
			}
			InGameEndRoundsEndView inGameEndRoundsEndView = view as InGameEndRoundsEndView;
			if (inGameEndRoundsEndView != null)
			{
				inGameEndRoundsEndView.RoundsDispatchEnded(this._winnerTeam, this._yourTeamScore, this._enemyTeamScore);
			}
			InGameRoundScoreView inGameRoundScoreView = view as InGameRoundScoreView;
			if (inGameRoundScoreView != null)
			{
				inGameRoundScoreView.SetData(this._yourTeamWins, this._enemyTeamWins, UserProfile.LocalGameClient.team);
			}
			InGameEndmatchScoreboardView inGameEndmatchScoreboardView = view as InGameEndmatchScoreboardView;
			if (inGameEndmatchScoreboardView != null)
			{
				this.UpdateScoreboard(inGameEndmatchScoreboardView);
			}
			InGameEndmatchVoteView inGameEndmatchVoteView = view as InGameEndmatchVoteView;
			if (inGameEndmatchVoteView != null)
			{
				this.UpdateVoteView(inGameEndmatchVoteView);
			}
		}

		// Token: 0x06000B3D RID: 2877 RVA: 0x00043730 File Offset: 0x00041930
		private void UpdateScoreboard(InGameEndmatchScoreboardView scoreboard)
		{
			if (this._gameModeService.GameMode == EGameMode.Rounds)
			{
				scoreboard.SetScores(this._yourTeamWins, this._enemyTeamWins);
			}
			else
			{
				scoreboard.SetScores(this._yourTeamScore, this._enemyTeamScore);
			}
			scoreboard.SetMode(UserProfile.LocalGameClient.clientMode, this._gameModeService.GameMode, UserProfile.LocalGameClient.team);
			scoreboard.UpdateYourTeamList(this._gameModeService.GameMode, this._yourTeamPlayerData, EClientMode.PLAYER, -1L);
			scoreboard.UpdateEnemyTeamList(this._gameModeService.GameMode, this._enemyTeamPlayerData, EClientMode.PLAYER, -1L);
		}

		// Token: 0x06000B3E RID: 2878 RVA: 0x000437D0 File Offset: 0x000419D0
		private void OnUserListChanged(UserListChangedEvent evt)
		{
			this.RebuildData();
			InGameEndmatchScoreboardView view = base.GetView<InGameEndmatchScoreboardView>();
			if (view != null)
			{
				this.UpdateScoreboard(view);
			}
		}

		// Token: 0x06000B3F RID: 2879 RVA: 0x000437D0 File Offset: 0x000419D0
		private void OnSelectTeamCompleted(SelectTeamCompletedResponse evt)
		{
			this.RebuildData();
			InGameEndmatchScoreboardView view = base.GetView<InGameEndmatchScoreboardView>();
			if (view != null)
			{
				this.UpdateScoreboard(view);
			}
		}

		// Token: 0x06000B40 RID: 2880 RVA: 0x000437D0 File Offset: 0x000419D0
		private void OnSelectTeam(SelectTeamResponse evt)
		{
			this.RebuildData();
			InGameEndmatchScoreboardView view = base.GetView<InGameEndmatchScoreboardView>();
			if (view != null)
			{
				this.UpdateScoreboard(view);
			}
		}

		// Token: 0x06000B41 RID: 2881 RVA: 0x00043800 File Offset: 0x00041A00
		private void OnTeamScoreEvent(TeamScoreEvent evt)
		{
			this.RebuildData();
			InGameEndmatchScoreboardView view = base.GetView<InGameEndmatchScoreboardView>();
			if (view != null)
			{
				this.UpdateScoreboard(view);
			}
			InGameEndmatchScoreView view2 = base.GetView<InGameEndmatchScoreView>();
			if (view2 != null)
			{
				view2.SetData(UserProfile.LocalGameClient.clientMode, this._gameModeService.GameMode, this._playerWinner == EWinningTeam.MINE, this._yourTeamScore, this._enemyTeamScore, this._yourTeamWins, this._enemyTeamWins, UserProfile.LocalGameClient.team);
			}
			InGameEndRoundsEndView view3 = base.GetView<InGameEndRoundsEndView>();
			if (view3 != null)
			{
				view3.RoundsDispatchEnded(this._winnerTeam, this._yourTeamScore, this._enemyTeamScore);
			}
		}

		// Token: 0x06000B42 RID: 2882 RVA: 0x000438B4 File Offset: 0x00041AB4
		private void OnServerTermination(ServerTerminationEvent serverTerminationEvent)
		{
			InGameEndmatchVoteView view = base.GetView<InGameEndmatchVoteView>();
			if (view != null)
			{
				view.Hide();
			}
		}

		// Token: 0x06000B43 RID: 2883 RVA: 0x000438DC File Offset: 0x00041ADC
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			this._canVote = true;
			InGameEndmatchVoteView view = base.GetView<InGameEndmatchVoteView>();
			if (view != null)
			{
				this.UpdateVoteView(view);
			}
			this.RebuildData();
			this._endMatchRoutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.EndGameRoutine());
			this.CheckLockboxUnlock();
		}

		// Token: 0x06000B44 RID: 2884 RVA: 0x0004392C File Offset: 0x00041B2C
		private void CheckLockboxUnlock()
		{
			if (UserProfile.LocalGameClient.score < 10)
			{
				return;
			}
			if (this._networkGameService.GetGameModeMetaData().GameConfig.MatchTime < 240)
			{
				return;
			}
			ServiceProvider.GetService<InventoryService>().TriggerDropItem(new Action<SteamItem>(this.HandleDropItemResponse));
		}

		// Token: 0x06000B45 RID: 2885 RVA: 0x00043984 File Offset: 0x00041B84
		private void HandleDropItemResponse(SteamItem droppedItem)
		{
			if (droppedItem != null)
			{
				IEnumerable<Lockbox> itemsOfType = ServiceProvider.GetService<GameItemService>().GetItemsOfType<Lockbox>();
				Lockbox lockbox = itemsOfType.FirstOrDefault((Lockbox x) => x.GetLockboxId() == droppedItem.IdentityId);
				if (lockbox != null)
				{
					LockboxData lockboxData = new LockboxData
					{
						Lockbox = lockbox,
						CurrentName = ServiceProvider.GetService<LocalizationService>().GetLockboxName(lockbox.HeroClass, lockbox.Season, ELocalizedTextCase.NONE),
						SteamItem = droppedItem,
						Visible = true
					};
					ServiceProvider.GetService<PopupService>().ShowUnlockLockbox(lockboxData);
					ServiceProvider.GetService<TelemetryService>().SubmitDrop(lockbox.HeroClass, lockbox.Season);
				}
			}
		}

		// Token: 0x06000B46 RID: 2886 RVA: 0x00043A34 File Offset: 0x00041C34
		private void OnVoteUpdate(VoteMapEvent evt)
		{
			this.RebuildData();
			InGameEndmatchVoteView view = base.GetView<InGameEndmatchVoteView>();
			if (view != null)
			{
				this.UpdateVoteView(view);
			}
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x00043A64 File Offset: 0x00041C64
		private void UpdateVoteView(InGameEndmatchVoteView view)
		{
			view.SetData(UserProfile.LocalGameClient.clientMode, this._networkGameService.GetGameModeMetaData().VoteMap.Votations, this._networkGameService.GetGameModeMetaData().VoteMap.MapModeEntry, this._canVote);
		}

		// Token: 0x06000B48 RID: 2888 RVA: 0x00043AB4 File Offset: 0x00041CB4
		private void OnTimeRemaining(TimeRemainingEvent evt)
		{
			InGameEndRoundsMessegeView view = base.GetView<InGameEndRoundsMessegeView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.RoundsTimeUpdate(this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType, (int)evt.RemainingTime);
			}
		}

		// Token: 0x06000B49 RID: 2889 RVA: 0x00043B04 File Offset: 0x00041D04
		private void OnChangeState(ChangeGameStateEvent evt)
		{
			if (this._networkGameService.GetGameModeMetaData().GameConfig.GameMode == EGameMode.Rounds && evt.GameStateType == EGameState.PLAYING)
			{
				InGameEndRoundsMessegeView view = base.GetView<InGameEndRoundsMessegeView>();
				if (view != null && view.isActiveAndEnabled)
				{
					view.RoundsDispatchStarted();
				}
				if (!UserProfile.LocalGameClient.spawned)
				{
					InGameEndmatchController.EnforcePlayerSpectate();
				}
			}
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x00043B70 File Offset: 0x00041D70
		public static void EnforcePlayerSpectate()
		{
			ClientCommonMetaData teammateTarget = ServiceProvider.GetService<GameModeService>().GetTeammateTarget((sbyte)UserProfile.LocalGameClient.team);
			if (teammateTarget != null && NetworkCharacterTable.ActivePlayers.ContainsKey(teammateTarget.User) && NetworkCharacterTable.ActivePlayers[teammateTarget.User] != null)
			{
				ServiceProvider.GetService<CameraService>().SetCamera(Cameras.KILLCAM, NetworkCharacterTable.ActivePlayers[teammateTarget.User].transform, LoadoutUtil.GetHeroClass(teammateTarget.LoadoutInfo), teammateTarget, -1);
			}
			else
			{
				ServiceProvider.GetService<CameraService>().SetCamera(Cameras.CUTSCENE, null, EHeroClass.NONE, null, -1);
				UIManager.Instance.ChangeState("CUTSCENE");
			}
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x00043C1C File Offset: 0x00041E1C
		private void OnRoundUp(ChangeRoundEvent evt)
		{
			this.RebuildData();
			Team team = (Team)evt.Winner;
			this._winnerTeam = ((UserProfile.LocalGameClient.team != team) ? ((team <= Team.NONE) ? EWinningTeam.NONE : EWinningTeam.ENEMY) : EWinningTeam.MINE);
			InGameEndmatchScoreboardView view = base.GetView<InGameEndmatchScoreboardView>();
			if (view != null)
			{
				this.UpdateScoreboard(view);
			}
			InGameEndmatchScoreView view2 = base.GetView<InGameEndmatchScoreView>();
			if (view2 != null)
			{
				view2.SetData(UserProfile.LocalGameClient.clientMode, this._gameModeService.GameMode, this._playerWinner == EWinningTeam.MINE, this._yourTeamScore, this._enemyTeamScore, this._yourTeamWins, this._enemyTeamWins, UserProfile.LocalGameClient.team);
			}
			InGameEndRoundsEndView view3 = base.GetView<InGameEndRoundsEndView>();
			if (view3 != null)
			{
				view3.RoundsDispatchEnded(this._winnerTeam, this._yourTeamScore, this._enemyTeamScore);
			}
			if ((int)evt.CurrentRound > (int)this._networkGameService.GetGameModeMetaData().GameConfig.Rounds)
			{
				return;
			}
			if (this._winnerTeam > EWinningTeam.NONE && this._networkGameService.GetGameModeMetaData().TeamMetaDataMap[evt.Winner].Points >= (int)this._networkGameService.GetGameModeMetaData().GameConfig.Rounds / 2 + 1)
			{
				return;
			}
			this._roundUpRoutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.RoundUpRoutine());
		}

		// Token: 0x06000B4C RID: 2892 RVA: 0x00043D84 File Offset: 0x00041F84
		private IEnumerator RoundUpRoutine()
		{
			yield return new WaitForSeconds(0.25f);
			UIManager.Instance.ChangeState("ROUND_END", true);
			yield return new WaitForSeconds(3f);
			UIManager.Instance.ChangeState("ROUND_SCORE", true);
			yield return new WaitForSeconds(3f);
			UIManager.Instance.ChangeState("RESPAWN", true);
			this._roundUpRoutine = null;
			yield break;
		}

		// Token: 0x06000B4D RID: 2893 RVA: 0x00043DA0 File Offset: 0x00041FA0
		private IEnumerator EndGameRoutine()
		{
			yield return new WaitForSeconds(0.25f);
			if (UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER)
			{
				EWinningTeam playerWinner = this._playerWinner;
				if (playerWinner != EWinningTeam.NONE)
				{
					if (playerWinner != EWinningTeam.MINE)
					{
						if (playerWinner == EWinningTeam.ENEMY)
						{
							UIManager.Instance.ChangeState("DEFEAT", true);
						}
					}
					else
					{
						UIManager.Instance.ChangeState("VICTORY", true);
					}
				}
				else
				{
					UIManager.Instance.ChangeState("TIED", true);
				}
			}
			else
			{
				UIManager.Instance.ChangeState("TIED", true);
			}
			yield return new WaitForSeconds(4f);
			EGameMode gameMode = this._gameModeService.GameMode;
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				UIManager.Instance.ChangeState("FINAL_SCORE", true);
				yield return new WaitForSeconds(4f);
			}
			UIManager.Instance.ChangeState("FINAL_SCOREBOARD", true);
			ServiceProvider.GetService<InputControlService>().ClearAll();
			this._endMatchRoutine = null;
			yield break;
		}

		// Token: 0x06000B4E RID: 2894 RVA: 0x00043DBC File Offset: 0x00041FBC
		internal void VoteEntry(int entry)
		{
			if (!this._canVote)
			{
				return;
			}
			this._canVote = false;
			VoteMapRequest voteMapRequest = new VoteMapRequest
			{
				MapModeEntry = new MapModeEntry
				{
					GameMode = this._networkGameService.GetGameModeMetaData().VoteMap.Votations[entry].GameMode,
					GameMap = this._networkGameService.GetGameModeMetaData().VoteMap.Votations[entry].GameMap
				}
			};
			ServiceProvider.GetService<NetworkGameService>().RaiseNetworkEvent(voteMapRequest);
		}

		// Token: 0x04000EB4 RID: 3764
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000EB5 RID: 3765
		private readonly GameModeService _gameModeService;

		// Token: 0x04000EB6 RID: 3766
		private readonly HighSpeedArray<ClientCommonMetaData> _yourTeamPlayerData;

		// Token: 0x04000EB7 RID: 3767
		private readonly HighSpeedArray<ClientCommonMetaData> _enemyTeamPlayerData;

		// Token: 0x04000EB8 RID: 3768
		private readonly ClientCommonMetaDataSortByScore _playerDataSorter;

		// Token: 0x04000EB9 RID: 3769
		private int _playerRankingPosition = -1;

		// Token: 0x04000EBA RID: 3770
		private int _yourTeamScore = -1;

		// Token: 0x04000EBB RID: 3771
		private int _enemyTeamScore = -1;

		// Token: 0x04000EBC RID: 3772
		private int _yourTeamWins = -1;

		// Token: 0x04000EBD RID: 3773
		private int _enemyTeamWins = -1;

		// Token: 0x04000EBE RID: 3774
		private EWinningTeam _playerWinner;

		// Token: 0x04000EBF RID: 3775
		private EWinningTeam _winnerTeam = EWinningTeam.UNDEFINED;

		// Token: 0x04000EC0 RID: 3776
		private Coroutine _endMatchRoutine;

		// Token: 0x04000EC1 RID: 3777
		private Coroutine _roundUpRoutine;

		// Token: 0x04000EC2 RID: 3778
		private bool _canVote = true;
	}
}
