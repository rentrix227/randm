﻿using System;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001E2 RID: 482
	public class InventoryScrapLockboxComponent : PoolableComponent
	{
		// Token: 0x060009C5 RID: 2501 RVA: 0x0003A690 File Offset: 0x00038890
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.SkinButton != null)
			{
				this.SkinButton.onClick.AddListener(new UnityAction(this.OnScrapLockboxClicked));
			}
			this.ProgressionFillBar.material = new Material(this.ProgressionFillBar.material);
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x0003A6F0 File Offset: 0x000388F0
		internal void SetData(bool completed, int quantity)
		{
			this._completed = completed;
			this.Completed.SetActive(completed);
			this.Uncompleted.SetActive(!completed);
			this.ProgressionFillBar.material.SetFloat("_Fill", (float)quantity / 10f);
			this.ProgressionText.text = quantity + " / 10";
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x00008CA4 File Offset: 0x00006EA4
		private void OnScrapLockboxClicked()
		{
			if (!this._completed)
			{
				return;
			}
			if (this.OnScrapLockboxClick != null)
			{
				this.OnScrapLockboxClick();
			}
		}

		// Token: 0x04000D0E RID: 3342
		public GameObject Completed;

		// Token: 0x04000D0F RID: 3343
		public GameObject Uncompleted;

		// Token: 0x04000D10 RID: 3344
		public Image ProgressionFillBar;

		// Token: 0x04000D11 RID: 3345
		public Text ProgressionText;

		// Token: 0x04000D12 RID: 3346
		public Button SkinButton;

		// Token: 0x04000D13 RID: 3347
		internal Action OnScrapLockboxClick;

		// Token: 0x04000D14 RID: 3348
		private bool _completed;
	}
}
