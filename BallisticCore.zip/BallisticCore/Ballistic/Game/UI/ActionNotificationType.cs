﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000273 RID: 627
	public enum ActionNotificationType
	{
		// Token: 0x0400101E RID: 4126
		None,
		// Token: 0x0400101F RID: 4127
		Kill,
		// Token: 0x04001020 RID: 4128
		DoubleKill,
		// Token: 0x04001021 RID: 4129
		TripleKill,
		// Token: 0x04001022 RID: 4130
		OverKill,
		// Token: 0x04001023 RID: 4131
		ExpertStreak,
		// Token: 0x04001024 RID: 4132
		ExpertKill,
		// Token: 0x04001025 RID: 4133
		EpicStreak,
		// Token: 0x04001026 RID: 4134
		EpicKill,
		// Token: 0x04001027 RID: 4135
		LegendaryStreak,
		// Token: 0x04001028 RID: 4136
		LegendaryKill,
		// Token: 0x04001029 RID: 4137
		KillAssist,
		// Token: 0x0400102A RID: 4138
		CriticalKillAssist,
		// Token: 0x0400102B RID: 4139
		Headshot,
		// Token: 0x0400102C RID: 4140
		MarksmanHeadshot,
		// Token: 0x0400102D RID: 4141
		Backstab,
		// Token: 0x0400102E RID: 4142
		DefenseKill,
		// Token: 0x0400102F RID: 4143
		AvengerKill,
		// Token: 0x04001030 RID: 4144
		SaviorKill,
		// Token: 0x04001031 RID: 4145
		CapturePoint,
		// Token: 0x04001032 RID: 4146
		Standing,
		// Token: 0x04001033 RID: 4147
		JuggernautPoint,
		// Token: 0x04001034 RID: 4148
		JuggernautAssist,
		// Token: 0x04001035 RID: 4149
		JuggernautKill
	}
}
