﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F7 RID: 503
	public class PoolableComponent : MonoBehaviour
	{
		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06000A26 RID: 2598 RVA: 0x0000918F File Offset: 0x0000738F
		// (set) Token: 0x06000A27 RID: 2599 RVA: 0x00009197 File Offset: 0x00007397
		internal bool InUse { get; private set; }

		// Token: 0x06000A28 RID: 2600 RVA: 0x000091A0 File Offset: 0x000073A0
		public virtual void Use()
		{
			this.InUse = true;
			if (!base.gameObject.activeSelf)
			{
				base.gameObject.SetActive(true);
			}
		}

		// Token: 0x06000A29 RID: 2601 RVA: 0x0003BFFC File Offset: 0x0003A1FC
		public virtual void Dispose()
		{
			this.InUse = false;
			if (base.transform.parent != null)
			{
				base.transform.SetSiblingIndex(base.transform.parent.childCount - 1);
			}
			if (base.gameObject.activeSelf)
			{
				base.gameObject.SetActive(false);
			}
		}
	}
}
