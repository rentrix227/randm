﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001CA RID: 458
	public class GameplayRoundClassComponent : PoolableComponent
	{
		// Token: 0x06000988 RID: 2440 RVA: 0x00039BAC File Offset: 0x00037DAC
		internal void SetState(bool isSpawned, string playerName, EHeroClass heroClass)
		{
			this._isSpawned = isSpawned;
			this.NotSpawned.SetActive(!this._isSpawned);
			this.Spawned.SetActive(this._isSpawned);
			for (int i = 0; i < this.ClassIcons.Length; i++)
			{
				if (this.ClassIcons[i].heroClass == heroClass)
				{
					this.ClassImageIcon.sprite = this.ClassIcons[i].heroIcon;
					break;
				}
			}
			if (this.ClassPlayerName != null)
			{
				this.ClassPlayerName.text = playerName;
			}
		}

		// Token: 0x04000C9F RID: 3231
		public GameObject NotSpawned;

		// Token: 0x04000CA0 RID: 3232
		public GameObject Spawned;

		// Token: 0x04000CA1 RID: 3233
		public Image ClassImageIcon;

		// Token: 0x04000CA2 RID: 3234
		public GameplayRoundClassComponent.ClassIcon[] ClassIcons;

		// Token: 0x04000CA3 RID: 3235
		public Text ClassPlayerName;

		// Token: 0x04000CA4 RID: 3236
		private bool _isSpawned;

		// Token: 0x020001CB RID: 459
		[Serializable]
		public struct ClassIcon
		{
			// Token: 0x04000CA5 RID: 3237
			public EHeroClass heroClass;

			// Token: 0x04000CA6 RID: 3238
			public Sprite heroIcon;
		}
	}
}
