﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001BA RID: 442
	public class AvailableWeaponComponent : PoolableComponent, IPointerEnterHandler, IEventSystemHandler
	{
		// Token: 0x06000924 RID: 2340 RVA: 0x000084AF File Offset: 0x000066AF
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.WeaponToggle != null)
			{
				this.WeaponToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnToggleClick));
			}
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x000084E9 File Offset: 0x000066E9
		private void OnToggleClick(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			if (this.OnWeaponClick != null)
			{
				this.OnWeaponClick(this._data, this._loadout);
			}
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x00037F78 File Offset: 0x00036178
		internal void SetData(PlayerWeaponData data, PlayerLoadoutV2 loadout, bool selected)
		{
			this._isSetting = true;
			this._data = data;
			this._loadout = loadout;
			if (this.WeaponToggle != null)
			{
				this.WeaponToggle.isOn = selected;
				this.WeaponToggle.interactable = true;
			}
			if (this.WeaponComponent != null)
			{
				this.WeaponComponent.SetData(data, loadout);
			}
			this._isSetting = false;
		}

		// Token: 0x06000927 RID: 2343 RVA: 0x00037FE8 File Offset: 0x000361E8
		internal void SetData(WeaponV4 data, PlayerLoadoutV2 loadout)
		{
			this._isSetting = true;
			if (this.WeaponToggle != null)
			{
				this.WeaponToggle.isOn = false;
				this.WeaponToggle.interactable = false;
			}
			if (this.WeaponComponent != null)
			{
				this.WeaponComponent.SetData(data, loadout);
			}
			this._isSetting = false;
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x0000851F File Offset: 0x0000671F
		void IPointerEnterHandler.OnPointerEnter(PointerEventData eventData)
		{
			if (!this.WeaponToggle.interactable)
			{
				return;
			}
			if (this.OnWeaponPreview != null)
			{
				this.OnWeaponPreview(this._data, this._loadout);
			}
		}

		// Token: 0x04000BF7 RID: 3063
		public SoldiersWeaponComponent WeaponComponent;

		// Token: 0x04000BF8 RID: 3064
		public Toggle WeaponToggle;

		// Token: 0x04000BF9 RID: 3065
		private PlayerWeaponData _data;

		// Token: 0x04000BFA RID: 3066
		private PlayerLoadoutV2 _loadout;

		// Token: 0x04000BFB RID: 3067
		public Action<PlayerWeaponData, PlayerLoadoutV2> OnWeaponPreview;

		// Token: 0x04000BFC RID: 3068
		public Action<PlayerWeaponData, PlayerLoadoutV2> OnWeaponClick;

		// Token: 0x04000BFD RID: 3069
		private bool _isSetting;
	}
}
