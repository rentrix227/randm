﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001FA RID: 506
	public class QuickMatchButtonComponent : MonoBehaviour
	{
		// Token: 0x06000A31 RID: 2609 RVA: 0x0003C234 File Offset: 0x0003A434
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.target.onValueChanged.AddListener(new UnityAction<bool>(this.OnValueChanged));
			this._lastState = this.target.isOn;
			this._quickMatchService = ServiceProvider.GetService<QuickMatchService>();
			this._quickMatchService.OnFinish += this.OnFinish;
		}

		// Token: 0x06000A32 RID: 2610 RVA: 0x000091D5 File Offset: 0x000073D5
		public void OnDestroy()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._quickMatchService.OnFinish -= this.OnFinish;
		}

		// Token: 0x06000A33 RID: 2611 RVA: 0x000091F9 File Offset: 0x000073F9
		private void OnFinish()
		{
			Debug.Log("QuickMatchButtonComponent:Finish");
			this.target.isOn = false;
		}

		// Token: 0x06000A34 RID: 2612 RVA: 0x00009211 File Offset: 0x00007411
		private void OnValueChanged(bool value)
		{
			if (this._lastState != value && value)
			{
				ServiceProvider.GetService<QuickMatchService>().Search();
			}
		}

		// Token: 0x04000D93 RID: 3475
		public Toggle target;

		// Token: 0x04000D94 RID: 3476
		private bool _lastState;

		// Token: 0x04000D95 RID: 3477
		private QuickMatchService _quickMatchService;
	}
}
