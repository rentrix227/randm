﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000275 RID: 629
	public abstract class GameplayBaseChatView : BaseView<InGameHeaderController>
	{
		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000D63 RID: 3427 RVA: 0x0000B308 File Offset: 0x00009508
		internal bool Visible
		{
			get
			{
				return base.gameObject.activeSelf;
			}
		}

		// Token: 0x06000D64 RID: 3428
		internal abstract bool IsTyping();

		// Token: 0x06000D65 RID: 3429
		internal abstract void SetTeamOnly(bool teamOnly);

		// Token: 0x06000D66 RID: 3430
		internal abstract void FocusInputField();

		// Token: 0x06000D67 RID: 3431
		internal abstract void HideInputField();

		// Token: 0x06000D68 RID: 3432 RVA: 0x0004EEBC File Offset: 0x0004D0BC
		internal void AddUserMessage(string nickname, string message, bool teamOnly, bool myTeam)
		{
			message = StringUtils.RemoveRichText(message);
			string text = ((!teamOnly) ? string.Format("\n<color=#{0}>{1}:</color> {2} ", this.OthersColor, nickname, message) : string.Format("\n<color=#{0}>{1}: {2}</color> ", this.TeamColor, nickname, message));
			this.AddTextEntry(text);
		}

		// Token: 0x06000D69 RID: 3433 RVA: 0x0004EF08 File Offset: 0x0004D108
		internal void AddServerMessage(string message)
		{
			string text = ServiceProvider.GetService<LocalizationService>().Get("server_message", ELocalizedTextCase.NONE);
			string text2 = string.Format("\n<color=#{0}>[{1}]</color> {2}", this.ServerColor, text, message);
			this.AddTextEntry(text2);
		}

		// Token: 0x06000D6A RID: 3434
		internal abstract void AddTextEntry(string entryText);

		// Token: 0x0400103C RID: 4156
		[Header("Chat Parameters")]
		public int ChatEntries = 30;

		// Token: 0x0400103D RID: 4157
		public string TeamColor = "19ecff";

		// Token: 0x0400103E RID: 4158
		public string OthersColor = "7f8285";

		// Token: 0x0400103F RID: 4159
		public string ServerColor = "eeee22";
	}
}
