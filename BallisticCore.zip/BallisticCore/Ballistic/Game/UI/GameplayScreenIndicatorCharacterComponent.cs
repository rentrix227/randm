﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001CE RID: 462
	public class GameplayScreenIndicatorCharacterComponent : MonoBehaviour
	{
		// Token: 0x06000991 RID: 2449 RVA: 0x000089F7 File Offset: 0x00006BF7
		public void SetNickname(string nickname)
		{
			this.NicknameLabel.text = nickname;
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x00039C54 File Offset: 0x00037E54
		public void UpdateInfo(bool visible, bool teammate, float health, float maxHealth, float arrowSize)
		{
			if (this.VisibleAnimator.isInitialized)
			{
				this.VisibleAnimator.SetBool(GameplayScreenIndicatorCharacterComponent._visibleHash, visible);
				this.VisibleAnimator.SetBool(GameplayScreenIndicatorCharacterComponent._friendHash, !visible && teammate);
			}
			if (this.ArrowIndicator != null)
			{
				this.ArrowIndicator.localScale = Vector3.one * arrowSize;
			}
			int num = Mathf.CeilToInt(health * 100f);
			if (num != this._lastHealth)
			{
				this._lastHealth = num;
				if (this.HealthLabel != null)
				{
					this.HealthLabel.text = num.ToString();
				}
				if (this.HealthFillImage != null)
				{
					this.HealthFillImage.fillAmount = health / maxHealth;
				}
			}
		}

		// Token: 0x06000993 RID: 2451 RVA: 0x00008A05 File Offset: 0x00006C05
		public void TriggerVoice()
		{
			if (this.VoiceAnimator.isInitialized)
			{
				this.VoiceAnimator.SetTrigger(GameplayScreenIndicatorCharacterComponent._voiceHash);
			}
		}

		// Token: 0x04000CAE RID: 3246
		public Animator VisibleAnimator;

		// Token: 0x04000CAF RID: 3247
		public Animator VoiceAnimator;

		// Token: 0x04000CB0 RID: 3248
		public Transform ArrowIndicator;

		// Token: 0x04000CB1 RID: 3249
		public Text NicknameLabel;

		// Token: 0x04000CB2 RID: 3250
		public Text HealthLabel;

		// Token: 0x04000CB3 RID: 3251
		public Image HealthFillImage;

		// Token: 0x04000CB4 RID: 3252
		private int _lastHealth = -1;

		// Token: 0x04000CB5 RID: 3253
		private static readonly int _visibleHash = Animator.StringToHash("visible");

		// Token: 0x04000CB6 RID: 3254
		private static readonly int _friendHash = Animator.StringToHash("arrow_only");

		// Token: 0x04000CB7 RID: 3255
		private static readonly int _voiceHash = Animator.StringToHash("voice");
	}
}
