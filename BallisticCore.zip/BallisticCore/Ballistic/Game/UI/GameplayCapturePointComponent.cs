﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C7 RID: 455
	public class GameplayCapturePointComponent : MonoBehaviour
	{
		// Token: 0x0600097A RID: 2426 RVA: 0x00008892 File Offset: 0x00006A92
		public void Awake()
		{
			this._animator = base.GetComponent<Animator>();
		}

		// Token: 0x0600097B RID: 2427 RVA: 0x000088A0 File Offset: 0x00006AA0
		internal void SetState(UITeam ownerTeam, UITeam capturingTeam, float captureAmount, bool isProtected, bool playerIsCapturing)
		{
			this._ownerTeam = ownerTeam;
			this._capturingTeam = capturingTeam;
			this._captureAmount = captureAmount;
			this._isProtected = isProtected;
			this._playerIsCapturing = playerIsCapturing && ownerTeam != UITeam.Mine;
			this.UpdateState();
		}

		// Token: 0x0600097C RID: 2428 RVA: 0x000088DC File Offset: 0x00006ADC
		public void OnEnable()
		{
			this._isDirty = true;
			this.UpdateState();
		}

		// Token: 0x0600097D RID: 2429 RVA: 0x000088EB File Offset: 0x00006AEB
		public void Update()
		{
			if (this._isDirty)
			{
				this.UpdateState();
			}
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x000398EC File Offset: 0x00037AEC
		private void UpdateState()
		{
			if (this._animator == null || !this._animator.isInitialized)
			{
				return;
			}
			this._animator.SetInteger(GameplayCapturePointComponent._ownerTeamHash, (int)this._ownerTeam);
			this._animator.SetInteger(GameplayCapturePointComponent._capturingTeamHash, (int)this._capturingTeam);
			this._animator.SetFloat(GameplayCapturePointComponent._captureAmountHash, this._captureAmount);
			this._animator.SetBool(GameplayCapturePointComponent._protectedHash, this._isProtected);
			this._animator.SetBool(GameplayCapturePointComponent._playerIsCapturingHash, this._playerIsCapturing);
			if (this.AudioSourceToSetPitch != null)
			{
				this.AudioSourceToSetPitch.pitch = Mathf.Lerp(this.MinAudioPitch, this.MaxAudioPitch, this._captureAmount);
			}
			this._isDirty = false;
		}

		// Token: 0x04000C83 RID: 3203
		public AudioSource AudioSourceToSetPitch;

		// Token: 0x04000C84 RID: 3204
		public float MinAudioPitch = 1f;

		// Token: 0x04000C85 RID: 3205
		public float MaxAudioPitch = 1.5f;

		// Token: 0x04000C86 RID: 3206
		private Animator _animator;

		// Token: 0x04000C87 RID: 3207
		private static readonly int _ownerTeamHash = Animator.StringToHash("owner_team");

		// Token: 0x04000C88 RID: 3208
		private static readonly int _capturingTeamHash = Animator.StringToHash("capturing_team");

		// Token: 0x04000C89 RID: 3209
		private static readonly int _captureAmountHash = Animator.StringToHash("capture_amount");

		// Token: 0x04000C8A RID: 3210
		private static readonly int _protectedHash = Animator.StringToHash("protected");

		// Token: 0x04000C8B RID: 3211
		private static readonly int _playerIsCapturingHash = Animator.StringToHash("capture_by_player");

		// Token: 0x04000C8C RID: 3212
		private UITeam _ownerTeam;

		// Token: 0x04000C8D RID: 3213
		private UITeam _capturingTeam;

		// Token: 0x04000C8E RID: 3214
		private float _captureAmount;

		// Token: 0x04000C8F RID: 3215
		private bool _isProtected;

		// Token: 0x04000C90 RID: 3216
		private bool _isDirty;

		// Token: 0x04000C91 RID: 3217
		private bool _playerIsCapturing;
	}
}
