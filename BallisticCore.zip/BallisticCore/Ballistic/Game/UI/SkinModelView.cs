﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Game.Weapon;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200030E RID: 782
	public class SkinModelView : BaseView<InventoryController>
	{
		// Token: 0x06001087 RID: 4231 RVA: 0x0005FBF8 File Offset: 0x0005DDF8
		internal void SetData(WeaponSkinData weaponSkinData)
		{
			this.Root.localRotation = Quaternion.Euler(0f, 270f, 0f);
			for (int i = 0; i < this.Root.childCount; i++)
			{
				Object.Destroy(this.Root.GetChild(i).gameObject);
			}
			foreach (SkinModelView.RarityBackground rarityBackground in this.RarityBackgrounds)
			{
				rarityBackground.Background.SetActive(rarityBackground.Rarity == weaponSkinData.WeaponSkin.Rarity);
			}
			ServiceProvider.GetService<EventProxy>().StartCoroutine(this.LoadAsync(weaponSkinData, this.Root));
		}

		// Token: 0x06001088 RID: 4232 RVA: 0x0005FCB8 File Offset: 0x0005DEB8
		private IEnumerator LoadAsync(WeaponSkinData weaponSkinData, Transform parent)
		{
			ResourceRequest rqt = Resources.LoadAsync<GameObject>("weapon/" + weaponSkinData.Weapon.ItemModel + "_prefab");
			while (!rqt.isDone)
			{
				yield return null;
			}
			GameObject weaponInstance = Object.Instantiate<GameObject>(rqt.asset as GameObject, parent);
			if (weaponSkinData.WeaponSkin.WeaponSkinName != EWeaponSkinName.DEFAULT && weaponInstance != null)
			{
				foreach (MonoBehaviour monoBehaviour in weaponInstance.GetComponentsInChildren<MonoBehaviour>())
				{
					Object.Destroy(monoBehaviour);
				}
				weaponInstance.transform.localPosition = Vector3.zero;
				weaponInstance.transform.localRotation = Quaternion.identity;
				weaponInstance.transform.localScale = Vector3.one;
				if (weaponInstance.transform.Find(weaponSkinData.Weapon.ItemModel + "_A") != null)
				{
					Transform transform = weaponInstance.transform.Find(weaponSkinData.Weapon.ItemModel + "_A");
					transform.localPosition = new Vector3(0.08f, 0f, 0.08f);
					Transform transform2 = weaponInstance.transform.Find(weaponSkinData.Weapon.ItemModel + "_B");
					transform2.localPosition = new Vector3(-0.08f, 0f, -0.08f);
				}
				Transform transform3 = weaponInstance.transform.Find(weaponSkinData.Weapon.ItemModel + "_center");
				if (transform3 != null)
				{
					weaponInstance.transform.localPosition = -transform3.localPosition;
					weaponInstance.transform.RotateAround(parent.position, Vector3.up, transform3.localRotation.eulerAngles.y);
					weaponInstance.transform.RotateAround(parent.position, Vector3.forward, transform3.localRotation.eulerAngles.x);
				}
				else
				{
					MeshRenderer[] componentsInChildren2 = weaponInstance.transform.Find(weaponSkinData.Weapon.ItemModel + "_3rd").GetComponentsInChildren<MeshRenderer>();
					if (componentsInChildren2.Length > 0)
					{
						Vector3 vector = Vector3.zero;
						foreach (MeshRenderer meshRenderer in componentsInChildren2)
						{
							vector += meshRenderer.bounds.center;
						}
						weaponInstance.transform.position = weaponInstance.transform.position - vector / (float)componentsInChildren2.Length;
					}
				}
				Object.Destroy(weaponInstance.transform.Find(weaponSkinData.Weapon.ItemModel + "_3rd").gameObject);
				int num = weaponSkinData.Weapon.ItemModel.IndexOf("_", StringComparison.Ordinal);
				string text;
				if (num >= 0)
				{
					text = weaponSkinData.Weapon.ItemModel.Substring(0, num);
				}
				else
				{
					text = weaponSkinData.Weapon.ItemModel;
				}
				string text2 = text + "/" + weaponSkinData.WeaponSkin.WeaponSkinName;
				WeaponSkinDefinition weaponSkinDefinition = Resources.Load<WeaponSkinDefinition>(text2);
				if (weaponSkinDefinition == null)
				{
					string[] array2 = weaponSkinData.Weapon.ItemModel.Split(new char[] { '_' });
					if (array2.Length >= 2)
					{
						text2 = string.Concat(new object[]
						{
							array2[0],
							"/",
							array2[1],
							"/",
							weaponSkinData.WeaponSkin.WeaponSkinName
						});
						weaponSkinDefinition = Resources.Load<WeaponSkinDefinition>(text2);
					}
				}
				if (weaponSkinDefinition != null)
				{
					weaponSkinDefinition.Apply(weaponInstance.transform);
				}
				else
				{
					Debug.LogWarning("[SKinModelView] Invalid weapon skin definition for " + text2);
				}
			}
			yield break;
		}

		// Token: 0x040015BF RID: 5567
		public Transform Root;

		// Token: 0x040015C0 RID: 5568
		public SkinModelView.RarityBackground[] RarityBackgrounds;

		// Token: 0x0200030F RID: 783
		[Serializable]
		public struct RarityBackground
		{
			// Token: 0x040015C1 RID: 5569
			public ERarity Rarity;

			// Token: 0x040015C2 RID: 5570
			public GameObject Background;
		}
	}
}
