﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D3 RID: 723
	public class InventorySearchSettingsView : BaseView<InventoryController>
	{
		// Token: 0x06000F2E RID: 3886 RVA: 0x0005B570 File Offset: 0x00059770
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SearchInputField.onEndEdit.AddListener(new UnityAction<string>(this.OnSearchSubmit));
			this.SearchBtn.onClick.AddListener(new UnityAction(this.OnSearchClick));
		}

		// Token: 0x06000F2F RID: 3887 RVA: 0x0000C7A8 File Offset: 0x0000A9A8
		private void OnSearchSubmit(string value)
		{
			base._controller.SetFilterName(value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F30 RID: 3888 RVA: 0x0000C7CC File Offset: 0x0000A9CC
		private void OnSearchClick()
		{
			base._controller.SetFilterName(this.SearchInputField.text);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x04001455 RID: 5205
		public InputField SearchInputField;

		// Token: 0x04001456 RID: 5206
		public Button SearchBtn;
	}
}
