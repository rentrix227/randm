﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200023E RID: 574
	internal class ScrapData : SteamItemData
	{
		// Token: 0x04000F4D RID: 3917
		internal uint Amount;
	}
}
