﻿using System;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Pattern.Singleton;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000254 RID: 596
	public class SoldiersWeaponController : BaseController
	{
		// Token: 0x06000CDC RID: 3292 RVA: 0x0004D6D8 File Offset: 0x0004B8D8
		public SoldiersWeaponController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldiersService = ServiceProvider.GetService<SoldiersService>();
			this._playerWeaponService = ServiceProvider.GetService<PlayerWeaponService>();
			this._allWeapons = new HighSpeedArray<WeaponV4>(100);
			this._avaliableWeapons = new HighSpeedArray<PlayerWeaponData>(100);
			this._soldiersService.OnWeaponChangeRequest += this.OnWeaponChangeRequest;
			this._soldiersService.OnWeaponClick += this.OnWeaponClick;
			this._soldiersService.OnWeaponSkinClick += this.OnWeaponSkinClick;
			this._soldiersService.OnWeaponPreview += this.OnWeaponPreview;
		}

		// Token: 0x06000CDD RID: 3293 RVA: 0x0004D780 File Offset: 0x0004B980
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldiersService.OnWeaponChangeRequest -= this.OnWeaponChangeRequest;
			this._soldiersService.OnWeaponClick -= this.OnWeaponClick;
			this._soldiersService.OnWeaponSkinClick -= this.OnWeaponSkinClick;
			this._soldiersService.OnWeaponPreview -= this.OnWeaponPreview;
		}

		// Token: 0x06000CDE RID: 3294 RVA: 0x0004D7FC File Offset: 0x0004B9FC
		private void OnWeaponChangeRequest(EHeroClass heroClass, EHeroItemSlot itemSlot, PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			this._currentWeaponSelected = weapon;
			this._currentSlot = itemSlot;
			this._currentSkin = weapon.PlayerItem.GetSkinIdForLoadout(loadout);
			EditWeaponCurrentView view = base.GetView<EditWeaponCurrentView>();
			if (view != null)
			{
				view.SetStartWeapon(weapon, loadout);
			}
			EditWeaponAvaliableView view2 = base.GetView<EditWeaponAvaliableView>();
			if (view2 != null)
			{
				this._soldiersService.GetWeaponsForSlot(itemSlot, this._avaliableWeapons, this._allWeapons);
				view2.SetWeaponList(this._avaliableWeapons, this._allWeapons, weapon, loadout);
			}
			EditWeaponStatsView view3 = base.GetView<EditWeaponStatsView>();
			if (view3 != null)
			{
				view3.SetStartInfo(this._currentWeaponSelected, this._currentWeaponSelected, this._playerWeaponService.GetAvailableSkins(this._currentWeaponSelected).ToList<WeaponSkin>(), this._currentSkin);
			}
		}

		// Token: 0x06000CDF RID: 3295 RVA: 0x0004D8C8 File Offset: 0x0004BAC8
		private void OnWeaponClick(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			if (this._currentWeaponSelected.PlayerItem.GameItemID == weapon.PlayerItem.GameItemID && Time.time - this._lastWeaponSelectedTimestamp < 0.5f)
			{
				this.DispatchWeaponSelected();
				UIManager.Instance.DisableLayer(1);
			}
			this._lastWeaponSelectedTimestamp = Time.time;
			this._currentWeaponSelected = weapon;
			this._currentSkin = weapon.PlayerItem.GetSkinIdForLoadout(loadout);
			EditWeaponCurrentView view = base.GetView<EditWeaponCurrentView>();
			if (view != null)
			{
				view.SetStartWeapon(weapon, loadout);
			}
			EditWeaponAvaliableView view2 = base.GetView<EditWeaponAvaliableView>();
			if (view2 != null)
			{
				this._soldiersService.GetWeaponsForSlot(this._currentSlot, this._avaliableWeapons, this._allWeapons);
				view2.SetWeaponList(this._avaliableWeapons, this._allWeapons, weapon, loadout);
			}
			EditWeaponStatsView view3 = base.GetView<EditWeaponStatsView>();
			if (view3 != null)
			{
				view3.SetStartInfo(this._currentWeaponSelected, this._currentWeaponSelected, this._playerWeaponService.GetAvailableSkins(this._currentWeaponSelected), this._currentSkin);
			}
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x0004D9DC File Offset: 0x0004BBDC
		private void OnWeaponPreview(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			EditWeaponStatsView view = base.GetView<EditWeaponStatsView>();
			if (view != null)
			{
				view.SetStartInfo(this._currentWeaponSelected, weapon, this._playerWeaponService.GetAvailableSkins(this._currentWeaponSelected), this._currentSkin);
			}
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x0004DA20 File Offset: 0x0004BC20
		private void OnWeaponSkinClick(PlayerWeaponData weapon, WeaponSkin skin, PlayerLoadoutV2 loadout)
		{
			this._currentSkin = weapon.PlayerItem.GetSkinIdForLoadout(loadout);
			EditWeaponCurrentView view = base.GetView<EditWeaponCurrentView>();
			if (view != null)
			{
				view.SetStartWeapon(weapon, loadout);
			}
			EditWeaponAvaliableView view2 = base.GetView<EditWeaponAvaliableView>();
			if (view2 != null)
			{
				this._soldiersService.GetWeaponsForSlot(this._currentSlot, this._avaliableWeapons, this._allWeapons);
				view2.SetWeaponList(this._avaliableWeapons, this._allWeapons, weapon, loadout);
			}
			EditWeaponStatsView view3 = base.GetView<EditWeaponStatsView>();
			if (view3 != null)
			{
				view3.SetStartInfo(this._currentWeaponSelected, this._currentWeaponSelected, this._playerWeaponService.GetAvailableSkins(this._currentWeaponSelected), this._currentSkin);
			}
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x0004DADC File Offset: 0x0004BCDC
		public void DispatchWeaponClick(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			if (weapon.PlayerItem.ItemId != this._currentWeaponSelected.PlayerItem.ItemId)
			{
				Singleton<UIEventSystem>.Instance.DispatchEvent("stats_skins", new object[] { true });
			}
			this._soldiersService.DispatchWeaponClick(weapon, loadout);
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x0000AC87 File Offset: 0x00008E87
		public void DispatchWeaponPreview(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			this._soldiersService.DispatchWeaponPreview(weapon, loadout);
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x0000AC96 File Offset: 0x00008E96
		public void DispatchWeaponSelected()
		{
			this._soldiersService.DispatchWeaponSelected(this._currentWeaponSelected);
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x0000ACA9 File Offset: 0x00008EA9
		public void DispatchWeaponSkinSelected(PlayerWeaponData weapon, WeaponSkin skin)
		{
			this._soldiersService.DispatchWeaponSkinChanged(weapon, skin);
		}

		// Token: 0x04000FB1 RID: 4017
		private readonly SoldiersService _soldiersService;

		// Token: 0x04000FB2 RID: 4018
		private readonly PlayerWeaponService _playerWeaponService;

		// Token: 0x04000FB3 RID: 4019
		private PlayerWeaponData _currentWeaponSelected;

		// Token: 0x04000FB4 RID: 4020
		private EHeroItemSlot _currentSlot;

		// Token: 0x04000FB5 RID: 4021
		private EWeaponSkinName _currentSkin;

		// Token: 0x04000FB6 RID: 4022
		private float _lastWeaponSelectedTimestamp;

		// Token: 0x04000FB7 RID: 4023
		private HighSpeedArray<WeaponV4> _allWeapons;

		// Token: 0x04000FB8 RID: 4024
		private HighSpeedArray<PlayerWeaponData> _avaliableWeapons;
	}
}
