﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200029B RID: 667
	internal class CapturePointScreenIndicator : BaseScreenIndicator
	{
		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000E39 RID: 3641 RVA: 0x0000B9ED File Offset: 0x00009BED
		public string PointName
		{
			get
			{
				return (!(this.IndicatorComponent != null)) ? null : this.IndicatorComponent.PointName;
			}
		}

		// Token: 0x06000E3A RID: 3642 RVA: 0x0000BA11 File Offset: 0x00009C11
		public void UpdateMarker(Vector3 worldPosition, UITeam ownerTeam, UITeam capturingTeam, float captureAmount)
		{
			base.UpdateMarkerPosition(worldPosition);
			this.IndicatorComponent.SetInfo(ownerTeam, capturingTeam, captureAmount);
		}

		// Token: 0x04001212 RID: 4626
		public GameplayScreenIndicatorCapturePointComponent IndicatorComponent;
	}
}
