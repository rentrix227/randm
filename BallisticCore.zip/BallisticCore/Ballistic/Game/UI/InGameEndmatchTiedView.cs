﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002B3 RID: 691
	public class InGameEndmatchTiedView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000E96 RID: 3734 RVA: 0x0000BE1A File Offset: 0x0000A01A
		internal void SetData(EClientMode clientMode)
		{
			this.MatchStatusText.text = ServiceProvider.GetService<LocalizationService>().Get((clientMode != EClientMode.PLAYER) ? "team_endgame_status_3" : "team_endgame_status_1", ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x0400136E RID: 4974
		public Text MatchStatusText;
	}
}
