﻿using System;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200023B RID: 571
	internal struct InventorySearchFilters
	{
		// Token: 0x04000F3F RID: 3903
		internal string Name;

		// Token: 0x04000F40 RID: 3904
		internal EHeroClass Class;

		// Token: 0x04000F41 RID: 3905
		internal ERarity Rarity;

		// Token: 0x04000F42 RID: 3906
		internal EnumBitMask<EWeaponCategory> Category;
	}
}
