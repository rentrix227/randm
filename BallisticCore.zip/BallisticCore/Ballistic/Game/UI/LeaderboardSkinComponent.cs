﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001EC RID: 492
	public class LeaderboardSkinComponent : PoolableComponent
	{
		// Token: 0x060009E6 RID: 2534 RVA: 0x0003AD80 File Offset: 0x00038F80
		internal void SetInfo(LeaderboardEntry info)
		{
			if (this.You != null)
			{
				this.You.SetActive(SteamUser.GetSteamID().m_SteamID == info.SteamId.m_SteamID);
			}
			this._steamId = info.SteamId.m_SteamID;
			int skillRatingTierNumber = RatingUtil.GetSkillRatingTierNumber((float)info.ScoreLegendary + (float)info.ScoreElite + (float)info.ScoreSpecial + (float)info.ScoreAdvanced + (float)info.ScoreCommon);
			this.PlayerName.text = info.Name;
			this.PlayerTierBadge.sprite = this.PlayerBadgeSprites[skillRatingTierNumber];
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(info.SteamId, new Action<ulong, Texture2D>(this.OnImageLoaded), true);
			this.GlobalPosition.text = info.Position.ToString();
			this.LegendarySkins.text = info.ScoreLegendary.ToString();
			this.EliteSkins.text = info.ScoreElite.ToString();
			this.SpecialSkins.text = info.ScoreSpecial.ToString();
			this.AdvancedSkins.text = info.ScoreAdvanced.ToString();
			this.CommonSkins.text = info.ScoreCommon.ToString();
			this.TotalSkins.text = (info.ScoreLegendary + info.ScoreElite + info.ScoreSpecial + info.ScoreAdvanced + info.ScoreCommon).ToString();
		}

		// Token: 0x060009E7 RID: 2535 RVA: 0x00008F27 File Offset: 0x00007127
		private void OnImageLoaded(ulong steamId, Texture2D texture)
		{
			if (steamId == this._steamId)
			{
				this.PlayerAvatar.texture = texture;
			}
		}

		// Token: 0x04000D41 RID: 3393
		public GameObject You;

		// Token: 0x04000D42 RID: 3394
		public Text PlayerName;

		// Token: 0x04000D43 RID: 3395
		public RawImage PlayerAvatar;

		// Token: 0x04000D44 RID: 3396
		public Image PlayerTierBadge;

		// Token: 0x04000D45 RID: 3397
		public Text GlobalPosition;

		// Token: 0x04000D46 RID: 3398
		public Text LegendarySkins;

		// Token: 0x04000D47 RID: 3399
		public Text EliteSkins;

		// Token: 0x04000D48 RID: 3400
		public Text SpecialSkins;

		// Token: 0x04000D49 RID: 3401
		public Text AdvancedSkins;

		// Token: 0x04000D4A RID: 3402
		public Text CommonSkins;

		// Token: 0x04000D4B RID: 3403
		public Text TotalSkins;

		// Token: 0x04000D4C RID: 3404
		public Sprite[] PlayerBadgeSprites;

		// Token: 0x04000D4D RID: 3405
		private ulong _steamId;
	}
}
