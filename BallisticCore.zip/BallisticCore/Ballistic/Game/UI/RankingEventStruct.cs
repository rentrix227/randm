﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002AE RID: 686
	[Serializable]
	internal class RankingEventStruct
	{
		// Token: 0x0400132A RID: 4906
		internal RankingEventStruct.EventStructType Type;

		// Token: 0x0400132B RID: 4907
		internal float StartTime;

		// Token: 0x0400132C RID: 4908
		internal float Duration;

		// Token: 0x0400132D RID: 4909
		internal bool Once;

		// Token: 0x0400132E RID: 4910
		public float IntFrom;

		// Token: 0x0400132F RID: 4911
		public float IntTo;

		// Token: 0x04001330 RID: 4912
		public float FloatTo;

		// Token: 0x04001331 RID: 4913
		public float FloatFrom;

		// Token: 0x04001332 RID: 4914
		public bool BoolFrom;

		// Token: 0x04001333 RID: 4915
		public bool BoolTo;

		// Token: 0x04001334 RID: 4916
		public Text PlacementsModeText;

		// Token: 0x04001335 RID: 4917
		public Image PlacementsModeFillbar;

		// Token: 0x04001336 RID: 4918
		public Animator PlacementsModeAnimator;

		// Token: 0x04001337 RID: 4919
		public Animator RankedAnimator;

		// Token: 0x04001338 RID: 4920
		public Text RankedText;

		// Token: 0x04001339 RID: 4921
		public int RankFrom;

		// Token: 0x0400133A RID: 4922
		public int RankTo;

		// Token: 0x0400133B RID: 4923
		public int OldLimiarDown;

		// Token: 0x0400133C RID: 4924
		public int OldLimiarUp;

		// Token: 0x0400133D RID: 4925
		public int NewLimiarDown;

		// Token: 0x0400133E RID: 4926
		public int NewLimiarUp;

		// Token: 0x020002AF RID: 687
		internal enum EventStructType
		{
			// Token: 0x04001340 RID: 4928
			PLACEMENTS_IN,
			// Token: 0x04001341 RID: 4929
			PLACEMENTS_MATCHS,
			// Token: 0x04001342 RID: 4930
			PLACEMENTS_MODE,
			// Token: 0x04001343 RID: 4931
			PLACEMENTS_MATCHS_COMPLETED,
			// Token: 0x04001344 RID: 4932
			PLACEMENTS_MODE_COMPLETED,
			// Token: 0x04001345 RID: 4933
			PLACEMENTS_ALLMODE_COMPLETED,
			// Token: 0x04001346 RID: 4934
			PLACEMENTS_RANKED_NOW,
			// Token: 0x04001347 RID: 4935
			PLACEMENTS_MATCH_INVALID,
			// Token: 0x04001348 RID: 4936
			RANKING_DISTRIBUTE,
			// Token: 0x04001349 RID: 4937
			RANKING_INCREASED,
			// Token: 0x0400134A RID: 4938
			RANKING_MATCH_INVALID,
			// Token: 0x0400134B RID: 4939
			RANKING_BADGE,
			// Token: 0x0400134C RID: 4940
			RANKING_DISTRIBUTE_IN
		}
	}
}
