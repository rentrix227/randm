﻿using System;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002BE RID: 702
	public class InGameKillcamQueueView : BaseView<InGameKillcamController>
	{
		// Token: 0x06000EBE RID: 3774 RVA: 0x00058FF0 File Offset: 0x000571F0
		internal void SetData(EGameMode gameMode, Team team, ETeamMode teamMode, QueueState queueState, int playerCount, int maxPlayerCount, int playerIndex)
		{
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				this.FFARoot.SetActive(false);
				this.TeamRoot.SetActive(true);
				this.TeamSpecificRoot.SetActive(teamMode != ETeamMode.ANY && teamMode != ETeamMode.SPECTATE);
				this.TeamAnyRoot.SetActive(teamMode == ETeamMode.ANY);
				if (teamMode == ETeamMode.MFA)
				{
					this.TeamName.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(Team.MFA, ELocalizedTextCase.UPPER_CASE);
				}
				if (teamMode == ETeamMode.SMOKE)
				{
					this.TeamName.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(Team.SMOKE, ELocalizedTextCase.UPPER_CASE);
				}
				this.TeamSize.text = playerCount.ToString() + "/" + maxPlayerCount.ToString();
				if (team != Team.NONE)
				{
					this.QueueTeamLogo.sprite = this.TeamLogos[(int)team];
				}
			}
			else
			{
				this.FFARoot.SetActive(true);
				this.TeamRoot.SetActive(false);
				this.TeamSpecificRoot.SetActive(false);
				this.TeamAnyRoot.SetActive(false);
				this.FFAMatchSize.text = playerCount + "/" + maxPlayerCount;
			}
			this.RebalanceRoot.SetActive(queueState == QueueState.REBALANCE && playerIndex > 1);
			this.QueuePositionRoot.SetActive(queueState == QueueState.FULL && playerIndex > 1);
			this.YouAreNextRoot.SetActive(playerIndex == 1);
			if (playerIndex > 1)
			{
				this.QueueStateText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("queue_position", ELocalizedTextCase.NONE), playerIndex);
				this.RebalanceStateText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("rebalance_position", ELocalizedTextCase.NONE), playerIndex);
			}
		}

		// Token: 0x0400139A RID: 5018
		[Header("Team")]
		public GameObject TeamRoot;

		// Token: 0x0400139B RID: 5019
		public GameObject TeamSpecificRoot;

		// Token: 0x0400139C RID: 5020
		public GameObject TeamAnyRoot;

		// Token: 0x0400139D RID: 5021
		public Text TeamName;

		// Token: 0x0400139E RID: 5022
		public Text TeamSize;

		// Token: 0x0400139F RID: 5023
		public Image QueueTeamLogo;

		// Token: 0x040013A0 RID: 5024
		[Header("FFA")]
		public GameObject FFARoot;

		// Token: 0x040013A1 RID: 5025
		public Text FFAMatchSize;

		// Token: 0x040013A2 RID: 5026
		[Header("Queue")]
		public GameObject QueuePositionRoot;

		// Token: 0x040013A3 RID: 5027
		public Text QueueStateText;

		// Token: 0x040013A4 RID: 5028
		public GameObject RebalanceRoot;

		// Token: 0x040013A5 RID: 5029
		public Text RebalanceStateText;

		// Token: 0x040013A6 RID: 5030
		public GameObject YouAreNextRoot;

		// Token: 0x040013A7 RID: 5031
		public Sprite[] TeamLogos;
	}
}
