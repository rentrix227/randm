﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Reward;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000243 RID: 579
	public class MainController : BaseController
	{
		// Token: 0x06000C26 RID: 3110 RVA: 0x0004A1E0 File Offset: 0x000483E0
		public MainController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._gameItemService = ServiceProvider.GetService<GameItemService>();
			this._inventoryService = ServiceProvider.GetService<InventoryService>();
			this._soldiersService = ServiceProvider.GetService<SoldiersService>();
			this._leaderboardService = ServiceProvider.GetService<LeaderboardService>();
			this._soldiersService.OnSoldierChanged += this.OnSoldierChanged;
			this._playerName = ((!string.IsNullOrEmpty(File.ReadAllText(Application.dataPath + "/NameTag.txt").Trim())) ? File.ReadAllText(Application.dataPath + "/NameTag.txt") : SteamFriends.GetPersonaName());
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(SteamUser.GetSteamID(), new Action<ulong, Texture2D>(this.OnLoadAvatar), true);
			ServiceProvider.GetService<StatisticsService>().RequestCurrentStats(new Action<StatisticsGeneralData>(this.OnRequestUserDataSucess));
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange += this.OnLanguageChange;
			ServiceProvider.GetService<SceneService>().OnSceneLoaded += this.OnSceneLoaded;
		}

		// Token: 0x06000C27 RID: 3111 RVA: 0x0000A473 File Offset: 0x00008673
		private void OnSceneLoaded(EBaseScene evt)
		{
			if (evt == EBaseScene.Main)
			{
				this.CheckRewards();
			}
		}

		// Token: 0x06000C28 RID: 3112 RVA: 0x0000A47F File Offset: 0x0000867F
		internal void CheckRewards()
		{
			ServiceProvider.GetService<EventProxy>().StartCoroutine(this.CheckWithDelay());
		}

		// Token: 0x06000C29 RID: 3113 RVA: 0x0000A492 File Offset: 0x00008692
		private IEnumerator CheckWithDelay()
		{
			yield return new WaitForSeconds(1f);
			if (this._inventoryService.GetCachedRewards().Count > 0)
			{
				if (this._inventoryService.GetCachedRewards().Any((SteamItem t) => (t.IdentityId >= 3000 && t.IdentityId <= 3100) || (t.IdentityId > 3310 && t.IdentityId <= 3325)))
				{
					UIManager.Instance.ChangeState("UNLOCKED_REWARD_MONTLY");
				}
				else
				{
					UIManager.Instance.ChangeState("UNLOCKED_REWARD_WEEKLY");
				}
			}
			yield break;
		}

		// Token: 0x06000C2A RID: 3114 RVA: 0x0000A4A1 File Offset: 0x000086A1
		private void OnLoadAvatar(ulong steamId, Texture2D texture)
		{
			this._playerAvatar = texture;
		}

		// Token: 0x06000C2B RID: 3115 RVA: 0x0000A4AA File Offset: 0x000086AA
		private void OnRequestUserDataSucess(StatisticsGeneralData statisticsGeneralData)
		{
			this._statisticsGeneral = statisticsGeneralData;
		}

		// Token: 0x06000C2C RID: 3116 RVA: 0x0004A2E0 File Offset: 0x000484E0
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			MainBackgroundView mainBackgroundView = view as MainBackgroundView;
			if (mainBackgroundView != null)
			{
				mainBackgroundView.SetStartHeroBackground(this._soldiersService.GetCurrentClass());
			}
			MainPlayerNameView mainPlayerNameView = view as MainPlayerNameView;
			if (mainPlayerNameView != null)
			{
				mainPlayerNameView.SetData(this._playerName, this._playerAvatar, ServiceProvider.GetService<ProgressionService>().GetAllHeroLevel());
			}
			MainPlayerStatsView mainPlayerStatsView = view as MainPlayerStatsView;
			if (mainPlayerStatsView != null)
			{
				this.ViewGeneralStatistics(mainPlayerStatsView);
			}
			MainRewardWeeklyView mainRewardWeeklyView = view as MainRewardWeeklyView;
			if (mainRewardWeeklyView != null)
			{
				IEnumerable<Reward> rewards2 = this._gameItemService.GetItemsOfType<Reward>();
				mainRewardWeeklyView.SetData(from t in this._inventoryService.GetCachedRewards()
					where t.IdentityId > 3100 && t.IdentityId <= 3310
					select new RewardPackData
					{
						reward = rewards2.FirstOrDefault((Reward r) => r.GetRewardId() == t.IdentityId),
						steamItem = t
					});
			}
			MainRewardMonthlyView mainRewardMonthlyView = view as MainRewardMonthlyView;
			if (mainRewardMonthlyView != null)
			{
				IEnumerable<Reward> rewards = this._gameItemService.GetItemsOfType<Reward>();
				mainRewardMonthlyView.SetData(from t in this._inventoryService.GetCachedRewards()
					where (t.IdentityId >= 3000 && t.IdentityId <= 3100) || (t.IdentityId > 3310 && t.IdentityId <= 3325)
					select new RewardPackData
					{
						reward = rewards.FirstOrDefault((Reward r) => r.GetRewardId() == t.IdentityId),
						steamItem = t
					});
			}
			MainReleaseNotesView mainReleaseNotesView = view as MainReleaseNotesView;
			if (mainReleaseNotesView != null)
			{
				mainReleaseNotesView.QueryData();
			}
		}

		// Token: 0x06000C2D RID: 3117 RVA: 0x0004A45C File Offset: 0x0004865C
		private void OnSoldierChanged(EHeroClass eHeroClass)
		{
			MainBackgroundView view = base.GetView<MainBackgroundView>();
			if (view)
			{
				view.SetHeroBackground(this._soldiersService.GetCurrentClass());
			}
		}

		// Token: 0x06000C2E RID: 3118 RVA: 0x0004A48C File Offset: 0x0004868C
		private void OnLanguageChange()
		{
			MainBackgroundView view = base.GetView<MainBackgroundView>();
			if (view != null)
			{
				view.SetStartHeroBackground(this._soldiersService.GetCurrentClass());
			}
			MainPlayerNameView view2 = base.GetView<MainPlayerNameView>();
			if (view2 != null)
			{
				view2.SetData(this._playerName, this._playerAvatar, ServiceProvider.GetService<ProgressionService>().GetAllHeroLevel());
			}
			MainPlayerStatsView view3 = base.GetView<MainPlayerStatsView>();
			if (view3 != null)
			{
				this.ViewGeneralStatistics(view3);
			}
		}

		// Token: 0x06000C2F RID: 3119 RVA: 0x0000A4B3 File Offset: 0x000086B3
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldiersService.OnSoldierChanged -= this.OnSoldierChanged;
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange -= this.OnLanguageChange;
		}

		// Token: 0x06000C30 RID: 3120 RVA: 0x0004A500 File Offset: 0x00048700
		public void ViewGeneralStatistics(MainPlayerStatsView view)
		{
			if (this._statisticsGeneral == null)
			{
				return;
			}
			view.SetClass(EHeroClass.NONE);
			view.SetWinsAndLoses(this._statisticsGeneral.GetStatistic(EGeneralStatistic.WINS), this._statisticsGeneral.GetStatistic(EGeneralStatistic.LOSES));
			view.SetKillsAndDeaths(this._statisticsGeneral.Kills, this._statisticsGeneral.Deaths);
			view.SetAssists(this._statisticsGeneral.Assists);
			view.SetMatchs(this._statisticsGeneral.Matchs);
			view.SetWinLoseRatio(this._statisticsGeneral.WinLoseRatio);
			view.SetKillDeathRatio(this._statisticsGeneral.KillDeathRatio);
			view.SetKillRatio(this._statisticsGeneral.KillRatio);
			view.SetHeadshots(this._statisticsGeneral.Headshots);
		}

		// Token: 0x06000C31 RID: 3121 RVA: 0x0004A5C0 File Offset: 0x000487C0
		public void ViewHeroStatistic(MainPlayerStatsView view, EHeroClass hero)
		{
			if (this._statisticsGeneral == null)
			{
				return;
			}
			view.SetWinsAndLoses(this._statisticsGeneral.GetStatistic(EGeneralStatistic.WINS), this._statisticsGeneral.GetStatistic(EGeneralStatistic.LOSES));
			view.SetWinLoseRatio(this._statisticsGeneral.WinLoseRatio);
			view.SetMatchs(this._statisticsGeneral.Matchs);
			view.SetClass(hero);
			view.SetKillsAndDeaths(this._statisticsGeneral.HeroUserDatas[hero].Kills, this._statisticsGeneral.HeroUserDatas[hero].Deaths);
			view.SetAssists(this._statisticsGeneral.HeroUserDatas[hero].Assists);
			view.SetKillDeathRatio(this._statisticsGeneral.HeroUserDatas[hero].KillDeathRatio);
			view.SetKillRatio(this._statisticsGeneral.HeroUserDatas[hero].KillRatio);
			view.SetHeadshots(this._statisticsGeneral.HeroUserDatas[hero].Headshots);
		}

		// Token: 0x06000C32 RID: 3122 RVA: 0x0000A4F0 File Offset: 0x000086F0
		internal void ClaimReward(RewardPackData rewardData, Action<bool, SteamItem[]> OnExchangeResponse)
		{
			this._inventoryService.ExchangeRewards(rewardData.steamItem, rewardData.reward, OnExchangeResponse);
		}

		// Token: 0x04000F59 RID: 3929
		private readonly SoldiersService _soldiersService;

		// Token: 0x04000F5A RID: 3930
		private readonly InventoryService _inventoryService;

		// Token: 0x04000F5B RID: 3931
		private GameItemService _gameItemService;

		// Token: 0x04000F5C RID: 3932
		private readonly string _playerName;

		// Token: 0x04000F5D RID: 3933
		private Texture2D _playerAvatar;

		// Token: 0x04000F5E RID: 3934
		private StatisticsGeneralData _statisticsGeneral;

		// Token: 0x04000F5F RID: 3935
		private LeaderboardService _leaderboardService;
	}
}
