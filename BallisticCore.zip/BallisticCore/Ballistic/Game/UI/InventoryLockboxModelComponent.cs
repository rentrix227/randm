﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001DB RID: 475
	public class InventoryLockboxModelComponent : MonoBehaviour
	{
		// Token: 0x060009B8 RID: 2488 RVA: 0x0003A4B0 File Offset: 0x000386B0
		internal void SetData(WeaponSkinData skinData)
		{
			foreach (InventoryLockboxModelComponent.RarityComponent rarityComponent in this.RarityComponents)
			{
				if (rarityComponent.Rarity == skinData.WeaponSkin.Rarity)
				{
					rarityComponent.Root.SetActive(true);
					string weaponIconPath = TextureHelper.GetWeaponIconPath(skinData.Weapon.ItemModel, EImageSize.LARGE, skinData.WeaponSkin.WeaponSkinName.ToString().ToLowerInvariant());
					TextureHelper.LoadImageAsync(weaponIconPath, rarityComponent.Mesh, EImageSource.METADATA);
				}
				else
				{
					rarityComponent.Root.SetActive(false);
				}
			}
		}

		// Token: 0x04000D01 RID: 3329
		public InventoryLockboxModelComponent.RarityComponent[] RarityComponents;

		// Token: 0x020001DC RID: 476
		[Serializable]
		public struct RarityComponent
		{
			// Token: 0x04000D02 RID: 3330
			public GameObject Root;

			// Token: 0x04000D03 RID: 3331
			public Renderer Mesh;

			// Token: 0x04000D04 RID: 3332
			public ERarity Rarity;
		}
	}
}
