﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D0 RID: 464
	public class GameplayScreenIndicatorDamageRootComponent : MonoBehaviour
	{
		// Token: 0x06000996 RID: 2454 RVA: 0x00008A56 File Offset: 0x00006C56
		public void Awake()
		{
			this.LowDamageTemplate.gameObject.SetActive(false);
			this.MediumDamageTemplate.gameObject.SetActive(false);
			this.HighDamageTemplate.gameObject.SetActive(false);
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x00039D30 File Offset: 0x00037F30
		public void SpawnDamage(float damage, DamageAmount amount)
		{
			if (damage < 1f)
			{
				return;
			}
			GameplayScreenIndicatorDamageElementComponent gameplayScreenIndicatorDamageElementComponent = null;
			if (amount != DamageAmount.Low)
			{
				if (amount != DamageAmount.Medium)
				{
					if (amount == DamageAmount.High)
					{
						gameplayScreenIndicatorDamageElementComponent = this.HighDamageTemplate;
					}
				}
				else
				{
					gameplayScreenIndicatorDamageElementComponent = this.MediumDamageTemplate;
				}
			}
			else
			{
				gameplayScreenIndicatorDamageElementComponent = this.LowDamageTemplate;
			}
			GameplayScreenIndicatorDamageElementComponent gameplayScreenIndicatorDamageElementComponent2 = Object.Instantiate<GameplayScreenIndicatorDamageElementComponent>(gameplayScreenIndicatorDamageElementComponent, gameplayScreenIndicatorDamageElementComponent.transform.parent);
			gameplayScreenIndicatorDamageElementComponent2.SetDamageAmount(Mathf.RoundToInt(damage));
			gameplayScreenIndicatorDamageElementComponent2.gameObject.SetActive(true);
			Object.Destroy(gameplayScreenIndicatorDamageElementComponent2.gameObject, gameplayScreenIndicatorDamageElementComponent2.TimeToDestroy);
		}

		// Token: 0x04000CBC RID: 3260
		public GameplayScreenIndicatorDamageElementComponent LowDamageTemplate;

		// Token: 0x04000CBD RID: 3261
		public GameplayScreenIndicatorDamageElementComponent MediumDamageTemplate;

		// Token: 0x04000CBE RID: 3262
		public GameplayScreenIndicatorDamageElementComponent HighDamageTemplate;
	}
}
