﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002CB RID: 715
	public class InGameSpectatorCountView : BaseView<InGameMatchTimeController>
	{
		// Token: 0x06000EFB RID: 3835 RVA: 0x0000C35F File Offset: 0x0000A55F
		internal void SetData(int spectatorCount)
		{
			this.SpectatorCountText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("spectator_in_match", ELocalizedTextCase.NONE), spectatorCount);
		}

		// Token: 0x0400141E RID: 5150
		public Text SpectatorCountText;
	}
}
