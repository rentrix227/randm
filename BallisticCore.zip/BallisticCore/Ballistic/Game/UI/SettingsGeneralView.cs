﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200030B RID: 779
	public class SettingsGeneralView : BaseView<SettingsController>
	{
		// Token: 0x06001042 RID: 4162 RVA: 0x0005F4BC File Offset: 0x0005D6BC
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.LanguageDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnLanguageValueChanged));
			this.InGameChatToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnInGameChatValueChanged));
			if (this.ResetLoadoutsButton != null)
			{
				this.ResetLoadoutsButton.onClick.AddListener(new UnityAction(this.OnResetLoadouts));
			}
			if (this.ResetStatisticsButton != null)
			{
				this.ResetStatisticsButton.onClick.AddListener(new UnityAction(this.OnResetStatistics));
			}
			this.MusicSlider.onValueChanged.AddListener(new UnityAction<float>(this.OnMusicValueChanged));
			this.MusicMinusButton.onClick.AddListener(new UnityAction(this.OnMusicMinusClick));
			this.MusicPlusButton.onClick.AddListener(new UnityAction(this.OnMusicPlusClick));
			this.SfxSlider.onValueChanged.AddListener(new UnityAction<float>(this.OnSfxValueChanged));
			this.SfxMinusButton.onClick.AddListener(new UnityAction(this.OnSfxMinusClick));
			this.SfxPlusButton.onClick.AddListener(new UnityAction(this.OnSfxPlusClick));
			this.VoiceSlider.onValueChanged.AddListener(new UnityAction<float>(this.OnVoiceValueChanged));
			this.VoiceMinusButton.onClick.AddListener(new UnityAction(this.OnVoiceMinusClick));
			this.VoicePlusButton.onClick.AddListener(new UnityAction(this.OnVoicePlusClick));
			this.NetworkNorthAmericaEast.onValueChanged.AddListener(new UnityAction<bool>(this.OnNetworkNorthAmericaEastChanged));
			this.NetworkNorthAmericaWest.onValueChanged.AddListener(new UnityAction<bool>(this.OnNetworkNorthAmericaWestChanged));
			this.NetworkSouthAmerica.onValueChanged.AddListener(new UnityAction<bool>(this.OnNetworkSouthAmericaChanged));
			this.NetworkEurope.onValueChanged.AddListener(new UnityAction<bool>(this.OnNetworkEuropeChanged));
			this.NetworkAsia.onValueChanged.AddListener(new UnityAction<bool>(this.OnNetworkAsiaChanged));
			this.NetworkChina.onValueChanged.AddListener(new UnityAction<bool>(this.OnNetworkChinaChanged));
			this.NetworkDedicated.onValueChanged.AddListener(new UnityAction<bool>(this.OnNetworkDedicatedChanged));
		}

		// Token: 0x06001043 RID: 4163 RVA: 0x0000D6A0 File Offset: 0x0000B8A0
		internal void SetLanguageDropdownValues(string[] values, string defaultValue)
		{
			this.LanguageDropdown.options.Clear();
			Array.ForEach<string>(values, delegate(string v)
			{
				this.LanguageDropdown.options.Add(new Dropdown.OptionData(v));
			});
			this.LanguageDropdown.value = Array.IndexOf<string>(values, defaultValue);
		}

		// Token: 0x06001044 RID: 4164 RVA: 0x0000D6D6 File Offset: 0x0000B8D6
		internal void SetInGameChatToggle(bool value)
		{
			this.InGameChatToggle.isOn = value;
		}

		// Token: 0x06001045 RID: 4165 RVA: 0x0005F72C File Offset: 0x0005D92C
		internal void SetMusicVolume(float value)
		{
			this.MusicText.text = ((int)(value * 100f)).ToString();
			this.MusicSlider.value = value;
		}

		// Token: 0x06001046 RID: 4166 RVA: 0x0005F768 File Offset: 0x0005D968
		internal void SetSfxVolume(float value)
		{
			this.SfxText.text = ((int)(value * 100f)).ToString();
			this.SfxSlider.value = value;
		}

		// Token: 0x06001047 RID: 4167 RVA: 0x0005F7A4 File Offset: 0x0005D9A4
		internal void SetVoiceVolume(float value)
		{
			this.VoiceText.text = ((int)(value * 100f)).ToString();
			this.VoiceSlider.value = value;
		}

		// Token: 0x06001048 RID: 4168 RVA: 0x0000D6E4 File Offset: 0x0000B8E4
		internal void SetQNetworkNorthAmericaEast(bool value)
		{
			this.NetworkNorthAmericaEast.isOn = value;
		}

		// Token: 0x06001049 RID: 4169 RVA: 0x0000D6F2 File Offset: 0x0000B8F2
		internal void SetQNetworkNorthAmericaWest(bool value)
		{
			this.NetworkNorthAmericaWest.isOn = value;
		}

		// Token: 0x0600104A RID: 4170 RVA: 0x0000D700 File Offset: 0x0000B900
		internal void SetQNetworkSouthAmerica(bool value)
		{
			this.NetworkSouthAmerica.isOn = value;
		}

		// Token: 0x0600104B RID: 4171 RVA: 0x0000D70E File Offset: 0x0000B90E
		internal void SetQNetworkEurope(bool value)
		{
			this.NetworkEurope.isOn = value;
		}

		// Token: 0x0600104C RID: 4172 RVA: 0x0000D71C File Offset: 0x0000B91C
		internal void SetQNetworkAsia(bool value)
		{
			this.NetworkAsia.isOn = value;
		}

		// Token: 0x0600104D RID: 4173 RVA: 0x0000D72A File Offset: 0x0000B92A
		internal void SetQNetworkChina(bool value)
		{
			this.NetworkChina.isOn = value;
		}

		// Token: 0x0600104E RID: 4174 RVA: 0x0000D738 File Offset: 0x0000B938
		internal void SetQNetworkDedicated(bool value)
		{
			this.NetworkDedicated.isOn = value;
		}

		// Token: 0x0600104F RID: 4175 RVA: 0x0000D746 File Offset: 0x0000B946
		private void OnQualityValueChanged(int newValue)
		{
			base._controller.SetQuality(newValue);
		}

		// Token: 0x06001050 RID: 4176 RVA: 0x0000D754 File Offset: 0x0000B954
		private void OnResolutionValueChanged(int newValue)
		{
			base._controller.SetResolution(newValue);
		}

		// Token: 0x06001051 RID: 4177 RVA: 0x0000D762 File Offset: 0x0000B962
		private void OnAliasingValueChanged(int newValue)
		{
			base._controller.SetAliasing(newValue);
		}

		// Token: 0x06001052 RID: 4178 RVA: 0x0000D770 File Offset: 0x0000B970
		private void OnFullScreenValueChanged(bool value)
		{
			base._controller.SetFullScreen(value);
		}

		// Token: 0x06001053 RID: 4179 RVA: 0x0000D77E File Offset: 0x0000B97E
		private void OnVSyncValueChanged(bool value)
		{
			base._controller.SetVSync(value);
		}

		// Token: 0x06001054 RID: 4180 RVA: 0x0000D78C File Offset: 0x0000B98C
		private void OnBlurValueChanged(bool value)
		{
			base._controller.SetBlur(value);
		}

		// Token: 0x06001055 RID: 4181 RVA: 0x0000D79A File Offset: 0x0000B99A
		private void OnLanguageValueChanged(int value)
		{
			base._controller.SetLanguage(value);
		}

		// Token: 0x06001056 RID: 4182 RVA: 0x0000D7A8 File Offset: 0x0000B9A8
		private void OnInGameChatValueChanged(bool value)
		{
			base._controller.SetInGameChat(value);
		}

		// Token: 0x06001057 RID: 4183 RVA: 0x0000D7B6 File Offset: 0x0000B9B6
		private void OnResetLoadouts()
		{
			base._controller.OnDefaultLoadout();
		}

		// Token: 0x06001058 RID: 4184 RVA: 0x0000D7C3 File Offset: 0x0000B9C3
		private void OnResetStatistics()
		{
			base._controller.OnDefaultStatistics();
		}

		// Token: 0x06001059 RID: 4185 RVA: 0x0000D7D0 File Offset: 0x0000B9D0
		private void OnMusicValueChanged(float value)
		{
			this.UpdateMusicLabel(value);
			base._controller.SetMusicVolume(value);
		}

		// Token: 0x0600105A RID: 4186 RVA: 0x0000D7E5 File Offset: 0x0000B9E5
		private void OnSfxValueChanged(float value)
		{
			this.UpdateSfxLabel(value);
			base._controller.SetAudioVolume(value);
		}

		// Token: 0x0600105B RID: 4187 RVA: 0x0000D7FA File Offset: 0x0000B9FA
		private void OnVoiceValueChanged(float value)
		{
			this.UpdateVoiceLabel(value);
			base._controller.SetVoiceVolume(value);
		}

		// Token: 0x0600105C RID: 4188 RVA: 0x0005F7E0 File Offset: 0x0005D9E0
		private void OnMusicPlusClick()
		{
			float num = this.MusicSlider.value + 0.1f;
			if (num > 1f)
			{
				num = 1f;
			}
			this.SetMusicVolume(num);
		}

		// Token: 0x0600105D RID: 4189 RVA: 0x0005F818 File Offset: 0x0005DA18
		private void OnMusicMinusClick()
		{
			float num = this.MusicSlider.value - 0.1f;
			if (num < 0f)
			{
				num = 0f;
			}
			this.SetMusicVolume(num);
		}

		// Token: 0x0600105E RID: 4190 RVA: 0x0005F850 File Offset: 0x0005DA50
		private void OnSfxPlusClick()
		{
			float num = this.SfxSlider.value + 0.1f;
			if (num > 1f)
			{
				num = 1f;
			}
			this.SetSfxVolume(num);
		}

		// Token: 0x0600105F RID: 4191 RVA: 0x0005F888 File Offset: 0x0005DA88
		private void OnSfxMinusClick()
		{
			float num = this.SfxSlider.value - 0.1f;
			if (num < 0f)
			{
				num = 0f;
			}
			this.SetSfxVolume(num);
		}

		// Token: 0x06001060 RID: 4192 RVA: 0x0005F8C0 File Offset: 0x0005DAC0
		private void OnVoicePlusClick()
		{
			float num = this.VoiceSlider.value + 0.1f;
			if (num > 1f)
			{
				num = 1f;
			}
			this.SetVoiceVolume(num);
		}

		// Token: 0x06001061 RID: 4193 RVA: 0x0005F8F8 File Offset: 0x0005DAF8
		private void OnVoiceMinusClick()
		{
			float num = this.VoiceSlider.value - 0.1f;
			if (num < 0f)
			{
				num = 0f;
			}
			this.SetVoiceVolume(num);
		}

		// Token: 0x06001062 RID: 4194 RVA: 0x0000D80F File Offset: 0x0000BA0F
		private void OnNetworkChinaChanged(bool value)
		{
			base._controller.SetNetworkChina(value);
		}

		// Token: 0x06001063 RID: 4195 RVA: 0x0000D81D File Offset: 0x0000BA1D
		private void OnNetworkDedicatedChanged(bool value)
		{
			base._controller.SetNetworkDedicated(value);
		}

		// Token: 0x06001064 RID: 4196 RVA: 0x0000D82B File Offset: 0x0000BA2B
		private void OnNetworkAsiaChanged(bool value)
		{
			base._controller.SetNetworkAsia(value);
		}

		// Token: 0x06001065 RID: 4197 RVA: 0x0000D839 File Offset: 0x0000BA39
		private void OnNetworkEuropeChanged(bool value)
		{
			base._controller.SetNetworkEurope(value);
		}

		// Token: 0x06001066 RID: 4198 RVA: 0x0000D847 File Offset: 0x0000BA47
		private void OnNetworkSouthAmericaChanged(bool value)
		{
			base._controller.SetNetworkSouthAmerica(value);
		}

		// Token: 0x06001067 RID: 4199 RVA: 0x0000D855 File Offset: 0x0000BA55
		private void OnNetworkNorthAmericaWestChanged(bool value)
		{
			base._controller.SetNetworkNorthAmericaWest(value);
		}

		// Token: 0x06001068 RID: 4200 RVA: 0x0000D863 File Offset: 0x0000BA63
		private void OnNetworkNorthAmericaEastChanged(bool value)
		{
			base._controller.SetNetworkNorthAmericaEast(value);
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x0005F930 File Offset: 0x0005DB30
		private void UpdateMusicLabel(float value)
		{
			this.MusicText.text = ((int)(value * 100f)).ToString();
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x0005F960 File Offset: 0x0005DB60
		private void UpdateSfxLabel(float value)
		{
			this.SfxText.text = ((int)(value * 100f)).ToString();
		}

		// Token: 0x0600106B RID: 4203 RVA: 0x0005F990 File Offset: 0x0005DB90
		private void UpdateVoiceLabel(float value)
		{
			this.VoiceText.text = ((int)(value * 100f)).ToString();
		}

		// Token: 0x0400159E RID: 5534
		[Header("UI")]
		public Dropdown LanguageDropdown;

		// Token: 0x0400159F RID: 5535
		public Toggle InGameChatToggle;

		// Token: 0x040015A0 RID: 5536
		public Button ResetLoadoutsButton;

		// Token: 0x040015A1 RID: 5537
		public Button ResetStatisticsButton;

		// Token: 0x040015A2 RID: 5538
		[Header("Audio")]
		public Text MusicText;

		// Token: 0x040015A3 RID: 5539
		public Slider MusicSlider;

		// Token: 0x040015A4 RID: 5540
		public Button MusicMinusButton;

		// Token: 0x040015A5 RID: 5541
		public Button MusicPlusButton;

		// Token: 0x040015A6 RID: 5542
		public Text SfxText;

		// Token: 0x040015A7 RID: 5543
		public Slider SfxSlider;

		// Token: 0x040015A8 RID: 5544
		public Button SfxMinusButton;

		// Token: 0x040015A9 RID: 5545
		public Button SfxPlusButton;

		// Token: 0x040015AA RID: 5546
		public Text VoiceText;

		// Token: 0x040015AB RID: 5547
		public Slider VoiceSlider;

		// Token: 0x040015AC RID: 5548
		public Button VoiceMinusButton;

		// Token: 0x040015AD RID: 5549
		public Button VoicePlusButton;

		// Token: 0x040015AE RID: 5550
		[Header("Network")]
		public Toggle NetworkNorthAmericaEast;

		// Token: 0x040015AF RID: 5551
		public Toggle NetworkNorthAmericaWest;

		// Token: 0x040015B0 RID: 5552
		public Toggle NetworkSouthAmerica;

		// Token: 0x040015B1 RID: 5553
		public Toggle NetworkEurope;

		// Token: 0x040015B2 RID: 5554
		public Toggle NetworkAsia;

		// Token: 0x040015B3 RID: 5555
		public Toggle NetworkChina;

		// Token: 0x040015B4 RID: 5556
		public Toggle NetworkDedicated;
	}
}
