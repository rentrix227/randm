﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002DA RID: 730
	public class LeaderboardsPlayersView : BaseView<LeaderboardsController>
	{
		// Token: 0x06000F60 RID: 3936 RVA: 0x0000CAFA File Offset: 0x0000ACFA
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.PlayersList.Template.Dispose();
			this.SkinList.Template.Dispose();
		}

		// Token: 0x06000F61 RID: 3937 RVA: 0x0000CB2A File Offset: 0x0000AD2A
		internal void ClearData()
		{
			this.PlayersList.SetActiveCount(0);
			this.SkinList.SetActiveCount(0);
		}

		// Token: 0x06000F62 RID: 3938 RVA: 0x0000CB44 File Offset: 0x0000AD44
		internal void SetLoading()
		{
			this._currentLoading = true;
		}

		// Token: 0x06000F63 RID: 3939 RVA: 0x0005BEF4 File Offset: 0x0005A0F4
		internal void SetData(Leaderboards leaderboard, LeaderboardEntry[] entries)
		{
			this._currentLoading = false;
			this.PlayerColumns.SetActive(leaderboard != Leaderboards.SKIN_LEGENDARY_LADDER);
			this.SkinColumns.SetActive(leaderboard == Leaderboards.SKIN_LEGENDARY_LADDER);
			this._currentLeaderboard = leaderboard;
			this._currentEntries = entries;
			this._pages = Mathf.CeilToInt((float)entries.Length / 10f);
			this.ClearData();
			this.SetPage(0);
		}

		// Token: 0x06000F64 RID: 3940 RVA: 0x0005BF64 File Offset: 0x0005A164
		internal void SetPage(int page)
		{
			if (page < 0 || page >= this._pages)
			{
				return;
			}
			this._currentPage = page;
			int num = this._currentPage * 10;
			int num2 = this._currentEntries.Length - num;
			int num3 = ((num2 <= 10) ? num2 : 10);
			this.ClearData();
			if (this._currentCoroutine != null)
			{
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._currentCoroutine);
				this._currentCoroutine = null;
			}
			this._currentCoroutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.SpawnPlayersWithDelay(num, num3));
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x0000CB4D File Offset: 0x0000AD4D
		private IEnumerator SpawnPlayersWithDelay(int start, int playerCount)
		{
			int i = start;
			while (i < start + playerCount && i < this._currentEntries.Length)
			{
				if (this._currentLeaderboard == Leaderboards.SKIN_LEGENDARY_LADDER)
				{
					this.SkinList.Instantiate().SetInfo(this._currentEntries[i]);
				}
				else
				{
					this.PlayersList.Instantiate().SetInfo(this._currentLeaderboard, this._currentEntries[i]);
				}
				yield return null;
				yield return null;
				int num = i;
				i = num + 1;
			}
			this._currentCoroutine = null;
			yield break;
		}

		// Token: 0x06000F66 RID: 3942 RVA: 0x0000CB6A File Offset: 0x0000AD6A
		public void Update()
		{
			if (this.Loading.isInitialized)
			{
				this.Loading.SetBool(LeaderboardsPlayersView.Animator_RetrieveLeaderboards, this._currentLoading);
			}
		}

		// Token: 0x06000F67 RID: 3943 RVA: 0x0000CB8F File Offset: 0x0000AD8F
		internal int GetCurrentPage()
		{
			return this._currentPage;
		}

		// Token: 0x0400148B RID: 5259
		internal const int PLAYERS_PER_PAGE = 10;

		// Token: 0x0400148C RID: 5260
		public Animator Loading;

		// Token: 0x0400148D RID: 5261
		public GameObject PlayerColumns;

		// Token: 0x0400148E RID: 5262
		public GameObject SkinColumns;

		// Token: 0x0400148F RID: 5263
		public LeaderboardsPlayersView.LeaderboardPlayersList PlayersList;

		// Token: 0x04001490 RID: 5264
		public LeaderboardsPlayersView.LeaderboardSkinList SkinList;

		// Token: 0x04001491 RID: 5265
		private static int Animator_RetrieveLeaderboards = Animator.StringToHash("retrieving_leaderboards");

		// Token: 0x04001492 RID: 5266
		[NonSerialized]
		private LeaderboardEntry[] _currentEntries;

		// Token: 0x04001493 RID: 5267
		[NonSerialized]
		private Leaderboards _currentLeaderboard;

		// Token: 0x04001494 RID: 5268
		private int _pages;

		// Token: 0x04001495 RID: 5269
		private int _currentPage;

		// Token: 0x04001496 RID: 5270
		private bool _currentLoading;

		// Token: 0x04001497 RID: 5271
		private Coroutine _currentCoroutine;

		// Token: 0x020002DB RID: 731
		[Serializable]
		public class LeaderboardPlayersList : PoolableList<LeaderboardPlayerComponent>
		{
		}

		// Token: 0x020002DC RID: 732
		[Serializable]
		public class LeaderboardSkinList : PoolableList<LeaderboardSkinComponent>
		{
		}
	}
}
