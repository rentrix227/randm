﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200028F RID: 655
	public enum EMatchStatus
	{
		// Token: 0x04001197 RID: 4503
		WINNING,
		// Token: 0x04001198 RID: 4504
		LOSING,
		// Token: 0x04001199 RID: 4505
		TIED,
		// Token: 0x0400119A RID: 4506
		UNDEFINED
	}
}
