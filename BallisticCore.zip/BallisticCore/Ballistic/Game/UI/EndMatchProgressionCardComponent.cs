﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C0 RID: 448
	public class EndMatchProgressionCardComponent : PoolableComponent
	{
		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000939 RID: 2361 RVA: 0x00008669 File Offset: 0x00006869
		private LocalizationService _localization
		{
			get
			{
				return ServiceProvider.GetService<LocalizationService>();
			}
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x00008670 File Offset: 0x00006870
		public void Awake()
		{
			this.XpBarCurrent.material = Object.Instantiate<Material>(this.XpBarCurrent.material);
			this.XpBarEarned.material = Object.Instantiate<Material>(this.XpBarEarned.material);
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x000086A8 File Offset: 0x000068A8
		public void SetSmallCard()
		{
			base.GetComponent<Animator>().runtimeAnimatorController = this.SmallCardAnimatorController;
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x000086BB File Offset: 0x000068BB
		public void OnClick()
		{
			if (this.OnCardClicked != null)
			{
				this.OnCardClicked(this._heroProgression);
			}
		}

		// Token: 0x0600093D RID: 2365 RVA: 0x00038C34 File Offset: 0x00036E34
		internal void SetData(ClassProgressionData progressionData, bool isSmall)
		{
			string classProgressionBackgroundPath = TextureHelper.GetClassProgressionBackgroundPath(progressionData.HeroClass);
			TextureHelper.LoadImageAsync(classProgressionBackgroundPath, this.ClassBackground, EImageSource.RESOURCES);
			this._heroProgression = progressionData;
			this.ClassName.text = this._localization.GetClassName(progressionData.HeroClass, ELocalizedTextCase.UPPER_CASE);
			this.XpAmount.text = "+" + progressionData.XpGained;
			this.SetLevel(progressionData.OldLevel);
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x000086D9 File Offset: 0x000068D9
		internal void SetCardIn(bool set)
		{
			this._isCardSet = set;
		}

		// Token: 0x0600093F RID: 2367 RVA: 0x000086E2 File Offset: 0x000068E2
		internal void SetXpCar(float from, float progress)
		{
			this.XpBarCurrent.material.SetFloat("_Fill", from);
			this.XpBarEarned.material.SetFloat("_Fill", progress);
		}

		// Token: 0x06000940 RID: 2368 RVA: 0x00008710 File Offset: 0x00006910
		internal void SetCardLevelUp(bool set)
		{
			this._isLevelSet = set;
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x00008719 File Offset: 0x00006919
		internal void SetCardLevelUpWithUnlock(bool set)
		{
			this._isUnlockSet = set;
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x00008722 File Offset: 0x00006922
		internal void SetRetriggerLevel()
		{
			this._isRetriggerLevelSet = true;
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x0000872B File Offset: 0x0000692B
		internal void SetRetriggerLevelWithUnlock()
		{
			this._isRetriggerLevelWithUnlockSet = true;
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x00008734 File Offset: 0x00006934
		internal void SetCardFitSquad(bool set)
		{
			this._isCardFitSet = set;
		}

		// Token: 0x06000945 RID: 2373 RVA: 0x00038CAC File Offset: 0x00036EAC
		internal void SetCardFinished(bool set)
		{
			this._isFinishedSet = set;
			if (this.ShowDetailsButton.activeSelf != (set && this._isUnlockSet && !this._isLevelSet))
			{
				this.ShowDetailsButton.SetActive(set && this._isUnlockSet && !this._isLevelSet);
			}
		}

		// Token: 0x06000946 RID: 2374 RVA: 0x00038D18 File Offset: 0x00036F18
		public void Update()
		{
			if (this.Animator.isInitialized)
			{
				this.Animator.SetBool(EndMatchProgressionCardComponent.animator_show_up, this._isCardSet);
				this.Animator.SetBool(EndMatchProgressionCardComponent.animator_level_up, this._isLevelSet);
				this.Animator.SetBool(EndMatchProgressionCardComponent.animator_level_up_with_unlock, this._isUnlockSet);
				this.Animator.SetBool(EndMatchProgressionCardComponent.animator_fit_squad, this._isCardFitSet);
				this.Animator.SetBool(EndMatchProgressionCardComponent.animator_finished, this._isFinishedSet);
				if (this._isRetriggerLevelSet)
				{
					this.Animator.SetTrigger(EndMatchProgressionCardComponent.animator_trigger_level_up);
					this._isRetriggerLevelSet = false;
				}
				if (this._isRetriggerLevelWithUnlockSet)
				{
					this.Animator.SetTrigger(EndMatchProgressionCardComponent.animator_trigger_level_up_with_unlock);
				}
			}
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x00038DE0 File Offset: 0x00036FE0
		internal void SetLevel(int level)
		{
			if (this._lastLevel == level)
			{
				return;
			}
			this._lastLevel = level;
			this.LevelNumber.text = string.Format(this._localization.Get("class_level", ELocalizedTextCase.UPPER_CASE), level);
			LevelUnlockData unlockForLevel = ProgressionData.GetUnlockForLevel(this._heroProgression.HeroClass, level);
			bool flag = unlockForLevel.UnlockType != EUnlockType.NONE;
			for (int i = 0; i < this.NextUnlockObjects.Count; i++)
			{
				this.NextUnlockObjects[i].SetActive(flag);
			}
			if (!flag)
			{
				return;
			}
			this.NextUnlockIsLoadoutIcon.gameObject.SetActive(unlockForLevel.UnlockType == EUnlockType.LOADOUT);
			this.NextUnlockIsSkillIcon.gameObject.SetActive(unlockForLevel.UnlockType == EUnlockType.SKILL);
			this.NextUnlockIsWeaponIcon.gameObject.SetActive(unlockForLevel.UnlockType == EUnlockType.WEAPON);
			EUnlockType unlockType = unlockForLevel.UnlockType;
			if (unlockType != EUnlockType.SKILL)
			{
				if (unlockType != EUnlockType.WEAPON)
				{
					if (unlockType == EUnlockType.LOADOUT)
					{
						this.NextUnlockName.text = this._localization.Get("reward_type_loadout", ELocalizedTextCase.UPPER_CASE);
						this.NextUnlockType.gameObject.SetActive(false);
					}
				}
				else
				{
					this.NextUnlockName.text = this._localization.GetWeaponName(unlockForLevel.UnlockedItemName, ELocalizedTextCase.UPPER_CASE);
					this.NextUnlockType.text = this._localization.Get("reward_type_weapon", ELocalizedTextCase.NONE);
					string text = TextureHelper.GetWeaponIconPath(unlockForLevel.UnlockedItemModel, EImageSize.SMALL, "default");
					TextureHelper.LoadImageAsync(text, this.NextUnlockIsWeaponIcon, false, EImageSource.METADATA);
				}
			}
			else
			{
				this.NextUnlockName.text = this._localization.Get(unlockForLevel.UnlockedItemName.ToLowerInvariant(), ELocalizedTextCase.UPPER_CASE);
				this.NextUnlockType.text = this._localization.Get("reward_type_skill", ELocalizedTextCase.NONE);
				string text = TextureHelper.GetSkillIconPath(unlockForLevel.UnlockedItemName);
				TextureHelper.LoadImageAsync(text, this.NextUnlockIsSkillIcon, false, EImageSource.RESOURCES);
			}
		}

		// Token: 0x04000C36 RID: 3126
		private static int animator_show_up = Animator.StringToHash("show_up");

		// Token: 0x04000C37 RID: 3127
		private static int animator_level_up = Animator.StringToHash("new_level");

		// Token: 0x04000C38 RID: 3128
		private static int animator_level_up_with_unlock = Animator.StringToHash("new_item");

		// Token: 0x04000C39 RID: 3129
		private static int animator_fit_squad = Animator.StringToHash("fit_squad");

		// Token: 0x04000C3A RID: 3130
		private static int animator_trigger_level_up = Animator.StringToHash("re_new_item");

		// Token: 0x04000C3B RID: 3131
		private static int animator_trigger_level_up_with_unlock = Animator.StringToHash("re_new_item");

		// Token: 0x04000C3C RID: 3132
		private static int animator_finished = Animator.StringToHash("finished");

		// Token: 0x04000C3D RID: 3133
		public Animator Animator;

		// Token: 0x04000C3E RID: 3134
		public Renderer ClassBackground;

		// Token: 0x04000C3F RID: 3135
		public Text ClassName;

		// Token: 0x04000C40 RID: 3136
		public Text XpAmount;

		// Token: 0x04000C41 RID: 3137
		public Image XpBarCurrent;

		// Token: 0x04000C42 RID: 3138
		public Image XpBarEarned;

		// Token: 0x04000C43 RID: 3139
		public Text LevelNumber;

		// Token: 0x04000C44 RID: 3140
		public Image NextUnlockIsLoadoutIcon;

		// Token: 0x04000C45 RID: 3141
		public Image NextUnlockIsSkillIcon;

		// Token: 0x04000C46 RID: 3142
		public Image NextUnlockIsWeaponIcon;

		// Token: 0x04000C47 RID: 3143
		public Text NextUnlockName;

		// Token: 0x04000C48 RID: 3144
		public Text NextUnlockType;

		// Token: 0x04000C49 RID: 3145
		public List<GameObject> NextUnlockObjects;

		// Token: 0x04000C4A RID: 3146
		public float XpBarFillSpeed = 0.6f;

		// Token: 0x04000C4B RID: 3147
		public GameObject ShowDetailsButton;

		// Token: 0x04000C4C RID: 3148
		public RuntimeAnimatorController SmallCardAnimatorController;

		// Token: 0x04000C4D RID: 3149
		public float MinCardShowTime = 0.7f;

		// Token: 0x04000C4E RID: 3150
		public Action<ClassProgressionData> OnCardClicked;

		// Token: 0x04000C4F RID: 3151
		private ClassProgressionData _heroProgression;

		// Token: 0x04000C50 RID: 3152
		private bool _isCardSet;

		// Token: 0x04000C51 RID: 3153
		private bool _isLevelSet;

		// Token: 0x04000C52 RID: 3154
		private bool _isUnlockSet;

		// Token: 0x04000C53 RID: 3155
		private bool _isCardFitSet;

		// Token: 0x04000C54 RID: 3156
		private bool _isRetriggerLevelSet;

		// Token: 0x04000C55 RID: 3157
		private bool _isRetriggerLevelWithUnlockSet;

		// Token: 0x04000C56 RID: 3158
		private bool _isFinishedSet;

		// Token: 0x04000C57 RID: 3159
		private int _lastLevel = -1;
	}
}
