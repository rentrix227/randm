﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200031D RID: 797
	public class SoldiersStatsView : BaseView<SoldiersController>
	{
		// Token: 0x060010DC RID: 4316 RVA: 0x0000DE77 File Offset: 0x0000C077
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
		}

		// Token: 0x060010DD RID: 4317 RVA: 0x0000DE95 File Offset: 0x0000C095
		internal void SetStartStats(PlayerHeroData playerHero)
		{
			this._currentHeroClass = playerHero;
			this.ChangeDataComplete();
		}

		// Token: 0x060010DE RID: 4318 RVA: 0x0000DEA4 File Offset: 0x0000C0A4
		internal void SetStats(PlayerHeroData playerHero)
		{
			this._currentHeroClass = playerHero;
		}

		// Token: 0x060010DF RID: 4319 RVA: 0x0006147C File Offset: 0x0005F67C
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (ServiceProvider.GetService<ProgressionService>().CheckGoldClass(this._currentHeroClass.GameItemData.GameItem.UniqueIdentifier))
			{
				string goldClassIconPath = TextureHelper.GetGoldClassIconPath(this._currentHeroClass.GameItemData.GameItem.UniqueIdentifier);
				TextureHelper.LoadImageAsync(goldClassIconPath, this.ClassIcon, false, EImageSource.RESOURCES);
			}
			else
			{
				string classIconPath = TextureHelper.GetClassIconPath(this._currentHeroClass.GameItemData.GameItem.UniqueIdentifier);
				TextureHelper.LoadImageAsync(classIconPath, this.ClassIcon, false, EImageSource.RESOURCES);
			}
			this.StatsDescription.text = this._localizationService.Get(this._currentHeroClass.GameItemData.GameItem.UniqueIdentifier.ToString().ToLower() + "_stats_description", ELocalizedTextCase.NONE);
			for (int i = 0; i < this.StatFeatures.Length; i++)
			{
				this.StatFeatures[i].text = this._localizationService.Get(this._currentHeroClass.GameItemData.GameItem.UniqueIdentifier.ToString().ToLower() + "_stats_feature" + i, ELocalizedTextCase.NONE);
			}
		}

		// Token: 0x04001612 RID: 5650
		public Text StatsDescription;

		// Token: 0x04001613 RID: 5651
		public Text[] StatFeatures;

		// Token: 0x04001614 RID: 5652
		public RawImage ClassIcon;

		// Token: 0x04001615 RID: 5653
		private LocalizationService _localizationService;

		// Token: 0x04001616 RID: 5654
		private PlayerHeroData _currentHeroClass;
	}
}
