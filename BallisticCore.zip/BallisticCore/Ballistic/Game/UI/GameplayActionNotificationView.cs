﻿using System;
using System.Collections.Generic;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000274 RID: 628
	public class GameplayActionNotificationView : BaseView<GameplayKillListController>
	{
		// Token: 0x06000D5D RID: 3421 RVA: 0x0000B297 File Offset: 0x00009497
		protected override void Awake()
		{
			base.Awake();
			this.NotificationTemplate.gameObject.SetActive(false);
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x0004ED14 File Offset: 0x0004CF14
		private GameplayActionNotificationItemComponent GetActiveComponent(ActionNotificationType action)
		{
			foreach (GameplayActionNotificationItemComponent gameplayActionNotificationItemComponent in this._instantiatedItems)
			{
				if (gameplayActionNotificationItemComponent.IsActive && gameplayActionNotificationItemComponent.ActionType == action)
				{
					return gameplayActionNotificationItemComponent;
				}
			}
			return null;
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x0004ED8C File Offset: 0x0004CF8C
		internal void NotifyAction(ActionNotificationType action, int score, bool incrementExisting = false)
		{
			GameplayActionNotificationItemComponent gameplayActionNotificationItemComponent;
			if (incrementExisting)
			{
				gameplayActionNotificationItemComponent = this.GetActiveComponent(action);
				if (gameplayActionNotificationItemComponent != null)
				{
					gameplayActionNotificationItemComponent.Increment(score);
					this._instantiatedItems.Remove(gameplayActionNotificationItemComponent);
					this._instantiatedItems.Add(gameplayActionNotificationItemComponent);
					return;
				}
			}
			if (this._instantiatedItems.Count >= this.MaximumItems)
			{
				Object.Destroy(this._instantiatedItems[0].gameObject);
				this._instantiatedItems.RemoveAt(0);
			}
			gameplayActionNotificationItemComponent = Object.Instantiate<GameplayActionNotificationItemComponent>(this.NotificationTemplate, this.NotificationTemplate.transform.parent);
			if (gameplayActionNotificationItemComponent == null)
			{
				return;
			}
			gameplayActionNotificationItemComponent.SetData(action, score);
			gameplayActionNotificationItemComponent.gameObject.SetActive(true);
			gameplayActionNotificationItemComponent.transform.SetAsFirstSibling();
			this._instantiatedItems.Add(gameplayActionNotificationItemComponent);
		}

		// Token: 0x06000D60 RID: 3424 RVA: 0x0004EE60 File Offset: 0x0004D060
		internal void ClearList()
		{
			if (this._instantiatedItems.Count > 0)
			{
				for (int i = 0; i < this._instantiatedItems.Count; i++)
				{
					Object.Destroy(this._instantiatedItems[i].gameObject);
				}
				this._instantiatedItems.Clear();
			}
		}

		// Token: 0x06000D61 RID: 3425 RVA: 0x0000B2B0 File Offset: 0x000094B0
		public void Update()
		{
			if (this.SendTestNotificationNow)
			{
				this.SendTestNotificationNow = false;
				this.NotifyAction(this.TestNotificationType, this.TestNotificationScore, false);
			}
		}

		// Token: 0x04001036 RID: 4150
		public int MaximumItems = 15;

		// Token: 0x04001037 RID: 4151
		public GameplayActionNotificationItemComponent NotificationTemplate;

		// Token: 0x04001038 RID: 4152
		[Header("Testing")]
		public ActionNotificationType TestNotificationType;

		// Token: 0x04001039 RID: 4153
		public int TestNotificationScore;

		// Token: 0x0400103A RID: 4154
		public bool SendTestNotificationNow;

		// Token: 0x0400103B RID: 4155
		private readonly List<GameplayActionNotificationItemComponent> _instantiatedItems = new List<GameplayActionNotificationItemComponent>();
	}
}
