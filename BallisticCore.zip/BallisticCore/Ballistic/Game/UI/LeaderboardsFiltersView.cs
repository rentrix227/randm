﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D7 RID: 727
	public class LeaderboardsFiltersView : BaseView<LeaderboardsController>
	{
		// Token: 0x06000F4D RID: 3917 RVA: 0x0005BB00 File Offset: 0x00059D00
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.FilterGlobalToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnFilterGlobalSelected));
			this.FilterFriendsToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnFilterFriendsSelected));
			this.FilterNeightboursToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnFilterNeightboursSelected));
		}

		// Token: 0x06000F4E RID: 3918 RVA: 0x0000C9D4 File Offset: 0x0000ABD4
		private void OnFilterGlobalSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboadMethodChange(LeaderboardMethod.GLOBAL);
			}
		}

		// Token: 0x06000F4F RID: 3919 RVA: 0x0000C9ED File Offset: 0x0000ABED
		private void OnFilterFriendsSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboadMethodChange(LeaderboardMethod.FRIENDS);
			}
		}

		// Token: 0x06000F50 RID: 3920 RVA: 0x0000CA06 File Offset: 0x0000AC06
		private void OnFilterNeightboursSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboadMethodChange(LeaderboardMethod.NEIGHTBOURS);
			}
		}

		// Token: 0x06000F51 RID: 3921 RVA: 0x0000CA1F File Offset: 0x0000AC1F
		internal void SetData(LeaderboardMethod method)
		{
			this._isSetting = true;
			this.FilterGlobalToggle.isOn = method == LeaderboardMethod.GLOBAL;
			this.FilterFriendsToggle.isOn = method == LeaderboardMethod.FRIENDS;
			this.FilterNeightboursToggle.isOn = method == LeaderboardMethod.NEIGHTBOURS;
			this._isSetting = false;
		}

		// Token: 0x0400146B RID: 5227
		public Toggle FilterGlobalToggle;

		// Token: 0x0400146C RID: 5228
		public Toggle FilterFriendsToggle;

		// Token: 0x0400146D RID: 5229
		public Toggle FilterNeightboursToggle;

		// Token: 0x0400146E RID: 5230
		private bool _isSetting;
	}
}
