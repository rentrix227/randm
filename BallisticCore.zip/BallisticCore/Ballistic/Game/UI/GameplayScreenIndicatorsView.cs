﻿using System;
using System.Collections.Generic;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200029D RID: 669
	public class GameplayScreenIndicatorsView : BaseView<GameplayScreenIndicatorsController>
	{
		// Token: 0x06000E3C RID: 3644 RVA: 0x000547E0 File Offset: 0x000529E0
		protected override void Awake()
		{
			base.Awake();
			this.GrenadeMarkerTemplate.gameObject.SetActive(false);
			this.AllyCharacterTemplate.gameObject.SetActive(false);
			this.EnemyCharacterTemplate.gameObject.SetActive(false);
			this.DamageRootTemplate.gameObject.SetActive(false);
			this.DeathTemplate.gameObject.SetActive(false);
			for (int i = 0; i < this.CapturePointTemplates.Count; i++)
			{
				this.CapturePointTemplates[i].gameObject.SetActive(false);
			}
		}

		// Token: 0x06000E3D RID: 3645 RVA: 0x0005487C File Offset: 0x00052A7C
		private T InitializeIndicator<T>(BaseScreenIndicator marker, T markerTemplate, Vector3 worldOffset, bool clampOnBorder, BorderSettings borderSize = null) where T : Component
		{
			marker.WorldOffset = worldOffset;
			marker.BottomLeftReference = this.BottomLeftReference;
			marker.TopRightReference = this.TopRightReference;
			marker.ClampOnBorder = clampOnBorder;
			marker.BorderSize = borderSize;
			T t = Object.Instantiate<T>(markerTemplate, markerTemplate.transform.parent);
			marker.Marker = t.transform;
			t.gameObject.SetActive(true);
			return t;
		}

		// Token: 0x06000E3E RID: 3646 RVA: 0x000548F8 File Offset: 0x00052AF8
		internal GrenadeScreenIndicator CreateGrenadeIndicator(Transform grenade)
		{
			GrenadeScreenIndicator grenadeScreenIndicator = new GrenadeScreenIndicator();
			grenadeScreenIndicator.IndicatorComponent = this.InitializeIndicator<GameplayScreenIndicatorGrenadeComponent>(grenadeScreenIndicator, this.GrenadeMarkerTemplate, Vector3.zero, true, this.GrenadeBorderSize);
			grenadeScreenIndicator.GrenadeTransform = grenade;
			return grenadeScreenIndicator;
		}

		// Token: 0x06000E3F RID: 3647 RVA: 0x00054934 File Offset: 0x00052B34
		internal CharacterScreenIndicator CreateCharacterIndicator(UITeam team, string nickname, bool isJuggernaut)
		{
			CharacterScreenIndicator characterScreenIndicator = new CharacterScreenIndicator();
			GameplayScreenIndicatorCharacterComponent gameplayScreenIndicatorCharacterComponent = ((!isJuggernaut) ? ((team != UITeam.Mine) ? this.EnemyCharacterTemplate : this.AllyCharacterTemplate) : this.JuggernautCharacterTemplate);
			characterScreenIndicator.Team = team;
			characterScreenIndicator.IndicatorComponent = this.InitializeIndicator<GameplayScreenIndicatorCharacterComponent>(characterScreenIndicator, gameplayScreenIndicatorCharacterComponent, this.CharacterIndicatorWorldOffset, false, null);
			characterScreenIndicator.WorldOffsetForTank = this.CharacterIndicatorWorldOffsetForTank;
			characterScreenIndicator.SetNickname(nickname);
			characterScreenIndicator.DistanceToShowWhenAiming = this.DistanceToShowCharacterMarkerWhenAimingAtHim;
			characterScreenIndicator.DistanceToShowWhenNotAiming = this.DistanceToShowCharacterMarker;
			characterScreenIndicator.DistanceToStartShowArrow = this.DistanceToStartShowArrow;
			characterScreenIndicator.DistanceToShowWhenJuggernaut = this.DistanceToShowWhenJuggernaut;
			characterScreenIndicator.DistanceMaximumToScaleArrow = this.DistanceMaximumToScaleArrow;
			characterScreenIndicator.DistanceScaleOfArrow = this.DistanceScaleOfArrow;
			return characterScreenIndicator;
		}

		// Token: 0x06000E40 RID: 3648 RVA: 0x000549EC File Offset: 0x00052BEC
		internal DamageScreenIndicator CreateDamageIndicator()
		{
			DamageScreenIndicator damageScreenIndicator = new DamageScreenIndicator();
			damageScreenIndicator.IndicatorComponent = this.InitializeIndicator<GameplayScreenIndicatorDamageRootComponent>(damageScreenIndicator, this.DamageRootTemplate, this.DamageIndicatorWorldOffset, false, null);
			damageScreenIndicator.MaxDamageForLow = this.MaxDamageForLow;
			damageScreenIndicator.MaxDamageForMedium = this.MaxDamageForMedium;
			return damageScreenIndicator;
		}

		// Token: 0x06000E41 RID: 3649 RVA: 0x00054A34 File Offset: 0x00052C34
		internal DeathScreenIndicator CreateDeathIndicator(string nickname)
		{
			DeathScreenIndicator deathScreenIndicator = new DeathScreenIndicator();
			deathScreenIndicator.IndicatorComponent = this.InitializeIndicator<GameplayScreenIndicatorDeathComponent>(deathScreenIndicator, this.DeathTemplate, this.DeathWorldOffset, false, null);
			deathScreenIndicator.SetNickname(nickname);
			deathScreenIndicator.DistanceToShow = this.DistanceToShowDeathMarker;
			return deathScreenIndicator;
		}

		// Token: 0x06000E42 RID: 3650 RVA: 0x00054A78 File Offset: 0x00052C78
		internal CapturePointScreenIndicator CreateCapturePointIndicator(string pointName)
		{
			CapturePointScreenIndicator capturePointScreenIndicator = new CapturePointScreenIndicator();
			GameplayScreenIndicatorCapturePointComponent gameplayScreenIndicatorCapturePointComponent = null;
			for (int i = 0; i < this.CapturePointTemplates.Count; i++)
			{
				if (this.CapturePointTemplates[i].PointName == pointName)
				{
					gameplayScreenIndicatorCapturePointComponent = this.CapturePointTemplates[i];
					break;
				}
			}
			if (gameplayScreenIndicatorCapturePointComponent == null)
			{
				Debug.LogErrorFormat("[CreateCapturePointIndicator] No valid template found for point name {0}", new object[] { pointName });
			}
			else
			{
				capturePointScreenIndicator.IndicatorComponent = this.InitializeIndicator<GameplayScreenIndicatorCapturePointComponent>(capturePointScreenIndicator, gameplayScreenIndicatorCapturePointComponent, this.CapturePointWorldOffset, false, null);
			}
			return capturePointScreenIndicator;
		}

		// Token: 0x06000E43 RID: 3651 RVA: 0x00054B14 File Offset: 0x00052D14
		public void Update()
		{
			if (this.DoGrenadeTest)
			{
				if (this._testGrenadeIndicator == null)
				{
					this._testGrenadeIndicator = this.CreateGrenadeIndicator(this.TestGrenadeWorldReference);
				}
				this._testGrenadeIndicator.UpdateMarker();
				this._testGrenadeIndicator.SetTeam(this.TestGrenadeTeam);
			}
			if (this.DoCharacterTest)
			{
				if (this._testCharacterIndicator == null)
				{
					this._testCharacterIndicator = this.CreateCharacterIndicator(this.TestCharacterTeam, this.TestCharacterNickname, false);
				}
				this._testCharacterIndicator.UpdateMarker(this.TestCharacterWorldReference.position, this.TestCharacterIsAiming, this.TestCharacterIsCamouflaged, this.TestCharacterHealth, this.TestCharacterMaxHealth, EHeroClass.BERSERKER, false, false, true);
			}
			if (this.DoDamageTest)
			{
				if (this._testDamageIndicator == null)
				{
					this._testDamageIndicator = this.CreateDamageIndicator();
				}
				this._testDamageIndicator.UpdateMarker(this.TestDamageWorldReference.position);
				if (this.DoDamageSpawnTestNow)
				{
					this.DoDamageSpawnTestNow = false;
					this._testDamageIndicator.SpawnDamage(this.DamageTestDamage, 0f, DamageAmount.Medium);
				}
			}
			if (this.DoDeathTestNow)
			{
				this.DoDeathTestNow = false;
				this._testDeathIndicator = this.CreateDeathIndicator(this.TestDeathNickname);
			}
			if (this._testDeathIndicator != null && this._testDeathIndicator.Marker != null)
			{
				this._testDeathIndicator.UpdateMarker(this.TestCharacterWorldReference.position);
			}
			if (this.DoCapturePointTest)
			{
				if (this._testPointIndicator == null)
				{
					this._testPointIndicator = this.CreateCapturePointIndicator(this.TestPointName);
				}
				this._testPointIndicator.UpdateMarker(this.TestPointWorldReference.position, this.TestPointOwnerTeam, this.TestPointCapturingTeam, this.TestPointCaptureAmount);
			}
		}

		// Token: 0x0400121B RID: 4635
		public Transform BottomLeftReference;

		// Token: 0x0400121C RID: 4636
		public Transform TopRightReference;

		// Token: 0x0400121D RID: 4637
		[Header("Grenades")]
		public GameplayScreenIndicatorGrenadeComponent GrenadeMarkerTemplate;

		// Token: 0x0400121E RID: 4638
		public BorderSettings GrenadeBorderSize;

		// Token: 0x0400121F RID: 4639
		[Header("Grenades testing")]
		public bool DoGrenadeTest;

		// Token: 0x04001220 RID: 4640
		public Transform TestGrenadeWorldReference;

		// Token: 0x04001221 RID: 4641
		public UITeam TestGrenadeTeam;

		// Token: 0x04001222 RID: 4642
		[Header("Characters")]
		public float DistanceToShowCharacterMarker = 7f;

		// Token: 0x04001223 RID: 4643
		public float DistanceToShowCharacterMarkerWhenAimingAtHim = 50f;

		// Token: 0x04001224 RID: 4644
		public float DistanceToShowWhenJuggernaut = 13f;

		// Token: 0x04001225 RID: 4645
		public Vector2 DistanceToShowArrow = new Vector2(20f, 50f);

		// Token: 0x04001226 RID: 4646
		public float DistanceToStartShowArrow = 15f;

		// Token: 0x04001227 RID: 4647
		public float DistanceMaximumToScaleArrow = 35f;

		// Token: 0x04001228 RID: 4648
		public Vector2 DistanceScaleOfArrow = new Vector2(1f, 0.3f);

		// Token: 0x04001229 RID: 4649
		public Vector3 CharacterIndicatorWorldOffset = 1.8f * Vector3.up;

		// Token: 0x0400122A RID: 4650
		public Vector3 CharacterIndicatorWorldOffsetForTank = 2f * Vector3.up;

		// Token: 0x0400122B RID: 4651
		public GameplayScreenIndicatorCharacterComponent AllyCharacterTemplate;

		// Token: 0x0400122C RID: 4652
		public GameplayScreenIndicatorCharacterComponent EnemyCharacterTemplate;

		// Token: 0x0400122D RID: 4653
		public GameplayScreenIndicatorCharacterComponent JuggernautCharacterTemplate;

		// Token: 0x0400122E RID: 4654
		[Header("Characters testing")]
		public bool DoCharacterTest;

		// Token: 0x0400122F RID: 4655
		public UITeam TestCharacterTeam;

		// Token: 0x04001230 RID: 4656
		public string TestCharacterNickname;

		// Token: 0x04001231 RID: 4657
		public float TestCharacterHealth;

		// Token: 0x04001232 RID: 4658
		public float TestCharacterMaxHealth;

		// Token: 0x04001233 RID: 4659
		public bool TestCharacterIsAiming;

		// Token: 0x04001234 RID: 4660
		public bool TestCharacterIsCamouflaged;

		// Token: 0x04001235 RID: 4661
		public Transform TestCharacterWorldReference;

		// Token: 0x04001236 RID: 4662
		[Header("Damage")]
		public GameplayScreenIndicatorDamageRootComponent DamageRootTemplate;

		// Token: 0x04001237 RID: 4663
		public float MaxDamageForLow;

		// Token: 0x04001238 RID: 4664
		public float MaxDamageForMedium;

		// Token: 0x04001239 RID: 4665
		public Vector3 DamageIndicatorWorldOffset = 1.8f * Vector3.up;

		// Token: 0x0400123A RID: 4666
		[Header("Damage testing")]
		public bool DoDamageTest;

		// Token: 0x0400123B RID: 4667
		public Transform TestDamageWorldReference;

		// Token: 0x0400123C RID: 4668
		public float DamageTestDamage = 50f;

		// Token: 0x0400123D RID: 4669
		public bool DoDamageSpawnTestNow;

		// Token: 0x0400123E RID: 4670
		[Header("Death")]
		public float DistanceToShowDeathMarker = 7f;

		// Token: 0x0400123F RID: 4671
		public Vector3 DeathWorldOffset = 0.15f * Vector3.up;

		// Token: 0x04001240 RID: 4672
		public GameplayScreenIndicatorDeathComponent DeathTemplate;

		// Token: 0x04001241 RID: 4673
		[Header("Death testing")]
		public bool DoDeathTestNow;

		// Token: 0x04001242 RID: 4674
		public string TestDeathNickname;

		// Token: 0x04001243 RID: 4675
		public Transform TestDeathWorldReference;

		// Token: 0x04001244 RID: 4676
		[Header("Capture Point")]
		public Vector3 CapturePointWorldOffset = 0.5f * Vector3.up;

		// Token: 0x04001245 RID: 4677
		public List<GameplayScreenIndicatorCapturePointComponent> CapturePointTemplates = new List<GameplayScreenIndicatorCapturePointComponent>();

		// Token: 0x04001246 RID: 4678
		[Header("Capture Point testing")]
		public bool DoCapturePointTest;

		// Token: 0x04001247 RID: 4679
		public string TestPointName;

		// Token: 0x04001248 RID: 4680
		public Transform TestPointWorldReference;

		// Token: 0x04001249 RID: 4681
		public UITeam TestPointOwnerTeam;

		// Token: 0x0400124A RID: 4682
		public UITeam TestPointCapturingTeam;

		// Token: 0x0400124B RID: 4683
		public float TestPointCaptureAmount;

		// Token: 0x0400124C RID: 4684
		private GrenadeScreenIndicator _testGrenadeIndicator;

		// Token: 0x0400124D RID: 4685
		private CharacterScreenIndicator _testCharacterIndicator;

		// Token: 0x0400124E RID: 4686
		private DamageScreenIndicator _testDamageIndicator;

		// Token: 0x0400124F RID: 4687
		private DeathScreenIndicator _testDeathIndicator;

		// Token: 0x04001250 RID: 4688
		private CapturePointScreenIndicator _testPointIndicator;
	}
}
