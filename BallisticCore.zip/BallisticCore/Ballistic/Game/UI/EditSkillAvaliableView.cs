﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000266 RID: 614
	public class EditSkillAvaliableView : BaseView<SkillsController>
	{
		// Token: 0x06000D36 RID: 3382 RVA: 0x0000B06B File Offset: 0x0000926B
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SkillTemplate.Template.Dispose();
		}

		// Token: 0x06000D37 RID: 3383 RVA: 0x0000B08E File Offset: 0x0000928E
		private void OnSkillSelect(HeroSkillData skillData)
		{
			base._controller.SetTemporarySkill(skillData);
		}

		// Token: 0x06000D38 RID: 3384 RVA: 0x0004E860 File Offset: 0x0004CA60
		internal void SetAvaliableSkills(EHeroClass heroClass, List<HeroSkillData> avaliableHeroSkillDatas, List<HeroSkillData> allHeroSkillDatas, HeroSkillData heroSkillData)
		{
			EditSkillAvaliableView.<SetAvaliableSkills>c__AnonStorey0 <SetAvaliableSkills>c__AnonStorey = new EditSkillAvaliableView.<SetAvaliableSkills>c__AnonStorey0();
			<SetAvaliableSkills>c__AnonStorey.allHeroSkillDatas = allHeroSkillDatas;
			this.SkillTemplate.SetActiveCount(<SetAvaliableSkills>c__AnonStorey.allHeroSkillDatas.Count);
			int i;
			for (i = 0; i < <SetAvaliableSkills>c__AnonStorey.allHeroSkillDatas.Count; i++)
			{
				SoldiersSkillComponent soldiersSkillComponent = this.SkillTemplate[i];
				bool flag = avaliableHeroSkillDatas.Exists((HeroSkillData x) => x.Skill == <SetAvaliableSkills>c__AnonStorey.allHeroSkillDatas[i].Skill);
				int levelForSkillUnlock = ProgressionData.GetLevelForSkillUnlock(heroClass, <SetAvaliableSkills>c__AnonStorey.allHeroSkillDatas[i].Skill.ToString());
				soldiersSkillComponent.SetData(<SetAvaliableSkills>c__AnonStorey.allHeroSkillDatas[i], heroSkillData.Skill == <SetAvaliableSkills>c__AnonStorey.allHeroSkillDatas[i].Skill, flag, levelForSkillUnlock);
				soldiersSkillComponent.OnSkillClicked = new Action<HeroSkillData>(this.OnSkillSelect);
			}
		}

		// Token: 0x04001008 RID: 4104
		public EditSkillAvaliableView.SoldiersSkillComponentPoolableList SkillTemplate;

		// Token: 0x02000267 RID: 615
		[Serializable]
		public class SoldiersSkillComponentPoolableList : PoolableList<SoldiersSkillComponent>
		{
		}
	}
}
