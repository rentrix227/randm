﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002F6 RID: 758
	public class NewLockboxPopupView : BaseView<PopupController>
	{
		// Token: 0x06000FCB RID: 4043 RVA: 0x0005CECC File Offset: 0x0005B0CC
		internal void SetData(LockboxData data)
		{
			if (this.LockboxImage != null)
			{
				string lockboxIconPath = TextureHelper.GetLockboxIconPath(data.Lockbox.Season, data.Lockbox.HeroClass, EImageSize.LARGE);
				TextureHelper.LoadImageAsync(lockboxIconPath, this.LockboxImage, false, EImageSource.RESOURCES);
			}
			if (this.LockboxSeasonImage != null)
			{
				string text;
				if (data.Lockbox.Season == ESeason.LADDER)
				{
					text = TextureHelper.GetRewardsIconPath(data.Lockbox.HeroClass, EImageSize.MEDIUM);
				}
				else
				{
					text = TextureHelper.GetSeasonIconPath(data.Lockbox.Season, EImageSize.MEDIUM);
				}
				TextureHelper.LoadImageAsync(text, this.LockboxSeasonImage, false, EImageSource.RESOURCES);
			}
			this.LockboxName.text = data.CurrentName;
			this.LockboxSeason.text = ServiceProvider.GetService<LocalizationService>().GetSeasonName(data.Lockbox.Season, ELocalizedTextCase.NONE);
		}

		// Token: 0x040014F3 RID: 5363
		public Image LockboxImage;

		// Token: 0x040014F4 RID: 5364
		public Image LockboxSeasonImage;

		// Token: 0x040014F5 RID: 5365
		public Text LockboxName;

		// Token: 0x040014F6 RID: 5366
		public Text LockboxSeason;
	}
}
