﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D4 RID: 468
	public class HeaderNotificationComponent : MonoBehaviour
	{
		// Token: 0x060009A4 RID: 2468 RVA: 0x00039EE4 File Offset: 0x000380E4
		public void Awake()
		{
			this._shouldCleanData = false;
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.ExcludeWhenToggleClick != null)
			{
				this.ExcludeWhenToggleClick.onValueChanged.AddListener(new UnityAction<bool>(this.OnExcludeNotificationClick));
			}
			this._inventoryService = ServiceProvider.GetService<InventoryService>();
			this._inventoryService.OnNotificationChange += this.OnNotificationChange;
			this.UpdateAmount();
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x00039F58 File Offset: 0x00038158
		private void OnExcludeNotificationClick(bool value)
		{
			if (value)
			{
				this._shouldCleanData = true;
			}
			else if (this._shouldCleanData)
			{
				foreach (ENotifications enotifications in this.NotificationsToListen)
				{
					this._inventoryService.ClearNotifications(enotifications);
				}
			}
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x00008B10 File Offset: 0x00006D10
		public void OnDestroy()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._inventoryService.OnNotificationChange -= this.OnNotificationChange;
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x00008B34 File Offset: 0x00006D34
		private void OnNotificationChange()
		{
			this.UpdateAmount();
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x00039FB0 File Offset: 0x000381B0
		private void UpdateAmount()
		{
			int num = 0;
			foreach (ENotifications enotifications in this.NotificationsToListen)
			{
				num += this._inventoryService.GetNotificationsCount(enotifications, false);
			}
			if (num == this._amount)
			{
				return;
			}
			this._amount = num;
			if (this._amount > 0)
			{
				if (this._notificationInstance == null)
				{
					this._notificationInstance = Object.Instantiate<GameObject>(this.NotificationTemplate);
					this._notificationInstance.transform.SetParent(this.NotificationParent, false);
				}
				if (this._notificationInstance == null)
				{
					return;
				}
				this._notificationInstance.GetComponent<Animator>().SetTrigger("count");
				this._notificationInstance.GetComponentInChildren<Text>().text = num.ToString();
			}
			else
			{
				if (this._notificationInstance == null)
				{
					return;
				}
				Object.Destroy(this._notificationInstance);
				this._notificationInstance = null;
			}
		}

		// Token: 0x04000CCE RID: 3278
		public GameObject NotificationTemplate;

		// Token: 0x04000CCF RID: 3279
		public Transform NotificationParent;

		// Token: 0x04000CD0 RID: 3280
		public ENotifications[] NotificationsToListen;

		// Token: 0x04000CD1 RID: 3281
		public Toggle ExcludeWhenToggleClick;

		// Token: 0x04000CD2 RID: 3282
		private InventoryService _inventoryService;

		// Token: 0x04000CD3 RID: 3283
		private GameObject _notificationInstance;

		// Token: 0x04000CD4 RID: 3284
		private int _amount = -1;

		// Token: 0x04000CD5 RID: 3285
		private bool _shouldCleanData;
	}
}
