﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D2 RID: 722
	public class InventoryMenuView : BaseView<InventoryController>
	{
		// Token: 0x06000F27 RID: 3879 RVA: 0x0005B344 File Offset: 0x00059544
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SelectLockbox.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectLockbox));
			this.SelectWeaponSkin.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectWeaponSkin));
			this.SelectVanity.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectVanity));
			this.SelectScraps.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectScraps));
		}

		// Token: 0x06000F28 RID: 3880 RVA: 0x0005B3D4 File Offset: 0x000595D4
		internal void SetData(InventoryData inventoryData, int accessoriesCompleted)
		{
			string text = " " + ServiceProvider.GetService<LocalizationService>().Get("item", ELocalizedTextCase.UPPER_CASE);
			string text2 = " " + ServiceProvider.GetService<LocalizationService>().Get("items", ELocalizedTextCase.UPPER_CASE);
			string text3 = " " + ServiceProvider.GetService<LocalizationService>().Get("items_completed", ELocalizedTextCase.UPPER_CASE);
			this.LockboxAmountText.text = ((inventoryData.Lockboxes.Count <= 1) ? (inventoryData.Lockboxes.Count + text) : (inventoryData.Lockboxes.Count + text2));
			this.SkinsAmountText.text = ((inventoryData.WeaponSkins.Count <= 1) ? (inventoryData.WeaponSkins.Count + text) : (inventoryData.WeaponSkins.Count + text2));
			this.SpecialItemsText.text = accessoriesCompleted + text3;
			if (inventoryData.Scraps.Count > 0)
			{
				this.ScrapsText.text = ((inventoryData.Scraps[0].Quantity <= 1U) ? (inventoryData.Scraps[0].Quantity + text) : (inventoryData.Scraps[0].Quantity + text2));
			}
			else
			{
				this.ScrapsText.text = "0" + text2;
			}
		}

		// Token: 0x06000F29 RID: 3881 RVA: 0x0000C754 File Offset: 0x0000A954
		private void OnSelectLockbox(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.DispatchBoardChanged(EInventoryBoard.LOCKBOX);
		}

		// Token: 0x06000F2A RID: 3882 RVA: 0x0000C769 File Offset: 0x0000A969
		private void OnSelectWeaponSkin(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.DispatchBoardChanged(EInventoryBoard.WEAPONSKIN);
		}

		// Token: 0x06000F2B RID: 3883 RVA: 0x0000C77E File Offset: 0x0000A97E
		private void OnSelectScraps(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.DispatchBoardChanged(EInventoryBoard.SCRAPS);
		}

		// Token: 0x06000F2C RID: 3884 RVA: 0x0000C793 File Offset: 0x0000A993
		private void OnSelectVanity(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.DispatchBoardChanged(EInventoryBoard.VANITY);
		}

		// Token: 0x0400144D RID: 5197
		public Toggle SelectLockbox;

		// Token: 0x0400144E RID: 5198
		public Toggle SelectWeaponSkin;

		// Token: 0x0400144F RID: 5199
		public Toggle SelectScraps;

		// Token: 0x04001450 RID: 5200
		public Toggle SelectVanity;

		// Token: 0x04001451 RID: 5201
		public Text LockboxAmountText;

		// Token: 0x04001452 RID: 5202
		public Text SkinsAmountText;

		// Token: 0x04001453 RID: 5203
		public Text SpecialItemsText;

		// Token: 0x04001454 RID: 5204
		public Text ScrapsText;
	}
}
