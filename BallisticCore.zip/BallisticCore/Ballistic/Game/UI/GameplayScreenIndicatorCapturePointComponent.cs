﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D3 RID: 467
	public class GameplayScreenIndicatorCapturePointComponent : MonoBehaviour
	{
		// Token: 0x060009A1 RID: 2465 RVA: 0x00039E2C File Offset: 0x0003802C
		public void Awake()
		{
			this._fillHash = Shader.PropertyToID("_Fill");
			this._ownerTeamHash = Animator.StringToHash("owner_team");
			this._capturingTeamHash = Animator.StringToHash("capturing_team");
			this._captureMaterial = Object.Instantiate<Material>(this.CaptureFillImage.material);
			this.CaptureFillImage.material = this._captureMaterial;
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x00039E90 File Offset: 0x00038090
		public void SetInfo(UITeam owner, UITeam capturing, float captureAmount)
		{
			this._captureMaterial.SetFloat(this._fillHash, captureAmount);
			if (this.Animator.isInitialized)
			{
				this.Animator.SetInteger(this._ownerTeamHash, (int)owner);
				this.Animator.SetInteger(this._capturingTeamHash, (int)capturing);
			}
		}

		// Token: 0x04000CC7 RID: 3271
		public string PointName;

		// Token: 0x04000CC8 RID: 3272
		public RawImage CaptureFillImage;

		// Token: 0x04000CC9 RID: 3273
		public Animator Animator;

		// Token: 0x04000CCA RID: 3274
		private Material _captureMaterial;

		// Token: 0x04000CCB RID: 3275
		private int _fillHash;

		// Token: 0x04000CCC RID: 3276
		private int _ownerTeamHash;

		// Token: 0x04000CCD RID: 3277
		private int _capturingTeamHash;
	}
}
