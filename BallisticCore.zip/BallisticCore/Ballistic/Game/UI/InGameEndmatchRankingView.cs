﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.UI.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002AD RID: 685
	public class InGameEndmatchRankingView : BaseView<InGameEndmatchRankingController>
	{
		// Token: 0x06000E83 RID: 3715 RVA: 0x0000BD8E File Offset: 0x00009F8E
		internal void SetStartData()
		{
			this.PlayerUnranked.SetActive(false);
			this.PlayerRanked.SetActive(false);
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x00056EA4 File Offset: 0x000550A4
		internal void SetData(string name, Texture avatar, int[] oldmatches, int[] newmatches, int oldrating, int newrating)
		{
			this._eventStructs.Clear();
			int num = oldrating;
			this._canRun = true;
			int num2 = oldmatches[0] + oldmatches[1] + oldmatches[2] + oldmatches[3] + oldmatches[4];
			int num3 = newmatches[0] + newmatches[1] + newmatches[2] + newmatches[3] + newmatches[4];
			bool flag = !oldmatches.Any((int t) => t < 5);
			bool flag2 = !newmatches.Any((int t) => t < 5);
			bool flag3 = num2 >= 25;
			bool flag4 = num3 >= 25;
			bool flag5 = flag3 && flag;
			bool flag6 = flag4 && flag2;
			bool flag7 = num2 == num3 && num == newrating;
			if (!flag5)
			{
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_IN,
					StartTime = this.GetLastTimedEvent(),
					Duration = 2f
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MATCHS,
					StartTime = this.GetLastTimedEvent(),
					Duration = ((num2 == num3) ? 0f : 1.5f),
					IntFrom = (float)num2,
					IntTo = (float)num3,
					FloatFrom = (float)num2 / 25f,
					FloatTo = (float)num3 / 25f,
					PlacementsModeText = this.MatchsAmount,
					PlacementsModeFillbar = this.MatchsFillbar
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MATCHS_COMPLETED,
					StartTime = this.GetLastTimedEvent(),
					Duration = ((flag3 == flag4) ? 0f : 1.5f),
					BoolFrom = flag3,
					BoolTo = flag4,
					PlacementsModeAnimator = this.MatchsCompleted
				});
				float num4 = ((num2 == num3) ? 0f : 1f);
				float num5 = this.GetLastTimedEvent() + 1f;
				float num6 = num5 + num4;
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE,
					StartTime = num5,
					Duration = num4,
					IntFrom = (float)oldmatches[0],
					IntTo = (float)newmatches[0],
					FloatFrom = (float)oldmatches[0] / 5f,
					FloatTo = (float)newmatches[0] / 5f,
					PlacementsModeText = this.TdmAmount,
					PlacementsModeFillbar = this.TdmFillbar
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE_COMPLETED,
					StartTime = num6,
					Duration = ((oldmatches[0] == newmatches[0]) ? 0f : num4),
					BoolFrom = (oldmatches[0] >= 5),
					BoolTo = (newmatches[0] >= 5),
					PlacementsModeAnimator = this.TdmCompleted
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE,
					StartTime = num5,
					Duration = num4,
					IntFrom = (float)oldmatches[1],
					IntTo = (float)newmatches[1],
					FloatFrom = (float)oldmatches[1] / 5f,
					FloatTo = (float)newmatches[1] / 5f,
					PlacementsModeText = this.FfaAmount,
					PlacementsModeFillbar = this.FfaFillbar
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE_COMPLETED,
					StartTime = num6,
					Duration = ((oldmatches[1] == newmatches[1]) ? 0f : num4),
					BoolFrom = (oldmatches[1] >= 5),
					BoolTo = (newmatches[1] >= 5),
					PlacementsModeAnimator = this.FfaCompleted
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE,
					StartTime = num5,
					Duration = num4,
					IntFrom = (float)oldmatches[2],
					IntTo = (float)newmatches[2],
					FloatFrom = (float)oldmatches[2] / 5f,
					FloatTo = (float)newmatches[2] / 5f,
					PlacementsModeText = this.CtpAmount,
					PlacementsModeFillbar = this.CtpFillbar
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE_COMPLETED,
					StartTime = num6,
					Duration = ((oldmatches[2] == newmatches[2]) ? 0f : num4),
					BoolFrom = (oldmatches[2] >= 5),
					BoolTo = (newmatches[2] >= 5),
					PlacementsModeAnimator = this.CtpCompleted
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE,
					StartTime = num5,
					Duration = num4,
					IntFrom = (float)oldmatches[3],
					IntTo = (float)newmatches[3],
					FloatFrom = (float)oldmatches[3] / 5f,
					FloatTo = (float)newmatches[3] / 5f,
					PlacementsModeText = this.KothAmount,
					PlacementsModeFillbar = this.KothFillbar
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE_COMPLETED,
					StartTime = num6,
					Duration = ((oldmatches[3] == newmatches[3]) ? 0f : num4),
					BoolFrom = (oldmatches[3] >= 5),
					BoolTo = (newmatches[3] >= 5),
					PlacementsModeAnimator = this.KothCompleted
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE,
					StartTime = num5,
					Duration = num4,
					IntFrom = (float)oldmatches[4],
					IntTo = (float)newmatches[4],
					FloatFrom = (float)oldmatches[4] / 5f,
					FloatTo = (float)newmatches[4] / 5f,
					PlacementsModeText = this.RoundsAmount,
					PlacementsModeFillbar = this.RoundsFillbar
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE_COMPLETED,
					StartTime = num6,
					Duration = ((oldmatches[4] == newmatches[4]) ? 0f : num4),
					BoolFrom = (oldmatches[4] >= 5),
					BoolTo = (newmatches[4] >= 5),
					PlacementsModeAnimator = this.RoundsCompleted
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MODE_COMPLETED,
					StartTime = this.GetLastTimedEvent(),
					Duration = ((flag == flag2) ? 0f : 2f),
					BoolFrom = flag,
					BoolTo = flag2,
					PlacementsModeAnimator = this.PerModeCompleted
				});
				if (flag6)
				{
					num = newrating;
					this._eventStructs.Add(new RankingEventStruct
					{
						Type = RankingEventStruct.EventStructType.PLACEMENTS_RANKED_NOW,
						StartTime = this.GetLastTimedEvent(),
						Duration = 2f
					});
				}
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.PLACEMENTS_MATCH_INVALID,
					StartTime = this.GetLastTimedEvent(),
					Duration = 2f,
					BoolFrom = false,
					BoolTo = flag7
				});
			}
			int skillRatingTierNumber = RatingUtil.GetSkillRatingTierNumber((float)num);
			int skillRatingTierNumber2 = RatingUtil.GetSkillRatingTierNumber((float)newrating);
			int skillRatingLimiarDrop = RatingUtil.GetSkillRatingLimiarDrop(num);
			int skillRatingLimiarDrop2 = RatingUtil.GetSkillRatingLimiarDrop(newrating);
			int skillRatingLimiarNext = RatingUtil.GetSkillRatingLimiarNext((float)num);
			int skillRatingLimiarNext2 = RatingUtil.GetSkillRatingLimiarNext((float)newrating);
			if (flag5 || flag6)
			{
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.RANKING_DISTRIBUTE_IN,
					StartTime = this.GetLastTimedEvent(),
					Duration = 2f
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.RANKING_DISTRIBUTE,
					StartTime = this.GetLastTimedEvent(),
					Duration = ((newrating == num) ? 0.5f : 2f),
					IntFrom = (float)num,
					IntTo = (float)newrating,
					RankedAnimator = this.RankedSkillRatingAnimator,
					RankedText = this.RankedNewRatingText
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.RANKING_INCREASED,
					StartTime = this.GetLastTimedEvent(),
					Duration = ((newrating == num) ? 0.5f : 2.5f),
					BoolFrom = false,
					BoolTo = (newrating > num),
					RankedAnimator = this.RankedSkillNotificationAnimator
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.RANKING_BADGE,
					StartTime = this.GetLastTimedEvent(),
					Duration = ((skillRatingTierNumber == skillRatingTierNumber2) ? 0f : 2.5f),
					RankFrom = skillRatingTierNumber,
					RankTo = skillRatingTierNumber2,
					OldLimiarDown = skillRatingLimiarDrop,
					OldLimiarUp = skillRatingLimiarNext,
					NewLimiarDown = skillRatingLimiarDrop2,
					NewLimiarUp = skillRatingLimiarNext2
				});
				this._eventStructs.Add(new RankingEventStruct
				{
					Type = RankingEventStruct.EventStructType.RANKING_MATCH_INVALID,
					StartTime = this.GetLastTimedEvent(),
					Duration = 2f,
					BoolFrom = false,
					BoolTo = flag7
				});
			}
			this.UnrankedPlayerName.text = name;
			this.UnrankedPlayerAvatar.texture = avatar;
			this.RankedPlayerAvatar.texture = avatar;
			this.RankedPlayerName.text = name;
			this.RankedCircle.SetActive(flag5);
			this.RankedNewRatingText.gameObject.SetActive(flag5);
			this.RankedOldRatingText.text = num.ToString();
			this.RankedNewRatingText.text = num.ToString();
			this.RankedCurrentBadgeRatingText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("reward_tier", ELocalizedTextCase.UPPER_CASE), skillRatingTierNumber + 1) + " - " + ServiceProvider.GetService<LocalizationService>().GetPlayerRankName(RatingUtil.GetSkillRatingTierByPosition(skillRatingTierNumber), ELocalizedTextCase.UPPER_CASE);
			this.RankedNextBadgeRatingText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("reward_tier", ELocalizedTextCase.UPPER_CASE), skillRatingTierNumber2 + 1) + " - " + ServiceProvider.GetService<LocalizationService>().GetPlayerRankName(RatingUtil.GetSkillRatingTierByPosition(skillRatingTierNumber2), ELocalizedTextCase.UPPER_CASE);
			this.GlobalPositionText.gameObject.SetActive(false);
		}

		// Token: 0x06000E85 RID: 3717 RVA: 0x000579C0 File Offset: 0x00055BC0
		public void Update()
		{
			if (this._test && OfflineInformation.OfflineUi)
			{
				this.SetStartData();
				this.SetData("FernandoRojas", this._testAvatar, this._oldmatches, this._newmatches, this._oldrating, this._newrating);
				this._test = false;
				this._EventTime = 0f;
			}
			if (this._canRun)
			{
				this._EventTime += Time.deltaTime;
				if (this._eventStructs.Count > 0)
				{
					this._canRun = EventUpdateHelper.IsTimeReady(this._EventTime, this.GetLastTimedEvent(), true, false);
				}
				else
				{
					this._canRun = false;
				}
			}
			foreach (RankingEventStruct rankingEventStruct in this._eventStructs)
			{
				switch (rankingEventStruct.Type)
				{
				case RankingEventStruct.EventStructType.PLACEMENTS_IN:
					if (this.PlayerUnranked.activeSelf != !this._AlreadyRankedSet)
					{
						this.PlayerUnranked.SetActive(!this._AlreadyRankedSet);
					}
					if (this.PlayerUnrankedAnim.isInitialized)
					{
						this.PlayerUnrankedAnim.SetBool(InGameEndmatchRankingView.animator_unranked_hash, EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, false, true));
					}
					break;
				case RankingEventStruct.EventStructType.PLACEMENTS_MATCHS:
					rankingEventStruct.PlacementsModeText.text = EventUpdateHelper.LerpIntValueWithMax(this._EventTime, rankingEventStruct.IntFrom, rankingEventStruct.IntTo, 25, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration);
					rankingEventStruct.PlacementsModeFillbar.fillAmount = EventUpdateHelper.LerpFloatValue(this._EventTime, rankingEventStruct.FloatFrom, rankingEventStruct.FloatTo, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration);
					EventUpdateHelper.PlayBarFill(this.BarFillAudio1, this._EventTime, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration, true);
					break;
				case RankingEventStruct.EventStructType.PLACEMENTS_MODE:
					rankingEventStruct.PlacementsModeText.text = EventUpdateHelper.LerpIntValueWithMax(this._EventTime, rankingEventStruct.IntFrom, rankingEventStruct.IntTo, 5, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration);
					rankingEventStruct.PlacementsModeFillbar.fillAmount = EventUpdateHelper.LerpFloatValue(this._EventTime, rankingEventStruct.FloatFrom, rankingEventStruct.FloatTo, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration);
					EventUpdateHelper.PlayBarFill(this.BarFillAudio2, this._EventTime, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration, true);
					break;
				case RankingEventStruct.EventStructType.PLACEMENTS_MATCHS_COMPLETED:
					if (rankingEventStruct.PlacementsModeAnimator.isInitialized)
					{
						rankingEventStruct.PlacementsModeAnimator.SetBool(InGameEndmatchRankingView.animator_unranked_active_hash, EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, rankingEventStruct.BoolFrom, rankingEventStruct.BoolTo));
					}
					break;
				case RankingEventStruct.EventStructType.PLACEMENTS_MODE_COMPLETED:
					if (rankingEventStruct.PlacementsModeAnimator.isInitialized)
					{
						rankingEventStruct.PlacementsModeAnimator.SetBool(InGameEndmatchRankingView.animator_unranked_active_hash, EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, rankingEventStruct.BoolFrom, rankingEventStruct.BoolTo));
					}
					break;
				case RankingEventStruct.EventStructType.PLACEMENTS_ALLMODE_COMPLETED:
					if (rankingEventStruct.PlacementsModeAnimator.isInitialized)
					{
						rankingEventStruct.PlacementsModeAnimator.SetBool(InGameEndmatchRankingView.animator_unranked_active_hash, EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, rankingEventStruct.BoolFrom, rankingEventStruct.BoolTo));
					}
					break;
				case RankingEventStruct.EventStructType.PLACEMENTS_RANKED_NOW:
					if (EventUpdateHelper.IsTimeReadyOnce(this._EventTime, rankingEventStruct.StartTime, false, true, ref rankingEventStruct.Once))
					{
						UIManager.Instance.ChangeState("UNLOCKED_LEADERBOARDS");
					}
					if (EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, false, true))
					{
						this.RankedOldRatingText.text = this._newrating.ToString();
						this.RankedNewRatingText.text = this._newrating.ToString();
					}
					else
					{
						this.RankedOldRatingText.text = this._oldrating.ToString();
						this.RankedNewRatingText.text = this._oldrating.ToString();
					}
					break;
				case RankingEventStruct.EventStructType.PLACEMENTS_MATCH_INVALID:
					EventUpdateHelper.IsObjectActive(this._EventTime, rankingEventStruct.StartTime, false, rankingEventStruct.BoolTo, ref this.UnrankedMatchValid);
					break;
				case RankingEventStruct.EventStructType.RANKING_DISTRIBUTE:
					if (rankingEventStruct.RankedAnimator.isInitialized)
					{
						rankingEventStruct.RankedAnimator.SetBool(InGameEndmatchRankingView.animator_ranked_positive_hash, EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, false, rankingEventStruct.IntTo > rankingEventStruct.IntFrom));
					}
					if (rankingEventStruct.RankedAnimator.isInitialized)
					{
						rankingEventStruct.RankedAnimator.SetBool(InGameEndmatchRankingView.animator_ranked_negative_hash, EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, false, rankingEventStruct.IntTo < rankingEventStruct.IntFrom));
					}
					this.RankedNewRatingText.text = EventUpdateHelper.LerpIntValue(this._EventTime, rankingEventStruct.IntFrom, rankingEventStruct.IntTo, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration).ToString();
					EventUpdateHelper.PlayBarFill(this.BarFillAudio3, this._EventTime, rankingEventStruct.StartTime, rankingEventStruct.StartTime + rankingEventStruct.Duration, rankingEventStruct.IntFrom < rankingEventStruct.IntTo);
					break;
				case RankingEventStruct.EventStructType.RANKING_INCREASED:
					if (rankingEventStruct.RankedAnimator.isInitialized)
					{
						rankingEventStruct.RankedAnimator.SetBool(InGameEndmatchRankingView.animator_ranked_in_hash, EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, rankingEventStruct.BoolFrom, rankingEventStruct.BoolTo));
					}
					break;
				case RankingEventStruct.EventStructType.RANKING_MATCH_INVALID:
					EventUpdateHelper.IsObjectActive(this._EventTime, rankingEventStruct.StartTime, false, rankingEventStruct.BoolTo, ref this.RankedMatchValid);
					break;
				case RankingEventStruct.EventStructType.RANKING_BADGE:
					if (EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, false, rankingEventStruct.RankFrom > rankingEventStruct.RankTo))
					{
						this.RankedRankDropRatingText.text = rankingEventStruct.NewLimiarDown.ToString();
						this.RankedRankUpRatingText.text = rankingEventStruct.NewLimiarUp.ToString();
						this.RankedPlayerBadge.sprite = this.PlayerBadgeSprites[rankingEventStruct.RankTo];
						if (this.RankedBadgeAnimator.isInitialized)
						{
							this.RankedBadgeAnimator.SetBool(InGameEndmatchRankingView.animator_ranked_in_hash, rankingEventStruct.RankFrom > rankingEventStruct.RankTo);
						}
					}
					else
					{
						this.RankedRankDropRatingText.text = ((rankingEventStruct.RankFrom >= rankingEventStruct.RankTo) ? rankingEventStruct.OldLimiarDown : rankingEventStruct.NewLimiarDown).ToString();
						this.RankedRankUpRatingText.text = ((rankingEventStruct.RankFrom >= rankingEventStruct.RankTo) ? rankingEventStruct.OldLimiarUp : rankingEventStruct.NewLimiarUp).ToString();
						this.RankedPlayerBadge.sprite = this.PlayerBadgeSprites[(rankingEventStruct.RankFrom >= rankingEventStruct.RankTo) ? rankingEventStruct.RankFrom : rankingEventStruct.RankTo];
						if (this.RankedBadgeAnimator.isInitialized)
						{
							this.RankedBadgeAnimator.SetBool(InGameEndmatchRankingView.animator_ranked_in_hash, false);
						}
					}
					break;
				case RankingEventStruct.EventStructType.RANKING_DISTRIBUTE_IN:
					this._AlreadyRankedSet = EventUpdateHelper.IsTimeReady(this._EventTime, rankingEventStruct.StartTime, false, true);
					if (this.PlayerRanked.activeSelf != this._AlreadyRankedSet)
					{
						this.PlayerRanked.SetActive(this._AlreadyRankedSet);
					}
					break;
				}
			}
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x00058168 File Offset: 0x00056368
		private float GetLastTimedEvent()
		{
			if (this._eventStructs.Count <= 0)
			{
				return 0f;
			}
			float num = -1f;
			float num2 = -1f;
			foreach (RankingEventStruct rankingEventStruct in this._eventStructs)
			{
				if (num + num2 < rankingEventStruct.StartTime + rankingEventStruct.Duration)
				{
					num = rankingEventStruct.StartTime;
					num2 = rankingEventStruct.Duration;
				}
			}
			return num + num2;
		}

		// Token: 0x040012EC RID: 4844
		private static int animator_unranked_hash = Animator.StringToHash("on");

		// Token: 0x040012ED RID: 4845
		private static int animator_unranked_active_hash = Animator.StringToHash("achieved");

		// Token: 0x040012EE RID: 4846
		private static int animator_ranked_positive_hash = Animator.StringToHash("positive");

		// Token: 0x040012EF RID: 4847
		private static int animator_ranked_negative_hash = Animator.StringToHash("negative");

		// Token: 0x040012F0 RID: 4848
		private static int animator_ranked_in_hash = Animator.StringToHash("in");

		// Token: 0x040012F1 RID: 4849
		public GameObject PlayerUnranked;

		// Token: 0x040012F2 RID: 4850
		public GameObject PlayerRanked;

		// Token: 0x040012F3 RID: 4851
		public Animator PlayerUnrankedAnim;

		// Token: 0x040012F4 RID: 4852
		public VariedPitchAudioComponent BarFillAudio1;

		// Token: 0x040012F5 RID: 4853
		public VariedPitchAudioComponent BarFillAudio2;

		// Token: 0x040012F6 RID: 4854
		public VariedPitchAudioComponent BarFillAudio3;

		// Token: 0x040012F7 RID: 4855
		[Header("Unranked")]
		public Text UnrankedPlayerName;

		// Token: 0x040012F8 RID: 4856
		public RawImage UnrankedPlayerAvatar;

		// Token: 0x040012F9 RID: 4857
		public Text MatchsAmount;

		// Token: 0x040012FA RID: 4858
		public Image MatchsFillbar;

		// Token: 0x040012FB RID: 4859
		public Animator MatchsCompleted;

		// Token: 0x040012FC RID: 4860
		public Text TdmAmount;

		// Token: 0x040012FD RID: 4861
		public Text FfaAmount;

		// Token: 0x040012FE RID: 4862
		public Text CtpAmount;

		// Token: 0x040012FF RID: 4863
		public Text KothAmount;

		// Token: 0x04001300 RID: 4864
		public Text RoundsAmount;

		// Token: 0x04001301 RID: 4865
		public Image TdmFillbar;

		// Token: 0x04001302 RID: 4866
		public Image FfaFillbar;

		// Token: 0x04001303 RID: 4867
		public Image CtpFillbar;

		// Token: 0x04001304 RID: 4868
		public Image KothFillbar;

		// Token: 0x04001305 RID: 4869
		public Image RoundsFillbar;

		// Token: 0x04001306 RID: 4870
		public Animator TdmCompleted;

		// Token: 0x04001307 RID: 4871
		public Animator FfaCompleted;

		// Token: 0x04001308 RID: 4872
		public Animator CtpCompleted;

		// Token: 0x04001309 RID: 4873
		public Animator KothCompleted;

		// Token: 0x0400130A RID: 4874
		public Animator RoundsCompleted;

		// Token: 0x0400130B RID: 4875
		public Animator PerModeCompleted;

		// Token: 0x0400130C RID: 4876
		public GameObject UnrankedMatchValid;

		// Token: 0x0400130D RID: 4877
		[Header("Ranked")]
		public Text RankedPlayerName;

		// Token: 0x0400130E RID: 4878
		public RawImage RankedPlayerAvatar;

		// Token: 0x0400130F RID: 4879
		public Image RankedPlayerBadge;

		// Token: 0x04001310 RID: 4880
		public Animator RankedSkillRatingAnimator;

		// Token: 0x04001311 RID: 4881
		public Animator RankedSkillNotificationAnimator;

		// Token: 0x04001312 RID: 4882
		public GameObject RankedCircle;

		// Token: 0x04001313 RID: 4883
		public Text RankedOldRatingText;

		// Token: 0x04001314 RID: 4884
		public Text RankedNewRatingText;

		// Token: 0x04001315 RID: 4885
		public Animator RankedBadgeAnimator;

		// Token: 0x04001316 RID: 4886
		public Text RankedCurrentBadgeRatingText;

		// Token: 0x04001317 RID: 4887
		public Text RankedNextBadgeRatingText;

		// Token: 0x04001318 RID: 4888
		public Text GlobalPositionText;

		// Token: 0x04001319 RID: 4889
		public Text RankedRankDropRatingText;

		// Token: 0x0400131A RID: 4890
		public Text RankedRankUpRatingText;

		// Token: 0x0400131B RID: 4891
		public GameObject RankedMatchValid;

		// Token: 0x0400131C RID: 4892
		public Sprite[] PlayerBadgeSprites;

		// Token: 0x0400131D RID: 4893
		public float _EventTime;

		// Token: 0x0400131E RID: 4894
		private List<RankingEventStruct> _eventStructs = new List<RankingEventStruct>();

		// Token: 0x0400131F RID: 4895
		[Header("Testing...")]
		public bool _test;

		// Token: 0x04001320 RID: 4896
		public Texture _testAvatar;

		// Token: 0x04001321 RID: 4897
		public int[] _oldmatches = new int[4];

		// Token: 0x04001322 RID: 4898
		public int[] _newmatches = new int[4];

		// Token: 0x04001323 RID: 4899
		public int _oldrating;

		// Token: 0x04001324 RID: 4900
		public int _newrating;

		// Token: 0x04001325 RID: 4901
		public int _globalPosition;

		// Token: 0x04001326 RID: 4902
		public bool _canRun;

		// Token: 0x04001327 RID: 4903
		private bool _AlreadyRankedSet;
	}
}
