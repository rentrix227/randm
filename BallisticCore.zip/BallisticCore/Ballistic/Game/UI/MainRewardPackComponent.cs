﻿using System;
using System.Collections;
using System.Linq;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.Reward;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F1 RID: 497
	public class MainRewardPackComponent : PoolableComponent
	{
		// Token: 0x06000A04 RID: 2564 RVA: 0x0003B554 File Offset: 0x00039754
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Claim.onClick.AddListener(new UnityAction(this.OnButtonClicked));
			this.Close.onClick.AddListener(new UnityAction(this.OnCloseClicked));
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x0003B5A4 File Offset: 0x000397A4
		internal void SetData(RewardPackData rewardData, Action<RewardPackData, Action<bool, SteamItem[]>> onClaimReward, Action<MainRewardPackComponent> onFinished)
		{
			this._rewardData = rewardData;
			string[] array = rewardData.reward.ItemName.Split(new char[] { '#' });
			this.Timestamp.text = string.Empty;
			this.Description.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("reward_" + array[0], ELocalizedTextCase.NONE), array[1]);
			if (rewardData.reward.ItemDropList.Exists((ItemDrop t) => t.SteamId == 910))
			{
				for (int i = 0; i < this.Sides.Length; i++)
				{
					this.Sides[i].sprite = this.SideGold[i];
				}
			}
			else
			{
				for (int j = 0; j < this.Sides.Length; j++)
				{
					this.Sides[j].sprite = this.SideRegular[j];
				}
			}
			this.OnButtonClick = onClaimReward;
			this.OnFinished = onFinished;
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x000090A5 File Offset: 0x000072A5
		private void OnButtonClicked()
		{
			if (this.OnButtonClick != null)
			{
				this.OnButtonClick(this._rewardData, new Action<bool, SteamItem[]>(this.OnExchangeResult));
			}
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x0003B6B0 File Offset: 0x000398B0
		private void OnExchangeResult(bool value, SteamItem[] steamItems)
		{
			if (!value)
			{
				UIManager.Instance.DisableLayer(1);
				ServiceProvider.GetService<PopupService>().Show(EPopupType.STEAM_ACTION_FAILED, null, null, null, 0f);
				Debug.LogWarning("Could not finish transaction.");
				return;
			}
			this.Animator.SetTrigger("open");
			int num = steamItems.Sum((SteamItem t) => (int)((t.IdentityId != 910) ? 0U : t.Quantity));
			int num2 = steamItems.Sum((SteamItem t) => (int)((t.IdentityId != 900) ? 0U : t.Quantity));
			if (num > 0 && num2 > 0)
			{
				this.PrizeMetal.SetActive(false);
				this.PrizeGold.SetActive(false);
				this.PrizeDouble.SetActive(true);
				this.PrizeMetalDoubleText.text = num2.ToString();
				this.PrizeGoldDoubleText.text = num.ToString();
			}
			else if (num > 0)
			{
				this.PrizeMetal.SetActive(false);
				this.PrizeGold.SetActive(true);
				this.PrizeDouble.SetActive(false);
				this.PrizeGoldText.text = num.ToString();
			}
			else if (num2 > 0)
			{
				this.PrizeMetal.SetActive(true);
				this.PrizeGold.SetActive(false);
				this.PrizeDouble.SetActive(false);
				this.PrizeMetalText.text = num2.ToString();
			}
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x000090CF File Offset: 0x000072CF
		private void OnCloseClicked()
		{
			base.StartCoroutine(this.WaitAndClose());
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x0003B838 File Offset: 0x00039A38
		private IEnumerator WaitAndClose()
		{
			yield return new WaitForSeconds(1f);
			if (this.OnFinished != null)
			{
				this.OnFinished(this);
			}
			yield break;
		}

		// Token: 0x04000D5D RID: 3421
		public Animator Animator;

		// Token: 0x04000D5E RID: 3422
		public Text Description;

		// Token: 0x04000D5F RID: 3423
		public Text Timestamp;

		// Token: 0x04000D60 RID: 3424
		public Button Claim;

		// Token: 0x04000D61 RID: 3425
		public Button Close;

		// Token: 0x04000D62 RID: 3426
		public Image[] Sides;

		// Token: 0x04000D63 RID: 3427
		public GameObject PrizeMetal;

		// Token: 0x04000D64 RID: 3428
		public GameObject PrizeGold;

		// Token: 0x04000D65 RID: 3429
		public GameObject PrizeDouble;

		// Token: 0x04000D66 RID: 3430
		public Text PrizeMetalText;

		// Token: 0x04000D67 RID: 3431
		public Text PrizeGoldText;

		// Token: 0x04000D68 RID: 3432
		public Text PrizeMetalDoubleText;

		// Token: 0x04000D69 RID: 3433
		public Text PrizeGoldDoubleText;

		// Token: 0x04000D6A RID: 3434
		[Header("Reward Sprites")]
		public Sprite[] SideRegular;

		// Token: 0x04000D6B RID: 3435
		public Sprite[] SideGold;

		// Token: 0x04000D6C RID: 3436
		private RewardPackData _rewardData;

		// Token: 0x04000D6D RID: 3437
		private Action<RewardPackData, Action<bool, SteamItem[]>> OnButtonClick;

		// Token: 0x04000D6E RID: 3438
		private Action<MainRewardPackComponent> OnFinished;
	}
}
