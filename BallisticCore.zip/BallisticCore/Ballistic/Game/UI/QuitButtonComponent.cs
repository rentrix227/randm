﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001FC RID: 508
	public class QuitButtonComponent : MonoBehaviour
	{
		// Token: 0x06000A3B RID: 2619 RVA: 0x0000929E File Offset: 0x0000749E
		public void OnQuitClick()
		{
			Application.Quit();
		}
	}
}
