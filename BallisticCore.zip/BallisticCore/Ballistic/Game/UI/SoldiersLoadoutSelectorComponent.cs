﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000207 RID: 519
	public class SoldiersLoadoutSelectorComponent : MonoBehaviour
	{
		// Token: 0x06000A74 RID: 2676 RVA: 0x0003D274 File Offset: 0x0003B474
		public void Start()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.Button != null)
			{
				foreach (Button button2 in this.Button)
				{
					button2.onClick.AddListener(new UnityAction(this.OnSelect));
				}
			}
			this._soldiersService = ServiceProvider.GetService<SoldiersService>();
		}

		// Token: 0x06000A75 RID: 2677 RVA: 0x0003D2D8 File Offset: 0x0003B4D8
		internal void SetSelector(PlayerLoadoutData loadout, bool isSpawned)
		{
			this._loadout = loadout;
			foreach (Button button2 in this.Button)
			{
				button2.interactable = !isSpawned;
			}
		}

		// Token: 0x06000A76 RID: 2678 RVA: 0x00009562 File Offset: 0x00007762
		private void OnSelect()
		{
			this._soldiersService.DispatchLoadoutChanged(this._loadout);
		}

		// Token: 0x04000DEE RID: 3566
		public Button[] Button;

		// Token: 0x04000DEF RID: 3567
		private SoldiersService _soldiersService;

		// Token: 0x04000DF0 RID: 3568
		private PlayerLoadoutData _loadout;
	}
}
