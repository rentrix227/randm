﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002B5 RID: 693
	public class InGameEndmatchVoteView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000E9A RID: 3738 RVA: 0x0000BE47 File Offset: 0x0000A047
		protected override void Awake()
		{
			base.Awake();
			this._animator = base.GetComponent<Animator>();
		}

		// Token: 0x06000E9B RID: 3739 RVA: 0x0000BE5B File Offset: 0x0000A05B
		internal void Hide()
		{
			this._hidden = true;
		}

		// Token: 0x06000E9C RID: 3740 RVA: 0x0000BE64 File Offset: 0x0000A064
		public void Update()
		{
			if (this._hidden && this._animator != null && this._animator.isInitialized)
			{
				this._animator.SetBool("hide", true);
			}
		}

		// Token: 0x06000E9D RID: 3741 RVA: 0x0000BEA3 File Offset: 0x0000A0A3
		private void OnMapModeClick(int entry)
		{
			base._controller.VoteEntry(entry);
		}

		// Token: 0x06000E9E RID: 3742 RVA: 0x0005870C File Offset: 0x0005690C
		internal void SetData(EClientMode clientMode, List<MapModeEntry> votations, Dictionary<long, MapModeEntry> votes, bool canVote)
		{
			ulong num = GameMapModeConfigService.DefaultAnyMap.MapId;
			EGameMode egameMode = EGameMode.Any;
			int[] array = new int[(votations == null) ? 0 : votations.Count];
			if (votations != null && votations.Count > 0 && votes != null)
			{
				for (int i = 0; i < votations.Count; i++)
				{
					foreach (KeyValuePair<long, MapModeEntry> keyValuePair in votes)
					{
						if (keyValuePair.Value.GameMode == votations[i].GameMode && keyValuePair.Value.GameMap == votations[i].GameMap)
						{
							array[i]++;
						}
					}
				}
				int num2 = 0;
				num = (ulong)votations[0].GameMap;
				egameMode = votations[0].GameMode;
				for (int j = 1; j < votations.Count; j++)
				{
					if (array[num2] < array[j])
					{
						num2 = j;
						num = (ulong)votations[j].GameMap;
						egameMode = votations[j].GameMode;
					}
				}
			}
			if (this.MostVotedMap != null && num != GameMapModeConfigService.DefaultAnyMap.MapId)
			{
				GameMapConfig gameMapConfig = ServiceProvider.GetService<GameMapModeConfigService>().FindGameMapConfig(num);
				TextureHelper.LoadImageAsync(TextureHelper.GetMapIconPath(gameMapConfig, EImageSize.MEDIUM), this.MostVotedMap, false, EImageSource.STREAMINGASSETS);
			}
			if (this.MostVotedMode != null && egameMode != EGameMode.Any)
			{
				foreach (InGameEndmatchVoteView.ModeSprite modeSprite in this.ModeSprites)
				{
					if (modeSprite.GameMode == egameMode)
					{
						this.MostVotedMode.sprite = modeSprite.Sprite;
					}
				}
			}
			int num3 = 0;
			while (num3 < this.VoteComponents.Length && num3 < votations.Count)
			{
				this.VoteComponents[num3].SetData(num3, (ulong)votations[num3].GameMap, votations[num3].GameMode, votations[num3].Beta, array[num3], clientMode);
				if (clientMode == EClientMode.PLAYER)
				{
					this.VoteComponents[num3].OnMapModeClick = new Action<int>(this.OnMapModeClick);
				}
				else
				{
					this.VoteComponents[num3].OnMapModeClick = null;
				}
				num3++;
			}
		}

		// Token: 0x04001371 RID: 4977
		public Image MostVotedMap;

		// Token: 0x04001372 RID: 4978
		public Image MostVotedMode;

		// Token: 0x04001373 RID: 4979
		public VoteMapComponent[] VoteComponents;

		// Token: 0x04001374 RID: 4980
		public InGameEndmatchVoteView.ModeSprite[] ModeSprites;

		// Token: 0x04001375 RID: 4981
		private Animator _animator;

		// Token: 0x04001376 RID: 4982
		private bool _hidden;

		// Token: 0x020002B6 RID: 694
		[Serializable]
		public struct ModeSprite
		{
			// Token: 0x04001377 RID: 4983
			public EGameMode GameMode;

			// Token: 0x04001378 RID: 4984
			public Sprite Sprite;
		}

		// Token: 0x020002B7 RID: 695
		[Serializable]
		public struct MapSprite
		{
			// Token: 0x04001379 RID: 4985
			public string GameMap;

			// Token: 0x0400137A RID: 4986
			public Sprite Sprite;
		}
	}
}
