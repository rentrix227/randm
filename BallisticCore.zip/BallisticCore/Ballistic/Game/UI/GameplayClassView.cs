﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000277 RID: 631
	public class GameplayClassView : BaseView<GameplayClassController>
	{
		// Token: 0x06000D6C RID: 3436 RVA: 0x0000B333 File Offset: 0x00009533
		protected override void Awake()
		{
			base.Awake();
			this._fillParameterHash = Shader.PropertyToID("_Fill");
		}

		// Token: 0x06000D6D RID: 3437 RVA: 0x0004EF40 File Offset: 0x0004D140
		internal void SetClass(EHeroClass heroClass, string heroSkin)
		{
			for (int i = 0; i < this.ClassPortraits.Count; i++)
			{
				if (this.ClassPortraits[i].Class == heroClass)
				{
					this.ClassPortraits[i].HealthBar.gameObject.SetActive(true);
					TextureHelper.LoadImageAsync(TextureHelper.GetClassHudIconPath(heroSkin), this.ClassPortraitImage, false, EImageSource.RESOURCES);
					this._currentHealthBar = this.ClassPortraits[i].HealthBar;
					this.SetHealth(this._lastHealth, this._lastMaxHealth, true);
				}
				else
				{
					this.ClassPortraits[i].HealthBar.gameObject.SetActive(false);
				}
			}
		}

		// Token: 0x06000D6E RID: 3438 RVA: 0x0004EFFC File Offset: 0x0004D1FC
		internal void SetHealth(float health, float maxHealth, bool forceUpdate = false)
		{
			if (Math.Abs(this._lastHealth - health) > 0.001f || forceUpdate)
			{
				float num = health / maxHealth;
				if (this.HealthAnimator.isInitialized)
				{
					if (health < this._lastHealth)
					{
						this.HealthAnimator.SetTrigger(GameplayClassView._damageParameterHash);
					}
					else
					{
						this.HealthAnimator.SetTrigger(GameplayClassView._recoveryParameterHash);
					}
				}
				this._lastHealth = health;
				this._lastMaxHealth = maxHealth;
				int num2 = Mathf.CeilToInt(health * 100f);
				this.HealthAmount.text = num2.ToString();
				this._currentHealthBar.material.SetFloat(this._fillParameterHash, num);
			}
		}

		// Token: 0x06000D6F RID: 3439 RVA: 0x0004F0B8 File Offset: 0x0004D2B8
		internal void SetSkills(IEnumerable<HeroSkillData> skillData)
		{
			int num = 0;
			foreach (HeroSkillData heroSkillData in skillData)
			{
				this.Skills[num].skill = heroSkillData.Skill;
				string skillIconPath = TextureHelper.GetSkillIconPath(heroSkillData.Skill);
				TextureHelper.LoadImageAsync(skillIconPath, this.Skills[num].skillImage, false, EImageSource.RESOURCES);
				this.Skills[num].skillName.text = ServiceProvider.GetService<LocalizationService>().GetSkillName(heroSkillData.Skill.ToString(), ELocalizedTextCase.CAPITALIZE);
				num++;
			}
		}

		// Token: 0x06000D70 RID: 3440 RVA: 0x0004F17C File Offset: 0x0004D37C
		internal void SetSkillState(EHeroSkillV2 skill, SkillState state)
		{
			for (int i = 0; i < this.Skills.Count; i++)
			{
				if (this.Skills[i].skill == skill)
				{
					if (state.timerCounter != 0 && this.CheckRemainingTime(state))
					{
						this.Skills[i].stackCounter.text = this.RemainingTime(state).ToString("0.0") + "s";
					}
					else if (state.stackCounter != 0)
					{
						this.Skills[i].stackCounter.text = state.stackCounter.ToString() + "x";
					}
					if (state.isTriggered && !this.Skills[i].skillState.isTriggered)
					{
						this.Skills[i].isTriggered = true;
					}
					this.Skills[i].skillState = state;
					break;
				}
			}
		}

		// Token: 0x06000D71 RID: 3441 RVA: 0x0004F29C File Offset: 0x0004D49C
		public void Update()
		{
			for (int i = 0; i < this.Skills.Count; i++)
			{
				if (this.Skills[i].skillAnimator.isInitialized)
				{
					this.Skills[i].skillAnimator.SetBool(GameplayClassView._isPermanentParameterHash, this.Skills[i].skillState.isPermanent);
					this.Skills[i].skillAnimator.SetBool(GameplayClassView._isActiveParameterHash, this.Skills[i].skillState.isActive);
					this.Skills[i].skillAnimator.SetBool(GameplayClassView._stackedParameterHash, this.Skills[i].skillState.stackCounter != 0);
					this.Skills[i].skillAnimator.SetBool(GameplayClassView._timedParameterHash, this.Skills[i].skillState.timerCounter != 0);
					if (this.Skills[i].isTriggered)
					{
						this.Skills[i].isTriggered = false;
						this.Skills[i].skillAnimator.SetTrigger(GameplayClassView._triggerParameterHash);
					}
					if (this.Skills[i].skillState.timerCounter != 0 && this.CheckRemainingTime(this.Skills[i].skillState))
					{
						this.Skills[i].stackCounter.text = this.RemainingTime(this.Skills[i].skillState).ToString("0.0") + "s";
					}
				}
			}
			if (this.HealthAnimator.isInitialized)
			{
				this.HealthAnimator.SetFloat(GameplayClassView._dyingParameterHash, 1f - this._lastHealth / this._lastMaxHealth);
			}
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x0000B34B File Offset: 0x0000954B
		private bool CheckRemainingTime(SkillState state)
		{
			return Time.time - state.Timestamp < (float)state.timerCounter;
		}

		// Token: 0x06000D73 RID: 3443 RVA: 0x0000B364 File Offset: 0x00009564
		private float RemainingTime(SkillState state)
		{
			return (float)state.timerCounter - (Time.time - state.Timestamp);
		}

		// Token: 0x04001042 RID: 4162
		private static readonly int _isPermanentParameterHash = Animator.StringToHash("permanent");

		// Token: 0x04001043 RID: 4163
		private static readonly int _isActiveParameterHash = Animator.StringToHash("active");

		// Token: 0x04001044 RID: 4164
		private static readonly int _stackedParameterHash = Animator.StringToHash("stack");

		// Token: 0x04001045 RID: 4165
		private static readonly int _timedParameterHash = Animator.StringToHash("timer");

		// Token: 0x04001046 RID: 4166
		private static readonly int _triggerParameterHash = Animator.StringToHash("refresh");

		// Token: 0x04001047 RID: 4167
		private static readonly int _damageParameterHash = Animator.StringToHash("damage");

		// Token: 0x04001048 RID: 4168
		private static readonly int _recoveryParameterHash = Animator.StringToHash("recover");

		// Token: 0x04001049 RID: 4169
		private static readonly int _dyingParameterHash = Animator.StringToHash("dying");

		// Token: 0x0400104A RID: 4170
		public Text HealthAmount;

		// Token: 0x0400104B RID: 4171
		public Animator HealthAnimator;

		// Token: 0x0400104C RID: 4172
		public List<GameplayClassView.SkillContainer> Skills = new List<GameplayClassView.SkillContainer>();

		// Token: 0x0400104D RID: 4173
		public Image ClassPortraitImage;

		// Token: 0x0400104E RID: 4174
		public List<GameplayClassView.ClassPortraitEntry> ClassPortraits = new List<GameplayClassView.ClassPortraitEntry>();

		// Token: 0x0400104F RID: 4175
		private int _fillParameterHash;

		// Token: 0x04001050 RID: 4176
		private float _lastHealth;

		// Token: 0x04001051 RID: 4177
		private float _lastMaxHealth;

		// Token: 0x04001052 RID: 4178
		private Renderer _currentHealthBar;

		// Token: 0x02000278 RID: 632
		[Serializable]
		public class ClassPortraitEntry
		{
			// Token: 0x04001053 RID: 4179
			public EHeroClass Class;

			// Token: 0x04001054 RID: 4180
			public Renderer HealthBar;
		}

		// Token: 0x02000279 RID: 633
		[Serializable]
		public class SkillContainer
		{
			// Token: 0x04001055 RID: 4181
			public EHeroSkillV2 skill;

			// Token: 0x04001056 RID: 4182
			public Image skillImage;

			// Token: 0x04001057 RID: 4183
			public Animator skillAnimator;

			// Token: 0x04001058 RID: 4184
			public Text skillName;

			// Token: 0x04001059 RID: 4185
			public Text stackCounter;

			// Token: 0x0400105A RID: 4186
			public Image timerFillImage;

			// Token: 0x0400105B RID: 4187
			internal SkillState skillState;

			// Token: 0x0400105C RID: 4188
			internal bool isTriggered;
		}
	}
}
