﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001CF RID: 463
	public enum DamageAmount
	{
		// Token: 0x04000CB9 RID: 3257
		Low,
		// Token: 0x04000CBA RID: 3258
		Medium,
		// Token: 0x04000CBB RID: 3259
		High
	}
}
