﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E8 RID: 744
	public class MainGameVersionView : BaseView<MainController>
	{
		// Token: 0x06000F9A RID: 3994 RVA: 0x0000CD69 File Offset: 0x0000AF69
		protected override void Start()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Version.text = string.Format("BUILD v1.5.7 / {1}", BallisticVersion.VERSION.Remove(5), SystemInfo.graphicsDeviceType);
		}

		// Token: 0x040014C1 RID: 5313
		public Text Version;
	}
}
