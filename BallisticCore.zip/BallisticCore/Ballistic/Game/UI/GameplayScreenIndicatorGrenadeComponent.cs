﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001CD RID: 461
	public class GameplayScreenIndicatorGrenadeComponent : MonoBehaviour
	{
		// Token: 0x0600098E RID: 2446 RVA: 0x000089BA File Offset: 0x00006BBA
		public void SetTeam(UITeam team)
		{
			this.TeamAnimator.SetBool("isAlly", team == UITeam.Mine);
		}

		// Token: 0x0600098F RID: 2447 RVA: 0x000089D0 File Offset: 0x00006BD0
		public void SetDirection(Vector3 screenSpaceDirection)
		{
			this.DirectionPivot.localRotation = Quaternion.FromToRotation(Vector3.down, screenSpaceDirection);
		}

		// Token: 0x04000CAC RID: 3244
		public Animator TeamAnimator;

		// Token: 0x04000CAD RID: 3245
		public Transform DirectionPivot;
	}
}
