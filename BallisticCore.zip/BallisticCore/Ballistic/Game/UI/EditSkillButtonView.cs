﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200026A RID: 618
	public class EditSkillButtonView : BaseView<SkillsController>
	{
		// Token: 0x06000D3E RID: 3390 RVA: 0x0000B0C9 File Offset: 0x000092C9
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SkillDescription.onClick.AddListener(new UnityAction(this.OnSaveSkills));
		}

		// Token: 0x06000D3F RID: 3391 RVA: 0x0000B0F8 File Offset: 0x000092F8
		private void OnSaveSkills()
		{
			base._controller.SaveSelectedSkills();
		}

		// Token: 0x0400100C RID: 4108
		public Button SkillDescription;
	}
}
