﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001BF RID: 447
	public class CustomMatchChatEntryComponent : MonoBehaviour
	{
		// Token: 0x06000936 RID: 2358 RVA: 0x000085E1 File Offset: 0x000067E1
		protected void Update()
		{
			if (!this._enabled)
			{
				return;
			}
			this._visibilityAmount -= Time.deltaTime;
			if (this._visibilityAmount < 0f)
			{
				Object.Destroy(base.gameObject);
			}
		}

		// Token: 0x06000937 RID: 2359 RVA: 0x0000861C File Offset: 0x0000681C
		public void ConfigureText(string text, float visibilityAmount, Color color)
		{
			this.Text.text = text;
			this.Text.color = color;
			this._visibilityAmount = visibilityAmount;
			this._enabled = true;
		}

		// Token: 0x04000C33 RID: 3123
		public Text Text;

		// Token: 0x04000C34 RID: 3124
		protected bool _enabled;

		// Token: 0x04000C35 RID: 3125
		protected float _visibilityAmount = 999f;
	}
}
