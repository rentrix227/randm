﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002B2 RID: 690
	public class InGameEndmatchScoreView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000E94 RID: 3732 RVA: 0x00058450 File Offset: 0x00056650
		internal void SetData(EClientMode clientMode, EGameMode gameMode, bool yourWinner, int yourTeamScore, int enemyTeamScore, int yourTeamWins, int enemyTeamWins, Team yourTeam)
		{
			this.WinnerYourTeamRoot.SetActive(yourWinner);
			this.WinnerEnemyTeamRoot.SetActive(!yourWinner);
			this.WinnerYourTeamTextRoot.SetActive(clientMode == EClientMode.PLAYER);
			this.WinnerEnemyTeamTextRoot.SetActive(clientMode == EClientMode.PLAYER);
			this.WinnerTeamLogo.texture = this.TeamLogos[(int)((!yourWinner) ? ((yourTeam != Team.MFA) ? Team.MFA : Team.SMOKE) : yourTeam)];
			this.WinnerTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName((!yourWinner) ? ((yourTeam != Team.MFA) ? Team.MFA : Team.SMOKE) : yourTeam, ELocalizedTextCase.UPPER_CASE);
			this.LoserYourTeamRoot.SetActive(!yourWinner);
			this.LoserEnemyTeamRoot.SetActive(yourWinner);
			this.LoserYourTeamTextRoot.SetActive(clientMode == EClientMode.PLAYER);
			this.LoserEnemyTeamTextRoot.SetActive(clientMode == EClientMode.PLAYER);
			this.LoserTeamLogo.texture = this.TeamLogos[(int)(yourWinner ? ((yourTeam != Team.MFA) ? Team.MFA : Team.SMOKE) : yourTeam)];
			this.LoserTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(yourWinner ? ((yourTeam != Team.MFA) ? Team.MFA : Team.SMOKE) : yourTeam, ELocalizedTextCase.UPPER_CASE);
			if (gameMode == EGameMode.Rounds)
			{
				this.WinnerYourTeam.text = yourTeamWins.ToString();
				this.LoserYourTeam.text = yourTeamWins.ToString();
				this.WinnerEnemyTeam.text = enemyTeamWins.ToString();
				this.LoserEnemyTeam.text = enemyTeamWins.ToString();
			}
			else
			{
				this.WinnerYourTeam.text = yourTeamScore.ToString();
				this.LoserYourTeam.text = yourTeamScore.ToString();
				this.WinnerEnemyTeam.text = enemyTeamScore.ToString();
				this.LoserEnemyTeam.text = enemyTeamScore.ToString();
			}
		}

		// Token: 0x0400135D RID: 4957
		public GameObject WinnerYourTeamRoot;

		// Token: 0x0400135E RID: 4958
		public GameObject WinnerYourTeamTextRoot;

		// Token: 0x0400135F RID: 4959
		public GameObject WinnerEnemyTeamRoot;

		// Token: 0x04001360 RID: 4960
		public GameObject WinnerEnemyTeamTextRoot;

		// Token: 0x04001361 RID: 4961
		public GameObject LoserYourTeamRoot;

		// Token: 0x04001362 RID: 4962
		public GameObject LoserYourTeamTextRoot;

		// Token: 0x04001363 RID: 4963
		public GameObject LoserEnemyTeamRoot;

		// Token: 0x04001364 RID: 4964
		public GameObject LoserEnemyTeamTextRoot;

		// Token: 0x04001365 RID: 4965
		public Text WinnerYourTeam;

		// Token: 0x04001366 RID: 4966
		public Text WinnerEnemyTeam;

		// Token: 0x04001367 RID: 4967
		public RawImage WinnerTeamLogo;

		// Token: 0x04001368 RID: 4968
		public Text WinnerTeamNameText;

		// Token: 0x04001369 RID: 4969
		public Text LoserYourTeam;

		// Token: 0x0400136A RID: 4970
		public Text LoserEnemyTeam;

		// Token: 0x0400136B RID: 4971
		public RawImage LoserTeamLogo;

		// Token: 0x0400136C RID: 4972
		public Text LoserTeamNameText;

		// Token: 0x0400136D RID: 4973
		public Texture[] TeamLogos;
	}
}
