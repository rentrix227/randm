﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000216 RID: 534
	public class GameplayClassController : BaseController
	{
		// Token: 0x06000AC6 RID: 2758 RVA: 0x0003EB4C File Offset: 0x0003CD4C
		public GameplayClassController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._soldiersService = ServiceProvider.GetService<SoldiersService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnRecoveryHealth.AddListener(new Action<RecoverHealthEvent>(this.OnRecoveryHealth));
			this._networkGameService.OnWeaponStationEvent.AddListener(new Action<WeaponStationEvent>(this.OnWeaponStationEvent));
			this._localCharacterService.OnSkillStateUpdate += this.OnSkillStateUpdate;
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x0003EC04 File Offset: 0x0003CE04
		private void OnSkillStateUpdate(EHeroSkillV2 skill, SkillState state)
		{
			GameplayClassView view = base.GetView<GameplayClassView>();
			if (view != null)
			{
				view.SetSkillState(skill, state);
			}
		}

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0003EC2C File Offset: 0x0003CE2C
		public override void DisableController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			base.DisableController();
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnRecoveryHealth.RemoveListener(new Action<RecoverHealthEvent>(this.OnRecoveryHealth));
			this._networkGameService.OnWeaponStationEvent.RemoveListener(new Action<WeaponStationEvent>(this.OnWeaponStationEvent));
			this._localCharacterService.OnSkillStateUpdate -= this.OnSkillStateUpdate;
		}

		// Token: 0x06000AC9 RID: 2761 RVA: 0x0003ECB8 File Offset: 0x0003CEB8
		private void OnRecoveryHealth(RecoverHealthEvent recoverHealthEvent)
		{
			if (!UserProfile.IsMe(recoverHealthEvent.User))
			{
				return;
			}
			GameplayClassView view = base.GetView<GameplayClassView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.SetHealth((float)recoverHealthEvent.CurrentHealth, UserProfile.LocalGameClient.maxHealth, false);
			}
		}

		// Token: 0x06000ACA RID: 2762 RVA: 0x0003ED0C File Offset: 0x0003CF0C
		private void OnWeaponStationEvent(WeaponStationEvent evt)
		{
			if (!UserProfile.IsMe(evt.User))
			{
				return;
			}
			GameplayClassView view = base.GetView<GameplayClassView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.SetHealth((float)evt.MaxHealth, UserProfile.LocalGameClient.maxHealth, false);
			}
		}

		// Token: 0x06000ACB RID: 2763 RVA: 0x0003ED60 File Offset: 0x0003CF60
		private void OnUserHit(HitEvent evt)
		{
			if (!UserProfile.IsMe(evt.VictimGameClientId))
			{
				return;
			}
			GameplayClassView view = base.GetView<GameplayClassView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.SetHealth(evt.VictimRemainingLife, UserProfile.LocalGameClient.maxHealth, false);
			}
		}

		// Token: 0x06000ACC RID: 2764 RVA: 0x0003EDB4 File Offset: 0x0003CFB4
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayClassView gameplayClassView = view as GameplayClassView;
			if (gameplayClassView != null)
			{
				PlayerLoadoutData selectedLoadout = this._gameModeService.SelectedLoadout;
				HeroSkin heroSkin = this._soldiersService.GetHeroSkin(selectedLoadout);
				IEnumerable<HeroSkillData> selectedHeroSkills = this._soldiersService.GetSelectedHeroSkills(selectedLoadout);
				gameplayClassView.SetClass(selectedLoadout.GameItemData.GameItem.UniqueIdentifier, heroSkin.ItemModel);
				gameplayClassView.SetHealth(UserProfile.LocalGameClient.health, UserProfile.LocalGameClient.maxHealth, false);
				gameplayClassView.SetSkills(selectedHeroSkills);
				foreach (HeroSkillData heroSkillData in selectedHeroSkills)
				{
					gameplayClassView.SetSkillState(heroSkillData.Skill, this._localCharacterService.GetSkillState(heroSkillData.Skill));
				}
			}
		}

		// Token: 0x04000E50 RID: 3664
		private readonly GameModeService _gameModeService;

		// Token: 0x04000E51 RID: 3665
		private readonly SoldiersService _soldiersService;

		// Token: 0x04000E52 RID: 3666
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E53 RID: 3667
		private readonly LocalCharacterService _localCharacterService;
	}
}
