﻿using System;
using Aquiris.Ballistic.Game.Weapon;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200027A RID: 634
	public class GameplayCrosshairView : BaseView<GameplayCrosshairController>
	{
		// Token: 0x06000D78 RID: 3448 RVA: 0x0000B396 File Offset: 0x00009596
		internal void SetHitTrigger()
		{
			if (!this.CrosshairAnimator.isInitialized)
			{
				return;
			}
			this.CrosshairAnimator.SetTrigger(GameplayCrosshairView._animatorDamageFeedback);
		}

		// Token: 0x06000D79 RID: 3449 RVA: 0x0000B3B9 File Offset: 0x000095B9
		internal void SetKillTrigger()
		{
			if (!this.CrosshairAnimator.isInitialized)
			{
				return;
			}
			this.CrosshairAnimator.SetTrigger(GameplayCrosshairView._animatorKillFeedback);
		}

		// Token: 0x06000D7A RID: 3450 RVA: 0x0004F52C File Offset: 0x0004D72C
		internal void SetCrosshair(CrosshairType type)
		{
			if (!this.CrosshairAnimator.isInitialized)
			{
				return;
			}
			this.CrosshairAnimator.SetBool(GameplayCrosshairView._animatorNone, type == CrosshairType.None);
			this.CrosshairAnimator.SetBool(GameplayCrosshairView._animatorShotgun, type == CrosshairType.Shotgun);
			this.CrosshairAnimator.SetBool(GameplayCrosshairView._animatorPistol, type == CrosshairType.Pistol);
			this.CrosshairAnimator.SetBool(GameplayCrosshairView._animatorGrenadeLauncher, type == CrosshairType.Launcher);
			this.CrosshairAnimator.SetBool(GameplayCrosshairView._animatorDefault, type == CrosshairType.Default);
			this._currentType = type;
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x0000B3DC File Offset: 0x000095DC
		internal void SetTargeting(WeaponTargeting targeting)
		{
			if (!this.CrosshairAnimator.isInitialized)
			{
				return;
			}
			this.CrosshairAnimator.SetBool(GameplayCrosshairView._animatorFriend, targeting == WeaponTargeting.FRIEND);
			this.CrosshairAnimator.SetBool(GameplayCrosshairView._animatorEnemy, targeting == WeaponTargeting.ENEMY);
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x0004F5B8 File Offset: 0x0004D7B8
		internal void SetCurrentPrecision(float precision, float pulseAmount, float pulseTimeNormalized)
		{
			for (int i = 0; i < this.CrosshairConfigurations.Length; i++)
			{
				if (this.CrosshairConfigurations[i].Type == this._currentType)
				{
					float num = Mathf.Clamp01((precision - pulseAmount * this.CrosshairConfigurations[i].PulseCurve.Evaluate(pulseTimeNormalized)) / 100f);
					for (int j = 0; j < this.CrosshairConfigurations[i].CrosshairParts.Length; j++)
					{
						this.CrosshairConfigurations[i].CrosshairParts[j].SetSpread(num);
					}
					for (int k = 0; k < this.CrosshairConfigurations[i].RendererParts.Length; k++)
					{
						this.CrosshairConfigurations[i].RendererParts[k].SetSpread(num);
					}
				}
			}
		}

		// Token: 0x0400105D RID: 4189
		private static readonly int _animatorNone = Animator.StringToHash("none");

		// Token: 0x0400105E RID: 4190
		private static readonly int _animatorShotgun = Animator.StringToHash("shotgun");

		// Token: 0x0400105F RID: 4191
		private static readonly int _animatorGrenadeLauncher = Animator.StringToHash("grenade_launcher");

		// Token: 0x04001060 RID: 4192
		private static readonly int _animatorPistol = Animator.StringToHash("pistol");

		// Token: 0x04001061 RID: 4193
		private static readonly int _animatorDefault = Animator.StringToHash("default");

		// Token: 0x04001062 RID: 4194
		private static readonly int _animatorKillFeedback = Animator.StringToHash("kill_feedback");

		// Token: 0x04001063 RID: 4195
		private static readonly int _animatorDamageFeedback = Animator.StringToHash("damage_feedback");

		// Token: 0x04001064 RID: 4196
		private static readonly int _animatorEnemy = Animator.StringToHash("enemy");

		// Token: 0x04001065 RID: 4197
		private static readonly int _animatorFriend = Animator.StringToHash("friend");

		// Token: 0x04001066 RID: 4198
		public Animator CrosshairAnimator;

		// Token: 0x04001067 RID: 4199
		public CrosshairConfiguration[] CrosshairConfigurations;

		// Token: 0x04001068 RID: 4200
		public float MaxPrecisionChangeSpeed = 0.3f;

		// Token: 0x04001069 RID: 4201
		private CrosshairType _currentType = CrosshairType.None;
	}
}
