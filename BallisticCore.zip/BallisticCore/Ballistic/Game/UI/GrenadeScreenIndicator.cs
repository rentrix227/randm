﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000296 RID: 662
	internal class GrenadeScreenIndicator : BaseScreenIndicator
	{
		// Token: 0x06000E24 RID: 3620 RVA: 0x0005436C File Offset: 0x0005256C
		internal void UpdateMarker()
		{
			base.UpdateMarkerPosition(this.GrenadeTransform.position);
			if (Vector3.Distance(this._clampedScreenPosition, this._unclampedScreenPosition) > 0.01f)
			{
				Vector3 vector;
				vector..ctor(this._unclampedScreenPosition.x - this._clampedScreenPosition.x, this._unclampedScreenPosition.y - this._clampedScreenPosition.y - 0.05f, 0f);
				this.IndicatorComponent.SetDirection(vector);
			}
			else
			{
				this.IndicatorComponent.SetDirection(Vector3.down);
			}
		}

		// Token: 0x06000E25 RID: 3621 RVA: 0x0000B92D File Offset: 0x00009B2D
		internal void SetTeam(UITeam team)
		{
			this.IndicatorComponent.SetTeam(team);
		}

		// Token: 0x040011F9 RID: 4601
		internal GameplayScreenIndicatorGrenadeComponent IndicatorComponent;

		// Token: 0x040011FA RID: 4602
		internal Transform GrenadeTransform;
	}
}
