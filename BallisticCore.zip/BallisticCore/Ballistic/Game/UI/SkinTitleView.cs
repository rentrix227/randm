﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000311 RID: 785
	public class SkinTitleView : BaseView<InventoryController>
	{
		// Token: 0x06001090 RID: 4240 RVA: 0x000601D0 File Offset: 0x0005E3D0
		internal void SetData(WeaponSkinData weaponSkinData)
		{
			this.SkinTitleText.text = weaponSkinData.CurrentName.ToUpper();
			this.SkinRarityText.text = ServiceProvider.GetService<LocalizationService>().Get("rarity_" + weaponSkinData.WeaponSkin.Rarity.ToString().ToLowerInvariant(), ELocalizedTextCase.NONE);
			this.SkinRarityText.color = RarityHelper.GetRarityColor(weaponSkinData.WeaponSkin.Rarity);
		}

		// Token: 0x040015CA RID: 5578
		public Text SkinTitleText;

		// Token: 0x040015CB RID: 5579
		public Text SkinRarityText;
	}
}
