﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002A6 RID: 678
	public class InGameEndmatchHeaderView : GameplayBaseChatView
	{
		// Token: 0x06000E67 RID: 3687 RVA: 0x00055DEC File Offset: 0x00053FEC
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._chatEntries = new HighSpeedArray<ChatEntry>(40);
			this.ChannelAll.onValueChanged.AddListener(new UnityAction<bool>(this.OnSetChannelAll));
			this.ChannelTeam.onValueChanged.AddListener(new UnityAction<bool>(this.OnSetChannelTeam));
			this.QuitButton.onClick.AddListener(new UnityAction(this.RequestQuitPopUp));
			this.InputField.onValueChanged.AddListener(new UnityAction<string>(this.OnInputTextChange));
			this.InputField.onEndEdit.AddListener(new UnityAction<string>(this.OnSubmitText));
			this.HideInputField();
			this.ChatText.text = string.Empty;
		}

		// Token: 0x06000E68 RID: 3688 RVA: 0x0000BBBD File Offset: 0x00009DBD
		private void OnSetChannelTeam(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.SetTeamOnly(true);
		}

		// Token: 0x06000E69 RID: 3689 RVA: 0x0000BBDD File Offset: 0x00009DDD
		private void OnSetChannelAll(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.SetTeamOnly(false);
		}

		// Token: 0x06000E6A RID: 3690 RVA: 0x0000BBFD File Offset: 0x00009DFD
		internal void SetServerOffline(bool serverIsOffline)
		{
			this.TimeToNextMatchGroup.SetActive(!serverIsOffline);
			this.ServerIsOfflineGroup.SetActive(serverIsOffline);
		}

		// Token: 0x06000E6B RID: 3691 RVA: 0x00055EBC File Offset: 0x000540BC
		internal override void AddTextEntry(string entryText)
		{
			if (!this.ChatBox.isOn)
			{
				this.ChatBox.isOn = true;
			}
			ChatEntry chatEntry = new ChatEntry
			{
				EntryText = entryText,
				Timestamp = Time.time
			};
			this._chatEntries.Add(chatEntry);
			while (this._chatEntries.Length > 30)
			{
				this._chatEntries.RemoveAt(0);
			}
			string text = string.Empty;
			for (int i = 0; i < this._chatEntries.Length; i++)
			{
				text += this._chatEntries[i].EntryText;
			}
			this.ChatText.text = text;
		}

		// Token: 0x06000E6C RID: 3692 RVA: 0x0000BC1A File Offset: 0x00009E1A
		internal override bool IsTyping()
		{
			return this.InputField.isFocused;
		}

		// Token: 0x06000E6D RID: 3693 RVA: 0x0000BC27 File Offset: 0x00009E27
		internal override void SetTeamOnly(bool teamOnly)
		{
			this._isSetting = true;
			this._teamOnly = teamOnly;
			this.ChannelAll.isOn = !teamOnly;
			this.ChannelTeam.isOn = teamOnly;
			this._isSetting = false;
		}

		// Token: 0x06000E6E RID: 3694 RVA: 0x0000BC59 File Offset: 0x00009E59
		internal override void FocusInputField()
		{
			if (EventSystem.current != null)
			{
				EventSystem.current.SetSelectedGameObject(this.InputField.gameObject);
			}
			this.InputField.OnPointerClick(new PointerEventData(EventSystem.current));
		}

		// Token: 0x06000E6F RID: 3695 RVA: 0x0000BC95 File Offset: 0x00009E95
		internal override void HideInputField()
		{
			this.ClearInputField();
		}

		// Token: 0x06000E70 RID: 3696 RVA: 0x00055F7C File Offset: 0x0005417C
		internal void UpdateTimeRemaining(int timeRemaining)
		{
			if (timeRemaining < 0)
			{
				this.TimeForNextMatch.text = "--:--";
				return;
			}
			int num = timeRemaining / 60;
			int num2 = timeRemaining % 60;
			this.TimeForNextMatch.text = StringUtils.Time00to99[num] + ":" + StringUtils.Time00to99[num2];
		}

		// Token: 0x06000E71 RID: 3697 RVA: 0x0000BC9D File Offset: 0x00009E9D
		private void ClearInputField()
		{
			this.InputField.text = string.Empty;
			this.InputField.ForceLabelUpdate();
		}

		// Token: 0x06000E72 RID: 3698 RVA: 0x00055FD0 File Offset: 0x000541D0
		private void OnSubmitText(string text)
		{
			string text2 = text.Trim();
			if (string.IsNullOrEmpty(text2))
			{
				return;
			}
			base._controller.OnTextInput(text2, this._teamOnly && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
			this.ClearInputField();
			this.FocusInputField();
		}

		// Token: 0x06000E73 RID: 3699 RVA: 0x00056024 File Offset: 0x00054224
		private void OnInputTextChange(string text)
		{
			if (text == "/all")
			{
				base._controller.SetTeamOnly(false);
				this.ClearInputField();
			}
			else if (text == "/team")
			{
				base._controller.SetTeamOnly(true);
				this.ClearInputField();
			}
		}

		// Token: 0x06000E74 RID: 3700 RVA: 0x0000BCBA File Offset: 0x00009EBA
		private void RequestQuitPopUp()
		{
			base._controller.RequestPopupQuit();
		}

		// Token: 0x040012AB RID: 4779
		public Text TimeForNextMatch;

		// Token: 0x040012AC RID: 4780
		public Toggle ChatBox;

		// Token: 0x040012AD RID: 4781
		public Toggle ChannelAll;

		// Token: 0x040012AE RID: 4782
		public Toggle ChannelTeam;

		// Token: 0x040012AF RID: 4783
		public InputField InputField;

		// Token: 0x040012B0 RID: 4784
		public Text ChatText;

		// Token: 0x040012B1 RID: 4785
		public Button QuitButton;

		// Token: 0x040012B2 RID: 4786
		public GameObject TimeToNextMatchGroup;

		// Token: 0x040012B3 RID: 4787
		public GameObject ServerIsOfflineGroup;

		// Token: 0x040012B4 RID: 4788
		private HighSpeedArray<ChatEntry> _chatEntries;

		// Token: 0x040012B5 RID: 4789
		private bool _teamOnly;

		// Token: 0x040012B6 RID: 4790
		private bool _isSetting;
	}
}
