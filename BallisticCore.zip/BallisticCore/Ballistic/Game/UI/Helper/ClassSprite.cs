﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI.Helper
{
	// Token: 0x02000256 RID: 598
	[Serializable]
	public struct ClassSprite
	{
		// Token: 0x04000FBB RID: 4027
		public EHeroClass HeroClass;

		// Token: 0x04000FBC RID: 4028
		public Sprite HeroIcon;

		// Token: 0x04000FBD RID: 4029
		public Sprite GoldIcon;
	}
}
