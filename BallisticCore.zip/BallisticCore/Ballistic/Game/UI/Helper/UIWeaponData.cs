﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI.Helper
{
	// Token: 0x02000258 RID: 600
	public class UIWeaponData : ScriptableObject
	{
		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000CF7 RID: 3319 RVA: 0x0000ADAF File Offset: 0x00008FAF
		private static UIWeaponData Instance
		{
			get
			{
				if (UIWeaponData._instance == null)
				{
					UIWeaponData._instance = Resources.Load<UIWeaponData>("UIWeaponData");
					if (UIWeaponData._instance == null)
					{
						Debug.LogError("[UIWeaponData] Could not find UIWeaponData asset");
					}
				}
				return UIWeaponData._instance;
			}
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x0000ADEF File Offset: 0x00008FEF
		internal static int GetDamage(WeaponV4 weapon)
		{
			return Mathf.RoundToInt(weapon.ShootData.DamagePerShot * (float)weapon.ShootData.BulletsPerShot * 100f);
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x0004DCB8 File Offset: 0x0004BEB8
		internal static int GetAccuracy(WeaponV4 weapon)
		{
			return Mathf.RoundToInt((weapon.AimData.Precision - weapon.AimData.ShootPrecision / 2f + weapon.AimData.AimPrecision - weapon.AimData.AimShootPrecision / 2f) / 2f);
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x0000AE14 File Offset: 0x00009014
		internal static int GetFireRate(WeaponV4 weapon)
		{
			return Mathf.RoundToInt(1f / weapon.ShootData.FireRate * 60f);
		}

		// Token: 0x06000CFB RID: 3323 RVA: 0x0000AE32 File Offset: 0x00009032
		internal static int GetMobility(WeaponV4 weapon)
		{
			return Mathf.RoundToInt((weapon.WeaponData.MobilityModifier * 3f + weapon.WeaponData.AimingMobilityModifier * 1f) / 4f * 100f);
		}

		// Token: 0x06000CFC RID: 3324 RVA: 0x0004DD0C File Offset: 0x0004BF0C
		internal static int GetRange(WeaponV4 weapon)
		{
			int num = weapon.ShootData.DamageCurve.keys.Length - 1;
			float time = weapon.ShootData.DamageCurve.keys[0].time;
			float time2 = weapon.ShootData.DamageCurve.keys[num].time;
			float num2 = Mathf.InverseLerp(1f, weapon.ShootData.DamageCurve.keys[num].value, 0.5f);
			return Mathf.RoundToInt(Mathf.Lerp(time, time2, num2));
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x0000AE68 File Offset: 0x00009068
		internal static int GetDamage(WeaponData weapon)
		{
			return UIWeaponData.GetDamage(weapon.GameItem);
		}

		// Token: 0x06000CFE RID: 3326 RVA: 0x0000AE75 File Offset: 0x00009075
		internal static int GetAccuracy(WeaponData weapon)
		{
			return UIWeaponData.GetAccuracy(weapon.GameItem);
		}

		// Token: 0x06000CFF RID: 3327 RVA: 0x0000AE82 File Offset: 0x00009082
		internal static int GetFireRate(WeaponData weapon)
		{
			return UIWeaponData.GetFireRate(weapon.GameItem);
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x0000AE8F File Offset: 0x0000908F
		internal static int GetMobility(WeaponData weapon)
		{
			return UIWeaponData.GetMobility(weapon.GameItem);
		}

		// Token: 0x06000D01 RID: 3329 RVA: 0x0000AE9C File Offset: 0x0000909C
		internal static int GetRange(WeaponData weapon)
		{
			return UIWeaponData.GetRange(weapon.GameItem);
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x0000AEA9 File Offset: 0x000090A9
		internal static float GetDamageBarValue(float damage)
		{
			return UIWeaponData.Instance.DamageBarData.Evaluate(damage);
		}

		// Token: 0x06000D03 RID: 3331 RVA: 0x0000AEBB File Offset: 0x000090BB
		internal static float GetAccuracyBarValue(float accuracy)
		{
			return UIWeaponData.Instance.AccuracyBarData.Evaluate(accuracy);
		}

		// Token: 0x06000D04 RID: 3332 RVA: 0x0000AECD File Offset: 0x000090CD
		internal static float GetFireRateBarValue(float fireRate)
		{
			return UIWeaponData.Instance.FireRateBarData.Evaluate(fireRate);
		}

		// Token: 0x06000D05 RID: 3333 RVA: 0x0000AEDF File Offset: 0x000090DF
		internal static float GetMobilityBarValue(float mobility)
		{
			return UIWeaponData.Instance.MobilityBarData.Evaluate(mobility);
		}

		// Token: 0x06000D06 RID: 3334 RVA: 0x0000AEF1 File Offset: 0x000090F1
		internal static float GetRangeBarValue(float range)
		{
			return UIWeaponData.Instance.RangeBarData.Evaluate(range);
		}

		// Token: 0x06000D07 RID: 3335 RVA: 0x0000AF03 File Offset: 0x00009103
		internal static float GetDamageBarValue(WeaponData weapon)
		{
			return UIWeaponData.GetDamageBarValue((float)UIWeaponData.GetDamage(weapon));
		}

		// Token: 0x06000D08 RID: 3336 RVA: 0x0000AF11 File Offset: 0x00009111
		internal static float GetAccuracyBarValue(WeaponData weapon)
		{
			return UIWeaponData.GetAccuracyBarValue((float)UIWeaponData.GetAccuracy(weapon));
		}

		// Token: 0x06000D09 RID: 3337 RVA: 0x0000AF1F File Offset: 0x0000911F
		internal static float GetFireRateBarValue(WeaponData weapon)
		{
			return UIWeaponData.GetFireRateBarValue((float)UIWeaponData.GetFireRate(weapon));
		}

		// Token: 0x06000D0A RID: 3338 RVA: 0x0000AF2D File Offset: 0x0000912D
		internal static float GetMobilityBarValue(WeaponData weapon)
		{
			return UIWeaponData.GetMobilityBarValue((float)UIWeaponData.GetMobility(weapon));
		}

		// Token: 0x06000D0B RID: 3339 RVA: 0x0000AF3B File Offset: 0x0000913B
		internal static float GetRangeBarValue(WeaponData weapon)
		{
			return UIWeaponData.GetRangeBarValue((float)UIWeaponData.GetRange(weapon));
		}

		// Token: 0x06000D0C RID: 3340 RVA: 0x0000AF49 File Offset: 0x00009149
		internal static float GetDamageBarValue(WeaponV4 weapon)
		{
			return UIWeaponData.GetDamageBarValue((float)UIWeaponData.GetDamage(weapon));
		}

		// Token: 0x06000D0D RID: 3341 RVA: 0x0000AF57 File Offset: 0x00009157
		internal static float GetAccuracyBarValue(WeaponV4 weapon)
		{
			return UIWeaponData.GetAccuracyBarValue((float)UIWeaponData.GetAccuracy(weapon));
		}

		// Token: 0x06000D0E RID: 3342 RVA: 0x0000AF65 File Offset: 0x00009165
		internal static float GetFireRateBarValue(WeaponV4 weapon)
		{
			return UIWeaponData.GetFireRateBarValue((float)UIWeaponData.GetFireRate(weapon));
		}

		// Token: 0x06000D0F RID: 3343 RVA: 0x0000AF73 File Offset: 0x00009173
		internal static float GetMobilityBarValue(WeaponV4 weapon)
		{
			return UIWeaponData.GetMobilityBarValue((float)UIWeaponData.GetMobility(weapon));
		}

		// Token: 0x06000D10 RID: 3344 RVA: 0x0000AF81 File Offset: 0x00009181
		internal static float GetRangeBarValue(WeaponV4 weapon)
		{
			return UIWeaponData.GetRangeBarValue((float)UIWeaponData.GetRange(weapon));
		}

		// Token: 0x04000FBE RID: 4030
		public UIWeaponData.WeaponStatData DamageBarData;

		// Token: 0x04000FBF RID: 4031
		public UIWeaponData.WeaponStatData AccuracyBarData;

		// Token: 0x04000FC0 RID: 4032
		public UIWeaponData.WeaponStatData FireRateBarData;

		// Token: 0x04000FC1 RID: 4033
		public UIWeaponData.WeaponStatData MobilityBarData;

		// Token: 0x04000FC2 RID: 4034
		public UIWeaponData.WeaponStatData RangeBarData;

		// Token: 0x04000FC3 RID: 4035
		private static UIWeaponData _instance;

		// Token: 0x02000259 RID: 601
		[Serializable]
		public class WeaponStatData
		{
			// Token: 0x06000D12 RID: 3346 RVA: 0x0000AFA2 File Offset: 0x000091A2
			public float Evaluate(float val)
			{
				return Mathf.InverseLerp(this.MinValue, this.MaxValue, val);
			}

			// Token: 0x04000FC4 RID: 4036
			public float MinValue;

			// Token: 0x04000FC5 RID: 4037
			public float MaxValue = 100f;
		}
	}
}
