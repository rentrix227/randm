﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI.Helper
{
	// Token: 0x02000257 RID: 599
	internal static class EventUpdateHelper
	{
		// Token: 0x06000CEE RID: 3310 RVA: 0x0004DC18 File Offset: 0x0004BE18
		internal static void PlayBarFill(VariedPitchAudioComponent player, float time, float step1, float step2, bool positive)
		{
			player.Playing = time > step1 && time < step2;
			if (positive)
			{
				player.SetPitchFactor((time - step1) / (step2 - step1));
			}
			else
			{
				player.SetPitchFactor(1f - (time - step1) / (step2 - step1));
			}
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x0004DC68 File Offset: 0x0004BE68
		internal static string LerpIntValueWithMax(float time, float value1, float value2, int max, float from, float until)
		{
			return string.Concat(new object[]
			{
				EventUpdateHelper.LerpIntValue(time, value1, value2, from, until).ToString(),
				"<color=#4C4E51FF><size=32>/",
				max,
				"</size></color>"
			});
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x0000AD0E File Offset: 0x00008F0E
		internal static int LerpIntValue(float time, float value1, float value2, float from, float until)
		{
			return (int)EventUpdateHelper.LerpFloatValue(time, value1, value2, from, until);
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x0000AD1C File Offset: 0x00008F1C
		internal static float LerpFloatValue(float time, float value1, float value2, float from, float until)
		{
			return Mathf.Lerp(value1, value2, (time - from) / (until - from));
		}

		// Token: 0x06000CF2 RID: 3314 RVA: 0x0000AD2D File Offset: 0x00008F2D
		internal static bool IsTimeReady(float time, float from, bool oldstate, bool newstate)
		{
			if (time > from)
			{
				return newstate;
			}
			return oldstate;
		}

		// Token: 0x06000CF3 RID: 3315 RVA: 0x0000AD39 File Offset: 0x00008F39
		internal static bool IsTimeReadyOnce(float time, float from, bool oldstate, bool newstate, ref bool once)
		{
			if (once)
			{
				once = time >= from;
			}
			if (time > from && !once)
			{
				once = true;
				return newstate;
			}
			return oldstate;
		}

		// Token: 0x06000CF4 RID: 3316 RVA: 0x0000AD63 File Offset: 0x00008F63
		internal static bool IsTimeIn(float time, float step1, float step2)
		{
			return time > step1 && time < step2;
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x0000AD73 File Offset: 0x00008F73
		internal static void IsObjectActive(float time, float from, bool oldstate, bool newstate, ref GameObject obj)
		{
			if (time > from)
			{
				if (obj.activeSelf != newstate)
				{
					obj.SetActive(newstate);
				}
			}
			else if (obj.activeSelf != oldstate)
			{
				obj.SetActive(oldstate);
			}
		}
	}
}
