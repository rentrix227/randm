﻿using System;
using System.Diagnostics;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000201 RID: 513
	public class ServerBrowserListItemComponent : PoolableComponent, IPointerClickHandler, IEventSystemHandler
	{
		// Token: 0x14000025 RID: 37
		// (add) Token: 0x06000A4D RID: 2637 RVA: 0x0003C9F8 File Offset: 0x0003ABF8
		// (remove) Token: 0x06000A4E RID: 2638 RVA: 0x0003CA30 File Offset: 0x0003AC30
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action<HostItem> OnSelected;

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x06000A4F RID: 2639 RVA: 0x0003CA68 File Offset: 0x0003AC68
		// (remove) Token: 0x06000A50 RID: 2640 RVA: 0x0003CAA0 File Offset: 0x0003ACA0
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action<HostItem> OnDoubleClicked;

		// Token: 0x06000A51 RID: 2641 RVA: 0x00009378 File Offset: 0x00007578
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Toggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnToggleValueChange));
			this._defaultMap = this.MapImage.sprite;
		}

		// Token: 0x06000A52 RID: 2642 RVA: 0x0003CAD8 File Offset: 0x0003ACD8
		internal void SetInfo(HostItem hostItem)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this._hostItem = hostItem;
			this.NameText.text = hostItem.Name;
			this.MapText.text = service.GetMapName(hostItem.GameMap, ELocalizedTextCase.UPPER_CASE);
			GameMapConfig gameMapConfig = ServiceProvider.GetService<GameMapModeConfigService>().FindGameMapConfig(hostItem.GameMap);
			if (gameMapConfig != null)
			{
				TextureHelper.LoadImageAsync(TextureHelper.GetMapIconPath(gameMapConfig, EImageSize.SMALL), this.MapImage, false, EImageSource.STREAMINGASSETS);
			}
			else
			{
				this.MapImage.sprite = this._defaultMap;
			}
			this.ModeText.text = service.GetModeName(hostItem.GameMode, ELocalizedTextCase.UPPER_CASE);
			this.LockImage.gameObject.SetActive(hostItem.Password);
			this.ShieldImage.gameObject.SetActive(hostItem.VacSecure);
			this.PlayersText.text = string.Format("{0}/{1}", hostItem.NumPlayers, hostItem.MaxPlayers);
			LatencyDefinitionData.LatencyDefinition definition = LatencyDefinitionData.GetDefinition(hostItem);
			this.LatencyText.text = ((definition.Value == 0U) ? definition.Region : (definition.Value + "ms"));
			this.LatencyText.color = definition.UiColor;
			if (hostItem.Status == EServerStatus.IN_GAME)
			{
				this.StatusText.text = ServiceProvider.GetService<LocalizationService>().Get("status_ingame", ELocalizedTextCase.UPPER_CASE);
			}
			else if (hostItem.Status == EServerStatus.IN_LOBBY)
			{
				this.StatusText.text = ServiceProvider.GetService<LocalizationService>().Get("status_lobby", ELocalizedTextCase.UPPER_CASE);
			}
			else if (hostItem.Status == EServerStatus.DEDICATED)
			{
				this.StatusText.text = ServiceProvider.GetService<LocalizationService>().Get("status_dedicated", ELocalizedTextCase.UPPER_CASE);
			}
			else if (hostItem.Status == EServerStatus.OFFICIAL)
			{
				this.StatusText.text = ServiceProvider.GetService<LocalizationService>().Get("status_official", ELocalizedTextCase.UPPER_CASE);
			}
			if (hostItem.MaxPing > 0)
			{
				Text nameText = this.NameText;
				nameText.text = nameText.text + " " + string.Format(service.Get("max_ping", ELocalizedTextCase.NONE), hostItem.MaxPing);
			}
		}

		// Token: 0x06000A53 RID: 2643 RVA: 0x000093B2 File Offset: 0x000075B2
		internal CSteamID GetId()
		{
			return this._hostItem.SteamId;
		}

		// Token: 0x06000A54 RID: 2644 RVA: 0x000093BF File Offset: 0x000075BF
		internal void ListenOnSelected(Action<HostItem> onSelected)
		{
			this.OnSelected = onSelected;
		}

		// Token: 0x06000A55 RID: 2645 RVA: 0x000093C8 File Offset: 0x000075C8
		internal void ListenOnDoubleClick(Action<HostItem> onDoubleClick)
		{
			this.OnDoubleClicked = onDoubleClick;
		}

		// Token: 0x06000A56 RID: 2646 RVA: 0x000093D1 File Offset: 0x000075D1
		internal void SetSelected(bool isEnabled)
		{
			this.Toggle.isOn = isEnabled;
		}

		// Token: 0x06000A57 RID: 2647 RVA: 0x000093DF File Offset: 0x000075DF
		public override void Dispose()
		{
			base.Dispose();
			this.OnSelected = null;
			this.OnDoubleClicked = null;
		}

		// Token: 0x06000A58 RID: 2648 RVA: 0x0003CD08 File Offset: 0x0003AF08
		public void OnPointerClick(PointerEventData eventData)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			float time = Time.time;
			if (time - this._clickTime <= 0.25f && this.OnDoubleClicked != null)
			{
				this.OnDoubleClicked(this._hostItem);
			}
			this._clickTime = time;
		}

		// Token: 0x06000A59 RID: 2649 RVA: 0x000093F5 File Offset: 0x000075F5
		private void OnToggleValueChange(bool value)
		{
			if (!value)
			{
				return;
			}
			if (this.OnSelected != null)
			{
				this.OnSelected(this._hostItem);
			}
		}

		// Token: 0x04000DBE RID: 3518
		private HostItem _hostItem;

		// Token: 0x04000DBF RID: 3519
		public Toggle Toggle;

		// Token: 0x04000DC0 RID: 3520
		public Image MapImage;

		// Token: 0x04000DC1 RID: 3521
		public Image LockImage;

		// Token: 0x04000DC2 RID: 3522
		public Image ShieldImage;

		// Token: 0x04000DC3 RID: 3523
		public Text NameText;

		// Token: 0x04000DC4 RID: 3524
		public Text MapText;

		// Token: 0x04000DC5 RID: 3525
		public Text ModeText;

		// Token: 0x04000DC6 RID: 3526
		public Text PlayersText;

		// Token: 0x04000DC7 RID: 3527
		public Text LatencyText;

		// Token: 0x04000DC8 RID: 3528
		public Text StatusText;

		// Token: 0x04000DCB RID: 3531
		private Sprite _defaultMap;

		// Token: 0x04000DCC RID: 3532
		private const float _doubleClickInterval = 0.25f;

		// Token: 0x04000DCD RID: 3533
		private float _clickTime;
	}
}
