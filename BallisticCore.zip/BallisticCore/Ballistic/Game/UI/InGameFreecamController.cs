﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000228 RID: 552
	public class InGameFreecamController : BaseController
	{
		// Token: 0x06000B72 RID: 2930 RVA: 0x00009E4F File Offset: 0x0000804F
		public InGameFreecamController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._inputControlService = ServiceProvider.GetService<InputControlService>();
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x00044B98 File Offset: 0x00042D98
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameFreecamView inGameFreecamView = view as InGameFreecamView;
			if (inGameFreecamView != null)
			{
				this._inputControlService.SetMouse(inGameFreecamView, false);
			}
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x00044BD8 File Offset: 0x00042DD8
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameFreecamView inGameFreecamView = view as InGameFreecamView;
			if (inGameFreecamView != null)
			{
				this._inputControlService.RemoveMouse(inGameFreecamView);
			}
		}

		// Token: 0x04000EE2 RID: 3810
		private readonly InputControlService _inputControlService;
	}
}
