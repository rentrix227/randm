﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Configuration.Steam;
using Aquiris.Ballistic.Network.Connection;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000214 RID: 532
	public class CustomMatchController : BaseController
	{
		// Token: 0x06000AAF RID: 2735 RVA: 0x00009910 File Offset: 0x00007B10
		public CustomMatchController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._popupService = ServiceProvider.GetService<PopupService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
		}

		// Token: 0x06000AB0 RID: 2736 RVA: 0x0003E420 File Offset: 0x0003C620
		internal void CreateLobby(string lobbyName, GameMapConfig map, EGameMode mode, bool isPrivate, string password)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._currentMap = map;
			this._currentMode = mode;
			SteamConfig steamConfig = new SteamConfig
			{
				MaxPlayers = 10U,
				MaxSpectators = 3U,
				MaxPing = 0,
				ServerName = ((!string.IsNullOrEmpty(lobbyName.Trim())) ? lobbyName : (SteamFriends.GetPersonaName() + "'s server")),
				PrivateMatch = false,
				MatchTime = 600U,
				GameMode = mode,
				GameMap = map.MapId,
				Password = password,
				TeamDeathMatch = 10U,
				RoundTime = 90U,
				WarmUpTime = 20f,
				DedicatedServer = true,
				OfficialServer = !string.IsNullOrEmpty(StatisticsConstants.GetOfficialAPI),
				OfficialApi = StatisticsConstants.GetOfficialAPI,
				BroadcastQuality = EConnectionQuality.P2PBroadcast,
				SteamPort = 8766,
				GamePort = 27015,
				QueryPort = 27016,
				BannerUrl = "https://i.imgur.com/vjlWbyS.png",
				ClickUrl = "https://steamcommunity.com/sharedfiles/filedetails/?id=2949256930",
				Owner = SteamUser.GetSteamID().m_SteamID,
				Beta = true
			};
			this._networkGameService.OnLobbyReady.AddListener(new Action(this.OnLobbyReady));
			this._networkGameService.OnLobbyEnter.AddListener(new Action(this.OnLobbyEnter));
			this._networkGameService.OnHostRunning.AddListener(new Action(this.OnHostRunning));
			this._networkGameService.OnHostInitError.AddListener(new Action(this.OnHostInitError));
			this._networkGameService.CreateLobby(steamConfig);
			this._popupService.Show(EPopupType.CREATING_MATCH, null, new Action<int>(this.OnStartCancel), null, 0f);
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x0003E5E4 File Offset: 0x0003C7E4
		internal void JoinLobby(CSteamID id, string password, EClientMode clientMode)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnClientConnectionStarted.AddListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnClientConnectionEstablished.AddListener(new Action(this.OnClientConnectionEstablished));
			this._networkGameService.OnClientConnectionFail.AddListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
			if (!string.IsNullOrEmpty(password))
			{
				this._networkGameService.JoinLobby(id, Crypto.ComputeMd5Hash(password), clientMode);
			}
			else
			{
				this._networkGameService.JoinLobby(id, null, clientMode);
			}
		}

		// Token: 0x06000AB2 RID: 2738 RVA: 0x00009944 File Offset: 0x00007B44
		internal void LeaveLobby()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.DisconnectFromServer();
			this._networkGameService.DestroyServer();
			this._networkGameService.LeaveCurrentLobby();
			UIManager.Instance.DisableLayer(4);
		}

		// Token: 0x06000AB3 RID: 2739 RVA: 0x0003E684 File Offset: 0x0003C884
		private GameMapConfig GetFinalMap(EGameMode mode)
		{
			if (this._currentMap.MapId != GameMapModeConfigService.DefaultAnyMap.MapId)
			{
				return this._currentMap;
			}
			IEnumerable<GameMapConfig> allAvailableGameMapsForGameMode = ServiceProvider.GetService<GameMapModeConfigService>().GetAllAvailableGameMapsForGameMode(mode);
			return allAvailableGameMapsForGameMode.ElementAt(Random.Range(0, allAvailableGameMapsForGameMode.Count<GameMapConfig>()));
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x0003E6D0 File Offset: 0x0003C8D0
		private EGameMode GetFinalMode(GameMapConfig gameMap)
		{
			if (this._currentMode != EGameMode.Any)
			{
				return this._currentMode;
			}
			IEnumerable<EGameMode> enumerable = ((gameMap.MapId != GameMapModeConfigService.DefaultAnyMap.MapId) ? ServiceProvider.GetService<GameMapModeConfigService>().GetAvailableGameModeList(gameMap) : ServiceProvider.GetService<GameMapModeConfigService>().GetAllPossibleGameModeList());
			return enumerable.ElementAt(Random.Range(1, enumerable.Count<EGameMode>()));
		}

		// Token: 0x06000AB5 RID: 2741 RVA: 0x0000997D File Offset: 0x00007B7D
		private void OnLobbyEnter()
		{
			this._networkGameService.OnLobbyEnter.RemoveListener(new Action(this.OnLobbyEnter));
		}

		// Token: 0x06000AB6 RID: 2742 RVA: 0x0003E734 File Offset: 0x0003C934
		private void OnLobbyReady()
		{
			this._networkGameService.OnLobbyReady.RemoveListener(new Action(this.OnLobbyReady));
			this._networkGameService.OnHostRunning.AddListener(new Action(this.OnHostRunning));
			this._networkGameService.OnHostInitError.AddListener(new Action(this.OnHostInitError));
			this._networkGameService.CreateServer(this._networkGameService.GetLobbyConfig());
			this._popupService.Show(EPopupType.CREATING_MATCH, null, new Action<int>(this.OnStartCancel), null, 0f);
		}

		// Token: 0x06000AB7 RID: 2743 RVA: 0x0003E7CC File Offset: 0x0003C9CC
		private void OnHostRunning()
		{
			Debug.Log("[CustomMatchController] Host Created.");
			this._networkGameService.OnHostRunning.RemoveListener(new Action(this.OnHostRunning));
			this._networkGameService.OnHostInitError.RemoveListener(new Action(this.OnHostInitError));
			this._networkGameService.OnClientConnectionStarted.AddListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnClientConnectionEstablished.AddListener(new Action(this.OnClientConnectionEstablished));
			this._networkGameService.OnClientConnectionFail.AddListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
			EGameMode finalMode = this.GetFinalMode(this._currentMap);
			GameMapConfig finalMap = this.GetFinalMap(finalMode);
			this._networkGameService.UpdateLobbyConfig(finalMap.MapId, finalMode);
			this._networkGameService.StartServer(finalMap, finalMode);
		}

		// Token: 0x06000AB8 RID: 2744 RVA: 0x0003E8A4 File Offset: 0x0003CAA4
		private void OnHostInitError()
		{
			Debug.Log("[CustomMatchController] Error Creating Host.");
			this._networkGameService.OnHostRunning.RemoveListener(new Action(this.OnHostRunning));
			this._networkGameService.OnHostInitError.RemoveListener(new Action(this.OnHostInitError));
			ServiceProvider.GetService<EventProxy>().StartCoroutine(this.HostInitCoroutine());
		}

		// Token: 0x06000AB9 RID: 2745 RVA: 0x0003E904 File Offset: 0x0003CB04
		private IEnumerator HostInitCoroutine()
		{
			yield return new WaitForSeconds(0.25f);
			this._popupService.Show(EPopupType.ERROR_CREATING_MATCH, null, new Action<int>(this.ErrorPopupClick), null, 0f);
			yield break;
		}

		// Token: 0x06000ABA RID: 2746 RVA: 0x0000999B File Offset: 0x00007B9B
		private void ErrorPopupClick(int i)
		{
			this._popupService.Hide(EPopupType.ERROR_CREATING_MATCH);
			this.LeaveLobby();
		}

		// Token: 0x06000ABB RID: 2747 RVA: 0x0003E920 File Offset: 0x0003CB20
		private void OnStartCancel(int value)
		{
			Debug.Log("[CustomMatchController] Cancelling Starting Host.");
			this._networkGameService.OnHostRunning.RemoveListener(new Action(this.OnHostRunning));
			this._networkGameService.OnHostInitError.RemoveListener(new Action(this.OnHostInitError));
			this.LeaveLobby();
		}

		// Token: 0x06000ABC RID: 2748 RVA: 0x000099AF File Offset: 0x00007BAF
		private void OnClientConnectionStarted()
		{
			ServiceProvider.GetService<PopupService>().Show(EPopupType.JOINING_MATCH, null, new Action<int>(this.OnJoinCancel), null, 0f);
		}

		// Token: 0x06000ABD RID: 2749 RVA: 0x0003E978 File Offset: 0x0003CB78
		private void OnJoinCancel(int value)
		{
			Debug.Log("[CustomMatchController] Cancelling Joining Host.");
			this._networkGameService.OnClientConnectionStarted.RemoveListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnClientConnectionEstablished.RemoveListener(new Action(this.OnClientConnectionEstablished));
			this._networkGameService.OnClientConnectionFail.RemoveListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
			this.LeaveLobby();
		}

		// Token: 0x06000ABE RID: 2750 RVA: 0x0003E9EC File Offset: 0x0003CBEC
		private void OnClientConnectionEstablished()
		{
			this._networkGameService.OnClientConnectionStarted.RemoveListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnClientConnectionEstablished.RemoveListener(new Action(this.OnClientConnectionEstablished));
			this._networkGameService.OnClientConnectionFail.RemoveListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
		}

		// Token: 0x06000ABF RID: 2751 RVA: 0x0003EA50 File Offset: 0x0003CC50
		private void OnClientConnectionFail(LeaveGameMotivation motivation)
		{
			this._networkGameService.OnClientConnectionStarted.RemoveListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnClientConnectionEstablished.RemoveListener(new Action(this.OnClientConnectionEstablished));
			this._networkGameService.OnClientConnectionFail.RemoveListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
			this._popupService.ShowConnectionFail(motivation);
			this.LeaveLobby();
		}

		// Token: 0x04000E48 RID: 3656
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E49 RID: 3657
		private readonly PopupService _popupService;

		// Token: 0x04000E4A RID: 3658
		private GameMapConfig _currentMap = GameMapModeConfigService.DefaultAnyMap;

		// Token: 0x04000E4B RID: 3659
		private EGameMode _currentMode;
	}
}
