﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002B4 RID: 692
	public class InGameEndmatchVictoryView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000E98 RID: 3736 RVA: 0x0005865C File Offset: 0x0005685C
		internal void SetData(EGameMode mode, int yourPosition)
		{
			bool flag = mode != EGameMode.FreeForAll && mode != EGameMode.Juggernaut;
			if (flag)
			{
				this.MatchStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_endgame_status_2", ELocalizedTextCase.UPPER_CASE);
				this.FfaPositionSuffix.text = string.Empty;
			}
			else
			{
				this.MatchStatusText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("your_position_x", ELocalizedTextCase.UPPER_CASE), "<color=#C4EBFFFF>" + yourPosition + "</color>");
				this.FfaPositionSuffix.text = ServiceProvider.GetService<LocalizationService>().Get("ordinal_suffix_" + yourPosition, ELocalizedTextCase.UPPER_CASE);
			}
		}

		// Token: 0x0400136F RID: 4975
		public Text MatchStatusText;

		// Token: 0x04001370 RID: 4976
		public Text FfaPositionSuffix;
	}
}
