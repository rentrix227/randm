﻿using System;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000270 RID: 624
	public class EditWeaponCurrentView : BaseView<SoldiersWeaponController>
	{
		// Token: 0x06000D53 RID: 3411 RVA: 0x0000B1DD File Offset: 0x000093DD
		internal void SetStartWeapon(PlayerWeaponData data, PlayerLoadoutV2 loadout)
		{
			this.WeaponComponent.SetData(data, loadout);
		}

		// Token: 0x04001014 RID: 4116
		public SoldiersWeaponComponent WeaponComponent;
	}
}
