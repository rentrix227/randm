﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200022B RID: 555
	public class InGameKillcamController : BaseController
	{
		// Token: 0x06000BAA RID: 2986 RVA: 0x00046A0C File Offset: 0x00044C0C
		public InGameKillcamController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._inputControlService = ServiceProvider.GetService<InputControlService>();
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnRecoveryHealth.AddListener(new Action<RecoverHealthEvent>(this.OnRecoveryHealth));
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnTeamQueueChanged.AddListener(new Action<TeamQueueChangedEvent>(this.OnTeamQueueChanged));
			this._networkGameService.OnUserListChanged.AddListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnSelectTeam.AddListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.AddListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnWeaponChange.AddListener(new Action<ChangeWeaponEvent>(this.OnWeaponChange));
			this._targetMetadata = null;
			ServiceProvider.GetService<EventProxy>().EUpdate.AddListener(new Action(this.Update));
		}

		// Token: 0x06000BAB RID: 2987 RVA: 0x00046B6C File Offset: 0x00044D6C
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnRecoveryHealth.RemoveListener(new Action<RecoverHealthEvent>(this.OnRecoveryHealth));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnWeaponChange.RemoveListener(new Action<ChangeWeaponEvent>(this.OnWeaponChange));
			this._networkGameService.OnTeamQueueChanged.RemoveListener(new Action<TeamQueueChangedEvent>(this.OnTeamQueueChanged));
			this._networkGameService.OnUserListChanged.RemoveListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnSelectTeam.RemoveListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.RemoveListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			ServiceProvider.GetService<EventProxy>().EUpdate.RemoveListener(new Action(this.Update));
		}

		// Token: 0x06000BAC RID: 2988 RVA: 0x00046CA4 File Offset: 0x00044EA4
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameKillcamView inGameKillcamView = view as InGameKillcamView;
			if (inGameKillcamView != null)
			{
				inGameKillcamView.SetActive(UserProfile.LocalGameClient.clientMode != EClientMode.SPECTATOR && this._gameModeService.GameMode != EGameMode.Rounds);
				this._inputControlService.SetMouse(inGameKillcamView, false);
			}
			InGameKillcamQueueView inGameKillcamQueueView = view as InGameKillcamQueueView;
			if (inGameKillcamQueueView != null)
			{
				this.UpdateKillCamQueueView(inGameKillcamQueueView);
				this._inputControlService.SetMouse(inGameKillcamQueueView, false);
			}
		}

		// Token: 0x06000BAD RID: 2989 RVA: 0x00046D34 File Offset: 0x00044F34
		private void UpdateKillCamQueueView(InGameKillcamQueueView killQueue)
		{
			if (!this._networkGameService.GetGameModeMetaData().QueueMetaDataList.Contains(UserProfile.LocalGameClient.gameClientId))
			{
				return;
			}
			int num = 0;
			EGameMode gameMode = this._gameModeService.GameMode;
			int num2;
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap)
				{
					if (keyValuePair.Value.ClientMode == EClientMode.PLAYER && (ETeamMode)keyValuePair.Value.Team == UserProfile.LocalGameClient.requestMode)
					{
						num++;
					}
				}
				num2 = (int)(this._networkGameService.GetGameModeMetaData().GameConfig.MaxPlayers / 2);
			}
			else
			{
				foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair2 in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap)
				{
					num++;
				}
				num2 = (int)this._networkGameService.GetGameModeMetaData().GameConfig.MaxPlayers;
			}
			QueueState queueState = this._gameModeService.MatchIsFull(UserProfile.LocalGameClient.requestMode);
			int num3 = this._networkGameService.GetQueueClientCommonMetadataList(UserProfile.LocalGameClient.requestMode).IndexOf((ClientCommonMetaData t) => UserProfile.IsMe(t.User)) + 1;
			killQueue.SetData(this._gameModeService.GameMode, UserProfile.LocalGameClient.team, UserProfile.LocalGameClient.requestMode, queueState, num, num2, num3);
		}

		// Token: 0x06000BAE RID: 2990 RVA: 0x00046F18 File Offset: 0x00045118
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameKillcamView inGameKillcamView = view as InGameKillcamView;
			if (inGameKillcamView != null)
			{
				this._inputControlService.RemoveMouse(inGameKillcamView);
			}
			InGameKillcamQueueView inGameKillcamQueueView = view as InGameKillcamQueueView;
			if (inGameKillcamQueueView != null)
			{
				this._inputControlService.RemoveMouse(inGameKillcamQueueView);
			}
		}

		// Token: 0x06000BAF RID: 2991 RVA: 0x00046F78 File Offset: 0x00045178
		private void OnWeaponChange(ChangeWeaponEvent evt)
		{
			if (UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER)
			{
				return;
			}
			if (this._targetMetadata == null)
			{
				return;
			}
			if (evt.User != this._targetMetadata.User)
			{
				return;
			}
			InGameKillcamView view = base.GetView<InGameKillcamView>();
			if (view == null)
			{
				return;
			}
			WeaponV4 itemById = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(evt.WantedWeaponId);
			WeaponSkin weaponSkin = new WeaponSkin(LoadoutUtil.GetSkinForWeapon(this._targetMetadata.LoadoutInfo, evt.WantedWeaponId));
			view.UpdateWeapon(itemById.ItemName, itemById.ItemModel, weaponSkin.WeaponSkinName, itemById.Category, weaponSkin.Rarity);
		}

		// Token: 0x06000BB0 RID: 2992 RVA: 0x0000A089 File Offset: 0x00008289
		private void OnSpawn(SpawnEvent evt)
		{
			if (UserProfile.IsMe(evt.User))
			{
				this._targetMetadata = null;
			}
		}

		// Token: 0x06000BB1 RID: 2993 RVA: 0x00047020 File Offset: 0x00045220
		private void OnDie(DieEvent evt)
		{
			if (UserProfile.IsMe(evt.SenderId))
			{
				return;
			}
			if (this._targetMetadata == null)
			{
				return;
			}
			if (this._targetMetadata.User != evt.SenderId)
			{
				return;
			}
			InGameKillcamView view = base.GetView<InGameKillcamView>();
			if (view != null)
			{
				view.UpdateHealthBar(LoadoutUtil.GetHeroClass(this._targetMetadata.LoadoutInfo), 0f, (float)this._targetMetadata.MaxHealth);
			}
			this._targetMetadata = null;
		}

		// Token: 0x06000BB2 RID: 2994 RVA: 0x000470A4 File Offset: 0x000452A4
		private void OnUserHit(HitEvent evt)
		{
			if (this._targetMetadata == null)
			{
				return;
			}
			if (evt.VictimGameClientId != this._targetMetadata.User)
			{
				return;
			}
			InGameKillcamView view = base.GetView<InGameKillcamView>();
			if (view != null)
			{
				view.UpdateHealthBar(LoadoutUtil.GetHeroClass(this._targetMetadata.LoadoutInfo), evt.VictimRemainingLife, (float)this._targetMetadata.MaxHealth);
			}
		}

		// Token: 0x06000BB3 RID: 2995 RVA: 0x00047110 File Offset: 0x00045310
		private void OnRecoveryHealth(RecoverHealthEvent evt)
		{
			if (this._targetMetadata == null)
			{
				return;
			}
			if (evt.User != this._targetMetadata.User)
			{
				return;
			}
			InGameKillcamView view = base.GetView<InGameKillcamView>();
			if (view != null)
			{
				view.UpdateHealthBar(LoadoutUtil.GetHeroClass(this._targetMetadata.LoadoutInfo), (float)evt.CurrentHealth, (float)this._targetMetadata.MaxHealth);
			}
		}

		// Token: 0x06000BB4 RID: 2996 RVA: 0x0004717C File Offset: 0x0004537C
		private void OnImageLoaded(ulong playerId, Texture2D texture)
		{
			InGameKillcamView view = base.GetView<InGameKillcamView>();
			if (view != null)
			{
				view.SetPlayerAvatar(texture);
			}
		}

		// Token: 0x06000BB5 RID: 2997 RVA: 0x000471A4 File Offset: 0x000453A4
		private void OnSelectTeamCompleted(SelectTeamCompletedResponse evt)
		{
			InGameKillcamQueueView view = base.GetView<InGameKillcamQueueView>();
			if (view != null)
			{
				this.UpdateKillCamQueueView(view);
			}
		}

		// Token: 0x06000BB6 RID: 2998 RVA: 0x000471A4 File Offset: 0x000453A4
		private void OnSelectTeam(SelectTeamResponse evt)
		{
			InGameKillcamQueueView view = base.GetView<InGameKillcamQueueView>();
			if (view != null)
			{
				this.UpdateKillCamQueueView(view);
			}
		}

		// Token: 0x06000BB7 RID: 2999 RVA: 0x000471A4 File Offset: 0x000453A4
		private void OnUserListChanged(UserListChangedEvent evt)
		{
			InGameKillcamQueueView view = base.GetView<InGameKillcamQueueView>();
			if (view != null)
			{
				this.UpdateKillCamQueueView(view);
			}
		}

		// Token: 0x06000BB8 RID: 3000 RVA: 0x000471A4 File Offset: 0x000453A4
		private void OnTeamQueueChanged(TeamQueueChangedEvent evt)
		{
			InGameKillcamQueueView view = base.GetView<InGameKillcamQueueView>();
			if (view != null)
			{
				this.UpdateKillCamQueueView(view);
			}
		}

		// Token: 0x06000BB9 RID: 3001 RVA: 0x000471CC File Offset: 0x000453CC
		public void Update()
		{
			if (this._targetMetadata == null)
			{
				return;
			}
			InGameKillcamView view = base.GetView<InGameKillcamView>();
			if (view == null || !view.isActiveAndEnabled)
			{
				return;
			}
			EHeroClass heroClass = LoadoutUtil.GetHeroClass(this._targetMetadata.LoadoutInfo);
			view.UpdateHealthBar(heroClass, (float)this._targetMetadata.Health, (float)this._targetMetadata.MaxHealth);
		}

		// Token: 0x06000BBA RID: 3002 RVA: 0x00047234 File Offset: 0x00045434
		public void SetTarget(long targetUser, int weaponId = -1)
		{
			this._targetMetadata = this._networkGameService.GetClientCommonMetaData(targetUser);
			if (weaponId == -1)
			{
				weaponId = this._targetMetadata.WeaponInUse;
			}
			InGameKillcamView view = base.GetView<InGameKillcamView>();
			if (view != null)
			{
				WeaponV4 itemById = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(weaponId);
				WeaponSkin weaponSkin = new WeaponSkin(LoadoutUtil.GetSkinForWeapon(this._targetMetadata.LoadoutInfo, weaponId));
				List<EHeroSkillV2> skillsSelected = LoadoutUtil.GetSkillsSelected(this._targetMetadata.LoadoutInfo);
				view.SetInfo(this._gameModeService.GameMode, this._targetMetadata.Nickname + this._targetMetadata.LoadoutInfo.HeroLevel.ToString("  [0]") + this._targetMetadata.Levels[0].ToString("[0]"), (int)((!this._targetMetadata.Levels.ContainsKey(0)) ? 0 : this._targetMetadata.Levels[0]), LoadoutUtil.GetHeroClass(this._targetMetadata.LoadoutInfo), (Team)this._targetMetadata.Team == UserProfile.LocalGameClient.team, (Team)this._targetMetadata.Team, LoadoutUtil.GetSkinBody(this._targetMetadata.LoadoutInfo).ItemModel, skillsSelected[0], skillsSelected[1], itemById.ItemName, itemById.ItemModel, weaponSkin.WeaponSkinName, itemById.Category, weaponSkin.Rarity, this._targetMetadata.LoadoutInfo.HeroLevel);
				view.UpdateHealthBar(LoadoutUtil.GetHeroClass(this._targetMetadata.LoadoutInfo), 0f, (float)this._targetMetadata.MaxHealth);
			}
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(new CSteamID((ulong)targetUser), new Action<ulong, Texture2D>(this.OnImageLoaded), true);
		}

		// Token: 0x04000EFB RID: 3835
		private readonly GameModeService _gameModeService;

		// Token: 0x04000EFC RID: 3836
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000EFD RID: 3837
		private readonly InputControlService _inputControlService;

		// Token: 0x04000EFE RID: 3838
		private ClientCommonMetaData _targetMetadata;
	}
}
