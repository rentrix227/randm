﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D6 RID: 726
	public class LeaderboardsCategoriesView : BaseView<LeaderboardsController>
	{
		// Token: 0x06000F41 RID: 3905 RVA: 0x0005B918 File Offset: 0x00059B18
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.OverallToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnOverallSelected));
			this.BerserkerToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnBerserkerSelected));
			this.VanguardToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnVanguardSelected));
			this.WraithToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnWraithSelected));
			this.ShadowToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnShadowSelected));
			this.TankToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnTankSelected));
			this.GrenadierToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnGrenadierSelected));
			this.MarksmanToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnMarksmanSelected));
			this.AccessoriesToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnAccessoriesSelected));
		}

		// Token: 0x06000F42 RID: 3906 RVA: 0x0000C8C6 File Offset: 0x0000AAC6
		private void OnOverallSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.PERFORMANCE_LADDER);
			}
		}

		// Token: 0x06000F43 RID: 3907 RVA: 0x0000C8E4 File Offset: 0x0000AAE4
		private void OnBerserkerSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.BESERKER_LADDER);
			}
		}

		// Token: 0x06000F44 RID: 3908 RVA: 0x0000C902 File Offset: 0x0000AB02
		private void OnVanguardSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.VANGUARD_LADDER);
			}
		}

		// Token: 0x06000F45 RID: 3909 RVA: 0x0000C920 File Offset: 0x0000AB20
		private void OnWraithSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.WRAITH_LADDER);
			}
		}

		// Token: 0x06000F46 RID: 3910 RVA: 0x0000C93E File Offset: 0x0000AB3E
		private void OnShadowSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.SHADOW_LADDER);
			}
		}

		// Token: 0x06000F47 RID: 3911 RVA: 0x0000C95C File Offset: 0x0000AB5C
		private void OnGrenadierSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.GRENADIER_LADDER);
			}
		}

		// Token: 0x06000F48 RID: 3912 RVA: 0x0000C97A File Offset: 0x0000AB7A
		private void OnTankSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.TANK_LADDER);
			}
		}

		// Token: 0x06000F49 RID: 3913 RVA: 0x0000C998 File Offset: 0x0000AB98
		private void OnMarksmanSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.MARKSMAN_LADDER);
			}
		}

		// Token: 0x06000F4A RID: 3914 RVA: 0x0000C9B6 File Offset: 0x0000ABB6
		private void OnAccessoriesSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchLeaderboardChange(Leaderboards.SKIN_LEGENDARY_LADDER);
			}
		}

		// Token: 0x06000F4B RID: 3915 RVA: 0x0005BA30 File Offset: 0x00059C30
		internal void SetData(Leaderboards leaderboard)
		{
			this._isSetting = true;
			this.OverallToggle.isOn = leaderboard == Leaderboards.PERFORMANCE_LADDER;
			this.BerserkerToggle.isOn = leaderboard == Leaderboards.BESERKER_LADDER;
			this.VanguardToggle.isOn = leaderboard == Leaderboards.VANGUARD_LADDER;
			this.WraithToggle.isOn = leaderboard == Leaderboards.WRAITH_LADDER;
			this.ShadowToggle.isOn = leaderboard == Leaderboards.SHADOW_LADDER;
			this.TankToggle.isOn = leaderboard == Leaderboards.TANK_LADDER;
			this.GrenadierToggle.isOn = leaderboard == Leaderboards.GRENADIER_LADDER;
			this.MarksmanToggle.isOn = leaderboard == Leaderboards.MARKSMAN_LADDER;
			this.AccessoriesToggle.isOn = leaderboard == Leaderboards.SKIN_LEGENDARY_LADDER;
			this._isSetting = false;
		}

		// Token: 0x04001461 RID: 5217
		[Header("Overall")]
		public Toggle OverallToggle;

		// Token: 0x04001462 RID: 5218
		[Header("Classes")]
		public Toggle BerserkerToggle;

		// Token: 0x04001463 RID: 5219
		public Toggle VanguardToggle;

		// Token: 0x04001464 RID: 5220
		public Toggle WraithToggle;

		// Token: 0x04001465 RID: 5221
		public Toggle ShadowToggle;

		// Token: 0x04001466 RID: 5222
		public Toggle GrenadierToggle;

		// Token: 0x04001467 RID: 5223
		public Toggle TankToggle;

		// Token: 0x04001468 RID: 5224
		public Toggle MarksmanToggle;

		// Token: 0x04001469 RID: 5225
		[Header("Accessories")]
		public Toggle AccessoriesToggle;

		// Token: 0x0400146A RID: 5226
		private bool _isSetting;
	}
}
