﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Services;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000307 RID: 775
	public class ServerFriendsView : BaseView<ServerBrowserController>
	{
		// Token: 0x06001012 RID: 4114 RVA: 0x0005E02C File Offset: 0x0005C22C
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.RefreshButton.onClick.AddListener(new UnityAction(this.OnRefreshFriendList));
			this.SortFriendsToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSortFriendsChanged));
			this.SortClanToggle.onValueChanged.AddListener(new UnityAction<bool>(this.SortClanChanged));
			this.SortFriendsAscendingToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSortFriendsChanged));
			this.SortClanAscendingToggle.onValueChanged.AddListener(new UnityAction<bool>(this.SortClanChanged));
			this.FriendItemTemplateList.Template.Dispose();
			this.ClanItemTemplateList.Template.Dispose();
			this.FriendCountText.text = ServiceProvider.GetService<LocalizationService>().Get("friends", ELocalizedTextCase.UPPER_CASE) + " / 0";
			this.ClanCountText.text = ServiceProvider.GetService<LocalizationService>().Get("clan", ELocalizedTextCase.UPPER_CASE) + " / 0";
		}

		// Token: 0x06001013 RID: 4115 RVA: 0x0005E140 File Offset: 0x0005C340
		internal void UpdateFriends(List<FriendHostItem> friendServerList, List<FriendHostItem> clanServerList, bool sortFriends, bool sortClan, bool quickMatchIsRunning)
		{
			this._isSetting = true;
			this.SortFriendsToggle.isOn = sortFriends;
			this.SortClanToggle.isOn = sortClan;
			this._isSetting = false;
			this.FriendItemTemplateList.Parent.gameObject.SetActive(sortFriends);
			this.ClanItemTemplateList.Parent.gameObject.SetActive(sortClan);
			this.RefreshButton.interactable = !quickMatchIsRunning;
			this.FriendCountText.text = ServiceProvider.GetService<LocalizationService>().Get("friends", ELocalizedTextCase.UPPER_CASE) + " / " + friendServerList.Count.ToString();
			this.FriendItemTemplateList.SetActiveCount(friendServerList.Count);
			int num = 0;
			foreach (FriendHostItem friendHostItem in friendServerList)
			{
				this.FriendItemTemplateList[num].SetInfo(friendHostItem.friend, friendHostItem.hostItem);
				this.FriendItemTemplateList[num].OnClicked = new Action<CSteamID, HostItem>(this.OnFriendClicked);
				this.FriendItemTemplateList[num].FriendButton.interactable = !quickMatchIsRunning;
				num++;
			}
			this.ClanCountText.text = ServiceProvider.GetService<LocalizationService>().Get("clan", ELocalizedTextCase.UPPER_CASE) + " / " + clanServerList.Count.ToString();
			this.ClanItemTemplateList.SetActiveCount(clanServerList.Count);
			num = 0;
			foreach (FriendHostItem friendHostItem2 in clanServerList)
			{
				this.ClanItemTemplateList[num].SetInfo(friendHostItem2.friend, friendHostItem2.hostItem);
				this.ClanItemTemplateList[num].OnClicked = new Action<CSteamID, HostItem>(this.OnFriendClicked);
				this.ClanItemTemplateList[num].FriendButton.interactable = !quickMatchIsRunning;
				num++;
			}
		}

		// Token: 0x06001014 RID: 4116 RVA: 0x0000D3AB File Offset: 0x0000B5AB
		private void OnFriendClicked(CSteamID friend, HostItem hostItem)
		{
			base._controller.SetFriendServer(friend, hostItem);
		}

		// Token: 0x06001015 RID: 4117 RVA: 0x0000D3BA File Offset: 0x0000B5BA
		private void OnSortFriendsChanged(bool value)
		{
			if (this.SortFriendsToggle.isOn && !this._isSetting)
			{
				base._controller.DispatchSortFriends(this.SortFriendsToggle.isOn, this.SortFriendsAscendingToggle.isOn, false, false);
			}
		}

		// Token: 0x06001016 RID: 4118 RVA: 0x0000D3FA File Offset: 0x0000B5FA
		private void SortClanChanged(bool value)
		{
			if (this.SortClanToggle.isOn && !this._isSetting)
			{
				base._controller.DispatchSortFriends(false, false, this.SortClanToggle.isOn, this.SortClanAscendingToggle.isOn);
			}
		}

		// Token: 0x06001017 RID: 4119 RVA: 0x0000D299 File Offset: 0x0000B499
		private void OnRefreshFriendList()
		{
			base._controller.RefreshServerList();
		}

		// Token: 0x04001542 RID: 5442
		public Text FriendCountText;

		// Token: 0x04001543 RID: 5443
		public Text ClanCountText;

		// Token: 0x04001544 RID: 5444
		public ServerFriendsView.FriendItemComponentList FriendItemTemplateList;

		// Token: 0x04001545 RID: 5445
		public ServerFriendsView.FriendItemComponentList ClanItemTemplateList;

		// Token: 0x04001546 RID: 5446
		public Button RefreshButton;

		// Token: 0x04001547 RID: 5447
		public Toggle SortFriendsToggle;

		// Token: 0x04001548 RID: 5448
		public Toggle SortFriendsAscendingToggle;

		// Token: 0x04001549 RID: 5449
		public Toggle SortClanToggle;

		// Token: 0x0400154A RID: 5450
		public Toggle SortClanAscendingToggle;

		// Token: 0x0400154B RID: 5451
		private bool _isSetting;

		// Token: 0x02000308 RID: 776
		[Serializable]
		public class FriendItemComponentList : PoolableList<FriendItemComponent>
		{
		}
	}
}
