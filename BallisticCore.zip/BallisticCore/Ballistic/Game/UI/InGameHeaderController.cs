﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Connection.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Chat;
using Aquiris.Ballistic.Network.Transport.Gameplay.Command.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Command.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Services;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000229 RID: 553
	public class InGameHeaderController : BaseController
	{
		// Token: 0x06000B75 RID: 2933 RVA: 0x00044C18 File Offset: 0x00042E18
		public InGameHeaderController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._teamOnly = false;
			this._submiting = false;
			this._showingScoreboard = false;
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			this._gameSettingsService = ServiceProvider.GetService<GameSettingsService>();
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._spectatorService = ServiceProvider.GetService<SpectatorService>();
			this._inventoryService = ServiceProvider.GetService<InventoryService>();
			this._inputControlService = ServiceProvider.GetService<InputControlService>();
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnVoteEnd.AddListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnUserListChanged.AddListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnTeamCall.AddListener(new Action<TeamCallRequest>(this.OnTeamCall));
			this._networkGameService.OnRebalanceCall.AddListener(new Action<RebalanceCallRequest>(this.OnRebalanceCall));
			this._networkGameService.OnSelectTeam.AddListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.AddListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnChatReceived.AddListener(new Action<ChatEvent>(this.OnChatReceived));
			this._networkGameService.OnTimeRemaining.AddListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnServerTermination.AddListener(new Action<ServerTerminationEvent>(this.OnServerTermination));
			this._networkGameService.OnServerCommandEvent.AddListener(new Action<ServerCommandEvent>(this.OnServerCommandEvent));
			UIManager.Instance.OnAfterViewStateChange += this.OnAfterViewStateChange;
			this._sceneService = ServiceProvider.GetService<SceneService>();
			this._sceneService.OnSceneLoaded += this.OnSceneLoaded;
			this._eventProxy.EUpdate.AddListener(new Action(this.OnUpdate));
		}

		// Token: 0x06000B76 RID: 2934 RVA: 0x00009E6D File Offset: 0x0000806D
		private void OnAfterViewStateChange(string arg1, string arg2, int arg3, object context)
		{
			this._currentStates = UIManager.Instance.CurrentStates;
		}

		// Token: 0x06000B77 RID: 2935 RVA: 0x00044E80 File Offset: 0x00043080
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnVoteEnd.RemoveListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnUserListChanged.RemoveListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnTeamCall.RemoveListener(new Action<TeamCallRequest>(this.OnTeamCall));
			this._networkGameService.OnRebalanceCall.RemoveListener(new Action<RebalanceCallRequest>(this.OnRebalanceCall));
			this._networkGameService.OnSelectTeam.RemoveListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.RemoveListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnChatReceived.RemoveListener(new Action<ChatEvent>(this.OnChatReceived));
			this._networkGameService.OnTimeRemaining.RemoveListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnServerTermination.RemoveListener(new Action<ServerTerminationEvent>(this.OnServerTermination));
			this._networkGameService.OnServerCommandEvent.RemoveListener(new Action<ServerCommandEvent>(this.OnServerCommandEvent));
			UIManager.Instance.OnAfterViewStateChange -= this.OnAfterViewStateChange;
			this._sceneService.OnSceneLoaded -= this.OnSceneLoaded;
			this._eventProxy.EUpdate.RemoveListener(new Action(this.OnUpdate));
		}

		// Token: 0x06000B78 RID: 2936 RVA: 0x00045070 File Offset: 0x00043270
		private void OnTimeRemaining(TimeRemainingEvent evt)
		{
			this._remainingTime = (long)evt.RemainingTime;
			InGameHeaderView view = base.GetView<InGameHeaderView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.SetData(UserProfile.LocalGameClient.clientMode, UserProfile.LocalGameClient.requestMode, this._gameModeService.GameMode, UserProfile.LocalGameClient.spawned, this.CanChangeTeam(), this._networkGameService.IsLobbyConnected(), this._gameModeService.AutoBalance);
			}
		}

		// Token: 0x06000B79 RID: 2937 RVA: 0x000450F4 File Offset: 0x000432F4
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayInGameChatView gameplayInGameChatView = view as GameplayInGameChatView;
			if (gameplayInGameChatView != null)
			{
				gameplayInGameChatView.SetTeamOnly(this._teamOnly);
				if (!gameplayInGameChatView.IsTyping())
				{
					gameplayInGameChatView.HideInputField();
				}
			}
			InGameHeaderView inGameHeaderView = view as InGameHeaderView;
			if (inGameHeaderView != null)
			{
				inGameHeaderView.SetData(UserProfile.LocalGameClient.clientMode, UserProfile.LocalGameClient.requestMode, this._gameModeService.GameMode, UserProfile.LocalGameClient.spawned, this.CanChangeTeam(), this._networkGameService.IsLobbyConnected(), this._gameModeService.AutoBalance);
				this._inputControlService.SetInput(inGameHeaderView, false);
			}
			InGameEndmatchHeaderView inGameEndmatchHeaderView = view as InGameEndmatchHeaderView;
			if (inGameEndmatchHeaderView != null)
			{
				int voteRemainingTime = this.GetVoteRemainingTime();
				if (voteRemainingTime >= 0)
				{
					inGameEndmatchHeaderView.UpdateTimeRemaining(voteRemainingTime);
				}
			}
			InGamePopupJoinMatchView inGamePopupJoinMatchView = view as InGamePopupJoinMatchView;
			if (inGamePopupJoinMatchView != null)
			{
				int num = 0;
				EGameMode gameMode = this._gameModeService.GameMode;
				int num2;
				if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
				{
					foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap)
					{
						if (keyValuePair.Value.ClientMode == EClientMode.PLAYER && (ETeamMode)keyValuePair.Value.Team == UserProfile.LocalGameClient.requestMode)
						{
							num++;
						}
					}
					num2 = (int)(this._networkGameService.GetGameModeMetaData().GameConfig.MaxPlayers / 2);
				}
				else
				{
					foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair2 in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap)
					{
						num++;
					}
					num2 = (int)this._networkGameService.GetGameModeMetaData().GameConfig.MaxPlayers;
				}
				inGamePopupJoinMatchView.SetData(this._gameModeService.GameMode, UserProfile.LocalGameClient.requestMode, num, num2, (int)this._teamCallRemainingTime);
				this._inputControlService.SetInput(inGamePopupJoinMatchView, false);
				this._inputControlService.SetMouse(inGamePopupJoinMatchView, true);
			}
			InGamePopupChangeTeamView inGamePopupChangeTeamView = view as InGamePopupChangeTeamView;
			if (inGamePopupChangeTeamView != null)
			{
				int num3 = 0;
				EGameMode gameMode2 = this._gameModeService.GameMode;
				int num4;
				if (gameMode2 != EGameMode.FreeForAll && gameMode2 != EGameMode.Juggernaut)
				{
					foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair3 in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap)
					{
						if (keyValuePair3.Value.ClientMode == EClientMode.PLAYER && (ETeamMode)keyValuePair3.Value.Team == UserProfile.LocalGameClient.requestMode)
						{
							num3++;
						}
					}
					num4 = (int)(this._networkGameService.GetGameModeMetaData().GameConfig.MaxPlayers / 2);
				}
				else
				{
					foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair4 in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap)
					{
						num3++;
					}
					num4 = (int)this._networkGameService.GetGameModeMetaData().GameConfig.MaxPlayers;
				}
				inGamePopupChangeTeamView.SetData(this._rebalanceTeam, num3, num4, (int)this._rebalanceCallRemainingTime);
				this._inputControlService.SetInput(inGamePopupChangeTeamView, false);
				this._inputControlService.SetMouse(inGamePopupChangeTeamView, true);
			}
		}

		// Token: 0x06000B7A RID: 2938 RVA: 0x000454F0 File Offset: 0x000436F0
		private void OnUserHit(HitEvent hitEvent)
		{
			if (UserProfile.IsMe(hitEvent.SenderId) && !UserProfile.IsMe(hitEvent.VictimGameClientId))
			{
				if (UserProfile.LocalGameClient.score > 10)
				{
					return;
				}
				if (this._networkGameService.GetGameModeMetaData().GameConfig.MatchTime >= 5)
				{
					return;
				}
				this._inventoryService.StartHeartbeat();
			}
		}

		// Token: 0x06000B7B RID: 2939 RVA: 0x00045558 File Offset: 0x00043758
		private void OnSceneLoaded(EBaseScene scene)
		{
			if (scene != EBaseScene.InGame)
			{
				return;
			}
			if (this._gameModeService.IsEnd())
			{
				UIManager.Instance.ChangeState("FINAL_SCOREBOARD");
			}
			else if (UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER && UserProfile.LocalGameClient.team != Team.NONE && this._gameModeService.GameMode == EGameMode.Rounds && this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType == EGameState.PLAYING)
			{
				InGameEndmatchController.EnforcePlayerSpectate();
			}
			else if (this._gameModeService.GameMode == EGameMode.FreeForAll || this._gameModeService.GameMode == EGameMode.Juggernaut)
			{
				UIManager.Instance.ChangeState("RESPAWN");
			}
			else if (this._gameModeService.AutoBalance || UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER)
			{
				UIManager.Instance.ChangeState("RESPAWN");
			}
			else
			{
				UIManager.Instance.ChangeState("CHOOSE_TEAM");
			}
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x00009E7F File Offset: 0x0000807F
		private bool CanChangeTeam()
		{
			return (float)this._remainingTime < (float)this._networkGameService.GetGameModeMetaData().GameConfig.MatchTime * 0.25f;
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x00045660 File Offset: 0x00043860
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameHeaderView inGameHeaderView = view as InGameHeaderView;
			if (inGameHeaderView != null)
			{
				this._inputControlService.SetInput(inGameHeaderView, true);
			}
			GameplayInGameChatView gameplayInGameChatView = view as GameplayInGameChatView;
			if (gameplayInGameChatView != null)
			{
				this._inputControlService.SetInput(gameplayInGameChatView, true);
			}
			InGamePopupJoinMatchView inGamePopupJoinMatchView = view as InGamePopupJoinMatchView;
			if (inGamePopupJoinMatchView != null)
			{
				this._inputControlService.SetInput(inGamePopupJoinMatchView, true);
				this._inputControlService.RemoveMouse(inGamePopupJoinMatchView);
			}
			InGamePopupChangeTeamView inGamePopupChangeTeamView = view as InGamePopupChangeTeamView;
			if (inGamePopupChangeTeamView != null)
			{
				this._inputControlService.SetInput(inGamePopupChangeTeamView, true);
				this._inputControlService.RemoveMouse(inGamePopupChangeTeamView);
			}
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x00009EA6 File Offset: 0x000080A6
		private void OnUpdate()
		{
			this.ChatUpdate();
			this.GameUpdate();
			this.VoteTime();
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x00045718 File Offset: 0x00043918
		private bool IsTyping()
		{
			foreach (AbstractView abstractView in this._view)
			{
				GameplayBaseChatView gameplayBaseChatView = abstractView as GameplayBaseChatView;
				if (!(gameplayBaseChatView == null))
				{
					if (gameplayBaseChatView.IsTyping())
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x0004579C File Offset: 0x0004399C
		private void ChatUpdate()
		{
			if (this.IsTyping())
			{
				this._submiting = true;
				if (this._optionControlService.GetKeyDown(KeyType.SCORES, false))
				{
					this.SetTeamOnly(!this._teamOnly);
				}
				return;
			}
			if (this._submiting)
			{
				this._submiting = false;
				return;
			}
			if (!this._optionControlService.GetKeyDown(KeyType.CHAT_ALL, true) && !this._optionControlService.GetKeyDown(KeyType.CHAT_TEAM, true))
			{
				return;
			}
			if (this._optionControlService.GetKeyDown(KeyType.CHAT_TEAM, true))
			{
				this.SetTeamOnly(true);
			}
			if (!this._gameSettingsService.Container.InGameChat)
			{
				this._gameSettingsService.Container.InGameChat = true;
				this._gameSettingsService.Save();
			}
			if (this.GameChatActive())
			{
				this.GameInputField(true);
			}
			else if (this.MenuChatActive())
			{
				this.MenuInputField(true);
			}
			else if (this.EndMenuChatActive())
			{
				this.EndMenuInputField(true);
			}
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x000458A4 File Offset: 0x00043AA4
		private void OnChatReceived(ChatEvent evt)
		{
			if (!this._gameSettingsService.Container.InGameChat)
			{
				return;
			}
			ClientCommonMetaData clientCommonMetaData = this._networkGameService.GetClientCommonMetaData(evt.User);
			ClientCommonMetaData clientCommonMetaData2 = this._networkGameService.GetClientCommonMetaData((long)UserProfile.MyId());
			if (clientCommonMetaData2 == null || clientCommonMetaData == null || evt == null)
			{
				return;
			}
			if (evt.TeamOnly && clientCommonMetaData2.ClientMode == EClientMode.SPECTATOR)
			{
				return;
			}
			this.OnTextOutput(clientCommonMetaData.Nickname, evt.Message, evt.TeamOnly, (int)clientCommonMetaData2.Team != (int)clientCommonMetaData.Team);
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x00045940 File Offset: 0x00043B40
		private void OnTextOutput(string nickname, string messege, bool teamOnly, bool myTeam)
		{
			for (int i = 0; i < this._view.Count; i++)
			{
				GameplayBaseChatView gameplayBaseChatView = this._view[i] as GameplayBaseChatView;
				if (gameplayBaseChatView != null)
				{
					gameplayBaseChatView.AddUserMessage(nickname, messege, teamOnly, myTeam);
				}
			}
		}

		// Token: 0x06000B83 RID: 2947 RVA: 0x00045994 File Offset: 0x00043B94
		private void OnServerOutput(string message)
		{
			for (int i = 0; i < this._view.Count; i++)
			{
				GameplayBaseChatView gameplayBaseChatView = this._view[i] as GameplayBaseChatView;
				if (gameplayBaseChatView != null)
				{
					gameplayBaseChatView.AddServerMessage(message);
				}
			}
		}

		// Token: 0x06000B84 RID: 2948 RVA: 0x00009EBA File Offset: 0x000080BA
		private void OnServerCommandEvent(ServerCommandEvent evt)
		{
			this.OnServerOutput(evt.Response);
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x000459E4 File Offset: 0x00043BE4
		private void OnServerTermination(ServerTerminationEvent evt)
		{
			string serverTerminationMessage = ServiceProvider.GetService<LocalizationService>().GetServerTerminationMessage(evt.Reason);
			this.OnServerOutput(serverTerminationMessage);
			for (int i = 0; i < this._view.Count; i++)
			{
				InGameEndmatchHeaderView inGameEndmatchHeaderView = this._view[i] as InGameEndmatchHeaderView;
				if (inGameEndmatchHeaderView != null)
				{
					inGameEndmatchHeaderView.SetServerOffline(true);
				}
			}
		}

		// Token: 0x06000B86 RID: 2950 RVA: 0x00045A4C File Offset: 0x00043C4C
		public void OnTextInput(string messege, bool teamOnly)
		{
			if (messege.StartsWith("./"))
			{
				ServerCommandRequest serverCommandRequest = new ServerCommandRequest
				{
					Command = messege
				};
				this._networkGameService.RaiseNetworkEvent(serverCommandRequest);
				teamOnly = false;
			}
			ChatEvent chatEvent = new ChatEvent
			{
				User = (long)UserProfile.MyId(),
				Message = messege,
				TeamOnly = teamOnly
			};
			this.OnTextOutput((!string.IsNullOrEmpty(File.ReadAllText(Application.dataPath + "/NameTag.txt").Trim())) ? File.ReadAllText(Application.dataPath + "/NameTag.txt") : SteamFriends.GetPersonaName(), messege, teamOnly, true);
			ServiceProvider.GetService<NetworkGameService>().BroadcastNetworkEvent(chatEvent, teamOnly);
			if (InGameHeaderController.OnChatMessageSent != null)
			{
				InGameHeaderController.OnChatMessageSent(messege);
			}
		}

		// Token: 0x06000B87 RID: 2951 RVA: 0x00045B04 File Offset: 0x00043D04
		private void GameInputField(bool enabled)
		{
			foreach (AbstractView abstractView in this._view)
			{
				GameplayInGameChatView gameplayInGameChatView = abstractView as GameplayInGameChatView;
				if (!(gameplayInGameChatView == null))
				{
					if (enabled)
					{
						gameplayInGameChatView.FocusInputField();
					}
					else
					{
						gameplayInGameChatView.HideInputField();
					}
				}
			}
		}

		// Token: 0x06000B88 RID: 2952 RVA: 0x00045B88 File Offset: 0x00043D88
		private void MenuInputField(bool enabled)
		{
			foreach (AbstractView abstractView in this._view)
			{
				InGameHeaderView inGameHeaderView = abstractView as InGameHeaderView;
				if (!(inGameHeaderView == null))
				{
					if (enabled)
					{
						inGameHeaderView.FocusInputField();
					}
					else
					{
						inGameHeaderView.HideInputField();
					}
				}
			}
		}

		// Token: 0x06000B89 RID: 2953 RVA: 0x00045C0C File Offset: 0x00043E0C
		private void EndMenuInputField(bool enabled)
		{
			foreach (AbstractView abstractView in this._view)
			{
				InGameEndmatchHeaderView inGameEndmatchHeaderView = abstractView as InGameEndmatchHeaderView;
				if (!(inGameEndmatchHeaderView == null))
				{
					if (enabled)
					{
						inGameEndmatchHeaderView.FocusInputField();
					}
					else
					{
						inGameEndmatchHeaderView.HideInputField();
					}
				}
			}
		}

		// Token: 0x06000B8A RID: 2954 RVA: 0x00045C90 File Offset: 0x00043E90
		private bool GameChatActive()
		{
			foreach (AbstractView abstractView in this._view)
			{
				GameplayInGameChatView gameplayInGameChatView = abstractView as GameplayInGameChatView;
				if (gameplayInGameChatView != null)
				{
					return gameplayInGameChatView.Visible;
				}
			}
			return false;
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x00045D08 File Offset: 0x00043F08
		private bool MenuChatActive()
		{
			foreach (AbstractView abstractView in this._view)
			{
				InGameHeaderView inGameHeaderView = abstractView as InGameHeaderView;
				if (inGameHeaderView != null)
				{
					return inGameHeaderView.Visible;
				}
			}
			return false;
		}

		// Token: 0x06000B8C RID: 2956 RVA: 0x00045D80 File Offset: 0x00043F80
		private bool EndMenuChatActive()
		{
			foreach (AbstractView abstractView in this._view)
			{
				InGameEndmatchHeaderView inGameEndmatchHeaderView = abstractView as InGameEndmatchHeaderView;
				if (inGameEndmatchHeaderView != null)
				{
					return inGameEndmatchHeaderView.Visible;
				}
			}
			return false;
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x00045DF8 File Offset: 0x00043FF8
		public void SetTeamOnly(bool teamOnly)
		{
			this._teamOnly = teamOnly;
			foreach (AbstractView abstractView in this._view)
			{
				GameplayBaseChatView gameplayBaseChatView = abstractView as GameplayBaseChatView;
				if (gameplayBaseChatView != null)
				{
					gameplayBaseChatView.SetTeamOnly(this._teamOnly);
				}
			}
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x00045E74 File Offset: 0x00044074
		private void GameUpdate()
		{
			if (this._networkGameService.GetGameModeMetaData() == null)
			{
				return;
			}
			if (this._gameModeService.IsEnd())
			{
				return;
			}
			if (UserProfile.LocalGameClient == null)
			{
				return;
			}
			if (UserProfile.LocalGameClient.ClientCommonMetaData == null)
			{
				return;
			}
			if (this._currentStates == null)
			{
				return;
			}
			this._escKeyCooldown -= Time.deltaTime;
			if (this._escKeyCooldown <= 0f && this._optionControlService.GetKeyDown(KeyType.ESCAPE, false))
			{
				this._escKeyCooldown = 0.5f;
				if (!this.IsSpawned())
				{
					return;
				}
				if (UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER)
				{
					if (this._currentStates.Contains("GAMEPLAY") || this._currentStates.Contains("TAB"))
					{
						UIManager.Instance.ChangeState("MATCH_INFO");
					}
					else
					{
						UIManager.Instance.ChangeState("GAMEPLAY");
						UIManager.Instance.DisableLayer(2);
					}
				}
				if (UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR)
				{
					if (this._currentStates.Contains("KILL_CAM") || this._currentStates.Contains("KILL_CAM_TAB") || this._currentStates.Contains("KILL_CAM_QUEUE") || this._currentStates.Contains("KILL_CAM_QUEUE_TAB") || this._currentStates.Contains("FREE_CAMERA") || this._currentStates.Contains("FREE_CAMERA_TAB") || this._currentStates.Contains("FREE_CAMERA_QUEUE") || this._currentStates.Contains("FREE_CAMERA_QUEUE_TAB"))
					{
						UIManager.Instance.ChangeState("MATCH_INFO");
					}
					else if (UserProfile.LocalGameClient.requestMode != ETeamMode.UNDEFINED && UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE)
					{
						UIManager.Instance.ChangeState((!this._spectatorService.HasFreeSpawned()) ? "KILL_CAM_QUEUE" : "FREE_CAMERA_QUEUE");
						UIManager.Instance.DisableLayer(2);
					}
					else
					{
						UIManager.Instance.ChangeState((!this._spectatorService.HasFreeSpawned()) ? "KILL_CAM" : "FREE_CAMERA");
						UIManager.Instance.DisableLayer(2);
					}
				}
			}
			if (!this.IsTyping())
			{
				if (UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR)
				{
					if (this._spectatorService.HasFreeSpawned())
					{
						if (this._optionControlService.GetKeyDown(KeyType.SHOOT) || this._optionControlService.GetKeyDown(KeyType.AIM))
						{
							this._spectatorService.SpawnOrbitSpectator();
						}
					}
					else if (this._spectatorService.HasOrbitSpawned())
					{
						if (this._optionControlService.GetKeyDown(KeyType.SHOOT))
						{
							this._spectatorService.CyclePrevious();
						}
						if (this._optionControlService.GetKeyDown(KeyType.AIM))
						{
							this._spectatorService.CycleNext();
						}
						if (this._optionControlService.GetKeyDown(KeyType.SPRINT))
						{
							this._spectatorService.SetAutoCycle(!this._spectatorService.GetAutoCycle());
							UIManager.Instance.FindController<GameplayScoreboardController>().ForceUpdateStatsView();
						}
						if (this._optionControlService.GetKeyDown(KeyType.SPACE_BAR))
						{
							this._spectatorService.SpawnFreeCamFromOrbit();
							UIManager.Instance.FindController<GameplayScoreboardController>().ForceUpdateStatsView();
						}
					}
					else if (this._optionControlService.GetKeyDown(KeyType.SPACE_BAR))
					{
						this._spectatorService.SpawnFreeCamFromCutCamera();
						UIManager.Instance.FindController<GameplayScoreboardController>().ForceUpdateStatsView();
					}
				}
				if (!this.IsSpawned())
				{
					return;
				}
				this._showingScoreboard = this._currentStates.Contains("TAB") || this._currentStates.Contains("KILL_CAM_TAB") || this._currentStates.Contains("KILL_CAM_QUEUE_TAB") || this._currentStates.Contains("FREE_CAMERA_TAB") || this._currentStates.Contains("FREE_CAMERA_QUEUE_TAB");
				if (this._optionControlService.GetKey(KeyType.SCORES, false) && !this._showingScoreboard)
				{
					if (this._currentStates.Contains("GAMEPLAY"))
					{
						UIManager.Instance.ChangeState("TAB");
					}
					if (this._currentStates.Contains("KILL_CAM"))
					{
						UIManager.Instance.ChangeState("KILL_CAM_TAB");
					}
					if (this._currentStates.Contains("KILL_CAM_QUEUE"))
					{
						UIManager.Instance.ChangeState("KILL_CAM_QUEUE_TAB");
					}
					if (this._currentStates.Contains("FREE_CAMERA"))
					{
						UIManager.Instance.ChangeState("FREE_CAMERA_TAB");
					}
					if (this._currentStates.Contains("FREE_CAMERA_QUEUE"))
					{
						UIManager.Instance.ChangeState("FREE_CAMERA_QUEUE_TAB");
					}
				}
				else if (!this._optionControlService.GetKey(KeyType.SCORES, false) && this._showingScoreboard)
				{
					if (this._currentStates.Contains("TAB"))
					{
						UIManager.Instance.ChangeState("GAMEPLAY");
					}
					if (this._currentStates.Contains("KILL_CAM_TAB"))
					{
						UIManager.Instance.ChangeState("KILL_CAM");
					}
					if (this._currentStates.Contains("KILL_CAM_QUEUE_TAB"))
					{
						UIManager.Instance.ChangeState("KILL_CAM_QUEUE");
					}
					if (this._currentStates.Contains("FREE_CAMERA_TAB"))
					{
						UIManager.Instance.ChangeState("FREE_CAMERA");
					}
					if (this._currentStates.Contains("FREE_CAMERA_QUEUE_TAB"))
					{
						UIManager.Instance.ChangeState("FREE_CAMERA_QUEUE");
					}
				}
				if (!this._spectatorService.HasOrbitSpawned() || UserProfile.LocalGameClient.clientMode != EClientMode.SPECTATOR)
				{
					return;
				}
				this._showingInfo = UIManager.Instance.CurrentStates.Contains("KILL_CAM") || UIManager.Instance.CurrentStates.Contains("KILL_CAM_TAB");
				if (this._optionControlService.GetKey(KeyType.CROUCH, false) && !this._showingInfo && UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE)
				{
					if (this._currentStates.Contains("KILL_CAM_QUEUE"))
					{
						UIManager.Instance.ChangeState("KILL_CAM");
					}
					if (this._currentStates.Contains("KILL_CAM_QUEUE_TAB"))
					{
						UIManager.Instance.ChangeState("KILL_CAM_TAB");
					}
				}
				else if (!this._optionControlService.GetKey(KeyType.CROUCH, false) && this._showingInfo && UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE)
				{
					if (this._currentStates.Contains("KILL_CAM"))
					{
						UIManager.Instance.ChangeState("KILL_CAM_QUEUE");
					}
					if (this._currentStates.Contains("KILL_CAM_TAB"))
					{
						UIManager.Instance.ChangeState("KILL_CAM_QUEUE_TAB");
					}
				}
			}
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x00046580 File Offset: 0x00044780
		private void VoteTime()
		{
			if (this._networkGameService.GetGameModeMetaData() == null)
			{
				return;
			}
			if (!this._gameModeService.IsEnd())
			{
				return;
			}
			InGameEndmatchHeaderView view = base.GetView<InGameEndmatchHeaderView>();
			if (view != null && view.isActiveAndEnabled)
			{
				int voteRemainingTime = this.GetVoteRemainingTime();
				if (voteRemainingTime >= 0)
				{
					view.UpdateTimeRemaining(voteRemainingTime);
				}
			}
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x00009EC8 File Offset: 0x000080C8
		internal void RequestPopupQuit()
		{
			ServiceProvider.GetService<PopupService>().Show(EPopupType.QUIT_GAME, null, new Action<int>(this.OnPopupQuit), null, 0f);
		}

		// Token: 0x06000B91 RID: 2961 RVA: 0x00009EE9 File Offset: 0x000080E9
		private void OnPopupQuit(int result)
		{
			ServiceProvider.GetService<PopupService>().Hide(EPopupType.QUIT_GAME);
			if (result != 2)
			{
				return;
			}
			UIManager.Instance.ChangeState("CUTSCENE");
			ServiceProvider.GetService<SceneService>().LoadMain(string.Empty);
		}

		// Token: 0x06000B92 RID: 2962 RVA: 0x00009F1D File Offset: 0x0000811D
		private void OnTeamCall(TeamCallRequest evt)
		{
			this._teamCallRemainingTime = evt.RemaningTime;
			UIManager.Instance.ChangeState("JOIN_MESSAGE");
		}

		// Token: 0x06000B93 RID: 2963 RVA: 0x00009F3A File Offset: 0x0000813A
		private void OnRebalanceCall(RebalanceCallRequest evt)
		{
			this._rebalanceCallRemainingTime = evt.RemaningTime;
			this._rebalanceTeam = evt.RequestedTeam;
			UIManager.Instance.ChangeState("CHANGE_TEAM_MESSAGE");
		}

		// Token: 0x06000B94 RID: 2964 RVA: 0x00009F63 File Offset: 0x00008163
		private void OnSelectTeam(SelectTeamResponse evt)
		{
			if (!UserProfile.IsMe(evt.User))
			{
				return;
			}
			this.UpdateTeamSelection(evt.JoinedQueueTeam);
		}

		// Token: 0x06000B95 RID: 2965 RVA: 0x00009F82 File Offset: 0x00008182
		private void OnSelectTeamCompleted(SelectTeamCompletedResponse evt)
		{
			if (!UserProfile.IsMe(evt.User))
			{
				return;
			}
			this.UpdateTeamSelection(evt.JoinedQueueTeam);
		}

		// Token: 0x06000B96 RID: 2966 RVA: 0x000465E4 File Offset: 0x000447E4
		private void UpdateTeamSelection(ETeamMode joinedQueueTeam)
		{
			InGameHeaderView view = base.GetView<InGameHeaderView>();
			if (view != null)
			{
				view.SetData(UserProfile.LocalGameClient.clientMode, UserProfile.LocalGameClient.requestMode, this._gameModeService.GameMode, UserProfile.LocalGameClient.spawned, this.CanChangeTeam(), this._networkGameService.IsLobbyConnected(), this._gameModeService.AutoBalance);
			}
			bool flag = this._spectatorService.HasOrbitSpawned() || this._spectatorService.HasFreeSpawned();
			if (flag && joinedQueueTeam != ETeamMode.SPECTATE)
			{
				this._spectatorService.FreeSpectator(false);
			}
			else if (!flag && joinedQueueTeam == ETeamMode.SPECTATE && !this._gameModeService.IsEnd())
			{
				this._spectatorService.SpawnFreeCamFromCutCamera();
			}
			else if (flag && joinedQueueTeam == ETeamMode.SPECTATE && UIManager.Instance.CurrentStates.Contains("FREE_CAMERA_QUEUE"))
			{
				UIManager.Instance.ChangeState("FREE_CAMERA");
			}
			else if (flag && joinedQueueTeam == ETeamMode.SPECTATE && UIManager.Instance.CurrentStates.Contains("KILL_CAM_QUEUE"))
			{
				UIManager.Instance.ChangeState("KILL_CAM");
			}
			else if (this._gameModeService.IsEnd())
			{
				this._eventProxy.StartCoroutine(this.ResetTo("FINAL_SCOREBOARD"));
			}
			else
			{
				this._eventProxy.StartCoroutine(this.ResetTo("RESPAWN"));
			}
		}

		// Token: 0x06000B97 RID: 2967 RVA: 0x00046770 File Offset: 0x00044970
		private IEnumerator ResetTo(string state)
		{
			if (UIManager.Instance.CurrentStates.Contains(state))
			{
				yield break;
			}
			yield return new WaitForSeconds(1f);
			if (!UIManager.Instance.CurrentStates.Contains(state))
			{
				UIManager.Instance.ChangeState(state);
			}
			yield break;
		}

		// Token: 0x06000B98 RID: 2968 RVA: 0x0004678C File Offset: 0x0004498C
		private void OnUserListChanged(UserListChangedEvent evt)
		{
			InGameHeaderView view = base.GetView<InGameHeaderView>();
			if (view == null)
			{
				return;
			}
			view.SetData(UserProfile.LocalGameClient.clientMode, UserProfile.LocalGameClient.requestMode, this._gameModeService.GameMode, UserProfile.LocalGameClient.spawned, this.CanChangeTeam(), this._networkGameService.IsLobbyConnected(), this._gameModeService.AutoBalance);
		}

		// Token: 0x06000B99 RID: 2969 RVA: 0x00009FA1 File Offset: 0x000081A1
		private void OnDie(DieEvent dieEvent)
		{
			if (!UserProfile.IsMe(dieEvent.SenderId))
			{
				return;
			}
			this._inventoryService.StopHeartbeat();
		}

		// Token: 0x06000B9A RID: 2970 RVA: 0x00009FBF File Offset: 0x000081BF
		private void OnSpawn(SpawnEvent spawnEvent)
		{
			if (!UserProfile.IsMe(spawnEvent.User))
			{
				return;
			}
			if (this._gameModeService.IsEnd())
			{
				return;
			}
			UIManager.Instance.ChangeState("GAMEPLAY");
		}

		// Token: 0x06000B9B RID: 2971 RVA: 0x00009FF2 File Offset: 0x000081F2
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			this._showingScoreboard = false;
			this._inventoryService.StopHeartbeat();
		}

		// Token: 0x06000B9C RID: 2972 RVA: 0x0000A006 File Offset: 0x00008206
		private void OnVoteEnd(VoteMapEndEvent voteData)
		{
			this._inputControlService.ClearAll();
		}

		// Token: 0x06000B9D RID: 2973 RVA: 0x0000A013 File Offset: 0x00008213
		private bool IsSpawned()
		{
			return UserProfile.LocalGameClient.spawned || this._spectatorService.HasFreeSpawned() || this._spectatorService.HasOrbitSpawned();
		}

		// Token: 0x06000B9E RID: 2974 RVA: 0x000467F8 File Offset: 0x000449F8
		internal int GetVoteRemainingTime()
		{
			if (this._networkGameService.BallisticClient == null)
			{
				return -1;
			}
			double serverTimeStamp = this._networkGameService.BallisticClient.GetServerTimeStamp();
			if (this._networkGameService.GetGameModeMetaData().VoteMap.VoteMapStartTime <= 0L || this._networkGameService.GetGameModeMetaData().VoteMap.VoteMapTime <= 0)
			{
				return -1;
			}
			if (serverTimeStamp > (double)(this._networkGameService.GetGameModeMetaData().VoteMap.VoteMapStartTime + (long)this._networkGameService.GetGameModeMetaData().VoteMap.VoteMapTime))
			{
				return 0;
			}
			return (int)(((double)this._networkGameService.GetGameModeMetaData().VoteMap.VoteMapTime - (serverTimeStamp - (double)this._networkGameService.GetGameModeMetaData().VoteMap.VoteMapStartTime)) * 0.001);
		}

		// Token: 0x06000B9F RID: 2975 RVA: 0x0000A042 File Offset: 0x00008242
		internal void DispatchClearPopupLayer()
		{
			UIManager.Instance.DisableLayer(2);
		}

		// Token: 0x06000BA0 RID: 2976 RVA: 0x000468D0 File Offset: 0x00044AD0
		internal void DispatchTeamCallDismiss(bool immediate)
		{
			UIManager.Instance.DisableLayer(2);
			if (immediate)
			{
				SelectTeamRequest selectTeamRequest = new SelectTeamRequest
				{
					RequestedTeam = ETeamMode.SPECTATE
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest);
			}
		}

		// Token: 0x06000BA1 RID: 2977 RVA: 0x0004690C File Offset: 0x00044B0C
		internal void DispatchRebalanceCallResponse()
		{
			RebalanceCallResponse rebalanceCallResponse = new RebalanceCallResponse
			{
				User = (long)UserProfile.MyId()
			};
			this._networkGameService.RaiseNetworkEvent(rebalanceCallResponse);
		}

		// Token: 0x06000BA2 RID: 2978 RVA: 0x00046938 File Offset: 0x00044B38
		internal void DispatchTeamCallResponse()
		{
			TeamCallResponse teamCallResponse = new TeamCallResponse
			{
				User = (long)UserProfile.MyId()
			};
			this._networkGameService.RaiseNetworkEvent(teamCallResponse);
		}

		// Token: 0x06000BA3 RID: 2979 RVA: 0x0000A04F File Offset: 0x0000824F
		internal void InviteFriends()
		{
			if (this._networkGameService.IsLobbyConnected())
			{
				SteamFriends.ActivateGameOverlayInviteDialog(this._networkGameService.GetLobbyId());
			}
		}

		// Token: 0x04000EE3 RID: 3811
		private readonly InputControlService _inputControlService;

		// Token: 0x04000EE4 RID: 3812
		private readonly OptionControlService _optionControlService;

		// Token: 0x04000EE5 RID: 3813
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000EE6 RID: 3814
		private readonly GameSettingsService _gameSettingsService;

		// Token: 0x04000EE7 RID: 3815
		private readonly SpectatorService _spectatorService;

		// Token: 0x04000EE8 RID: 3816
		private readonly GameModeService _gameModeService;

		// Token: 0x04000EE9 RID: 3817
		private readonly SceneService _sceneService;

		// Token: 0x04000EEA RID: 3818
		private readonly InventoryService _inventoryService;

		// Token: 0x04000EEB RID: 3819
		private readonly EventProxy _eventProxy;

		// Token: 0x04000EEC RID: 3820
		public static Action<string> OnChatMessageSent;

		// Token: 0x04000EED RID: 3821
		private bool _teamOnly;

		// Token: 0x04000EEE RID: 3822
		private bool _submiting;

		// Token: 0x04000EEF RID: 3823
		private bool _showingScoreboard;

		// Token: 0x04000EF0 RID: 3824
		private bool _showingInfo;

		// Token: 0x04000EF1 RID: 3825
		private float _escKeyCooldown;

		// Token: 0x04000EF2 RID: 3826
		private long _remainingTime;

		// Token: 0x04000EF3 RID: 3827
		private short _teamCallRemainingTime;

		// Token: 0x04000EF4 RID: 3828
		private List<string> _currentStates;

		// Token: 0x04000EF5 RID: 3829
		private short _rebalanceCallRemainingTime;

		// Token: 0x04000EF6 RID: 3830
		private ETeamMode _rebalanceTeam;
	}
}
