﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002F8 RID: 760
	public class PlayNowView : BaseView<PlaySubmenuController>
	{
		// Token: 0x06000FCF RID: 4047 RVA: 0x0005D0CC File Offset: 0x0005B2CC
		protected override void Awake()
		{
			base.Awake();
			this._animator = base.GetComponent<Animator>();
			this._lastBool = this._animator.GetBool(PlayNowView.AnimationMoveUp);
			this._lastMatchStateFound = this._animator.GetBool(PlayNowView.AnimationEnteringMatch);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			UIManager.Instance.OnAfterViewStateChange += this.OnAfterViewStateChange;
			this.CancelBtn.onClick.AddListener(new UnityAction(this.OnQuickMatchCancel));
		}

		// Token: 0x06000FD0 RID: 4048 RVA: 0x0000D048 File Offset: 0x0000B248
		protected override void OnDestroy()
		{
			base.OnDestroy();
			UIManager.Instance.OnAfterViewStateChange -= this.OnAfterViewStateChange;
		}

		// Token: 0x06000FD1 RID: 4049 RVA: 0x0005D154 File Offset: 0x0005B354
		public void Update()
		{
			if (this._animator.isInitialized)
			{
				this._animator.SetBool(PlayNowView.AnimationEnteringMatch, this._lastMatchStateFound);
				if (this._currentBool != this._lastBool)
				{
					this._animator.SetBool(PlayNowView.AnimationMoveUp, this._currentBool);
					this._lastBool = this._currentBool;
				}
			}
		}

		// Token: 0x06000FD2 RID: 4050 RVA: 0x0000D066 File Offset: 0x0000B266
		private void OnAfterViewStateChange(string state_from, string state_to, int layer, object context)
		{
			if (layer == 1)
			{
				this._currentBool = this._MoveUpStates.Contains(state_to);
			}
		}

		// Token: 0x06000FD3 RID: 4051 RVA: 0x0005D1BC File Offset: 0x0005B3BC
		internal void SetState(string key, bool matchFound)
		{
			if (this.textOnDisable != null)
			{
				this.textOnDisable.text = ServiceProvider.GetService<LocalizationService>().Get(key, ELocalizedTextCase.NONE);
				this.textOnDisable.gameObject.SetActive(!matchFound);
			}
			if (this.textOnEnable != null)
			{
				this.textOnEnable.text = ServiceProvider.GetService<LocalizationService>().Get(key, ELocalizedTextCase.NONE);
				this.textOnDisable.gameObject.SetActive(matchFound);
			}
			this._lastMatchStateFound = matchFound;
		}

		// Token: 0x06000FD4 RID: 4052 RVA: 0x0000D081 File Offset: 0x0000B281
		private void OnQuickMatchCancel()
		{
			base._controller.QuickMatchCancel();
		}

		// Token: 0x040014FC RID: 5372
		private static int AnimationMoveUp = Animator.StringToHash("move_up");

		// Token: 0x040014FD RID: 5373
		private static int AnimationEnteringMatch = Animator.StringToHash("entering_match");

		// Token: 0x040014FE RID: 5374
		public Text textOnDisable;

		// Token: 0x040014FF RID: 5375
		public Text textOnEnable;

		// Token: 0x04001500 RID: 5376
		public Button CancelBtn;

		// Token: 0x04001501 RID: 5377
		private List<string> _MoveUpStates = new List<string>
		{
			"SETTINGS_GENERAL", "SETTINGS_GRAPHICS", "SETTINGS_CONTROLS", "EDIT_SKILLS_SLOT", "EDIT_WEAPON", "INVENTORY_LOCKBOX", "INVENTORY_LOCKBOX_WAIT", "INVENTORY_LOCKBOX_OPEN", "INVENTORY_LOCKBOX_CLOSE", "INVENTORY_SKINS",
			"INVENTORY_ACCESSORIES"
		};

		// Token: 0x04001502 RID: 5378
		private Animator _animator;

		// Token: 0x04001503 RID: 5379
		private bool _currentBool;

		// Token: 0x04001504 RID: 5380
		private bool _lastBool;

		// Token: 0x04001505 RID: 5381
		private bool _lastMatchStateFound;
	}
}
