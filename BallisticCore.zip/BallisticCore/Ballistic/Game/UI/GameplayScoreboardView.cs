﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200028C RID: 652
	public class GameplayScoreboardView : BaseView<GameplayScoreboardController>
	{
		// Token: 0x06000DED RID: 3565 RVA: 0x00052350 File Offset: 0x00050550
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._fillParameterHash = Shader.PropertyToID("_Fill");
			this._lastGameMode = EGameMode.Any;
			this.FfaAllPlayerList.Template.Dispose();
			this.JugAllPlayerList.Template.Dispose();
			this.TdmYourTeamPlayerList.Template.Dispose();
			this.TdmEnemyTeamPlayerList.Template.Dispose();
			this.KothYourTeamPlayerList.Template.Dispose();
			this.KothEnemyTeamPlayerList.Template.Dispose();
			this.CtpYourTeamPlayerList.Template.Dispose();
			this.CtpEnemyTeamPlayerList.Template.Dispose();
		}

		// Token: 0x06000DEE RID: 3566 RVA: 0x00052408 File Offset: 0x00050608
		internal void SetGameMode(EGameMode mode)
		{
			if (this._lastGameMode == mode)
			{
				return;
			}
			this.TdmRoot.SetActive(mode == EGameMode.TeamDeathMatch);
			this.CtpRoot.SetActive(mode == EGameMode.Conquest);
			this.KothRoot.SetActive(mode == EGameMode.KingOfTheHill);
			this.FfaRoot.SetActive(mode == EGameMode.FreeForAll);
			this.JugRoot.SetActive(mode == EGameMode.Juggernaut);
			this.RoundsRoot.SetActive(mode == EGameMode.Rounds);
			this._lastGameMode = mode;
		}

		// Token: 0x06000DEF RID: 3567 RVA: 0x00052484 File Offset: 0x00050684
		internal void TdmUpdateData(EClientMode clientMode, EWinningTeam status, Team yourTeam, Team enemyTeam, int yourTeamScore, int enemyTeamScore)
		{
			this.TdmYourTeamLogo.texture = this.TeamLogos[(int)yourTeam];
			this.TdmEnemyTeamLogo.texture = this.TeamLogos[(int)enemyTeam];
			this.TdmYourTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(yourTeam, ELocalizedTextCase.UPPER_CASE);
			this.TdmEnemyTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(enemyTeam, ELocalizedTextCase.UPPER_CASE);
			this.TdmYourTeamText.SetActive(clientMode == EClientMode.PLAYER);
			this.TdmEnemyTeamText.SetActive(clientMode == EClientMode.PLAYER);
			if (clientMode == EClientMode.PLAYER)
			{
				if (status != this._status)
				{
					if (status != EWinningTeam.MINE)
					{
						if (status != EWinningTeam.ENEMY)
						{
							if (status == EWinningTeam.NONE)
							{
								this.TdmStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_1", ELocalizedTextCase.NONE);
							}
						}
						else
						{
							this.TdmStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_0", ELocalizedTextCase.NONE);
						}
					}
					else
					{
						this.TdmStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_2", ELocalizedTextCase.NONE);
					}
					this._status = status;
				}
			}
			else
			{
				this.TdmStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_spectatormode", ELocalizedTextCase.NONE);
			}
			if (yourTeamScore != this._yourTeamLastScore)
			{
				this.TdmYourTeamScoreText.text = yourTeamScore.ToString();
				this._yourTeamLastScore = yourTeamScore;
			}
			if (enemyTeamScore != this._enemyTeamLastScore)
			{
				this.TdmEnemyTeamScoreText.text = enemyTeamScore.ToString();
				this._enemyTeamLastScore = enemyTeamScore;
			}
		}

		// Token: 0x06000DF0 RID: 3568 RVA: 0x00052614 File Offset: 0x00050814
		internal void RoundsUpdateData(EClientMode clientMode, EWinningTeam status, Team yourTeam, Team enemyTeam, short currentRound, int yourTeamScore, int enemyTeamScore, int yourWins, int enemyWins)
		{
			this.RoundsYourTeamLogo.texture = this.TeamLogos[(int)yourTeam];
			this.RoundsEnemyTeamLogo.texture = this.TeamLogos[(int)enemyTeam];
			this.RoundsYourTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(yourTeam, ELocalizedTextCase.UPPER_CASE);
			this.RoundsEnemyTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(enemyTeam, ELocalizedTextCase.UPPER_CASE);
			this.RoundsYourTeamText.SetActive(clientMode == EClientMode.PLAYER);
			this.RoundsEnemyTeamText.SetActive(clientMode == EClientMode.PLAYER);
			if (clientMode == EClientMode.PLAYER)
			{
				if (status != this._status)
				{
					if (status != EWinningTeam.MINE)
					{
						if (status != EWinningTeam.ENEMY)
						{
							if (status == EWinningTeam.NONE)
							{
								this.RoundsStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_1", ELocalizedTextCase.NONE);
							}
						}
						else
						{
							this.RoundsStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_0", ELocalizedTextCase.NONE);
						}
					}
					else
					{
						this.RoundsStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_2", ELocalizedTextCase.NONE);
					}
					this._status = status;
				}
			}
			else
			{
				this.RoundsStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_spectatormode", ELocalizedTextCase.NONE);
			}
			if (currentRound != this._lastRound)
			{
				this._lastRound = currentRound;
				this.RoundsCurrent.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("rounds_current", ELocalizedTextCase.NONE), currentRound);
			}
			if (yourTeamScore != this._yourTeamLastScore)
			{
				this.RoundsYourTeamScoreText.text = yourTeamScore.ToString();
				this._yourTeamLastScore = yourTeamScore;
			}
			if (enemyTeamScore != this._enemyTeamLastScore)
			{
				this.RoundsEnemyTeamScoreText.text = enemyTeamScore.ToString();
				this._enemyTeamLastScore = enemyTeamScore;
			}
			if (yourWins != this._yourWinsLast)
			{
				this._yourWinsLast = yourWins;
				this.RoundsYourWinsText.text = yourWins.ToString();
			}
			if (enemyWins != this._enemyWinsLast)
			{
				this._enemyWinsLast = enemyWins;
				this.RoundsEnemyWinsText.text = enemyWins.ToString();
			}
		}

		// Token: 0x06000DF1 RID: 3569 RVA: 0x00052838 File Offset: 0x00050A38
		internal void RoundsUpdateTeams(HighSpeedArray<ClientCommonMetaData> yourTeamData, HighSpeedArray<ClientCommonMetaData> enemyTeamData)
		{
			this.RoundsYourTeamPlayers.SetActiveCount(7);
			this.RoundsEnemyTeamPlayers.SetActiveCount(7);
			for (int i = 0; i < this.RoundsYourTeamPlayers.Count; i++)
			{
				int num = this.RoundsYourTeamPlayers.Count - 1 - i;
				bool flag = num < yourTeamData.Length && yourTeamData[num].ClientMode == EClientMode.PLAYER;
				bool flag2 = flag && yourTeamData[num].CurrentState == EPlayerState.ALIVE;
				this.RoundsYourTeamPlayers[i].SetState(flag, flag2);
			}
			for (int j = 0; j < this.RoundsEnemyTeamPlayers.Count; j++)
			{
				bool flag3 = j < enemyTeamData.Length && enemyTeamData[j].ClientMode == EClientMode.PLAYER;
				bool flag4 = flag3 && enemyTeamData[j].CurrentState == EPlayerState.ALIVE;
				this.RoundsEnemyTeamPlayers[j].SetState(flag3, flag4);
			}
		}

		// Token: 0x06000DF2 RID: 3570 RVA: 0x00052948 File Offset: 0x00050B48
		internal void FfaUpdateData(EClientMode clientMode, int yourPosition)
		{
			if (yourPosition > 0)
			{
				this.FfaStatusTeam.text = ((clientMode != EClientMode.PLAYER) ? ServiceProvider.GetService<LocalizationService>().Get("team_spectatormode", ELocalizedTextCase.NONE) : string.Format(ServiceProvider.GetService<LocalizationService>().Get("your_position_x", ELocalizedTextCase.NONE), yourPosition));
			}
			else
			{
				this.FfaStatusTeam.text = ((clientMode != EClientMode.PLAYER) ? ServiceProvider.GetService<LocalizationService>().Get("team_spectatormode", ELocalizedTextCase.NONE) : string.Empty);
			}
		}

		// Token: 0x06000DF3 RID: 3571 RVA: 0x000529D0 File Offset: 0x00050BD0
		internal void KothUpdateData(EClientMode clientMode, EWinningTeam status, Team yourTeam, Team enemyTeam, int yourTeamScore, int enemyTeamScore, int yourTeamPlayerCount, int enemyTeamPlayerCount, int maxScore)
		{
			this.KothYourTeamLogo.texture = this.TeamLogos[(int)yourTeam];
			this.KothEnemyTeamLogo.texture = this.TeamLogos[(int)enemyTeam];
			this.KothYourTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(yourTeam, ELocalizedTextCase.UPPER_CASE);
			this.KothEnemyTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(enemyTeam, ELocalizedTextCase.UPPER_CASE);
			this.KothYourTeamText.SetActive(clientMode == EClientMode.PLAYER);
			this.KothEnemyTeamText.SetActive(clientMode == EClientMode.PLAYER);
			if (clientMode == EClientMode.PLAYER)
			{
				if (status != this._status)
				{
					if (status != EWinningTeam.MINE)
					{
						if (status != EWinningTeam.ENEMY)
						{
							if (status == EWinningTeam.NONE)
							{
								this.KothStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_1", ELocalizedTextCase.NONE);
							}
						}
						else
						{
							this.KothStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_0", ELocalizedTextCase.NONE);
						}
					}
					else
					{
						this.KothStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_2", ELocalizedTextCase.NONE);
					}
					this._status = status;
				}
			}
			else
			{
				this.KothStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_spectatormode", ELocalizedTextCase.NONE);
			}
			if (yourTeamScore != this._yourTeamLastScore)
			{
				this.KothYourTeamScoreText.text = yourTeamScore.ToString();
				this.KothYourTeamBar.material.SetFloat(this._fillParameterHash, (float)yourTeamScore / (float)maxScore);
				this._yourTeamLastScore = yourTeamScore;
			}
			if (enemyTeamScore != this._enemyTeamLastScore)
			{
				this.KothEnemyTeamScoreText.text = enemyTeamScore.ToString();
				this.KothEnemyTeamBar.material.SetFloat(this._fillParameterHash, (float)enemyTeamScore / (float)maxScore);
				this._enemyTeamLastScore = enemyTeamScore;
			}
			if (maxScore != this._maxScore)
			{
				this.KothYourTeamMaxScoreText.text = "/" + maxScore;
				this.KothEnemyTeamMaxScoreText.text = "/" + maxScore;
				this._maxScore = maxScore;
			}
			this._playerCountHasChanged = false;
			if (yourTeamPlayerCount != this._yourTeamPlayerCount)
			{
				this.KothYourTeamPlayerCountText.text = yourTeamPlayerCount.ToString();
				this._yourTeamPlayerCount = yourTeamPlayerCount;
				this._playerCountHasChanged = true;
			}
			if (enemyTeamPlayerCount != this._enemyTeamPlayerCount)
			{
				this.KothEnemyTeamPlayerCountText.text = enemyTeamPlayerCount.ToString();
				this._enemyTeamPlayerCount = enemyTeamPlayerCount;
				this._playerCountHasChanged = true;
			}
			float kingOfTheHillScore = this.GetKingOfTheHillScore(yourTeamPlayerCount);
			float kingOfTheHillScore2 = this.GetKingOfTheHillScore(enemyTeamPlayerCount);
			this._currentKingOfTheHillFillTarget = kingOfTheHillScore / (kingOfTheHillScore + kingOfTheHillScore2);
			if (!this._playerCountHasChanged)
			{
				return;
			}
			if (yourTeamPlayerCount == enemyTeamPlayerCount)
			{
				this.KothYourTeamStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_raiding", ELocalizedTextCase.NONE);
				this.KothEnemyTeamStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_raiding", ELocalizedTextCase.NONE);
			}
			else if (yourTeamPlayerCount > enemyTeamPlayerCount)
			{
				this.KothYourTeamStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_guarding", ELocalizedTextCase.NONE);
				this.KothEnemyTeamStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_raiding", ELocalizedTextCase.NONE);
			}
			else
			{
				this.KothYourTeamStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_raiding", ELocalizedTextCase.NONE);
				this.KothEnemyTeamStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_guarding", ELocalizedTextCase.NONE);
			}
		}

		// Token: 0x06000DF4 RID: 3572 RVA: 0x0000B829 File Offset: 0x00009A29
		internal float GetKingOfTheHillScore(int players)
		{
			return 1f + Mathf.Pow((float)players, this.KingOfTheHillPowFactor);
		}

		// Token: 0x06000DF5 RID: 3573 RVA: 0x00052D3C File Offset: 0x00050F3C
		internal void CtpSetNumberOfCapturePoints(int numberOfPoints)
		{
			if (numberOfPoints == this._numberOfPoints)
			{
				return;
			}
			this._numberOfPoints = numberOfPoints;
			for (int i = 0; i < this.Points.Length; i++)
			{
				this.Points[i].gameObject.SetActive(i < numberOfPoints);
				if (i >= numberOfPoints)
				{
					this.YourCtpPoints[i].SetActive(false);
					this.NeutralCtpPoints[i].SetActive(false);
					this.EnemyCtpPoints[i].SetActive(false);
				}
			}
		}

		// Token: 0x06000DF6 RID: 3574 RVA: 0x00052DC4 File Offset: 0x00050FC4
		internal void CtpUpdateData(EClientMode clientMode, EWinningTeam status, Team yourTeam, Team enemyTeam, int yourTeamScore, int enemyTeamScore, int maxScore, int yourTeamPoints, int enemyTeamPoints)
		{
			this.CtpYourTeamLogo.texture = this.TeamLogos[(int)yourTeam];
			this.CtpEnemyTeamLogo.texture = this.TeamLogos[(int)enemyTeam];
			this.CtpYourTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(yourTeam, ELocalizedTextCase.UPPER_CASE);
			this.CtpEnemyTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(enemyTeam, ELocalizedTextCase.UPPER_CASE);
			this.CtpYourTeamText.SetActive(clientMode == EClientMode.PLAYER);
			this.CtpEnemyTeamText.SetActive(clientMode == EClientMode.PLAYER);
			if (clientMode == EClientMode.PLAYER)
			{
				if (status != this._status)
				{
					if (status != EWinningTeam.MINE)
					{
						if (status != EWinningTeam.ENEMY)
						{
							if (status == EWinningTeam.NONE)
							{
								this.CtpStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_1", ELocalizedTextCase.NONE);
							}
						}
						else
						{
							this.CtpStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_0", ELocalizedTextCase.NONE);
						}
					}
					else
					{
						this.CtpStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_ingame_status_2", ELocalizedTextCase.NONE);
					}
					this._status = status;
				}
			}
			else
			{
				this.CtpStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_spectatormode", ELocalizedTextCase.NONE);
			}
			if (yourTeamScore != this._yourTeamLastScore)
			{
				this.CtpYourTeamScoreText.text = yourTeamScore.ToString();
				this.CtpYourTeamBar.material.SetFloat(this._fillParameterHash, (float)yourTeamScore / (float)maxScore);
				this._yourTeamLastScore = yourTeamScore;
			}
			if (enemyTeamScore != this._enemyTeamLastScore)
			{
				this.CtpEnemyTeamScoreText.text = enemyTeamScore.ToString();
				this.CtpEnemyTeamBar.material.SetFloat(this._fillParameterHash, (float)enemyTeamScore / (float)maxScore);
				this._enemyTeamLastScore = enemyTeamScore;
			}
			if (maxScore != this._maxScore)
			{
				this.CtpTotalTeamScoreText.text = maxScore.ToString();
				this._maxScore = maxScore;
			}
			if (yourTeamPoints != this._yourTeamPoints)
			{
				this.CtpYourTeamDominingPointsText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get((yourTeamPoints != 1) ? "team_ctp_points" : "team_ctp_point", ELocalizedTextCase.NONE), yourTeamPoints);
				this._yourTeamPoints = yourTeamPoints;
			}
			if (enemyTeamPoints != this._enemyTeamPoints)
			{
				this.CtpEnemyTeamDominingPointsText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get((yourTeamPoints != 1) ? "team_ctp_points" : "team_ctp_point", ELocalizedTextCase.NONE), enemyTeamPoints);
				this._enemyTeamPoints = enemyTeamPoints;
			}
		}

		// Token: 0x06000DF7 RID: 3575 RVA: 0x00053054 File Offset: 0x00051254
		internal void CtpUpdatePointState(int pointIndex, UITeam ownerTeam, UITeam capturingTeam, float captureAmount, bool isProtected, bool playerIsCapturing)
		{
			if (ownerTeam != UITeam.Mine)
			{
				if (ownerTeam != UITeam.None)
				{
					if (ownerTeam == UITeam.Other)
					{
						this.EnemyCtpPoints[pointIndex].SetActive(true);
					}
				}
				else
				{
					this.NeutralCtpPoints[pointIndex].SetActive(true);
				}
			}
			else
			{
				this.YourCtpPoints[pointIndex].SetActive(true);
			}
			if (pointIndex >= 0 && pointIndex < 5)
			{
				this.Points[pointIndex].SetState(ownerTeam, capturingTeam, captureAmount, isProtected, playerIsCapturing);
			}
		}

		// Token: 0x06000DF8 RID: 3576 RVA: 0x000530D8 File Offset: 0x000512D8
		internal void UpdateYourTeamList(EGameMode gameMode, HighSpeedArray<ClientCommonMetaData> playerData, EClientMode clientMode, long spectatorPlayerSelected)
		{
			switch (gameMode)
			{
			case EGameMode.TeamDeathMatch:
				this.SetPlayerList(this.TdmYourTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.Conquest:
				this.SetPlayerList(this.CtpYourTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.KingOfTheHill:
				this.SetPlayerList(this.KothYourTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.Rounds:
				this.SetPlayerList(this.RoundsYourTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.FreeForAll:
				this.SetPlayerList(this.FfaAllPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.Juggernaut:
				this.SetPlayerList(this.JugAllPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			}
		}

		// Token: 0x06000DF9 RID: 3577 RVA: 0x00053188 File Offset: 0x00051388
		internal void UpdateEnemyTeamList(EGameMode gameMode, HighSpeedArray<ClientCommonMetaData> playerData, EClientMode clientMode, long spectatorPlayerSelected)
		{
			switch (gameMode)
			{
			case EGameMode.TeamDeathMatch:
				this.SetPlayerList(this.TdmEnemyTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.Conquest:
				this.SetPlayerList(this.CtpEnemyTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.KingOfTheHill:
				this.SetPlayerList(this.KothEnemyTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			case EGameMode.Rounds:
				this.SetPlayerList(this.RoundsEnemyTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
				break;
			}
		}

		// Token: 0x06000DFA RID: 3578 RVA: 0x00053208 File Offset: 0x00051408
		public void Update()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._currentKingOfTheHillFillFactor = Mathf.Lerp(this._currentKingOfTheHillFillFactor, this._currentKingOfTheHillFillTarget, this.KingOfTheHillFillDamping * Time.deltaTime);
			this.KothCenterWheel.material.SetFloat(this._fillParameterHash, this._currentKingOfTheHillFillFactor);
		}

		// Token: 0x06000DFB RID: 3579 RVA: 0x00053260 File Offset: 0x00051460
		private void SetPlayerList(PoolableList<ScoreboardPlayerComponent> teamPlayerTemplate, HighSpeedArray<ClientCommonMetaData> playerData, EClientMode mode, long spectatorPlayerSelected)
		{
			teamPlayerTemplate.SetActiveCount(playerData.Length);
			for (int i = 0; i < playerData.Length; i++)
			{
				ScoreboardPlayerComponent scoreboardPlayerComponent = teamPlayerTemplate[i];
				float pingForPlayer = ServiceProvider.GetService<RemoteCharactersService>().GetPingForPlayer(playerData[i].User);
				scoreboardPlayerComponent.SetData(i + 1, playerData[i], UserProfile.IsMe(playerData[i].User) || playerData[i].User == spectatorPlayerSelected, mode == EClientMode.SPECTATOR, pingForPlayer);
				scoreboardPlayerComponent.OnPlayerClick = new Action<long>(this.OnPlayerClick);
			}
		}

		// Token: 0x06000DFC RID: 3580 RVA: 0x0000B83E File Offset: 0x00009A3E
		private void OnPlayerClick(long playerId)
		{
			base._controller.DispatchSpectatorOrbit(playerId);
		}

		// Token: 0x04001135 RID: 4405
		private int _fillParameterHash;

		// Token: 0x04001136 RID: 4406
		[Header("GameMode Roots")]
		public GameObject TdmRoot;

		// Token: 0x04001137 RID: 4407
		public GameObject RoundsRoot;

		// Token: 0x04001138 RID: 4408
		public GameObject CtpRoot;

		// Token: 0x04001139 RID: 4409
		public GameObject KothRoot;

		// Token: 0x0400113A RID: 4410
		public GameObject FfaRoot;

		// Token: 0x0400113B RID: 4411
		public GameObject JugRoot;

		// Token: 0x0400113C RID: 4412
		public Texture[] TeamLogos;

		// Token: 0x0400113D RID: 4413
		[Header("TDM")]
		public GameObject TdmYourTeamText;

		// Token: 0x0400113E RID: 4414
		public GameObject TdmEnemyTeamText;

		// Token: 0x0400113F RID: 4415
		public Text TdmStatusText;

		// Token: 0x04001140 RID: 4416
		public RawImage TdmYourTeamLogo;

		// Token: 0x04001141 RID: 4417
		public RawImage TdmEnemyTeamLogo;

		// Token: 0x04001142 RID: 4418
		public Text TdmYourTeamNameText;

		// Token: 0x04001143 RID: 4419
		public Text TdmEnemyTeamNameText;

		// Token: 0x04001144 RID: 4420
		public Text TdmYourTeamScoreText;

		// Token: 0x04001145 RID: 4421
		public Text TdmEnemyTeamScoreText;

		// Token: 0x04001146 RID: 4422
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList TdmYourTeamPlayerList;

		// Token: 0x04001147 RID: 4423
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList TdmEnemyTeamPlayerList;

		// Token: 0x04001148 RID: 4424
		[Header("ROUNDS")]
		public GameObject RoundsYourTeamText;

		// Token: 0x04001149 RID: 4425
		public GameObject RoundsEnemyTeamText;

		// Token: 0x0400114A RID: 4426
		public Text RoundsStatusText;

		// Token: 0x0400114B RID: 4427
		public Text RoundsCurrent;

		// Token: 0x0400114C RID: 4428
		public RawImage RoundsYourTeamLogo;

		// Token: 0x0400114D RID: 4429
		public RawImage RoundsEnemyTeamLogo;

		// Token: 0x0400114E RID: 4430
		public GameplayScoreboardView.ScoreboardRoundPlayerComponentPoolableList RoundsYourTeamPlayers;

		// Token: 0x0400114F RID: 4431
		public GameplayScoreboardView.ScoreboardRoundPlayerComponentPoolableList RoundsEnemyTeamPlayers;

		// Token: 0x04001150 RID: 4432
		public Text RoundsYourTeamNameText;

		// Token: 0x04001151 RID: 4433
		public Text RoundsEnemyTeamNameText;

		// Token: 0x04001152 RID: 4434
		public Text RoundsYourTeamScoreText;

		// Token: 0x04001153 RID: 4435
		public Text RoundsEnemyTeamScoreText;

		// Token: 0x04001154 RID: 4436
		public Text RoundsYourWinsText;

		// Token: 0x04001155 RID: 4437
		public Text RoundsEnemyWinsText;

		// Token: 0x04001156 RID: 4438
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList RoundsYourTeamPlayerList;

		// Token: 0x04001157 RID: 4439
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList RoundsEnemyTeamPlayerList;

		// Token: 0x04001158 RID: 4440
		[Header("FFA")]
		public Text FfaStatusTeam;

		// Token: 0x04001159 RID: 4441
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList FfaAllPlayerList;

		// Token: 0x0400115A RID: 4442
		[Header("Juggernaut")]
		public Text JugStatusTeam;

		// Token: 0x0400115B RID: 4443
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList JugAllPlayerList;

		// Token: 0x0400115C RID: 4444
		[Header("KOTH")]
		public GameObject KothYourTeamText;

		// Token: 0x0400115D RID: 4445
		public GameObject KothEnemyTeamText;

		// Token: 0x0400115E RID: 4446
		public Text KothStatusText;

		// Token: 0x0400115F RID: 4447
		public RawImage KothYourTeamLogo;

		// Token: 0x04001160 RID: 4448
		public RawImage KothEnemyTeamLogo;

		// Token: 0x04001161 RID: 4449
		public Text KothYourTeamNameText;

		// Token: 0x04001162 RID: 4450
		public Text KothEnemyTeamNameText;

		// Token: 0x04001163 RID: 4451
		public Text KothYourTeamStatusText;

		// Token: 0x04001164 RID: 4452
		public Text KothYourTeamScoreText;

		// Token: 0x04001165 RID: 4453
		public Text KothYourTeamMaxScoreText;

		// Token: 0x04001166 RID: 4454
		public Text KothYourTeamPlayerCountText;

		// Token: 0x04001167 RID: 4455
		public Text KothEnemyTeamStatusText;

		// Token: 0x04001168 RID: 4456
		public Text KothEnemyTeamScoreText;

		// Token: 0x04001169 RID: 4457
		public Text KothEnemyTeamMaxScoreText;

		// Token: 0x0400116A RID: 4458
		public Text KothEnemyTeamPlayerCountText;

		// Token: 0x0400116B RID: 4459
		public Renderer KothCenterWheel;

		// Token: 0x0400116C RID: 4460
		public Renderer KothYourTeamBar;

		// Token: 0x0400116D RID: 4461
		public Renderer KothEnemyTeamBar;

		// Token: 0x0400116E RID: 4462
		public float KingOfTheHillPowFactor = 1.5f;

		// Token: 0x0400116F RID: 4463
		public float KingOfTheHillFillDamping = 0.5f;

		// Token: 0x04001170 RID: 4464
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList KothYourTeamPlayerList;

		// Token: 0x04001171 RID: 4465
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList KothEnemyTeamPlayerList;

		// Token: 0x04001172 RID: 4466
		[Header("CTP")]
		public GameObject CtpYourTeamText;

		// Token: 0x04001173 RID: 4467
		public GameObject CtpEnemyTeamText;

		// Token: 0x04001174 RID: 4468
		public Text CtpStatusText;

		// Token: 0x04001175 RID: 4469
		public RawImage CtpYourTeamLogo;

		// Token: 0x04001176 RID: 4470
		public RawImage CtpEnemyTeamLogo;

		// Token: 0x04001177 RID: 4471
		public Text CtpYourTeamNameText;

		// Token: 0x04001178 RID: 4472
		public Text CtpEnemyTeamNameText;

		// Token: 0x04001179 RID: 4473
		public Text CtpYourTeamScoreText;

		// Token: 0x0400117A RID: 4474
		public Text CtpEnemyTeamScoreText;

		// Token: 0x0400117B RID: 4475
		public Text CtpTotalTeamScoreText;

		// Token: 0x0400117C RID: 4476
		public Text CtpYourTeamDominingPointsText;

		// Token: 0x0400117D RID: 4477
		public Text CtpEnemyTeamDominingPointsText;

		// Token: 0x0400117E RID: 4478
		public Renderer CtpYourTeamBar;

		// Token: 0x0400117F RID: 4479
		public Renderer CtpEnemyTeamBar;

		// Token: 0x04001180 RID: 4480
		public GameplayCapturePointComponent[] Points;

		// Token: 0x04001181 RID: 4481
		public GameObject[] YourCtpPoints;

		// Token: 0x04001182 RID: 4482
		public GameObject[] NeutralCtpPoints;

		// Token: 0x04001183 RID: 4483
		public GameObject[] EnemyCtpPoints;

		// Token: 0x04001184 RID: 4484
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList CtpYourTeamPlayerList;

		// Token: 0x04001185 RID: 4485
		public GameplayScoreboardView.ScoreboardPlayerComponentPoolableList CtpEnemyTeamPlayerList;

		// Token: 0x04001186 RID: 4486
		private EGameMode _lastGameMode;

		// Token: 0x04001187 RID: 4487
		private int _yourTeamLastScore = -1;

		// Token: 0x04001188 RID: 4488
		private int _enemyTeamLastScore = -1;

		// Token: 0x04001189 RID: 4489
		private int _yourTeamPlayerCount = -1;

		// Token: 0x0400118A RID: 4490
		private int _enemyTeamPlayerCount = -1;

		// Token: 0x0400118B RID: 4491
		private bool _playerCountHasChanged = true;

		// Token: 0x0400118C RID: 4492
		private EWinningTeam _status = EWinningTeam.UNDEFINED;

		// Token: 0x0400118D RID: 4493
		private float _currentKingOfTheHillFillFactor = 0.5f;

		// Token: 0x0400118E RID: 4494
		private float _currentKingOfTheHillFillTarget = 0.5f;

		// Token: 0x0400118F RID: 4495
		private int _maxScore = -1;

		// Token: 0x04001190 RID: 4496
		private int _yourTeamPoints = -1;

		// Token: 0x04001191 RID: 4497
		private int _enemyTeamPoints = -1;

		// Token: 0x04001192 RID: 4498
		private int _numberOfPoints = -1;

		// Token: 0x04001193 RID: 4499
		private int _yourWinsLast = -1;

		// Token: 0x04001194 RID: 4500
		private int _enemyWinsLast = -1;

		// Token: 0x04001195 RID: 4501
		private short _lastRound = -1;

		// Token: 0x0200028D RID: 653
		[Serializable]
		public class ScoreboardPlayerComponentPoolableList : PoolableList<ScoreboardPlayerComponent>
		{
		}

		// Token: 0x0200028E RID: 654
		[Serializable]
		public class ScoreboardRoundPlayerComponentPoolableList : PoolableList<GameplayRoundPlayerComponent>
		{
		}
	}
}
