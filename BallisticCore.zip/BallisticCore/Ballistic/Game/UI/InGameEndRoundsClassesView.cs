﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002B8 RID: 696
	public class InGameEndRoundsClassesView : BaseView<InGameRespawnController>
	{
		// Token: 0x06000EA0 RID: 3744 RVA: 0x0000BEB9 File Offset: 0x0000A0B9
		protected override void Awake()
		{
			base.Awake();
			this.RoundsClasses.Template.Dispose();
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x000589A4 File Offset: 0x00056BA4
		internal void SetSelectedData(EGameMode mode, HighSpeedArray<ClientCommonMetaData> selectedClasses)
		{
			bool flag = mode == EGameMode.Rounds;
			if (this.RoundsClassesRoot.activeSelf != flag)
			{
				this.RoundsClassesRoot.SetActive(flag);
			}
			this.RoundsClasses.SetActiveCount(6);
			for (int i = 0; i < 6; i++)
			{
				bool flag2 = i < selectedClasses.Length;
				this.RoundsClasses[i].SetState(flag2, (!flag2) ? string.Empty : selectedClasses[i].Nickname, (!flag2) ? EHeroClass.NONE : LoadoutUtil.GetHeroClass(selectedClasses[i].LoadoutInfo));
			}
		}

		// Token: 0x0400137B RID: 4987
		public GameObject RoundsClassesRoot;

		// Token: 0x0400137C RID: 4988
		public InGameEndRoundsClassesView.GameplayRoundClassComponentList RoundsClasses;

		// Token: 0x020002B9 RID: 697
		[Serializable]
		public class GameplayRoundClassComponentList : PoolableList<GameplayRoundClassComponent>
		{
		}
	}
}
