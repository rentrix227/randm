﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001E7 RID: 487
	public class ItemDetailsSkillTooltipComponent : MonoBehaviour
	{
		// Token: 0x060009D5 RID: 2517 RVA: 0x00008D91 File Offset: 0x00006F91
		public void Awake()
		{
			this._toggle = base.GetComponent<Toggle>();
			if (this._toggle != null)
			{
				this._toggle.onValueChanged.AddListener(new UnityAction<bool>(this.HandleToggleValueChanged));
			}
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x00008DCC File Offset: 0x00006FCC
		private void HandleToggleValueChanged(bool valueSet)
		{
			if (this._isSetting)
			{
				return;
			}
			if (this.OnSkillClick != null)
			{
				this.OnSkillClick(this, valueSet);
			}
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0003A8E8 File Offset: 0x00038AE8
		public void SetSkill(string skillName, bool wasReplaced = false)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.SkillName.text = service.GetSkillName(skillName, ELocalizedTextCase.UPPER_CASE);
			this.SkillDescription.text = service.GetSkillDescription(skillName, ELocalizedTextCase.NONE);
			TextureHelper.LoadImageAsync(TextureHelper.GetSkillIconPath(skillName), this.SkillIcon, false, EImageSource.RESOURCES);
			if (this._toggle != null)
			{
				this._isSetting = true;
				this._toggle.isOn = wasReplaced;
				this._isSetting = false;
			}
		}

		// Token: 0x04000D1E RID: 3358
		public Text SkillName;

		// Token: 0x04000D1F RID: 3359
		public Text SkillDescription;

		// Token: 0x04000D20 RID: 3360
		public Image SkillIcon;

		// Token: 0x04000D21 RID: 3361
		public Action<ItemDetailsSkillTooltipComponent, bool> OnSkillClick;

		// Token: 0x04000D22 RID: 3362
		private Toggle _toggle;

		// Token: 0x04000D23 RID: 3363
		private bool _isSetting;
	}
}
