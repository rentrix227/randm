﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000302 RID: 770
	public class SeasonInfoTitleView : BaseView<SeasonController>
	{
		// Token: 0x06000FF7 RID: 4087 RVA: 0x0005DA70 File Offset: 0x0005BC70
		internal void SetData(SeasonInfo seasonInfo)
		{
			string seasonIconPath = TextureHelper.GetSeasonIconPath(seasonInfo.Season, EImageSize.LARGE);
			TextureHelper.LoadImageAsync(seasonIconPath, this.SeasonIcon, false, EImageSource.RESOURCES);
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.SeasonNameLabel.text = service.GetSeasonName(seasonInfo.Season, ELocalizedTextCase.NONE);
		}

		// Token: 0x04001525 RID: 5413
		public Image SeasonIcon;

		// Token: 0x04001526 RID: 5414
		public Text SeasonNameLabel;
	}
}
