﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002A3 RID: 675
	public class InGameChooseTeamView : BaseView<GameplayScoreboardController>
	{
		// Token: 0x06000E58 RID: 3672 RVA: 0x00055504 File Offset: 0x00053704
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.ToggleMFATeam.onValueChanged.AddListener(new UnityAction<bool>(this.OnMFASelected));
			this.ToggleSMKTeam.onValueChanged.AddListener(new UnityAction<bool>(this.OnSMKSelected));
			this.ToggleAnyTeam.onClick.AddListener(new UnityAction(this.OnAnyTeamSelected));
			this.MfaPlayerList.Template.Dispose();
			this.SmkPlayerList.Template.Dispose();
		}

		// Token: 0x06000E59 RID: 3673 RVA: 0x00055598 File Offset: 0x00053798
		internal void SetData(Team team, ETeamMode teamMode, int mfaScore, QueueState mfaQueueState, int mfaWaitingAmount, int smkScore, QueueState smkQueueState, int smkWaitingAmount, bool includePlayerAtEndOfMfa, bool includePlayerAtEndOfSmk, Dictionary<long, ClientCommonMetaData> players)
		{
			this._isSetting = true;
			this._mfaScore = mfaScore;
			this._smkScore = smkScore;
			this._mfaPlayers = players.Values.Sum((ClientCommonMetaData t) => (t.ClientMode != EClientMode.PLAYER || (int)t.Team != 1) ? 1 : 0) + mfaWaitingAmount;
			this._smkPlayers = players.Values.Sum((ClientCommonMetaData t) => (t.ClientMode != EClientMode.PLAYER || (int)t.Team != 2) ? 1 : 0) + smkWaitingAmount;
			this.MfaScoreText.text = mfaScore.ToString();
			this.SmkScoreText.text = smkScore.ToString();
			bool flag = team == Team.MFA;
			bool flag2 = team == Team.SMOKE;
			if (this.ToggleMFATeam.isOn != flag && teamMode != ETeamMode.UNDEFINED && teamMode != ETeamMode.ANY)
			{
				this.ToggleMFATeam.isOn = flag;
			}
			if (this.ToggleSMKTeam.isOn != flag2 && teamMode != ETeamMode.UNDEFINED && teamMode != ETeamMode.ANY)
			{
				this.ToggleSMKTeam.isOn = flag2;
			}
			this._lastMfaState = this.ToggleMFATeam.isOn;
			this._lastSmkState = this.ToggleSMKTeam.isOn;
			this.ToggleAnyTeam.gameObject.SetActive(teamMode == ETeamMode.UNDEFINED || Time.time < this._lastTimeViewAreUndefined + 2f);
			this.MfaWaitingRoot.SetActive(mfaQueueState != QueueState.OPEN);
			this.MfaQueueWaitingRoot.SetActive(mfaQueueState == QueueState.FULL && mfaWaitingAmount > 0);
			if (mfaQueueState == QueueState.FULL && mfaWaitingAmount > 0)
			{
				this.MfaQueueWaitingText.text = mfaWaitingAmount.ToString() + " " + ServiceProvider.GetService<LocalizationService>().Get("waiting", ELocalizedTextCase.CAPITALIZE);
				this.MfaMessegeText.text = ServiceProvider.GetService<LocalizationService>().Get("spectator_match_full", ELocalizedTextCase.NONE);
			}
			this.MfaRebalanceRoot.SetActive(mfaQueueState == QueueState.REBALANCE && mfaWaitingAmount > 0);
			if (mfaQueueState == QueueState.REBALANCE && mfaWaitingAmount > 0)
			{
				this.MfaRebalanceText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("rebalance_position", ELocalizedTextCase.NONE), mfaWaitingAmount);
				this.MfaMessegeText.text = ServiceProvider.GetService<LocalizationService>().Get("spectator_match_unbalanced", ELocalizedTextCase.NONE);
			}
			this.MfaYouAreNextRoot.SetActive(mfaWaitingAmount <= 0);
			this.SmkWaitingRoot.SetActive(smkQueueState != QueueState.OPEN);
			this.SmkQueueWaitingRoot.SetActive(smkQueueState == QueueState.FULL && smkWaitingAmount > 0);
			if (smkQueueState == QueueState.FULL && smkWaitingAmount > 0)
			{
				this.SmkQueueWaitingText.text = smkWaitingAmount.ToString() + " " + ServiceProvider.GetService<LocalizationService>().Get("waiting", ELocalizedTextCase.CAPITALIZE);
				this.SmkMessegeText.text = ServiceProvider.GetService<LocalizationService>().Get("spectator_match_full", ELocalizedTextCase.NONE);
			}
			this.SmkRebalanceRoot.SetActive(smkQueueState == QueueState.REBALANCE && smkWaitingAmount > 0);
			if (smkQueueState == QueueState.REBALANCE && smkWaitingAmount > 0)
			{
				this.SmkRebalanceText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("rebalance_position", ELocalizedTextCase.NONE), smkWaitingAmount);
				this.SmkMessegeText.text = ServiceProvider.GetService<LocalizationService>().Get("spectator_match_unbalanced", ELocalizedTextCase.NONE);
			}
			this.SmkYouAreNextRoot.SetActive(smkWaitingAmount <= 0);
			long currentUser = ServiceProvider.GetService<SpectatorService>().GetCurrentUser();
			this.MfaPlayerList.SetActiveCount(players.Count);
			int num = 0;
			int num2 = 0;
			foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in players)
			{
				ChoosePlayerComponent choosePlayerComponent = this.MfaPlayerList[num];
				bool flag3 = UserProfile.IsMe(keyValuePair.Value.User);
				bool flag4 = ((byte)keyValuePair.Value.Team == 1 && keyValuePair.Value.ClientMode == EClientMode.PLAYER && (!flag3 || (flag3 && !includePlayerAtEndOfSmk))) || (includePlayerAtEndOfMfa && flag3 && mfaQueueState == QueueState.OPEN);
				bool flag5 = keyValuePair.Value.User == currentUser;
				bool flag6 = !flag3 && SteamFriends.HasFriend(new CSteamID((ulong)keyValuePair.Value.User), 4);
				choosePlayerComponent.SetData((!flag4) ? 0 : (num2 + 1), keyValuePair.Value, flag4, flag3, flag5, flag6);
				if (flag4)
				{
					num2++;
				}
				num++;
			}
			this.SmkPlayerList.SetActiveCount(players.Count);
			num = 0;
			num2 = 0;
			foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair2 in players)
			{
				ChoosePlayerComponent choosePlayerComponent2 = this.SmkPlayerList[num];
				bool flag7 = UserProfile.IsMe(keyValuePair2.Value.User);
				bool flag8 = ((byte)keyValuePair2.Value.Team == 2 && keyValuePair2.Value.ClientMode == EClientMode.PLAYER && (!flag7 || (flag7 && !includePlayerAtEndOfMfa))) || (includePlayerAtEndOfSmk && flag7 && smkQueueState == QueueState.OPEN);
				bool flag9 = keyValuePair2.Value.User == currentUser;
				bool flag10 = !flag7 && SteamFriends.HasFriend(new CSteamID((ulong)keyValuePair2.Value.User), 4);
				choosePlayerComponent2.SetData((!flag8) ? 0 : (num2 + 1), keyValuePair2.Value, flag8, flag7, flag9, flag10);
				if (flag8)
				{
					num2++;
				}
				num++;
			}
			this._isSetting = false;
		}

		// Token: 0x06000E5A RID: 3674 RVA: 0x0000BB1D File Offset: 0x00009D1D
		public void IncludeSelfMFA()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			base._controller.SetChooseViewIncludeData(true, false);
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x0000BB37 File Offset: 0x00009D37
		public void IncludeSelfSmoke()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			base._controller.SetChooseViewIncludeData(false, true);
		}

		// Token: 0x06000E5C RID: 3676 RVA: 0x0000BB51 File Offset: 0x00009D51
		public void ClearInclude()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			base._controller.SetChooseViewIncludeData(false, false);
		}

		// Token: 0x06000E5D RID: 3677 RVA: 0x00055BB8 File Offset: 0x00053DB8
		private void OnAnyTeamSelected()
		{
			if (UserProfile.LocalGameClient.requestMode != ETeamMode.UNDEFINED)
			{
				return;
			}
			ETeamMode eteamMode;
			if (this._mfaPlayers == this._smkPlayers)
			{
				eteamMode = ((this._mfaScore >= this._smkScore) ? ETeamMode.SMOKE : ETeamMode.MFA);
			}
			else if (this._mfaPlayers < this._smkPlayers)
			{
				eteamMode = ETeamMode.MFA;
			}
			else
			{
				eteamMode = ETeamMode.SMOKE;
			}
			this._isSetting = true;
			this.BlockerSMK.SetActive(true);
			this.BlockerMFA.SetActive(true);
			this.ToggleMFATeam.isOn = eteamMode == ETeamMode.MFA;
			this.ToggleSMKTeam.isOn = eteamMode == ETeamMode.SMOKE;
			this._lastTimeViewAreUndefined = Time.time;
			base._controller.DispatchRequestMode(eteamMode);
			this._isSetting = false;
		}

		// Token: 0x06000E5E RID: 3678 RVA: 0x00055C7C File Offset: 0x00053E7C
		private void OnSMKSelected(bool value)
		{
			if (this._isSetting || this._lastSmkState || !value)
			{
				return;
			}
			if (UserProfile.LocalGameClient.requestMode == ETeamMode.UNDEFINED)
			{
				this._lastTimeViewAreUndefined = Time.time;
			}
			this.BlockerSMK.SetActive(true);
			base._controller.DispatchRequestMode(ETeamMode.SMOKE);
		}

		// Token: 0x06000E5F RID: 3679 RVA: 0x00055CDC File Offset: 0x00053EDC
		private void OnMFASelected(bool value)
		{
			if (this._isSetting || !value || this._lastMfaState)
			{
				return;
			}
			if (UserProfile.LocalGameClient.requestMode == ETeamMode.UNDEFINED)
			{
				this._lastTimeViewAreUndefined = Time.time;
			}
			this.BlockerMFA.SetActive(true);
			base._controller.DispatchRequestMode(ETeamMode.MFA);
		}

		// Token: 0x06000E60 RID: 3680 RVA: 0x00002A31 File Offset: 0x00000C31
		public void ChangeDataComplete()
		{
		}

		// Token: 0x04001288 RID: 4744
		public Toggle ToggleMFATeam;

		// Token: 0x04001289 RID: 4745
		public Toggle ToggleSMKTeam;

		// Token: 0x0400128A RID: 4746
		public GameObject BlockerMFA;

		// Token: 0x0400128B RID: 4747
		public GameObject BlockerSMK;

		// Token: 0x0400128C RID: 4748
		public Button ToggleAnyTeam;

		// Token: 0x0400128D RID: 4749
		[Header("MFA")]
		public Text MfaScoreText;

		// Token: 0x0400128E RID: 4750
		public GameObject MfaWaitingRoot;

		// Token: 0x0400128F RID: 4751
		public GameObject MfaQueueWaitingRoot;

		// Token: 0x04001290 RID: 4752
		public Text MfaQueueWaitingText;

		// Token: 0x04001291 RID: 4753
		public GameObject MfaRebalanceRoot;

		// Token: 0x04001292 RID: 4754
		public Text MfaRebalanceText;

		// Token: 0x04001293 RID: 4755
		public GameObject MfaYouAreNextRoot;

		// Token: 0x04001294 RID: 4756
		public Text MfaMessegeText;

		// Token: 0x04001295 RID: 4757
		public InGameChooseTeamView.ChoosePlayerComponentList MfaPlayerList;

		// Token: 0x04001296 RID: 4758
		[Header("Smokes")]
		public Text SmkScoreText;

		// Token: 0x04001297 RID: 4759
		public GameObject SmkWaitingRoot;

		// Token: 0x04001298 RID: 4760
		public GameObject SmkQueueWaitingRoot;

		// Token: 0x04001299 RID: 4761
		public Text SmkQueueWaitingText;

		// Token: 0x0400129A RID: 4762
		public GameObject SmkRebalanceRoot;

		// Token: 0x0400129B RID: 4763
		public Text SmkRebalanceText;

		// Token: 0x0400129C RID: 4764
		public GameObject SmkYouAreNextRoot;

		// Token: 0x0400129D RID: 4765
		public Text SmkMessegeText;

		// Token: 0x0400129E RID: 4766
		public InGameChooseTeamView.ChoosePlayerComponentList SmkPlayerList;

		// Token: 0x0400129F RID: 4767
		private bool _isSetting;

		// Token: 0x040012A0 RID: 4768
		private int _mfaScore;

		// Token: 0x040012A1 RID: 4769
		private int _smkScore;

		// Token: 0x040012A2 RID: 4770
		private int _mfaPlayers;

		// Token: 0x040012A3 RID: 4771
		private int _smkPlayers;

		// Token: 0x040012A4 RID: 4772
		private bool _lastSmkState;

		// Token: 0x040012A5 RID: 4773
		private bool _lastMfaState;

		// Token: 0x040012A6 RID: 4774
		private float _lastTimeViewAreUndefined;

		// Token: 0x020002A4 RID: 676
		[Serializable]
		public class ChoosePlayerComponentList : PoolableList<ChoosePlayerComponent>
		{
		}
	}
}
