﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000265 RID: 613
	public class CustomMatchPopupView : BaseView<CustomMatchController>
	{
		// Token: 0x06000D31 RID: 3377 RVA: 0x0004E724 File Offset: 0x0004C924
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			MapImagePreviewComponent mapPreview = this.MapPreview;
			mapPreview.OnValueChanged = (Action<GameMapConfig>)Delegate.Combine(mapPreview.OnValueChanged, new Action<GameMapConfig>(this.OnMapChanged));
			this.CreateMatchBtn.onClick.AddListener(new UnityAction(this.OnCreateMatchClick));
			this.LobbyNameText.text = SteamFriends.GetPersonaName() + "'s Server";
		}

		// Token: 0x06000D32 RID: 3378 RVA: 0x0004E7A0 File Offset: 0x0004C9A0
		protected override void OnDestroy()
		{
			base.OnDestroy();
			this.CreateMatchBtn.onClick.RemoveListener(new UnityAction(this.OnCreateMatchClick));
			MapImagePreviewComponent mapPreview = this.MapPreview;
			mapPreview.OnValueChanged = (Action<GameMapConfig>)Delegate.Remove(mapPreview.OnValueChanged, new Action<GameMapConfig>(this.OnMapChanged));
		}

		// Token: 0x06000D33 RID: 3379 RVA: 0x0000B055 File Offset: 0x00009255
		private void OnMapChanged(GameMapConfig map)
		{
			this.ModePreview.UpdateAvaliableItems(map);
		}

		// Token: 0x06000D34 RID: 3380 RVA: 0x0004E7F8 File Offset: 0x0004C9F8
		private void OnCreateMatchClick()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			base._controller.CreateLobby(this.LobbyNameText.text, this.MapPreview.GetCurrentValue(), this.ModePreview.GetCurrentValue(), false, (!this.PasswordProtected.isOn) ? null : this.PasswordText.text);
		}

		// Token: 0x04001001 RID: 4097
		public MapImagePreviewComponent MapPreview;

		// Token: 0x04001002 RID: 4098
		public ModeImagePreviewComponent ModePreview;

		// Token: 0x04001003 RID: 4099
		public Toggle PublicMatch;

		// Token: 0x04001004 RID: 4100
		public Toggle PasswordProtected;

		// Token: 0x04001005 RID: 4101
		public Button CreateMatchBtn;

		// Token: 0x04001006 RID: 4102
		public InputField LobbyNameText;

		// Token: 0x04001007 RID: 4103
		public InputField PasswordText;
	}
}
