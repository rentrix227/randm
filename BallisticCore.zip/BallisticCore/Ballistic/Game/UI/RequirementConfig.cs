﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D6 RID: 470
	internal struct RequirementConfig
	{
		// Token: 0x04000CE1 RID: 3297
		internal ERequirementType Type;

		// Token: 0x04000CE2 RID: 3298
		internal EWeaponSkinName CollectionWeaponSkinName;

		// Token: 0x04000CE3 RID: 3299
		internal int CollectionAmountRemaining;

		// Token: 0x04000CE4 RID: 3300
		internal int CollectionAmountTotal;

		// Token: 0x04000CE5 RID: 3301
		internal WeaponV4 SpecificWeapon;

		// Token: 0x04000CE6 RID: 3302
		internal WeaponSkin SpecificSkin;

		// Token: 0x04000CE7 RID: 3303
		internal bool SpecificCompleted;
	}
}
