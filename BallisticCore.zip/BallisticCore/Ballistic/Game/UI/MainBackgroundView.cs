﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E7 RID: 743
	public class MainBackgroundView : BaseView<MainController>
	{
		// Token: 0x06000F95 RID: 3989 RVA: 0x0000CCE7 File Offset: 0x0000AEE7
		internal void SetStartHeroBackground(EHeroClass heroClass)
		{
			this.CurrentHeroBackground.texture = this.Backgrounds[(int)heroClass];
			this.NextHeroBackground.texture = this.Backgrounds[(int)heroClass];
			this._currentHeroClass = heroClass;
		}

		// Token: 0x06000F96 RID: 3990 RVA: 0x0000CD16 File Offset: 0x0000AF16
		internal void SetHeroBackground(EHeroClass heroClass)
		{
			this._currentHeroClass = heroClass;
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x0000CD1F File Offset: 0x0000AF1F
		public void PreChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.NextHeroBackground.texture = this.Backgrounds[(int)this._currentHeroClass];
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x0000CD44 File Offset: 0x0000AF44
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.CurrentHeroBackground.texture = this.Backgrounds[(int)this._currentHeroClass];
		}

		// Token: 0x040014BD RID: 5309
		public RawImage CurrentHeroBackground;

		// Token: 0x040014BE RID: 5310
		public RawImage NextHeroBackground;

		// Token: 0x040014BF RID: 5311
		public Texture2D[] Backgrounds;

		// Token: 0x040014C0 RID: 5312
		private EHeroClass _currentHeroClass;
	}
}
