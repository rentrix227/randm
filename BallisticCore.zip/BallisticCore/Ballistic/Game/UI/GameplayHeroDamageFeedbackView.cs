﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200027E RID: 638
	public class GameplayHeroDamageFeedbackView : BaseView<GameplayHeroController>
	{
		// Token: 0x06000D82 RID: 3458 RVA: 0x0004F7BC File Offset: 0x0004D9BC
		protected override void Awake()
		{
			base.Awake();
			this.BloodArrowList.Template.gameObject.SetActive(false);
			this._bloodVignetteAngles = new float[this.BloodVignette.sharedMesh.vertexCount];
			this._bloodVignetteTimers = new float[this.BloodVignette.sharedMesh.vertexCount];
			this._bloodVignetteColors = new Color[this.BloodVignette.sharedMesh.vertexCount];
			for (int i = 0; i < this._bloodVignetteAngles.Length; i++)
			{
				if (this.BloodVignette.sharedMesh.vertices[i].sqrMagnitude > 0.1f)
				{
					Vector3 vector;
					vector..ctor(this.BloodVignette.sharedMesh.vertices[i].x, 0f, this.BloodVignette.sharedMesh.vertices[i].y);
					this._bloodVignetteAngles[i] = Quaternion.LookRotation(vector, Vector3.up).eulerAngles.y;
				}
				else
				{
					this._bloodVignetteAngles[i] = 361f;
				}
				this._bloodVignetteColors[i] = new Color(0f, 0f, 0f, 0f);
			}
			this._internalBloodVignette = new Mesh
			{
				vertices = this.BloodVignette.sharedMesh.vertices,
				normals = this.BloodVignette.sharedMesh.normals,
				colors32 = this.BloodVignette.sharedMesh.colors32,
				name = this.BloodVignette.sharedMesh.name + "_Procedural",
				triangles = this.BloodVignette.sharedMesh.triangles,
				tangents = this.BloodVignette.sharedMesh.tangents,
				uv = this.BloodVignette.sharedMesh.uv,
				uv2 = this.BloodVignette.sharedMesh.uv2
			};
			this.BloodVignette.mesh = this._internalBloodVignette;
			this.ClearDamage();
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x0004FA00 File Offset: 0x0004DC00
		public void Update()
		{
			if (this.TestNow)
			{
				this.TestNow = false;
				this.SetExternalDamage(this.TestCamera, this.TestShooter.position, this.TestDamage);
			}
			this._arrows.RemoveAll((GameplayHeroDamageFeedbackView.Arrow t) => !t.BloodArrow.isActiveAndEnabled);
			if (OfflineInformation.OfflineUi || !base._controller.PlayerIsDead)
			{
				for (int i = 0; i < this._arrows.Length; i++)
				{
					this._arrows[i].BloodArrow.transform.localRotation = Quaternion.Euler(0f, 0f, this.GetAngular(this._arrows[i].ShooterPosition));
				}
			}
			if (this.JuggernautMode.isInitialized)
			{
				this.JuggernautMode.SetBool(GameplayHeroDamageFeedbackView._animIsJuggernautHash, this._isJuggernautActive);
			}
			this.DecreamentDamage(Time.deltaTime);
		}

		// Token: 0x06000D84 RID: 3460 RVA: 0x0000B49D File Offset: 0x0000969D
		public void SetJuggernautMode(bool isActive)
		{
			this._isJuggernautActive = isActive;
		}

		// Token: 0x06000D85 RID: 3461 RVA: 0x0004FB14 File Offset: 0x0004DD14
		internal void SetInternalDamage(float damageIntensity)
		{
			float num = Mathf.Clamp(damageIntensity, 0.1f, 1f);
			for (int i = 0; i < this._bloodVignetteColors.Length; i++)
			{
				if (this._bloodVignetteAngles[i] <= 360f)
				{
					this._bloodVignetteTimers[i] = num;
					this._bloodVignetteColors[i].a = this.BloodAnimationCurve.Evaluate(this._bloodVignetteTimers[i]);
				}
			}
			this._internalBloodVignette.colors = this._bloodVignetteColors;
		}

		// Token: 0x06000D86 RID: 3462 RVA: 0x0004FBA0 File Offset: 0x0004DDA0
		internal void SetExternalDamage(Camera camera, Vector3 shooterPosition, float damageIntensity)
		{
			this._camera = camera;
			float num = Mathf.Clamp(damageIntensity, 0.5f, 2f);
			GameplayHeroDamageFeedbackView.Arrow arrow = new GameplayHeroDamageFeedbackView.Arrow
			{
				BloodArrow = this.BloodArrowList.Instantiate(),
				ShooterPosition = shooterPosition
			};
			arrow.BloodArrow.GetComponent<Animator>().SetFloat("speed", num);
			arrow.BloodArrow.transform.localScale = new Vector3(num, 1f, 1f);
			this._arrows.Add(arrow);
			float angular = this.GetAngular(shooterPosition);
			for (int i = 0; i < this._bloodVignetteColors.Length; i++)
			{
				if (this._bloodVignetteAngles[i] <= 360f)
				{
					this._bloodVignetteTimers[i] += (float)((1f - Mathf.Abs(angular - this._bloodVignetteAngles[i]) / (30f * damageIntensity) <= 0f) ? 0 : 1);
					if (this._bloodVignetteTimers[i] > 1f)
					{
						this._bloodVignetteTimers[i] = 1f;
					}
					this._bloodVignetteColors[i].a = this.BloodAnimationCurve.Evaluate(this._bloodVignetteTimers[i]);
				}
			}
			this._internalBloodVignette.colors = this._bloodVignetteColors;
		}

		// Token: 0x06000D87 RID: 3463 RVA: 0x0004FD04 File Offset: 0x0004DF04
		private float SignedAngle(Vector3 from, Vector3 to, Vector3 axis)
		{
			float num = Vector3.Angle(from, to);
			Vector3 vector = Vector3.Cross(from, to);
			if (Vector3.Dot(vector, axis) < 0f)
			{
				num *= -1f;
			}
			return num;
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x0004FD3C File Offset: 0x0004DF3C
		private float GetAngular(Vector3 shooterPosition)
		{
			Vector3 forward = this._camera.transform.forward;
			forward.y = 0f;
			Vector3 vector = shooterPosition - this._camera.transform.position;
			Vector3 vector2 = vector;
			vector2.y = 0f;
			float num = this.SignedAngle(forward, vector2, Vector3.down);
			Vector3 vector3 = this._camera.WorldToScreenPoint(shooterPosition);
			vector3.x /= (float)this._camera.pixelWidth;
			vector3.y /= (float)this._camera.pixelHeight;
			vector3.z = 0f;
			Vector3 vector4 = vector3 - new Vector3(0.5f, 0.5f, 0f);
			if (vector4.y < 0f && vector4.y > -this.ArrowShooterYOffset)
			{
				vector4.y *= -1f;
			}
			float num4;
			if (Mathf.Abs(num) > this.MaxArrowAngleStart)
			{
				float num2 = Mathf.Sign(num);
				float num3 = 180f - Mathf.Abs(num);
				num4 = num2 * (180f - this.ArrowBehindScaleFactor * num3);
			}
			else
			{
				num4 = num * this.ArrowFrontScaleFactor;
			}
			return num4;
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x0004FE88 File Offset: 0x0004E088
		private void DecreamentDamage(float time)
		{
			time *= 1f / this.BloodTotalAnimationTime;
			for (int i = 0; i < this._bloodVignetteTimers.Length; i++)
			{
				this._bloodVignetteTimers[i] -= time;
				this._bloodVignetteColors[i].a = this.BloodAnimationCurve.Evaluate(this._bloodVignetteTimers[i]);
			}
			this._internalBloodVignette.colors = this._bloodVignetteColors;
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x0004FF04 File Offset: 0x0004E104
		internal void ClearDamage()
		{
			if (this._bloodVignetteColors == null)
			{
				return;
			}
			for (int i = 0; i < this._bloodVignetteColors.Length; i++)
			{
				this._bloodVignetteTimers[i] = 0f;
				this._bloodVignetteColors[i].a = this.BloodAnimationCurve.Evaluate(this._bloodVignetteTimers[i]);
			}
			this._internalBloodVignette.colors = this._bloodVignetteColors;
		}

		// Token: 0x04001075 RID: 4213
		private static int _animIsJuggernautHash = Animator.StringToHash("isJuggernaut");

		// Token: 0x04001076 RID: 4214
		public AnimationCurve BloodAnimationCurve = AnimationCurve.EaseInOut(0f, 1f, 1f, 0f);

		// Token: 0x04001077 RID: 4215
		public float BloodTotalAnimationTime = 4f;

		// Token: 0x04001078 RID: 4216
		public MeshFilter BloodVignette;

		// Token: 0x04001079 RID: 4217
		public PoolableList BloodArrowList;

		// Token: 0x0400107A RID: 4218
		public float ArrowShooterYOffset = 0.25f;

		// Token: 0x0400107B RID: 4219
		public float MaxArrowAngleStart = 60f;

		// Token: 0x0400107C RID: 4220
		public float MaxArrowAngleEnd = 80f;

		// Token: 0x0400107D RID: 4221
		public float ArrowCenterDistanceStart = 0.1f;

		// Token: 0x0400107E RID: 4222
		public float ArrowCenterDistanceEnd = 0.3f;

		// Token: 0x0400107F RID: 4223
		public float ArrowFrontScaleFactor = 0.9f;

		// Token: 0x04001080 RID: 4224
		public float ArrowBehindScaleFactor = 0.7f;

		// Token: 0x04001081 RID: 4225
		public Animator JuggernautMode;

		// Token: 0x04001082 RID: 4226
		private float[] _bloodVignetteAngles;

		// Token: 0x04001083 RID: 4227
		private float[] _bloodVignetteTimers;

		// Token: 0x04001084 RID: 4228
		private Color[] _bloodVignetteColors;

		// Token: 0x04001085 RID: 4229
		private Mesh _internalBloodVignette;

		// Token: 0x04001086 RID: 4230
		private bool _isJuggernautActive;

		// Token: 0x04001087 RID: 4231
		private Camera _camera;

		// Token: 0x04001088 RID: 4232
		private readonly HighSpeedArray<GameplayHeroDamageFeedbackView.Arrow> _arrows = new HighSpeedArray<GameplayHeroDamageFeedbackView.Arrow>(50);

		// Token: 0x04001089 RID: 4233
		[Header("Testing")]
		public bool TestNow;

		// Token: 0x0400108A RID: 4234
		public Camera TestCamera;

		// Token: 0x0400108B RID: 4235
		public Transform TestShooter;

		// Token: 0x0400108C RID: 4236
		public float TestDamage;

		// Token: 0x0200027F RID: 639
		internal struct Arrow
		{
			// Token: 0x0400108E RID: 4238
			internal PoolableComponent BloodArrow;

			// Token: 0x0400108F RID: 4239
			internal Vector3 ShooterPosition;
		}
	}
}
