﻿using System;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F0 RID: 496
	public class LoadSceneComponent : MonoBehaviour, IPointerClickHandler, IEventSystemHandler
	{
		// Token: 0x06000A01 RID: 2561 RVA: 0x0003B4A4 File Offset: 0x000396A4
		public void OnPointerClick(PointerEventData eventData)
		{
			if (this.ConfirmPopupToShow == EPopupType.NONE)
			{
				ServiceProvider.GetService<SceneService>().LoadMain(this.DefaultUIState);
			}
			else
			{
				ServiceProvider.GetService<PopupService>().Show(this.ConfirmPopupToShow, null, new Action<int>(this.OnButtonClicked), null, 0f);
			}
		}

		// Token: 0x06000A02 RID: 2562 RVA: 0x0003B4F4 File Offset: 0x000396F4
		private void OnButtonClicked(int result)
		{
			ServiceProvider.GetService<PopupService>().Hide(this.ConfirmPopupToShow);
			Debug.Log("Button:" + result);
			if (result == this.PopupConfirmButtonIndex)
			{
				UIManager.Instance.ChangeState("CUTSCENE");
				ServiceProvider.GetService<SceneService>().LoadMain(this.DefaultUIState);
			}
		}

		// Token: 0x04000D5A RID: 3418
		public string DefaultUIState = string.Empty;

		// Token: 0x04000D5B RID: 3419
		public EPopupType ConfirmPopupToShow;

		// Token: 0x04000D5C RID: 3420
		public int PopupConfirmButtonIndex = 2;
	}
}
