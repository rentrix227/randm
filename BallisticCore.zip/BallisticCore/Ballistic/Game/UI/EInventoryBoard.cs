﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000242 RID: 578
	internal enum EInventoryBoard
	{
		// Token: 0x04000F55 RID: 3925
		LOCKBOX,
		// Token: 0x04000F56 RID: 3926
		WEAPONSKIN,
		// Token: 0x04000F57 RID: 3927
		SCRAPS,
		// Token: 0x04000F58 RID: 3928
		VANITY
	}
}
