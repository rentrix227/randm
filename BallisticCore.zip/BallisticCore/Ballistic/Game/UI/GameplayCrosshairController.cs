﻿using System;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000217 RID: 535
	public class GameplayCrosshairController : BaseController
	{
		// Token: 0x06000ACD RID: 2765 RVA: 0x0003EEB0 File Offset: 0x0003D0B0
		public GameplayCrosshairController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._localCharacterService.OnAimingUpdate += this.OnAimingUpdate;
			this._localCharacterService.OnWeaponShotFired += this.OnWeaponShotFired;
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._eventProxy.EUpdate.AddListener(new Action(this.UpdateCrosshair));
			this._firerate = 1f;
		}

		// Token: 0x06000ACE RID: 2766 RVA: 0x000099E7 File Offset: 0x00007BE7
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this._crossView == null)
			{
				this._crossView = view as GameplayCrosshairView;
			}
		}

		// Token: 0x06000ACF RID: 2767 RVA: 0x0003EF7C File Offset: 0x0003D17C
		private void UpdateCrosshair()
		{
			if (this._currentPrecision < 0f)
			{
				this._currentPrecision = this._targetPrecision;
			}
			else
			{
				this._currentPrecision = Mathf.Lerp(this._currentPrecision, this._targetPrecision, 50f * Time.deltaTime);
			}
			if (this._crossView != null && this._crossView.isActiveAndEnabled)
			{
				this._crossView.SetCurrentPrecision(this._currentPrecision, this._pulseAmount, Mathf.Clamp01((Time.time - this._shakingCrosshairTimer) / this._firerate));
			}
		}

		// Token: 0x06000AD0 RID: 2768 RVA: 0x00009A18 File Offset: 0x00007C18
		private void OnWeaponShotFired()
		{
			this._shakingCrosshairTimer = Time.time;
		}

		// Token: 0x06000AD1 RID: 2769 RVA: 0x0003F01C File Offset: 0x0003D21C
		private void OnAimingUpdate(AimingUpdateStruct evt)
		{
			this._targetPrecision = evt.CurrentPrecision;
			this._pulseAmount = evt.PulsePrecisionLoss;
			this._firerate = evt.FireRate;
			if (this._crossView != null && this._crossView.isActiveAndEnabled)
			{
				this._crossView.SetCrosshair(evt.Crosshair);
				this._crossView.SetTargeting(evt.Targeting);
			}
		}

		// Token: 0x06000AD2 RID: 2770 RVA: 0x0003F098 File Offset: 0x0003D298
		private void OnUserHit(HitEvent evt)
		{
			if (!UserProfile.IsMe(evt.SenderId) || UserProfile.IsMe(evt.VictimGameClientId))
			{
				return;
			}
			GameplayCrosshairView view = base.GetView<GameplayCrosshairView>();
			if (view == null)
			{
				return;
			}
			view.SetHitTrigger();
		}

		// Token: 0x06000AD3 RID: 2771 RVA: 0x0003F0E0 File Offset: 0x0003D2E0
		private void OnDie(DieEvent evt)
		{
			if (!UserProfile.IsMe(evt.KillerId) || UserProfile.IsMe(evt.SenderId))
			{
				return;
			}
			GameplayCrosshairView view = base.GetView<GameplayCrosshairView>();
			if (view == null)
			{
				return;
			}
			view.SetKillTrigger();
		}

		// Token: 0x06000AD4 RID: 2772 RVA: 0x0003F128 File Offset: 0x0003D328
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._localCharacterService.OnAimingUpdate -= this.OnAimingUpdate;
		}

		// Token: 0x04000E54 RID: 3668
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E55 RID: 3669
		private readonly LocalCharacterService _localCharacterService;

		// Token: 0x04000E56 RID: 3670
		private readonly EventProxy _eventProxy;

		// Token: 0x04000E57 RID: 3671
		private const float _maxPrecisionChangeSpeed = 50f;

		// Token: 0x04000E58 RID: 3672
		private float _currentPrecision;

		// Token: 0x04000E59 RID: 3673
		private float _targetPrecision;

		// Token: 0x04000E5A RID: 3674
		private float _shakingCrosshairTimer;

		// Token: 0x04000E5B RID: 3675
		private float _pulseAmount;

		// Token: 0x04000E5C RID: 3676
		private float _firerate;

		// Token: 0x04000E5D RID: 3677
		private GameplayCrosshairView _crossView;
	}
}
