﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002A7 RID: 679
	public class InGameEndmatchProfileView : BasePlayerNameView<InGameEndmatchProgressionController>
	{
		// Token: 0x06000E76 RID: 3702 RVA: 0x0005607C File Offset: 0x0005427C
		public void ShowLockbox(EHeroClass heroClass, ESeason season, bool instant)
		{
			string lockboxIconPath = TextureHelper.GetLockboxIconPath(season, heroClass, EImageSize.SMALL);
			TextureHelper.LoadImageAsync(lockboxIconPath, this.LockboxIcon, false, EImageSource.RESOURCES);
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.LockboxTooltipText.text = string.Format(service.Get("got_a_new_lockbox", ELocalizedTextCase.NONE), service.GetLockboxName(heroClass, season, ELocalizedTextCase.UPPER_CASE));
			if (this.LockboxSeasonIcon != null)
			{
				string seasonIconPath = TextureHelper.GetSeasonIconPath(season, EImageSize.SMALL);
				TextureHelper.LoadImageAsync(seasonIconPath, this.LockboxSeasonIcon, false, EImageSource.RESOURCES);
			}
			this.LockboxAnimator.SetBool((!instant) ? "animate" : "ready", true);
		}

		// Token: 0x040012B7 RID: 4791
		public Animator LockboxAnimator;

		// Token: 0x040012B8 RID: 4792
		public Image LockboxIcon;

		// Token: 0x040012B9 RID: 4793
		public Text LockboxTooltipText;

		// Token: 0x040012BA RID: 4794
		public Image LockboxSeasonIcon;
	}
}
