﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200026D RID: 621
	public class EditWeaponAvaliableView : BaseView<SoldiersWeaponController>
	{
		// Token: 0x06000D4A RID: 3402 RVA: 0x0000B158 File Offset: 0x00009358
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.WeaponTemplate.Template.Dispose();
		}

		// Token: 0x06000D4B RID: 3403 RVA: 0x0004EAA0 File Offset: 0x0004CCA0
		internal void SetWeaponList(HighSpeedArray<PlayerWeaponData> avaliableWeapons, HighSpeedArray<WeaponV4> allWeaponsOfSlot, PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			this.WeaponTemplate.SetActiveCount(allWeaponsOfSlot.Length);
			int i;
			for (i = 0; i < avaliableWeapons.Length; i++)
			{
				AvailableWeaponComponent availableWeaponComponent = this.WeaponTemplate[i];
				availableWeaponComponent.SetData(avaliableWeapons[i], loadout, avaliableWeapons[i].PlayerItem.GameItemID == weapon.PlayerItem.GameItemID);
				availableWeaponComponent.OnWeaponPreview = new Action<PlayerWeaponData, PlayerLoadoutV2>(this.OnWeaponPreview);
				availableWeaponComponent.OnWeaponClick = new Action<PlayerWeaponData, PlayerLoadoutV2>(this.OnWeaponClick);
			}
			while (i < allWeaponsOfSlot.Length && i < this.WeaponTemplate.Count)
			{
				AvailableWeaponComponent availableWeaponComponent2 = this.WeaponTemplate[i];
				availableWeaponComponent2.SetData(allWeaponsOfSlot[i], loadout);
				i++;
			}
		}

		// Token: 0x06000D4C RID: 3404 RVA: 0x0000B17B File Offset: 0x0000937B
		private void OnWeaponClick(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			base._controller.DispatchWeaponClick(weapon, loadout);
		}

		// Token: 0x06000D4D RID: 3405 RVA: 0x0000B18A File Offset: 0x0000938A
		private void OnWeaponPreview(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			base._controller.DispatchWeaponPreview(weapon, loadout);
		}

		// Token: 0x04001012 RID: 4114
		public EditWeaponAvaliableView.AvailableWeaponComponentPoolableList WeaponTemplate;

		// Token: 0x0200026E RID: 622
		[Serializable]
		public class AvailableWeaponComponentPoolableList : PoolableList<AvailableWeaponComponent>
		{
		}
	}
}
