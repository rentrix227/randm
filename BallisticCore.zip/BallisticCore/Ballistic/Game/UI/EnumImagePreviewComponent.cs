﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C1 RID: 449
	public abstract class EnumImagePreviewComponent<T> : MonoBehaviour
	{
		// Token: 0x0600094A RID: 2378 RVA: 0x0003905C File Offset: 0x0003725C
		public void Awake()
		{
			if (!OfflineInformation.OfflineUi)
			{
				this.ImageTemplate.SetActive(false);
			}
			this.PreviousMapBtn.onClick.AddListener(new UnityAction(this.OnPreviousClick));
			this.NextMapBtn.onClick.AddListener(new UnityAction(this.OnNextClick));
			this._animators = new Dictionary<T, Animator>();
			this._availableItems = this.LoadAvailableItems();
			if (this._availableItems.Count <= 0)
			{
				return;
			}
			this._currentItem = this._availableItems.First<T>();
			foreach (T t in this._availableItems)
			{
				Animator component = Object.Instantiate<GameObject>(this.ImageTemplate, this.ImagesRoot, false).GetComponent<Animator>();
				this._animators[t] = component;
				component.GetComponent<RawImage>().enabled = t.Equals(this._currentItem);
				component.gameObject.SetActive(true);
			}
		}

		// Token: 0x0600094B RID: 2379 RVA: 0x0000873D File Offset: 0x0000693D
		internal void SetEnableButtons(bool value)
		{
			this.PreviousMapBtn.interactable = value;
			this.NextMapBtn.interactable = value;
		}

		// Token: 0x0600094C RID: 2380 RVA: 0x00039190 File Offset: 0x00037390
		public void OnNextClick()
		{
			T currentValue = this.GetCurrentValue();
			T t = this.Next();
			this.UpdateImage(currentValue, t, true, true);
			this.Text.text = this.UpdateText(t);
			if (this.OnValueChanged != null)
			{
				this.OnValueChanged(this.GetCurrentValue());
			}
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x000391E4 File Offset: 0x000373E4
		public void OnPreviousClick()
		{
			T currentValue = this.GetCurrentValue();
			T t = this.Previous();
			this.UpdateImage(currentValue, t, false, true);
			this.Text.text = this.UpdateText(t);
			if (this.OnValueChanged != null)
			{
				this.OnValueChanged(this.GetCurrentValue());
			}
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x00008757 File Offset: 0x00006957
		internal T GetCurrentValue()
		{
			return this._currentItem;
		}

		// Token: 0x0600094F RID: 2383 RVA: 0x00039238 File Offset: 0x00037438
		private T Next()
		{
			int count = this._availableItems.Count;
			int num = this._availableItems.IndexOf(this._currentItem);
			if (num < count - 1)
			{
				num++;
			}
			else
			{
				num = 0;
			}
			this._currentItem = this._availableItems[num];
			return this._currentItem;
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x00039290 File Offset: 0x00037490
		private T Previous()
		{
			int num = this._availableItems.IndexOf(this._currentItem);
			if (num > 0)
			{
				num--;
			}
			else
			{
				num = this._availableItems.Count - 1;
			}
			this._currentItem = this._availableItems[num];
			return this._currentItem;
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x000392E8 File Offset: 0x000374E8
		private void UpdateImage(T current, T next, bool forwardsOrBackwards, bool immediate)
		{
			if (current.Equals(next))
			{
				return;
			}
			if (immediate)
			{
				this.UpdateImageImmediate(current, next, forwardsOrBackwards);
				return;
			}
			if (this._updateCoroutine != null)
			{
				base.StopCoroutine(this._updateCoroutine);
			}
			this._updateCoroutine = base.StartCoroutine(this.UpdateImageDelayed(current, next, forwardsOrBackwards));
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x0003934C File Offset: 0x0003754C
		private IEnumerator UpdateImageDelayed(T previous, T next, bool forwardsOrBackwards)
		{
			Animator previousMapAnim = this._animators[previous];
			Animator nextMapAnim = this._animators[next];
			while (!previousMapAnim.isInitialized && !nextMapAnim.isInitialized)
			{
				yield return null;
			}
			string command = ((!forwardsOrBackwards) ? "backward" : "forward");
			previousMapAnim.SetTrigger(command + "_out");
			nextMapAnim.SetTrigger(command + "_in");
			yield break;
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x0003937C File Offset: 0x0003757C
		private void UpdateImageImmediate(T previous, T next, bool forwardsOrBackwards)
		{
			Animator animator = this._animators[previous];
			Animator animator2 = this._animators[next];
			string text = ((!forwardsOrBackwards) ? "backward" : "forward");
			animator.SetTrigger(text + "_out");
			animator2.SetTrigger(text + "_in");
		}

		// Token: 0x06000954 RID: 2388 RVA: 0x000393DC File Offset: 0x000375DC
		internal void SetValue(T value, bool force, bool immediate = false)
		{
			T currentValue = this.GetCurrentValue();
			if (currentValue.Equals(value) && !force)
			{
				return;
			}
			this.Reset(value, immediate);
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x00039418 File Offset: 0x00037618
		internal void Reset(T defaultValue, bool immediate = false)
		{
			if (immediate)
			{
				this.ResetValues(defaultValue);
				return;
			}
			if (this._resetCoroutine != null)
			{
				base.StopCoroutine(this._resetCoroutine);
			}
			if (!base.isActiveAndEnabled)
			{
				return;
			}
			this._resetCoroutine = base.StartCoroutine(this.ResetCoroutine(defaultValue));
		}

		// Token: 0x06000956 RID: 2390 RVA: 0x0003946C File Offset: 0x0003766C
		private IEnumerator ResetCoroutine(T defaultValue)
		{
			while (!this.AreAnimatorsInitialized())
			{
				yield return null;
			}
			this.ResetValues(defaultValue);
			yield break;
		}

		// Token: 0x06000957 RID: 2391 RVA: 0x00039490 File Offset: 0x00037690
		private void ResetValues(T defaultValue)
		{
			foreach (KeyValuePair<T, Animator> keyValuePair in this._animators)
			{
				string text = "forward_";
				T key = keyValuePair.Key;
				string text2 = text + ((!key.Equals(defaultValue)) ? "out" : "in");
				keyValuePair.Value.SetTrigger(text2);
			}
			this._currentItem = defaultValue;
			this.Text.text = this.UpdateText(defaultValue);
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x00039548 File Offset: 0x00037748
		private bool AreAnimatorsInitialized()
		{
			foreach (KeyValuePair<T, Animator> keyValuePair in this._animators)
			{
				if (!keyValuePair.Value.isInitialized)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000959 RID: 2393
		protected abstract List<T> LoadAvailableItems();

		// Token: 0x0600095A RID: 2394
		protected abstract string UpdateText(T newText);

		// Token: 0x04000C58 RID: 3160
		public Button NextMapBtn;

		// Token: 0x04000C59 RID: 3161
		public Button PreviousMapBtn;

		// Token: 0x04000C5A RID: 3162
		public Transform ImagesRoot;

		// Token: 0x04000C5B RID: 3163
		public GameObject ImageTemplate;

		// Token: 0x04000C5C RID: 3164
		public Text Text;

		// Token: 0x04000C5D RID: 3165
		protected Dictionary<T, Animator> _animators;

		// Token: 0x04000C5E RID: 3166
		protected T _currentItem;

		// Token: 0x04000C5F RID: 3167
		protected List<T> _availableItems;

		// Token: 0x04000C60 RID: 3168
		protected Coroutine _updateCoroutine;

		// Token: 0x04000C61 RID: 3169
		internal Action<T> OnValueChanged;

		// Token: 0x04000C62 RID: 3170
		private Coroutine _resetCoroutine;
	}
}
