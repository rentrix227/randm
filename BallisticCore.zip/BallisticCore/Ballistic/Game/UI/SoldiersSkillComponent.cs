﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000208 RID: 520
	public class SoldiersSkillComponent : PoolableComponent
	{
		// Token: 0x06000A78 RID: 2680 RVA: 0x0003D318 File Offset: 0x0003B518
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.SkillButton != null)
			{
				this.SkillButton.onClick.AddListener(new UnityAction(this.OnSkillClick));
			}
			if (this.SkillToggle != null)
			{
				this.SkillToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnToggleClick));
			}
			this._animator = base.GetComponentInChildren<Animator>(true);
			this._isAvailableHash = Animator.StringToHash("Available");
			this._animatorHasAvailable = false;
			if (this._animator != null)
			{
				for (int i = 0; i < this._animator.parameterCount; i++)
				{
					if (this._animator.GetParameter(i).name == "Available")
					{
						this._animatorHasAvailable = true;
						break;
					}
				}
			}
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x0003D408 File Offset: 0x0003B608
		public void Update()
		{
			if (this._animator != null && this._animator.isInitialized && this._animatorHasAvailable)
			{
				this._animator.SetBool(this._isAvailableHash, this._isAvailable);
			}
		}

		// Token: 0x06000A7A RID: 2682 RVA: 0x00009575 File Offset: 0x00007775
		private void OnToggleClick(bool value)
		{
			if (!value)
			{
				return;
			}
			this.OnSkillClick();
		}

		// Token: 0x06000A7B RID: 2683 RVA: 0x00009584 File Offset: 0x00007784
		private void OnSkillClick()
		{
			if (this.OnSkillClicked != null && !this._isSetting)
			{
				this.OnSkillClicked(this._heroSkillData);
			}
		}

		// Token: 0x06000A7C RID: 2684 RVA: 0x0003D458 File Offset: 0x0003B658
		internal void SetData(HeroSkillData skill, bool isActived, bool isAvailable = true, int levelRequired = -1)
		{
			this._isSetting = true;
			if (skill == null)
			{
				return;
			}
			this._heroSkillData = skill;
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			if (this.SkillImage != null)
			{
				string skillIconPath = TextureHelper.GetSkillIconPath(skill.Skill);
				TextureHelper.LoadImageAsync(skillIconPath, this.SkillImage, false, EImageSource.RESOURCES);
			}
			if (this.SkillNameText != null)
			{
				this.SkillNameText.text = service.Get(skill.LocalizationKey, ELocalizedTextCase.UPPER_CASE);
				this.SkillNameText.SetAllDirty();
			}
			if (this.SkillDescriptionNameText != null)
			{
				this.SkillDescriptionNameText.text = service.Get(skill.LocalizationKey, ELocalizedTextCase.UPPER_CASE);
				this.SkillDescriptionNameText.SetAllDirty();
			}
			if (this.SkillDescription != null)
			{
				this.SkillDescription.text = ((!isAvailable) ? string.Empty : service.Get(skill.DescriptionKey, ELocalizedTextCase.NONE));
				this.SkillDescription.SetAllDirty();
			}
			if (this.SkillToggle != null)
			{
				this.SkillToggle.isOn = isActived;
			}
			this._isAvailable = isAvailable;
			if (this.RequiresLevelLabel != null)
			{
				if (levelRequired > 0)
				{
					this.RequiresLevelLabel.text = string.Format(service.Get("requires_level", ELocalizedTextCase.UPPER_CASE), levelRequired);
				}
				else
				{
					this.RequiresLevelLabel.gameObject.SetActive(false);
				}
			}
			this._isSetting = false;
		}

		// Token: 0x04000DF1 RID: 3569
		public Image SkillImage;

		// Token: 0x04000DF2 RID: 3570
		public Text SkillNameText;

		// Token: 0x04000DF3 RID: 3571
		public Text SkillDescription;

		// Token: 0x04000DF4 RID: 3572
		public Text SkillDescriptionNameText;

		// Token: 0x04000DF5 RID: 3573
		public Button SkillButton;

		// Token: 0x04000DF6 RID: 3574
		public Toggle SkillToggle;

		// Token: 0x04000DF7 RID: 3575
		public Text RequiresLevelLabel;

		// Token: 0x04000DF8 RID: 3576
		internal Action<HeroSkillData> OnSkillClicked;

		// Token: 0x04000DF9 RID: 3577
		private HeroSkillData _heroSkillData;

		// Token: 0x04000DFA RID: 3578
		private Animator _animator;

		// Token: 0x04000DFB RID: 3579
		private bool _isAvailable;

		// Token: 0x04000DFC RID: 3580
		private int _isAvailableHash;

		// Token: 0x04000DFD RID: 3581
		private bool _animatorHasAvailable;

		// Token: 0x04000DFE RID: 3582
		private bool _isSetting;
	}
}
