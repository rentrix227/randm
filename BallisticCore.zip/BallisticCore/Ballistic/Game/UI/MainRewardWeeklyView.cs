﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002F2 RID: 754
	public class MainRewardWeeklyView : BaseView<MainController>
	{
		// Token: 0x06000FC1 RID: 4033 RVA: 0x0000CFDC File Offset: 0x0000B1DC
		protected override void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.MainRewardList.Template.Dispose();
		}

		// Token: 0x06000FC2 RID: 4034 RVA: 0x0000CFC5 File Offset: 0x0000B1C5
		private void OnClaimReward(RewardPackData rewardData, Action<bool, SteamItem[]> OnExchangeResponse)
		{
			base._controller.ClaimReward(rewardData, OnExchangeResponse);
		}

		// Token: 0x06000FC3 RID: 4035 RVA: 0x0005CDC8 File Offset: 0x0005AFC8
		private void OnFinish(MainRewardPackComponent pack)
		{
			for (int i = 0; i < this.MainRewardList.Count; i++)
			{
				if (pack == this.MainRewardList[i])
				{
					this.MainRewardList[i].Dispose();
				}
			}
			this.UpdateRewardList();
			if (this._currentRewards.Count <= 0 && this.MainRewardList.Lenght <= 0)
			{
				UIManager.Instance.DisableLayer(1);
				base._controller.CheckRewards();
			}
		}

		// Token: 0x06000FC4 RID: 4036 RVA: 0x0000CFF9 File Offset: 0x0000B1F9
		internal void SetData(IEnumerable<RewardPackData> rewards)
		{
			this._currentRewards = rewards.ToList<RewardPackData>();
			this.UpdateRewardList();
		}

		// Token: 0x06000FC5 RID: 4037 RVA: 0x0005CE58 File Offset: 0x0005B058
		private void UpdateRewardList()
		{
			while (this._currentRewards.Count > 0 && this.MainRewardList.Lenght < 3)
			{
				this.MainRewardList.Instantiate().SetData(this._currentRewards.First<RewardPackData>(), new Action<RewardPackData, Action<bool, SteamItem[]>>(this.OnClaimReward), new Action<MainRewardPackComponent>(this.OnFinish));
				this._currentRewards.RemoveAt(0);
			}
		}

		// Token: 0x040014F0 RID: 5360
		public MainRewardWeeklyView.MainRewardPackList MainRewardList;

		// Token: 0x040014F1 RID: 5361
		private List<RewardPackData> _currentRewards;

		// Token: 0x020002F3 RID: 755
		[Serializable]
		public class MainRewardPackList : PoolableList<MainRewardPackComponent>
		{
		}
	}
}
