﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000281 RID: 641
	public class GameplayInGameChatView : GameplayBaseChatView
	{
		// Token: 0x06000D96 RID: 3478 RVA: 0x00050254 File Offset: 0x0004E454
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._chatEntries = new HighSpeedArray<ChatEntry>(20);
			this.InputField.onValueChanged.AddListener(new UnityAction<string>(this.OnInputTextChange));
			this.InputField.onEndEdit.AddListener(new UnityAction<string>(this.OnSubmitText));
			this._chatActive = false;
			this.HideInputField();
			this.ChatText.text = string.Empty;
			this._lastTime = Time.time - 10f;
		}

		// Token: 0x06000D97 RID: 3479 RVA: 0x000502E8 File Offset: 0x0004E4E8
		public void Update()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.ChatPanelAnimator.isInitialized && this.InputPanelAnimator.isInitialized)
			{
				this.ChatPanelAnimator.SetBool(GameplayInGameChatView._panelIsOn, this._lastTime + 10f > Time.time);
				this.InputPanelAnimator.SetBool(GameplayInGameChatView._panelIsOn, this._chatActive);
			}
		}

		// Token: 0x06000D98 RID: 3480 RVA: 0x0005035C File Offset: 0x0004E55C
		internal override void AddTextEntry(string entryText)
		{
			this._lastTime = Time.time;
			ChatEntry chatEntry = new ChatEntry
			{
				EntryText = entryText,
				Timestamp = Time.time
			};
			this._chatEntries.Add(chatEntry);
			while (this._chatEntries.Length > 10)
			{
				this._chatEntries.RemoveAt(0);
			}
			string text = string.Empty;
			for (int i = 0; i < this._chatEntries.Length; i++)
			{
				text += this._chatEntries[i].EntryText;
			}
			this.ChatText.text = text;
		}

		// Token: 0x06000D99 RID: 3481 RVA: 0x0000B55C File Offset: 0x0000975C
		internal override bool IsTyping()
		{
			return this.InputField.isFocused;
		}

		// Token: 0x06000D9A RID: 3482 RVA: 0x0005040C File Offset: 0x0004E60C
		internal override void SetTeamOnly(bool teamOnly)
		{
			this._teamOnly = teamOnly;
			this.ChannelText.text = "[" + ServiceProvider.GetService<LocalizationService>().Get((!teamOnly) ? "ingame_general_message" : "ingame_team_message", ELocalizedTextCase.NONE) + "]";
		}

		// Token: 0x06000D9B RID: 3483 RVA: 0x0000B569 File Offset: 0x00009769
		internal override void FocusInputField()
		{
			this._chatActive = true;
			ServiceProvider.GetService<EventProxy>().StartCoroutine(this.Focus());
		}

		// Token: 0x06000D9C RID: 3484 RVA: 0x0005045C File Offset: 0x0004E65C
		private IEnumerator Focus()
		{
			yield return null;
			yield return null;
			yield return null;
			ServiceProvider.GetService<InputControlService>().SetInput(this, false);
			if (EventSystem.current != null)
			{
				EventSystem.current.SetSelectedGameObject(this.InputField.gameObject, null);
			}
			this.InputField.ActivateInputField();
			yield break;
		}

		// Token: 0x06000D9D RID: 3485 RVA: 0x00050478 File Offset: 0x0004E678
		internal override void HideInputField()
		{
			this._chatActive = false;
			ServiceProvider.GetService<InputControlService>().SetInput(this, true);
			if (EventSystem.current != null)
			{
				EventSystem.current.SetSelectedGameObject(null);
			}
			this.ClearInputField();
			this.InputField.DeactivateInputField();
		}

		// Token: 0x06000D9E RID: 3486 RVA: 0x0000B583 File Offset: 0x00009783
		private void ClearInputField()
		{
			this.InputField.text = string.Empty;
			this.InputField.ForceLabelUpdate();
		}

		// Token: 0x06000D9F RID: 3487 RVA: 0x000504C4 File Offset: 0x0004E6C4
		private void OnSubmitText(string text)
		{
			string text2 = text.Trim();
			this.HideInputField();
			if (string.IsNullOrEmpty(text2))
			{
				return;
			}
			base._controller.OnTextInput(text2, this._teamOnly && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
		}

		// Token: 0x06000DA0 RID: 3488 RVA: 0x00050514 File Offset: 0x0004E714
		public void OnInputTextChange(string text)
		{
			if (text == "/all")
			{
				base._controller.SetTeamOnly(false);
				this.ClearInputField();
			}
			else if (text == "/team")
			{
				base._controller.SetTeamOnly(true);
				this.ClearInputField();
			}
		}

		// Token: 0x0400109D RID: 4253
		private const float _chatEntryVisibleSeconds = 10f;

		// Token: 0x0400109E RID: 4254
		private static readonly int _panelIsOn = Animator.StringToHash("isOn");

		// Token: 0x0400109F RID: 4255
		private float _lastTime;

		// Token: 0x040010A0 RID: 4256
		public Animator InputPanelAnimator;

		// Token: 0x040010A1 RID: 4257
		public Animator ChatPanelAnimator;

		// Token: 0x040010A2 RID: 4258
		public Text ChannelText;

		// Token: 0x040010A3 RID: 4259
		public InputField InputField;

		// Token: 0x040010A4 RID: 4260
		public Text ChatText;

		// Token: 0x040010A5 RID: 4261
		private HighSpeedArray<ChatEntry> _chatEntries;

		// Token: 0x040010A6 RID: 4262
		private bool _teamOnly;

		// Token: 0x040010A7 RID: 4263
		private bool _chatActive;
	}
}
