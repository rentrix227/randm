﻿using System;
using System.Linq;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002FA RID: 762
	public class PopupView : BaseView<PopupController>
	{
		// Token: 0x06000FD8 RID: 4056 RVA: 0x0000D0B6 File Offset: 0x0000B2B6
		internal EPopupType[] GetPopupTypes()
		{
			return this.PopupTypes;
		}

		// Token: 0x06000FD9 RID: 4057 RVA: 0x0000D0BE File Offset: 0x0000B2BE
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.InputField != null)
			{
				this.InputField.onEndEdit.AddListener(new UnityAction<string>(this.OnEndEdit));
			}
		}

		// Token: 0x06000FDA RID: 4058 RVA: 0x0000D0FE File Offset: 0x0000B2FE
		private void OnEndEdit(string value)
		{
			base._controller.PasswordClick(2, this.InputField.text);
		}

		// Token: 0x06000FDB RID: 4059 RVA: 0x0005D248 File Offset: 0x0005B448
		internal void UpdateInfo(PopupData data)
		{
			if (!this.PopupTypes.Contains(data.Type))
			{
				return;
			}
			if (this.Title != null)
			{
				this.Title.text = data.Title;
			}
			if (this.Message != null)
			{
				this.Message.text = data.Message;
			}
			if (this.Buttons.Length <= 0)
			{
				return;
			}
			if (this.Progressive != null)
			{
				this.Progressive.value = data.Progression;
			}
			if (data.ButtonTexts == null)
			{
				foreach (Button button in this.Buttons)
				{
					button.gameObject.SetActive(false);
				}
				return;
			}
			for (int j = 0; j < data.ButtonTexts.Length; j++)
			{
				if (string.IsNullOrEmpty(data.ButtonTexts[j]))
				{
					if (this.Buttons[j].transform.parent.gameObject.activeSelf)
					{
						this.Buttons[j].transform.parent.gameObject.SetActive(false);
					}
				}
				else
				{
					if (!this.Buttons[j].transform.parent.gameObject.activeSelf)
					{
						this.Buttons[j].transform.parent.gameObject.SetActive(true);
					}
					Text component = this.Buttons[j].transform.GetChild(0).GetComponent<Text>();
					if (component != null)
					{
						component.text = data.ButtonTexts[j];
					}
					int a = j;
					this.Buttons[j].onClick.RemoveAllListeners();
					this.Buttons[j].onClick.AddListener(delegate
					{
						this.OnButtonClick(a);
					});
				}
			}
		}

		// Token: 0x06000FDC RID: 4060 RVA: 0x0000D117 File Offset: 0x0000B317
		private void OnButtonClick(int button)
		{
			if (this.InputField == null)
			{
				base._controller.ButtonClick(button);
			}
			else
			{
				base._controller.PasswordClick(button, this.InputField.text);
			}
		}

		// Token: 0x04001506 RID: 5382
		public EPopupType[] PopupTypes;

		// Token: 0x04001507 RID: 5383
		public Text Message;

		// Token: 0x04001508 RID: 5384
		public Text Title;

		// Token: 0x04001509 RID: 5385
		public InputField InputField;

		// Token: 0x0400150A RID: 5386
		public Slider Progressive;

		// Token: 0x0400150B RID: 5387
		public Button[] Buttons;
	}
}
