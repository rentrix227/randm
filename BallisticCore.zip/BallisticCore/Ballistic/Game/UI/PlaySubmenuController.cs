﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200024B RID: 587
	public class PlaySubmenuController : BaseController
	{
		// Token: 0x06000C47 RID: 3143 RVA: 0x0004A800 File Offset: 0x00048A00
		public PlaySubmenuController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._quickMatchService = ServiceProvider.GetService<QuickMatchService>();
			this._quickMatchService.OnStart += this.OnQuickMatchStart;
			this._quickMatchService.OnFailed += this.OnQuickMatchSearchFailed;
			this._quickMatchService.OnJoining += this.OnQuickMatchJoining;
			this._quickMatchService.OnConnected += this.OnQuickMatchConnected;
			this._quickMatchService.OnMatchIsTakingTooMuchTime += this.OnQuickMatchIsTakingTooMuchTime;
			this._quickMatchService.OnMatchIsAboutToStart += this.OnQuickMatchIsAboutToStart;
			this._quickMatchService.OnCancel += this.OnQuickMatchCancel;
			this._quickMatchService.OnFinish += this.OnQuickMatchFinish;
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x0004A8E4 File Offset: 0x00048AE4
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._quickMatchService.OnStart -= this.OnQuickMatchStart;
			this._quickMatchService.OnFailed -= this.OnQuickMatchSearchFailed;
			this._quickMatchService.OnJoining -= this.OnQuickMatchJoining;
			this._quickMatchService.OnConnected -= this.OnQuickMatchConnected;
			this._quickMatchService.OnMatchIsTakingTooMuchTime -= this.OnQuickMatchIsTakingTooMuchTime;
			this._quickMatchService.OnMatchIsAboutToStart -= this.OnQuickMatchIsAboutToStart;
			this._quickMatchService.OnCancel -= this.OnQuickMatchCancel;
			this._quickMatchService.OnFinish -= this.OnQuickMatchFinish;
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x0000A5B5 File Offset: 0x000087B5
		internal void QuickMatchCancel()
		{
			this._quickMatchService.Cancel();
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x0004A9BC File Offset: 0x00048BBC
		private void OnQuickMatchStart()
		{
			PlayNowView view = base.GetView<PlayNowView>();
			if (view != null)
			{
				view.SetState("popup_searching_match_message", false);
			}
		}

		// Token: 0x06000C4B RID: 3147 RVA: 0x0004A9E8 File Offset: 0x00048BE8
		private void OnQuickMatchJoining()
		{
			PlayNowView view = base.GetView<PlayNowView>();
			if (view != null)
			{
				view.SetState("popup_join_match", false);
			}
		}

		// Token: 0x06000C4C RID: 3148 RVA: 0x0004AA14 File Offset: 0x00048C14
		private void OnQuickMatchConnected()
		{
			PlayNowView view = base.GetView<PlayNowView>();
			if (view != null)
			{
				view.SetState("popup_waiting_players", false);
			}
		}

		// Token: 0x06000C4D RID: 3149 RVA: 0x0004AA40 File Offset: 0x00048C40
		private void OnQuickMatchIsTakingTooMuchTime()
		{
			PlayNowView view = base.GetView<PlayNowView>();
			if (view != null)
			{
				view.SetState("popup_waiting_players_toomuch", false);
			}
		}

		// Token: 0x06000C4E RID: 3150 RVA: 0x0004AA6C File Offset: 0x00048C6C
		private void OnQuickMatchIsAboutToStart()
		{
			PlayNowView view = base.GetView<PlayNowView>();
			if (view != null)
			{
				view.SetState("popup_match_starting", true);
			}
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x0000A5C2 File Offset: 0x000087C2
		private void OnQuickMatchSearchFailed()
		{
			ServiceProvider.GetService<PopupService>().Show(EPopupType.NO_MATCH_FOUND, null, new Action<int>(this.OnNoMatchFoundCallback), null, 0f);
			UIManager.Instance.DisableLayer(4);
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x0000A5ED File Offset: 0x000087ED
		private void OnQuickMatchCancel()
		{
			UIManager.Instance.DisableLayer(4);
		}

		// Token: 0x06000C51 RID: 3153 RVA: 0x0000A5FA File Offset: 0x000087FA
		private void OnQuickMatchFinish()
		{
			Debug.Log("Disable state!");
			UIManager.Instance.DisableLayer(4);
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x0000A611 File Offset: 0x00008811
		private void OnNoMatchFoundCallback(int button)
		{
			if (button == 0)
			{
				ServiceProvider.GetService<PopupService>().Hide(EPopupType.NO_MATCH_FOUND);
			}
		}

		// Token: 0x04000F6D RID: 3949
		private QuickMatchService _quickMatchService;
	}
}
