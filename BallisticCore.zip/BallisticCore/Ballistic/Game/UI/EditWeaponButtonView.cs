﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200026F RID: 623
	public class EditWeaponButtonView : BaseView<SoldiersWeaponController>
	{
		// Token: 0x06000D50 RID: 3408 RVA: 0x0000B1A1 File Offset: 0x000093A1
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SaveButton.onClick.AddListener(new UnityAction(this.OnSaveChanges));
		}

		// Token: 0x06000D51 RID: 3409 RVA: 0x0000B1D0 File Offset: 0x000093D0
		private void OnSaveChanges()
		{
			base._controller.DispatchWeaponSelected();
		}

		// Token: 0x04001013 RID: 4115
		public Button SaveButton;
	}
}
