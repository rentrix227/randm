﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002B0 RID: 688
	public class InGameEndmatchScoreboardView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000E8C RID: 3724 RVA: 0x00058260 File Offset: 0x00056460
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.AllPlayerPoolableList.Template.Dispose();
			this.YourTeamPlayerList.Template.Dispose();
			this.EnemyTeamPlayerList.Template.Dispose();
		}

		// Token: 0x06000E8D RID: 3725 RVA: 0x000582B0 File Offset: 0x000564B0
		internal void SetMode(EClientMode clientMode, EGameMode gameMode, Team yourTeam)
		{
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				this.TeamModesRoot.SetActive(true);
				this.AllModeRoot.SetActive(false);
				this.YourTeamLogo.texture = this.TeamLogos[(int)yourTeam];
				this.EnemyTeamLogo.texture = this.TeamLogos[(yourTeam != Team.SMOKE) ? 2 : 1];
				this.YourTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(yourTeam, ELocalizedTextCase.UPPER_CASE);
				this.EnemyTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName((yourTeam != Team.SMOKE) ? Team.SMOKE : Team.MFA, ELocalizedTextCase.UPPER_CASE);
				this.YourTeamText.SetActive(clientMode == EClientMode.PLAYER);
				this.EnemyTeamText.SetActive(clientMode == EClientMode.PLAYER);
			}
			else
			{
				this.TeamModesRoot.SetActive(false);
				this.AllModeRoot.SetActive(true);
			}
		}

		// Token: 0x06000E8E RID: 3726 RVA: 0x00058398 File Offset: 0x00056598
		internal void SetScores(int yourTeamScore, int enemyTeamScore)
		{
			this.YourTeamScoreLabel.text = yourTeamScore.ToString();
			this.EnemyTeamScoreLabel.text = enemyTeamScore.ToString();
			this.YourTeamIsWinnerTag.SetActive(yourTeamScore > enemyTeamScore);
			this.EnemyTeamIsWinnerTag.SetActive(enemyTeamScore > yourTeamScore);
		}

		// Token: 0x06000E8F RID: 3727 RVA: 0x0000BDAE File Offset: 0x00009FAE
		internal void UpdateYourTeamList(EGameMode gameMode, HighSpeedArray<ClientCommonMetaData> playerData, EClientMode clientMode, long spectatorPlayerSelected = -1L)
		{
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				InGameEndmatchScoreboardView.SetPlayerList(this.YourTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
			}
			else
			{
				InGameEndmatchScoreboardView.SetPlayerList(this.AllPlayerPoolableList, playerData, clientMode, spectatorPlayerSelected);
			}
		}

		// Token: 0x06000E90 RID: 3728 RVA: 0x0000BDEB File Offset: 0x00009FEB
		internal void UpdateEnemyTeamList(EGameMode gameMode, HighSpeedArray<ClientCommonMetaData> playerData, EClientMode clientMode, long spectatorPlayerSelected = -1L)
		{
			if (gameMode != EGameMode.FreeForAll)
			{
				InGameEndmatchScoreboardView.SetPlayerList(this.EnemyTeamPlayerList, playerData, clientMode, spectatorPlayerSelected);
			}
		}

		// Token: 0x06000E91 RID: 3729 RVA: 0x000583F4 File Offset: 0x000565F4
		private static void SetPlayerList(PoolableList<ScoreboardEndmatchPlayerComponent> teamPlayerTemplate, HighSpeedArray<ClientCommonMetaData> playerData, EClientMode mode, long spectatorPlayerSelected)
		{
			teamPlayerTemplate.SetActiveCount(playerData.Length);
			for (int i = 0; i < playerData.Length; i++)
			{
				ScoreboardEndmatchPlayerComponent scoreboardEndmatchPlayerComponent = teamPlayerTemplate[i];
				scoreboardEndmatchPlayerComponent.SetData(i + 1, playerData[i], UserProfile.IsMe(playerData[i].User));
			}
		}

		// Token: 0x0400134D RID: 4941
		public GameObject TeamModesRoot;

		// Token: 0x0400134E RID: 4942
		public GameObject AllModeRoot;

		// Token: 0x0400134F RID: 4943
		public Texture[] TeamLogos;

		// Token: 0x04001350 RID: 4944
		[Header("TeamMode")]
		public InGameEndmatchScoreboardView.ScoreboardEndmatchPlayerComponentPoolableList YourTeamPlayerList;

		// Token: 0x04001351 RID: 4945
		public InGameEndmatchScoreboardView.ScoreboardEndmatchPlayerComponentPoolableList EnemyTeamPlayerList;

		// Token: 0x04001352 RID: 4946
		public GameObject YourTeamText;

		// Token: 0x04001353 RID: 4947
		public GameObject EnemyTeamText;

		// Token: 0x04001354 RID: 4948
		public RawImage YourTeamLogo;

		// Token: 0x04001355 RID: 4949
		public RawImage EnemyTeamLogo;

		// Token: 0x04001356 RID: 4950
		public Text YourTeamNameText;

		// Token: 0x04001357 RID: 4951
		public Text EnemyTeamNameText;

		// Token: 0x04001358 RID: 4952
		public Text YourTeamScoreLabel;

		// Token: 0x04001359 RID: 4953
		public Text EnemyTeamScoreLabel;

		// Token: 0x0400135A RID: 4954
		public GameObject YourTeamIsWinnerTag;

		// Token: 0x0400135B RID: 4955
		public GameObject EnemyTeamIsWinnerTag;

		// Token: 0x0400135C RID: 4956
		[Header("AllMode")]
		public InGameEndmatchScoreboardView.ScoreboardEndmatchPlayerComponentPoolableList AllPlayerPoolableList;

		// Token: 0x020002B1 RID: 689
		[Serializable]
		public class ScoreboardEndmatchPlayerComponentPoolableList : PoolableList<ScoreboardEndmatchPlayerComponent>
		{
		}
	}
}
