﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002DF RID: 735
	public class LeaderboardsRewardsView : BaseView<LeaderboardsController>
	{
		// Token: 0x06000F78 RID: 3960 RVA: 0x0000CBE6 File Offset: 0x0000ADE6
		internal void SetStartData(Leaderboards leaderboard)
		{
			this._current = leaderboard;
			this.ChangeDataComplete();
		}

		// Token: 0x06000F79 RID: 3961 RVA: 0x0000CBF5 File Offset: 0x0000ADF5
		internal void SetData(Leaderboards leaderboard)
		{
			this._current = leaderboard;
		}

		// Token: 0x06000F7A RID: 3962 RVA: 0x0005C1D0 File Offset: 0x0005A3D0
		public void ChangeDataComplete()
		{
			Leaderboards current = this._current;
			if (current >= Leaderboards.SHADOW_LADDER && current <= Leaderboards.BESERKER_LADDER)
			{
				int num = (int)(current - Leaderboards.SHADOW_LADDER);
				if (num <= 3 || num - 5 <= 1)
				{
					goto IL_0110;
				}
			}
			if (current >= Leaderboards.SKIN_SPECIAL_LADDER && current <= Leaderboards.SKIN_COMMON_LADDER)
			{
				int num = (int)(current - Leaderboards.SKIN_SPECIAL_LADDER);
				if (num <= 2)
				{
					goto IL_00C4;
				}
			}
			if (current != Leaderboards.SKIN_LEGENDARY_LADDER && current != Leaderboards.SKIN_ELITE_LADDER)
			{
				if (current == Leaderboards.PERFORMANCE_LADDER)
				{
					this.PrizeGoldLockbox.SetActive(true);
					this.PrizeGoldScraps.SetActive(true);
					this.PrizeRankedScraps.SetActive(true);
					this.PrizeHeroesScraps.SetActive(false);
					this.LeaderboardPrizeDescription.text = ServiceProvider.GetService<LocalizationService>().Get("leader_overall_description", ELocalizedTextCase.NONE);
					return;
				}
				if (current != Leaderboards.WRAITH_LADDER)
				{
					return;
				}
				goto IL_0110;
			}
			IL_00C4:
			this.PrizeGoldLockbox.SetActive(false);
			this.PrizeGoldScraps.SetActive(false);
			this.PrizeRankedScraps.SetActive(false);
			this.PrizeHeroesScraps.SetActive(false);
			this.LeaderboardPrizeDescription.text = ServiceProvider.GetService<LocalizationService>().Get("leader_skins_description", ELocalizedTextCase.NONE);
			return;
			IL_0110:
			this.PrizeGoldLockbox.SetActive(false);
			this.PrizeGoldScraps.SetActive(false);
			this.PrizeRankedScraps.SetActive(false);
			this.PrizeHeroesScraps.SetActive(true);
			this.LeaderboardPrizeDescription.text = ServiceProvider.GetService<LocalizationService>().Get("leader_classes_description", ELocalizedTextCase.NONE);
		}

		// Token: 0x040014A4 RID: 5284
		public Text LeaderboardPrizeDescription;

		// Token: 0x040014A5 RID: 5285
		public GameObject PrizeGoldLockbox;

		// Token: 0x040014A6 RID: 5286
		public GameObject PrizeGoldScraps;

		// Token: 0x040014A7 RID: 5287
		public GameObject PrizeRankedScraps;

		// Token: 0x040014A8 RID: 5288
		public GameObject PrizeHeroesScraps;

		// Token: 0x040014A9 RID: 5289
		[HideInInspector]
		[NonSerialized]
		private Leaderboards _current;
	}
}
