﻿using System;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001E9 RID: 489
	public class LeaderboardPageDotComponent : PoolableComponent
	{
		// Token: 0x060009DD RID: 2525 RVA: 0x00008E53 File Offset: 0x00007053
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.PageToggle != null)
			{
				this.PageToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnToggleClick));
			}
		}

		// Token: 0x060009DE RID: 2526 RVA: 0x00008E8D File Offset: 0x0000708D
		internal void SetData(bool isActive, int page)
		{
			this._isSetting = true;
			this._currentPage = page;
			this.PageToggle.isOn = isActive;
			this._isSetting = false;
		}

		// Token: 0x060009DF RID: 2527 RVA: 0x00008EB0 File Offset: 0x000070B0
		private void OnToggleClick(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			if (this.OnToggleClicked != null)
			{
				this.OnToggleClicked(this._currentPage);
			}
		}

		// Token: 0x04000D2B RID: 3371
		public Toggle PageToggle;

		// Token: 0x04000D2C RID: 3372
		internal Action<int> OnToggleClicked;

		// Token: 0x04000D2D RID: 3373
		private bool _isSetting;

		// Token: 0x04000D2E RID: 3374
		private int _currentPage;
	}
}
