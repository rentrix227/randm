﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E0 RID: 736
	public class LockboxAvaliableItemsView : BaseView<InventoryController>
	{
		// Token: 0x06000F7C RID: 3964 RVA: 0x0000CBFE File Offset: 0x0000ADFE
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.WeaponSkinList.Template.Dispose();
		}

		// Token: 0x06000F7D RID: 3965 RVA: 0x0005C338 File Offset: 0x0005A538
		internal void SetData(bool hasLegendary, List<WeaponSkinData> weaponSkinArray)
		{
			this.LegendaryIcon.SetActive(hasLegendary);
			this.WeaponSkinList.SetActiveCount(weaponSkinArray.Count);
			for (int i = 0; i < weaponSkinArray.Count; i++)
			{
				this.WeaponSkinList[i].SetData(weaponSkinArray[i], false, false);
				this.WeaponSkinList[i].OnWeaponSkinClick = null;
			}
		}

		// Token: 0x040014AA RID: 5290
		public GameObject LegendaryIcon;

		// Token: 0x040014AB RID: 5291
		public LockboxAvaliableItemsView.InventorySkinList WeaponSkinList;

		// Token: 0x020002E1 RID: 737
		[Serializable]
		public class InventorySkinList : PoolableList<WeaponSkinComponent>
		{
		}
	}
}
