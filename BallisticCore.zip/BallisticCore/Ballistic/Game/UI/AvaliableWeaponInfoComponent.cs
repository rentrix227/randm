﻿using System;
using Aquiris.Ballistic.Game.UI.Helper;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001BB RID: 443
	public class AvaliableWeaponInfoComponent : MonoBehaviour
	{
		// Token: 0x0600092A RID: 2346 RVA: 0x0003804C File Offset: 0x0003624C
		internal void SetData(WeaponData weaponSelected, WeaponData weaponPreview)
		{
			if (weaponSelected == null || weaponPreview == null)
			{
				return;
			}
			int damage = UIWeaponData.GetDamage(weaponSelected);
			int fireRate = UIWeaponData.GetFireRate(weaponSelected);
			int accuracy = UIWeaponData.GetAccuracy(weaponSelected);
			float reloadSpeed = weaponSelected.GameItem.ShootData.ReloadSpeed;
			int mobility = UIWeaponData.GetMobility(weaponSelected);
			int magazineSize = weaponSelected.GameItem.ShootData.MagazineSize;
			float num = weaponSelected.GameItem.ShootData.HeadshotMultiplier + 1f;
			int range = UIWeaponData.GetRange(weaponSelected);
			this.WeaponSelected.DamagePerRoundText.text = damage.ToString();
			this.WeaponSelected.FireRateText.text = fireRate.ToString();
			this.WeaponSelected.AccuracyText.text = accuracy + "%";
			this.WeaponSelected.ReloadSpeedText.text = reloadSpeed.ToString("0.0") + "s";
			this.WeaponSelected.MobilityText.text = mobility + "%";
			this.WeaponSelected.ClipSizeText.text = magazineSize.ToString();
			this.WeaponSelected.HeadshotText.text = num.ToString("0.00") + "x";
			this.WeaponSelected.RangeText.text = (((float)range >= float.PositiveInfinity) ? "∞" : (range + "m"));
			this.DamageBarSelected.fillAmount = UIWeaponData.GetDamageBarValue((float)damage);
			this.FireRateBarSelected.fillAmount = UIWeaponData.GetFireRateBarValue((float)fireRate);
			this.AccuracyBarSelected.fillAmount = UIWeaponData.GetAccuracyBarValue((float)accuracy);
			this.RangeBarNormal.sizeDelta = Vector2.Lerp(this.RangeWidthMin, this.RangeWidthMax, UIWeaponData.GetRangeBarValue((float)range));
			this.RangeBarNegative.gameObject.SetActive(false);
			this.RangeBarPositive.gameObject.SetActive(false);
			if (this.HasGrLauncOnSelected.activeSelf != (weaponSelected.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.GRENADE_LAUNCHER))
			{
				this.HasGrLauncOnSelected.SetActive(weaponSelected.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.GRENADE_LAUNCHER);
			}
			if (this.HasShotgunOnSelected.activeSelf != (weaponSelected.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.SHOTGUN))
			{
				this.HasShotgunOnSelected.SetActive(weaponSelected.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.SHOTGUN);
			}
			if (this.HasSilenceOnSelected.activeSelf != weaponSelected.GameItem.WeaponData.IsSupressed)
			{
				this.HasSilenceOnSelected.SetActive(weaponSelected.GameItem.WeaponData.IsSupressed);
			}
			if (this.HasLaserSgOnSelected.activeSelf != weaponSelected.GameItem.WeaponData.IsLaserSight)
			{
				this.HasLaserSgOnSelected.SetActive(weaponSelected.GameItem.WeaponData.IsLaserSight);
			}
			if (this.HasMeKnifeOnSelected.activeSelf != (weaponSelected.GameItem.ShootData.WeaponSkill == EWeaponSkill.MELEE))
			{
				this.HasMeKnifeOnSelected.SetActive(weaponSelected.GameItem.ShootData.WeaponSkill == EWeaponSkill.MELEE);
			}
			if (weaponSelected.GameItem.ItemId != weaponPreview.GameItem.ItemId)
			{
				int damage2 = UIWeaponData.GetDamage(weaponPreview);
				int fireRate2 = UIWeaponData.GetFireRate(weaponPreview);
				int accuracy2 = UIWeaponData.GetAccuracy(weaponPreview);
				float reloadSpeed2 = weaponPreview.GameItem.ShootData.ReloadSpeed;
				int mobility2 = UIWeaponData.GetMobility(weaponPreview);
				int magazineSize2 = weaponPreview.GameItem.ShootData.MagazineSize;
				float num2 = weaponPreview.GameItem.ShootData.HeadshotMultiplier + 1f;
				int range2 = UIWeaponData.GetRange(weaponPreview);
				this.WeaponPreview.DamagePerRoundText.text = damage2.ToString();
				this.WeaponPreview.FireRateText.text = fireRate2.ToString();
				this.WeaponPreview.AccuracyText.text = accuracy2 + "%";
				this.WeaponPreview.ReloadSpeedText.text = reloadSpeed2.ToString("0.0") + "s";
				this.WeaponPreview.MobilityText.text = mobility2 + "%";
				this.WeaponPreview.ClipSizeText.text = magazineSize2.ToString();
				this.WeaponPreview.HeadshotText.text = num2.ToString("0.00") + "x";
				this.WeaponPreview.RangeText.text = (((float)range2 >= float.PositiveInfinity) ? "∞" : (range2 + "m"));
				this.WeaponPreview.DamagePerRoundText.color = this.Comparison((float)damage2, (float)damage);
				this.WeaponPreview.FireRateText.color = this.Comparison((float)fireRate2, (float)fireRate);
				this.WeaponPreview.AccuracyText.color = this.Comparison((float)accuracy2, (float)accuracy);
				this.WeaponPreview.ReloadSpeedText.color = this.Comparison(reloadSpeed, reloadSpeed2);
				this.WeaponPreview.MobilityText.color = this.Comparison((float)mobility2, (float)mobility);
				this.WeaponPreview.ClipSizeText.color = this.Comparison((float)magazineSize2, (float)magazineSize);
				this.WeaponPreview.HeadshotText.color = this.Comparison(num2, num);
				this.WeaponPreview.RangeText.color = this.Comparison((float)range2, (float)range);
				this.DamageBarPreview.fillAmount = UIWeaponData.GetDamageBarValue((float)damage2);
				this.FireRateBarPreview.fillAmount = UIWeaponData.GetFireRateBarValue((float)fireRate2);
				this.AccuracyBarPreview.fillAmount = UIWeaponData.GetAccuracyBarValue((float)accuracy2);
				this.DamageBarPreview.color = this.WeaponPreview.DamagePerRoundText.color;
				this.FireRateBarPreview.color = this.WeaponPreview.FireRateText.color;
				this.AccuracyBarPreview.color = this.WeaponPreview.AccuracyText.color;
				if (range2 < range)
				{
					this.RangeBarNegative.sizeDelta = Vector2.Lerp(this.RangeWidthMin, this.RangeWidthMax, UIWeaponData.GetRangeBarValue((float)range2));
					this.RangeBarNegative.gameObject.SetActive(true);
				}
				else
				{
					this.RangeBarPositive.sizeDelta = Vector2.Lerp(this.RangeWidthMin, this.RangeWidthMax, UIWeaponData.GetRangeBarValue((float)range2));
					this.RangeBarPositive.gameObject.SetActive(true);
				}
				if (this.HasGrLauncOnPreview.activeSelf != (weaponPreview.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.GRENADE_LAUNCHER))
				{
					this.HasGrLauncOnPreview.SetActive(weaponPreview.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.GRENADE_LAUNCHER);
				}
				if (this.HasShotgunOnPreview.activeSelf != (weaponPreview.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.SHOTGUN))
				{
					this.HasShotgunOnPreview.SetActive(weaponPreview.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.SHOTGUN);
				}
				if (this.HasSilenceOnPreview.activeSelf != weaponPreview.GameItem.WeaponData.IsSupressed)
				{
					this.HasSilenceOnPreview.SetActive(weaponPreview.GameItem.WeaponData.IsSupressed);
				}
				if (this.HasLaserSgOnPreview.activeSelf != weaponPreview.GameItem.WeaponData.IsLaserSight)
				{
					this.HasLaserSgOnPreview.SetActive(weaponPreview.GameItem.WeaponData.IsLaserSight);
				}
				if (this.HasMeKnifeOnPreview.activeSelf != (weaponPreview.GameItem.ShootData.WeaponSkill == EWeaponSkill.MELEE))
				{
					this.HasMeKnifeOnPreview.SetActive(weaponPreview.GameItem.ShootData.WeaponSkill == EWeaponSkill.MELEE);
				}
				if (this.ComparisonAnimator.isInitialized)
				{
					this.ComparisonAnimator.SetBool(AvaliableWeaponInfoComponent.AnimatorComparisonBool, true);
				}
			}
			else
			{
				this.DamageBarPreview.fillAmount = this.DamageBarSelected.fillAmount;
				this.FireRateBarPreview.fillAmount = this.FireRateBarSelected.fillAmount;
				this.AccuracyBarPreview.fillAmount = this.AccuracyBarSelected.fillAmount;
				this.DamageBarPreview.color = this.DamageBarSelected.color;
				this.FireRateBarPreview.color = this.DamageBarSelected.color;
				this.AccuracyBarPreview.color = this.DamageBarSelected.color;
				if (this.ComparisonAnimator.isInitialized)
				{
					this.ComparisonAnimator.SetBool(AvaliableWeaponInfoComponent.AnimatorComparisonBool, false);
				}
			}
		}

		// Token: 0x0600092B RID: 2347 RVA: 0x00008554 File Offset: 0x00006754
		public Color Comparison(float a, float b)
		{
			if (Mathf.Approximately(a, b))
			{
				return this.Normal;
			}
			return (a <= b) ? this.Lower : this.Higher;
		}

		// Token: 0x04000BFE RID: 3070
		public static int AnimatorComparisonBool = Animator.StringToHash("isComparing");

		// Token: 0x04000BFF RID: 3071
		public WeaponInfo WeaponSelected;

		// Token: 0x04000C00 RID: 3072
		public WeaponInfo WeaponPreview;

		// Token: 0x04000C01 RID: 3073
		[Header("Comparison Colors")]
		public Color Normal;

		// Token: 0x04000C02 RID: 3074
		public Color Lower;

		// Token: 0x04000C03 RID: 3075
		public Color Higher;

		// Token: 0x04000C04 RID: 3076
		public Animator ComparisonAnimator;

		// Token: 0x04000C05 RID: 3077
		public Image DamageBarSelected;

		// Token: 0x04000C06 RID: 3078
		public Image DamageBarPreview;

		// Token: 0x04000C07 RID: 3079
		public Image FireRateBarSelected;

		// Token: 0x04000C08 RID: 3080
		public Image FireRateBarPreview;

		// Token: 0x04000C09 RID: 3081
		public Image AccuracyBarSelected;

		// Token: 0x04000C0A RID: 3082
		public Image AccuracyBarPreview;

		// Token: 0x04000C0B RID: 3083
		public GameObject HasGrLauncOnSelected;

		// Token: 0x04000C0C RID: 3084
		public GameObject HasShotgunOnSelected;

		// Token: 0x04000C0D RID: 3085
		public GameObject HasLaserSgOnSelected;

		// Token: 0x04000C0E RID: 3086
		public GameObject HasSilenceOnSelected;

		// Token: 0x04000C0F RID: 3087
		public GameObject HasMeKnifeOnSelected;

		// Token: 0x04000C10 RID: 3088
		public GameObject HasGrLauncOnPreview;

		// Token: 0x04000C11 RID: 3089
		public GameObject HasShotgunOnPreview;

		// Token: 0x04000C12 RID: 3090
		public GameObject HasLaserSgOnPreview;

		// Token: 0x04000C13 RID: 3091
		public GameObject HasSilenceOnPreview;

		// Token: 0x04000C14 RID: 3092
		public GameObject HasMeKnifeOnPreview;

		// Token: 0x04000C15 RID: 3093
		public RectTransform RangeBarNormal;

		// Token: 0x04000C16 RID: 3094
		public RectTransform RangeBarPositive;

		// Token: 0x04000C17 RID: 3095
		public RectTransform RangeBarNegative;

		// Token: 0x04000C18 RID: 3096
		public Vector2 RangeWidthMin;

		// Token: 0x04000C19 RID: 3097
		public Vector2 RangeWidthMax;
	}
}
