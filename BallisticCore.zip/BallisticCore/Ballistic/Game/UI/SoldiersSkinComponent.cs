﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000209 RID: 521
	public class SoldiersSkinComponent : PoolableComponent
	{
		// Token: 0x06000A7E RID: 2686 RVA: 0x000095AD File Offset: 0x000077AD
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.SkinToggle != null)
			{
				this.SkinToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnToggleClick));
			}
		}

		// Token: 0x06000A7F RID: 2687 RVA: 0x000095E7 File Offset: 0x000077E7
		private void OnToggleClick(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			if (this.OnToggleClicked != null)
			{
				this.OnToggleClicked(this._skin);
			}
		}

		// Token: 0x06000A80 RID: 2688 RVA: 0x0003D5D4 File Offset: 0x0003B7D4
		internal void SetData(HeroSkin heroSkin, bool selected)
		{
			this._isSetting = true;
			this._skin = heroSkin;
			if (this.SkinImage != null)
			{
				string classSkinIconPath = TextureHelper.GetClassSkinIconPath(heroSkin.ItemName);
				TextureHelper.LoadImageAsync(classSkinIconPath, this.SkinImage, false, EImageSource.RESOURCES);
			}
			if (this.SkinToggle != null)
			{
				this.SkinToggle.isOn = selected;
			}
			this._isSetting = false;
		}

		// Token: 0x04000DFF RID: 3583
		public Image SkinImage;

		// Token: 0x04000E00 RID: 3584
		public Toggle SkinToggle;

		// Token: 0x04000E01 RID: 3585
		internal Action<HeroSkin> OnToggleClicked;

		// Token: 0x04000E02 RID: 3586
		private HeroSkin _skin;

		// Token: 0x04000E03 RID: 3587
		private bool _isSetting;
	}
}
