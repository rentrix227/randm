﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200029C RID: 668
	public enum MarkerType
	{
		// Token: 0x04001214 RID: 4628
		None,
		// Token: 0x04001215 RID: 4629
		Grenade,
		// Token: 0x04001216 RID: 4630
		EnemyName,
		// Token: 0x04001217 RID: 4631
		AllyName,
		// Token: 0x04001218 RID: 4632
		Damage,
		// Token: 0x04001219 RID: 4633
		Killed,
		// Token: 0x0400121A RID: 4634
		CapturePoint
	}
}
