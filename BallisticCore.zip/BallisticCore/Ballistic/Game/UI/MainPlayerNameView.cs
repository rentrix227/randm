﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E9 RID: 745
	public class MainPlayerNameView : BasePlayerNameView<MainController>
	{
	}
}
