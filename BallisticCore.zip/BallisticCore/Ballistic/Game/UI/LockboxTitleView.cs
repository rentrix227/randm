﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E6 RID: 742
	public class LockboxTitleView : BaseView<InventoryController>
	{
		// Token: 0x06000F93 RID: 3987 RVA: 0x0005C680 File Offset: 0x0005A880
		internal void SetData(LockboxData data)
		{
			this.LockboxTitleText.text = data.CurrentName.ToUpper();
			string text;
			if (data.Lockbox.Season == ESeason.LADDER)
			{
				text = TextureHelper.GetRewardsIconPath(data.Lockbox.HeroClass, EImageSize.MEDIUM);
			}
			else
			{
				text = TextureHelper.GetSeasonIconPath(data.Lockbox.Season, EImageSize.MEDIUM);
			}
			TextureHelper.LoadImageAsync(text, this.LockboxSeasonImage, false, EImageSource.RESOURCES);
		}

		// Token: 0x040014BB RID: 5307
		public Text LockboxTitleText;

		// Token: 0x040014BC RID: 5308
		public Image LockboxSeasonImage;
	}
}
