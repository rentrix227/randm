﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000203 RID: 515
	public class SettingsKeyDefineComponent : MonoBehaviour
	{
		// Token: 0x06000A5E RID: 2654 RVA: 0x0000941A File Offset: 0x0000761A
		public void Update()
		{
			if (this._definingKey)
			{
				base.StartCoroutine(this.CheckKey());
			}
		}

		// Token: 0x06000A5F RID: 2655 RVA: 0x0003CEA8 File Offset: 0x0003B0A8
		public void Start()
		{
			this._texts = base.GetComponentsInChildren<Text>();
			this._button = base.GetComponentInChildren<Button>();
			if (this._button == null)
			{
				Debug.LogError("KeyDefineButton can't find a Button in the same GameObject");
				return;
			}
			if (this.KeyNameText == null)
			{
				Debug.LogError("KeyDefineButton can't find a TextLocalize in the same GameObject");
				return;
			}
			this._button.onClick.AddListener(new UnityAction(this.OnRequestKeyBinding));
			this._definingKey = false;
		}

		// Token: 0x06000A60 RID: 2656 RVA: 0x00009434 File Offset: 0x00007634
		internal void SetLocalization(string key)
		{
			this.KeyNameText.text = ServiceProvider.GetService<LocalizationService>().Get(key, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x06000A61 RID: 2657 RVA: 0x0000944D File Offset: 0x0000764D
		private void OnRequestKeyBinding()
		{
			this._definingKey = true;
			ServiceProvider.GetService<PopupService>().Show(EPopupType.KEY_DEFINE, this.KeyType.ToString().ToLower(), null, null, 0f);
		}

		// Token: 0x06000A62 RID: 2658 RVA: 0x0003CF28 File Offset: 0x0003B128
		private IEnumerator CheckKey()
		{
			yield return null;
			KeyCode newBinding = ServiceProvider.GetService<OptionControlService>().GetCurrentKeyUp();
			if (newBinding == null)
			{
				yield break;
			}
			this.AttemptChange(newBinding);
			ServiceProvider.GetService<PopupService>().Hide(EPopupType.KEY_DEFINE);
			yield break;
		}

		// Token: 0x06000A63 RID: 2659 RVA: 0x0000947E File Offset: 0x0000767E
		private void AttemptChange(KeyCode code)
		{
			if (code == 8)
			{
				this.DoCancel();
			}
			else
			{
				this.DoChange(code);
			}
		}

		// Token: 0x06000A64 RID: 2660 RVA: 0x00009499 File Offset: 0x00007699
		private void DoChange(KeyCode code)
		{
			this._definingKey = false;
			if (this.OnKeyBound != null)
			{
				this.OnKeyBound(this.KeyType, code);
			}
		}

		// Token: 0x06000A65 RID: 2661 RVA: 0x000094BF File Offset: 0x000076BF
		private void DoCancel()
		{
			this._definingKey = false;
			if (this.OnKeyCancelled != null)
			{
				this.OnKeyCancelled();
			}
		}

		// Token: 0x06000A66 RID: 2662 RVA: 0x0003CF44 File Offset: 0x0003B144
		internal void SetupType(KeyType type)
		{
			KeyCode keyCode = ServiceProvider.GetService<OptionControlService>().GetKeyCode(type);
			this.SetLocalization("key_" + keyCode.ToString().ToLower());
			if (this._texts == null)
			{
				return;
			}
			Color color = ((keyCode != null) ? this.BindingSucess : this.BindingError);
			foreach (Text text in this._texts)
			{
				text.color = color;
			}
		}

		// Token: 0x04000DD0 RID: 3536
		internal Action<KeyType, KeyCode> OnKeyBound;

		// Token: 0x04000DD1 RID: 3537
		internal Action OnKeyCancelled;

		// Token: 0x04000DD2 RID: 3538
		public KeyType KeyType;

		// Token: 0x04000DD3 RID: 3539
		public Text KeyNameText;

		// Token: 0x04000DD4 RID: 3540
		public Color BindingError = new Color32(245, 14, 14, byte.MaxValue);

		// Token: 0x04000DD5 RID: 3541
		public Color BindingSucess = new Color32(86, 95, 95, byte.MaxValue);

		// Token: 0x04000DD6 RID: 3542
		private bool _definingKey;

		// Token: 0x04000DD7 RID: 3543
		private Button _button;

		// Token: 0x04000DD8 RID: 3544
		private Text[] _texts;
	}
}
