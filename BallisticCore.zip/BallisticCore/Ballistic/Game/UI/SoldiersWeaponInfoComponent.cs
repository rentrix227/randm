﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200020C RID: 524
	public class SoldiersWeaponInfoComponent : MonoBehaviour
	{
		// Token: 0x06000A87 RID: 2695 RVA: 0x0003D878 File Offset: 0x0003BA78
		internal void SetData(PlayerWeaponData weaponSelected, PlayerLoadoutV2 loadout)
		{
			if (weaponSelected == null)
			{
				return;
			}
			if (this.WeaponNameLabel != null)
			{
				WeaponSkin skinForLoadout = weaponSelected.PlayerItem.GetSkinForLoadout(loadout);
				this.WeaponNameLabel.text = ServiceProvider.GetService<LocalizationService>().GetWeaponName(weaponSelected.GameItemData.GameItem.ItemName, skinForLoadout.WeaponSkinName, ELocalizedTextCase.UPPER_CASE);
			}
			if (this.WeaponCategoryText != null)
			{
				this.WeaponCategoryText.text = ServiceProvider.GetService<LocalizationService>().Get(weaponSelected.GameItemData.GameItem.WeaponData.WeaponCategory.ToString().ToLower(), ELocalizedTextCase.UPPER_CASE);
			}
			int num = SoldiersWeaponInfoComponent.Dmg(weaponSelected);
			int num2 = SoldiersWeaponInfoComponent.Frate(weaponSelected);
			int num3 = SoldiersWeaponInfoComponent.Acc(weaponSelected);
			float reloadSpeed = weaponSelected.GameItemData.GameItem.ShootData.ReloadSpeed;
			int num4 = SoldiersWeaponInfoComponent.Moby(weaponSelected);
			int magazineSize = weaponSelected.GameItemData.GameItem.ShootData.MagazineSize;
			float num5 = weaponSelected.GameItemData.GameItem.ShootData.HeadshotMultiplier + 1f;
			int num6 = SoldiersWeaponInfoComponent.Range(weaponSelected);
			this.WeaponSelected.DamagePerRoundText.text = num.ToString();
			this.WeaponSelected.FireRateText.text = num2.ToString();
			this.WeaponSelected.AccuracyText.text = num3 + "%";
			this.WeaponSelected.ReloadSpeedText.text = reloadSpeed.ToString("0.0") + "s";
			this.WeaponSelected.MobilityText.text = num4 + "%";
			this.WeaponSelected.ClipSizeText.text = magazineSize.ToString();
			this.WeaponSelected.HeadshotText.text = num5.ToString("0.00") + "x";
			this.WeaponSelected.RangeText.text = (((float)num6 >= float.PositiveInfinity) ? "∞" : (num6 + "m"));
			this.DamageBarSelected.fillAmount = this.DamageBarCurve.Evaluate(SoldiersWeaponInfoComponent.DmgEval((float)num));
			this.FireRateBarSelected.fillAmount = this.FireRateCurve.Evaluate(SoldiersWeaponInfoComponent.RateEval((float)num2));
			this.AccuracyBarSelected.fillAmount = this.AccuraryCurve.Evaluate(SoldiersWeaponInfoComponent.AccEval((float)num3));
			this.RangeBarNormal.sizeDelta = Vector2.Lerp(this.RangeWidthMin, this.RangeWidthMax, (float)num6 / 100f);
			if (this.HasGrLauncOnSelected.activeSelf != (weaponSelected.GameItemData.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.GRENADE_LAUNCHER))
			{
				this.HasGrLauncOnSelected.SetActive(weaponSelected.GameItemData.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.GRENADE_LAUNCHER);
			}
			if (this.HasShotgunOnSelected.activeSelf != (weaponSelected.GameItemData.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.SHOTGUN))
			{
				this.HasShotgunOnSelected.SetActive(weaponSelected.GameItemData.GameItem.ShootData.WeaponSecondaryFunction == EWeaponSkill.SHOTGUN);
			}
			if (this.HasSilenceOnSelected.activeSelf != weaponSelected.GameItemData.GameItem.WeaponData.IsSupressed)
			{
				this.HasSilenceOnSelected.SetActive(weaponSelected.GameItemData.GameItem.WeaponData.IsSupressed);
			}
			if (this.HasLaserSgOnSelected.activeSelf != weaponSelected.GameItemData.GameItem.WeaponData.IsLaserSight)
			{
				this.HasLaserSgOnSelected.SetActive(weaponSelected.GameItemData.GameItem.WeaponData.IsLaserSight);
			}
			if (this.HasMeKnifeOnSelected.activeSelf != (weaponSelected.GameItemData.GameItem.ShootData.WeaponSkill == EWeaponSkill.MELEE))
			{
				this.HasMeKnifeOnSelected.SetActive(weaponSelected.GameItemData.GameItem.ShootData.WeaponSkill == EWeaponSkill.MELEE);
			}
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x00009617 File Offset: 0x00007817
		private static int Dmg(PlayerWeaponData weapon)
		{
			return (int)(weapon.GameItemData.GameItem.ShootData.DamagePerShot * (float)weapon.GameItemData.GameItem.ShootData.BulletsPerShot * 100f);
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x0003DC98 File Offset: 0x0003BE98
		private static int Acc(PlayerWeaponData weapon)
		{
			return (int)((weapon.GameItemData.GameItem.AimData.Precision - weapon.GameItemData.GameItem.AimData.ShootPrecision / 2f + weapon.GameItemData.GameItem.AimData.AimPrecision - weapon.GameItemData.GameItem.AimData.AimShootPrecision / 2f) / 2f);
		}

		// Token: 0x06000A8A RID: 2698 RVA: 0x0000964C File Offset: 0x0000784C
		private static int Frate(PlayerWeaponData weapon)
		{
			return (int)(1f / weapon.GameItemData.GameItem.ShootData.FireRate * 60f);
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x00009670 File Offset: 0x00007870
		private static int Moby(PlayerWeaponData weapon)
		{
			return (int)((weapon.GameItemData.GameItem.WeaponData.MobilityModifier * 3f + weapon.GameItemData.GameItem.WeaponData.AimingMobilityModifier) / 4f * 100f);
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x0003DD10 File Offset: 0x0003BF10
		private static int Range(PlayerWeaponData weapon)
		{
			int num = weapon.GameItemData.GameItem.ShootData.DamageCurve.keys.Length - 1;
			float time = weapon.GameItemData.GameItem.ShootData.DamageCurve.keys[0].time;
			float time2 = weapon.GameItemData.GameItem.ShootData.DamageCurve.keys[num].time;
			float num2 = Mathf.InverseLerp(1f, weapon.GameItemData.GameItem.ShootData.DamageCurve.keys[num].value, 0.5f);
			return (int)(time + num2 * (time2 - time));
		}

		// Token: 0x06000A8D RID: 2701 RVA: 0x000096B0 File Offset: 0x000078B0
		private static float DmgEval(float damage)
		{
			return damage / 150f;
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x000096B9 File Offset: 0x000078B9
		private static float AccEval(float acc)
		{
			return acc / 100f;
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x000096C2 File Offset: 0x000078C2
		private static float RateEval(float frate)
		{
			return frate / 1100f;
		}

		// Token: 0x04000E0A RID: 3594
		public Text WeaponNameLabel;

		// Token: 0x04000E0B RID: 3595
		public Text WeaponCategoryText;

		// Token: 0x04000E0C RID: 3596
		public WeaponInfo WeaponSelected;

		// Token: 0x04000E0D RID: 3597
		public Image DamageBarSelected;

		// Token: 0x04000E0E RID: 3598
		public Image FireRateBarSelected;

		// Token: 0x04000E0F RID: 3599
		public Image AccuracyBarSelected;

		// Token: 0x04000E10 RID: 3600
		public GameObject HasGrLauncOnSelected;

		// Token: 0x04000E11 RID: 3601
		public GameObject HasShotgunOnSelected;

		// Token: 0x04000E12 RID: 3602
		public GameObject HasLaserSgOnSelected;

		// Token: 0x04000E13 RID: 3603
		public GameObject HasSilenceOnSelected;

		// Token: 0x04000E14 RID: 3604
		public GameObject HasMeKnifeOnSelected;

		// Token: 0x04000E15 RID: 3605
		public AnimationCurve DamageBarCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x04000E16 RID: 3606
		public AnimationCurve FireRateCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x04000E17 RID: 3607
		public AnimationCurve AccuraryCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x04000E18 RID: 3608
		public RectTransform RangeBarNormal;

		// Token: 0x04000E19 RID: 3609
		public Vector2 RangeWidthMin;

		// Token: 0x04000E1A RID: 3610
		public Vector2 RangeWidthMax;
	}
}
