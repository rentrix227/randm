﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000292 RID: 658
	[Serializable]
	public class BorderSettings
	{
		// Token: 0x040011DF RID: 4575
		public float LeftBorder;

		// Token: 0x040011E0 RID: 4576
		public float RightBorder;

		// Token: 0x040011E1 RID: 4577
		public float TopBorder;

		// Token: 0x040011E2 RID: 4578
		public float BottomBorder;
	}
}
