﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200030C RID: 780
	public class SettingsGraphicsView : BaseView<SettingsController>
	{
		// Token: 0x0600106E RID: 4206 RVA: 0x0005F9C0 File Offset: 0x0005DBC0
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.QualityDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnQualityValueChanged));
			this.ResolutionDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnResolutionValueChanged));
			this.AliasingDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnAliasingValueChanged));
			this.FullScreenToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnFullScreenValueChanged));
			this.VsyncToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnVSyncValueChanged));
			this.BlurToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnBlurValueChanged));
		}

		// Token: 0x0600106F RID: 4207 RVA: 0x0000D889 File Offset: 0x0000BA89
		internal void SetQualityDropdownValues(string[] values, string defaultValue)
		{
			this.QualityDropdown.options.Clear();
			Array.ForEach<string>(values, delegate(string v)
			{
				this.QualityDropdown.options.Add(new Dropdown.OptionData(v));
			});
			this.QualityDropdown.value = Array.IndexOf<string>(values, defaultValue);
		}

		// Token: 0x06001070 RID: 4208 RVA: 0x0000D8BF File Offset: 0x0000BABF
		internal void SetResolutionDropdownValues(string[] values, string defaultValue)
		{
			this.ResolutionDropdown.options.Clear();
			Array.ForEach<string>(values, delegate(string v)
			{
				this.ResolutionDropdown.options.Add(new Dropdown.OptionData(v));
			});
			this.ResolutionDropdown.value = Array.IndexOf<string>(values, defaultValue);
		}

		// Token: 0x06001071 RID: 4209 RVA: 0x0000D8F5 File Offset: 0x0000BAF5
		internal void SetAliasingDropdownValues(string[] values, string defaultValue)
		{
			this.AliasingDropdown.options.Clear();
			Array.ForEach<string>(values, delegate(string v)
			{
				this.AliasingDropdown.options.Add(new Dropdown.OptionData(v));
			});
			this.AliasingDropdown.value = Array.IndexOf<string>(values, defaultValue);
		}

		// Token: 0x06001072 RID: 4210 RVA: 0x0000D92B File Offset: 0x0000BB2B
		internal void SetFullScreenToggle(bool value)
		{
			this.FullScreenToggle.isOn = value;
		}

		// Token: 0x06001073 RID: 4211 RVA: 0x0000D939 File Offset: 0x0000BB39
		internal void SetVSyncToggle(bool value)
		{
			this.VsyncToggle.isOn = value;
		}

		// Token: 0x06001074 RID: 4212 RVA: 0x0000D947 File Offset: 0x0000BB47
		internal void SetBlurToggle(bool value)
		{
			this.BlurToggle.isOn = value;
		}

		// Token: 0x06001075 RID: 4213 RVA: 0x0000D746 File Offset: 0x0000B946
		private void OnQualityValueChanged(int newValue)
		{
			base._controller.SetQuality(newValue);
		}

		// Token: 0x06001076 RID: 4214 RVA: 0x0000D754 File Offset: 0x0000B954
		private void OnResolutionValueChanged(int newValue)
		{
			base._controller.SetResolution(newValue);
		}

		// Token: 0x06001077 RID: 4215 RVA: 0x0000D762 File Offset: 0x0000B962
		private void OnAliasingValueChanged(int newValue)
		{
			base._controller.SetAliasing(newValue);
		}

		// Token: 0x06001078 RID: 4216 RVA: 0x0000D770 File Offset: 0x0000B970
		private void OnFullScreenValueChanged(bool value)
		{
			base._controller.SetFullScreen(value);
		}

		// Token: 0x06001079 RID: 4217 RVA: 0x0000D77E File Offset: 0x0000B97E
		private void OnVSyncValueChanged(bool value)
		{
			base._controller.SetVSync(value);
		}

		// Token: 0x0600107A RID: 4218 RVA: 0x0000D78C File Offset: 0x0000B98C
		private void OnBlurValueChanged(bool value)
		{
			base._controller.SetBlur(value);
		}

		// Token: 0x0600107B RID: 4219 RVA: 0x0000D79A File Offset: 0x0000B99A
		private void OnLanguageValueChanged(int value)
		{
			base._controller.SetLanguage(value);
		}

		// Token: 0x0600107C RID: 4220 RVA: 0x0000D7A8 File Offset: 0x0000B9A8
		private void OnInGameChatValueChanged(bool value)
		{
			base._controller.SetInGameChat(value);
		}

		// Token: 0x0600107D RID: 4221 RVA: 0x0000D7B6 File Offset: 0x0000B9B6
		private void OnResetLoadouts()
		{
			base._controller.OnDefaultLoadout();
		}

		// Token: 0x0600107E RID: 4222 RVA: 0x0000D7C3 File Offset: 0x0000B9C3
		private void OnResetStatistics()
		{
			base._controller.OnDefaultStatistics();
		}

		// Token: 0x040015B5 RID: 5557
		[Header("Graphics")]
		public Dropdown QualityDropdown;

		// Token: 0x040015B6 RID: 5558
		public Dropdown ResolutionDropdown;

		// Token: 0x040015B7 RID: 5559
		public Toggle FullScreenToggle;

		// Token: 0x040015B8 RID: 5560
		public Toggle VsyncToggle;

		// Token: 0x040015B9 RID: 5561
		public Dropdown AliasingDropdown;

		// Token: 0x040015BA RID: 5562
		public Toggle BlurToggle;
	}
}
