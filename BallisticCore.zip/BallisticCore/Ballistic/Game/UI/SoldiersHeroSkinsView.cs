﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000315 RID: 789
	public class SoldiersHeroSkinsView : BaseView<SoldiersController>
	{
		// Token: 0x060010AA RID: 4266 RVA: 0x000607C0 File Offset: 0x0005E9C0
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SkinTemplate.Template.Dispose();
			for (int i = 0; i < this.SkinPreviewLists.Length; i++)
			{
				this.SkinPreviewLists[i].Template.Dispose();
			}
		}

		// Token: 0x060010AB RID: 4267 RVA: 0x0000DBF4 File Offset: 0x0000BDF4
		internal void SetStartSkinList(IEnumerable<HeroSkin> avaliableSkins, List<HeroSkin> selectedSkins, int currentSkin)
		{
			this._avaliableSkins = avaliableSkins.ToList<HeroSkin>();
			this._selectedSkins = selectedSkins;
			this._currentSkin = currentSkin;
			this.ChangeDataComplete();
		}

		// Token: 0x060010AC RID: 4268 RVA: 0x0000DC16 File Offset: 0x0000BE16
		internal void SetSkinList(IEnumerable<HeroSkin> avaliableSkins, List<HeroSkin> selectedSkins, int currentSkin)
		{
			this._avaliableSkins = avaliableSkins.ToList<HeroSkin>();
			this._selectedSkins = selectedSkins;
			this._currentSkin = currentSkin;
		}

		// Token: 0x060010AD RID: 4269 RVA: 0x0000DC32 File Offset: 0x0000BE32
		private void OnSkinSelected(HeroSkin skin)
		{
			if (skin.ItemId == this._selectedSkins[this._currentSkin].ItemId)
			{
				return;
			}
			base._controller.DispatchSoldierSkinChanged(skin);
		}

		// Token: 0x060010AE RID: 4270 RVA: 0x0006081C File Offset: 0x0005EA1C
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SkinTemplate.SetActiveCount(this._avaliableSkins.Count);
			for (int i = 0; i < this._avaliableSkins.Count; i++)
			{
				SoldiersSkinComponent soldiersSkinComponent = (SoldiersSkinComponent)this.SkinTemplate[i];
				soldiersSkinComponent.SetData(this._avaliableSkins[i], this._avaliableSkins[i].ItemId == this._selectedSkins[this._currentSkin].ItemId);
				soldiersSkinComponent.OnToggleClicked = new Action<HeroSkin>(this.OnSkinSelected);
			}
			int num = 0;
			while (num < this.SkinPreviewLists.Length && num < this._selectedSkins.Count)
			{
				this.SkinPreviewLists[num].SetActiveCount(this._avaliableSkins.Count);
				for (int j = 0; j < this._avaliableSkins.Count; j++)
				{
					SoldiersSkinComponent soldiersSkinComponent2 = (SoldiersSkinComponent)this.SkinPreviewLists[num][j];
					soldiersSkinComponent2.SetData(this._avaliableSkins[j], this._avaliableSkins[j].ItemId == this._selectedSkins[num].ItemId);
					soldiersSkinComponent2.OnToggleClicked = null;
				}
				num++;
			}
		}

		// Token: 0x040015E5 RID: 5605
		public PoolableList SkinTemplate;

		// Token: 0x040015E6 RID: 5606
		public PoolableList[] SkinPreviewLists;

		// Token: 0x040015E7 RID: 5607
		private List<HeroSkin> _avaliableSkins;

		// Token: 0x040015E8 RID: 5608
		private List<HeroSkin> _selectedSkins;

		// Token: 0x040015E9 RID: 5609
		private int _currentSkin;
	}
}
