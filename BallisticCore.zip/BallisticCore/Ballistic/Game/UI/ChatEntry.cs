﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000276 RID: 630
	public struct ChatEntry
	{
		// Token: 0x04001040 RID: 4160
		public string EntryText;

		// Token: 0x04001041 RID: 4161
		public float Timestamp;
	}
}
