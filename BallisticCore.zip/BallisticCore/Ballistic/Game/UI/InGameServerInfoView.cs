﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002CA RID: 714
	public class InGameServerInfoView : BaseView<InGameMatchTimeController>
	{
		// Token: 0x06000EF6 RID: 3830 RVA: 0x0000C2FF File Offset: 0x0000A4FF
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.BannerCustomButton.onClick.AddListener(new UnityAction(InGameServerInfoView.OnOpenServerUrl));
		}

		// Token: 0x06000EF7 RID: 3831 RVA: 0x0000C33F File Offset: 0x0000A53F
		private static void OnOpenServerUrl()
		{
			if (ServiceProvider.GetService<ServerInfoService>().ClickUrl != null)
			{
				Application.OpenURL(ServiceProvider.GetService<ServerInfoService>().ClickUrl);
			}
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x0005A3A0 File Offset: 0x000585A0
		internal void SetServerData(string serverName, EServerType serverType, bool locked, Texture banner)
		{
			this.ServerTitleText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("hud_server", ELocalizedTextCase.NONE), serverName);
			if (serverType != EServerType.INGAME)
			{
				if (serverType != EServerType.DEDICATED)
				{
					if (serverType == EServerType.OFFICIAL)
					{
						this.ServerTypeText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("hud_server_type", ELocalizedTextCase.NONE), ServiceProvider.GetService<LocalizationService>().Get("status_official", ELocalizedTextCase.NONE));
					}
				}
				else
				{
					this.ServerTypeText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("hud_server_type", ELocalizedTextCase.NONE), ServiceProvider.GetService<LocalizationService>().Get("status_dedicated", ELocalizedTextCase.NONE));
				}
			}
			else
			{
				this.ServerTypeText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("hud_server_type", ELocalizedTextCase.NONE), ServiceProvider.GetService<LocalizationService>().Get("status_ingame", ELocalizedTextCase.NONE));
			}
			if (this.ServerLocked.gameObject.activeSelf != locked)
			{
				this.ServerLocked.gameObject.SetActive(locked);
			}
			this.BannerGameObject.SetActive(serverType == EServerType.DEDICATED || serverType == EServerType.OFFICIAL);
			this.BannerDefault.SetActive(banner == null);
			this.BannerCustom.SetActive(banner != null);
			if (banner != null)
			{
				this.BannerCustomImage.texture = banner;
			}
		}

		// Token: 0x06000EF9 RID: 3833 RVA: 0x0005A508 File Offset: 0x00058708
		internal void SetPingData(uint ping)
		{
			this._latency = LatencyDefinitionData.GetLatency(ping);
			this.ServerPingText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("hud_server_ping", ELocalizedTextCase.NONE), ping);
			this.ServerPingText.color = this._latency.UiColor;
			this.ServerPingBar.color = this._latency.UiColor;
			this.ServerPingBar.fillAmount = 1f - this._latency.Value / 300f;
		}

		// Token: 0x04001412 RID: 5138
		public Text ServerTitleText;

		// Token: 0x04001413 RID: 5139
		public Text ServerPingText;

		// Token: 0x04001414 RID: 5140
		public Image ServerPingBar;

		// Token: 0x04001415 RID: 5141
		public Text ServerTypeText;

		// Token: 0x04001416 RID: 5142
		public Image ServerLocked;

		// Token: 0x04001417 RID: 5143
		public GameObject BannerGameObject;

		// Token: 0x04001418 RID: 5144
		public GameObject BannerDefault;

		// Token: 0x04001419 RID: 5145
		public GameObject BannerCustom;

		// Token: 0x0400141A RID: 5146
		public RawImage BannerCustomImage;

		// Token: 0x0400141B RID: 5147
		public Button BannerCustomButton;

		// Token: 0x0400141C RID: 5148
		private LatencyDefinitionData.LatencyDefinition _latency;
	}
}
