﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Capture.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000219 RID: 537
	public class GameplayKillListController : BaseController
	{
		// Token: 0x06000ADD RID: 2781 RVA: 0x0003F448 File Offset: 0x0003D648
		public GameplayKillListController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnUserListChanged.AddListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnSelectTeamCompleted.AddListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnWeaponStationEvent.AddListener(new Action<WeaponStationEvent>(this.OnWeaponStationEvent));
			this._networkGameService.OnClientConnectionClosed.AddListener(new Action(this.OnClientConnectionClosed));
			this._networkGameService.OnCapturedPoint.AddListener(new Action<CapturedPointEvent>(this.OnCapturedPoint));
			this._networkGameService.OnCapturePointUpdate.AddListener(new Action<CapturePointUpdateStateEvent>(this.OnCapturePointUpdate));
			this._networkGameService.OnScoreUpdateEvent.AddListener(new Action<ScoreUpdateEvent>(this.OnScoreUpdateEvent));
		}

		// Token: 0x06000ADE RID: 2782 RVA: 0x0003F5AC File Offset: 0x0003D7AC
		public override void DisableController()
		{
			base.DisableController();
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnUserListChanged.RemoveListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnSelectTeamCompleted.RemoveListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnWeaponStationEvent.RemoveListener(new Action<WeaponStationEvent>(this.OnWeaponStationEvent));
			this._networkGameService.OnClientConnectionClosed.RemoveListener(new Action(this.OnClientConnectionClosed));
			this._networkGameService.OnCapturedPoint.RemoveListener(new Action<CapturedPointEvent>(this.OnCapturedPoint));
			this._networkGameService.OnCapturePointUpdate.RemoveListener(new Action<CapturePointUpdateStateEvent>(this.OnCapturePointUpdate));
			this._networkGameService.OnScoreUpdateEvent.RemoveListener(new Action<ScoreUpdateEvent>(this.OnScoreUpdateEvent));
		}

		// Token: 0x06000ADF RID: 2783 RVA: 0x0003F6D8 File Offset: 0x0003D8D8
		public override void OnShow(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayKillListView gameplayKillListView = view as GameplayKillListView;
			if (gameplayKillListView != null)
			{
				this._gameplayKillListView = gameplayKillListView;
				this._gameplayKillListView.SetKillStreak(this._playerKillStreak);
			}
			GameplayKillNotificationView gameplayKillNotificationView = view as GameplayKillNotificationView;
			if (gameplayKillNotificationView != null)
			{
				this._gameplayKillNotificationView = gameplayKillNotificationView;
			}
			GameplayActionNotificationView gameplayActionNotificationView = view as GameplayActionNotificationView;
			if (gameplayActionNotificationView != null)
			{
				this._gameplayActionNotificationView = gameplayActionNotificationView;
			}
		}

		// Token: 0x06000AE0 RID: 2784 RVA: 0x0003F750 File Offset: 0x0003D950
		public override void OnHide(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (view is GameplayKillListView)
			{
				this._gameplayKillListView = null;
			}
			if (view is GameplayKillNotificationView)
			{
				if (this._gameplayKillNotificationView != null)
				{
					this._gameplayKillNotificationView.ClearList();
				}
				this._gameplayKillNotificationView = null;
			}
			if (view is GameplayActionNotificationView)
			{
				if (this._gameplayActionNotificationView != null)
				{
					this._gameplayActionNotificationView.ClearList();
				}
				this._gameplayActionNotificationView = null;
			}
		}

		// Token: 0x06000AE1 RID: 2785 RVA: 0x00009A95 File Offset: 0x00007C95
		private void OnSpawn(SpawnEvent spawnEvent)
		{
			if (spawnEvent.User == UserProfile.LocalGameClient.gameClientId)
			{
				this._playerKillStreak = 0;
				if (this._gameplayKillListView != null)
				{
					this._gameplayKillListView.SetKillStreak(this._playerKillStreak);
				}
			}
		}

		// Token: 0x06000AE2 RID: 2786 RVA: 0x0003F7D8 File Offset: 0x0003D9D8
		private void OnUserListChanged(UserListChangedEvent userListEvent)
		{
			long senderId = userListEvent.SenderId;
			if (userListEvent.UpdateType == UserUpdateType.UserJoinedRoom)
			{
				if (this._usersInRoom.Contains(senderId))
				{
					return;
				}
				this._usersInRoom.Add(senderId);
			}
			else if (userListEvent.UpdateType == UserUpdateType.UserLeftRoom && this._usersInRoom.Contains(senderId))
			{
				this._usersInRoom.Remove(senderId);
			}
			if (this._gameplayKillListView != null)
			{
				this._gameplayKillListView.NotifyEvent(userListEvent.SenderNickname, UIEnums.GetRelativeTeam(userListEvent.SenderTeam), userListEvent.UpdateType);
			}
		}

		// Token: 0x06000AE3 RID: 2787 RVA: 0x0003F878 File Offset: 0x0003DA78
		private void OnSelectTeamCompleted(SelectTeamCompletedResponse evt)
		{
			ClientCommonMetaData clientCommonMetaData = this._networkGameService.GetClientCommonMetaData(evt.User);
			if (clientCommonMetaData == null || evt.ClientMode != EClientMode.PLAYER)
			{
				return;
			}
			Team team = (Team)evt.JoinedTeam;
			if (this._gameplayKillListView != null)
			{
				if (team == Team.MFA)
				{
					this._gameplayKillListView.NotifyEvent(clientCommonMetaData.Nickname, UIEnums.GetRelativeTeam(team), UserUpdateType.JoinedMfaTeam);
				}
				else if (team == Team.SMOKE)
				{
					this._gameplayKillListView.NotifyEvent(clientCommonMetaData.Nickname, UIEnums.GetRelativeTeam(team), UserUpdateType.JoinedSmokeTeam);
				}
			}
		}

		// Token: 0x06000AE4 RID: 2788 RVA: 0x0003F908 File Offset: 0x0003DB08
		private void OnWeaponStationEvent(WeaponStationEvent evt)
		{
			ClientCommonMetaData clientCommonMetaData = this._networkGameService.GetClientCommonMetaData(evt.User);
			if (clientCommonMetaData == null)
			{
				return;
			}
			if (this._gameplayKillListView != null)
			{
				this._gameplayKillListView.NotifyEvent(clientCommonMetaData.Nickname, UIEnums.GetRelativeTeam((Team)clientCommonMetaData.Team), UserUpdateType.BecomesJuggernaut);
			}
		}

		// Token: 0x06000AE5 RID: 2789 RVA: 0x00009AD5 File Offset: 0x00007CD5
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			this._usersInRoom.Clear();
		}

		// Token: 0x06000AE6 RID: 2790 RVA: 0x00009AD5 File Offset: 0x00007CD5
		private void OnClientConnectionClosed()
		{
			this._usersInRoom.Clear();
		}

		// Token: 0x06000AE7 RID: 2791 RVA: 0x0003F960 File Offset: 0x0003DB60
		private void OnDie(DieEvent dieEvent)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			bool flag = dieEvent.Killer.isMe && dieEvent.Sender.isMe;
			if (dieEvent.Killer.isMe && !flag)
			{
				this._playerKillStreak++;
				if (this._gameplayKillNotificationView != null)
				{
					this._gameplayKillNotificationView.NotifyKill(dieEvent.Sender.nickname);
				}
			}
			if (this._gameplayKillListView != null)
			{
				float num = Vector3.Distance(dieEvent.ShooterPosition, dieEvent.VictimPosition);
				UITeam relativeTeam = UIEnums.GetRelativeTeam(dieEvent.Killer.team);
				UITeam relativeTeam2 = UIEnums.GetRelativeTeam(dieEvent.Sender.team);
				this._gameplayKillListView.NotifyKill(dieEvent.Killer.nickname, dieEvent.Sender.nickname, relativeTeam, relativeTeam2, dieEvent.WeaponCategory, dieEvent.IsHeadshot, num);
				this._gameplayKillListView.SetKillStreak(this._playerKillStreak);
			}
			if (this._gameplayActionNotificationView != null)
			{
				this._killActions.Clear();
				this._killScores.Clear();
				if (dieEvent.Killer.isMe && !flag)
				{
					bool flag2 = false;
					if (dieEvent.KillerMultiKill == 2)
					{
						this._killActions.Add(ActionNotificationType.DoubleKill);
						this._killScores.Add(10);
					}
					else if (dieEvent.KillerMultiKill == 3)
					{
						this._killActions.Add(ActionNotificationType.TripleKill);
						this._killScores.Add(20);
					}
					else if (dieEvent.KillerMultiKill > 3)
					{
						this._killActions.Add(ActionNotificationType.OverKill);
						this._killScores.Add(50);
					}
					if (dieEvent.KillerKillStreak == 5)
					{
						this._killActions.Add(ActionNotificationType.ExpertStreak);
						this._killScores.Add(25);
					}
					else if (dieEvent.KillerKillStreak > 5 && dieEvent.KillerKillStreak < 10)
					{
						this._killActions.Add(ActionNotificationType.ExpertKill);
						this._killScores.Add(20);
						flag2 = true;
					}
					else if (dieEvent.KillerKillStreak == 10)
					{
						this._killActions.Add(ActionNotificationType.EpicStreak);
						this._killScores.Add(60);
					}
					else if (dieEvent.KillerKillStreak > 10 && dieEvent.KillerKillStreak < 25)
					{
						this._killActions.Add(ActionNotificationType.EpicKill);
						this._killScores.Add(30);
						flag2 = true;
					}
					else if (dieEvent.KillerKillStreak == 25)
					{
						this._killActions.Add(ActionNotificationType.LegendaryStreak);
						this._killScores.Add(150);
					}
					else if (dieEvent.KillerKillStreak > 25)
					{
						this._killActions.Add(ActionNotificationType.LegendaryKill);
						this._killScores.Add(55);
						flag2 = true;
					}
					if (dieEvent.KillOfJuggernaut)
					{
						this._killActions.Add(ActionNotificationType.Kill);
						this._killScores.Add(10);
						flag2 = true;
					}
					if (dieEvent.JuggernautKill)
					{
						this._killActions.Add(ActionNotificationType.JuggernautKill);
						this._killScores.Add((int)dieEvent.FinalScore);
						flag2 = true;
					}
					if (dieEvent.IsHeadshot)
					{
						HeadshotType headshot = dieEvent.Headshot;
						if (headshot != HeadshotType.HEADSHOT)
						{
							if (headshot == HeadshotType.MARKSMAN_HEADSHOT)
							{
								this._killActions.Add(ActionNotificationType.MarksmanHeadshot);
								this._killScores.Add(15);
							}
						}
						else
						{
							this._killActions.Add(ActionNotificationType.Headshot);
							this._killScores.Add(5);
						}
					}
					if (dieEvent.IsBackstab)
					{
						this._killActions.Add(ActionNotificationType.Backstab);
						this._killScores.Add(5);
					}
					if (dieEvent.DefenseKill)
					{
						this._killActions.Add(ActionNotificationType.DefenseKill);
						this._killScores.Add(15);
					}
					if (dieEvent.AvengerKill)
					{
						this._killActions.Add(ActionNotificationType.AvengerKill);
						this._killScores.Add(10);
					}
					if (dieEvent.SaviorKill)
					{
						this._killActions.Add(ActionNotificationType.SaviorKill);
						this._killScores.Add(10);
					}
					if (!flag2)
					{
						this._killActions.Add(ActionNotificationType.Kill);
						this._killScores.Add(15);
					}
				}
				if (dieEvent.AdditionalPlayers != null)
				{
					for (int i = 0; i < dieEvent.AdditionalPlayers.Count; i++)
					{
						AdditionalScorer additionalScorer = dieEvent.AdditionalPlayers[i];
						if (additionalScorer.Sender.isMe)
						{
							if (additionalScorer.IsCriticalAssist)
							{
								this._killActions.Add(ActionNotificationType.CriticalKillAssist);
								this._killScores.Add(additionalScorer.Score);
							}
							else if (additionalScorer.IsJuggernautAssist)
							{
								this._killActions.Add(ActionNotificationType.JuggernautAssist);
								this._killScores.Add(additionalScorer.Score);
							}
							else if (additionalScorer.IsAssist)
							{
								this._killActions.Add(ActionNotificationType.KillAssist);
								this._killScores.Add(additionalScorer.Score);
							}
						}
					}
				}
				for (int j = 0; j < this._killActions.Count; j++)
				{
					this._gameplayActionNotificationView.NotifyAction(this._killActions[j], this._killScores[j], false);
				}
			}
		}

		// Token: 0x06000AE8 RID: 2792 RVA: 0x0003FECC File Offset: 0x0003E0CC
		private void OnCapturedPoint(CapturedPointEvent evt)
		{
			if (evt.CaptureScoreChange.ContainsKey(UserProfile.LocalGameClient.gameClientId) && this._gameplayActionNotificationView != null)
			{
				this._gameplayActionNotificationView.NotifyAction(ActionNotificationType.CapturePoint, (int)evt.CaptureScoreChange[UserProfile.LocalGameClient.gameClientId], false);
			}
		}

		// Token: 0x06000AE9 RID: 2793 RVA: 0x0003FF28 File Offset: 0x0003E128
		private void OnCapturePointUpdate(CapturePointUpdateStateEvent evt)
		{
			if (this._gameplayActionNotificationView == null)
			{
				return;
			}
			for (int i = 0; i < evt.StandingPlayers.Count; i++)
			{
				if (UserProfile.IsMe(evt.StandingPlayers[i]))
				{
					this._gameplayActionNotificationView.NotifyAction(ActionNotificationType.Standing, (int)evt.StandingScoreChanges[i], true);
					return;
				}
			}
		}

		// Token: 0x06000AEA RID: 2794 RVA: 0x0003FF9C File Offset: 0x0003E19C
		private void OnScoreUpdateEvent(ScoreUpdateEvent evt)
		{
			if (this._gameplayActionNotificationView == null)
			{
				return;
			}
			foreach (KeyValuePair<long, short> keyValuePair in evt.ScoreChanges)
			{
				if (UserProfile.IsMe(keyValuePair.Key))
				{
					this._gameplayActionNotificationView.NotifyAction(ActionNotificationType.JuggernautPoint, (int)keyValuePair.Value, true);
				}
			}
		}

		// Token: 0x04000E62 RID: 3682
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E63 RID: 3683
		private GameplayKillListView _gameplayKillListView;

		// Token: 0x04000E64 RID: 3684
		private GameplayKillNotificationView _gameplayKillNotificationView;

		// Token: 0x04000E65 RID: 3685
		private GameplayActionNotificationView _gameplayActionNotificationView;

		// Token: 0x04000E66 RID: 3686
		private int _playerKillStreak;

		// Token: 0x04000E67 RID: 3687
		private readonly List<ActionNotificationType> _killActions = new List<ActionNotificationType>();

		// Token: 0x04000E68 RID: 3688
		private readonly List<int> _killScores = new List<int>();

		// Token: 0x04000E69 RID: 3689
		private readonly List<long> _usersInRoom = new List<long>();
	}
}
