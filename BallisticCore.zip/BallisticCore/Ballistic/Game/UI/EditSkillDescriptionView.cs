﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200026C RID: 620
	public class EditSkillDescriptionView : BaseView<SkillsController>
	{
		// Token: 0x06000D46 RID: 3398 RVA: 0x0004E9F8 File Offset: 0x0004CBF8
		internal void SetStartDescription(HeroSkillData skill)
		{
			this._skill = skill;
			this.SkillDescription.text = ServiceProvider.GetService<LocalizationService>().Get(skill.DescriptionKey, ELocalizedTextCase.NONE);
			this.SkillNameText.text = ServiceProvider.GetService<LocalizationService>().Get(skill.LocalizationKey, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x06000D47 RID: 3399 RVA: 0x0000B147 File Offset: 0x00009347
		internal void SetDescription(HeroSkillData skill)
		{
			this._skill = skill;
		}

		// Token: 0x06000D48 RID: 3400 RVA: 0x0004EA44 File Offset: 0x0004CC44
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SkillDescription.text = ServiceProvider.GetService<LocalizationService>().Get(this._skill.DescriptionKey, ELocalizedTextCase.NONE);
			this.SkillNameText.text = ServiceProvider.GetService<LocalizationService>().Get(this._skill.LocalizationKey, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x0400100F RID: 4111
		public Text SkillNameText;

		// Token: 0x04001010 RID: 4112
		public Text SkillDescription;

		// Token: 0x04001011 RID: 4113
		private HeroSkillData _skill;
	}
}
