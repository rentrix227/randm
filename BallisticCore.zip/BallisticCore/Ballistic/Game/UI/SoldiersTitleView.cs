﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200031E RID: 798
	public class SoldiersTitleView : BaseView<SoldiersController>
	{
		// Token: 0x060010E1 RID: 4321 RVA: 0x0000DEAD File Offset: 0x0000C0AD
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x0000DECB File Offset: 0x0000C0CB
		internal void SetStartTitle(EHeroClass heroClass)
		{
			this._currentHeroClass = heroClass;
			this.TitleText.text = this._localizationService.GetClassName(heroClass, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x0000DEEC File Offset: 0x0000C0EC
		internal void SetTitle(EHeroClass heroClass)
		{
			this._currentHeroClass = heroClass;
		}

		// Token: 0x060010E4 RID: 4324 RVA: 0x0000DEF5 File Offset: 0x0000C0F5
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.TitleText.text = this._localizationService.GetClassName(this._currentHeroClass, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x04001617 RID: 5655
		public Text TitleText;

		// Token: 0x04001618 RID: 5656
		private LocalizationService _localizationService;

		// Token: 0x04001619 RID: 5657
		private EHeroClass _currentHeroClass;
	}
}
