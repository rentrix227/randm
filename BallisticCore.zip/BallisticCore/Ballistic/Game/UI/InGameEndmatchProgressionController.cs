﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000226 RID: 550
	public class InGameEndmatchProgressionController : BaseController
	{
		// Token: 0x06000B5D RID: 2909 RVA: 0x000440D8 File Offset: 0x000422D8
		public InGameEndmatchProgressionController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._progressionService = ServiceProvider.GetService<ProgressionService>();
			this._playerLoadoutService = ServiceProvider.GetService<PlayerLoadoutService>();
			this._weaponService = ServiceProvider.GetService<WeaponService>();
			this._playerWeaponService = ServiceProvider.GetService<PlayerWeaponService>();
			this._soldiersService = ServiceProvider.GetService<SoldiersService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._oldLoadoutPrimaryWeapons = new Dictionary<EHeroClass, List<PlayerWeaponData>>();
			this._oldLoadoutSecondaryWeapons = new Dictionary<EHeroClass, List<PlayerWeaponData>>();
			this._oldLoadoutSkills = new Dictionary<EHeroClass, List<List<EHeroSkillV2>>>();
		}

		// Token: 0x06000B5E RID: 2910 RVA: 0x00009DCB File Offset: 0x00007FCB
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
		}

		// Token: 0x06000B5F RID: 2911 RVA: 0x0004418C File Offset: 0x0004238C
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameEndmatchProgressionView inGameEndmatchProgressionView = view as InGameEndmatchProgressionView;
			if (inGameEndmatchProgressionView != null)
			{
				inGameEndmatchProgressionView.SetData(this._awardedXpByCategory, this._classesProgressionData);
			}
			ItemUnlockDetailsPopupView itemUnlockDetailsPopupView = view as ItemUnlockDetailsPopupView;
			if (itemUnlockDetailsPopupView != null)
			{
				this.UpdateDetailsView();
			}
		}

		// Token: 0x06000B60 RID: 2912 RVA: 0x000441EC File Offset: 0x000423EC
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			this._progressionService.SetMatchEnded();
			this._classesProgressionData = this._progressionService.CalculateClassesXpGain(out this._awardedXpByCategory);
			foreach (ClassProgressionData classProgressionData in this._classesProgressionData)
			{
				if (!this._oldLoadoutPrimaryWeapons.ContainsKey(classProgressionData.HeroClass))
				{
					this._oldLoadoutPrimaryWeapons.Add(classProgressionData.HeroClass, new List<PlayerWeaponData>());
				}
				if (!this._oldLoadoutSecondaryWeapons.ContainsKey(classProgressionData.HeroClass))
				{
					this._oldLoadoutSecondaryWeapons.Add(classProgressionData.HeroClass, new List<PlayerWeaponData>());
				}
				if (!this._oldLoadoutSkills.ContainsKey(classProgressionData.HeroClass))
				{
					this._oldLoadoutSkills.Add(classProgressionData.HeroClass, new List<List<EHeroSkillV2>>());
				}
				this._oldLoadoutPrimaryWeapons[classProgressionData.HeroClass].Clear();
				this._oldLoadoutSecondaryWeapons[classProgressionData.HeroClass].Clear();
				this._oldLoadoutSkills[classProgressionData.HeroClass].Clear();
				foreach (PlayerLoadoutData playerLoadoutData in this._playerLoadoutService.GetPlayerLoadouts(classProgressionData.HeroClass))
				{
					this._oldLoadoutPrimaryWeapons[classProgressionData.HeroClass].Add(this.GetEquippedWeapon(playerLoadoutData, EWeaponType.PrimaryWeapon));
					this._oldLoadoutSecondaryWeapons[classProgressionData.HeroClass].Add(this.GetEquippedWeapon(playerLoadoutData, EWeaponType.SecondaryWeapon));
					this._oldLoadoutSkills[classProgressionData.HeroClass].Add((from t in this._soldiersService.GetSelectedHeroSkills(playerLoadoutData)
						select t.Skill).ToList<EHeroSkillV2>());
				}
			}
			int num;
			int num2;
			this._progressionService.GetPlayerAccountLevel(out num, out num2);
			this._progressionService.GetPlayerRank();
			this._progressionService.ApplyMatchProgression();
		}

		// Token: 0x06000B61 RID: 2913 RVA: 0x00009DFA File Offset: 0x00007FFA
		internal void DispatchClassCardClicked(ClassProgressionData heroProgression)
		{
			this._selectedClassProgressionData = heroProgression;
			this.UpdateDetailsView();
		}

		// Token: 0x06000B62 RID: 2914 RVA: 0x00044438 File Offset: 0x00042638
		private EHeroItemSlot WeaponTypeToLoadoutSlot(EWeaponType weaponType)
		{
			EHeroItemSlot eheroItemSlot = EHeroItemSlot.None;
			if (weaponType == EWeaponType.PrimaryWeapon)
			{
				eheroItemSlot = EHeroItemSlot.PrimaryWeapon;
			}
			else if (weaponType == EWeaponType.SecondaryWeapon)
			{
				eheroItemSlot = EHeroItemSlot.SecondaryWeapon;
			}
			return eheroItemSlot;
		}

		// Token: 0x06000B63 RID: 2915 RVA: 0x00044460 File Offset: 0x00042660
		private PlayerWeaponData GetEquippedWeapon(PlayerLoadoutData loadout, EWeaponType weaponType)
		{
			EHeroItemSlot eheroItemSlot = this.WeaponTypeToLoadoutSlot(weaponType);
			if (eheroItemSlot != EHeroItemSlot.None)
			{
				WeaponData weapon = this._weaponService.GetWeapon(loadout.PlayerItem.ItemMap[eheroItemSlot]);
				return this._playerWeaponService.GetPlayerWeapon(weapon);
			}
			return null;
		}

		// Token: 0x06000B64 RID: 2916 RVA: 0x00009E09 File Offset: 0x00008009
		private PlayerWeaponData GetEquippedWeapon(int loadoutIndex, EWeaponType weaponType)
		{
			return this.GetEquippedWeapon(this._playerLoadoutService.GetPlayerLoadouts(this._selectedClassProgressionData.HeroClass).Skip(loadoutIndex).FirstOrDefault<PlayerLoadoutData>(), weaponType);
		}

		// Token: 0x06000B65 RID: 2917 RVA: 0x000444A8 File Offset: 0x000426A8
		internal void HandleWeaponLoadoutReplace(int loadoutIndex, int weaponIndex, bool equipNewItem)
		{
			PlayerWeaponData playerWeapon = this._playerWeaponService.GetPlayerWeapon(this._weaponService.GetWeapon(this._selectedClassProgressionData.UnlockedItems.Last<string>()));
			if (weaponIndex == 0)
			{
				this.ReplaceWeaponInLoadout(loadoutIndex, EHeroItemSlot.SecondaryWeapon, this._oldLoadoutSecondaryWeapons[this._selectedClassProgressionData.HeroClass][loadoutIndex]);
				this.ReplaceWeaponInLoadout(loadoutIndex, EHeroItemSlot.PrimaryWeapon, (weaponIndex != 0 || !equipNewItem) ? this._oldLoadoutPrimaryWeapons[this._selectedClassProgressionData.HeroClass][loadoutIndex] : playerWeapon);
			}
			else if (weaponIndex == 1)
			{
				this.ReplaceWeaponInLoadout(loadoutIndex, EHeroItemSlot.PrimaryWeapon, this._oldLoadoutPrimaryWeapons[this._selectedClassProgressionData.HeroClass][loadoutIndex]);
				this.ReplaceWeaponInLoadout(loadoutIndex, EHeroItemSlot.SecondaryWeapon, (weaponIndex != 1 || !equipNewItem) ? this._oldLoadoutSecondaryWeapons[this._selectedClassProgressionData.HeroClass][loadoutIndex] : playerWeapon);
			}
			this.UpdateDetailsView();
		}

		// Token: 0x06000B66 RID: 2918 RVA: 0x000445AC File Offset: 0x000427AC
		internal void ReplaceWeaponInLoadout(int loadoutIndex, EHeroItemSlot itemSlot, PlayerWeaponData weaponToEquip)
		{
			EHeroClass heroClass = this._selectedClassProgressionData.HeroClass;
			IEnumerable<PlayerLoadoutData> playerLoadouts = this._playerLoadoutService.GetPlayerLoadouts(heroClass);
			PlayerLoadoutData playerLoadoutData = playerLoadouts.Skip(loadoutIndex).FirstOrDefault<PlayerLoadoutData>();
			this._playerLoadoutService.EquipItem(playerLoadoutData, weaponToEquip, itemSlot);
		}

		// Token: 0x06000B67 RID: 2919 RVA: 0x000445F0 File Offset: 0x000427F0
		internal void HandleSkillLoadoutReplace(int loadoutIndex, int skillIndex, bool equipNewItem)
		{
			EHeroSkillV2 eheroSkillV = (EHeroSkillV2)Enum.Parse(typeof(EHeroSkillV2), this._selectedClassProgressionData.UnlockedItems.Last<string>().ToUpperInvariant());
			if (skillIndex == 0)
			{
				this.ReplaceSkillInLoadout(loadoutIndex, (!equipNewItem) ? this._oldLoadoutSkills[this._selectedClassProgressionData.HeroClass][loadoutIndex][0] : eheroSkillV, this._oldLoadoutSkills[this._selectedClassProgressionData.HeroClass][loadoutIndex][1]);
			}
			else if (skillIndex == 1)
			{
				this.ReplaceSkillInLoadout(loadoutIndex, this._oldLoadoutSkills[this._selectedClassProgressionData.HeroClass][loadoutIndex][0], (!equipNewItem) ? this._oldLoadoutSkills[this._selectedClassProgressionData.HeroClass][loadoutIndex][1] : eheroSkillV);
			}
			this.UpdateDetailsView();
		}

		// Token: 0x06000B68 RID: 2920 RVA: 0x000446F0 File Offset: 0x000428F0
		private void ReplaceSkillInLoadout(int loadoutIndex, EHeroSkillV2 skill1, EHeroSkillV2 skill2)
		{
			EHeroClass heroClass = this._selectedClassProgressionData.HeroClass;
			IEnumerable<PlayerLoadoutData> playerLoadouts = this._playerLoadoutService.GetPlayerLoadouts(heroClass);
			PlayerLoadoutData playerLoadoutData = playerLoadouts.Skip(loadoutIndex).FirstOrDefault<PlayerLoadoutData>();
			this._playerLoadoutService.ClearLoadoutSkills(playerLoadoutData);
			this._playerLoadoutService.EquipSkill(playerLoadoutData, skill1);
			this._playerLoadoutService.EquipSkill(playerLoadoutData, skill2);
			this._soldiersService.LoadPlayerLoadouts();
		}

		// Token: 0x06000B69 RID: 2921 RVA: 0x00044758 File Offset: 0x00042958
		private void UpdateDetailsView()
		{
			ItemUnlockDetailsPopupView view = base.GetView<ItemUnlockDetailsPopupView>();
			if (view != null)
			{
				EHeroClass heroClass = this._selectedClassProgressionData.HeroClass;
				EUnlockType eunlockType = this._selectedClassProgressionData.UnlockTypes.Last<EUnlockType>();
				int num = 1 + this._selectedClassProgressionData.UnlockedItemIndexes.Last<int>();
				string text = this._selectedClassProgressionData.UnlockedItems.Last<string>();
				view.UpdateInfo(eunlockType, heroClass, text, num);
			}
		}

		// Token: 0x04000ECD RID: 3789
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000ECE RID: 3790
		private readonly ProgressionService _progressionService;

		// Token: 0x04000ECF RID: 3791
		private readonly PlayerLoadoutService _playerLoadoutService;

		// Token: 0x04000ED0 RID: 3792
		private readonly WeaponService _weaponService;

		// Token: 0x04000ED1 RID: 3793
		private readonly PlayerWeaponService _playerWeaponService;

		// Token: 0x04000ED2 RID: 3794
		private readonly SoldiersService _soldiersService;

		// Token: 0x04000ED3 RID: 3795
		private ClassProgressionData _selectedClassProgressionData;

		// Token: 0x04000ED4 RID: 3796
		private Dictionary<EHeroClass, List<PlayerWeaponData>> _oldLoadoutPrimaryWeapons;

		// Token: 0x04000ED5 RID: 3797
		private Dictionary<EHeroClass, List<PlayerWeaponData>> _oldLoadoutSecondaryWeapons;

		// Token: 0x04000ED6 RID: 3798
		private Dictionary<EHeroClass, List<List<EHeroSkillV2>>> _oldLoadoutSkills;

		// Token: 0x04000ED7 RID: 3799
		private Dictionary<EAwardedXpCategory, int> _awardedXpByCategory = new Dictionary<EAwardedXpCategory, int>();

		// Token: 0x04000ED8 RID: 3800
		private List<ClassProgressionData> _classesProgressionData = new List<ClassProgressionData>();
	}
}
