﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C4 RID: 452
	public class ExcludeNotificationComponent : MonoBehaviour
	{
		// Token: 0x06000968 RID: 2408 RVA: 0x0003973C File Offset: 0x0003793C
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.ExcludeWhenButtonClick != null)
			{
				this.ExcludeWhenButtonClick.onClick.AddListener(new UnityAction(this.OnExcludeNotificationClick));
			}
			this._inventoryService = ServiceProvider.GetService<InventoryService>();
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x0003978C File Offset: 0x0003798C
		private void OnExcludeNotificationClick()
		{
			foreach (ENotifications enotifications in this.NotificationsToListen)
			{
				this._inventoryService.ClearNotifications(enotifications);
			}
		}

		// Token: 0x04000C72 RID: 3186
		public Button ExcludeWhenButtonClick;

		// Token: 0x04000C73 RID: 3187
		public ENotifications[] NotificationsToListen;

		// Token: 0x04000C74 RID: 3188
		private InventoryService _inventoryService;
	}
}
