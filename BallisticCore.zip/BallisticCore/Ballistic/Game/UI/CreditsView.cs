﻿using System;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000264 RID: 612
	public class CreditsView : BaseView<CreditsController>
	{
		// Token: 0x06000D2F RID: 3375 RVA: 0x0004E6D4 File Offset: 0x0004C8D4
		internal void ScrollUp(float deltatime)
		{
			if (this.CreditsScroll != null && this.CreditsScroll.verticalNormalizedPosition > this.ScrollEnd)
			{
				this.CreditsScroll.verticalNormalizedPosition -= this.ScrollSpeed * deltatime;
			}
		}

		// Token: 0x04000FFE RID: 4094
		public ScrollRect CreditsScroll;

		// Token: 0x04000FFF RID: 4095
		public float ScrollSpeed = -0.01f;

		// Token: 0x04001000 RID: 4096
		public float ScrollEnd;
	}
}
