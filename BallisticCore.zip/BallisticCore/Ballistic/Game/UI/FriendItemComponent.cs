﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Services;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C5 RID: 453
	public class FriendItemComponent : PoolableComponent
	{
		// Token: 0x0600096B RID: 2411 RVA: 0x0000878F File Offset: 0x0000698F
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.FriendButton.onClick.AddListener(new UnityAction(this.OnFriendClicked));
		}

		// Token: 0x0600096C RID: 2412 RVA: 0x000087B8 File Offset: 0x000069B8
		private void OnFriendClicked()
		{
			if (this.OnClicked != null)
			{
				this.OnClicked(this._frienditem, this._hostItem);
			}
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x000087DC File Offset: 0x000069DC
		internal void SetInfo(CSteamID friend, HostItem hostItem)
		{
			this._frienditem = friend;
			this._hostItem = hostItem;
			this.FriendName.text = SteamFriends.GetFriendPersonaName(friend);
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(friend, new Action<ulong, Texture2D>(this.OnFriendAvatarLoaded), true);
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x00008815 File Offset: 0x00006A15
		private void OnFriendAvatarLoaded(ulong steamId, Texture2D avatar)
		{
			this.FriendAvatar.texture = avatar;
		}

		// Token: 0x04000C75 RID: 3189
		public Text FriendName;

		// Token: 0x04000C76 RID: 3190
		public RawImage FriendAvatar;

		// Token: 0x04000C77 RID: 3191
		public Button FriendButton;

		// Token: 0x04000C78 RID: 3192
		private CSteamID _frienditem;

		// Token: 0x04000C79 RID: 3193
		private HostItem _hostItem;

		// Token: 0x04000C7A RID: 3194
		internal Action<CSteamID, HostItem> OnClicked;
	}
}
