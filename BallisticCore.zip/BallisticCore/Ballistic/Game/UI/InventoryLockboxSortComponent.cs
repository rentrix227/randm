﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001DD RID: 477
	public class InventoryLockboxSortComponent : PoolableComponent
	{
		// Token: 0x060009BA RID: 2490 RVA: 0x00008C1F File Offset: 0x00006E1F
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.LockboxList.Template.Dispose();
		}

		// Token: 0x060009BB RID: 2491 RVA: 0x0003A558 File Offset: 0x00038758
		internal void SetData(string key, List<LockboxData> lockboxArray, List<ulong> lockboxNotifications)
		{
			InventoryLockboxSortComponent.<SetData>c__AnonStorey0 <SetData>c__AnonStorey = new InventoryLockboxSortComponent.<SetData>c__AnonStorey0();
			<SetData>c__AnonStorey.lockboxArray = lockboxArray;
			this.LockboxSortNameText.text = key.ToUpper();
			this.LockboxSortAmountText.text = "| " + <SetData>c__AnonStorey.lockboxArray.Count;
			this.LockboxList.SetActiveCount(<SetData>c__AnonStorey.lockboxArray.Count((LockboxData t) => t.Visible));
			int num = 0;
			int i;
			for (i = 0; i < <SetData>c__AnonStorey.lockboxArray.Count; i++)
			{
				if (<SetData>c__AnonStorey.lockboxArray[i].Visible)
				{
					this.LockboxList[num].SetData(<SetData>c__AnonStorey.lockboxArray[i], lockboxNotifications.Exists((ulong t) => t == <SetData>c__AnonStorey.lockboxArray[i].SteamItem.InstanceId));
					this.LockboxList[num].OnLockboxClick = new Action<LockboxData>(this.OnLockboxClicked);
					num++;
				}
			}
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x00008C3C File Offset: 0x00006E3C
		private void OnLockboxClicked(LockboxData lockbox)
		{
			if (this.OnLockboxClick != null)
			{
				this.OnLockboxClick(lockbox);
			}
		}

		// Token: 0x04000D05 RID: 3333
		public Text LockboxSortNameText;

		// Token: 0x04000D06 RID: 3334
		public Text LockboxSortAmountText;

		// Token: 0x04000D07 RID: 3335
		public InventoryLockboxSortComponent.InventoryLockboxList LockboxList;

		// Token: 0x04000D08 RID: 3336
		internal Action<LockboxData> OnLockboxClick;

		// Token: 0x020001DE RID: 478
		[Serializable]
		public class InventoryLockboxList : PoolableList<InventoryLockboxComponent>
		{
		}
	}
}
