﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002FD RID: 765
	public class SeasonInfoAccessoriesView : BaseView<SeasonController>
	{
		// Token: 0x06000FE3 RID: 4067 RVA: 0x0005D498 File Offset: 0x0005B698
		public void SetAccessories(List<Accessory> accessories)
		{
			this.AccessoriesList.SetActiveCount(accessories.Count);
			for (int i = 0; i < accessories.Count; i++)
			{
				this.AccessoriesList[i].SetData(accessories[i]);
				this.AccessoriesList[i].OnAccessoryPreview = new Action<Accessory>(this.OnAccessoryPreview);
			}
		}

		// Token: 0x06000FE4 RID: 4068 RVA: 0x0005D504 File Offset: 0x0005B704
		public void OnAccessoryPreview(Accessory accessory)
		{
			if (this.AccessoryName != null)
			{
				this.AccessoryName.text = ServiceProvider.GetService<LocalizationService>().GetAccessoryName(accessory.ItemName);
			}
			int num;
			int num2;
			List<RequirementConfig> requirementList = InventoryController.GetRequirementList(accessory, out num, out num2);
			num = requirementList.FindAll((RequirementConfig t) => t.Type == ERequirementType.COLLECTION).Count + ((!requirementList.Exists((RequirementConfig t) => t.Type == ERequirementType.SPECIFIC)) ? 0 : 1);
			AccessoryRequirementComponent accessoryRequirementComponent = null;
			string text = string.Empty;
			this.AccessoryRequirementList.SetActiveCount(num);
			int i = 0;
			int num3 = 0;
			while (i < requirementList.Count)
			{
				if (requirementList[i].Type == ERequirementType.COLLECTION)
				{
					this.AccessoryRequirementList[num3].SetData(string.Format(ServiceProvider.GetService<LocalizationService>().Get("requirement_any_skin", ELocalizedTextCase.NONE), requirementList[i].CollectionAmountTotal, ServiceProvider.GetService<LocalizationService>().GetWeaponSkinName(requirementList[i].CollectionWeaponSkinName, ELocalizedTextCase.NONE)));
					num3++;
				}
				else if (requirementList[i].Type == ERequirementType.SPECIFIC)
				{
					text = text + ServiceProvider.GetService<LocalizationService>().GetWeaponName(requirementList[i].SpecificWeapon.ItemName, requirementList[i].SpecificSkin.WeaponSkinName, ELocalizedTextCase.CAPITALIZE) + " ";
					if (accessoryRequirementComponent == null)
					{
						accessoryRequirementComponent = this.AccessoryRequirementList[num3];
						num3++;
					}
				}
				i++;
			}
			if (accessoryRequirementComponent != null)
			{
				accessoryRequirementComponent.SetData(string.Format(ServiceProvider.GetService<LocalizationService>().Get("requirement_specific_skin", ELocalizedTextCase.NONE), text));
			}
		}

		// Token: 0x04001511 RID: 5393
		public SeasonInfoAccessoriesView.AccessoryComponentList AccessoriesList;

		// Token: 0x04001512 RID: 5394
		[Header("Info")]
		public Text AccessoryName;

		// Token: 0x04001513 RID: 5395
		public SeasonInfoAccessoriesView.RequirementComponentList AccessoryRequirementList;

		// Token: 0x020002FE RID: 766
		[Serializable]
		public class AccessoryComponentList : PoolableList<AccessoryComponent>
		{
		}

		// Token: 0x020002FF RID: 767
		[Serializable]
		public class RequirementComponentList : PoolableList<AccessoryRequirementComponent>
		{
		}
	}
}
