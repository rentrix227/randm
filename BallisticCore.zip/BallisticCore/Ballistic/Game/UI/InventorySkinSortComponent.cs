﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001E3 RID: 483
	public class InventorySkinSortComponent : PoolableComponent
	{
		// Token: 0x060009C9 RID: 2505 RVA: 0x00008CC8 File Offset: 0x00006EC8
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.WeaponSkinList.Template.Dispose();
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x00008CE5 File Offset: 0x00006EE5
		internal void ShowLegendaryMistery()
		{
			this.WeaponSkinList.SetActiveCount(1);
			this.WeaponSkinList[0].SetLegendary(true);
			this.WeaponSkinList[0].OnWeaponSkinClick = new Action<WeaponSkinData>(this.OnWeaponSkinClicked);
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x00008D22 File Offset: 0x00006F22
		internal void SetData(List<WeaponSkinData> weaponSkinArray, bool firstSelected = false)
		{
			this.SetData(null, weaponSkinArray, new List<ulong>(), firstSelected);
		}

		// Token: 0x060009CC RID: 2508 RVA: 0x0003A758 File Offset: 0x00038958
		internal void SetData(string key, List<WeaponSkinData> weaponSkinArray, List<ulong> weaponNotifications, bool firstSelected = false)
		{
			InventorySkinSortComponent.<SetData>c__AnonStorey0 <SetData>c__AnonStorey = new InventorySkinSortComponent.<SetData>c__AnonStorey0();
			if (this.SkinSortNameText != null)
			{
				this.SkinSortNameText.text = key.ToUpper();
			}
			if (this.SkinSortAmountText != null)
			{
				this.SkinSortAmountText.text = "| " + weaponSkinArray.Count;
			}
			<SetData>c__AnonStorey.visibleSkins = weaponSkinArray.Where((WeaponSkinData t) => t.Visible).ToList<WeaponSkinData>();
			this.WeaponSkinList.SetActiveCount(<SetData>c__AnonStorey.visibleSkins.Count);
			int i;
			for (i = 0; i < <SetData>c__AnonStorey.visibleSkins.Count; i++)
			{
				bool flag = i == 0 && firstSelected;
				bool flag2 = weaponNotifications.Exists((ulong t) => t == <SetData>c__AnonStorey.visibleSkins[i].SteamItem.InstanceId);
				this.WeaponSkinList[i].SetLegendary(false);
				this.WeaponSkinList[i].SetData(<SetData>c__AnonStorey.visibleSkins[i], flag2, flag);
				this.WeaponSkinList[i].OnWeaponSkinClick = new Action<WeaponSkinData>(this.OnWeaponSkinClicked);
				this.WeaponSkinList[i].OnWeaponSkinPreview = new Action<WeaponSkinData>(this.OnWeaponSkinPreviewing);
			}
		}

		// Token: 0x060009CD RID: 2509 RVA: 0x00008D32 File Offset: 0x00006F32
		private void OnWeaponSkinClicked(WeaponSkinData weaponSkin)
		{
			if (this.OnWeaponSkinClick != null)
			{
				this.OnWeaponSkinClick(weaponSkin);
			}
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x00008D4B File Offset: 0x00006F4B
		private void OnWeaponSkinPreviewing(WeaponSkinData weaponSkin)
		{
			if (this.OnWeaponSkinPreview != null)
			{
				this.OnWeaponSkinPreview(weaponSkin);
			}
		}

		// Token: 0x04000D15 RID: 3349
		public Text SkinSortNameText;

		// Token: 0x04000D16 RID: 3350
		public Text SkinSortAmountText;

		// Token: 0x04000D17 RID: 3351
		public InventorySkinSortComponent.InventorySkinList WeaponSkinList;

		// Token: 0x04000D18 RID: 3352
		internal Action<WeaponSkinData> OnWeaponSkinPreview;

		// Token: 0x04000D19 RID: 3353
		internal Action<WeaponSkinData> OnWeaponSkinClick;

		// Token: 0x020001E4 RID: 484
		[Serializable]
		public class InventorySkinList : PoolableList<WeaponSkinComponent>
		{
		}
	}
}
