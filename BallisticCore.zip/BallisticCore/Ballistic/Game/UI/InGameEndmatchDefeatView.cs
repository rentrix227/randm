﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002A5 RID: 677
	public class InGameEndmatchDefeatView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000E65 RID: 3685 RVA: 0x00055D3C File Offset: 0x00053F3C
		internal void SetData(EGameMode mode, int yourPosition)
		{
			bool flag = mode != EGameMode.FreeForAll && mode != EGameMode.Juggernaut;
			if (flag)
			{
				this.MatchStatusText.text = ServiceProvider.GetService<LocalizationService>().Get("team_endgame_status_0", ELocalizedTextCase.UPPER_CASE);
				this.FfaPositionSuffix.text = string.Empty;
			}
			else
			{
				this.MatchStatusText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("your_position_x", ELocalizedTextCase.UPPER_CASE), "<color=#FFC4C4FF>" + yourPosition + "</color>");
				this.FfaPositionSuffix.text = ServiceProvider.GetService<LocalizationService>().Get("ordinal_suffix_" + yourPosition, ELocalizedTextCase.UPPER_CASE);
			}
		}

		// Token: 0x040012A9 RID: 4777
		public Text MatchStatusText;

		// Token: 0x040012AA RID: 4778
		public Text FfaPositionSuffix;
	}
}
