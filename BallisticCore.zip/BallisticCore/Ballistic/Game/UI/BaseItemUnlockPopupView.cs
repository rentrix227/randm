﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000262 RID: 610
	public abstract class BaseItemUnlockPopupView<T> : BaseView<T> where T : BaseController
	{
		// Token: 0x17000117 RID: 279
		// (get) Token: 0x06000D28 RID: 3368
		protected abstract string WeaponTitleLocalizationKey { get; }

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000D29 RID: 3369
		protected abstract string SkillTitleLocalizationKey { get; }

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000D2A RID: 3370
		protected abstract string LoadoutTitleLocalizationKey { get; }

		// Token: 0x06000D2B RID: 3371 RVA: 0x0004E3DC File Offset: 0x0004C5DC
		internal virtual void UpdateInfo(EUnlockType unlockType, EHeroClass heroClass, string itemName, int loadoutNumber)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.WeaponGroup.SetActive(unlockType == EUnlockType.WEAPON);
			this.SkillGroup.SetActive(unlockType == EUnlockType.SKILL);
			this.LoadoutGroup.SetActive(unlockType == EUnlockType.LOADOUT);
			if (unlockType != EUnlockType.WEAPON)
			{
				if (unlockType != EUnlockType.SKILL)
				{
					if (unlockType == EUnlockType.LOADOUT)
					{
						this.LoadoutTitle.text = string.Format(service.Get(this.LoadoutTitleLocalizationKey, ELocalizedTextCase.UPPER_CASE), service.GetClassName(heroClass, ELocalizedTextCase.UPPER_CASE));
						this.LoadoutIconNumber.text = loadoutNumber.ToString();
						this.LoadoutNumberDescription.text = string.Format("{0} / 3", loadoutNumber);
					}
				}
				else
				{
					this.SkillTitle.text = string.Format(service.Get(this.SkillTitleLocalizationKey, ELocalizedTextCase.UPPER_CASE), service.GetClassName(heroClass, ELocalizedTextCase.UPPER_CASE));
					TextureHelper.LoadImageAsync(TextureHelper.GetSkillIconPath(itemName), this.SkillIcon, false, EImageSource.RESOURCES);
					this.SkillName.text = service.GetSkillName(itemName, ELocalizedTextCase.UPPER_CASE);
					this.SkillDescription.text = service.GetSkillDescription(itemName, ELocalizedTextCase.NONE);
				}
			}
			else
			{
				WeaponData weapon = ServiceProvider.GetService<WeaponService>().GetWeapon(itemName);
				this.WeaponTitle.text = string.Format(service.Get(this.WeaponTitleLocalizationKey, ELocalizedTextCase.UPPER_CASE), service.GetClassName(heroClass, ELocalizedTextCase.UPPER_CASE));
				TextureHelper.LoadImageAsync(TextureHelper.GetWeaponIconPath(weapon.GameItem.ItemModel, EImageSize.LARGE, "default"), this.WeaponIcon, true, EImageSource.METADATA);
				this.WeaponName.text = service.GetWeaponName(weapon.GameItem.ItemName, ELocalizedTextCase.UPPER_CASE);
				this.WeaponCategory.text = service.GetWeaponCategory(weapon.GameItem.Category, ELocalizedTextCase.UPPER_CASE);
				if (this.WeaponStats != null)
				{
					this.WeaponStats.SetData(weapon, weapon);
				}
				if (this.WeaponType != null)
				{
					EWeaponType weaponType = weapon.GameItem.WeaponData.WeaponType;
					if (weaponType != EWeaponType.PrimaryWeapon)
					{
						if (weaponType != EWeaponType.SecondaryWeapon)
						{
							this.WeaponType.gameObject.SetActive(false);
						}
						else
						{
							this.WeaponType.gameObject.SetActive(true);
							this.WeaponType.text = service.Get("weapontype_secondary", ELocalizedTextCase.NONE);
						}
					}
					else
					{
						this.WeaponType.gameObject.SetActive(true);
						this.WeaponType.text = service.Get("weapontype_primary", ELocalizedTextCase.NONE);
					}
				}
			}
		}

		// Token: 0x04000FE8 RID: 4072
		public GameObject WeaponGroup;

		// Token: 0x04000FE9 RID: 4073
		public Text WeaponTitle;

		// Token: 0x04000FEA RID: 4074
		public Text WeaponType;

		// Token: 0x04000FEB RID: 4075
		public RawImage WeaponIcon;

		// Token: 0x04000FEC RID: 4076
		public Text WeaponName;

		// Token: 0x04000FED RID: 4077
		public Text WeaponCategory;

		// Token: 0x04000FEE RID: 4078
		public AvaliableWeaponInfoComponent WeaponStats;

		// Token: 0x04000FEF RID: 4079
		public GameObject SkillGroup;

		// Token: 0x04000FF0 RID: 4080
		public Text SkillTitle;

		// Token: 0x04000FF1 RID: 4081
		public Image SkillIcon;

		// Token: 0x04000FF2 RID: 4082
		public Text SkillName;

		// Token: 0x04000FF3 RID: 4083
		public Text SkillDescription;

		// Token: 0x04000FF4 RID: 4084
		public GameObject LoadoutGroup;

		// Token: 0x04000FF5 RID: 4085
		public Text LoadoutTitle;

		// Token: 0x04000FF6 RID: 4086
		public Text LoadoutIconNumber;

		// Token: 0x04000FF7 RID: 4087
		public Text LoadoutNumberDescription;
	}
}
