﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Game.Weapon;
using Aquiris.Ballistic.Network.Transport.Gameplay.Capture.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Ballistic.Network.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200021D RID: 541
	public class GameplayVoiceController : BaseController
	{
		// Token: 0x06000B13 RID: 2835 RVA: 0x00041F68 File Offset: 0x00040168
		public GameplayVoiceController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._voiceRequests = new Dictionary<VoicePool, HighSpeedArray<VoiceEnum>>();
			this._damages = new HighSpeedArray<GameplayVoiceController.DamageReceived>(100);
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._eventProxy.EUpdate.AddListener(new Action(this.Update));
			this._eventProxy.ELateUpdate.AddListener(new Action(this.LateUpdate));
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnCapturedPoint.AddListener(new Action<CapturedPointEvent>(this.OnCapturePoint));
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnTimeRemaining.AddListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._transmissionService = ServiceProvider.GetService<TransmissionService>();
			this._transmissionService.OnShoot.AddListener(new Action<OnShootData>(this.OnShoot));
			this._transmissionService.OnProjectileEnterPlayerRange.AddListener(new Action<OnProjectileEnterPlayerRangeData>(this.OnProjectileEnterPlayerRange));
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._localCharacterService.OnAimingUpdate += this.OnAimingUpdate;
			this._remoteCharacterService = ServiceProvider.GetService<RemoteCharactersService>();
			this._voiceView = null;
			this._hasTriggeredEndMatch = false;
			this._hasFirstSpawn = false;
			this._lastTargetingEnemyId = -1L;
			this._lastVoicePoolExecution = -1f;
			this._lastInvokedSound = -1f;
		}

		// Token: 0x06000B14 RID: 2836 RVA: 0x00042128 File Offset: 0x00040328
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._eventProxy.EUpdate.RemoveListener(new Action(this.Update));
			this._eventProxy.ELateUpdate.RemoveListener(new Action(this.LateUpdate));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnCapturedPoint.RemoveListener(new Action<CapturedPointEvent>(this.OnCapturePoint));
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnTimeRemaining.RemoveListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._transmissionService.OnShoot.RemoveListener(new Action<OnShootData>(this.OnShoot));
			this._transmissionService.OnProjectileEnterPlayerRange.RemoveListener(new Action<OnProjectileEnterPlayerRangeData>(this.OnProjectileEnterPlayerRange));
			this._localCharacterService.OnAimingUpdate -= this.OnAimingUpdate;
		}

		// Token: 0x06000B15 RID: 2837 RVA: 0x0004225C File Offset: 0x0004045C
		private void OnAimingUpdate(AimingUpdateStruct evt)
		{
			if (evt.Targeting == WeaponTargeting.ENEMY && evt.TargetingEnemyId != this._lastTargetingEnemyId && Time.time - this._lastTargetingTriggered > 5f)
			{
				this._lastTargetingEnemyId = evt.TargetingEnemyId;
				this._lastTargetingTriggered = Time.time;
				this.InvokeSound(VoiceEnum.ENEMY_SPOTTED, false);
			}
		}

		// Token: 0x06000B16 RID: 2838 RVA: 0x000422C4 File Offset: 0x000404C4
		private void OnTimeRemaining(TimeRemainingEvent evt)
		{
			if (this._hasTriggeredEndMatch)
			{
				return;
			}
			if (this._voiceView == null)
			{
				return;
			}
			if (!this._voiceView.isActiveAndEnabled)
			{
				return;
			}
			if (evt.RemainingTime <= 60.0 && this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType == EGameState.PLAYING)
			{
				this._hasTriggeredEndMatch = true;
				if (ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam == EWinningTeam.MINE)
				{
					this.InvokeSound(VoiceEnum.WINNING_MATCH, false);
				}
				else
				{
					this.InvokeSound(VoiceEnum.LOSING_MATCH, false);
				}
			}
		}

		// Token: 0x06000B17 RID: 2839 RVA: 0x00009B75 File Offset: 0x00007D75
		private void OnProjectileEnterPlayerRange(OnProjectileEnterPlayerRangeData evt)
		{
			if (evt.LauncherTeam != UserProfile.LocalGameClient.team && !evt.LauncherIsLocalCharacter)
			{
				this.InvokePooledSound(VoiceEnum.GRENADE_WARNING, VoicePool.KILL_POOL);
			}
		}

		// Token: 0x06000B18 RID: 2840 RVA: 0x0004236C File Offset: 0x0004056C
		private void OnShoot(OnShootData evt)
		{
			if (evt.IsFirstPerson && evt.WeaponName != null && string.Equals(evt.WeaponName, "m67"))
			{
				this._shouldInvokeSoundSpawn = !this._shouldInvokeSoundSpawn;
				if (this._shouldInvokeSoundSpawn)
				{
					this.InvokePooledSound(VoiceEnum.THROW_GRENADE, VoicePool.KILL_POOL);
				}
			}
		}

		// Token: 0x06000B19 RID: 2841 RVA: 0x000423D0 File Offset: 0x000405D0
		private void OnSpawn(SpawnEvent evt)
		{
			if (UserProfile.IsMe(evt.User))
			{
				this.ClearAllPooledSounds();
				this._shouldInvokeSoundThrow = !this._shouldInvokeSoundThrow;
				if (!this._hasFirstSpawn)
				{
					this._eventProxy.StartCoroutine(this.InvokeSoundWithDelay(VoiceEnum.START_MATCH, 1f));
				}
				else if (this._shouldInvokeSoundThrow)
				{
					this._eventProxy.StartCoroutine(this.InvokeSoundWithDelay(VoiceEnum.SPAWNING, 1f));
				}
			}
		}

		// Token: 0x06000B1A RID: 2842 RVA: 0x00042458 File Offset: 0x00040658
		private void OnUserHit(HitEvent evt)
		{
			if (!evt.Sender.isMe && evt.VictimGameClient.isMe)
			{
				this._damages.Add(new GameplayVoiceController.DamageReceived
				{
					damage = Mathf.RoundToInt(evt.Damage),
					timestamp = Time.time
				});
			}
		}

		// Token: 0x06000B1B RID: 2843 RVA: 0x000424B8 File Offset: 0x000406B8
		private void OnDie(DieEvent evt)
		{
			if (evt.Killer.isMe && !evt.Sender.isMe)
			{
				switch (LoadoutUtil.GetHeroClass(evt.Killer.loadoutInfo))
				{
				case EHeroClass.BERSERKER:
				{
					EHeroClass heroClass = LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo);
					if (heroClass != EHeroClass.MARKSMAN)
					{
						if (heroClass != EHeroClass.SHADOW)
						{
							if (heroClass == EHeroClass.VANGUARD)
							{
								this.InvokePooledSound(VoiceEnum.KILL_VANGUARD, VoicePool.KILL_POOL);
							}
						}
						else
						{
							this.InvokePooledSound(VoiceEnum.KILL_SHADOW, VoicePool.KILL_POOL);
						}
					}
					else
					{
						this.InvokePooledSound(VoiceEnum.KILL_MARKSMAN, VoicePool.KILL_POOL);
					}
					break;
				}
				case EHeroClass.GRENADIER:
				{
					EHeroClass heroClass2 = LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo);
					if (heroClass2 != EHeroClass.TANK)
					{
						if (heroClass2 != EHeroClass.WRAITH)
						{
							if (heroClass2 == EHeroClass.SHADOW)
							{
								this.InvokePooledSound(VoiceEnum.KILL_SHADOW, VoicePool.KILL_POOL);
							}
						}
						else
						{
							this.InvokePooledSound(VoiceEnum.KILL_WRAITH, VoicePool.KILL_POOL);
						}
					}
					else
					{
						this.InvokePooledSound(VoiceEnum.KILL_TANK, VoicePool.KILL_POOL);
					}
					break;
				}
				case EHeroClass.MARKSMAN:
				{
					EHeroClass heroClass3 = LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo);
					if (heroClass3 != EHeroClass.TANK)
					{
						if (heroClass3 != EHeroClass.BERSERKER)
						{
							if (heroClass3 == EHeroClass.GRENADIER)
							{
								this.InvokePooledSound(VoiceEnum.KILL_GRENADIER, VoicePool.KILL_POOL);
							}
						}
						else
						{
							this.InvokePooledSound(VoiceEnum.KILL_BERSERKER, VoicePool.KILL_POOL);
						}
					}
					else
					{
						this.InvokePooledSound(VoiceEnum.KILL_TANK, VoicePool.KILL_POOL);
					}
					break;
				}
				case EHeroClass.SHADOW:
				{
					EHeroClass heroClass4 = LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo);
					if (heroClass4 != EHeroClass.WRAITH)
					{
						if (heroClass4 != EHeroClass.MARKSMAN)
						{
							if (heroClass4 == EHeroClass.BERSERKER)
							{
								this.InvokePooledSound(VoiceEnum.KILL_BERSERKER, VoicePool.KILL_POOL);
							}
						}
						else
						{
							this.InvokePooledSound(VoiceEnum.KILL_MARKSMAN, VoicePool.KILL_POOL);
						}
					}
					else
					{
						this.InvokePooledSound(VoiceEnum.KILL_WRAITH, VoicePool.KILL_POOL);
					}
					break;
				}
				case EHeroClass.TANK:
				{
					EHeroClass heroClass5 = LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo);
					if (heroClass5 != EHeroClass.MARKSMAN)
					{
						if (heroClass5 != EHeroClass.VANGUARD)
						{
							if (heroClass5 == EHeroClass.GRENADIER)
							{
								this.InvokePooledSound(VoiceEnum.KILL_GRENADIER, VoicePool.KILL_POOL);
							}
						}
						else
						{
							this.InvokePooledSound(VoiceEnum.KILL_VANGUARD, VoicePool.KILL_POOL);
						}
					}
					else
					{
						this.InvokePooledSound(VoiceEnum.KILL_MARKSMAN, VoicePool.KILL_POOL);
					}
					break;
				}
				case EHeroClass.VANGUARD:
				{
					EHeroClass heroClass6 = LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo);
					if (heroClass6 != EHeroClass.TANK)
					{
						if (heroClass6 != EHeroClass.BERSERKER)
						{
							if (heroClass6 == EHeroClass.WRAITH)
							{
								this.InvokePooledSound(VoiceEnum.KILL_WRAITH, VoicePool.KILL_POOL);
							}
						}
						else
						{
							this.InvokePooledSound(VoiceEnum.KILL_BERSERKER, VoicePool.KILL_POOL);
						}
					}
					else
					{
						this.InvokePooledSound(VoiceEnum.KILL_TANK, VoicePool.KILL_POOL);
					}
					break;
				}
				case EHeroClass.WRAITH:
				{
					EHeroClass heroClass7 = LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo);
					if (heroClass7 != EHeroClass.SHADOW)
					{
						if (heroClass7 != EHeroClass.GRENADIER)
						{
							if (heroClass7 == EHeroClass.VANGUARD)
							{
								this.InvokePooledSound(VoiceEnum.KILL_VANGUARD, VoicePool.KILL_POOL);
							}
						}
						else
						{
							this.InvokePooledSound(VoiceEnum.KILL_GRENADIER, VoicePool.KILL_POOL);
						}
					}
					else
					{
						this.InvokePooledSound(VoiceEnum.KILL_SHADOW, VoicePool.KILL_POOL);
					}
					break;
				}
				}
				if (evt.KillerMultiKill == 2)
				{
					this.InvokePooledSound(VoiceEnum.KILLSTREAK_2, VoicePool.KILL_POOL);
				}
				else if (evt.KillerMultiKill == 3)
				{
					this.InvokePooledSound(VoiceEnum.KILLSTREAK_3, VoicePool.KILL_POOL);
				}
				else if (evt.KillerMultiKill == 4)
				{
					this.InvokePooledSound(VoiceEnum.KILLSTREAK_4, VoicePool.KILL_POOL);
				}
				if (evt.Headshot == HeadshotType.HEADSHOT || evt.Headshot == HeadshotType.MARKSMAN_HEADSHOT)
				{
					this.InvokePooledSound(VoiceEnum.HEADSHOT, VoicePool.KILL_POOL);
				}
				if (evt.IsBackstab)
				{
					this.InvokePooledSound(VoiceEnum.BACKSTAB, VoicePool.KILL_POOL);
				}
				int num = this._damages.Sum(new Func<GameplayVoiceController.DamageReceived, int>(this.DamageReceivedOver5Seconds));
				if (num > Mathf.CeilToInt(UserProfile.LocalGameClient.maxHealth * 100f / 2f))
				{
					this.InvokePooledSound(VoiceEnum.CLOSE_CALL, VoicePool.KILL_POOL);
				}
				this._damages.RemoveAll(new Func<GameplayVoiceController.DamageReceived, bool>(this.DamageReceivedOver5ToRemove));
				bool flag = true;
				for (int i = 0; i < this._remoteCharacterService.ActivePlayers.Length; i++)
				{
					if (this._remoteCharacterService.ActivePlayers[i].Team != evt.Killer.team && this._remoteCharacterService.ActivePlayers[i].PlayerId != evt.SenderId && this._remoteCharacterService.ActivePlayers[i].PlayerId != evt.KillerId && Vector3.Distance(this._remoteCharacterService.ActivePlayers[i].WorldPosition, evt.VictimPosition) <= 20f)
					{
						flag = false;
						break;
					}
				}
				if (flag)
				{
					this._eventProxy.StartCoroutine(this.InvokeSoundWithDelay(VoiceEnum.AREA_CLEAR, 3.5f));
				}
				if (evt.OffensiveKill || evt.DefenseKill)
				{
					this.InvokePooledSound(VoiceEnum.STANDING_KOTH, VoicePool.KILL_POOL);
				}
				this.InvokePooledSound(VoiceEnum.KILL_REGULAR, VoicePool.KILL_POOL);
			}
			if (evt.Sender.isMe)
			{
				this.InvokePooledSound(VoiceEnum.DYING_SCREAM, VoicePool.KILL_POOL);
				this._lastTargetingEnemyId = -1L;
			}
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x00009BA5 File Offset: 0x00007DA5
		private void OnCapturePoint(CapturedPointEvent evt)
		{
			if (evt.CaptureScoreChange.ContainsKey(UserProfile.LocalGameClient.gameClientId))
			{
				this.InvokeSound(VoiceEnum.CAPTURE_POINT, false);
			}
		}

		// Token: 0x06000B1D RID: 2845 RVA: 0x00042A10 File Offset: 0x00040C10
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayVoiceView gameplayVoiceView = view as GameplayVoiceView;
			if (gameplayVoiceView != null)
			{
				this._voiceView = gameplayVoiceView;
			}
		}

		// Token: 0x06000B1E RID: 2846 RVA: 0x00042A4C File Offset: 0x00040C4C
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayVoiceView gameplayVoiceView = view as GameplayVoiceView;
			if (gameplayVoiceView != null)
			{
				gameplayVoiceView.Hide(false);
			}
		}

		// Token: 0x06000B1F RID: 2847 RVA: 0x00042A88 File Offset: 0x00040C88
		public void Update()
		{
			this._damages.RemoveAll(new Func<GameplayVoiceController.DamageReceived, bool>(this.DamageReceivedOver5ToRemove));
			if (this._voiceView == null)
			{
				return;
			}
			if (!this._voiceView.isActiveAndEnabled)
			{
				return;
			}
			if (this._optionControlService.GetKeyDown(KeyType.VOICE_MOVE))
			{
				this.InvokeSound(VoiceEnum.MOVE, true);
			}
			else if (this._optionControlService.GetKeyDown(KeyType.VOICE_FOLLOW))
			{
				this.InvokeSound(VoiceEnum.FOLLOWME, true);
			}
			else if (this._optionControlService.GetKeyDown(KeyType.VOICE_LAUGH))
			{
				this.InvokeSound(VoiceEnum.LAUGH, true);
			}
			else if (this._optionControlService.GetKeyDown(KeyType.VOICE_HELP))
			{
				this.InvokeSound(VoiceEnum.COVER, true);
			}
			else if (this._optionControlService.GetKeyDown(KeyType.VOICE_DEFEND))
			{
				this.InvokeSound(VoiceEnum.DEFEND, true);
			}
			else if (this._optionControlService.GetKeyDown(KeyType.VOICE_TAUNT))
			{
				this.InvokeSound(VoiceEnum.TAUNT, true);
			}
			if (this._optionControlService.GetKey(KeyType.VOICE_WHEEL) && !this._voiceView.IsVisible())
			{
				this._voiceView.Show(KeyType.NONE);
			}
			else if (!this._optionControlService.GetKey(KeyType.VOICE_WHEEL) && this._voiceView.IsVisible())
			{
				this._voiceView.Hide(true);
			}
			else if (this._voiceView.IsVisible())
			{
				this._voiceView.UpdatePointer(new Vector2(this._optionControlService.GetAxisL(AxisType.MOUSE_X, false) * this._optionControlService.Container.RawSensitivity, this._optionControlService.GetAxisL(AxisType.MOUSE_Y, false) * this._optionControlService.Container.RawSensitivity));
			}
		}

		// Token: 0x06000B20 RID: 2848 RVA: 0x00042C48 File Offset: 0x00040E48
		private void LateUpdate()
		{
			if (this._voiceView == null)
			{
				return;
			}
			if (!this._voiceView.isActiveAndEnabled)
			{
				return;
			}
			if (Time.time - this._lastVoicePoolExecution > 0.15f)
			{
				foreach (VoicePool voicePool in EnumUtil.GetValues<VoicePool>())
				{
					if (!this._voiceRequests.ContainsKey(voicePool))
					{
						this._voiceRequests.Add(voicePool, new HighSpeedArray<VoiceEnum>(20));
					}
					if (this._voiceRequests[voicePool].Length > 0)
					{
						VoiceEnum voiceEnum = this._voiceRequests[voicePool][0];
						for (int i = 1; i < this._voiceRequests[voicePool].Length; i++)
						{
							if (this._voiceRequests[voicePool][i] > voiceEnum)
							{
								voiceEnum = this._voiceRequests[voicePool][i];
							}
						}
						this.InvokeSound(voiceEnum, false);
						this._voiceRequests[voicePool].Clear();
					}
				}
				this._lastVoicePoolExecution = Time.time;
			}
		}

		// Token: 0x06000B21 RID: 2849 RVA: 0x00042D94 File Offset: 0x00040F94
		private void ClearAllPooledSounds()
		{
			foreach (KeyValuePair<VoicePool, HighSpeedArray<VoiceEnum>> keyValuePair in this._voiceRequests)
			{
				keyValuePair.Value.Clear();
			}
		}

		// Token: 0x06000B22 RID: 2850 RVA: 0x00009BCD File Offset: 0x00007DCD
		internal void InvokePooledSound(VoiceEnum voice, VoicePool pool)
		{
			if (!this._voiceRequests.ContainsKey(pool))
			{
				this._voiceRequests.Add(pool, new HighSpeedArray<VoiceEnum>(20));
			}
			this._voiceRequests[pool].Add(voice);
		}

		// Token: 0x06000B23 RID: 2851 RVA: 0x00042DF8 File Offset: 0x00040FF8
		internal void InvokeSound(VoiceEnum voice, bool ignoreShutdown)
		{
			if (voice != VoiceEnum.DYING_SCREAM && this._localCharacterService.IsDead)
			{
				return;
			}
			if (voice != VoiceEnum.DYING_SCREAM && Time.time - this._lastInvokedSound < 1.5f)
			{
				return;
			}
			this._lastInvokedSound = Time.time;
			VoiceRequest voiceRequest = new VoiceRequest
			{
				User = UserProfile.LocalGameClient.gameClientId,
				Voice = (short)voice
			};
			this._networkGameService.RaiseNetworkEvent(voiceRequest);
		}

		// Token: 0x06000B24 RID: 2852 RVA: 0x00042E7C File Offset: 0x0004107C
		private IEnumerator InvokeSoundWithDelay(VoiceEnum voice, float delay)
		{
			yield return new WaitForSeconds(delay);
			if (!this._localCharacterService.IsDead)
			{
				this.InvokeSound(voice, false);
			}
			yield break;
		}

		// Token: 0x06000B25 RID: 2853 RVA: 0x00009C05 File Offset: 0x00007E05
		private int DamageReceivedOver5Seconds(GameplayVoiceController.DamageReceived rec)
		{
			if (Time.time - rec.timestamp < 5f)
			{
				return rec.damage;
			}
			return 0;
		}

		// Token: 0x06000B26 RID: 2854 RVA: 0x00009C27 File Offset: 0x00007E27
		private bool DamageReceivedOver5ToRemove(GameplayVoiceController.DamageReceived rec)
		{
			return Time.time - rec.timestamp > 5f;
		}

		// Token: 0x04000E90 RID: 3728
		private const float _secondsRemainingToPlayEndingMatchMusic = 60f;

		// Token: 0x04000E91 RID: 3729
		private const float _secondsDelayBetweenEnemySpotted = 5f;

		// Token: 0x04000E92 RID: 3730
		private const float _poolingExecutionDelay = 0.15f;

		// Token: 0x04000E93 RID: 3731
		private const float _invokeSoundShutdown = 1.5f;

		// Token: 0x04000E94 RID: 3732
		private const float _areaClearedDistance = 20f;

		// Token: 0x04000E95 RID: 3733
		private const int _voicePoolLimit = 20;

		// Token: 0x04000E96 RID: 3734
		private readonly OptionControlService _optionControlService;

		// Token: 0x04000E97 RID: 3735
		private readonly EventProxy _eventProxy;

		// Token: 0x04000E98 RID: 3736
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E99 RID: 3737
		private readonly TransmissionService _transmissionService;

		// Token: 0x04000E9A RID: 3738
		private readonly LocalCharacterService _localCharacterService;

		// Token: 0x04000E9B RID: 3739
		private readonly RemoteCharactersService _remoteCharacterService;

		// Token: 0x04000E9C RID: 3740
		private const string _grenadeModelName = "m67";

		// Token: 0x04000E9D RID: 3741
		private GameplayVoiceView _voiceView;

		// Token: 0x04000E9E RID: 3742
		private bool _hasTriggeredEndMatch;

		// Token: 0x04000E9F RID: 3743
		private bool _hasFirstSpawn;

		// Token: 0x04000EA0 RID: 3744
		private Dictionary<VoicePool, HighSpeedArray<VoiceEnum>> _voiceRequests;

		// Token: 0x04000EA1 RID: 3745
		private float _lastVoicePoolExecution;

		// Token: 0x04000EA2 RID: 3746
		private bool _shouldInvokeSoundSpawn;

		// Token: 0x04000EA3 RID: 3747
		private bool _shouldInvokeSoundThrow;

		// Token: 0x04000EA4 RID: 3748
		private HighSpeedArray<GameplayVoiceController.DamageReceived> _damages;

		// Token: 0x04000EA5 RID: 3749
		private long _lastTargetingEnemyId;

		// Token: 0x04000EA6 RID: 3750
		private float _lastTargetingTriggered;

		// Token: 0x04000EA7 RID: 3751
		private float _lastInvokedSound;

		// Token: 0x0200021E RID: 542
		internal struct DamageReceived
		{
			// Token: 0x04000EA8 RID: 3752
			internal int damage;

			// Token: 0x04000EA9 RID: 3753
			internal float timestamp;
		}
	}
}
