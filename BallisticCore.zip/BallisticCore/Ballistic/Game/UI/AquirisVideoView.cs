﻿using System;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Video;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000260 RID: 608
	public class AquirisVideoView : MonoBehaviour
	{
		// Token: 0x06000D22 RID: 3362 RVA: 0x00002A31 File Offset: 0x00000C31
		public void Awake()
		{
		}

		// Token: 0x06000D23 RID: 3363 RVA: 0x0004E308 File Offset: 0x0004C508
		public void Update()
		{
			this._shouldPassTimeFirst += Time.deltaTime;
			if (this._shouldPassTimeFirst < 1f)
			{
				return;
			}
			if (!this.VideoPlayer.isPlaying || Input.anyKeyDown)
			{
				this.Animator.SetTrigger("out");
			}
		}

		// Token: 0x06000D24 RID: 3364 RVA: 0x0000B026 File Offset: 0x00009226
		public void OnVideoFinished()
		{
			ServiceProvider.GetService<SceneService>().LoadSceneTitle();
		}

		// Token: 0x04000FE2 RID: 4066
		public VideoPlayer VideoPlayer;

		// Token: 0x04000FE3 RID: 4067
		public Animator Animator;

		// Token: 0x04000FE4 RID: 4068
		public float _shouldPassTimeFirst;
	}
}
