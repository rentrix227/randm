﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000297 RID: 663
	internal class CharacterScreenIndicator : BaseScreenIndicator
	{
		// Token: 0x06000E27 RID: 3623 RVA: 0x0000B963 File Offset: 0x00009B63
		private void SetTankOffset(bool isTank)
		{
			if (this._originalWorldOffset == Vector3.zero)
			{
				this._originalWorldOffset = this.WorldOffset;
			}
			this.WorldOffset = ((!isTank) ? this._originalWorldOffset : this.WorldOffsetForTank);
		}

		// Token: 0x06000E28 RID: 3624 RVA: 0x0000B9A3 File Offset: 0x00009BA3
		internal void SetNickname(string nickname)
		{
			this.IndicatorComponent.SetNickname(nickname);
		}

		// Token: 0x06000E29 RID: 3625 RVA: 0x00054408 File Offset: 0x00052608
		internal void UpdateMarker(Vector3 worldPosition, bool isAiming, bool isCamouflaged, float health, float maxHealth, EHeroClass heroClass, bool teammate, bool juggernaut, bool isVisible)
		{
			this.SetTankOffset(heroClass == EHeroClass.TANK);
			base.UpdateMarkerPosition(worldPosition);
			float num = Vector3.Distance(worldPosition, base._camera.transform.position);
			float num2 = ((!isAiming) ? ((!juggernaut) ? this.DistanceToShowWhenNotAiming : this.DistanceToShowWhenJuggernaut) : this.DistanceToShowWhenAiming);
			bool flag = num < num2 && !isCamouflaged && (isVisible || teammate || juggernaut);
			float num3 = Mathf.Lerp(this.DistanceScaleOfArrow.x, this.DistanceScaleOfArrow.y, (num - this.DistanceToStartShowArrow) / this.DistanceMaximumToScaleArrow);
			this.IndicatorComponent.UpdateInfo(flag, (teammate && num > this.DistanceToStartShowArrow) || (juggernaut && num > num2), health, maxHealth, num3);
		}

		// Token: 0x06000E2A RID: 3626 RVA: 0x0000B9B1 File Offset: 0x00009BB1
		internal void TriggerVoice()
		{
			this.IndicatorComponent.TriggerVoice();
		}

		// Token: 0x040011FB RID: 4603
		internal GameplayScreenIndicatorCharacterComponent IndicatorComponent;

		// Token: 0x040011FC RID: 4604
		internal UITeam Team;

		// Token: 0x040011FD RID: 4605
		internal float DistanceToShowWhenAiming;

		// Token: 0x040011FE RID: 4606
		internal float DistanceToShowWhenNotAiming;

		// Token: 0x040011FF RID: 4607
		internal float DistanceToShowWhenJuggernaut;

		// Token: 0x04001200 RID: 4608
		internal float DistanceToStartShowArrow;

		// Token: 0x04001201 RID: 4609
		internal float DistanceMaximumToScaleArrow;

		// Token: 0x04001202 RID: 4610
		internal Vector2 DistanceScaleOfArrow = new Vector2(1f, 0.3f);

		// Token: 0x04001203 RID: 4611
		internal Vector3 WorldOffsetForTank;

		// Token: 0x04001204 RID: 4612
		private Vector3 _originalWorldOffset = Vector3.zero;
	}
}
