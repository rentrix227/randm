﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000299 RID: 665
	internal class DamageScreenIndicator : BaseScreenIndicator
	{
		// Token: 0x06000E2F RID: 3631 RVA: 0x0005454C File Offset: 0x0005274C
		internal void SpawnDamage(float damage, float accumulateTime = 0f, DamageAmount damageAmount = DamageAmount.Medium)
		{
			if (accumulateTime < 0.02f)
			{
				this.IndicatorComponent.SpawnDamage(damage, damageAmount);
				return;
			}
			if (this._accumulatedDamageCoroutine == null)
			{
				this._accumulatedDamage = 0f;
				this._accumulateTimer = 0f;
				this._damageAmount = damageAmount;
				this._accumulatedDamageCoroutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.AccumulateDamageRoutine(accumulateTime));
			}
			this._accumulateTimer = Mathf.Max(this._accumulateTimer, accumulateTime);
			this._accumulatedDamage += damage;
		}

		// Token: 0x06000E30 RID: 3632 RVA: 0x000545D4 File Offset: 0x000527D4
		private IEnumerator AccumulateDamageRoutine(float accumulateTime)
		{
			yield return null;
			while (this._accumulateTimer > 0f)
			{
				this._accumulateTimer -= Time.deltaTime;
				yield return null;
			}
			if (this.IndicatorComponent == null)
			{
				yield break;
			}
			this.IndicatorComponent.SpawnDamage(this._accumulatedDamage, this._damageAmount);
			this._accumulatedDamageCoroutine = null;
			yield break;
		}

		// Token: 0x06000E31 RID: 3633 RVA: 0x0000B9CC File Offset: 0x00009BCC
		internal void UpdateMarker(Vector3 worldPosition)
		{
			base.UpdateMarkerPosition(worldPosition);
		}

		// Token: 0x04001207 RID: 4615
		internal GameplayScreenIndicatorDamageRootComponent IndicatorComponent;

		// Token: 0x04001208 RID: 4616
		internal float MaxDamageForLow;

		// Token: 0x04001209 RID: 4617
		internal float MaxDamageForMedium;

		// Token: 0x0400120A RID: 4618
		private Coroutine _accumulatedDamageCoroutine;

		// Token: 0x0400120B RID: 4619
		private float _accumulatedDamage;

		// Token: 0x0400120C RID: 4620
		private float _accumulateTimer;

		// Token: 0x0400120D RID: 4621
		private DamageAmount _damageAmount;
	}
}
