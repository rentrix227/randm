﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001E8 RID: 488
	public class ItemDetailsWeaponTooltipComponent : MonoBehaviour
	{
		// Token: 0x060009D9 RID: 2521 RVA: 0x00008DF2 File Offset: 0x00006FF2
		public void Awake()
		{
			this._toggle = base.GetComponent<Toggle>();
			if (this._toggle != null)
			{
				this._toggle.onValueChanged.AddListener(new UnityAction<bool>(this.HandleToggleValueChanged));
			}
		}

		// Token: 0x060009DA RID: 2522 RVA: 0x00008E2D File Offset: 0x0000702D
		private void HandleToggleValueChanged(bool valueSet)
		{
			if (this._isSetting)
			{
				return;
			}
			if (this.OnWeaponClick != null)
			{
				this.OnWeaponClick(this, valueSet);
			}
		}

		// Token: 0x060009DB RID: 2523 RVA: 0x0003A960 File Offset: 0x00038B60
		public void SetWeapon(WeaponV4 weapon, bool wasReplaced = false)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			TextureHelper.LoadImageAsync(TextureHelper.GetWeaponIconPath(weapon.ItemModel, EImageSize.SMALL, "default"), this.WeaponIcon, false, EImageSource.METADATA);
			if (this.WeaponMiniIcon != null)
			{
				TextureHelper.LoadImageAsync(TextureHelper.GetWeaponIconPath(weapon.ItemModel, EImageSize.SMALL, "default"), this.WeaponMiniIcon, false, EImageSource.METADATA);
			}
			this.WeaponName.text = service.GetWeaponName(weapon.ItemName, ELocalizedTextCase.UPPER_CASE);
			this.WeaponCategory.text = service.GetWeaponCategory(weapon.Category, ELocalizedTextCase.UPPER_CASE);
			if (this._toggle != null)
			{
				this._isSetting = true;
				this._toggle.isOn = wasReplaced;
				this._isSetting = false;
			}
		}

		// Token: 0x04000D24 RID: 3364
		public RawImage WeaponIcon;

		// Token: 0x04000D25 RID: 3365
		public Image WeaponMiniIcon;

		// Token: 0x04000D26 RID: 3366
		public Text WeaponName;

		// Token: 0x04000D27 RID: 3367
		public Text WeaponCategory;

		// Token: 0x04000D28 RID: 3368
		public Action<ItemDetailsWeaponTooltipComponent, bool> OnWeaponClick;

		// Token: 0x04000D29 RID: 3369
		private Toggle _toggle;

		// Token: 0x04000D2A RID: 3370
		private bool _isSetting;
	}
}
