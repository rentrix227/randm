﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200022D RID: 557
	public class InGameRespawnController : BaseController
	{
		// Token: 0x06000BC4 RID: 3012 RVA: 0x000476C8 File Offset: 0x000458C8
		public InGameRespawnController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldierService = ServiceProvider.GetService<SoldiersService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._playerHeroService = ServiceProvider.GetService<PlayerHeroService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._spectatorService = ServiceProvider.GetService<SpectatorService>();
			this._sceneService = ServiceProvider.GetService<SceneService>();
			this._soldierService.OnSoldierChanged += this.OnSoldierChanged;
			this._soldierService.OnLoadoutChanged += this.OnLoadoutChanged;
			this._networkGameService.OnSelectTeam.AddListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.AddListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnTeamQueueChanged.AddListener(new Action<TeamQueueChangedEvent>(this.OnTeamQueueChanged));
			this._networkGameService.OnReadyToSpawn.AddListener(new Action<ReadyToSpawnResponse>(this.OnReadyToRespawn));
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnRoundUp.AddListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			this._networkGameService.OnChangeState.AddListener(new Action<ChangeGameStateEvent>(this.OnChangeState));
			this._sceneService.OnSceneLoaded += this.OnSceneLoaded;
		}

		// Token: 0x06000BC5 RID: 3013 RVA: 0x00047834 File Offset: 0x00045A34
		public override void DisableController()
		{
			base.DisableController();
			this._soldierService.OnSoldierChanged -= this.OnSoldierChanged;
			this._soldierService.OnLoadoutChanged -= this.OnLoadoutChanged;
			this._networkGameService.OnSelectTeam.RemoveListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnSelectTeamCompleted.RemoveListener(new Action<SelectTeamCompletedResponse>(this.OnSelectTeamCompleted));
			this._networkGameService.OnTeamQueueChanged.RemoveListener(new Action<TeamQueueChangedEvent>(this.OnTeamQueueChanged));
			this._networkGameService.OnReadyToSpawn.RemoveListener(new Action<ReadyToSpawnResponse>(this.OnReadyToRespawn));
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			this._networkGameService.OnChangeState.AddListener(new Action<ChangeGameStateEvent>(this.OnChangeState));
			this._sceneService.OnSceneLoaded -= this.OnSceneLoaded;
		}

		// Token: 0x06000BC6 RID: 3014 RVA: 0x00047950 File Offset: 0x00045B50
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameRespawnSoldiersView inGameRespawnSoldiersView = view as InGameRespawnSoldiersView;
			if (inGameRespawnSoldiersView != null)
			{
				inGameRespawnSoldiersView.SetSoldier(this._showSpectatorWindow, UserProfile.LocalGameClient.clientMode, this._soldierService.UpdateAndGetAvaliableClasses(this._gameModeService.GameMode), this._soldierService.GetCurrentClass());
			}
			InGameRespawnLoadoutsView inGameRespawnLoadoutsView = view as InGameRespawnLoadoutsView;
			if (inGameRespawnLoadoutsView != null)
			{
				this.UpdateRespawnLoadouts(inGameRespawnLoadoutsView, true);
			}
			InGameRespawnClassInfoView inGameRespawnClassInfoView = view as InGameRespawnClassInfoView;
			if (inGameRespawnClassInfoView != null)
			{
				inGameRespawnClassInfoView.SetStartData(this._showSpectatorWindow, this._soldierService.GetCurrentPlayerHero());
			}
			InGameEndRoundsClassesView inGameEndRoundsClassesView = view as InGameEndRoundsClassesView;
			if (inGameEndRoundsClassesView != null)
			{
				inGameEndRoundsClassesView.SetSelectedData(this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, this._soldierService.UpdateAndGetSelectedClasses());
			}
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x00047A38 File Offset: 0x00045C38
		private void UpdateRespawnLoadouts(InGameRespawnLoadoutsView inGameRespawnLoadoutsView, bool startData)
		{
			if (!inGameRespawnLoadoutsView.isActiveAndEnabled)
			{
				return;
			}
			if (UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE && UserProfile.LocalGameClient.requestMode != ETeamMode.UNDEFINED)
			{
				this._lastRequestMode = UserProfile.LocalGameClient.requestMode;
			}
			if (startData)
			{
				Dictionary<EHeroClass, List<PlayerLoadoutData>> playerLoadouts = this._soldierService.GetPlayerLoadouts();
				foreach (PlayerHeroData playerHeroData in this._playerHeroService.GetAvailablePlayerHeroes())
				{
					List<PlayerLoadoutData> list = playerLoadouts[playerHeroData.GameItemData.GameItem.UniqueIdentifier];
					foreach (PlayerLoadoutData playerLoadoutData in list)
					{
						List<HeroSkillData> list2 = this._soldierService.GetSelectedHeroSkills(playerLoadoutData).ToList<HeroSkillData>();
						if (list2.Count < 2)
						{
							Debug.LogWarning(string.Concat(new object[]
							{
								"Loadout [",
								playerLoadoutData.GameItemData.GameItem.UniqueIdentifier,
								playerLoadoutData.PlayerItem.Number,
								"] has missing selectable skills."
							}));
						}
						HeroSkin heroSkin = this._soldierService.GetHeroSkin(playerLoadoutData);
						Accessory value = this._soldierService.GetAccessories(playerLoadoutData).First<KeyValuePair<EHeroItemSlot, Accessory>>().Value;
						inGameRespawnLoadoutsView.SetLoadoutData(playerHeroData.GameItemData.GameItem.UniqueIdentifier, playerLoadoutData.PlayerItem.ItemName, heroSkin, value, this._soldierService.GetLoadoutInfo(playerLoadoutData), playerLoadoutData, list2[0], list2[1], UserProfile.LocalGameClient.spawned);
					}
				}
			}
			bool flag = this._networkGameService.GetGameModeMetaData().QueueMetaDataList.Contains(UserProfile.LocalGameClient.gameClientId);
			HighSpeedArray<ClientCommonMetaData> queueClientCommonMetadataList = this._networkGameService.GetQueueClientCommonMetadataList(UserProfile.LocalGameClient.requestMode);
			int num = queueClientCommonMetadataList.IndexOf((ClientCommonMetaData t) => UserProfile.IsMe(t.User)) + 1;
			inGameRespawnLoadoutsView.SetQueuePlayerData(queueClientCommonMetadataList);
			int count = this._networkGameService.GetGameModeMetaData().QueueMetaDataList.Count;
			QueueState queueState = this._gameModeService.MatchIsFull(UserProfile.LocalGameClient.requestMode);
			bool flag2 = false;
			EGameMode gameMode = this._gameModeService.GameMode;
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				if (UserProfile.LocalGameClient.requestMode == ETeamMode.MFA)
				{
					flag2 = this._gameModeService.MatchIsFull(ETeamMode.SMOKE) == QueueState.OPEN;
				}
				else if (UserProfile.LocalGameClient.requestMode == ETeamMode.SMOKE)
				{
					flag2 = this._gameModeService.MatchIsFull(ETeamMode.MFA) == QueueState.OPEN;
				}
			}
			if (startData)
			{
				inGameRespawnLoadoutsView.SetStartData(this._showSpectatorWindow, UserProfile.LocalGameClient.clientMode, this._soldierService.GetCurrentClass(), queueState, flag, num, count, flag2);
			}
			else
			{
				inGameRespawnLoadoutsView.SetData(this._showSpectatorWindow, UserProfile.LocalGameClient.clientMode, this._soldierService.GetCurrentClass(), queueState, flag, num, count, flag2);
			}
		}

		// Token: 0x06000BC8 RID: 3016 RVA: 0x0000A0BA File Offset: 0x000082BA
		internal void DispatchSoldierChanged(EHeroClass soldier)
		{
			this._showSpectatorWindow = false;
			this._soldierService.DispatchSoldierChanged(soldier);
		}

		// Token: 0x06000BC9 RID: 3017 RVA: 0x00047DA4 File Offset: 0x00045FA4
		internal void DispatchSpectatorSelected()
		{
			this._showSpectatorWindow = true;
			InGameRespawnLoadoutsView view = base.GetView<InGameRespawnLoadoutsView>();
			if (view != null)
			{
				this.UpdateRespawnLoadouts(view, false);
			}
			InGameRespawnClassInfoView view2 = base.GetView<InGameRespawnClassInfoView>();
			if (view2 != null)
			{
				view2.SetData(this._showSpectatorWindow, this._soldierService.GetCurrentPlayerHero());
			}
		}

		// Token: 0x06000BCA RID: 3018 RVA: 0x0000A0CF File Offset: 0x000082CF
		internal void DispatchOnLoadoutSelected(PlayerLoadoutData loadout)
		{
			this._soldierService.SetLoadoutClicked(loadout);
		}

		// Token: 0x06000BCB RID: 3019 RVA: 0x0000A0DD File Offset: 0x000082DD
		private void OnSceneLoaded(EBaseScene scene)
		{
			if (scene != EBaseScene.InGame)
			{
				return;
			}
			this._showSpectatorWindow = UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR;
		}

		// Token: 0x06000BCC RID: 3020 RVA: 0x00047E00 File Offset: 0x00046000
		private void OnSelectTeamCompleted(SelectTeamCompletedResponse evt)
		{
			if (UserProfile.IsMe(evt.User))
			{
				this._showSpectatorWindow = UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR;
				InGameRespawnClassInfoView view = base.GetView<InGameRespawnClassInfoView>();
				if (view != null)
				{
					view.SetData(this._showSpectatorWindow, this._soldierService.GetCurrentPlayerHero());
				}
				InGameRespawnSoldiersView view2 = base.GetView<InGameRespawnSoldiersView>();
				if (view2 != null)
				{
					view2.SetSoldier(this._showSpectatorWindow, UserProfile.LocalGameClient.clientMode, this._soldierService.UpdateAndGetAvaliableClasses(this._gameModeService.GameMode), this._soldierService.GetCurrentClass());
				}
			}
			InGameRespawnLoadoutsView view3 = base.GetView<InGameRespawnLoadoutsView>();
			if (view3 != null)
			{
				this.UpdateRespawnLoadouts(view3, true);
			}
			InGameEndRoundsClassesView view4 = base.GetView<InGameEndRoundsClassesView>();
			if (view4 != null)
			{
				view4.SetSelectedData(this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, this._soldierService.UpdateAndGetSelectedClasses());
			}
		}

		// Token: 0x06000BCD RID: 3021 RVA: 0x00047EF8 File Offset: 0x000460F8
		private void OnSelectTeam(SelectTeamResponse evt)
		{
			if (UserProfile.IsMe(evt.User))
			{
				this._showSpectatorWindow = true;
				InGameRespawnClassInfoView view = base.GetView<InGameRespawnClassInfoView>();
				if (view != null)
				{
					view.SetData(this._showSpectatorWindow, this._soldierService.GetCurrentPlayerHero());
				}
				InGameRespawnSoldiersView view2 = base.GetView<InGameRespawnSoldiersView>();
				if (view2 != null)
				{
					view2.SetSoldier(this._showSpectatorWindow, UserProfile.LocalGameClient.clientMode, this._soldierService.UpdateAndGetAvaliableClasses(this._gameModeService.GameMode), this._soldierService.GetCurrentClass());
				}
			}
			InGameRespawnLoadoutsView view3 = base.GetView<InGameRespawnLoadoutsView>();
			if (view3 != null)
			{
				this.UpdateRespawnLoadouts(view3, true);
			}
			InGameEndRoundsClassesView view4 = base.GetView<InGameEndRoundsClassesView>();
			if (view4 != null)
			{
				view4.SetSelectedData(this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, this._soldierService.UpdateAndGetSelectedClasses());
			}
		}

		// Token: 0x06000BCE RID: 3022 RVA: 0x00047FE4 File Offset: 0x000461E4
		private void OnChangeState(ChangeGameStateEvent obj)
		{
			InGameEndRoundsClassesView view = base.GetView<InGameEndRoundsClassesView>();
			if (view != null)
			{
				view.SetSelectedData(this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, this._soldierService.UpdateAndGetSelectedClasses());
			}
		}

		// Token: 0x06000BCF RID: 3023 RVA: 0x00047FE4 File Offset: 0x000461E4
		private void OnRoundUp(ChangeRoundEvent obj)
		{
			InGameEndRoundsClassesView view = base.GetView<InGameEndRoundsClassesView>();
			if (view != null)
			{
				view.SetSelectedData(this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, this._soldierService.UpdateAndGetSelectedClasses());
			}
		}

		// Token: 0x06000BD0 RID: 3024 RVA: 0x0004802C File Offset: 0x0004622C
		private void OnTeamQueueChanged(TeamQueueChangedEvent evt)
		{
			InGameRespawnLoadoutsView view = base.GetView<InGameRespawnLoadoutsView>();
			if (view != null)
			{
				this.UpdateRespawnLoadouts(view, true);
			}
		}

		// Token: 0x06000BD1 RID: 3025 RVA: 0x0000A0FA File Offset: 0x000082FA
		private void OnReadyToRespawn(ReadyToSpawnResponse evt)
		{
			if (evt.ReadyToSpawn)
			{
				UIManager.Instance.ChangeState("CUTSCENE");
			}
		}

		// Token: 0x06000BD2 RID: 3026 RVA: 0x00048054 File Offset: 0x00046254
		private void OnSpawn(SpawnEvent evt)
		{
			InGameRespawnSoldiersView view = base.GetView<InGameRespawnSoldiersView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.SetSoldier(this._showSpectatorWindow, UserProfile.LocalGameClient.clientMode, this._soldierService.UpdateAndGetAvaliableClasses(this._gameModeService.GameMode), this._soldierService.GetCurrentClass());
			}
			InGameEndRoundsClassesView view2 = base.GetView<InGameEndRoundsClassesView>();
			if (view2 != null && view2.isActiveAndEnabled)
			{
				view2.SetSelectedData(this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, this._soldierService.UpdateAndGetSelectedClasses());
			}
			InGameRespawnLoadoutsView view3 = base.GetView<InGameRespawnLoadoutsView>();
			if (view3 != null)
			{
				this.UpdateRespawnLoadouts(view3, true);
			}
		}

		// Token: 0x06000BD3 RID: 3027 RVA: 0x00048118 File Offset: 0x00046318
		private void OnSoldierChanged(EHeroClass eHeroClass)
		{
			InGameRespawnLoadoutsView view = base.GetView<InGameRespawnLoadoutsView>();
			if (view != null)
			{
				this.UpdateRespawnLoadouts(view, false);
			}
			InGameRespawnClassInfoView view2 = base.GetView<InGameRespawnClassInfoView>();
			if (view2 != null)
			{
				view2.SetData(this._showSpectatorWindow, this._soldierService.GetCurrentPlayerHero());
			}
		}

		// Token: 0x06000BD4 RID: 3028 RVA: 0x0004816C File Offset: 0x0004636C
		private void OnLoadoutChanged(PlayerLoadoutData loadout)
		{
			if (this._networkGameService.GetGameModeMetaData().GameConfig.GameMode == EGameMode.Rounds && this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType == EGameState.PLAYING)
			{
				return;
			}
			this._gameModeService.RequestSpawn(loadout);
		}

		// Token: 0x06000BD5 RID: 3029 RVA: 0x000481BC File Offset: 0x000463BC
		public void DispatchSpectateMatch(bool stay)
		{
			if (UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE && !stay)
			{
				SelectTeamRequest selectTeamRequest = new SelectTeamRequest
				{
					RequestedTeam = ETeamMode.SPECTATE
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest);
			}
			else
			{
				this._spectatorService.SpawnFreeCamFromCutCamera();
			}
		}

		// Token: 0x06000BD6 RID: 3030 RVA: 0x0004820C File Offset: 0x0004640C
		internal void DispatchSwitchTeamRequest()
		{
			if (UserProfile.LocalGameClient.requestMode == ETeamMode.MFA)
			{
				SelectTeamRequest selectTeamRequest = new SelectTeamRequest
				{
					RequestedTeam = ETeamMode.SMOKE
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest);
			}
			else if (UserProfile.LocalGameClient.requestMode == ETeamMode.SMOKE)
			{
				SelectTeamRequest selectTeamRequest2 = new SelectTeamRequest
				{
					RequestedTeam = ETeamMode.MFA
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest2);
			}
		}

		// Token: 0x06000BD7 RID: 3031 RVA: 0x00048274 File Offset: 0x00046474
		internal void DispatchSpectateOnly()
		{
			if (UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE)
			{
				SelectTeamRequest selectTeamRequest = new SelectTeamRequest
				{
					RequestedTeam = ETeamMode.SPECTATE
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest);
			}
		}

		// Token: 0x06000BD8 RID: 3032 RVA: 0x000482AC File Offset: 0x000464AC
		internal void DispatchRespawnAsPlayer()
		{
			if (!this._networkGameService.IsConnected())
			{
				return;
			}
			if (this._networkGameService.GetGameModeMetaData().GameConfig.AutoBalance)
			{
				SelectTeamRequest selectTeamRequest = new SelectTeamRequest
				{
					RequestedTeam = ETeamMode.ANY
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest);
			}
			else if (this._lastRequestMode == ETeamMode.MFA || this._lastRequestMode == ETeamMode.SMOKE)
			{
				SelectTeamRequest selectTeamRequest2 = new SelectTeamRequest
				{
					RequestedTeam = this._lastRequestMode
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest2);
			}
			else
			{
				SelectTeamRequest selectTeamRequest3 = new SelectTeamRequest
				{
					RequestedTeam = ETeamMode.ANY
				};
				this._networkGameService.RaiseNetworkEvent(selectTeamRequest3);
			}
		}

		// Token: 0x04000F04 RID: 3844
		private readonly PlayerHeroService _playerHeroService;

		// Token: 0x04000F05 RID: 3845
		private readonly SoldiersService _soldierService;

		// Token: 0x04000F06 RID: 3846
		private readonly GameModeService _gameModeService;

		// Token: 0x04000F07 RID: 3847
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000F08 RID: 3848
		private readonly SpectatorService _spectatorService;

		// Token: 0x04000F09 RID: 3849
		private readonly SceneService _sceneService;

		// Token: 0x04000F0A RID: 3850
		private bool _showSpectatorWindow;

		// Token: 0x04000F0B RID: 3851
		private ETeamMode _lastRequestMode;
	}
}
