﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000290 RID: 656
	public class GameplayScoreView : BaseView<GameplayScoreboardController>
	{
		// Token: 0x06000E00 RID: 3584 RVA: 0x00053398 File Offset: 0x00051598
		protected override void Awake()
		{
			base.Awake();
			this._fillParameterHash = Shader.PropertyToID("_Fill");
			this._currentPointOwners = new UITeam[this.YourCtpPoints.Length];
			this._desiredPointOwners = new UITeam[this.YourCtpPoints.Length];
			this._pointOwnerChangeCooldown = new float[this.YourCtpPoints.Length];
		}

		// Token: 0x06000E01 RID: 3585 RVA: 0x000533F4 File Offset: 0x000515F4
		internal void SetGameMode(EGameMode mode)
		{
			if (this._lastGameMode == mode)
			{
				return;
			}
			this.TdmRoot.SetActive(mode == EGameMode.TeamDeathMatch);
			this.CtpRoot.SetActive(mode == EGameMode.Conquest);
			this.RoundsRoot.SetActive(mode == EGameMode.Rounds);
			this.KothRoot.SetActive(mode == EGameMode.KingOfTheHill);
			this.FfaRoot.SetActive(mode == EGameMode.FreeForAll);
			this.JugRoot.SetActive(mode == EGameMode.Juggernaut);
			this._lastGameMode = mode;
		}

		// Token: 0x06000E02 RID: 3586 RVA: 0x00053470 File Offset: 0x00051670
		internal void FfaUpdateData(int totalSeconds, int yourRank, int totalPlayers)
		{
			if (this._lastTotalSeconds != totalSeconds)
			{
				this.UpdateTimeSeconds(this.FfaTimerText, totalSeconds);
				bool flag = totalSeconds <= this.SecondsToConsiderEnding;
				if (this.FfaTimeAnimator.isInitialized)
				{
					EWinningTeam winningTeam = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam;
					this.FfaTimeAnimator.SetBool("ending_losing", flag && winningTeam == EWinningTeam.ENEMY && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
					this.FfaTimeAnimator.SetBool("ending_winning", flag && winningTeam == EWinningTeam.MINE && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
				}
			}
			if (this._lastRank != yourRank)
			{
				this.FfaRankingRoot.SetActive(yourRank > 0 && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
				this.FfaRankingNumberLabel.text = yourRank.ToString();
				this.FfaRankingNumberSuffixLabel.text = ServiceProvider.GetService<LocalizationService>().Get("ordinal_suffix_" + yourRank, ELocalizedTextCase.UPPER_CASE);
				this._lastRank = yourRank;
			}
		}

		// Token: 0x06000E03 RID: 3587 RVA: 0x00053594 File Offset: 0x00051794
		internal void JugUpdateData(int totalSeconds, int yourRank, int totalPlayers)
		{
			if (this._lastTotalSeconds != totalSeconds)
			{
				this.UpdateTimeSeconds(this.JugTimerText, totalSeconds);
				bool flag = totalSeconds <= this.SecondsToConsiderEnding;
				if (this.JugTimeAnimator.isInitialized)
				{
					EWinningTeam winningTeam = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam;
					this.JugTimeAnimator.SetBool("ending_losing", flag && winningTeam == EWinningTeam.ENEMY && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
					this.JugTimeAnimator.SetBool("ending_winning", flag && winningTeam == EWinningTeam.MINE && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
				}
			}
			if (this._lastRank != yourRank)
			{
				this.JugRankingRoot.SetActive(yourRank > 0 && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
				this.JugRankingNumberLabel.text = yourRank.ToString();
				this.JugRankingNumberSuffixLabel.text = ServiceProvider.GetService<LocalizationService>().Get("ordinal_suffix_" + yourRank, ELocalizedTextCase.UPPER_CASE);
				this._lastRank = yourRank;
			}
		}

		// Token: 0x06000E04 RID: 3588 RVA: 0x000536B8 File Offset: 0x000518B8
		internal void TdmUpdateData(int totalSeconds, int yourTeamScore, int enemyTeamScore)
		{
			EWinningTeam winningTeam = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam;
			bool flag = winningTeam == EWinningTeam.MINE;
			bool flag2 = winningTeam == EWinningTeam.ENEMY;
			if (this._lastTotalSeconds != totalSeconds)
			{
				this.UpdateTimeSeconds(this.TdmTimerText, totalSeconds);
				bool flag3 = totalSeconds <= this.SecondsToConsiderEnding;
				if (this.TdmTimeAnimator.isInitialized)
				{
					this.TdmTimeAnimator.SetBool("ending_losing", flag3 && flag2);
					this.TdmTimeAnimator.SetBool("ending_winning", flag3 && flag);
				}
			}
			if (this._yourLastTeamScore != yourTeamScore)
			{
				this._yourLastTeamScore = yourTeamScore;
				this.TdmYourScoreText.text = yourTeamScore.ToString();
			}
			if (this._enemyLastTeamScore != enemyTeamScore)
			{
				this._enemyLastTeamScore = enemyTeamScore;
				this.TdmEnemyScoreText.text = enemyTeamScore.ToString();
			}
			for (int i = 0; i < this.TdmEnableYourWinning.Length; i++)
			{
				if (this.TdmEnableYourWinning[i].activeInHierarchy != flag)
				{
					this.TdmEnableYourWinning[i].SetActive(flag);
				}
			}
			for (int j = 0; j < this.TdmEnableEnemyWinning.Length; j++)
			{
				if (this.TdmEnableEnemyWinning[j].activeInHierarchy != flag2)
				{
					this.TdmEnableEnemyWinning[j].SetActive(flag2);
				}
			}
		}

		// Token: 0x06000E05 RID: 3589 RVA: 0x00053828 File Offset: 0x00051A28
		internal void RoundsUpdateData(EGameState state, int totalSeconds, int yourWins, int enemyWins)
		{
			EWinningTeam winningTeam = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam;
			bool flag = winningTeam == EWinningTeam.MINE;
			bool flag2 = winningTeam == EWinningTeam.ENEMY;
			if (this._lastTotalSeconds != totalSeconds)
			{
				this.UpdateTimeSeconds(this.RoundsTimerText, totalSeconds);
				bool flag3 = state == EGameState.PLAYING && totalSeconds <= this.SecondsToConsiderRoundIsEnding;
				if (this.RoundsTimeAnimator.isInitialized)
				{
					this.RoundsTimeAnimator.SetBool("ending_losing", flag3 && flag2);
					this.RoundsTimeAnimator.SetBool("ending_winning", flag3 && flag);
				}
			}
			if (this._yourWins != yourWins)
			{
				this._yourWins = yourWins;
				this.RoundsYourWinsText.text = yourWins.ToString();
			}
			if (this._enemyWins != enemyWins)
			{
				this._enemyWins = enemyWins;
				this.RoundsEnemyWinsText.text = enemyWins.ToString();
			}
		}

		// Token: 0x06000E06 RID: 3590 RVA: 0x00053924 File Offset: 0x00051B24
		internal void RoundsUpdateTeams(HighSpeedArray<ClientCommonMetaData> yourTeamData, HighSpeedArray<ClientCommonMetaData> enemyTeamData)
		{
			this.RoundsYourTeamPlayers.SetActiveCount(7);
			this.RoundsEnemyTeamPlayers.SetActiveCount(7);
			for (int i = 0; i < this.RoundsYourTeamPlayers.Count; i++)
			{
				int num = this.RoundsYourTeamPlayers.Count - 1 - i;
				bool flag = num < yourTeamData.Length && yourTeamData[num].ClientMode == EClientMode.PLAYER;
				bool flag2 = flag && yourTeamData[num].CurrentState == EPlayerState.ALIVE;
				this.RoundsYourTeamPlayers[i].SetState(flag, flag2);
			}
			for (int j = 0; j < this.RoundsEnemyTeamPlayers.Count; j++)
			{
				bool flag3 = j < enemyTeamData.Length && enemyTeamData[j].ClientMode == EClientMode.PLAYER;
				bool flag4 = flag3 && enemyTeamData[j].CurrentState == EPlayerState.ALIVE;
				this.RoundsEnemyTeamPlayers[j].SetState(flag3, flag4);
			}
		}

		// Token: 0x06000E07 RID: 3591 RVA: 0x00053A34 File Offset: 0x00051C34
		internal void KothUpdateData(int totalSeconds, int yourTeamScore, int enemyTeamScore, int yourTeamPlayerCount, int enemyTeamPlayerCount, int maxScore)
		{
			EWinningTeam winningTeam = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam;
			bool flag = winningTeam == EWinningTeam.MINE;
			bool flag2 = winningTeam == EWinningTeam.ENEMY;
			if (this._lastTotalSeconds != totalSeconds)
			{
				this.UpdateTimeSeconds(this.KothTimerText, totalSeconds);
				bool flag3 = totalSeconds <= this.SecondsToConsiderEnding;
				if (this.KothTimeAnimator.isInitialized)
				{
					this.KothTimeAnimator.SetBool("ending_losing", flag3 && flag2);
					this.KothTimeAnimator.SetBool("ending_winning", flag3 && flag);
				}
			}
			if (yourTeamScore != this._yourLastTeamScore)
			{
				this.KothYourScoreText.text = yourTeamScore.ToString();
				this.KothYourTeamBar.material.SetFloat(this._fillParameterHash, (float)yourTeamScore / (float)maxScore);
				this._yourLastTeamScore = yourTeamScore;
			}
			if (enemyTeamScore != this._enemyLastTeamScore)
			{
				this.KothEnemyScoreText.text = enemyTeamScore.ToString();
				this.KothEnemyTeamBar.material.SetFloat(this._fillParameterHash, (float)enemyTeamScore / (float)maxScore);
				this._enemyLastTeamScore = enemyTeamScore;
			}
			float kingOfTheHillScore = this.GetKingOfTheHillScore(yourTeamPlayerCount);
			float kingOfTheHillScore2 = this.GetKingOfTheHillScore(enemyTeamPlayerCount);
			float num = kingOfTheHillScore + kingOfTheHillScore2;
			this._currentKingOfTheHillFillTarget = ((num <= 0.001f) ? 0.5f : (kingOfTheHillScore / num));
		}

		// Token: 0x06000E08 RID: 3592 RVA: 0x0000B85C File Offset: 0x00009A5C
		internal float GetKingOfTheHillScore(int players)
		{
			return this.BaseKingOfTheHillBarFactor + Mathf.Pow((float)players, this.KingOfTheHillPowFactor);
		}

		// Token: 0x06000E09 RID: 3593 RVA: 0x00053B98 File Offset: 0x00051D98
		internal void CtpUpdateData(int totalSeconds, int yourTeamScore, int enemyTeamScore, int maxScore)
		{
			EWinningTeam winningTeam = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam;
			bool flag = winningTeam == EWinningTeam.MINE;
			bool flag2 = winningTeam == EWinningTeam.ENEMY;
			if (this._lastTotalSeconds != totalSeconds)
			{
				this.UpdateTimeSeconds(this.CtpTimerText, totalSeconds);
				bool flag3 = totalSeconds <= this.SecondsToConsiderEnding;
				if (this.CtpTimeAnimator.isInitialized)
				{
					this.CtpTimeAnimator.SetBool("ending_losing", flag3 && flag2);
					this.CtpTimeAnimator.SetBool("ending_winning", flag3 && flag);
				}
			}
			if (yourTeamScore != this._yourLastTeamScore)
			{
				this.CtpYourTeamScoreText.text = yourTeamScore.ToString();
				this.CtpYourTeamBar.material.SetFloat(this._fillParameterHash, (float)yourTeamScore / (float)maxScore);
				this._yourLastTeamScore = yourTeamScore;
			}
			if (enemyTeamScore != this._enemyLastTeamScore)
			{
				this.CtpEnemyTeamScoreText.text = enemyTeamScore.ToString();
				this.CtpEnemyTeamBar.material.SetFloat(this._fillParameterHash, (float)enemyTeamScore / (float)maxScore);
				this._enemyLastTeamScore = enemyTeamScore;
			}
		}

		// Token: 0x06000E0A RID: 3594 RVA: 0x00053CC0 File Offset: 0x00051EC0
		internal void CtpSetNumberOfCapturePoints(int numberOfPoints)
		{
			if (numberOfPoints == this._numberOfPoints)
			{
				return;
			}
			this._numberOfPoints = numberOfPoints;
			for (int i = 0; i < this.Points.Length; i++)
			{
				this.Points[i].gameObject.SetActive(i < numberOfPoints);
				if (i >= numberOfPoints)
				{
					this.YourCtpPoints[i].SetActive(false);
					this.NeutralCtpPoints[i].SetActive(false);
					this.EnemyCtpPoints[i].SetActive(false);
				}
			}
		}

		// Token: 0x06000E0B RID: 3595 RVA: 0x0000B872 File Offset: 0x00009A72
		internal void CtpUpdatePointState(int pointIndex, UITeam ownerTeam, UITeam capturingTeam, float captureAmount, bool isProtected, bool playerIsCapturing)
		{
			this._desiredPointOwners[pointIndex] = ownerTeam;
			this._pointOwnerChangeCooldown[pointIndex] = this.CtpMoveBubbleDelay;
			if (pointIndex >= 0 && pointIndex < 5)
			{
				this.Points[pointIndex].SetState(ownerTeam, capturingTeam, captureAmount, isProtected, playerIsCapturing);
			}
		}

		// Token: 0x06000E0C RID: 3596 RVA: 0x00053D48 File Offset: 0x00051F48
		public void Update()
		{
			for (int i = 0; i < this._currentPointOwners.Length; i++)
			{
				this._pointOwnerChangeCooldown[i] -= Time.deltaTime;
				if (this._currentPointOwners[i] != this._desiredPointOwners[i] && this._pointOwnerChangeCooldown[i] < 0f)
				{
					this._currentPointOwners[i] = this._desiredPointOwners[i];
					UITeam uiteam = this._currentPointOwners[i];
					if (uiteam != UITeam.Mine)
					{
						if (uiteam != UITeam.None)
						{
							if (uiteam == UITeam.Other)
							{
								this.EnemyCtpPoints[i].SetActive(true);
							}
						}
						else
						{
							this.NeutralCtpPoints[i].SetActive(true);
						}
					}
					else
					{
						this.YourCtpPoints[i].SetActive(true);
					}
				}
			}
			if (this.FfaRankingArrowAnimator.isInitialized)
			{
				this.FfaRankingArrowAnimator.SetBool("up", this._lastRankResult);
			}
			if (this.JugRankingArrowAnimator.isInitialized)
			{
				this.JugRankingArrowAnimator.SetBool("up", this._lastRankResult);
			}
			this._currentKingOfTheHillFillFactor = Mathf.Lerp(this._currentKingOfTheHillFillFactor, this._currentKingOfTheHillFillTarget, this.KingOfTheHillFillDamping * Time.deltaTime);
			this.KothCenterWheel.material.SetFloat(this._fillParameterHash, this._currentKingOfTheHillFillFactor);
		}

		// Token: 0x06000E0D RID: 3597 RVA: 0x00053EA0 File Offset: 0x000520A0
		private void UpdateTimeSeconds(Text timerText, int totalSeconds)
		{
			if (totalSeconds < 0)
			{
				timerText.text = "--:--";
				return;
			}
			this._lastTotalSeconds = totalSeconds;
			int num = totalSeconds / 60;
			int num2 = totalSeconds % 60;
			timerText.text = StringUtils.Time00to99[num] + ":" + StringUtils.Time00to99[num2];
		}

		// Token: 0x0400119B RID: 4507
		private int _fillParameterHash;

		// Token: 0x0400119C RID: 4508
		public int SecondsToConsiderEnding = 60;

		// Token: 0x0400119D RID: 4509
		public int SecondsToConsiderRoundIsEnding = 15;

		// Token: 0x0400119E RID: 4510
		[Header("GameMode Roots")]
		public GameObject TdmRoot;

		// Token: 0x0400119F RID: 4511
		public GameObject RoundsRoot;

		// Token: 0x040011A0 RID: 4512
		public GameObject CtpRoot;

		// Token: 0x040011A1 RID: 4513
		public GameObject KothRoot;

		// Token: 0x040011A2 RID: 4514
		public GameObject FfaRoot;

		// Token: 0x040011A3 RID: 4515
		public GameObject JugRoot;

		// Token: 0x040011A4 RID: 4516
		[Header("TDM")]
		public Text TdmTimerText;

		// Token: 0x040011A5 RID: 4517
		public Animator TdmTimeAnimator;

		// Token: 0x040011A6 RID: 4518
		public Text TdmYourScoreText;

		// Token: 0x040011A7 RID: 4519
		public Text TdmEnemyScoreText;

		// Token: 0x040011A8 RID: 4520
		public GameObject[] TdmEnableYourWinning;

		// Token: 0x040011A9 RID: 4521
		public GameObject[] TdmEnableEnemyWinning;

		// Token: 0x040011AA RID: 4522
		[Header("Rounds")]
		public Text RoundsTimerText;

		// Token: 0x040011AB RID: 4523
		public Animator RoundsTimeAnimator;

		// Token: 0x040011AC RID: 4524
		public Text RoundsYourWinsText;

		// Token: 0x040011AD RID: 4525
		public Text RoundsEnemyWinsText;

		// Token: 0x040011AE RID: 4526
		public GameplayScoreView.GameplayRoundPlayerComponentPoolableList RoundsYourTeamPlayers;

		// Token: 0x040011AF RID: 4527
		public GameplayScoreView.GameplayRoundPlayerComponentPoolableList RoundsEnemyTeamPlayers;

		// Token: 0x040011B0 RID: 4528
		[Header("Free for All")]
		public Text FfaTimerText;

		// Token: 0x040011B1 RID: 4529
		public Animator FfaTimeAnimator;

		// Token: 0x040011B2 RID: 4530
		public GameObject FfaRankingRoot;

		// Token: 0x040011B3 RID: 4531
		public Text FfaRankingNumberLabel;

		// Token: 0x040011B4 RID: 4532
		public Text FfaRankingNumberSuffixLabel;

		// Token: 0x040011B5 RID: 4533
		public Animator FfaRankingArrowAnimator;

		// Token: 0x040011B6 RID: 4534
		[Header("Capture Point")]
		public Text CtpTimerText;

		// Token: 0x040011B7 RID: 4535
		public Animator CtpTimeAnimator;

		// Token: 0x040011B8 RID: 4536
		public Text CtpYourTeamScoreText;

		// Token: 0x040011B9 RID: 4537
		public Text CtpEnemyTeamScoreText;

		// Token: 0x040011BA RID: 4538
		public Renderer CtpYourTeamBar;

		// Token: 0x040011BB RID: 4539
		public Renderer CtpEnemyTeamBar;

		// Token: 0x040011BC RID: 4540
		public float CtpMoveBubbleDelay = 0.5f;

		// Token: 0x040011BD RID: 4541
		public GameplayCapturePointComponent[] Points;

		// Token: 0x040011BE RID: 4542
		public GameObject[] YourCtpPoints;

		// Token: 0x040011BF RID: 4543
		public GameObject[] NeutralCtpPoints;

		// Token: 0x040011C0 RID: 4544
		public GameObject[] EnemyCtpPoints;

		// Token: 0x040011C1 RID: 4545
		[Header("King of The Hill")]
		public Text KothTimerText;

		// Token: 0x040011C2 RID: 4546
		public Animator KothTimeAnimator;

		// Token: 0x040011C3 RID: 4547
		public Text KothYourScoreText;

		// Token: 0x040011C4 RID: 4548
		public Text KothEnemyScoreText;

		// Token: 0x040011C5 RID: 4549
		public Renderer KothCenterWheel;

		// Token: 0x040011C6 RID: 4550
		public Renderer KothYourTeamBar;

		// Token: 0x040011C7 RID: 4551
		public Renderer KothEnemyTeamBar;

		// Token: 0x040011C8 RID: 4552
		public float KingOfTheHillPowFactor = 1.5f;

		// Token: 0x040011C9 RID: 4553
		public float KingOfTheHillFillDamping = 0.5f;

		// Token: 0x040011CA RID: 4554
		public float BaseKingOfTheHillBarFactor = 1f;

		// Token: 0x040011CB RID: 4555
		[Header("Juggernaut")]
		public Text JugTimerText;

		// Token: 0x040011CC RID: 4556
		public Animator JugTimeAnimator;

		// Token: 0x040011CD RID: 4557
		public GameObject JugRankingRoot;

		// Token: 0x040011CE RID: 4558
		public Text JugRankingNumberLabel;

		// Token: 0x040011CF RID: 4559
		public Text JugRankingNumberSuffixLabel;

		// Token: 0x040011D0 RID: 4560
		public Animator JugRankingArrowAnimator;

		// Token: 0x040011D1 RID: 4561
		private EGameMode _lastGameMode;

		// Token: 0x040011D2 RID: 4562
		private int _lastTotalSeconds = -1;

		// Token: 0x040011D3 RID: 4563
		private int _yourLastTeamScore = -1;

		// Token: 0x040011D4 RID: 4564
		private int _enemyLastTeamScore = -1;

		// Token: 0x040011D5 RID: 4565
		private int _yourWins = -1;

		// Token: 0x040011D6 RID: 4566
		private int _enemyWins = -1;

		// Token: 0x040011D7 RID: 4567
		private int _lastRank = -1;

		// Token: 0x040011D8 RID: 4568
		private bool _lastRankResult;

		// Token: 0x040011D9 RID: 4569
		private int _numberOfPoints = -1;

		// Token: 0x040011DA RID: 4570
		private float _currentKingOfTheHillFillFactor = 0.5f;

		// Token: 0x040011DB RID: 4571
		private float _currentKingOfTheHillFillTarget = 0.5f;

		// Token: 0x040011DC RID: 4572
		private UITeam[] _currentPointOwners;

		// Token: 0x040011DD RID: 4573
		private UITeam[] _desiredPointOwners;

		// Token: 0x040011DE RID: 4574
		private float[] _pointOwnerChangeCooldown;

		// Token: 0x02000291 RID: 657
		[Serializable]
		public class GameplayRoundPlayerComponentPoolableList : PoolableList<GameplayRoundPlayerComponent>
		{
		}
	}
}
