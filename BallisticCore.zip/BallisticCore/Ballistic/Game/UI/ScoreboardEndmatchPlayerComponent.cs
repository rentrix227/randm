﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001FE RID: 510
	public class ScoreboardEndmatchPlayerComponent : PoolableComponent
	{
		// Token: 0x06000A42 RID: 2626 RVA: 0x0003C444 File Offset: 0x0003A644
		internal void SetData(int number, ClientCommonMetaData metaData, bool isActive)
		{
			if (this.PlayerNumber != null)
			{
				this.PlayerNumber.text = number.ToString();
			}
			if (this.PlayerAvatarImage != null)
			{
				ServiceProvider.GetService<AvatarService>().LoadImageMedium(new CSteamID((ulong)metaData.User), new Action<ulong, Texture2D>(this.OnImageLoaded), true);
			}
			if (this.PlayerBadge != null)
			{
				if (metaData.Levels.ContainsKey(0))
				{
					this.PlayerBadge.sprite = this.PlayerBadgeSprites[RatingUtil.GetSkillRatingTierNumber((float)metaData.Levels[0])];
				}
				else
				{
					this.PlayerBadge.sprite = this.PlayerBadgeSprites[RatingUtil.GetSkillRatingTierNumber(0f)];
				}
			}
			if (this.PlayerName != null)
			{
				this.PlayerName.text = metaData.Nickname;
			}
			if (this.Kills != null)
			{
				this.Kills.text = metaData.Kills.ToString();
			}
			if (this.Assists != null)
			{
				this.Assists.text = ((int)(metaData.Assists + metaData.Criticalassists)).ToString();
			}
			if (this.KdRatioText != null)
			{
				this.KdRatioText.text = StatisticsService.GetKillDeathRatio((int)metaData.Kills, (int)metaData.Deaths).ToString("0.00");
			}
			if (this.Score != null)
			{
				this.Score.text = metaData.Score.ToString();
			}
			if (this.PlayerPanel != null && this.PlayerPanel.activeSelf != isActive)
			{
				this.PlayerPanel.SetActive(isActive);
			}
		}

		// Token: 0x06000A43 RID: 2627 RVA: 0x00009303 File Offset: 0x00007503
		private void OnImageLoaded(ulong playerId, Texture2D texture)
		{
			if (this.PlayerAvatarImage != null)
			{
				this.PlayerAvatarImage.texture = texture;
			}
		}

		// Token: 0x04000DA3 RID: 3491
		public RawImage PlayerAvatarImage;

		// Token: 0x04000DA4 RID: 3492
		public Text PlayerNumber;

		// Token: 0x04000DA5 RID: 3493
		public Image PlayerBadge;

		// Token: 0x04000DA6 RID: 3494
		public Image PlayerPanelSelected;

		// Token: 0x04000DA7 RID: 3495
		public Text PlayerName;

		// Token: 0x04000DA8 RID: 3496
		public Text Kills;

		// Token: 0x04000DA9 RID: 3497
		[FormerlySerializedAs("Deaths")]
		public Text Assists;

		// Token: 0x04000DAA RID: 3498
		public Text Score;

		// Token: 0x04000DAB RID: 3499
		public Text KdRatioText;

		// Token: 0x04000DAC RID: 3500
		public Sprite[] PlayerBadgeSprites;

		// Token: 0x04000DAD RID: 3501
		public GameObject PlayerPanel;
	}
}
