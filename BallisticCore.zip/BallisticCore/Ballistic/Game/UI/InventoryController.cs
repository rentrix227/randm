﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Lockbox;
using Aquiris.Pattern.Singleton;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroSkinModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200022E RID: 558
	public class InventoryController : BaseController
	{
		// Token: 0x06000BDA RID: 3034 RVA: 0x0004835C File Offset: 0x0004655C
		public InventoryController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._eventSystem = Singleton<UIEventSystem>.Instance;
			this._inventoryService = ServiceProvider.GetService<InventoryService>();
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
			this._telemetryService = ServiceProvider.GetService<TelemetryService>();
			this._lockboxData = ServiceProvider.GetService<GameItemService>().GetItemsOfType<Lockbox>().ToArray<Lockbox>();
			this._weaponData = ServiceProvider.GetService<GameItemService>().GetItemsOfType<WeaponV4>().ToArray<WeaponV4>();
			this._localizationService.OnLanguageChange += this.OnLanguageChange;
			InventoryData inventoryData = new InventoryData();
			inventoryData.Accessories = (from t in ServiceProvider.GetService<GameItemService>().GetItemsOfType<Accessory>()
				where t.Available && !t.IsDefaultAccessory
				select t).ToList<Accessory>();
			this._inventoryData = inventoryData;
			this._filters.Name = string.Empty;
			this._filters.Category = new EnumBitMask<EWeaponCategory>();
			this._filters.Class = EHeroClass.NONE;
			this._filters.Rarity = ERarity.NONE;
			this._currentBoard = EInventoryBoard.LOCKBOX;
			this._lockboxSorting = ELockboxSorting.CLASS;
			this._weaponSkinSorting = EWeaponSkinSorting.SKIN;
			this._accessorySorting = EAccessorySorting.NAME;
			this._lockboxSortingAscending = true;
			this._weaponSkinSortingAscending = true;
			this._accessorySortingAscending = true;
			this._lockboxSorterByClass = new LockboxSorterByClass();
			this._lockboxSorterBySeason = new LockboxSorterBySeason();
			this._skinSorterByWeaponName = new SkinSorterByWeaponName();
			this._skinSorterByRarity = new SkinSorterByRarity();
			this._skinSorterBySkinName = new SkinSorterBySkinName();
			this._accessorySorterByName = new AccessorySorterByName();
			this._inventoryService.OnNotificationChange += this.UpdateInventoryBoard;
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x0004851C File Offset: 0x0004671C
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localizationService.OnLanguageChange -= this.OnLanguageChange;
			this._inventoryService.OnNotificationChange -= this.UpdateInventoryBoard;
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x0000A116 File Offset: 0x00008316
		private void OnLanguageChange()
		{
			this.RebuildInventoryData();
			this.RefreshInventoryFiltered();
			this.RefreshInventorySorting();
			this.UpdateInventoryBoard();
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x00048568 File Offset: 0x00046768
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InventoryBoardView inventoryBoardView = view as InventoryBoardView;
			if (inventoryBoardView != null)
			{
				this.RebuildInventoryData();
				this.RefreshInventoryFiltered();
				this.RefreshInventorySorting();
				inventoryBoardView.SetSorting(this._lockboxSorting, this._lockboxSortingAscending, this._weaponSkinSorting, this._weaponSkinSortingAscending, this._accessorySorting, this._accessorySortingAscending);
				this.UpdateInventoryBoardRoot();
				this.UpdateInventoryBoard();
			}
			InventoryFilterSettingsView inventoryFilterSettingsView = view as InventoryFilterSettingsView;
			if (inventoryFilterSettingsView != null)
			{
				inventoryFilterSettingsView.HeroesDropdown(this._heroClasses);
				inventoryFilterSettingsView.RaritiesDropdown(this._rarities);
				int num = 0;
				for (int i = 0; i < this._heroClasses.Length; i++)
				{
					if (this._heroClasses[i] == this._filters.Class)
					{
						num = i;
						break;
					}
				}
				int num2 = 0;
				for (int j = 0; j < this._rarities.Length; j++)
				{
					if (this._rarities[j] == this._filters.Rarity)
					{
						num2 = j;
						break;
					}
				}
				inventoryFilterSettingsView.SetData(num, num2, this._filters.Category.IsSet(EWeaponCategory.AssaultRifle), this._filters.Category.IsSet(EWeaponCategory.SniperRifle), this._filters.Category.IsSet(EWeaponCategory.LightMachineGun), this._filters.Category.IsSet(EWeaponCategory.SubMachineGun), this._filters.Category.IsSet(EWeaponCategory.MachinePistol), this._filters.Category.IsSet(EWeaponCategory.Shotgun), this._filters.Category.IsSet(EWeaponCategory.Sidearm), this._filters.Category.IsSet(EWeaponCategory.MeleeSpecial), this._filters.Category.IsSet(EWeaponCategory.Concussion), this._filters.Category.IsSet(EWeaponCategory.GrenadeLauncher));
			}
			LockboxAvaliableItemsView lockboxAvaliableItemsView = view as LockboxAvaliableItemsView;
			if (lockboxAvaliableItemsView != null)
			{
				List<WeaponSkinData> list = new List<WeaponSkinData>();
				bool flag = false;
				using (List<WeaponDropItem>.Enumerator enumerator = this._currentLockbox.Lockbox.ItemDropList.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						WeaponDropItem dropItem = enumerator.Current;
						WeaponV4 weaponV = this._weaponData.FirstOrDefault((WeaponV4 t) => t.ItemId == dropItem.WeaponIndex);
						if (weaponV != null)
						{
							WeaponSkin weaponSkin = new WeaponSkin(dropItem.SkinName);
							if (weaponSkin.Rarity == ERarity.LEGENDARY)
							{
								flag = true;
							}
							else
							{
								string weaponName = ServiceProvider.GetService<LocalizationService>().GetWeaponName(weaponV.ItemName, weaponSkin.WeaponSkinName, ELocalizedTextCase.UPPER_CASE);
								list.Add(new WeaponSkinData
								{
									Weapon = weaponV,
									WeaponSkin = weaponSkin,
									SteamItem = null,
									CurrentName = weaponName
								});
							}
						}
					}
				}
				list.Sort(this._skinSorterByRarity);
				list.Reverse();
				lockboxAvaliableItemsView.SetData(flag, list);
			}
			LockboxModelView lockboxModelView = view as LockboxModelView;
			if (lockboxModelView != null)
			{
				lockboxModelView.SetModel(this._currentLockbox);
			}
			LockboxTitleView lockboxTitleView = view as LockboxTitleView;
			if (lockboxTitleView != null)
			{
				lockboxTitleView.SetData(this._currentLockbox);
			}
			LockboxButtonsView lockboxButtonsView = view as LockboxButtonsView;
			if (lockboxButtonsView != null)
			{
				lockboxButtonsView.SetData(this._currentLockbox);
			}
			SkinTitleView skinTitleView = view as SkinTitleView;
			if (skinTitleView != null)
			{
				skinTitleView.SetData(this._currentWeaponSkin);
			}
			SkinButtonsView skinButtonsView = view as SkinButtonsView;
			if (skinButtonsView != null)
			{
				skinButtonsView.SetData(this._currentWeaponSkin, this._inventoryData.Scraps.Count <= 0 || this._inventoryData.Scraps[0].Quantity < 60000U);
			}
			SkinModelView skinModelView = view as SkinModelView;
			if (skinModelView != null)
			{
				skinModelView.SetData(this._currentWeaponSkin);
			}
			AccessoryModelView accessoryModelView = view as AccessoryModelView;
			if (accessoryModelView != null)
			{
				accessoryModelView.SetData(this._currentAccessory);
			}
			AccessoryTitleView accessoryTitleView = view as AccessoryTitleView;
			if (accessoryTitleView != null)
			{
				accessoryTitleView.SetData(this._currentAccessory);
			}
			AccessoryRenderView accessoryRenderView = view as AccessoryRenderView;
			if (accessoryRenderView != null)
			{
				accessoryRenderView.SetData(InventoryController.GetRequerimentListIsCompleted(this._currentAccessory));
			}
		}

		// Token: 0x06000BDE RID: 3038 RVA: 0x000489E8 File Offset: 0x00046BE8
		private void UpdateInventoryBoardRoot()
		{
			InventoryBoardView view = base.GetView<InventoryBoardView>();
			if (view == null)
			{
				return;
			}
			view.SetRoot(this._currentBoard);
		}

		// Token: 0x06000BDF RID: 3039 RVA: 0x00048A18 File Offset: 0x00046C18
		internal void UpdateInventoryBoard()
		{
			InventoryBoardView view = base.GetView<InventoryBoardView>();
			if (view == null)
			{
				return;
			}
			view.SetData(this._inventoryData, this._inventoryService.Container, this._lockboxSortingAscending, this._weaponSkinSortingAscending, this._accessorySortingAscending);
			InventoryMenuView view2 = base.GetView<InventoryMenuView>();
			if (view2 == null)
			{
				return;
			}
			int num = ServiceProvider.GetService<PlayerHeroSkinService>().GetAvailableAccessories(true).Count<Accessory>();
			view2.SetData(this._inventoryData, (num <= 0) ? 0 : num);
		}

		// Token: 0x06000BE0 RID: 3040 RVA: 0x00048AA4 File Offset: 0x00046CA4
		internal void RebuildInventoryData()
		{
			List<SteamItem> list;
			InventoryController.CheckList<LockboxData>(ref this._inventoryData.Lockboxes, this._inventoryService.GetCachedLockboxes(), out list);
			using (List<SteamItem>.Enumerator enumerator = list.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					SteamItem item2 = enumerator.Current;
					Lockbox lockbox = this._lockboxData.FirstOrDefault((Lockbox t) => t.GetLockboxId() == item2.IdentityId);
					if (lockbox != null)
					{
						string lockboxName = ServiceProvider.GetService<LocalizationService>().GetLockboxName(lockbox.HeroClass, lockbox.Season, ELocalizedTextCase.NONE);
						this._inventoryData.Lockboxes.Add(new LockboxData
						{
							Lockbox = lockbox,
							SteamItem = item2,
							CurrentName = lockboxName
						});
					}
				}
			}
			InventoryController.CheckList<WeaponSkinData>(ref this._inventoryData.WeaponSkins, this._inventoryService.GetCachedWeaponSkins(), out list);
			using (List<SteamItem>.Enumerator enumerator2 = list.GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					SteamItem item = enumerator2.Current;
					WeaponV4 weaponV = this._weaponData.FirstOrDefault((WeaponV4 t) => t.HasIdentity(item.IdentityId));
					if (weaponV != null)
					{
						WeaponSkin weaponSkinByIdentity = weaponV.GetWeaponSkinByIdentity(item.IdentityId);
						string weaponName = ServiceProvider.GetService<LocalizationService>().GetWeaponName(weaponV.ItemName, weaponSkinByIdentity.WeaponSkinName, ELocalizedTextCase.NONE);
						this._inventoryData.WeaponSkins.Add(new WeaponSkinData
						{
							Weapon = weaponV,
							WeaponSkin = weaponSkinByIdentity,
							SteamItem = item,
							CurrentName = weaponName
						});
					}
				}
			}
			InventoryController.CheckList<VanityData>(ref this._inventoryData.VanityData, this._inventoryService.GetCachedVanities(), out list);
			this._inventoryData.Scraps = this._inventoryService.GetCachedScraps();
			this._inventoryData.GoldScraps = this._inventoryService.GetCachedGoldScraps();
		}

		// Token: 0x06000BE1 RID: 3041 RVA: 0x00048CDC File Offset: 0x00046EDC
		internal void RefreshInventoryFiltered()
		{
			bool categoryIsSet = this._filters.Category.IsSet(EWeaponCategory.AssaultRifle) || this._filters.Category.IsSet(EWeaponCategory.SniperRifle) || this._filters.Category.IsSet(EWeaponCategory.LightMachineGun) || this._filters.Category.IsSet(EWeaponCategory.SubMachineGun) || this._filters.Category.IsSet(EWeaponCategory.MachinePistol) || this._filters.Category.IsSet(EWeaponCategory.Shotgun) || this._filters.Category.IsSet(EWeaponCategory.Sidearm) || this._filters.Category.IsSet(EWeaponCategory.Melee) || this._filters.Category.IsSet(EWeaponCategory.MeleeSpecial) || this._filters.Category.IsSet(EWeaponCategory.Concussion) || this._filters.Category.IsSet(EWeaponCategory.GrenadeLauncher);
			InventoryController.SetVisible<LockboxData>(ref this._inventoryData.Lockboxes, (LockboxData t) => !this.IsFilteredByName(t.CurrentName) && (this._filters.Class == EHeroClass.NONE || this._filters.Class == t.Lockbox.HeroClass));
			InventoryController.SetVisible<WeaponSkinData>(ref this._inventoryData.WeaponSkins, (WeaponSkinData t) => !this.IsFilteredByName(t.CurrentName) && (this._filters.Class == EHeroClass.NONE || t.Weapon.AvailableForHero == this._filters.Class) && (!categoryIsSet || this._filters.Category.IsSet(t.Weapon.Category)) && (this._filters.Rarity == ERarity.NONE || t.WeaponSkin.Rarity == this._filters.Rarity));
			InventoryController.SetVisible<VanityData>(ref this._inventoryData.VanityData, (VanityData t) => false);
		}

		// Token: 0x06000BE2 RID: 3042 RVA: 0x0000A130 File Offset: 0x00008330
		private bool IsFilteredByName(string currentName)
		{
			return !string.IsNullOrEmpty(this._filters.Name) && !currentName.ToLowerInvariant().Contains(this._filters.Name.ToLowerInvariant());
		}

		// Token: 0x06000BE3 RID: 3043 RVA: 0x00048E54 File Offset: 0x00047054
		internal void RefreshInventorySorting()
		{
			ELockboxSorting lockboxSorting = this._lockboxSorting;
			if (lockboxSorting != ELockboxSorting.CLASS)
			{
				if (lockboxSorting != ELockboxSorting.SEASON)
				{
					string all2 = this._localizationService.Get("all", ELocalizedTextCase.NONE);
					InventoryController.SortAndCollect<LockboxData>(ref this._inventoryData.Lockboxes, ref this._inventoryData.LockboxDictionary, this._lockboxSorterByClass, (LockboxData t) => all2);
				}
				else
				{
					InventoryController.SortAndCollect<LockboxData>(ref this._inventoryData.Lockboxes, ref this._inventoryData.LockboxDictionary, this._lockboxSorterBySeason, (LockboxData t) => this._localizationService.GetSeasonName(t.Lockbox.Season, ELocalizedTextCase.NONE));
				}
			}
			else
			{
				InventoryController.SortAndCollect<LockboxData>(ref this._inventoryData.Lockboxes, ref this._inventoryData.LockboxDictionary, this._lockboxSorterByClass, (LockboxData t) => this._localizationService.GetClassName(t.Lockbox.HeroClass, ELocalizedTextCase.UPPER_CASE));
			}
			EWeaponSkinSorting weaponSkinSorting = this._weaponSkinSorting;
			switch (weaponSkinSorting)
			{
			case EWeaponSkinSorting.NAME:
				InventoryController.SortAndCollect<WeaponSkinData>(ref this._inventoryData.WeaponSkins, ref this._inventoryData.WeaponSkinDictionary, this._skinSorterByWeaponName, (WeaponSkinData t) => this._localizationService.GetWeaponName(t.Weapon.ItemName, ELocalizedTextCase.UPPER_CASE));
				break;
			case EWeaponSkinSorting.SKIN:
				InventoryController.SortAndCollect<WeaponSkinData>(ref this._inventoryData.WeaponSkins, ref this._inventoryData.WeaponSkinDictionary, this._skinSorterBySkinName, (WeaponSkinData t) => this._localizationService.GetWeaponSkinName(t.WeaponSkin.WeaponSkinName, ELocalizedTextCase.NONE));
				break;
			case EWeaponSkinSorting.RARITY:
				InventoryController.SortAndCollect<WeaponSkinData>(ref this._inventoryData.WeaponSkins, ref this._inventoryData.WeaponSkinDictionary, this._skinSorterByRarity, (WeaponSkinData t) => this._localizationService.GetRarityName(t.WeaponSkin.Rarity));
				break;
			default:
			{
				string all = this._localizationService.Get("all", ELocalizedTextCase.NONE);
				InventoryController.SortAndCollect<WeaponSkinData>(ref this._inventoryData.WeaponSkins, ref this._inventoryData.WeaponSkinDictionary, this._skinSorterByRarity, (WeaponSkinData t) => all);
				break;
			}
			}
			EAccessorySorting accessorySorting = this._accessorySorting;
			if (accessorySorting != EAccessorySorting.NAME)
			{
				this._inventoryData.Accessories.Sort(this._accessorySorterByName);
			}
			else
			{
				this._inventoryData.Accessories.Sort(this._accessorySorterByName);
			}
		}

		// Token: 0x06000BE4 RID: 3044 RVA: 0x0000A168 File Offset: 0x00008368
		internal void DispatchBoardChanged(EInventoryBoard board)
		{
			this._currentBoard = board;
			this.UpdateInventoryBoardRoot();
		}

		// Token: 0x06000BE5 RID: 3045 RVA: 0x0000A177 File Offset: 0x00008377
		internal void SetSorting(ELockboxSorting lockboxSorting, bool ascending)
		{
			this._lockboxSorting = lockboxSorting;
			this._lockboxSortingAscending = ascending;
		}

		// Token: 0x06000BE6 RID: 3046 RVA: 0x0000A187 File Offset: 0x00008387
		internal void SetSorting(EWeaponSkinSorting weaponSkinSorting, bool ascending)
		{
			this._weaponSkinSorting = weaponSkinSorting;
			this._weaponSkinSortingAscending = ascending;
		}

		// Token: 0x06000BE7 RID: 3047 RVA: 0x0000A197 File Offset: 0x00008397
		internal void SetSorting(EAccessorySorting accessorySorting, bool ascending)
		{
			this._accessorySorting = accessorySorting;
			this._accessorySortingAscending = ascending;
		}

		// Token: 0x06000BE8 RID: 3048 RVA: 0x0000A1A7 File Offset: 0x000083A7
		internal void SetFilterName(string name)
		{
			this._filters.Name = name;
		}

		// Token: 0x06000BE9 RID: 3049 RVA: 0x0000A1B5 File Offset: 0x000083B5
		internal void SetFilterClass(EHeroClass heroClass)
		{
			this._filters.Class = heroClass;
		}

		// Token: 0x06000BEA RID: 3050 RVA: 0x0000A1C3 File Offset: 0x000083C3
		internal void SetFilterRarity(ERarity rarity)
		{
			this._filters.Rarity = rarity;
		}

		// Token: 0x06000BEB RID: 3051 RVA: 0x0000A1D1 File Offset: 0x000083D1
		internal void SetFilterCategory(EWeaponCategory category, bool enabled)
		{
			if (enabled)
			{
				this._filters.Category.Set(category);
			}
			else
			{
				this._filters.Category.Clear(category);
			}
		}

		// Token: 0x06000BEC RID: 3052 RVA: 0x0000A200 File Offset: 0x00008400
		internal void OpenLockbox(LockboxData lockboxData)
		{
			this._currentLockbox = lockboxData;
			this._inventoryService.ExchangeLockbox(lockboxData.Lockbox, new Action<bool, SteamItem[]>(this.OnLockboxOpened));
		}

		// Token: 0x06000BED RID: 3053 RVA: 0x0000A226 File Offset: 0x00008426
		internal void DisassemblyWeaponSkin(WeaponSkinData weaponSkinData)
		{
			this._currentWeaponSkin = weaponSkinData;
			ServiceProvider.GetService<PopupService>().Show(EPopupType.STEAM_CONFIRMATION, null, new Action<int>(this.OnWeaponDisassembleConfirmation), null, 0f);
		}

		// Token: 0x06000BEE RID: 3054 RVA: 0x0000A24E File Offset: 0x0000844E
		internal void ClaimLockbox()
		{
			this._inventoryService.ExchangeScraps(new Action<bool, SteamItem[]>(this.OnScrapChangeCompleted));
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x0000A267 File Offset: 0x00008467
		internal void ClaimGoldLockbox()
		{
			this._inventoryService.ExchangeGoldScraps(new Action<bool, SteamItem[]>(this.OnScrapChangeCompleted));
		}

		// Token: 0x06000BF0 RID: 3056 RVA: 0x0004908C File Offset: 0x0004728C
		private void OnWeaponDisassembleConfirmation(int result)
		{
			if (result == 2)
			{
				this._inventoryService.ExchangeWeapons(this._currentWeaponSkin, new Action<bool, SteamItem[]>(this.OnWeaponDisassembled));
			}
			else
			{
				SkinButtonsView view = base.GetView<SkinButtonsView>();
				if (view != null)
				{
					view.SetData(this._currentWeaponSkin, this._inventoryData.Scraps.Count <= 0 || this._inventoryData.Scraps[0].Quantity < 60000U);
				}
			}
			ServiceProvider.GetService<PopupService>().Hide(EPopupType.STEAM_CONFIRMATION);
		}

		// Token: 0x06000BF1 RID: 3057 RVA: 0x00049124 File Offset: 0x00047324
		private void OnLockboxOpened(bool value, SteamItem[] steamItems)
		{
			if (!value)
			{
				UIManager.Instance.DisableLayer(1);
				ServiceProvider.GetService<PopupService>().Show(EPopupType.STEAM_ACTION_FAILED, null, null, null, 0f);
				Debug.LogWarning("Could not finish transaction.");
				return;
			}
			WeaponV4 weaponV = this._weaponData.FirstOrDefault((WeaponV4 t) => t.HasIdentity(steamItems[0].IdentityId));
			if (weaponV == null)
			{
				Debug.LogWarning("Could not find associated weapon.[" + steamItems[0].IdentityId + "]");
				return;
			}
			WeaponSkin weaponSkinByIdentity = weaponV.GetWeaponSkinByIdentity(steamItems[0].IdentityId);
			string weaponName = ServiceProvider.GetService<LocalizationService>().GetWeaponName(weaponV.ItemName, weaponSkinByIdentity.WeaponSkinName, ELocalizedTextCase.NONE);
			WeaponSkinData skinData = new WeaponSkinData
			{
				Weapon = weaponV,
				WeaponSkin = weaponSkinByIdentity,
				SteamItem = steamItems[0],
				CurrentName = weaponName
			};
			LockboxModelView view = base.GetView<LockboxModelView>();
			if (view != null)
			{
				view.SetData(this._currentLockbox, skinData);
			}
			LockboxItemInfoView view2 = base.GetView<LockboxItemInfoView>();
			if (view2 != null)
			{
				view2.SetData(skinData, !this._inventoryData.WeaponSkins.Any((WeaponSkinData t) => t.SteamItem.IdentityId == skinData.SteamItem.IdentityId));
			}
			bool flag = this._filters.Category.IsSet(EWeaponCategory.AssaultRifle) || this._filters.Category.IsSet(EWeaponCategory.SniperRifle) || this._filters.Category.IsSet(EWeaponCategory.LightMachineGun) || this._filters.Category.IsSet(EWeaponCategory.SubMachineGun) || this._filters.Category.IsSet(EWeaponCategory.MachinePistol) || this._filters.Category.IsSet(EWeaponCategory.Shotgun) || this._filters.Category.IsSet(EWeaponCategory.Sidearm) || this._filters.Category.IsSet(EWeaponCategory.Melee) || this._filters.Category.IsSet(EWeaponCategory.MeleeSpecial) || this._filters.Category.IsSet(EWeaponCategory.Concussion) || this._filters.Category.IsSet(EWeaponCategory.GrenadeLauncher);
			skinData.Visible = (string.IsNullOrEmpty(this._filters.Name) || skinData.CurrentName.StartsWith(this._filters.Name)) && (this._filters.Class == EHeroClass.NONE || skinData.Weapon.AvailableForHero == this._filters.Class) && (!flag || this._filters.Category.IsSet(skinData.Weapon.Category)) && (this._filters.Rarity == ERarity.NONE || skinData.WeaponSkin.Rarity == this._filters.Rarity);
			this._inventoryData.WeaponSkins.Add(skinData);
			this._telemetryService.SubmitLockboxOpen(this._currentLockbox.Lockbox.HeroClass, this._currentLockbox.Lockbox.Season, skinData.WeaponSkin.WeaponSkinName + " " + skinData.Weapon.ItemName, skinData.WeaponSkin.Rarity);
			this._inventoryData.Lockboxes.Remove(this._currentLockbox);
			this.RefreshInventorySorting();
			this.UpdateInventoryBoard();
			ERarity rarity = skinData.WeaponSkin.Rarity;
			switch (rarity)
			{
			case ERarity.COMMON:
				ServiceProvider.GetService<SoundService>().DispatchToMasterAudio("sfx_ui_lockbox_open_tier1");
				break;
			case ERarity.ADVANCED:
				ServiceProvider.GetService<SoundService>().DispatchToMasterAudio("sfx_ui_lockbox_open_tier2");
				break;
			case ERarity.SPECIAL:
				ServiceProvider.GetService<SoundService>().DispatchToMasterAudio("sfx_ui_lockbox_open_tier3");
				break;
			case ERarity.ELITE:
				ServiceProvider.GetService<SoundService>().DispatchToMasterAudio("sfx_ui_lockbox_open_tier4");
				break;
			case ERarity.LEGENDARY:
				ServiceProvider.GetService<SoundService>().DispatchToMasterAudio("sfx_ui_lockbox_open_tier5");
				break;
			default:
				if (rarity != ERarity.LEGACY)
				{
					if (rarity == ERarity.RANKED)
					{
						ServiceProvider.GetService<SoundService>().DispatchToMasterAudio("sfx_ui_lockbox_open_tier5");
					}
				}
				else
				{
					ServiceProvider.GetService<SoundService>().DispatchToMasterAudio("sfx_ui_lockbox_open_tier4");
				}
				break;
			}
			this._eventSystem.DispatchEvent("lockbox_open", new object[] { 16 });
			UIManager.Instance.ChangeState("INVENTORY_LOCKBOX_OPEN");
		}

		// Token: 0x06000BF2 RID: 3058 RVA: 0x000495E8 File Offset: 0x000477E8
		private void OnWeaponDisassembled(bool value, SteamItem[] scrapItems)
		{
			UIManager.Instance.DisableLayer(1);
			if (!value)
			{
				ServiceProvider.GetService<PopupService>().Show(EPopupType.STEAM_ACTION_FAILED, null, null, null, 0f);
				Debug.LogWarning("Could not finish transaction.");
				return;
			}
			this._inventoryData.Scraps = this._inventoryService.GetCachedScraps();
			this._inventoryData.GoldScraps = this._inventoryService.GetCachedGoldScraps();
			this._telemetryService.SubmitDisassembly(this._currentWeaponSkin.WeaponSkin.WeaponSkinName + " " + this._currentWeaponSkin.Weapon.ItemName, this._currentWeaponSkin.WeaponSkin.Rarity, scrapItems.Sum((SteamItem t) => (int)t.Quantity));
			this._inventoryData.WeaponSkins.Remove(this._currentWeaponSkin);
			this.RefreshInventorySorting();
			this.UpdateInventoryBoard();
			uint num = (uint)scrapItems.Sum((SteamItem t) => (long)((ulong)t.Quantity));
			ScrapData scrapData = new ScrapData
			{
				SteamItem = scrapItems.FirstOrDefault<SteamItem>(),
				CurrentName = string.Format(ServiceProvider.GetService<LocalizationService>().Get("popup_scraps_received_message", ELocalizedTextCase.NONE), num),
				Amount = num,
				Visible = false
			};
			ServiceProvider.GetService<PopupService>().ShowUnlockScraps(scrapData);
		}

		// Token: 0x06000BF3 RID: 3059 RVA: 0x00049754 File Offset: 0x00047954
		private void OnScrapChangeCompleted(bool value, SteamItem[] lockboxItems)
		{
			if (!value)
			{
				ServiceProvider.GetService<PopupService>().Show(EPopupType.STEAM_ACTION_FAILED, null, null, null, 0f);
				Debug.LogWarning("Could not finish transaction.");
				return;
			}
			this._inventoryData.Scraps = this._inventoryService.GetCachedScraps();
			Lockbox lockbox = this._lockboxData.FirstOrDefault((Lockbox t) => t.GetLockboxId() == lockboxItems[0].IdentityId);
			if (lockbox == null)
			{
				ServiceProvider.GetService<PopupService>().Show(EPopupType.STEAM_ACTION_FAILED, null, null, null, 0f);
				Debug.LogWarning("Claimed lockbox doesnt exist!.");
				return;
			}
			string lockboxName = ServiceProvider.GetService<LocalizationService>().GetLockboxName(lockbox.HeroClass, lockbox.Season, ELocalizedTextCase.NONE);
			LockboxData lockboxData = new LockboxData
			{
				Lockbox = lockbox,
				SteamItem = lockboxItems[0],
				CurrentName = lockboxName
			};
			lockboxData.Visible = (string.IsNullOrEmpty(this._filters.Name) || lockboxData.CurrentName.StartsWith(this._filters.Name)) && (this._filters.Class == EHeroClass.NONE || this._filters.Class == lockboxData.Lockbox.HeroClass);
			this._inventoryData.Lockboxes.Add(lockboxData);
			this.RefreshInventorySorting();
			this.UpdateInventoryBoard();
			this._telemetryService.SubmitScrapsExchange(lockboxData.Lockbox.HeroClass, lockboxData.Lockbox.Season);
			ServiceProvider.GetService<PopupService>().ShowUnlockLockbox(lockboxData);
		}

		// Token: 0x06000BF4 RID: 3060 RVA: 0x0000A280 File Offset: 0x00008480
		internal void DispatchLockboxClicked(LockboxData lockboxData)
		{
			this._currentLockbox = lockboxData;
		}

		// Token: 0x06000BF5 RID: 3061 RVA: 0x0000A289 File Offset: 0x00008489
		internal void DispatchWeaponSkinClicked(WeaponSkinData weaponSkinData)
		{
			this._currentWeaponSkin = weaponSkinData;
		}

		// Token: 0x06000BF6 RID: 3062 RVA: 0x0000A292 File Offset: 0x00008492
		public void DispatchAccessoryClicked(Accessory accessory)
		{
			this._currentAccessory = accessory;
		}

		// Token: 0x06000BF7 RID: 3063 RVA: 0x000498D4 File Offset: 0x00047AD4
		private static void SetVisible<T>(ref List<T> itemList, Predicate<T> predicate) where T : SteamItemData
		{
			foreach (T t in itemList)
			{
				t.Visible = predicate(t);
			}
		}

		// Token: 0x06000BF8 RID: 3064 RVA: 0x00049938 File Offset: 0x00047B38
		private static void CheckList<T>(ref List<T> itemList, ICollection<SteamItem> steamItems, out List<SteamItem> toAdd) where T : SteamItemData
		{
			List<T> list = itemList.Where((T item) => !steamItems.Contains(item.SteamItem)).ToList<T>();
			toAdd = new List<SteamItem>();
			using (IEnumerator<SteamItem> enumerator = steamItems.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					SteamItem steamItem = enumerator.Current;
					if (!itemList.Exists((T t) => t.SteamItem.InstanceId == steamItem.InstanceId))
					{
						toAdd.Add(steamItem);
					}
				}
			}
			foreach (T t2 in list)
			{
				itemList.Remove(t2);
			}
		}

		// Token: 0x06000BF9 RID: 3065 RVA: 0x00049A34 File Offset: 0x00047C34
		private static void SortAndCollect<T>(ref List<T> itemList, ref Dictionary<string, List<T>> dictionary, IComparer<T> comparer, Func<T, string> dictionaryKey) where T : SteamItemData
		{
			for (int i = 0; i < itemList.Count; i++)
			{
				for (int j = i + 1; j < itemList.Count; j++)
				{
					if (comparer.Compare(itemList[i], itemList[j]) < 0)
					{
						T t = itemList[i];
						itemList[i] = itemList[j];
						itemList[j] = t;
					}
				}
			}
			dictionary.Clear();
			foreach (T t2 in itemList)
			{
				string text = dictionaryKey(t2);
				if (!dictionary.ContainsKey(text))
				{
					dictionary.Add(text, new List<T> { t2 });
				}
				else
				{
					dictionary[text].Add(t2);
				}
			}
		}

		// Token: 0x06000BFA RID: 3066 RVA: 0x00049B48 File Offset: 0x00047D48
		internal static List<RequirementConfig> GetRequirementList(Accessory accessory, out int requeriments, out int completed)
		{
			List<SteamItem> cachedWeaponSkins = ServiceProvider.GetService<InventoryService>().GetCachedWeaponSkins();
			IEnumerable<WeaponV4> itemsOfType = ServiceProvider.GetService<GameItemService>().GetItemsOfType<WeaponV4>();
			requeriments = 0;
			completed = 0;
			List<RequirementConfig> list = new List<RequirementConfig>();
			foreach (WeaponSkinRequeriment weaponSkinRequeriment in accessory.WeaponSkinRequeriments)
			{
				requeriments++;
				RequirementConfig requirementConfig = new RequirementConfig
				{
					Type = ERequirementType.SPECIFIC,
					SpecificWeapon = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(weaponSkinRequeriment.WeaponIndex),
					SpecificSkin = new WeaponSkin(weaponSkinRequeriment.SkinName)
				};
				int steamWeaponSkinId = requirementConfig.SpecificWeapon.GetSteamWeaponSkinId(requirementConfig.SpecificSkin.WeaponSkinName);
				requirementConfig.SpecificCompleted = ServiceProvider.GetService<InventoryService>().HasWeaponSkin(steamWeaponSkinId);
				if (requirementConfig.SpecificCompleted)
				{
					completed++;
				}
				list.Add(requirementConfig);
			}
			foreach (SkinRequeriment skinRequeriment in accessory.WeaponSkinAmount)
			{
				InventoryController.<GetRequirementList>c__AnonStoreyA <GetRequirementList>c__AnonStoreyA = new InventoryController.<GetRequirementList>c__AnonStoreyA();
				requeriments += skinRequeriment.Amount;
				InventoryController._internalSkinName = skinRequeriment.WeaponSkinName;
				<GetRequirementList>c__AnonStoreyA.weaponsOfType = cachedWeaponSkins.FindAll(new Predicate<SteamItem>(InventoryController.IdentityIsEqual));
				completed += ((<GetRequirementList>c__AnonStoreyA.weaponsOfType.Count <= skinRequeriment.Amount) ? <GetRequirementList>c__AnonStoreyA.weaponsOfType.Count : skinRequeriment.Amount);
				int i = 0;
				while (i < <GetRequirementList>c__AnonStoreyA.weaponsOfType.Count && i < skinRequeriment.Amount)
				{
					RequirementConfig requirementConfig2 = new RequirementConfig
					{
						Type = ERequirementType.SPECIFIC,
						SpecificWeapon = itemsOfType.FirstOrDefault((WeaponV4 t) => t.GetSteamWeaponSkinId(InventoryController._internalSkinName) == <GetRequirementList>c__AnonStoreyA.weaponsOfType[i].IdentityId),
						SpecificCompleted = true
					};
					requirementConfig2.SpecificSkin = new WeaponSkin(skinRequeriment.WeaponSkinName);
					list.Add(requirementConfig2);
					i++;
				}
				if (<GetRequirementList>c__AnonStoreyA.weaponsOfType.Count < skinRequeriment.Amount)
				{
					RequirementConfig requirementConfig3 = new RequirementConfig
					{
						Type = ERequirementType.COLLECTION,
						CollectionWeaponSkinName = skinRequeriment.WeaponSkinName,
						CollectionAmountRemaining = skinRequeriment.Amount - <GetRequirementList>c__AnonStoreyA.weaponsOfType.Count,
						CollectionAmountTotal = skinRequeriment.Amount
					};
					list.Add(requirementConfig3);
				}
			}
			return list;
		}

		// Token: 0x06000BFB RID: 3067 RVA: 0x00049E44 File Offset: 0x00048044
		internal static bool GetRequerimentListIsCompleted(Accessory accessory)
		{
			List<SteamItem> cachedWeaponSkins = ServiceProvider.GetService<InventoryService>().GetCachedWeaponSkins();
			int num = 0;
			int num2 = 0;
			foreach (WeaponSkinRequeriment weaponSkinRequeriment in accessory.WeaponSkinRequeriments)
			{
				num++;
				RequirementConfig requirementConfig = new RequirementConfig
				{
					Type = ERequirementType.SPECIFIC,
					SpecificWeapon = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(weaponSkinRequeriment.WeaponIndex)
				};
				requirementConfig.SpecificSkin = new WeaponSkin(weaponSkinRequeriment.SkinName);
				int steamWeaponSkinId = requirementConfig.SpecificWeapon.GetSteamWeaponSkinId(requirementConfig.SpecificSkin.WeaponSkinName);
				requirementConfig.SpecificCompleted = ServiceProvider.GetService<InventoryService>().HasWeaponSkin(steamWeaponSkinId);
				if (requirementConfig.SpecificCompleted)
				{
					num2++;
				}
			}
			foreach (SkinRequeriment skinRequeriment in accessory.WeaponSkinAmount)
			{
				num += skinRequeriment.Amount;
				InventoryController._internalSkinName = skinRequeriment.WeaponSkinName;
				List<SteamItem> list = cachedWeaponSkins.FindAll(new Predicate<SteamItem>(InventoryController.IdentityIsEqual));
				num2 += ((list.Count <= skinRequeriment.Amount) ? list.Count : skinRequeriment.Amount);
			}
			return num2 == num;
		}

		// Token: 0x06000BFC RID: 3068 RVA: 0x0000A29B File Offset: 0x0000849B
		private static bool IdentityIsEqual(SteamItem item)
		{
			return item.IdentityId % 1000 == (int)InventoryController._internalSkinName;
		}

		// Token: 0x04000F0D RID: 3853
		private readonly UIEventSystem _eventSystem;

		// Token: 0x04000F0E RID: 3854
		private readonly InventoryService _inventoryService;

		// Token: 0x04000F0F RID: 3855
		private readonly LocalizationService _localizationService;

		// Token: 0x04000F10 RID: 3856
		private readonly TelemetryService _telemetryService;

		// Token: 0x04000F11 RID: 3857
		private readonly Lockbox[] _lockboxData;

		// Token: 0x04000F12 RID: 3858
		private readonly WeaponV4[] _weaponData;

		// Token: 0x04000F13 RID: 3859
		private readonly InventoryData _inventoryData;

		// Token: 0x04000F14 RID: 3860
		private readonly LockboxSorterByClass _lockboxSorterByClass;

		// Token: 0x04000F15 RID: 3861
		private readonly LockboxSorterBySeason _lockboxSorterBySeason;

		// Token: 0x04000F16 RID: 3862
		private readonly SkinSorterByWeaponName _skinSorterByWeaponName;

		// Token: 0x04000F17 RID: 3863
		private readonly SkinSorterByRarity _skinSorterByRarity;

		// Token: 0x04000F18 RID: 3864
		private readonly SkinSorterBySkinName _skinSorterBySkinName;

		// Token: 0x04000F19 RID: 3865
		private readonly AccessorySorterByName _accessorySorterByName;

		// Token: 0x04000F1A RID: 3866
		private readonly EHeroClass[] _heroClasses = new EHeroClass[]
		{
			EHeroClass.NONE,
			EHeroClass.BERSERKER,
			EHeroClass.VANGUARD,
			EHeroClass.WRAITH,
			EHeroClass.SHADOW,
			EHeroClass.GRENADIER,
			EHeroClass.TANK,
			EHeroClass.MARKSMAN
		};

		// Token: 0x04000F1B RID: 3867
		private readonly ERarity[] _rarities = new ERarity[]
		{
			ERarity.NONE,
			ERarity.COMMON,
			ERarity.ADVANCED,
			ERarity.SPECIAL,
			ERarity.ELITE,
			ERarity.LEGENDARY
		};

		// Token: 0x04000F1C RID: 3868
		private InventorySearchFilters _filters;

		// Token: 0x04000F1D RID: 3869
		private ELockboxSorting _lockboxSorting;

		// Token: 0x04000F1E RID: 3870
		private EWeaponSkinSorting _weaponSkinSorting;

		// Token: 0x04000F1F RID: 3871
		private EAccessorySorting _accessorySorting;

		// Token: 0x04000F20 RID: 3872
		private bool _lockboxSortingAscending;

		// Token: 0x04000F21 RID: 3873
		private bool _weaponSkinSortingAscending;

		// Token: 0x04000F22 RID: 3874
		private bool _accessorySortingAscending;

		// Token: 0x04000F23 RID: 3875
		private EInventoryBoard _currentBoard;

		// Token: 0x04000F24 RID: 3876
		private LockboxData _currentLockbox;

		// Token: 0x04000F25 RID: 3877
		private WeaponSkinData _currentWeaponSkin;

		// Token: 0x04000F26 RID: 3878
		private Accessory _currentAccessory;

		// Token: 0x04000F27 RID: 3879
		private static EWeaponSkinName _internalSkinName;
	}
}
