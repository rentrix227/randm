﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200031B RID: 795
	public class SoldiersSkillsView : BaseView<SkillsController>
	{
		// Token: 0x060010D3 RID: 4307 RVA: 0x0006130C File Offset: 0x0005F50C
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.CurrentSkillPair.Skill1 != null)
			{
				SoldiersSkillComponent skill = this.CurrentSkillPair.Skill1;
				skill.OnSkillClicked = (Action<HeroSkillData>)Delegate.Combine(skill.OnSkillClicked, new Action<HeroSkillData>(this.OnSkill1Selected));
			}
			if (this.CurrentSkillPair.Skill2 != null)
			{
				SoldiersSkillComponent skill2 = this.CurrentSkillPair.Skill2;
				skill2.OnSkillClicked = (Action<HeroSkillData>)Delegate.Combine(skill2.OnSkillClicked, new Action<HeroSkillData>(this.OnSkill2Selected));
			}
		}

		// Token: 0x060010D4 RID: 4308 RVA: 0x0000DDD9 File Offset: 0x0000BFD9
		private void OnSkill1Selected(HeroSkillData skill)
		{
			base._controller.RequestSkillChange(0);
		}

		// Token: 0x060010D5 RID: 4309 RVA: 0x0000DDE7 File Offset: 0x0000BFE7
		private void OnSkill2Selected(HeroSkillData skill)
		{
			base._controller.RequestSkillChange(1);
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x0000DDF5 File Offset: 0x0000BFF5
		internal void SetSkills(List<List<HeroSkillData>> skills, int skillIndex)
		{
			this._skill1 = skills[skillIndex][0];
			this._skill2 = skills[skillIndex][1];
			this._skills = skills;
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x0000DE24 File Offset: 0x0000C024
		internal void SetStartSkills(List<List<HeroSkillData>> skills, int skillIndex)
		{
			this._skill1 = skills[skillIndex][0];
			this._skill2 = skills[skillIndex][1];
			this._skills = skills;
			this.ChangeDataComplete();
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x000613B0 File Offset: 0x0005F5B0
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.CurrentSkillPair.Skill1.SetData(this._skill1, false, true, -1);
			this.CurrentSkillPair.Skill2.SetData(this._skill2, false, true, -1);
			int num = 0;
			while (num < this.PreviewSkillPairs.Length && num < this._skills.Count)
			{
				this.PreviewSkillPairs[num].Skill1.SetData(this._skills[num][0], false, true, -1);
				this.PreviewSkillPairs[num].Skill2.SetData(this._skills[num][1], false, true, -1);
				num++;
			}
		}

		// Token: 0x060010D9 RID: 4313 RVA: 0x0000DE59 File Offset: 0x0000C059
		public void OnLoadoutChangeAnimEnd()
		{
			this.ChangeDataComplete();
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x0000DE61 File Offset: 0x0000C061
		public void SetImediateSkills(HeroSkillData skill1, HeroSkillData skill2)
		{
			this._skill1 = skill1;
			this._skill2 = skill2;
			this.ChangeDataComplete();
		}

		// Token: 0x0400160B RID: 5643
		public SoldiersSkillsView.SkillPair CurrentSkillPair;

		// Token: 0x0400160C RID: 5644
		public SoldiersSkillsView.SkillPair[] PreviewSkillPairs;

		// Token: 0x0400160D RID: 5645
		private HeroSkillData _skill1;

		// Token: 0x0400160E RID: 5646
		private HeroSkillData _skill2;

		// Token: 0x0400160F RID: 5647
		private List<List<HeroSkillData>> _skills;

		// Token: 0x0200031C RID: 796
		[Serializable]
		public struct SkillPair
		{
			// Token: 0x04001610 RID: 5648
			public SoldiersSkillComponent Skill1;

			// Token: 0x04001611 RID: 5649
			public SoldiersSkillComponent Skill2;
		}
	}
}
