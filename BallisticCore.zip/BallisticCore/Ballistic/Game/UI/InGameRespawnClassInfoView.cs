﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C5 RID: 709
	public class InGameRespawnClassInfoView : BaseView<InGameRespawnController>
	{
		// Token: 0x06000ED6 RID: 3798 RVA: 0x0000C12B File Offset: 0x0000A32B
		protected override void Start()
		{
			base.Start();
			this._progressionService = ServiceProvider.GetService<ProgressionService>();
		}

		// Token: 0x06000ED7 RID: 3799 RVA: 0x0000C13E File Offset: 0x0000A33E
		internal void SetStartData(bool isSpectator, PlayerHeroData playerHero)
		{
			this._isSpectator = isSpectator;
			this._playerHero = playerHero;
			this.ChangeDataComplete();
		}

		// Token: 0x06000ED8 RID: 3800 RVA: 0x0000C154 File Offset: 0x0000A354
		internal void SetData(bool isSpectator, PlayerHeroData playerHero)
		{
			this._isSpectator = isSpectator;
			this._playerHero = playerHero;
		}

		// Token: 0x06000ED9 RID: 3801 RVA: 0x000598E4 File Offset: 0x00057AE4
		public void ChangeDataComplete()
		{
			if (this.ScreenNameText != null)
			{
				if (this._isSpectator)
				{
					this.ScreenNameText.text = ServiceProvider.GetService<LocalizationService>().Get("team_spectatormode", ELocalizedTextCase.UPPER_CASE);
				}
				else
				{
					this.ScreenNameText.text = ServiceProvider.GetService<LocalizationService>().Get(this._playerHero.GameItemData.LocalizationKey, ELocalizedTextCase.UPPER_CASE);
				}
			}
			this.ClassInfoRoot.SetActive(!this._isSpectator);
			if (this._isSpectator)
			{
				return;
			}
			if (UserProfile.LocalGameClient.levels.ContainsKey((short)this._playerHero.GameItemData.GameItem.UniqueIdentifier))
			{
				if (ServiceProvider.GetService<ProgressionService>().CheckGoldClass((int)UserProfile.LocalGameClient.levels[(short)this._playerHero.GameItemData.GameItem.UniqueIdentifier]))
				{
					string goldClassIconPath = TextureHelper.GetGoldClassIconPath(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
					TextureHelper.LoadImageAsync(goldClassIconPath, this.HeroClassInfo, false, EImageSource.RESOURCES);
				}
				else
				{
					string classIconPath = TextureHelper.GetClassIconPath(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
					TextureHelper.LoadImageAsync(classIconPath, this.HeroClassInfo, false, EImageSource.RESOURCES);
				}
			}
			else
			{
				string classIconPath2 = TextureHelper.GetClassIconPath(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
				TextureHelper.LoadImageAsync(classIconPath2, this.HeroClassInfo, false, EImageSource.RESOURCES);
			}
			if (this.HeroLevelText != null)
			{
				this.HeroLevelText.text = this._progressionService.GetHeroClassLevel(this._playerHero.GameItemData.GameItem.UniqueIdentifier).ToString();
			}
			int heroClassLevelXp = this._progressionService.GetHeroClassLevelXp(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
			int heroClassMaxLevelXp = this._progressionService.GetHeroClassMaxLevelXp(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
			if (this.HeroXpText != null)
			{
				this.HeroXpText.text = heroClassLevelXp.ToString() + "/" + heroClassMaxLevelXp.ToString();
			}
			if (this.HeroProgressBar != null)
			{
				this.HeroProgressBar.material.SetFloat("_Scroll", (float)heroClassLevelXp / (float)((heroClassMaxLevelXp <= 0) ? 1 : heroClassMaxLevelXp));
			}
		}

		// Token: 0x040013DD RID: 5085
		private ProgressionService _progressionService;

		// Token: 0x040013DE RID: 5086
		public Text ScreenNameText;

		// Token: 0x040013DF RID: 5087
		public GameObject ClassInfoRoot;

		// Token: 0x040013E0 RID: 5088
		public RawImage HeroClassInfo;

		// Token: 0x040013E1 RID: 5089
		public Text HeroLevelText;

		// Token: 0x040013E2 RID: 5090
		public Text HeroXpText;

		// Token: 0x040013E3 RID: 5091
		public MeshRenderer HeroProgressBar;

		// Token: 0x040013E4 RID: 5092
		private bool _isSpectator;

		// Token: 0x040013E5 RID: 5093
		private PlayerHeroData _playerHero;
	}
}
