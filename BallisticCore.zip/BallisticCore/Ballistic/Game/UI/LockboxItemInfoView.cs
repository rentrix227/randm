﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E3 RID: 739
	public class LockboxItemInfoView : BaseView<InventoryController>
	{
		// Token: 0x06000F84 RID: 3972 RVA: 0x0000C118 File Offset: 0x0000A318
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
		}

		// Token: 0x06000F85 RID: 3973 RVA: 0x0005C3A8 File Offset: 0x0005A5A8
		internal void SetData(WeaponSkinData weaponSkinData, bool unlockedFirstTime)
		{
			this.LockboxTitleText.text = weaponSkinData.CurrentName.ToUpper();
			this.LockboxRarityText.text = ServiceProvider.GetService<LocalizationService>().GetRarityName(weaponSkinData.WeaponSkin.Rarity);
			this.LockboxRarityText.color = RarityHelper.GetRarityColor(weaponSkinData.WeaponSkin.Rarity);
			this.UnlockedFirstTime.SetActive(unlockedFirstTime);
		}

		// Token: 0x040014AE RID: 5294
		public Text LockboxTitleText;

		// Token: 0x040014AF RID: 5295
		public Text LockboxRarityText;

		// Token: 0x040014B0 RID: 5296
		public GameObject UnlockedFirstTime;
	}
}
