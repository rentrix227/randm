﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000263 RID: 611
	public class BasePlayerNameView<T> : BaseView<T> where T : BaseController
	{
		// Token: 0x06000D2D RID: 3373 RVA: 0x0004E64C File Offset: 0x0004C84C
		internal void SetData(string playerName, Texture texture, int rating)
		{
			this.PlayerNameText.text = playerName;
			this.PlayerImage.texture = texture;
			this.PlayerTitle.text = ServiceProvider.GetService<LocalizationService>().GetPlayerRankName(RatingUtil.GetSkillRatingTier(rating), ELocalizedTextCase.NONE);
			this.PlayerSkillRating.text = ServiceProvider.GetService<LocalizationService>().Get("level", ELocalizedTextCase.CAPITALIZE) + " " + rating;
			this.PlayerTierBadge.sprite = this.PlayerBadgeSprites[RatingUtil.GetSkillRatingTierNumber((float)rating)];
		}

		// Token: 0x04000FF8 RID: 4088
		public Text PlayerNameText;

		// Token: 0x04000FF9 RID: 4089
		public RawImage PlayerImage;

		// Token: 0x04000FFA RID: 4090
		public Image PlayerTierBadge;

		// Token: 0x04000FFB RID: 4091
		public Text PlayerTitle;

		// Token: 0x04000FFC RID: 4092
		public Text PlayerSkillRating;

		// Token: 0x04000FFD RID: 4093
		public Sprite[] PlayerBadgeSprites;
	}
}
