﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.UI.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001BE RID: 446
	public class ChoosePlayerComponent : PoolableComponent
	{
		// Token: 0x06000931 RID: 2353 RVA: 0x00008592 File Offset: 0x00006792
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x00038978 File Offset: 0x00036B78
		internal void SetData(int number, ClientCommonMetaData metaData, bool isOn, bool isActive, bool isSpectator, bool isFriend)
		{
			this._isOn = isOn;
			this._isPlayer = isActive;
			this._isFriend = isFriend;
			if (this.PlayerNumber != null)
			{
				this.PlayerNumber.text = number.ToString();
			}
			if (this.PlayerLevel != null)
			{
				if (metaData.Levels.ContainsKey(0))
				{
					this.PlayerLevel.text = (RatingUtil.GetSkillRatingTierNumber((float)metaData.Levels[0]) + 1).ToString();
				}
				else
				{
					this.PlayerLevel.text = (RatingUtil.GetSkillRatingTierNumber(0f) + 1).ToString();
				}
			}
			if (this.PlayerBadge != null)
			{
				if (metaData.Levels.ContainsKey(0))
				{
					this.PlayerBadge.sprite = this.PlayerBadgeSprites[RatingUtil.GetSkillRatingTierNumber((float)metaData.Levels[0])];
				}
				else
				{
					this.PlayerBadge.sprite = this.PlayerBadgeSprites[RatingUtil.GetSkillRatingTierNumber(0f)];
				}
			}
			if (this.SpectatorCameraImage != null && this.SpectatorCameraImage.gameObject.activeSelf != isSpectator)
			{
				this.SpectatorCameraImage.gameObject.SetActive(isSpectator);
			}
			if (this.PlayerName != null)
			{
				this.PlayerName.text = metaData.Nickname;
			}
			if (this.ClassIcon != null)
			{
				EHeroClass heroClass = LoadoutUtil.GetHeroClass(metaData.LoadoutInfo);
				foreach (ClassSprite classSprite in this.ClassSprites)
				{
					if (classSprite.HeroClass == heroClass)
					{
						if (metaData.Levels.ContainsKey((short)heroClass))
						{
							this.ClassIcon.sprite = ((!ServiceProvider.GetService<ProgressionService>().CheckGoldClass((int)metaData.Levels[(short)heroClass])) ? classSprite.HeroIcon : classSprite.GoldIcon);
						}
						else
						{
							this.ClassIcon.sprite = classSprite.HeroIcon;
						}
						this.ClassIcon.SetNativeSize();
						break;
					}
				}
			}
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x00038BD4 File Offset: 0x00036DD4
		public void Update()
		{
			if (this.ChoosePlayerAnimator.isInitialized)
			{
				this.ChoosePlayerAnimator.SetBool(ChoosePlayerComponent.anim_hash_isOn, this._isOn);
				this.ChoosePlayerAnimator.SetBool(ChoosePlayerComponent.anim_hash_isPlayer, this._isPlayer);
				this.ChoosePlayerAnimator.SetBool(ChoosePlayerComponent.anim_hash_isFriend, this._isFriend);
			}
		}

		// Token: 0x04000C24 RID: 3108
		private static int anim_hash_isOn = Animator.StringToHash("isOn");

		// Token: 0x04000C25 RID: 3109
		private static int anim_hash_isPlayer = Animator.StringToHash("isPlayer");

		// Token: 0x04000C26 RID: 3110
		private static int anim_hash_isFriend = Animator.StringToHash("isFriend");

		// Token: 0x04000C27 RID: 3111
		public Text PlayerNumber;

		// Token: 0x04000C28 RID: 3112
		public Image SpectatorCameraImage;

		// Token: 0x04000C29 RID: 3113
		public Text PlayerLevel;

		// Token: 0x04000C2A RID: 3114
		public Image PlayerBadge;

		// Token: 0x04000C2B RID: 3115
		public Image ClassIcon;

		// Token: 0x04000C2C RID: 3116
		public Text PlayerName;

		// Token: 0x04000C2D RID: 3117
		public ClassSprite[] ClassSprites;

		// Token: 0x04000C2E RID: 3118
		public Sprite[] PlayerBadgeSprites;

		// Token: 0x04000C2F RID: 3119
		public Animator ChoosePlayerAnimator;

		// Token: 0x04000C30 RID: 3120
		private bool _isPlayer;

		// Token: 0x04000C31 RID: 3121
		private bool _isFriend;

		// Token: 0x04000C32 RID: 3122
		private bool _isOn;
	}
}
