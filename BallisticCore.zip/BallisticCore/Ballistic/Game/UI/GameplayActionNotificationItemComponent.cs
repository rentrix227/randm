﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C6 RID: 454
	public class GameplayActionNotificationItemComponent : MonoBehaviour
	{
		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000970 RID: 2416 RVA: 0x00008836 File Offset: 0x00006A36
		// (set) Token: 0x06000971 RID: 2417 RVA: 0x0000883E File Offset: 0x00006A3E
		public bool IsActive { get; private set; }

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000972 RID: 2418 RVA: 0x00008847 File Offset: 0x00006A47
		// (set) Token: 0x06000973 RID: 2419 RVA: 0x0000884F File Offset: 0x00006A4F
		public ActionNotificationType ActionType { get; private set; }

		// Token: 0x06000974 RID: 2420 RVA: 0x00008858 File Offset: 0x00006A58
		public void Awake()
		{
			this._animator = base.GetComponent<Animator>();
		}

		// Token: 0x06000975 RID: 2421 RVA: 0x000397C4 File Offset: 0x000379C4
		public void Update()
		{
			if (this.IsActive)
			{
				this._elapsedTime += Time.deltaTime;
				if (this._elapsedTime > this.ShowTime)
				{
					this.IsActive = false;
					this._animator.SetTrigger("out");
				}
			}
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x00008866 File Offset: 0x00006A66
		public void DisableThisObject()
		{
			base.gameObject.SetActive(false);
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x00039818 File Offset: 0x00037A18
		internal void Increment(int scoreToIncrement)
		{
			this._totalScore += scoreToIncrement;
			this.Score.text = "+" + this._totalScore;
			this._elapsedTime = Mathf.Min(1f, 0.5f * this.ShowTime);
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x00039870 File Offset: 0x00037A70
		internal void SetData(ActionNotificationType action, int score)
		{
			this.ActionText.text = ServiceProvider.GetService<LocalizationService>().Get("ingame_action_feedback_" + action.ToString().ToLower(), ELocalizedTextCase.UPPER_CASE);
			this.Score.text = "+" + score;
			this.ActionType = action;
			this._elapsedTime = 0f;
			this._totalScore = score;
			this.IsActive = true;
		}

		// Token: 0x04000C7B RID: 3195
		public Text ActionText;

		// Token: 0x04000C7C RID: 3196
		public Text Score;

		// Token: 0x04000C7D RID: 3197
		public float ShowTime = 2.8f;

		// Token: 0x04000C80 RID: 3200
		private Animator _animator;

		// Token: 0x04000C81 RID: 3201
		private float _elapsedTime;

		// Token: 0x04000C82 RID: 3202
		private int _totalScore;
	}
}
