﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E2 RID: 738
	public class LockboxButtonsView : BaseView<InventoryController>
	{
		// Token: 0x06000F80 RID: 3968 RVA: 0x0000CC21 File Offset: 0x0000AE21
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.OpenLockboxBtn.onClick.AddListener(new UnityAction(this.OpenLockbox));
		}

		// Token: 0x06000F81 RID: 3969 RVA: 0x0000CC50 File Offset: 0x0000AE50
		internal void SetData(LockboxData lockboxData)
		{
			this.OpenLockboxBtn.interactable = true;
			this._lockboxData = lockboxData;
		}

		// Token: 0x06000F82 RID: 3970 RVA: 0x0000CC65 File Offset: 0x0000AE65
		private void OpenLockbox()
		{
			base._controller.OpenLockbox(this._lockboxData);
		}

		// Token: 0x040014AC RID: 5292
		public Button OpenLockboxBtn;

		// Token: 0x040014AD RID: 5293
		private LockboxData _lockboxData;
	}
}
