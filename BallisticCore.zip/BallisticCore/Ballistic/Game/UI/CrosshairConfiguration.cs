﻿using System;
using Aquiris.Ballistic.Game.Weapon;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200027B RID: 635
	[Serializable]
	public class CrosshairConfiguration
	{
		// Token: 0x0400106A RID: 4202
		public CrosshairType Type;

		// Token: 0x0400106B RID: 4203
		public CrosshairConfiguration.CrosshairPart[] CrosshairParts;

		// Token: 0x0400106C RID: 4204
		public CrosshairConfiguration.RendererPart[] RendererParts;

		// Token: 0x0400106D RID: 4205
		public AnimationCurve PulseCurve = AnimationCurve.Linear(0f, 0f, 1f, 0f);

		// Token: 0x0200027C RID: 636
		[Serializable]
		public struct CrosshairPart
		{
			// Token: 0x06000D7F RID: 3455 RVA: 0x0000B43E File Offset: 0x0000963E
			public void SetSpread(float spread)
			{
				this.Part.anchoredPosition = Vector2.Lerp(this.Max, this.Min, spread);
			}

			// Token: 0x0400106E RID: 4206
			public RectTransform Part;

			// Token: 0x0400106F RID: 4207
			public Vector2 Min;

			// Token: 0x04001070 RID: 4208
			public Vector2 Max;
		}

		// Token: 0x0200027D RID: 637
		[Serializable]
		public struct RendererPart
		{
			// Token: 0x06000D80 RID: 3456 RVA: 0x0000B45D File Offset: 0x0000965D
			public void SetSpread(float spread)
			{
				if (this._propertyId == 0)
				{
					this._propertyId = Shader.PropertyToID(this.Variable);
				}
				this.Part.material.SetFloat(this._propertyId, this.PrecisionNormalizeCurve.Evaluate(spread));
			}

			// Token: 0x04001071 RID: 4209
			public MeshRenderer Part;

			// Token: 0x04001072 RID: 4210
			public string Variable;

			// Token: 0x04001073 RID: 4211
			public AnimationCurve PrecisionNormalizeCurve;

			// Token: 0x04001074 RID: 4212
			private int _propertyId;
		}
	}
}
