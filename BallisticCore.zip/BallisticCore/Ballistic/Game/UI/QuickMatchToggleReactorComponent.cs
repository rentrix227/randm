﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001FB RID: 507
	public class QuickMatchToggleReactorComponent : MonoBehaviour
	{
		// Token: 0x06000A36 RID: 2614 RVA: 0x0003C29C File Offset: 0x0003A49C
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._quickMatchService = ServiceProvider.GetService<QuickMatchService>();
			this._quickMatchService.OnStart += this.OnQuickMatchStart;
			this._quickMatchService.OnFinish += this.OnQuickMatchFinished;
		}

		// Token: 0x06000A37 RID: 2615 RVA: 0x0000922F File Offset: 0x0000742F
		public void OnDestroy()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._quickMatchService.OnStart -= this.OnQuickMatchStart;
			this._quickMatchService.OnFinish -= this.OnQuickMatchFinished;
		}

		// Token: 0x06000A38 RID: 2616 RVA: 0x0000926A File Offset: 0x0000746A
		private void OnQuickMatchStart()
		{
			this.toggle.isOn = false;
			this.toggle.interactable = false;
		}

		// Token: 0x06000A39 RID: 2617 RVA: 0x00009284 File Offset: 0x00007484
		private void OnQuickMatchFinished()
		{
			this.toggle.isOn = false;
			this.toggle.interactable = true;
		}

		// Token: 0x04000D96 RID: 3478
		public Toggle toggle;

		// Token: 0x04000D97 RID: 3479
		private QuickMatchService _quickMatchService;
	}
}
