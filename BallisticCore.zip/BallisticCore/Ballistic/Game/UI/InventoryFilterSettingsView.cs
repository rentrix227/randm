﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D1 RID: 721
	public class InventoryFilterSettingsView : BaseView<InventoryController>
	{
		// Token: 0x06000F16 RID: 3862 RVA: 0x0005ADF4 File Offset: 0x00058FF4
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._locationService = ServiceProvider.GetService<LocalizationService>();
			this._classIndexes = new List<EHeroClass>();
			this._rarityIndexes = new List<ERarity>();
			this.ClassDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnClassDropdownValueChanged));
			this.RarityDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnRarityDropdownValueChanged));
			this.AssaultRifleToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnAssaultRifleToggleClick));
			this.SniperRifleToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSniperRifleToggleClick));
			this.LightMachineGunToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnLightMachineGunToggleClick));
			this.SubMachineGunToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSubMachineGunToggleClick));
			this.MachinePistolToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnMachinePistolToggleClick));
			this.ShotgunToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnShotgunToggleClick));
			this.PistolToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnPistolToggleClick));
			this.MeeleToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnMeeleToggleClick));
			this.GrenadeLauncherToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnGrenadeLauncherToggleClick));
			this.ResetBtn.onClick.AddListener(new UnityAction(this.OnResetClick));
		}

		// Token: 0x06000F17 RID: 3863 RVA: 0x0005AF84 File Offset: 0x00059184
		internal void HeroesDropdown(EHeroClass[] heroClasses)
		{
			this.ClassDropdown.options.Clear();
			foreach (EHeroClass eheroClass in heroClasses)
			{
				this._classIndexes.Add(eheroClass);
				this.ClassDropdown.options.Add(new Dropdown.OptionData((eheroClass != EHeroClass.NONE) ? this._locationService.Get("item_name_hero_" + eheroClass.ToString().ToLower(), ELocalizedTextCase.NONE) : this._locationService.Get("all", ELocalizedTextCase.NONE)));
			}
			this.ClassDropdown.RefreshShownValue();
		}

		// Token: 0x06000F18 RID: 3864 RVA: 0x0005B02C File Offset: 0x0005922C
		internal void RaritiesDropdown(ERarity[] rarities)
		{
			this.RarityDropdown.options.Clear();
			foreach (ERarity erarity in rarities)
			{
				this._rarityIndexes.Add(erarity);
				this.RarityDropdown.options.Add(new Dropdown.OptionData((erarity != ERarity.NONE) ? this._locationService.Get("rarity_" + erarity.ToString().ToLower(), ELocalizedTextCase.NONE) : this._locationService.Get("all", ELocalizedTextCase.NONE)));
			}
			this.RarityDropdown.RefreshShownValue();
		}

		// Token: 0x06000F19 RID: 3865 RVA: 0x0005B0D8 File Offset: 0x000592D8
		internal void SetData(int hero, int rarity, bool assaultEnabled, bool sniperEnabled, bool lightmachineEnabled, bool submachineEnabled, bool machinePistolEnabled, bool shotgunEnabled, bool pistolEnabled, bool meeleEnabled, bool concussionEnabled, bool grenadeEnabled)
		{
			this._isSetting = true;
			this.ClassDropdown.value = hero;
			this.RarityDropdown.value = rarity;
			this.AssaultRifleToggle.isOn = assaultEnabled;
			this.SniperRifleToggle.isOn = sniperEnabled;
			this.LightMachineGunToggle.isOn = lightmachineEnabled;
			this.SubMachineGunToggle.isOn = submachineEnabled;
			this.MachinePistolToggle.isOn = machinePistolEnabled;
			this.ShotgunToggle.isOn = shotgunEnabled;
			this.PistolToggle.isOn = pistolEnabled;
			this.MeeleToggle.isOn = meeleEnabled;
			this.GrenadeLauncherToggle.isOn = grenadeEnabled;
			this._isSetting = false;
		}

		// Token: 0x06000F1A RID: 3866 RVA: 0x0000C555 File Offset: 0x0000A755
		private void OnAssaultRifleToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.AssaultRifle, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F1B RID: 3867 RVA: 0x0000C586 File Offset: 0x0000A786
		private void OnGrenadeLauncherToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.GrenadeLauncher, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F1C RID: 3868 RVA: 0x0005B180 File Offset: 0x00059380
		private void OnMeeleToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.Melee, value);
			base._controller.SetFilterCategory(EWeaponCategory.MeleeSpecial, value);
			base._controller.SetFilterCategory(EWeaponCategory.Concussion, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F1D RID: 3869 RVA: 0x0000C5B7 File Offset: 0x0000A7B7
		private void OnPistolToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.Sidearm, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F1E RID: 3870 RVA: 0x0000C5E8 File Offset: 0x0000A7E8
		private void OnShotgunToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.Shotgun, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F1F RID: 3871 RVA: 0x0000C619 File Offset: 0x0000A819
		private void OnMachinePistolToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.MachinePistol, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F20 RID: 3872 RVA: 0x0000C64A File Offset: 0x0000A84A
		private void OnLightMachineGunToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.LightMachineGun, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F21 RID: 3873 RVA: 0x0000C67B File Offset: 0x0000A87B
		private void OnSubMachineGunToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.SubMachineGun, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F22 RID: 3874 RVA: 0x0000C6AD File Offset: 0x0000A8AD
		private void OnSniperRifleToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterCategory(EWeaponCategory.SniperRifle, value);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F23 RID: 3875 RVA: 0x0000C6DE File Offset: 0x0000A8DE
		private void OnClassDropdownValueChanged(int value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterClass(this._classIndexes[value]);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F24 RID: 3876 RVA: 0x0000C719 File Offset: 0x0000A919
		private void OnRarityDropdownValueChanged(int value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetFilterRarity(this._rarityIndexes[value]);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F25 RID: 3877 RVA: 0x0005B1D8 File Offset: 0x000593D8
		private void OnResetClick()
		{
			base._controller.SetFilterClass(this._classIndexes[0]);
			base._controller.SetFilterRarity(this._rarityIndexes[0]);
			base._controller.SetFilterCategory(EWeaponCategory.AssaultRifle, false);
			base._controller.SetFilterCategory(EWeaponCategory.GrenadeLauncher, false);
			base._controller.SetFilterCategory(EWeaponCategory.Melee, false);
			base._controller.SetFilterCategory(EWeaponCategory.MeleeSpecial, false);
			base._controller.SetFilterCategory(EWeaponCategory.Concussion, false);
			base._controller.SetFilterCategory(EWeaponCategory.Sidearm, false);
			base._controller.SetFilterCategory(EWeaponCategory.Shotgun, false);
			base._controller.SetFilterCategory(EWeaponCategory.MachinePistol, false);
			base._controller.SetFilterCategory(EWeaponCategory.LightMachineGun, false);
			base._controller.SetFilterCategory(EWeaponCategory.SubMachineGun, false);
			base._controller.SetFilterCategory(EWeaponCategory.SniperRifle, false);
			base._controller.RefreshInventoryFiltered();
			base._controller.UpdateInventoryBoard();
			this._isSetting = true;
			this.ClassDropdown.value = 0;
			this.RarityDropdown.value = 0;
			this.AssaultRifleToggle.isOn = false;
			this.SniperRifleToggle.isOn = false;
			this.SubMachineGunToggle.isOn = false;
			this.MachinePistolToggle.isOn = false;
			this.ShotgunToggle.isOn = false;
			this.PistolToggle.isOn = false;
			this.MeeleToggle.isOn = false;
			this.GrenadeLauncherToggle.isOn = false;
			this._isSetting = false;
		}

		// Token: 0x0400143D RID: 5181
		public Dropdown ClassDropdown;

		// Token: 0x0400143E RID: 5182
		public Dropdown RarityDropdown;

		// Token: 0x0400143F RID: 5183
		public Toggle AssaultRifleToggle;

		// Token: 0x04001440 RID: 5184
		public Toggle SniperRifleToggle;

		// Token: 0x04001441 RID: 5185
		public Toggle LightMachineGunToggle;

		// Token: 0x04001442 RID: 5186
		public Toggle SubMachineGunToggle;

		// Token: 0x04001443 RID: 5187
		public Toggle MachinePistolToggle;

		// Token: 0x04001444 RID: 5188
		public Toggle ShotgunToggle;

		// Token: 0x04001445 RID: 5189
		public Toggle PistolToggle;

		// Token: 0x04001446 RID: 5190
		public Toggle MeeleToggle;

		// Token: 0x04001447 RID: 5191
		public Toggle GrenadeLauncherToggle;

		// Token: 0x04001448 RID: 5192
		public Button ResetBtn;

		// Token: 0x04001449 RID: 5193
		private LocalizationService _locationService;

		// Token: 0x0400144A RID: 5194
		private List<EHeroClass> _classIndexes;

		// Token: 0x0400144B RID: 5195
		private List<ERarity> _rarityIndexes;

		// Token: 0x0400144C RID: 5196
		private bool _isSetting;
	}
}
