﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C9 RID: 457
	public class GameplayKillNotificationItemComponent : MonoBehaviour
	{
		// Token: 0x06000986 RID: 2438 RVA: 0x0000893E File Offset: 0x00006B3E
		internal void SetInfo(string victim)
		{
			this.Victim.text = victim;
		}

		// Token: 0x04000C9E RID: 3230
		public Text Victim;
	}
}
