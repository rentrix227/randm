﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C1 RID: 705
	public class InGameMatchTimeView : BaseView<InGameMatchTimeController>
	{
		// Token: 0x06000EC7 RID: 3783 RVA: 0x0005956C File Offset: 0x0005776C
		internal void UpdateTimeRemaining(EGameMode mode, int timeRemaining)
		{
			if (this._lastTime == timeRemaining)
			{
				return;
			}
			this._lastTime = timeRemaining;
			if (timeRemaining < 0)
			{
				this.MatchTimeText.text = "--:--";
				return;
			}
			int num = timeRemaining / 60;
			int num2 = timeRemaining % 60;
			this.MatchTimeText.text = StringUtils.Time00to99[num] + ":" + StringUtils.Time00to99[num2];
			this.MatchTimeLabelText.SetActive(mode != EGameMode.Rounds);
		}

		// Token: 0x040013C5 RID: 5061
		public Text MatchTimeText;

		// Token: 0x040013C6 RID: 5062
		public GameObject MatchTimeLabelText;

		// Token: 0x040013C7 RID: 5063
		private int _lastTime = -1;
	}
}
