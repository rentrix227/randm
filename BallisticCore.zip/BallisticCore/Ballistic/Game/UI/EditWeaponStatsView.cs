﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000271 RID: 625
	public class EditWeaponStatsView : BaseView<SoldiersWeaponController>
	{
		// Token: 0x06000D55 RID: 3413 RVA: 0x0000B1EC File Offset: 0x000093EC
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SkinList.Template.Dispose();
		}

		// Token: 0x06000D56 RID: 3414 RVA: 0x0000B20F File Offset: 0x0000940F
		internal void SetStartInfo(PlayerWeaponData weapon, PlayerWeaponData preview, IEnumerable<WeaponSkin> disponibleSkins, EWeaponSkinName selectedSkin)
		{
			this._selectedWeapon = weapon;
			this._previewWeapon = preview;
			this._disponibleSkins = disponibleSkins.ToList<WeaponSkin>();
			this._selectedSkin = selectedSkin;
			this.UpdateWeaponTexts();
			this.ChangeDataComplete();
		}

		// Token: 0x06000D57 RID: 3415 RVA: 0x0004EB78 File Offset: 0x0004CD78
		private void UpdateWeaponTexts()
		{
			if (this.WeaponNameText != null)
			{
				this.WeaponNameText.text = ServiceProvider.GetService<LocalizationService>().GetWeaponName(this._selectedWeapon.GameItemData.GameItem.ItemName, this._selectedSkin, ELocalizedTextCase.UPPER_CASE);
			}
			if (this.WeaponCategoryText != null)
			{
				this.WeaponCategoryText.text = ServiceProvider.GetService<LocalizationService>().GetWeaponCategory(this._selectedWeapon.GameItemData.GameItem.Category, ELocalizedTextCase.CAPITALIZE);
			}
		}

		// Token: 0x06000D58 RID: 3416 RVA: 0x0000B23F File Offset: 0x0000943F
		internal void SetInfo(PlayerWeaponData weapon, PlayerWeaponData preview, IEnumerable<WeaponSkin> disponibleSkins, EWeaponSkinName selectedSkin)
		{
			this._selectedWeapon = weapon;
			this._previewWeapon = preview;
			this._disponibleSkins = disponibleSkins.ToList<WeaponSkin>();
			this._selectedSkin = selectedSkin;
		}

		// Token: 0x06000D59 RID: 3417 RVA: 0x0004EC04 File Offset: 0x0004CE04
		private void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this._disponibleSkins == null)
			{
				return;
			}
			this.UpdateWeaponTexts();
			this.Info.SetData(this._selectedWeapon.GameItemData, this._previewWeapon.GameItemData);
			this.SkinList.SetActiveCount(this._disponibleSkins.Count);
			int num = 0;
			while (num < this._disponibleSkins.Count && num < this.SkinList.Count)
			{
				WeaponSkinComponent weaponSkinComponent = this.SkinList[num];
				WeaponSkinData weaponSkinData = new WeaponSkinData
				{
					PlayerWeaponData = this._selectedWeapon,
					Weapon = this._selectedWeapon.GameItemData.GameItem,
					WeaponSkin = this._disponibleSkins[num]
				};
				weaponSkinComponent.SetData(weaponSkinData, false, this._disponibleSkins[num].WeaponSkinName == this._selectedSkin);
				weaponSkinComponent.OnWeaponSkinClick = new Action<WeaponSkinData>(this.OnWeaponSkinClick);
				num++;
			}
		}

		// Token: 0x06000D5A RID: 3418 RVA: 0x0000B263 File Offset: 0x00009463
		private void OnWeaponSkinClick(WeaponSkinData skinData)
		{
			base._controller.DispatchWeaponSkinSelected(skinData.PlayerWeaponData, skinData.WeaponSkin);
		}

		// Token: 0x04001015 RID: 4117
		public Text WeaponNameText;

		// Token: 0x04001016 RID: 4118
		public Text WeaponCategoryText;

		// Token: 0x04001017 RID: 4119
		public AvaliableWeaponInfoComponent Info;

		// Token: 0x04001018 RID: 4120
		public EditWeaponStatsView.AvailableWeaponSkinComponentPoolableList SkinList;

		// Token: 0x04001019 RID: 4121
		private PlayerWeaponData _selectedWeapon;

		// Token: 0x0400101A RID: 4122
		private PlayerWeaponData _previewWeapon;

		// Token: 0x0400101B RID: 4123
		private List<WeaponSkin> _disponibleSkins;

		// Token: 0x0400101C RID: 4124
		private EWeaponSkinName _selectedSkin;

		// Token: 0x02000272 RID: 626
		[Serializable]
		public class AvailableWeaponSkinComponentPoolableList : PoolableList<WeaponSkinComponent>
		{
		}
	}
}
