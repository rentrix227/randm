﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000293 RID: 659
	internal abstract class BaseScreenIndicator
	{
		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000E11 RID: 3601 RVA: 0x00053EF0 File Offset: 0x000520F0
		protected Camera _camera
		{
			get
			{
				if (UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR)
				{
					return ServiceProvider.GetService<SpectatorService>().GetCurrentCamera();
				}
				if (this._cachedCamera == null)
				{
					this._cachedCamera = ServiceProvider.GetService<LocalCharacterService>().StageCamera;
					if (this._cachedCamera == null)
					{
						return Camera.main;
					}
				}
				return this._cachedCamera;
			}
		}

		// Token: 0x06000E12 RID: 3602 RVA: 0x0000B8AE File Offset: 0x00009AAE
		protected void UpdateMarkerPosition(Vector3 worldPosition)
		{
			this._worldPosition = worldPosition;
			if (this._positionUpdateRoutine == null)
			{
				this._positionUpdateRoutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.UpdateMarkerPositionRoutine());
			}
		}

		// Token: 0x06000E13 RID: 3603 RVA: 0x00053F58 File Offset: 0x00052158
		private IEnumerator UpdateMarkerPositionRoutine()
		{
			for (;;)
			{
				yield return new WaitForEndOfFrame();
				if (this.Marker == null || this.Marker.gameObject == null)
				{
					break;
				}
				Vector3 worldPosition = this._worldPosition;
				worldPosition += this.WorldOffset;
				if (this._camera == null)
				{
					goto Block_1;
				}
				Vector3 screenPoint = CameraUtils.SafeWorldToScreenPoint(this._camera, worldPosition);
				screenPoint.x /= (float)this._camera.pixelWidth;
				screenPoint.y /= (float)this._camera.pixelHeight;
				this._unclampedScreenPosition = screenPoint;
				if (this.ClampOnBorder)
				{
					screenPoint.x = Mathf.Max(screenPoint.x, this.BorderSize.LeftBorder * this._camera.aspect);
					screenPoint.x = Mathf.Min(screenPoint.x, 1f - this.BorderSize.RightBorder * this._camera.aspect);
					screenPoint.y = Mathf.Max(screenPoint.y, this.BorderSize.BottomBorder);
					screenPoint.y = Mathf.Min(screenPoint.y, 1f - this.BorderSize.TopBorder);
				}
				this._clampedScreenPosition = screenPoint;
				this.Marker.localPosition = new Vector3(BaseScreenIndicator.UnclampedLerp(this.BottomLeftReference.localPosition.x, this.TopRightReference.localPosition.x, screenPoint.x), BaseScreenIndicator.UnclampedLerp(this.BottomLeftReference.localPosition.y, this.TopRightReference.localPosition.y, screenPoint.y), this.BottomLeftReference.localPosition.z);
			}
			yield break;
			Block_1:
			yield break;
			yield break;
		}

		// Token: 0x06000E14 RID: 3604 RVA: 0x0000B8D8 File Offset: 0x00009AD8
		private static float UnclampedLerp(float a, float b, float t)
		{
			return a + t * (b - a);
		}

		// Token: 0x06000E15 RID: 3605 RVA: 0x0000B8E1 File Offset: 0x00009AE1
		internal virtual void Destroy(float delay = 0f)
		{
			ServiceProvider.GetService<EventProxy>().StartCoroutine(this.DestroyRoutine(delay));
		}

		// Token: 0x06000E16 RID: 3606 RVA: 0x00053F74 File Offset: 0x00052174
		private IEnumerator DestroyRoutine(float delay)
		{
			if (delay > 0f)
			{
				yield return new WaitForSeconds(delay);
			}
			if (this.Marker != null && this.Marker.gameObject)
			{
				Object.Destroy(this.Marker.gameObject);
				if (this._positionUpdateRoutine != null)
				{
					ServiceProvider.GetService<EventProxy>().StopCoroutine(this._positionUpdateRoutine);
				}
			}
			yield break;
		}

		// Token: 0x040011E3 RID: 4579
		internal Transform BottomLeftReference;

		// Token: 0x040011E4 RID: 4580
		internal Transform TopRightReference;

		// Token: 0x040011E5 RID: 4581
		internal Transform Marker;

		// Token: 0x040011E6 RID: 4582
		internal Vector3 WorldOffset;

		// Token: 0x040011E7 RID: 4583
		internal bool ClampOnBorder;

		// Token: 0x040011E8 RID: 4584
		internal BorderSettings BorderSize;

		// Token: 0x040011E9 RID: 4585
		protected Vector3 _unclampedScreenPosition;

		// Token: 0x040011EA RID: 4586
		protected Vector3 _clampedScreenPosition;

		// Token: 0x040011EB RID: 4587
		private Vector3 _worldPosition;

		// Token: 0x040011EC RID: 4588
		private Coroutine _positionUpdateRoutine;

		// Token: 0x040011ED RID: 4589
		private Camera _cachedCamera;
	}
}
