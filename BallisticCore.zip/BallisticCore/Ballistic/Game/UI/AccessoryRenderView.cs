﻿using System;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200025E RID: 606
	public class AccessoryRenderView : BaseView<InventoryController>
	{
		// Token: 0x06000D1E RID: 3358 RVA: 0x0000AFD6 File Offset: 0x000091D6
		internal void SetData(bool isEnabled)
		{
			this.AccessoryRenderer.color = new Color32(0, 128, (!isEnabled) ? byte.MaxValue : 0, byte.MaxValue);
		}

		// Token: 0x04000FDD RID: 4061
		private const byte zero = 0;

		// Token: 0x04000FDE RID: 4062
		private const byte half = 128;

		// Token: 0x04000FDF RID: 4063
		private const byte full = 255;

		// Token: 0x04000FE0 RID: 4064
		public RawImage AccessoryRenderer;
	}
}
