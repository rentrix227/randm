﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000304 RID: 772
	public class ServerBrowserListView : BaseView<ServerBrowserController>
	{
		// Token: 0x06001004 RID: 4100 RVA: 0x0000D2A6 File Offset: 0x0000B4A6
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.ServerItemTemplateList.Template.Dispose();
			this.JoinButton.onClick.AddListener(new UnityAction(this.OnJoinGameClick));
		}

		// Token: 0x06001005 RID: 4101 RVA: 0x0005DD7C File Offset: 0x0005BF7C
		private void OnJoinGameClick()
		{
			Toggle toggle = this.ServerListGroup.ActiveToggles().FirstOrDefault((Toggle item) => item.GetComponentInChildren<ServerBrowserListItemComponent>().GetId() == this._lastServerSelected.SteamId);
			if (toggle == null)
			{
				return;
			}
			base._controller.Join(this._lastServerSelected, EClientMode.SPECTATOR);
		}

		// Token: 0x06001006 RID: 4102 RVA: 0x0000D2E5 File Offset: 0x0000B4E5
		private void OnServerSelected(HostItem hostItem)
		{
			this._lastServerSelected = hostItem;
			this.JoinButton.interactable = true;
		}

		// Token: 0x06001007 RID: 4103 RVA: 0x0000D2FA File Offset: 0x0000B4FA
		private void OnServerDoubleClick(HostItem hostItem)
		{
			this._lastServerSelected = hostItem;
			this.JoinButton.interactable = true;
			this.OnJoinGameClick();
		}

		// Token: 0x06001008 RID: 4104 RVA: 0x0000D315 File Offset: 0x0000B515
		internal void SortBy(ESortByCategories category, bool ascOrDesc)
		{
			base._controller.SortServers(category, ascOrDesc);
		}

		// Token: 0x06001009 RID: 4105 RVA: 0x0005DDC8 File Offset: 0x0005BFC8
		internal void UpdateServers(IEnumerable<HostItem> servers)
		{
			int num = servers.Count<HostItem>();
			this.ServerItemTemplateList.SetActiveCount(num);
			this.JoinButton.interactable = false;
			int num2 = 0;
			foreach (HostItem hostItem in servers)
			{
				ServerBrowserListItemComponent serverBrowserListItemComponent = this.ServerItemTemplateList[num2];
				num2++;
				serverBrowserListItemComponent.SetInfo(hostItem);
				serverBrowserListItemComponent.ListenOnSelected(new Action<HostItem>(this.OnServerSelected));
				serverBrowserListItemComponent.ListenOnDoubleClick(new Action<HostItem>(this.OnServerDoubleClick));
				if (this._lastServerSelected != null)
				{
					bool flag = this._lastServerSelected.SteamId == hostItem.SteamId;
					serverBrowserListItemComponent.SetSelected(flag);
					if (flag)
					{
						this.OnServerSelected(this._lastServerSelected);
					}
				}
			}
		}

		// Token: 0x04001531 RID: 5425
		public Button JoinButton;

		// Token: 0x04001532 RID: 5426
		public ToggleGroup ServerListGroup;

		// Token: 0x04001533 RID: 5427
		public ServerBrowserListView.ServerBrowserListItemComponentPoolableList ServerItemTemplateList;

		// Token: 0x04001534 RID: 5428
		private HostItem _lastServerSelected;

		// Token: 0x02000305 RID: 773
		[Serializable]
		public class ServerBrowserListItemComponentPoolableList : PoolableList<ServerBrowserListItemComponent>
		{
		}
	}
}
