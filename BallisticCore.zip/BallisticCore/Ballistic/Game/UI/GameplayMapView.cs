﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000286 RID: 646
	public class GameplayMapView : BaseView<GameplayMapController>
	{
		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000DB8 RID: 3512 RVA: 0x0000B688 File Offset: 0x00009888
		private float _worldScale
		{
			get
			{
				return this.BaseWorldScale * this.WorldScaleFactor;
			}
		}

		// Token: 0x06000DB9 RID: 3513 RVA: 0x00050A1C File Offset: 0x0004EC1C
		private Transform InstantiateMapEntity(Transform template)
		{
			Transform transform = Object.Instantiate<Transform>(template, template.parent);
			transform.gameObject.SetActive(true);
			return transform;
		}

		// Token: 0x06000DBA RID: 3514 RVA: 0x0000B697 File Offset: 0x00009897
		protected override void Awake()
		{
			base.Awake();
			this._ownerHash = Animator.StringToHash("owner");
		}

		// Token: 0x06000DBB RID: 3515 RVA: 0x00050A44 File Offset: 0x0004EC44
		internal void Initialize(EGameMode gameMode)
		{
			if (this._isInitialized)
			{
				return;
			}
			this._floorHeights = new List<float>();
			this._floors = new List<RawImage>();
			this._targetFloorAlphas = new List<float>();
			this._originalFloorScales = new List<Vector3>();
			this._originalFloorPositions = new List<Vector3>();
			this.FloorTemplate.gameObject.SetActive(false);
			this.CapturePointTemplate.gameObject.SetActive(false);
			this.KingOfTheHillTemplate.gameObject.SetActive(false);
			this.HealthStationTemplate.gameObject.SetActive(false);
			this.JuggernautWeaponTemplate.gameObject.SetActive(false);
			this.PlayerTemplate.gameObject.SetActive(false);
			this._mapEntities = new List<GameplayMapView.MapEntity>();
			this._playerEntities = new Dictionary<long, GameplayMapView.PlayerEntity>();
			this._originalWorldScale = (this._lastWorldScale = this._worldScale);
			Transform transform = null;
			GameObject[] rootGameObjects = SceneManager.GetActiveScene().GetRootGameObjects();
			for (int i = 0; i < rootGameObjects.Length; i++)
			{
				if (rootGameObjects[i].name == "_minimap")
				{
					transform = rootGameObjects[i].transform;
				}
				if (rootGameObjects[i].name == "_levelSetup")
				{
					Transform transform2 = rootGameObjects[i].transform.Find(gameMode.ToString());
					if (transform2 == null)
					{
						Debug.LogWarning("GameModeRoot not found. Include '_levelSetup' root on your map.");
						return;
					}
					Transform transform3 = null;
					for (int j = 0; j < transform2.childCount; j++)
					{
						Transform child = transform2.GetChild(j);
						if (child.name.StartsWith("pickup", StringComparison.InvariantCultureIgnoreCase))
						{
							transform3 = child;
							break;
						}
					}
					if (transform3 != null)
					{
						for (int k = 0; k < transform3.childCount; k++)
						{
							Transform child2 = transform3.GetChild(k);
							if (child2.name.Contains("health"))
							{
								GameplayMapView.MapEntity mapEntity = new GameplayMapView.MapEntity
								{
									Marker = this.InstantiateMapEntity(this.HealthStationTemplate),
									WorldPosition = child2.position
								};
								this._mapEntities.Add(mapEntity);
							}
						}
					}
				}
			}
			if (transform == null)
			{
				Debug.LogWarning("MapRoot not found. Include '_minimap' root on your map.");
				return;
			}
			this._forwardReference = transform.Find("forward");
			if (this._forwardReference == null)
			{
				Debug.LogWarning("MapForwardRoot not found. Include '_minimap/forward' root on your map.");
				return;
			}
			if (gameMode != EGameMode.Conquest)
			{
				if (gameMode != EGameMode.KingOfTheHill)
				{
					if (gameMode == EGameMode.Juggernaut)
					{
						List<WeaponInfo> weaponInfo = ServiceProvider.GetService<NetworkGameService>().GetGameModeMetaData().GameMetaData.WeaponInfo;
						if (weaponInfo == null)
						{
							return;
						}
						for (int l = 0; l < weaponInfo.Count; l++)
						{
							Vector3 vector;
							vector..ctor((float)weaponInfo[l].CurrentPosition[0], (float)weaponInfo[l].CurrentPosition[1], (float)weaponInfo[l].CurrentPosition[1]);
							GameplayMapView.WeaponPointEntity weaponPointEntity = new GameplayMapView.WeaponPointEntity
							{
								PointIndex = l,
								Marker = this.InstantiateMapEntity(this.JuggernautWeaponTemplate),
								WorldPosition = vector
							};
							weaponPointEntity.UpdateMarker(weaponInfo[l].Active, vector);
							this._mapEntities.Add(weaponPointEntity);
						}
					}
				}
				else
				{
					Transform transform4 = transform.Find("modes/king_of_the_hill");
					if (transform4 == null)
					{
						Debug.LogWarning("KingOfTheHill Root not found. Include '_minimap/modes/king_of_the_hill' root on your map.");
						return;
					}
					for (int m = 0; m < transform4.childCount; m++)
					{
						Transform child3 = transform4.GetChild(m);
						GameplayMapView.CapturePointEntity capturePointEntity = new GameplayMapView.CapturePointEntity
						{
							PointIndex = m,
							Marker = this.InstantiateMapEntity(this.KingOfTheHillTemplate),
							WorldPosition = child3.position
						};
						this._mapEntities.Add(capturePointEntity);
					}
				}
			}
			else
			{
				Transform transform5 = transform.Find("modes/capture_point");
				if (transform5 == null)
				{
					Debug.LogWarning("CapturePoint Root not found. Include '_minimap/modes/capture_point' root on your map.");
					return;
				}
				for (int n = 0; n < transform5.childCount; n++)
				{
					Transform child4 = transform5.GetChild(n);
					GameplayMapView.CapturePointEntity capturePointEntity2 = new GameplayMapView.CapturePointEntity
					{
						PointIndex = n,
						WorldPosition = child4.position,
						Marker = this.InstantiateMapEntity(this.CapturePointTemplate)
					};
					capturePointEntity2.Marker.name = "Point " + n;
					this._mapEntities.Add(capturePointEntity2);
					Image component = capturePointEntity2.Marker.GetComponent<Image>();
					if (component != null && n < this.CapturePointSprites.Count)
					{
						component.sprite = this.CapturePointSprites[n];
					}
				}
			}
			for (int num = 0; num < transform.childCount; num++)
			{
				Transform child5 = transform.GetChild(num);
				int num2 = 0;
				if (int.TryParse(child5.name, out num2))
				{
					this._floorHeights.Add(child5.position.y);
					RawImage rawImage = Object.Instantiate<RawImage>(this.FloorTemplate, this.FloorTemplate.transform.parent);
					Material sharedMaterial = child5.GetComponent<Renderer>().sharedMaterial;
					Vector2 mainTextureScale = sharedMaterial.mainTextureScale;
					Vector3 normalized = child5.transform.InverseTransformDirection(this._forwardReference.right).normalized;
					Vector3 normalized2 = child5.transform.InverseTransformDirection(this._forwardReference.forward).normalized;
					float num3 = this.ReferenceMapMeshSize * Mathf.Abs(Vector3.Dot(normalized, child5.transform.lossyScale) / mainTextureScale.x);
					float num4 = this.ReferenceMapMeshSize * Mathf.Abs(Vector3.Dot(normalized2, child5.transform.lossyScale) / mainTextureScale.y);
					float width = rawImage.rectTransform.rect.width;
					float height = rawImage.rectTransform.rect.height;
					rawImage.transform.localScale = new Vector3(num3 * this._worldScale / width, num4 * this._worldScale / height, 1f);
					this._originalFloorScales.Add(rawImage.transform.localScale);
					rawImage.transform.localPosition = new Vector3(Vector3.Dot(this._forwardReference.right, child5.position) * this._worldScale, Vector3.Dot(this._forwardReference.forward, child5.position) * this._worldScale, 0f);
					this._originalFloorPositions.Add(rawImage.transform.localPosition);
					rawImage.texture = sharedMaterial.mainTexture;
					rawImage.gameObject.SetActive(true);
					this._floors.Add(rawImage);
					this._targetFloorAlphas.Add(0f);
				}
			}
			this._isInitialized = true;
		}

		// Token: 0x06000DBC RID: 3516 RVA: 0x00051180 File Offset: 0x0004F380
		internal Vector3 TransformPosition(Vector3 worldPosition)
		{
			Vector3 vector;
			vector.x = Vector3.Dot(this._forwardReference.right, worldPosition) * this._worldScale;
			vector.y = Vector3.Dot(this._forwardReference.forward, worldPosition) * this._worldScale;
			vector.z = 0f;
			return vector;
		}

		// Token: 0x06000DBD RID: 3517 RVA: 0x000511D8 File Offset: 0x0004F3D8
		internal float TransformHeight(float worldHeight)
		{
			int i;
			for (i = 0; i < this._floorHeights.Count; i++)
			{
				if (this._floorHeights[i] > worldHeight)
				{
					break;
				}
			}
			if (i == 0)
			{
				return 0f;
			}
			if (i == this._floorHeights.Count)
			{
				return (float)(this._floorHeights.Count - 1);
			}
			return (float)(i - 1) + Mathf.InverseLerp(this._floorHeights[i - 1], this._floorHeights[i], worldHeight);
		}

		// Token: 0x06000DBE RID: 3518 RVA: 0x0005126C File Offset: 0x0004F46C
		internal float TransformRotation(Vector3 worldForward)
		{
			return Quaternion.FromToRotation(this._forwardReference.forward, worldForward).eulerAngles.y;
		}

		// Token: 0x06000DBF RID: 3519 RVA: 0x0005129C File Offset: 0x0004F49C
		internal void SetPlayerData(Vector3 worldPosition, Vector3 worldForward, bool isVisible)
		{
			if (!this._isInitialized)
			{
				return;
			}
			Vector3 vector = this.TransformPosition(worldPosition);
			this.TranslatePivot.localPosition = -vector;
			this.RotatePivot.localRotation = Quaternion.AngleAxis(this.TransformRotation(worldForward), Vector3.forward);
			float num = this.TransformHeight(worldPosition.y + 0.15f);
			int num2 = Mathf.RoundToInt(num);
			for (int i = 0; i < this._floors.Count; i++)
			{
				float num3;
				if (i == num2)
				{
					num3 = 1f;
				}
				else
				{
					float num4 = Mathf.Abs(num - (float)i);
					num3 = Mathf.Pow(this.FloorFadeOutAlpha, num4);
				}
				this._targetFloorAlphas[i] = num3;
			}
			for (int j = 0; j < this._mapEntities.Count; j++)
			{
				GameplayMapView.MapEntity mapEntity = this._mapEntities[j];
				float num5 = this.TransformHeight(mapEntity.WorldPosition.y);
				float num6 = Mathf.Abs(num - num5);
				if (num6 < this.EntityFadeHeightTolerance)
				{
					mapEntity.TargetAlpha = 1f;
				}
				else
				{
					mapEntity.TargetAlpha = Mathf.Pow(this.EntityFadeOutAlpha, num6);
				}
			}
			this._isVisible = isVisible;
		}

		// Token: 0x06000DC0 RID: 3520 RVA: 0x000513E4 File Offset: 0x0004F5E4
		internal void SetRemotePlayerData(long playerId, UITeam team, Vector3 worldPosition, bool visible, bool juggernaut, Vector3 worldForward)
		{
			if (!this._isInitialized)
			{
				return;
			}
			GameplayMapView.PlayerEntity playerEntity;
			if (!this._playerEntities.TryGetValue(playerId, out playerEntity))
			{
				playerEntity = new GameplayMapView.PlayerEntity
				{
					Marker = this.InstantiateMapEntity(this.PlayerTemplate)
				};
				playerEntity.Init();
				this._mapEntities.Add(playerEntity);
				this._playerEntities.Add(playerId, playerEntity);
			}
			playerEntity.WorldPosition = worldPosition;
			playerEntity.WorldForward = worldForward;
			playerEntity.SetVisibility(visible);
			playerEntity.SetTeam(team, juggernaut);
		}

		// Token: 0x06000DC1 RID: 3521 RVA: 0x0005146C File Offset: 0x0004F66C
		internal void RemoveRemotePlayer(long playerId)
		{
			if (!this._isInitialized)
			{
				return;
			}
			if (this._playerEntities.ContainsKey(playerId))
			{
				GameplayMapView.PlayerEntity playerEntity = this._playerEntities[playerId];
				Object.Destroy(playerEntity.Marker.gameObject);
				this._mapEntities.Remove(playerEntity);
				this._playerEntities.Remove(playerId);
			}
		}

		// Token: 0x06000DC2 RID: 3522 RVA: 0x000514D0 File Offset: 0x0004F6D0
		internal void RemoveAllRemotePlayers()
		{
			if (!this._isInitialized)
			{
				return;
			}
			foreach (KeyValuePair<long, GameplayMapView.PlayerEntity> keyValuePair in this._playerEntities)
			{
				Object.Destroy(keyValuePair.Value.Marker.gameObject);
				this._mapEntities.Remove(keyValuePair.Value);
			}
			this._playerEntities.Clear();
		}

		// Token: 0x06000DC3 RID: 3523 RVA: 0x00051568 File Offset: 0x0004F768
		internal void SetCapturePointStatus(int pointIndex, UITeam owner)
		{
			if (!this._isInitialized)
			{
				return;
			}
			for (int i = 0; i < this._mapEntities.Count; i++)
			{
				GameplayMapView.CapturePointEntity capturePointEntity = this._mapEntities[i] as GameplayMapView.CapturePointEntity;
				if (capturePointEntity != null && capturePointEntity.PointIndex == pointIndex && capturePointEntity.Animator != null && capturePointEntity.Animator.isInitialized)
				{
					capturePointEntity.Animator.SetInteger(this._ownerHash, (int)owner);
				}
			}
		}

		// Token: 0x06000DC4 RID: 3524 RVA: 0x000515F4 File Offset: 0x0004F7F4
		internal void SetWeaponPointStatus(int pointIndex, WeaponInfo weaponInfo)
		{
			if (!this._isInitialized)
			{
				return;
			}
			for (int i = 0; i < this._mapEntities.Count; i++)
			{
				GameplayMapView.WeaponPointEntity weaponPointEntity = this._mapEntities[i] as GameplayMapView.WeaponPointEntity;
				if (weaponPointEntity != null && weaponPointEntity.PointIndex == pointIndex)
				{
					weaponPointEntity.UpdateMarker(weaponInfo.Active, new Vector3((float)weaponInfo.CurrentPosition[0], (float)weaponInfo.CurrentPosition[1], (float)weaponInfo.CurrentPosition[2]));
				}
			}
		}

		// Token: 0x06000DC5 RID: 3525 RVA: 0x00051688 File Offset: 0x0004F888
		private void UpdateMapEntities()
		{
			if (this._mapEntities == null)
			{
				return;
			}
			Quaternion quaternion = Quaternion.Inverse(this.RotatePivot.localRotation);
			for (int i = 0; i < this._mapEntities.Count; i++)
			{
				GameplayMapView.MapEntity mapEntity = this._mapEntities[i];
				mapEntity.Marker.localPosition = this.TransformPosition(mapEntity.WorldPosition);
				if (mapEntity.RotationIsFixed)
				{
					mapEntity.Marker.localRotation = quaternion;
				}
				else
				{
					GameplayMapView.PlayerEntity playerEntity = mapEntity as GameplayMapView.PlayerEntity;
					if (playerEntity != null)
					{
						mapEntity.Marker.localRotation = Quaternion.AngleAxis(this.TransformRotation(playerEntity.WorldForward), Vector3.back);
					}
				}
				if (mapEntity.Graphic != null)
				{
					float num = ((!mapEntity.IsVisible) ? 0f : mapEntity.TargetAlpha);
					Color color = mapEntity.Graphic.color;
					color.a = Mathf.MoveTowards(color.a, num, this.EntityFadeSpeed * Time.deltaTime);
					mapEntity.Graphic.color = color;
				}
			}
		}

		// Token: 0x06000DC6 RID: 3526 RVA: 0x000517A8 File Offset: 0x0004F9A8
		private void UpdateFloors()
		{
			if (this._floors == null)
			{
				return;
			}
			for (int i = 0; i < this._floors.Count; i++)
			{
				Color color = this._floors[i].color;
				color.a = Mathf.MoveTowards(color.a, this._targetFloorAlphas[i], this.FloorFadeSpeed * Time.deltaTime);
				this._floors[i].color = color;
			}
		}

		// Token: 0x06000DC7 RID: 3527 RVA: 0x0005182C File Offset: 0x0004FA2C
		public void Update()
		{
			if (!this._isInitialized)
			{
				return;
			}
			this.UpdateMapEntities();
			this.UpdateFloors();
			if (this.MapAnimator.isInitialized)
			{
				this.MapAnimator.SetBool(GameplayMapView._animatorIsVisibleHash, this._isVisible);
			}
			if (this._worldScale != this._lastWorldScale)
			{
				if (this._floors != null)
				{
					float num = this._worldScale / this._originalWorldScale;
					for (int i = 0; i < this._floors.Count; i++)
					{
						this._floors[i].transform.localScale = this._originalFloorScales[i] * num;
						this._floors[i].transform.localPosition = this._originalFloorPositions[i] * num;
					}
				}
				this._lastWorldScale = this._worldScale;
			}
			if (this.DoTest)
			{
				if (this.TestInitializeNow)
				{
					this.TestInitializeNow = false;
					this.Initialize(this.TestGameMode);
				}
				if (this._isInitialized)
				{
					if (this.TestPlayerReference != null)
					{
						this.SetPlayerData(this.TestPlayerReference.position, this.TestPlayerReference.forward, false);
					}
					for (int j = 0; j < this.TestCapturePointStatus.Count; j++)
					{
						this.SetCapturePointStatus(j, this.TestCapturePointStatus[j]);
					}
					for (int k = 0; k < this.TestMyTeamReferences.Count; k++)
					{
						this.SetRemotePlayerData((long)(1000 + k), UITeam.Mine, this.TestMyTeamReferences[k].position, true, false, this.TestMyTeamReferences[k].forward);
					}
					for (int l = 0; l < this.TestOtherTeamReferences.Count; l++)
					{
						this.SetRemotePlayerData((long)(2000 + l), UITeam.Other, this.TestOtherTeamReferences[l].position, true, false, Vector3.zero);
					}
				}
			}
		}

		// Token: 0x040010C9 RID: 4297
		private static readonly int _animatorIsVisibleHash = Animator.StringToHash("isVisible");

		// Token: 0x040010CA RID: 4298
		public Transform RotatePivot;

		// Token: 0x040010CB RID: 4299
		public Transform TranslatePivot;

		// Token: 0x040010CC RID: 4300
		public Animator MapAnimator;

		// Token: 0x040010CD RID: 4301
		public float ReferenceMapMeshSize = 4.3f;

		// Token: 0x040010CE RID: 4302
		public float BaseWorldScale = 6f;

		// Token: 0x040010CF RID: 4303
		public float WorldScaleFactor = 1f;

		// Token: 0x040010D0 RID: 4304
		public RawImage FloorTemplate;

		// Token: 0x040010D1 RID: 4305
		public float FloorFadeSpeed = 2f;

		// Token: 0x040010D2 RID: 4306
		public float FloorFadeOutAlpha = 0.2f;

		// Token: 0x040010D3 RID: 4307
		[Header("Entities")]
		public Transform CapturePointTemplate;

		// Token: 0x040010D4 RID: 4308
		public Transform KingOfTheHillTemplate;

		// Token: 0x040010D5 RID: 4309
		public Transform HealthStationTemplate;

		// Token: 0x040010D6 RID: 4310
		public Transform JuggernautWeaponTemplate;

		// Token: 0x040010D7 RID: 4311
		public Transform PlayerTemplate;

		// Token: 0x040010D8 RID: 4312
		public float EntityFadeHeightTolerance = 0.6f;

		// Token: 0x040010D9 RID: 4313
		public float EntityFadeOutAlpha = 0.2f;

		// Token: 0x040010DA RID: 4314
		public float EntityFadeSpeed = 5f;

		// Token: 0x040010DB RID: 4315
		public List<Sprite> CapturePointSprites = new List<Sprite>();

		// Token: 0x040010DC RID: 4316
		private bool _isInitialized;

		// Token: 0x040010DD RID: 4317
		private bool _isVisible;

		// Token: 0x040010DE RID: 4318
		private Transform _forwardReference;

		// Token: 0x040010DF RID: 4319
		private List<float> _floorHeights;

		// Token: 0x040010E0 RID: 4320
		private List<Vector3> _originalFloorPositions;

		// Token: 0x040010E1 RID: 4321
		private List<Vector3> _originalFloorScales;

		// Token: 0x040010E2 RID: 4322
		private List<RawImage> _floors;

		// Token: 0x040010E3 RID: 4323
		private List<float> _targetFloorAlphas;

		// Token: 0x040010E4 RID: 4324
		private float _originalWorldScale;

		// Token: 0x040010E5 RID: 4325
		private float _lastWorldScale;

		// Token: 0x040010E6 RID: 4326
		private List<GameplayMapView.MapEntity> _mapEntities;

		// Token: 0x040010E7 RID: 4327
		private Dictionary<long, GameplayMapView.PlayerEntity> _playerEntities;

		// Token: 0x040010E8 RID: 4328
		private int _ownerHash;

		// Token: 0x040010E9 RID: 4329
		[Header("Testing")]
		public bool DoTest;

		// Token: 0x040010EA RID: 4330
		public bool TestInitializeNow;

		// Token: 0x040010EB RID: 4331
		public EGameMode TestGameMode = EGameMode.Conquest;

		// Token: 0x040010EC RID: 4332
		public Transform TestPlayerReference;

		// Token: 0x040010ED RID: 4333
		public List<UITeam> TestCapturePointStatus = new List<UITeam>();

		// Token: 0x040010EE RID: 4334
		public List<Transform> TestMyTeamReferences = new List<Transform>();

		// Token: 0x040010EF RID: 4335
		public List<Transform> TestOtherTeamReferences = new List<Transform>();

		// Token: 0x02000287 RID: 647
		private class MapEntity
		{
			// Token: 0x1700011E RID: 286
			// (get) Token: 0x06000DCA RID: 3530 RVA: 0x0000B6C0 File Offset: 0x000098C0
			// (set) Token: 0x06000DCB RID: 3531 RVA: 0x0000B6C8 File Offset: 0x000098C8
			public Transform Marker
			{
				get
				{
					return this._marker;
				}
				set
				{
					this._marker = value;
					if (this._marker != null)
					{
						this.Animator = this.Marker.GetComponentInChildren<Animator>();
						this.Graphic = this.Marker.GetComponent<Graphic>();
					}
				}
			}

			// Token: 0x1700011F RID: 287
			// (get) Token: 0x06000DCC RID: 3532 RVA: 0x00003043 File Offset: 0x00001243
			public virtual bool RotationIsFixed
			{
				get
				{
					return true;
				}
			}

			// Token: 0x17000120 RID: 288
			// (get) Token: 0x06000DCD RID: 3533 RVA: 0x00003043 File Offset: 0x00001243
			public virtual bool IsVisible
			{
				get
				{
					return true;
				}
			}

			// Token: 0x17000121 RID: 289
			// (get) Token: 0x06000DCE RID: 3534 RVA: 0x0000B704 File Offset: 0x00009904
			// (set) Token: 0x06000DCF RID: 3535 RVA: 0x0000B70C File Offset: 0x0000990C
			public Animator Animator { get; protected set; }

			// Token: 0x17000122 RID: 290
			// (get) Token: 0x06000DD0 RID: 3536 RVA: 0x0000B715 File Offset: 0x00009915
			// (set) Token: 0x06000DD1 RID: 3537 RVA: 0x0000B71D File Offset: 0x0000991D
			public Graphic Graphic { get; protected set; }

			// Token: 0x040010F0 RID: 4336
			private Transform _marker;

			// Token: 0x040010F1 RID: 4337
			public Vector3 WorldPosition;

			// Token: 0x040010F4 RID: 4340
			public float TargetAlpha;
		}

		// Token: 0x02000288 RID: 648
		private class CapturePointEntity : GameplayMapView.MapEntity
		{
			// Token: 0x040010F5 RID: 4341
			public int PointIndex;
		}

		// Token: 0x02000289 RID: 649
		private class WeaponPointEntity : GameplayMapView.MapEntity
		{
			// Token: 0x17000123 RID: 291
			// (get) Token: 0x06000DD4 RID: 3540 RVA: 0x0000B72E File Offset: 0x0000992E
			public override bool IsVisible
			{
				get
				{
					return this._isVisible;
				}
			}

			// Token: 0x06000DD5 RID: 3541 RVA: 0x0000B736 File Offset: 0x00009936
			public void UpdateMarker(bool visibility, Vector3 currentPosition)
			{
				this._isVisible = visibility;
				this.WorldPosition = currentPosition;
			}

			// Token: 0x040010F6 RID: 4342
			public int PointIndex;

			// Token: 0x040010F7 RID: 4343
			private bool _isVisible;
		}

		// Token: 0x0200028A RID: 650
		private class PlayerEntity : GameplayMapView.MapEntity
		{
			// Token: 0x17000124 RID: 292
			// (get) Token: 0x06000DD7 RID: 3543 RVA: 0x0000B746 File Offset: 0x00009946
			public override bool RotationIsFixed
			{
				get
				{
					return this.WorldForward.sqrMagnitude < 0.01f;
				}
			}

			// Token: 0x17000125 RID: 293
			// (get) Token: 0x06000DD8 RID: 3544 RVA: 0x0000B75A File Offset: 0x0000995A
			public override bool IsVisible
			{
				get
				{
					return this._isVisible;
				}
			}

			// Token: 0x06000DD9 RID: 3545 RVA: 0x0000B762 File Offset: 0x00009962
			public void SetVisibility(bool visible)
			{
				this._isVisible = visible;
			}

			// Token: 0x06000DDA RID: 3546 RVA: 0x0000B76B File Offset: 0x0000996B
			public void Init()
			{
				this._graphics = base.Marker.GetComponentsInChildren<Image>(true);
			}

			// Token: 0x06000DDB RID: 3547 RVA: 0x00051A44 File Offset: 0x0004FC44
			public void SetTeam(UITeam team, bool isJuggernaut)
			{
				if (this._uiTeam != team || this._isJuggernaut != isJuggernaut)
				{
					this._uiTeam = team;
					this._isJuggernaut = isJuggernaut;
					if (isJuggernaut)
					{
						this.UpdateMarkerGraphic("juggernaut");
					}
					else if (this._uiTeam == UITeam.Mine)
					{
						this.UpdateMarkerGraphic("ally");
					}
					else
					{
						this.UpdateMarkerGraphic("enemy");
					}
				}
			}

			// Token: 0x06000DDC RID: 3548 RVA: 0x00051AB4 File Offset: 0x0004FCB4
			private void UpdateMarkerGraphic(string searchTag)
			{
				for (int i = 0; i < this._graphics.Length; i++)
				{
					this._graphics[i].enabled = this._graphics[i].name.Equals(searchTag);
					if (this._graphics[i].enabled)
					{
						base.Graphic = this._graphics[i];
					}
				}
			}

			// Token: 0x040010F8 RID: 4344
			public Vector3 WorldForward;

			// Token: 0x040010F9 RID: 4345
			private bool _isVisible;

			// Token: 0x040010FA RID: 4346
			private UITeam _uiTeam;

			// Token: 0x040010FB RID: 4347
			private bool _isJuggernaut;

			// Token: 0x040010FC RID: 4348
			private Image[] _graphics;
		}
	}
}
