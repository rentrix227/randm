﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Services;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200023C RID: 572
	internal class InventoryData
	{
		// Token: 0x04000F43 RID: 3907
		internal List<LockboxData> Lockboxes = new List<LockboxData>();

		// Token: 0x04000F44 RID: 3908
		internal List<WeaponSkinData> WeaponSkins = new List<WeaponSkinData>();

		// Token: 0x04000F45 RID: 3909
		internal List<VanityData> VanityData = new List<VanityData>();

		// Token: 0x04000F46 RID: 3910
		internal List<SteamItem> Scraps = new List<SteamItem>();

		// Token: 0x04000F47 RID: 3911
		internal List<SteamItem> GoldScraps = new List<SteamItem>();

		// Token: 0x04000F48 RID: 3912
		internal List<Accessory> Accessories = new List<Accessory>();

		// Token: 0x04000F49 RID: 3913
		internal Dictionary<string, List<LockboxData>> LockboxDictionary = new Dictionary<string, List<LockboxData>>();

		// Token: 0x04000F4A RID: 3914
		internal Dictionary<string, List<WeaponSkinData>> WeaponSkinDictionary = new Dictionary<string, List<WeaponSkinData>>();

		// Token: 0x04000F4B RID: 3915
		internal Dictionary<string, List<VanityData>> VanityDictionary = new Dictionary<string, List<VanityData>>();
	}
}
