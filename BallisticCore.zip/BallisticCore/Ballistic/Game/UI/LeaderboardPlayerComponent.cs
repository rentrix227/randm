﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001EA RID: 490
	public class LeaderboardPlayerComponent : PoolableComponent
	{
		// Token: 0x060009E1 RID: 2529 RVA: 0x00008EF3 File Offset: 0x000070F3
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
		}

		// Token: 0x060009E2 RID: 2530 RVA: 0x0003AA1C File Offset: 0x00038C1C
		internal void SetInfo(Leaderboards leader, LeaderboardEntry info)
		{
			if (this.You != null)
			{
				this.You.SetActive(SteamUser.GetSteamID().m_SteamID == info.SteamId.m_SteamID);
			}
			this._steamId = info.SteamId.m_SteamID;
			int skillRatingTierNumber = RatingUtil.GetSkillRatingTierNumber((float)info.Score);
			this.PlayerName.text = info.Name;
			this.PlayerTierBadge.sprite = this.PlayerBadgeSprites[skillRatingTierNumber];
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(info.SteamId, new Action<ulong, Texture2D>(this.OnImageLoaded), true);
			this.GlobalPosition.text = info.Position.ToString();
			this.SkillRating.text = info.Score.ToString();
			if (leader == Leaderboards.PERFORMANCE_LADDER)
			{
				this.Tier.gameObject.SetActive(true);
				this.TierTooltip.SetActive(true);
				this.Tier.text = (skillRatingTierNumber + 1).ToString();
				this.TierTooltipText.text = ServiceProvider.GetService<LocalizationService>().GetPlayerRankName(RatingUtil.GetSkillRatingTierByPosition(skillRatingTierNumber), ELocalizedTextCase.UPPER_CASE);
			}
			else
			{
				this.Tier.gameObject.SetActive(false);
				this.TierTooltip.SetActive(false);
			}
			this.PrizeLockbox.SetActive(info.PrizeType == LeaderboardPrize.GOLD_LOCKBOX);
			this.PrizeGoldScrap.SetActive(info.PrizeType == LeaderboardPrize.GOLD_SCRAP);
			this.PrizeScraps.SetActive(info.PrizeType == LeaderboardPrize.SCRAP);
			this.PrizeTooltip.SetActive(this.PrizeLockbox.activeSelf || this.PrizeScraps.activeSelf || this.PrizeGoldScrap.activeSelf);
			if (info.PrizeType != LeaderboardPrize.NONE)
			{
				this._rewardTypes.Clear();
				for (int i = 0; i < info.Prize.ItemDropList.Count; i++)
				{
					if (!this._rewardTypes.ContainsKey(info.Prize.ItemDropList[i].SteamId))
					{
						this._rewardTypes.Add(info.Prize.ItemDropList[i].SteamId, 0);
					}
					Dictionary<int, int> rewardTypes;
					int steamId;
					(rewardTypes = this._rewardTypes)[steamId = info.Prize.ItemDropList[i].SteamId] = rewardTypes[steamId] + info.Prize.ItemDropList[i].Quantity;
				}
				this.TooltipLineList.SetActiveCount(this._rewardTypes.Count);
				int num = 0;
				foreach (KeyValuePair<int, int> keyValuePair in this._rewardTypes)
				{
					int key = keyValuePair.Key;
					if (key != 900)
					{
						if (key == 910)
						{
							this.TooltipLineList[num].SetInfo(string.Format("{0} <color=#5c6166> {1}</color>", keyValuePair.Value, this._localizationService.Get("goldscraps", ELocalizedTextCase.UPPER_CASE)));
						}
					}
					else
					{
						this.TooltipLineList[num].SetInfo(string.Format("{0} <color=#5c6166> {1}</color>", keyValuePair.Value, this._localizationService.Get("scraps", ELocalizedTextCase.UPPER_CASE)));
					}
					num++;
				}
			}
		}

		// Token: 0x060009E3 RID: 2531 RVA: 0x00008F08 File Offset: 0x00007108
		private void OnImageLoaded(ulong steamId, Texture2D texture)
		{
			if (steamId == this._steamId)
			{
				this.PlayerAvatar.texture = texture;
			}
		}

		// Token: 0x04000D2F RID: 3375
		public GameObject You;

		// Token: 0x04000D30 RID: 3376
		public Text PlayerName;

		// Token: 0x04000D31 RID: 3377
		public RawImage PlayerAvatar;

		// Token: 0x04000D32 RID: 3378
		public Image PlayerTierBadge;

		// Token: 0x04000D33 RID: 3379
		public Text GlobalPosition;

		// Token: 0x04000D34 RID: 3380
		public Text SkillRating;

		// Token: 0x04000D35 RID: 3381
		public Text Tier;

		// Token: 0x04000D36 RID: 3382
		public Text TierTooltipText;

		// Token: 0x04000D37 RID: 3383
		public GameObject TierTooltip;

		// Token: 0x04000D38 RID: 3384
		public GameObject PrizeLockbox;

		// Token: 0x04000D39 RID: 3385
		public GameObject PrizeGoldScrap;

		// Token: 0x04000D3A RID: 3386
		public GameObject PrizeScraps;

		// Token: 0x04000D3B RID: 3387
		public GameObject PrizeTooltip;

		// Token: 0x04000D3C RID: 3388
		public LeaderboardPlayerComponent.LeaderboardTooltipLineList TooltipLineList;

		// Token: 0x04000D3D RID: 3389
		public Sprite[] PlayerBadgeSprites;

		// Token: 0x04000D3E RID: 3390
		private ulong _steamId;

		// Token: 0x04000D3F RID: 3391
		private LocalizationService _localizationService;

		// Token: 0x04000D40 RID: 3392
		private Dictionary<int, int> _rewardTypes = new Dictionary<int, int>();

		// Token: 0x020001EB RID: 491
		[Serializable]
		public class LeaderboardTooltipLineList : PoolableList<LeaderboardTooltipLineComponent>
		{
		}
	}
}
