﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D7 RID: 471
	internal enum ERequirementType
	{
		// Token: 0x04000CE9 RID: 3305
		COLLECTION,
		// Token: 0x04000CEA RID: 3306
		SPECIFIC
	}
}
