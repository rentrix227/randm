﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002EA RID: 746
	public class MainPlayerStatsView : BaseView<MainController>
	{
		// Token: 0x06000F9D RID: 3997 RVA: 0x0005C6EC File Offset: 0x0005A8EC
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SelectAll.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectAll));
			this.SelectBeserker.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectBeserker));
			this.SelectVanguard.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectVanguard));
			this.SelectWraith.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectWraith));
			this.SelectShadow.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectShadow));
			this.SelectGrenadier.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectGrenadier));
			this.SelectTank.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectTank));
			this.SelectMarksman.onValueChanged.AddListener(new UnityAction<bool>(this.OnSelectMarksman));
		}

		// Token: 0x06000F9E RID: 3998 RVA: 0x0000CDAB File Offset: 0x0000AFAB
		private void OnSelectAll(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewGeneralStatistics(this);
		}

		// Token: 0x06000F9F RID: 3999 RVA: 0x0000CDC0 File Offset: 0x0000AFC0
		private void OnSelectBeserker(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewHeroStatistic(this, EHeroClass.BERSERKER);
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x0000CDD6 File Offset: 0x0000AFD6
		private void OnSelectVanguard(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewHeroStatistic(this, EHeroClass.VANGUARD);
		}

		// Token: 0x06000FA1 RID: 4001 RVA: 0x0000CDEC File Offset: 0x0000AFEC
		private void OnSelectWraith(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewHeroStatistic(this, EHeroClass.WRAITH);
		}

		// Token: 0x06000FA2 RID: 4002 RVA: 0x0000CE02 File Offset: 0x0000B002
		private void OnSelectShadow(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewHeroStatistic(this, EHeroClass.SHADOW);
		}

		// Token: 0x06000FA3 RID: 4003 RVA: 0x0000CE18 File Offset: 0x0000B018
		private void OnSelectGrenadier(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewHeroStatistic(this, EHeroClass.GRENADIER);
		}

		// Token: 0x06000FA4 RID: 4004 RVA: 0x0000CE2E File Offset: 0x0000B02E
		private void OnSelectTank(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewHeroStatistic(this, EHeroClass.TANK);
		}

		// Token: 0x06000FA5 RID: 4005 RVA: 0x0000CE44 File Offset: 0x0000B044
		private void OnSelectMarksman(bool value)
		{
			if (!value)
			{
				return;
			}
			base._controller.ViewHeroStatistic(this, EHeroClass.MARKSMAN);
		}

		// Token: 0x06000FA6 RID: 4006 RVA: 0x0000CE5A File Offset: 0x0000B05A
		internal void SetClass(EHeroClass heroClass)
		{
			if (heroClass == EHeroClass.NONE)
			{
				this.ClassTitleText.text = ServiceProvider.GetService<LocalizationService>().Get("all_classes", ELocalizedTextCase.UPPER_CASE);
			}
			else
			{
				this.ClassTitleText.text = ServiceProvider.GetService<LocalizationService>().GetClassName(heroClass, ELocalizedTextCase.UPPER_CASE);
			}
		}

		// Token: 0x06000FA7 RID: 4007 RVA: 0x0000CE99 File Offset: 0x0000B099
		internal void SetWinsAndLoses(int wins, int loses)
		{
			this.WinXLoseText.text = wins + "/" + loses;
		}

		// Token: 0x06000FA8 RID: 4008 RVA: 0x0000CEBC File Offset: 0x0000B0BC
		internal void SetKillsAndDeaths(int kills, int deaths)
		{
			this.KillXDeathText.text = kills + "/" + deaths;
		}

		// Token: 0x06000FA9 RID: 4009 RVA: 0x0000CEDF File Offset: 0x0000B0DF
		internal void SetMatchs(int value)
		{
			this.MatchsText.text = value.ToString();
		}

		// Token: 0x06000FAA RID: 4010 RVA: 0x0000CEF9 File Offset: 0x0000B0F9
		public void SetHeadshots(int value)
		{
			this.HeadshotsText.text = value.ToString();
		}

		// Token: 0x06000FAB RID: 4011 RVA: 0x0000CF13 File Offset: 0x0000B113
		public void SetAssists(int value)
		{
			this.AssistsText.text = value.ToString();
		}

		// Token: 0x06000FAC RID: 4012 RVA: 0x0005C7EC File Offset: 0x0005A9EC
		internal void SetWinLoseRatio(float value)
		{
			this.WinLoseTransform.localRotation = Quaternion.Euler(0f, 0f, 180f * Mathf.Clamp01((2f - value) / 2f));
			this.WinLoseText.text = value.ToString("0.00");
		}

		// Token: 0x06000FAD RID: 4013 RVA: 0x0005C844 File Offset: 0x0005AA44
		internal void SetKillDeathRatio(float value)
		{
			this.KillDeathTransform.localRotation = Quaternion.Euler(0f, 0f, 180f * Mathf.Clamp01((2f - value) / 2f));
			this.KillDeathText.text = value.ToString("0.00");
		}

		// Token: 0x06000FAE RID: 4014 RVA: 0x0000CF2D File Offset: 0x0000B12D
		internal void SetKillRatio(float value)
		{
			this.KillRateSprite.fillAmount = value;
			this.KillRateText.text = Mathf.FloorToInt(value * 100f) + "%";
		}

		// Token: 0x040014C2 RID: 5314
		public Text ClassTitleText;

		// Token: 0x040014C3 RID: 5315
		public Text WinXLoseText;

		// Token: 0x040014C4 RID: 5316
		public Text KillXDeathText;

		// Token: 0x040014C5 RID: 5317
		public Text MatchsText;

		// Token: 0x040014C6 RID: 5318
		public Text HeadshotsText;

		// Token: 0x040014C7 RID: 5319
		public Text KillDeathText;

		// Token: 0x040014C8 RID: 5320
		public Text WinLoseText;

		// Token: 0x040014C9 RID: 5321
		public Text KillRateText;

		// Token: 0x040014CA RID: 5322
		public Text AssistsText;

		// Token: 0x040014CB RID: 5323
		public RectTransform KillDeathTransform;

		// Token: 0x040014CC RID: 5324
		public RectTransform WinLoseTransform;

		// Token: 0x040014CD RID: 5325
		public Image KillRateSprite;

		// Token: 0x040014CE RID: 5326
		public Toggle SelectAll;

		// Token: 0x040014CF RID: 5327
		public Toggle SelectBeserker;

		// Token: 0x040014D0 RID: 5328
		public Toggle SelectVanguard;

		// Token: 0x040014D1 RID: 5329
		public Toggle SelectWraith;

		// Token: 0x040014D2 RID: 5330
		public Toggle SelectShadow;

		// Token: 0x040014D3 RID: 5331
		public Toggle SelectGrenadier;

		// Token: 0x040014D4 RID: 5332
		public Toggle SelectTank;

		// Token: 0x040014D5 RID: 5333
		public Toggle SelectMarksman;
	}
}
