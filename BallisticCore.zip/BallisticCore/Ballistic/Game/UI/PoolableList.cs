﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F8 RID: 504
	[Serializable]
	public class PoolableList<T> : List<T> where T : PoolableComponent
	{
		// Token: 0x06000A2B RID: 2603 RVA: 0x0003C060 File Offset: 0x0003A260
		public void ReleaseAt(int index)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (i == index)
				{
					T t = base[i];
					t.Dispose();
					return;
				}
			}
		}

		// Token: 0x06000A2C RID: 2604 RVA: 0x0003C0A4 File Offset: 0x0003A2A4
		public void SetActiveCount(int count)
		{
			this.Template.gameObject.SetActive(false);
			int num = 0;
			while (num < count && num < base.Count)
			{
				T t = base[num];
				t.Use();
				num++;
			}
			while (base.Count < count)
			{
				this.Instantiate();
			}
			for (int i = count; i < base.Count; i++)
			{
				T t2 = base[i];
				t2.Dispose();
			}
		}

		// Token: 0x06000A2D RID: 2605 RVA: 0x0003C140 File Offset: 0x0003A340
		internal T Instantiate()
		{
			for (int i = 0; i < base.Count; i++)
			{
				T t = base[i];
				if (!t.InUse)
				{
					T t2 = base[i];
					t2.Use();
					return base[i];
				}
			}
			T component = Object.Instantiate<GameObject>(this.Template.gameObject, this.Parent, false).GetComponent<T>();
			component.gameObject.SetActive(true);
			component.Use();
			base.Add(component);
			return component;
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000A2E RID: 2606 RVA: 0x0003C1EC File Offset: 0x0003A3EC
		public int Lenght
		{
			get
			{
				int num = 0;
				for (int i = 0; i < base.Count; i++)
				{
					T t = base[i];
					if (t.InUse)
					{
						num++;
					}
				}
				return num;
			}
		}

		// Token: 0x04000D91 RID: 3473
		public Transform Parent;

		// Token: 0x04000D92 RID: 3474
		public T Template;
	}
}
