﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000221 RID: 545
	public class GameplayWeaponController : BaseController
	{
		// Token: 0x06000B32 RID: 2866 RVA: 0x00009CE1 File Offset: 0x00007EE1
		public GameplayWeaponController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._localCharacterService.OnAmmoUpdate += this.OnAmmoUpdate;
		}

		// Token: 0x06000B33 RID: 2867 RVA: 0x00009D16 File Offset: 0x00007F16
		public override void OnShow(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (view is GameplayWeaponView)
			{
				this._viewVisible = true;
			}
		}

		// Token: 0x06000B34 RID: 2868 RVA: 0x00009D35 File Offset: 0x00007F35
		public override void OnHide(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (view is GameplayWeaponView)
			{
				this._viewVisible = false;
			}
		}

		// Token: 0x06000B35 RID: 2869 RVA: 0x00042FD8 File Offset: 0x000411D8
		private void OnAmmoUpdate(AmmoUpdateStruct evt)
		{
			GameplayWeaponView view = base.GetView<GameplayWeaponView>();
			if (view == null || !this._viewVisible)
			{
				return;
			}
			view.SetWeaponModel(evt.Weapon);
			view.SetAmmo(evt.Ammo, evt.TotalAmmo);
			view.SetMelee(evt.IsMelee);
			view.SetSecondaryFunction(evt.SecondaryFunctionType);
			view.SetGrenadeCooldown(evt.GrenadeCooldownPercent);
			view.SetSecondaryFunctionCooldown(evt.SecondaryFunctionCooldownPercent);
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x00009D54 File Offset: 0x00007F54
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localCharacterService.OnAmmoUpdate -= this.OnAmmoUpdate;
		}

		// Token: 0x04000EB2 RID: 3762
		private readonly LocalCharacterService _localCharacterService;

		// Token: 0x04000EB3 RID: 3763
		private bool _viewVisible;
	}
}
