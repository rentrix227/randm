﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000251 RID: 593
	public class SettingsController : BaseController
	{
		// Token: 0x06000C94 RID: 3220 RVA: 0x0004BA28 File Offset: 0x00049C28
		public SettingsController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._gameSettingsService = ServiceProvider.GetService<GameSettingsService>();
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			UIManager.Instance.OnBeforeViewStateChange += this.OnBeforeViewStateChange;
			this._qualities = new List<OptionPresetLevel>(Enum.GetValues(typeof(OptionPresetLevel)).Cast<OptionPresetLevel>().ToList<OptionPresetLevel>());
			this._antialisingLevels = new List<AntialisingPresetLevel>(Enum.GetValues(typeof(AntialisingPresetLevel)).Cast<AntialisingPresetLevel>().ToList<AntialisingPresetLevel>());
			this._languages = this._localizationService.GetLanguages();
			this._resolutions = new List<Resolution>(Screen.resolutions);
			Resolution currentResolution = this._gameSettingsService.GetCurrentResolution();
			if (!this._resolutions.Contains(currentResolution))
			{
				this._resolutions.Add(currentResolution);
			}
			if (Application.platform == 7)
			{
				for (int i = 1; i <= 10; i++)
				{
					Resolution resolution = default(Resolution);
					int num = i;
					resolution.height = num;
					resolution.width = num;
					this._resolutions.Add(resolution);
				}
			}
		}

		// Token: 0x06000C95 RID: 3221 RVA: 0x0000A94A File Offset: 0x00008B4A
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			UIManager.Instance.OnBeforeViewStateChange -= this.OnBeforeViewStateChange;
		}

		// Token: 0x06000C96 RID: 3222 RVA: 0x0004BB54 File Offset: 0x00049D54
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			SettingsButtonsView settingsButtonsView = view as SettingsButtonsView;
			if (settingsButtonsView != null)
			{
				ServiceProvider.GetService<InputControlService>().SetInput(settingsButtonsView, false);
			}
		}

		// Token: 0x06000C97 RID: 3223 RVA: 0x0004BB94 File Offset: 0x00049D94
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			SettingsButtonsView settingsButtonsView = view as SettingsButtonsView;
			if (settingsButtonsView != null)
			{
				ServiceProvider.GetService<InputControlService>().SetInput(settingsButtonsView, true);
			}
		}

		// Token: 0x06000C98 RID: 3224 RVA: 0x0004BBD4 File Offset: 0x00049DD4
		private void OnBeforeViewStateChange(string previousState, string currentState, int layer, object context)
		{
			if (previousState == "GAMESETTINGS_GENERAL" && currentState == "GAMESETTINGS_CONTROLS")
			{
				return;
			}
			if (previousState == "GAMESETTINGS_CONTROLS" && currentState == "GAMESETTINGS_GENERAL")
			{
				return;
			}
			if (previousState == "SETTINGS_GENERAL" && currentState == "SETTINGS_CONTROLS")
			{
				return;
			}
			if (previousState == "SETTINGS_CONTROLS" && currentState == "SETTINGS_GENERAL")
			{
				return;
			}
			if (currentState == "SETTINGS_GENERAL" || currentState == "SETTINGS_CONTROLS" || currentState == "GAMESETTINGS_CONTROLS" || currentState == "GAMESETTINGS_GENERAL")
			{
				this.ResetUi();
			}
		}

		// Token: 0x06000C99 RID: 3225 RVA: 0x0004BCAC File Offset: 0x00049EAC
		private void ResetUi()
		{
			this._selectedResolution = this._resolutions.IndexOf(this._gameSettingsService.GetCurrentResolution());
			this._selectedQuality = (int)this._gameSettingsService.Container.Quality;
			this._selectedAliasing = (int)this._gameSettingsService.Container.AntiAliasing;
			this._selectedFullScreen = this._gameSettingsService.Container.FullScreen;
			this._selectedVSync = this._gameSettingsService.Container.VSync;
			this._selectedBlur = this._gameSettingsService.Container.MotionBlur;
			this._selectedMusicVolume = this._gameSettingsService.Container.MusicVolume;
			this._selectedSoundVolume = this._gameSettingsService.Container.SoundVolume;
			this._selectedVoiceVolume = this._gameSettingsService.Container.VoiceVolume;
			this._selectedLanguage = this._languages.IndexOf(this._gameSettingsService.Container.Language);
			this._selectedInGameChat = this._gameSettingsService.Container.InGameChat;
			this._selectedQNetworkNorthAmericaEast = this._gameSettingsService.Container.QNetworkNorthAmericaEast;
			this._selectedQNetworkNorthAmericaWest = this._gameSettingsService.Container.QNetworkNorthAmericaWest;
			this._selectedQNetworkSouthAmerica = this._gameSettingsService.Container.QNetworkSouthAmerica;
			this._selectedQNetworkEurope = this._gameSettingsService.Container.QNetworkEurope;
			this._selectedQNetworkAsia = this._gameSettingsService.Container.QNetworkAsia;
			this._selectedQNetworkChina = this._gameSettingsService.Container.QNetworkChina;
			this._selectedQNetworkDedicated = this._gameSettingsService.Container.QNetworkDedicated;
			SettingsGeneralView view = base.GetView<SettingsGeneralView>();
			if (view != null)
			{
				this.LoadLanguageDropdown(view);
				view.SetMusicVolume(this._selectedMusicVolume);
				view.SetSfxVolume(this._selectedSoundVolume);
				view.SetVoiceVolume(this._selectedVoiceVolume);
				view.SetInGameChatToggle(this._selectedInGameChat);
				view.SetQNetworkNorthAmericaEast(this._selectedQNetworkNorthAmericaEast);
				view.SetQNetworkNorthAmericaWest(this._selectedQNetworkNorthAmericaWest);
				view.SetQNetworkSouthAmerica(this._selectedQNetworkSouthAmerica);
				view.SetQNetworkEurope(this._selectedQNetworkEurope);
				view.SetQNetworkAsia(this._selectedQNetworkAsia);
				view.SetQNetworkChina(this._selectedQNetworkChina);
				view.SetQNetworkDedicated(this._selectedQNetworkDedicated);
			}
			SettingsGraphicsView view2 = base.GetView<SettingsGraphicsView>();
			if (view2 != null)
			{
				this.LoadQualityDropdown(view2);
				this.LoadResolutionDropdown(view2);
				this.LoadAntialiasingDropdown(view2);
				view2.SetFullScreenToggle(this._selectedFullScreen);
				view2.SetVSyncToggle(this._selectedVSync);
				view2.SetBlurToggle(this._selectedBlur);
			}
			SettingsControlsView view3 = base.GetView<SettingsControlsView>();
			if (view3 != null)
			{
				view3.SetInvertAim(this._optionControlService.Container.InvertMouse);
				view3.SetSprintToggle(this._optionControlService.Container.ToggleSprint);
				view3.SetAim(this._optionControlService.Container.ToggleAim);
				view3.SetCrouch(this._optionControlService.Container.ToggleCrouch);
				view3.SetFovSlider((float)this._optionControlService.Container.NormalStageFov);
				view3.SetSensitivitySlider(this._optionControlService.Container.MouseSensitivityNormal);
				view3.SetSensitivityIronSightSlider(this._optionControlService.Container.MouseSensitivityIronSight);
				view3.SetSensitivityTelescopicSlider(this._optionControlService.Container.MouseSensitivityTelescopic);
				view3.SetUseMouseWheel(this._optionControlService.Container.MouseWheel);
				view3.UpdateKeysText();
			}
		}

		// Token: 0x06000C9A RID: 3226 RVA: 0x0004C020 File Offset: 0x0004A220
		private void LoadQualityDropdown(SettingsGraphicsView view)
		{
			List<string> list = new List<string>();
			foreach (OptionPresetLevel optionPresetLevel in this._qualities)
			{
				list.Add(this._localizationService.Get(optionPresetLevel.ToString(), ELocalizedTextCase.UPPER_CASE));
			}
			view.SetQualityDropdownValues(list.ToArray(), list[this._selectedQuality]);
		}

		// Token: 0x06000C9B RID: 3227 RVA: 0x0004C0B4 File Offset: 0x0004A2B4
		private void LoadResolutionDropdown(SettingsGraphicsView view)
		{
			List<string> list = new List<string>();
			foreach (Resolution resolution in this._resolutions)
			{
				list.Add(resolution.ToString());
			}
			view.SetResolutionDropdownValues(list.ToArray(), this._resolutions[this._selectedResolution].ToString());
		}

		// Token: 0x06000C9C RID: 3228 RVA: 0x0004C150 File Offset: 0x0004A350
		private void LoadLanguageDropdown(SettingsGeneralView view)
		{
			List<string> list = new List<string>();
			foreach (string text in this._languages)
			{
				list.Add(this._localizationService.Get("language_name", ELocalizedTextCase.UPPER_CASE, text));
			}
			string text2 = this._localizationService.Get("language_name", ELocalizedTextCase.UPPER_CASE, this._gameSettingsService.Container.Language);
			view.SetLanguageDropdownValues(list.ToArray(), text2);
		}

		// Token: 0x06000C9D RID: 3229 RVA: 0x0004C1F4 File Offset: 0x0004A3F4
		private void LoadAntialiasingDropdown(SettingsGraphicsView view)
		{
			List<string> list = new List<string>();
			foreach (AntialisingPresetLevel antialisingPresetLevel in this._antialisingLevels)
			{
				list.Add(this._localizationService.Get(antialisingPresetLevel.ToString(), ELocalizedTextCase.UPPER_CASE));
			}
			view.SetAliasingDropdownValues(list.ToArray(), list[this._selectedAliasing]);
		}

		// Token: 0x06000C9E RID: 3230 RVA: 0x0000A973 File Offset: 0x00008B73
		internal void SetQuality(int quality)
		{
			this._selectedQuality = quality;
		}

		// Token: 0x06000C9F RID: 3231 RVA: 0x0000A97C File Offset: 0x00008B7C
		internal void SetResolution(int resolution)
		{
			this._selectedResolution = resolution;
		}

		// Token: 0x06000CA0 RID: 3232 RVA: 0x0000A985 File Offset: 0x00008B85
		internal void SetFullScreen(bool value)
		{
			this._selectedFullScreen = value;
		}

		// Token: 0x06000CA1 RID: 3233 RVA: 0x0000A98E File Offset: 0x00008B8E
		internal void SetVSync(bool value)
		{
			this._selectedVSync = value;
		}

		// Token: 0x06000CA2 RID: 3234 RVA: 0x0000A997 File Offset: 0x00008B97
		internal void SetAliasing(int value)
		{
			this._selectedAliasing = value;
		}

		// Token: 0x06000CA3 RID: 3235 RVA: 0x0000A9A0 File Offset: 0x00008BA0
		internal void SetBlur(bool value)
		{
			this._selectedBlur = value;
		}

		// Token: 0x06000CA4 RID: 3236 RVA: 0x0004C288 File Offset: 0x0004A488
		internal void SetLanguage(int value)
		{
			this._selectedLanguage = value;
			this._gameSettingsService.Container.Language = this._languages[this._selectedLanguage];
			this._localizationService.CurrentLanguage = this._languages[this._selectedLanguage];
			this.LoadLanguageDropdown(base.GetView<SettingsGeneralView>());
			this.LoadQualityDropdown(base.GetView<SettingsGraphicsView>());
		}

		// Token: 0x06000CA5 RID: 3237 RVA: 0x0000A9A9 File Offset: 0x00008BA9
		internal void SetInGameChat(bool value)
		{
			this._selectedInGameChat = value;
		}

		// Token: 0x06000CA6 RID: 3238 RVA: 0x0000A9B2 File Offset: 0x00008BB2
		internal void SetMusicVolume(float value)
		{
			this._gameSettingsService.Container.MusicVolume = value;
			this._selectedMusicVolume = value;
			this._gameSettingsService.RebuildAudio();
		}

		// Token: 0x06000CA7 RID: 3239 RVA: 0x0000A9D7 File Offset: 0x00008BD7
		internal void SetAudioVolume(float value)
		{
			this._gameSettingsService.Container.SoundVolume = value;
			this._selectedSoundVolume = value;
			this._gameSettingsService.RebuildAudio();
		}

		// Token: 0x06000CA8 RID: 3240 RVA: 0x0000A9FC File Offset: 0x00008BFC
		internal void SetVoiceVolume(float value)
		{
			this._gameSettingsService.Container.VoiceVolume = value;
			this._selectedVoiceVolume = value;
			this._gameSettingsService.RebuildAudio();
		}

		// Token: 0x06000CA9 RID: 3241 RVA: 0x0000AA21 File Offset: 0x00008C21
		internal void SetNetworkChina(bool value)
		{
			this._selectedQNetworkChina = value;
		}

		// Token: 0x06000CAA RID: 3242 RVA: 0x0000AA2A File Offset: 0x00008C2A
		internal void SetNetworkDedicated(bool value)
		{
			this._selectedQNetworkDedicated = value;
		}

		// Token: 0x06000CAB RID: 3243 RVA: 0x0000AA33 File Offset: 0x00008C33
		internal void SetNetworkAsia(bool value)
		{
			this._selectedQNetworkAsia = value;
		}

		// Token: 0x06000CAC RID: 3244 RVA: 0x0000AA3C File Offset: 0x00008C3C
		internal void SetNetworkEurope(bool value)
		{
			this._selectedQNetworkEurope = value;
		}

		// Token: 0x06000CAD RID: 3245 RVA: 0x0000AA45 File Offset: 0x00008C45
		internal void SetNetworkSouthAmerica(bool value)
		{
			this._selectedQNetworkSouthAmerica = value;
		}

		// Token: 0x06000CAE RID: 3246 RVA: 0x0000AA4E File Offset: 0x00008C4E
		internal void SetNetworkNorthAmericaWest(bool value)
		{
			this._selectedQNetworkNorthAmericaWest = value;
		}

		// Token: 0x06000CAF RID: 3247 RVA: 0x0000AA57 File Offset: 0x00008C57
		internal void SetNetworkNorthAmericaEast(bool value)
		{
			this._selectedQNetworkNorthAmericaEast = value;
		}

		// Token: 0x06000CB0 RID: 3248 RVA: 0x0000AA60 File Offset: 0x00008C60
		internal void OnDefaultLoadout()
		{
			ServiceProvider.GetService<PlayerItemService>().ResetLoadouts();
			ServiceProvider.GetService<SoldiersService>().LoadPlayerLoadouts(0);
			ServiceProvider.GetService<PopupService>().Show(EPopupType.DEFAULT_LOADOUTS, null, null, null, 0f);
			ServiceProvider.GetService<SoldiersService>().DispatchSoldierChanged(ServiceProvider.GetService<SoldiersService>().GetCurrentClass());
		}

		// Token: 0x06000CB1 RID: 3249 RVA: 0x0000AA9F File Offset: 0x00008C9F
		internal void OnDefaultStatistics()
		{
			ServiceProvider.GetService<StatisticsService>().EraseUserStats();
			ServiceProvider.GetService<PopupService>().Show(EPopupType.RESET_STATISTICS, null, null, null, 0f);
		}

		// Token: 0x06000CB2 RID: 3250 RVA: 0x0004C2F4 File Offset: 0x0004A4F4
		internal void OnDiscard()
		{
			this._optionControlService.Load();
			this._gameSettingsService.Load();
			this._gameSettingsService.Container.Language = this._languages[this._selectedLanguage];
			this._localizationService.CurrentLanguage = this._languages[this._selectedLanguage];
			this._gameSettingsService.RebuildAudio();
			this._gameSettingsService.RebuildQuality();
			this.LoadLanguageDropdown(base.GetView<SettingsGeneralView>());
			this.LoadQualityDropdown(base.GetView<SettingsGraphicsView>());
		}

		// Token: 0x06000CB3 RID: 3251 RVA: 0x0000AABF File Offset: 0x00008CBF
		public void OnReset()
		{
			this._gameSettingsService.Reset();
			this._optionControlService.Reset();
			this._gameSettingsService.RebuildAudio();
			this._gameSettingsService.RebuildQuality();
			this.ResetUi();
		}

		// Token: 0x06000CB4 RID: 3252 RVA: 0x0004C384 File Offset: 0x0004A584
		internal void OnSave()
		{
			Resolution resolution = default(Resolution);
			resolution.width = this._gameSettingsService.Container.Width;
			resolution.height = this._gameSettingsService.Container.Height;
			resolution.refreshRate = this._gameSettingsService.Container.RefreshRate;
			this._lastResolution = resolution;
			this._lastFullscreen = this._gameSettingsService.Container.FullScreen;
			Debug.Log("Last Resolution = " + this._lastResolution);
			Debug.Log("Current Resolution = " + this._resolutions[this._selectedResolution]);
			Debug.Log("Full Screen = " + this._selectedFullScreen);
			this._gameSettingsService.Container.Width = this._resolutions[this._selectedResolution].width;
			this._gameSettingsService.Container.Height = this._resolutions[this._selectedResolution].height;
			this._gameSettingsService.Container.RefreshRate = this._resolutions[this._selectedResolution].refreshRate;
			this._gameSettingsService.Container.FullScreen = this._selectedFullScreen;
			this._gameSettingsService.Container.Quality = this._qualities[this._selectedQuality];
			this._gameSettingsService.Container.AntiAliasing = this._antialisingLevels[this._selectedAliasing];
			this._gameSettingsService.Container.VSync = this._selectedVSync;
			this._gameSettingsService.Container.MotionBlur = this._selectedBlur;
			this._gameSettingsService.Container.Language = this._languages[this._selectedLanguage];
			this._localizationService.CurrentLanguage = this._languages[this._selectedLanguage];
			this._gameSettingsService.Container.InGameChat = this._selectedInGameChat;
			this._gameSettingsService.Container.MusicVolume = this._selectedMusicVolume;
			this._gameSettingsService.Container.SoundVolume = this._selectedSoundVolume;
			this._gameSettingsService.Container.VoiceVolume = this._selectedVoiceVolume;
			this._gameSettingsService.Container.QNetworkNorthAmericaEast = this._selectedQNetworkNorthAmericaEast;
			this._gameSettingsService.Container.QNetworkNorthAmericaWest = this._selectedQNetworkNorthAmericaWest;
			this._gameSettingsService.Container.QNetworkSouthAmerica = this._selectedQNetworkSouthAmerica;
			this._gameSettingsService.Container.QNetworkEurope = this._selectedQNetworkEurope;
			this._gameSettingsService.Container.QNetworkAsia = this._selectedQNetworkAsia;
			this._gameSettingsService.Container.QNetworkChina = this._selectedQNetworkChina;
			this._gameSettingsService.Container.QNetworkDedicated = this._selectedQNetworkDedicated;
			this._gameSettingsService.Save();
			this._optionControlService.Save();
			this._gameSettingsService.RebuildQuality();
			this._gameSettingsService.RebuildAudio();
			if (this._resolutions[this._selectedResolution].ToString() != this._lastResolution.ToString() || this._gameSettingsService.Container.FullScreen != this._lastFullscreen)
			{
				this._gameSettingsService.RebuildVideo();
				ServiceProvider.GetService<PopupService>().Show(EPopupType.RESOLUTION_CONFIRMATION, null, new Action<int>(this.OnResolutionConfirmationCallback), null, 0f);
				SettingsController.UpdateConfirmResolutionPopupMessage(15U);
				this.BeginAutoRevertProcess();
			}
		}

		// Token: 0x06000CB5 RID: 3253 RVA: 0x0004C73C File Offset: 0x0004A93C
		private static void UpdateConfirmResolutionPopupMessage(uint time)
		{
			string text = ServiceProvider.GetService<LocalizationService>().Get("popup_confirm_resolution_message", ELocalizedTextCase.UPPER_CASE).Replace("{0}", time.ToString());
			ServiceProvider.GetService<PopupService>().UpdateData(null, text, null, null, 0f);
		}

		// Token: 0x06000CB6 RID: 3254 RVA: 0x0000AAF3 File Offset: 0x00008CF3
		private void BeginAutoRevertProcess()
		{
			this._autoRevertRemainingTime = 15f;
			ServiceProvider.GetService<EventProxy>().EUpdate.AddListener(new Action(this.OnAutoRevertUpdate));
		}

		// Token: 0x06000CB7 RID: 3255 RVA: 0x0004C784 File Offset: 0x0004A984
		private void OnAutoRevertUpdate()
		{
			uint num = (uint)this._autoRevertRemainingTime;
			this._autoRevertRemainingTime -= Time.deltaTime;
			uint num2 = (uint)this._autoRevertRemainingTime;
			if (num2 != num)
			{
				SettingsController.UpdateConfirmResolutionPopupMessage(num2);
			}
			if (this._autoRevertRemainingTime <= 0f)
			{
				ServiceProvider.GetService<PopupService>().Hide(EPopupType.RESOLUTION_CONFIRMATION);
				this.OnResolutionConfirmationCallback(0);
			}
		}

		// Token: 0x06000CB8 RID: 3256 RVA: 0x0000AB1B File Offset: 0x00008D1B
		private void OnResolutionConfirmationCallback(int index)
		{
			ServiceProvider.GetService<EventProxy>().EUpdate.RemoveListener(new Action(this.OnAutoRevertUpdate));
			ServiceProvider.GetService<PopupService>().Hide(EPopupType.RESOLUTION_CONFIRMATION);
			if (index == 0)
			{
				this.Revert();
			}
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x0004C7E4 File Offset: 0x0004A9E4
		private void Revert()
		{
			Debug.Log("Reverting Resolution to " + this._lastResolution);
			this._gameSettingsService.Container.Width = this._lastResolution.width;
			this._gameSettingsService.Container.Height = this._lastResolution.height;
			this._gameSettingsService.Container.RefreshRate = this._lastResolution.refreshRate;
			this._gameSettingsService.Container.FullScreen = this._lastFullscreen;
			this._gameSettingsService.Save();
			this._gameSettingsService.RebuildVideo();
			this.ResetUi();
		}

		// Token: 0x04000F8E RID: 3982
		private readonly GameSettingsService _gameSettingsService;

		// Token: 0x04000F8F RID: 3983
		private readonly OptionControlService _optionControlService;

		// Token: 0x04000F90 RID: 3984
		private readonly LocalizationService _localizationService;

		// Token: 0x04000F91 RID: 3985
		private readonly List<OptionPresetLevel> _qualities;

		// Token: 0x04000F92 RID: 3986
		private readonly List<AntialisingPresetLevel> _antialisingLevels;

		// Token: 0x04000F93 RID: 3987
		private readonly List<string> _languages;

		// Token: 0x04000F94 RID: 3988
		private readonly List<Resolution> _resolutions;

		// Token: 0x04000F95 RID: 3989
		private Resolution _lastResolution;

		// Token: 0x04000F96 RID: 3990
		private bool _lastFullscreen;

		// Token: 0x04000F97 RID: 3991
		private int _selectedQuality;

		// Token: 0x04000F98 RID: 3992
		private int _selectedResolution;

		// Token: 0x04000F99 RID: 3993
		private int _selectedLanguage;

		// Token: 0x04000F9A RID: 3994
		private bool _selectedFullScreen;

		// Token: 0x04000F9B RID: 3995
		private bool _selectedVSync;

		// Token: 0x04000F9C RID: 3996
		private bool _selectedBlur;

		// Token: 0x04000F9D RID: 3997
		private int _selectedAliasing;

		// Token: 0x04000F9E RID: 3998
		private bool _selectedInGameChat;

		// Token: 0x04000F9F RID: 3999
		private float _selectedMusicVolume;

		// Token: 0x04000FA0 RID: 4000
		private float _selectedSoundVolume;

		// Token: 0x04000FA1 RID: 4001
		private float _selectedVoiceVolume;

		// Token: 0x04000FA2 RID: 4002
		private float _autoRevertRemainingTime;

		// Token: 0x04000FA3 RID: 4003
		private bool _selectedQNetworkNorthAmericaEast;

		// Token: 0x04000FA4 RID: 4004
		private bool _selectedQNetworkNorthAmericaWest;

		// Token: 0x04000FA5 RID: 4005
		private bool _selectedQNetworkSouthAmerica;

		// Token: 0x04000FA6 RID: 4006
		private bool _selectedQNetworkEurope;

		// Token: 0x04000FA7 RID: 4007
		private bool _selectedQNetworkAsia;

		// Token: 0x04000FA8 RID: 4008
		private bool _selectedQNetworkChina;

		// Token: 0x04000FA9 RID: 4009
		private bool _selectedQNetworkDedicated;

		// Token: 0x04000FAA RID: 4010
		public const uint RevertTime = 15U;
	}
}
