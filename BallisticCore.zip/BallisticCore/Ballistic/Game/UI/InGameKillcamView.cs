﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002BF RID: 703
	public class InGameKillcamView : BaseView<InGameKillcamController>
	{
		// Token: 0x06000EC0 RID: 3776 RVA: 0x0000C053 File Offset: 0x0000A253
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameKillcamView._fillParameterHash = Shader.PropertyToID("_Fill");
		}

		// Token: 0x06000EC1 RID: 3777 RVA: 0x0000C075 File Offset: 0x0000A275
		internal void SetActive(bool isActive)
		{
			if (this.KilledBy.activeSelf != isActive)
			{
				this.KilledBy.SetActive(isActive);
			}
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x000591D0 File Offset: 0x000573D0
		internal void SetInfo(EGameMode gameMode, string playerName, int rating, EHeroClass heroClass, bool fromMyTeam, Team team, string heroSkin, EHeroSkillV2 skill1, EHeroSkillV2 skill2, string weaponItemName, string weaponItemModel, EWeaponSkinName skinName, EWeaponCategory weaponCategory, ERarity skinRarity, int classLevel)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.PlayerNameText.text = playerName;
			this.PlayerRankText.text = service.Get("playerrank_" + RatingUtil.GetSkillRatingTier(rating).ToString().ToLower(), ELocalizedTextCase.NONE);
			this.PlayerBadgeImage.sprite = this.PlayerBadgeSprites[RatingUtil.GetSkillRatingTierNumber((float)rating)];
			foreach (InGameKillcamView.ClassPortraitEntry classPortraitEntry in this.ClassPortraits)
			{
				if (classPortraitEntry.HeroClass == heroClass)
				{
					TextureHelper.LoadImageAsync(TextureHelper.GetClassHudIconPath(heroSkin), this.ClassPortraitImage, false, EImageSource.RESOURCES);
					bool flag = ServiceProvider.GetService<ProgressionService>().CheckGoldClass(classLevel);
					this.ClassIconImage.sprite = ((!flag) ? classPortraitEntry.HeroIcon : classPortraitEntry.GoldIcon);
					this.ClassIconImage.color = ((!flag) ? new Color32(153, 157, 168, byte.MaxValue) : new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue));
					this.ClassIconImage.SetNativeSize();
					break;
				}
			}
			TextureHelper.LoadImageAsync(TextureHelper.GetSkillIconPath(skill1), this.Skill1Image, false, EImageSource.RESOURCES);
			TextureHelper.LoadImageAsync(TextureHelper.GetSkillIconPath(skill2), this.Skill2Image, false, EImageSource.RESOURCES);
			this.ClassName.text = service.GetClassName(heroClass, ELocalizedTextCase.CAPITALIZE);
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				if (fromMyTeam)
				{
					this.YourTeam.SetActive(fromMyTeam);
					this.EnemyTeam.SetActive(!fromMyTeam);
					this.YourTeamName.text = service.GetTeamName(team, ELocalizedTextCase.NONE);
					this.YourTeamLogo.texture = this.TeamLogos[(int)team];
				}
				else
				{
					this.YourTeam.SetActive(fromMyTeam);
					this.EnemyTeam.SetActive(!fromMyTeam);
					this.EnemyTeamName.text = service.GetTeamName(team, ELocalizedTextCase.NONE);
					this.EnemyTeamLogo.texture = this.TeamLogos[(int)team];
				}
			}
			else
			{
				this.YourTeam.SetActive(false);
				this.YourTeamLogo.gameObject.SetActive(false);
				this.YourTeamName.gameObject.SetActive(false);
				this.EnemyTeam.SetActive(true);
				this.EnemyTeamLogo.gameObject.SetActive(false);
				this.EnemyTeamName.gameObject.SetActive(false);
			}
			this.UpdateWeapon(weaponItemName, weaponItemModel, skinName, weaponCategory, skinRarity);
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x00059478 File Offset: 0x00057678
		internal void UpdateWeapon(string weaponItemName, string weaponItemModel, EWeaponSkinName skinName, EWeaponCategory weaponCategory, ERarity skinRarity)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			TextureHelper.LoadImageAsync(TextureHelper.GetWeaponIconPath(weaponItemModel, EImageSize.SMALL, skinName.ToString().ToLowerInvariant()), this.WeaponRawImage, true, EImageSource.METADATA);
			this.WeaponNameText.text = service.GetWeaponName(weaponItemName, skinName, ELocalizedTextCase.UPPER_CASE);
			this.WeaponCategoryText.text = service.GetWeaponCategory(weaponCategory, ELocalizedTextCase.UPPER_CASE);
			this.WeaponSkinRarityText.text = ((skinRarity == ERarity.NONE) ? string.Empty : service.GetRarityName(skinRarity));
			Color rarityColor = RarityHelper.GetRarityColor(skinRarity);
			this.WeaponSkinRarityText.color = rarityColor;
			this.WeaponGlowImage.color = rarityColor;
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x00059520 File Offset: 0x00057720
		internal void UpdateHealthBar(EHeroClass heroClass, float health, float maxHealth)
		{
			for (int i = 0; i < this.ClassPortraits.Length; i++)
			{
				this.ClassPortraits[i].HealthBar.material.SetFloat(InGameKillcamView._fillParameterHash, health / maxHealth);
			}
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0000C094 File Offset: 0x0000A294
		internal void SetPlayerAvatar(Texture2D texture)
		{
			this.PlayerAvatarImage.texture = texture;
		}

		// Token: 0x040013A8 RID: 5032
		private static int _fillParameterHash;

		// Token: 0x040013A9 RID: 5033
		[Header("Spectator")]
		public GameObject KilledBy;

		// Token: 0x040013AA RID: 5034
		[Header("Team")]
		public GameObject YourTeam;

		// Token: 0x040013AB RID: 5035
		public GameObject EnemyTeam;

		// Token: 0x040013AC RID: 5036
		public RawImage YourTeamLogo;

		// Token: 0x040013AD RID: 5037
		public RawImage EnemyTeamLogo;

		// Token: 0x040013AE RID: 5038
		public Text YourTeamName;

		// Token: 0x040013AF RID: 5039
		public Text EnemyTeamName;

		// Token: 0x040013B0 RID: 5040
		public Texture[] TeamLogos;

		// Token: 0x040013B1 RID: 5041
		[Header("Player")]
		public Text PlayerNameText;

		// Token: 0x040013B2 RID: 5042
		public Text PlayerRankText;

		// Token: 0x040013B3 RID: 5043
		public RawImage PlayerAvatarImage;

		// Token: 0x040013B4 RID: 5044
		public Image PlayerBadgeImage;

		// Token: 0x040013B5 RID: 5045
		public Sprite[] PlayerBadgeSprites;

		// Token: 0x040013B6 RID: 5046
		[Header("Class")]
		public Image ClassPortraitImage;

		// Token: 0x040013B7 RID: 5047
		public InGameKillcamView.ClassPortraitEntry[] ClassPortraits;

		// Token: 0x040013B8 RID: 5048
		public Image Skill1Image;

		// Token: 0x040013B9 RID: 5049
		public Image Skill2Image;

		// Token: 0x040013BA RID: 5050
		public Image ClassIconImage;

		// Token: 0x040013BB RID: 5051
		public Text ClassName;

		// Token: 0x040013BC RID: 5052
		[Header("Weapon")]
		public RawImage WeaponRawImage;

		// Token: 0x040013BD RID: 5053
		public Text WeaponNameText;

		// Token: 0x040013BE RID: 5054
		public Text WeaponCategoryText;

		// Token: 0x040013BF RID: 5055
		public Text WeaponSkinRarityText;

		// Token: 0x040013C0 RID: 5056
		public Image WeaponGlowImage;

		// Token: 0x020002C0 RID: 704
		[Serializable]
		public struct ClassPortraitEntry
		{
			// Token: 0x040013C1 RID: 5057
			public EHeroClass HeroClass;

			// Token: 0x040013C2 RID: 5058
			public Sprite HeroIcon;

			// Token: 0x040013C3 RID: 5059
			public Sprite GoldIcon;

			// Token: 0x040013C4 RID: 5060
			public Renderer HealthBar;
		}
	}
}
