﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000283 RID: 643
	public class GameplayKillListView : BaseView<GameplayKillListController>
	{
		// Token: 0x06000DA9 RID: 3497 RVA: 0x0000B5C9 File Offset: 0x000097C9
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.EntryList.Template.Dispose();
		}

		// Token: 0x06000DAA RID: 3498 RVA: 0x000506C4 File Offset: 0x0004E8C4
		private GameplayKillListItemComponent InstantiateItem(UITeam killerTeam, UITeam victimTeam = UITeam.None)
		{
			if (this.EntryList.Lenght >= this.MaximumItems)
			{
				this.EntryList.ReleaseAt(0);
			}
			GameplayKillListItemComponent gameplayKillListItemComponent = this.EntryList.Instantiate();
			gameplayKillListItemComponent.SetTeams(killerTeam, victimTeam);
			return gameplayKillListItemComponent;
		}

		// Token: 0x06000DAB RID: 3499 RVA: 0x00050708 File Offset: 0x0004E908
		internal void NotifyKill(string killer, string victim, UITeam killerTeam, UITeam victimTeam, EWeaponCategory weaponCategory, bool isHeadshot, float distance)
		{
			bool flag = distance > this.LongShotDistance;
			GameplayKillListItemComponent gameplayKillListItemComponent = this.InstantiateItem(killerTeam, victimTeam);
			gameplayKillListItemComponent.SetInfoKill(killer, victim, weaponCategory, isHeadshot, flag);
			this._timeSinceEvent = 0f;
		}

		// Token: 0x06000DAC RID: 3500 RVA: 0x00050744 File Offset: 0x0004E944
		internal void NotifyEvent(string player, UITeam playerTeam, UserUpdateType eventType)
		{
			GameplayKillListItemComponent gameplayKillListItemComponent = this.InstantiateItem(playerTeam, UITeam.None);
			gameplayKillListItemComponent.SetInfoEvent(player, eventType);
			this._timeSinceEvent = 0f;
		}

		// Token: 0x06000DAD RID: 3501 RVA: 0x00050770 File Offset: 0x0004E970
		internal void SetKillStreak(int killStreak)
		{
			this.KillStreakCounter.text = killStreak.ToString();
			if (this.FadeInKillStreakAnimator.isInitialized)
			{
				this.FadeInKillStreakAnimator.SetBool(this._isOnHash, killStreak > 0);
			}
			if (killStreak == 0)
			{
				this.FadeInKillStreakAnimator.Rebind();
			}
		}

		// Token: 0x06000DAE RID: 3502 RVA: 0x000507CC File Offset: 0x0004E9CC
		public void Update()
		{
			if (this.SendTestKillNotificationNow)
			{
				this.SendTestKillNotificationNow = false;
				this.NotifyKill(this.TestKillerName, this.TestVictimName, this.TestKillerTeam, this.TestVictimTeam, this.TestWeaponCategory, this.TestIsHeadshot, this.TestDistance);
			}
			if (this.SendTestEventNotificationNow)
			{
				this.SendTestEventNotificationNow = false;
				this.NotifyEvent(this.TestEventPlayerName, this.TestEventPlayerTeam, this.TestEventUserEvent);
			}
			if (this.DoTestKillStreak)
			{
				this.SetKillStreak(this.TestKillStreakCount);
			}
			this._timeSinceEvent += Time.deltaTime;
			if (this.FadeInListAnimator.isInitialized)
			{
				this.FadeInListAnimator.SetBool(this._isOnHash, this._timeSinceEvent < this.ListShowTime);
			}
		}

		// Token: 0x06000DAF RID: 3503 RVA: 0x0000B5EC File Offset: 0x000097EC
		public void LateUpdate()
		{
			if (this._timeSinceEvent > 0.5f && !this.ReferenceForListVisibility.activeInHierarchy)
			{
				this.EntryList.SetActiveCount(0);
			}
		}

		// Token: 0x06000DB0 RID: 3504 RVA: 0x0000B61A File Offset: 0x0000981A
		internal void NotifyEvent(string nickname, UITeam uITeam, object becomesJuggernaut)
		{
			throw new NotImplementedException();
		}

		// Token: 0x040010AC RID: 4268
		public float LongShotDistance = 20f;

		// Token: 0x040010AD RID: 4269
		public int MaximumItems = 10;

		// Token: 0x040010AE RID: 4270
		public float ListShowTime = 5f;

		// Token: 0x040010AF RID: 4271
		public Animator FadeInListAnimator;

		// Token: 0x040010B0 RID: 4272
		public GameObject ReferenceForListVisibility;

		// Token: 0x040010B1 RID: 4273
		public GameplayKillListView.GameplayKillListItemComponentList EntryList;

		// Token: 0x040010B2 RID: 4274
		public Animator FadeInKillStreakAnimator;

		// Token: 0x040010B3 RID: 4275
		public Text KillStreakCounter;

		// Token: 0x040010B4 RID: 4276
		[Header("Testing")]
		public string TestKillerName = "Killah";

		// Token: 0x040010B5 RID: 4277
		public string TestVictimName = "Sucka";

		// Token: 0x040010B6 RID: 4278
		public UITeam TestKillerTeam;

		// Token: 0x040010B7 RID: 4279
		public UITeam TestVictimTeam;

		// Token: 0x040010B8 RID: 4280
		public EWeaponCategory TestWeaponCategory;

		// Token: 0x040010B9 RID: 4281
		public bool TestIsHeadshot;

		// Token: 0x040010BA RID: 4282
		public float TestDistance = 15f;

		// Token: 0x040010BB RID: 4283
		public bool SendTestKillNotificationNow;

		// Token: 0x040010BC RID: 4284
		public string TestEventPlayerName = "Willa";

		// Token: 0x040010BD RID: 4285
		public UITeam TestEventPlayerTeam;

		// Token: 0x040010BE RID: 4286
		public UserUpdateType TestEventUserEvent;

		// Token: 0x040010BF RID: 4287
		public bool SendTestEventNotificationNow;

		// Token: 0x040010C0 RID: 4288
		public bool DoTestKillStreak;

		// Token: 0x040010C1 RID: 4289
		public int TestKillStreakCount;

		// Token: 0x040010C2 RID: 4290
		private float _timeSinceEvent = 999f;

		// Token: 0x040010C3 RID: 4291
		private readonly int _isOnHash = Animator.StringToHash("isOn");

		// Token: 0x02000284 RID: 644
		[Serializable]
		public class GameplayKillListItemComponentList : PoolableList<GameplayKillListItemComponent>
		{
		}
	}
}
