﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200028B RID: 651
	public class GameplayScoreboardStatsView : BaseView<GameplayScoreboardController>
	{
		// Token: 0x06000DDE RID: 3550 RVA: 0x00051B1C File Offset: 0x0004FD1C
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.FreeCameraToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnFreeCameraClick));
			this.CycleNextBtn.onClick.AddListener(new UnityAction(this.OnCycleNext));
			this.CyclePreviousBtn.onClick.AddListener(new UnityAction(this.OnCyclePrevious));
			this.AutoCycleToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnAutoCycleClick));
			this.ShowSpecToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnShowSpecClick));
		}

		// Token: 0x06000DDF RID: 3551 RVA: 0x0000B7BC File Offset: 0x000099BC
		private void OnShowSpecClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetSpectatorShowInfo(value);
		}

		// Token: 0x06000DE0 RID: 3552 RVA: 0x0000B7D6 File Offset: 0x000099D6
		private void OnAutoCycleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			base._controller.SetSpectatorAutoCycle(value);
		}

		// Token: 0x06000DE1 RID: 3553 RVA: 0x0000B7F0 File Offset: 0x000099F0
		private void OnCyclePrevious()
		{
			base._controller.SpectatorCyclePrevious();
		}

		// Token: 0x06000DE2 RID: 3554 RVA: 0x0000B7FD File Offset: 0x000099FD
		private void OnCycleNext()
		{
			base._controller.SpectatorCycleNext();
		}

		// Token: 0x06000DE3 RID: 3555 RVA: 0x0000B80A File Offset: 0x00009A0A
		private void OnFreeCameraClick(bool value)
		{
			if (this._isSetting || !value)
			{
				return;
			}
			base._controller.DispatchSpectatorFreeCamera();
		}

		// Token: 0x06000DE4 RID: 3556 RVA: 0x00051BC8 File Offset: 0x0004FDC8
		internal void SetData(EClientMode clientMode, EGameMode mode, string playerName, EHeroClass selectedClass)
		{
			this.TdmRoot.SetActive(mode == EGameMode.TeamDeathMatch && clientMode == EClientMode.PLAYER);
			this.RoundsRoot.SetActive(mode == EGameMode.Rounds && clientMode == EClientMode.PLAYER);
			this.FfaRoot.SetActive(mode == EGameMode.FreeForAll && clientMode == EClientMode.PLAYER);
			this.KothRoot.SetActive(mode == EGameMode.KingOfTheHill && clientMode == EClientMode.PLAYER);
			this.CtpRoot.SetActive(mode == EGameMode.Conquest && clientMode == EClientMode.PLAYER);
			this.JugRoot.SetActive(mode == EGameMode.Juggernaut && clientMode == EClientMode.PLAYER);
			this.SpectatorRoot.SetActive(clientMode == EClientMode.SPECTATOR);
			if (clientMode == EClientMode.PLAYER)
			{
				string classIconPath = TextureHelper.GetClassIconPath(selectedClass);
				switch (mode)
				{
				case EGameMode.TeamDeathMatch:
					TextureHelper.LoadImageAsync(classIconPath, this.TdmClassIcon, false, EImageSource.RESOURCES);
					this.TdmPlayerNameText.text = playerName;
					break;
				case EGameMode.Conquest:
					TextureHelper.LoadImageAsync(classIconPath, this.CtpClassIcon, false, EImageSource.RESOURCES);
					this.CtpPlayerNameText.text = playerName;
					break;
				case EGameMode.KingOfTheHill:
					TextureHelper.LoadImageAsync(classIconPath, this.KothClassIcon, false, EImageSource.RESOURCES);
					this.KothPlayerNameText.text = playerName;
					break;
				case EGameMode.Rounds:
					TextureHelper.LoadImageAsync(classIconPath, this.RoundsClassIcon, false, EImageSource.RESOURCES);
					this.RoundsPlayerNameText.text = playerName;
					break;
				case EGameMode.FreeForAll:
					TextureHelper.LoadImageAsync(classIconPath, this.FfaClassIcon, false, EImageSource.RESOURCES);
					this.FfaPlayerNameText.text = playerName;
					break;
				case EGameMode.Juggernaut:
					TextureHelper.LoadImageAsync(classIconPath, this.JugClassIcon, false, EImageSource.RESOURCES);
					this.JugPlayerNameText.text = playerName;
					break;
				}
			}
		}

		// Token: 0x06000DE5 RID: 3557 RVA: 0x00051D68 File Offset: 0x0004FF68
		internal void TdmUpdateData(int maxKillStreak, float killRate, int totalDamage, float killDeathRatio)
		{
			if (maxKillStreak != this._lastMaxKillStreak)
			{
				this.TdmMaxKillstreakText.text = maxKillStreak.ToString();
				this._lastMaxKillStreak = maxKillStreak;
			}
			if (Mathf.RoundToInt(killRate) != this._lastKillRate)
			{
				this._lastKillRate = Mathf.RoundToInt(killRate);
				this.TdmKillRateText.text = this._lastKillRate + "%";
			}
			if (totalDamage != this._totalDamage)
			{
				this.TdmTotalDamageText.text = totalDamage.ToString();
				this._totalDamage = totalDamage;
			}
			if (Math.Abs(killDeathRatio - this._lastKillDeathRatio) > Mathf.Epsilon)
			{
				this._lastKillDeathRatio = killDeathRatio;
				this.TdmKdRatioText.text = killDeathRatio.ToString("0.00");
			}
		}

		// Token: 0x06000DE6 RID: 3558 RVA: 0x00051E40 File Offset: 0x00050040
		internal void RoundsUpdateData(int maxKillStreak, float killRate, int totalDamage, float killDeathRatio)
		{
			if (maxKillStreak != this._lastMaxKillStreak)
			{
				this.RoundsMaxKillstreakText.text = maxKillStreak.ToString();
				this._lastMaxKillStreak = maxKillStreak;
			}
			if (Mathf.RoundToInt(killRate) != this._lastKillRate)
			{
				this._lastKillRate = Mathf.RoundToInt(killRate);
				this.RoundsKillRateText.text = this._lastKillRate + "%";
			}
			if (totalDamage != this._totalDamage)
			{
				this.RoundsTotalDamageText.text = totalDamage.ToString();
				this._totalDamage = totalDamage;
			}
			if (Math.Abs(killDeathRatio - this._lastKillDeathRatio) > Mathf.Epsilon)
			{
				this._lastKillDeathRatio = killDeathRatio;
				this.RoundsKdRatioText.text = killDeathRatio.ToString("0.00");
			}
		}

		// Token: 0x06000DE7 RID: 3559 RVA: 0x00051F18 File Offset: 0x00050118
		internal void FfaUpdateData(int maxKillStreak, float killRate, int totalDamage, float killDeathRatio)
		{
			if (maxKillStreak != this._lastMaxKillStreak)
			{
				this.FfaMaxKillstreakText.text = maxKillStreak.ToString();
				this._lastMaxKillStreak = maxKillStreak;
			}
			if (Mathf.RoundToInt(killRate) != this._lastKillRate)
			{
				this._lastKillRate = Mathf.RoundToInt(killRate);
				this.FfaKillRateText.text = this._lastKillRate + "%";
			}
			if (totalDamage != this._totalDamage)
			{
				this.FfaTotalDamageText.text = totalDamage.ToString();
				this._totalDamage = totalDamage;
			}
			if (Math.Abs(killDeathRatio - this._lastKillDeathRatio) > Mathf.Epsilon)
			{
				this._lastKillDeathRatio = killDeathRatio;
				this.FfaKdRatioText.text = killDeathRatio.ToString("0.00");
			}
		}

		// Token: 0x06000DE8 RID: 3560 RVA: 0x00051FF0 File Offset: 0x000501F0
		internal void KothUpdateData(int maxKillStreak, int guardTime, int guardKills, float killDeathRatio)
		{
			if (maxKillStreak != this._lastMaxKillStreak)
			{
				this.KothMaxKillstreakText.text = maxKillStreak.ToString();
				this._lastMaxKillStreak = maxKillStreak;
			}
			if (guardTime != this._guardTime)
			{
				this.KothGuardingTimeText.text = guardTime + "s";
				this._guardTime = guardTime;
			}
			if (guardKills != this._guardKills)
			{
				this.KothGuardKillsText.text = guardKills.ToString();
				this._guardKills = guardKills;
			}
			if (Math.Abs(killDeathRatio - this._lastKillDeathRatio) > Mathf.Epsilon)
			{
				this._lastKillDeathRatio = killDeathRatio;
				this.KothKdRatioText.text = killDeathRatio.ToString("0.00");
			}
		}

		// Token: 0x06000DE9 RID: 3561 RVA: 0x000520B8 File Offset: 0x000502B8
		internal void CtpUpdateData(int maxKillStreak, int captures, int guardKills, float killDeathRatio)
		{
			if (maxKillStreak != this._lastMaxKillStreak)
			{
				this.CtpMaxKillstreakText.text = maxKillStreak.ToString();
				this._lastMaxKillStreak = maxKillStreak;
			}
			if (captures != this._captures)
			{
				this.CtpCapturesText.text = captures.ToString();
				this._captures = captures;
			}
			if (guardKills != this._guardKills)
			{
				this.CtpGuardKillsText.text = guardKills.ToString();
				this._guardKills = guardKills;
			}
			if (Math.Abs(killDeathRatio - this._lastKillDeathRatio) > Mathf.Epsilon)
			{
				this._lastKillDeathRatio = killDeathRatio;
				this.CtpKdRatioText.text = killDeathRatio.ToString("0.00");
			}
		}

		// Token: 0x06000DEA RID: 3562 RVA: 0x00052180 File Offset: 0x00050380
		internal void JugUpdateData(int maxKillStreak, float killRate, int totalDamage, float killDeathRatio)
		{
			if (maxKillStreak != this._lastMaxKillStreak)
			{
				this.JugMaxKillstreakText.text = maxKillStreak.ToString();
				this._lastMaxKillStreak = maxKillStreak;
			}
			if (Mathf.RoundToInt(killRate) != this._lastKillRate)
			{
				this._lastKillRate = Mathf.RoundToInt(killRate);
				this.JugKillRateText.text = this._lastKillRate + "%";
			}
			if (totalDamage != this._totalDamage)
			{
				this.JugTotalDamageText.text = totalDamage.ToString();
				this._totalDamage = totalDamage;
			}
			if (Math.Abs(killDeathRatio - this._lastKillDeathRatio) > Mathf.Epsilon)
			{
				this._lastKillDeathRatio = killDeathRatio;
				this.JugKdRatioText.text = killDeathRatio.ToString("0.00");
			}
		}

		// Token: 0x06000DEB RID: 3563 RVA: 0x00052258 File Offset: 0x00050458
		public void SetSpectatorData(bool isFreeCamera, bool isAutoCycle, bool isShowInfo, bool hasOrbitSpawned)
		{
			this._isSetting = true;
			this.CyclePreviousBtn.interactable = hasOrbitSpawned;
			this.CycleNextBtn.interactable = hasOrbitSpawned;
			this.FreeCameraToggle.isOn = isFreeCamera;
			this.AutoCycleToggle.isOn = isAutoCycle;
			this.ShowSpecToggle.isOn = isShowInfo;
			this._isSetting = false;
		}

		// Token: 0x040010FD RID: 4349
		public GameObject TdmRoot;

		// Token: 0x040010FE RID: 4350
		public GameObject RoundsRoot;

		// Token: 0x040010FF RID: 4351
		public GameObject FfaRoot;

		// Token: 0x04001100 RID: 4352
		public GameObject CtpRoot;

		// Token: 0x04001101 RID: 4353
		public GameObject KothRoot;

		// Token: 0x04001102 RID: 4354
		public GameObject JugRoot;

		// Token: 0x04001103 RID: 4355
		public GameObject SpectatorRoot;

		// Token: 0x04001104 RID: 4356
		[Header("Team Deathmatch")]
		public RawImage TdmClassIcon;

		// Token: 0x04001105 RID: 4357
		public Text TdmPlayerNameText;

		// Token: 0x04001106 RID: 4358
		public Text TdmMaxKillstreakText;

		// Token: 0x04001107 RID: 4359
		public Text TdmKillRateText;

		// Token: 0x04001108 RID: 4360
		public Text TdmTotalDamageText;

		// Token: 0x04001109 RID: 4361
		public Text TdmKdRatioText;

		// Token: 0x0400110A RID: 4362
		[Header("Rounds")]
		public RawImage RoundsClassIcon;

		// Token: 0x0400110B RID: 4363
		public Text RoundsPlayerNameText;

		// Token: 0x0400110C RID: 4364
		public Text RoundsMaxKillstreakText;

		// Token: 0x0400110D RID: 4365
		public Text RoundsKillRateText;

		// Token: 0x0400110E RID: 4366
		public Text RoundsTotalDamageText;

		// Token: 0x0400110F RID: 4367
		public Text RoundsKdRatioText;

		// Token: 0x04001110 RID: 4368
		[Header("Free for All")]
		public RawImage FfaClassIcon;

		// Token: 0x04001111 RID: 4369
		public Text FfaPlayerNameText;

		// Token: 0x04001112 RID: 4370
		public Text FfaMaxKillstreakText;

		// Token: 0x04001113 RID: 4371
		public Text FfaKillRateText;

		// Token: 0x04001114 RID: 4372
		public Text FfaTotalDamageText;

		// Token: 0x04001115 RID: 4373
		public Text FfaKdRatioText;

		// Token: 0x04001116 RID: 4374
		[Header("King of the Hill")]
		public RawImage KothClassIcon;

		// Token: 0x04001117 RID: 4375
		public Text KothPlayerNameText;

		// Token: 0x04001118 RID: 4376
		public Text KothMaxKillstreakText;

		// Token: 0x04001119 RID: 4377
		public Text KothGuardingTimeText;

		// Token: 0x0400111A RID: 4378
		public Text KothGuardKillsText;

		// Token: 0x0400111B RID: 4379
		public Text KothKdRatioText;

		// Token: 0x0400111C RID: 4380
		[Header("Capture Point")]
		public RawImage CtpClassIcon;

		// Token: 0x0400111D RID: 4381
		public Text CtpPlayerNameText;

		// Token: 0x0400111E RID: 4382
		public Text CtpMaxKillstreakText;

		// Token: 0x0400111F RID: 4383
		public Text CtpCapturesText;

		// Token: 0x04001120 RID: 4384
		public Text CtpGuardKillsText;

		// Token: 0x04001121 RID: 4385
		public Text CtpKdRatioText;

		// Token: 0x04001122 RID: 4386
		[Header("Juggernaut")]
		public RawImage JugClassIcon;

		// Token: 0x04001123 RID: 4387
		public Text JugPlayerNameText;

		// Token: 0x04001124 RID: 4388
		public Text JugMaxKillstreakText;

		// Token: 0x04001125 RID: 4389
		public Text JugKillRateText;

		// Token: 0x04001126 RID: 4390
		public Text JugTotalDamageText;

		// Token: 0x04001127 RID: 4391
		public Text JugKdRatioText;

		// Token: 0x04001128 RID: 4392
		[Header("Spectator")]
		public Toggle FreeCameraToggle;

		// Token: 0x04001129 RID: 4393
		public Button CyclePreviousBtn;

		// Token: 0x0400112A RID: 4394
		public Button CycleNextBtn;

		// Token: 0x0400112B RID: 4395
		public Toggle AutoCycleToggle;

		// Token: 0x0400112C RID: 4396
		public Toggle ShowSpecToggle;

		// Token: 0x0400112D RID: 4397
		private int _lastMaxKillStreak = -1;

		// Token: 0x0400112E RID: 4398
		private int _lastKillRate = -1;

		// Token: 0x0400112F RID: 4399
		private float _lastKillDeathRatio = -1f;

		// Token: 0x04001130 RID: 4400
		private int _totalDamage = -1;

		// Token: 0x04001131 RID: 4401
		private int _guardTime = -1;

		// Token: 0x04001132 RID: 4402
		private int _guardKills = -1;

		// Token: 0x04001133 RID: 4403
		private int _captures = -1;

		// Token: 0x04001134 RID: 4404
		private bool _isSetting;
	}
}
