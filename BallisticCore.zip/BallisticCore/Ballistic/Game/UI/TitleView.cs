﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Pattern.Singleton;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200031F RID: 799
	public class TitleView : MonoBehaviour
	{
		// Token: 0x060010E6 RID: 4326 RVA: 0x000615BC File Offset: 0x0005F7BC
		public void Start()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			ServiceProvider.GetService<AssetPreloadService>();
			this.Version.text = string.Format("BUILD v1.5.7 / {1}", BallisticVersion.VERSION.Remove(5), SystemInfo.graphicsDeviceType);
			this._eventSystem = Singleton<UIEventSystem>.Instance;
			this._functionExecuted = false;
			this._loadingScene = false;
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x0006161C File Offset: 0x0005F81C
		public void Update()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (Input.anyKeyDown && !this._loadingScene)
			{
				this._eventSystem.DispatchEvent("press_key", new object[] { 4 });
				this._loadingScene = true;
			}
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x0000DF1F File Offset: 0x0000C11F
		public void LoadNextScene()
		{
			if (this._functionExecuted)
			{
				return;
			}
			this._functionExecuted = true;
			ServiceProvider.GetService<SceneService>().LoadMain(string.Empty);
		}

		// Token: 0x0400161A RID: 5658
		public Text Version;

		// Token: 0x0400161B RID: 5659
		public List<Animator> TargetAnimators;

		// Token: 0x0400161C RID: 5660
		private bool _loadingScene;

		// Token: 0x0400161D RID: 5661
		private bool _functionExecuted;

		// Token: 0x0400161E RID: 5662
		private UIEventSystem _eventSystem;
	}
}
