﻿using System;
using Aquiris.Ballistic.Network.Discovery;
using Steamworks;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000250 RID: 592
	internal struct FriendHostItem
	{
		// Token: 0x04000F8C RID: 3980
		internal CSteamID friend;

		// Token: 0x04000F8D RID: 3981
		internal HostItem hostItem;
	}
}
