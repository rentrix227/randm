﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000298 RID: 664
	internal class DeathScreenIndicator : BaseScreenIndicator
	{
		// Token: 0x06000E2C RID: 3628 RVA: 0x0000B9BE File Offset: 0x00009BBE
		internal void SetNickname(string nickname)
		{
			this.IndicatorComponent.SetNickname(nickname);
		}

		// Token: 0x06000E2D RID: 3629 RVA: 0x000544EC File Offset: 0x000526EC
		internal void UpdateMarker(Vector3 worldPosition)
		{
			base.UpdateMarkerPosition(worldPosition);
			if (base._camera == null)
			{
				this.IndicatorComponent.UpdateInfo(false);
				return;
			}
			float num = Vector3.Distance(worldPosition, base._camera.transform.position);
			bool flag = num < this.DistanceToShow;
			this.IndicatorComponent.UpdateInfo(flag);
		}

		// Token: 0x04001205 RID: 4613
		internal GameplayScreenIndicatorDeathComponent IndicatorComponent;

		// Token: 0x04001206 RID: 4614
		internal float DistanceToShow;
	}
}
