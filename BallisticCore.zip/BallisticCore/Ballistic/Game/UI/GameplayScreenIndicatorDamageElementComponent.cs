﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D1 RID: 465
	public class GameplayScreenIndicatorDamageElementComponent : MonoBehaviour
	{
		// Token: 0x06000999 RID: 2457 RVA: 0x00008A9E File Offset: 0x00006C9E
		public void SetDamageAmount(int damage)
		{
			this.DamageAmount.text = damage.ToString();
		}

		// Token: 0x04000CBF RID: 3263
		public Text DamageAmount;

		// Token: 0x04000CC0 RID: 3264
		public float TimeToDestroy = 5f;
	}
}
