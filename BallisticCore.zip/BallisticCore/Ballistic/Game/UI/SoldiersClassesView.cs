﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000314 RID: 788
	public class SoldiersClassesView : BaseView<SoldiersController>
	{
		// Token: 0x060010A0 RID: 4256 RVA: 0x00060664 File Offset: 0x0005E864
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.BeserkerToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnBerserkerSelected));
			this.VanguardToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnVanguardSelected));
			this.WraithToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnWraithSelected));
			this.ShadowToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnShadowSelected));
			this.TankToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnTankSelected));
			this.GrenadierToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnGrenadierSelected));
			this.MarksmanToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnMarksmanSelected));
		}

		// Token: 0x060010A1 RID: 4257 RVA: 0x00060748 File Offset: 0x0005E948
		internal void SetSoldier(EHeroClass heroClass)
		{
			this._isSetting = true;
			this.BeserkerToggle.isOn = heroClass == EHeroClass.BERSERKER;
			this.VanguardToggle.isOn = heroClass == EHeroClass.VANGUARD;
			this.WraithToggle.isOn = heroClass == EHeroClass.WRAITH;
			this.ShadowToggle.isOn = heroClass == EHeroClass.SHADOW;
			this.TankToggle.isOn = heroClass == EHeroClass.TANK;
			this.MarksmanToggle.isOn = heroClass == EHeroClass.MARKSMAN;
			this._isSetting = false;
		}

		// Token: 0x060010A2 RID: 4258 RVA: 0x0000DB14 File Offset: 0x0000BD14
		private void OnBerserkerSelected(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.DispatchSoldierChanged(EHeroClass.BERSERKER);
		}

		// Token: 0x060010A3 RID: 4259 RVA: 0x0000DB34 File Offset: 0x0000BD34
		private void OnVanguardSelected(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.DispatchSoldierChanged(EHeroClass.VANGUARD);
		}

		// Token: 0x060010A4 RID: 4260 RVA: 0x0000DB54 File Offset: 0x0000BD54
		private void OnWraithSelected(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.DispatchSoldierChanged(EHeroClass.WRAITH);
		}

		// Token: 0x060010A5 RID: 4261 RVA: 0x0000DB74 File Offset: 0x0000BD74
		private void OnShadowSelected(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.DispatchSoldierChanged(EHeroClass.SHADOW);
		}

		// Token: 0x060010A6 RID: 4262 RVA: 0x0000DB94 File Offset: 0x0000BD94
		private void OnTankSelected(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.DispatchSoldierChanged(EHeroClass.TANK);
		}

		// Token: 0x060010A7 RID: 4263 RVA: 0x0000DBB4 File Offset: 0x0000BDB4
		private void OnGrenadierSelected(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.DispatchSoldierChanged(EHeroClass.GRENADIER);
		}

		// Token: 0x060010A8 RID: 4264 RVA: 0x0000DBD4 File Offset: 0x0000BDD4
		private void OnMarksmanSelected(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.DispatchSoldierChanged(EHeroClass.MARKSMAN);
		}

		// Token: 0x040015DD RID: 5597
		public Toggle BeserkerToggle;

		// Token: 0x040015DE RID: 5598
		public Toggle VanguardToggle;

		// Token: 0x040015DF RID: 5599
		public Toggle WraithToggle;

		// Token: 0x040015E0 RID: 5600
		public Toggle ShadowToggle;

		// Token: 0x040015E1 RID: 5601
		public Toggle TankToggle;

		// Token: 0x040015E2 RID: 5602
		public Toggle GrenadierToggle;

		// Token: 0x040015E3 RID: 5603
		public Toggle MarksmanToggle;

		// Token: 0x040015E4 RID: 5604
		private bool _isSetting;
	}
}
