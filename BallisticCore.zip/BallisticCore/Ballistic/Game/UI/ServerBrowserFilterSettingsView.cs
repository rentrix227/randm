﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000303 RID: 771
	public class ServerBrowserFilterSettingsView : BaseView<ServerBrowserController>
	{
		// Token: 0x06000FF9 RID: 4089 RVA: 0x0005DAB8 File Offset: 0x0005BCB8
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._locationService = ServiceProvider.GetService<LocalizationService>();
			this._mapIndexes = new List<GameMapConfig>();
			this._modeIndexes = new List<EGameMode>();
			this._latencyIndexes = new List<ELatency>();
			this.ServerNameInputField.onEndEdit.AddListener(new UnityAction<string>(this.OnSearchServerSubmit));
			this.MapDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnMapsDropdownValueChanged));
			this.ModeDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnModesDropdownValueChanged));
			this.LatencyDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnLatencyDropdownValueChanged));
			this.FriendsOnlyToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnFriendsToggleClick));
			this.RefreshButton.onClick.AddListener(new UnityAction(this.OnRefreshClick));
		}

		// Token: 0x06000FFA RID: 4090 RVA: 0x0005DBAC File Offset: 0x0005BDAC
		internal void SetMapDropdown(GameMapConfig[] maps, GameMapConfig mapDefault)
		{
			this._mapIndexes.Clear();
			this.MapDropdown.options.Clear();
			foreach (GameMapConfig gameMapConfig in maps)
			{
				this._mapIndexes.Add(gameMapConfig);
				this.MapDropdown.options.Add(new Dropdown.OptionData(this._locationService.GetMapName(gameMapConfig.MapId, ELocalizedTextCase.UPPER_CASE)));
			}
			int num = Array.IndexOf<GameMapConfig>(maps, mapDefault);
			if (num != -1)
			{
				this.MapDropdown.value = num;
			}
			this.MapDropdown.RefreshShownValue();
		}

		// Token: 0x06000FFB RID: 4091 RVA: 0x0005DC48 File Offset: 0x0005BE48
		internal void SetModeDropdown(EGameMode[] modes, EGameMode modeDefault)
		{
			this._modeIndexes.Clear();
			this.ModeDropdown.options.Clear();
			foreach (EGameMode egameMode in modes)
			{
				this._modeIndexes.Add(egameMode);
				this.ModeDropdown.options.Add(new Dropdown.OptionData(this._locationService.GetModeName(egameMode, ELocalizedTextCase.UPPER_CASE)));
			}
			int num = Array.IndexOf<EGameMode>(modes, modeDefault);
			if (num != -1)
			{
				this.ModeDropdown.value = num;
			}
			this.ModeDropdown.RefreshShownValue();
		}

		// Token: 0x06000FFC RID: 4092 RVA: 0x0005DCE0 File Offset: 0x0005BEE0
		internal void SetLatencyDropdown(ELatency[] latencies, ELatency latencyDefault)
		{
			this.LatencyDropdown.options.Clear();
			foreach (ELatency elatency in latencies)
			{
				this._latencyIndexes.Add(elatency);
				this.LatencyDropdown.options.Add(new Dropdown.OptionData(this._locationService.Get("latency_" + elatency, ELocalizedTextCase.UPPER_CASE)));
			}
			int num = Array.IndexOf<ELatency>(latencies, latencyDefault);
			if (num != -1)
			{
				this.LatencyDropdown.value = num;
			}
			this.LatencyDropdown.RefreshShownValue();
		}

		// Token: 0x06000FFD RID: 4093 RVA: 0x0000D1FB File Offset: 0x0000B3FB
		private void OnFriendsToggleClick(bool value)
		{
			base._controller.SetFriendsOnly(value);
			base._controller.RefreshServerList();
		}

		// Token: 0x06000FFE RID: 4094 RVA: 0x0000D214 File Offset: 0x0000B414
		private void OnSearchServerSubmit(string value)
		{
			base._controller.SetServerName(value);
			base._controller.UpdateServerList();
		}

		// Token: 0x06000FFF RID: 4095 RVA: 0x0000D22D File Offset: 0x0000B42D
		private void OnMapsDropdownValueChanged(int value)
		{
			base._controller.SetMap(this._mapIndexes[value]);
			base._controller.UpdateServerList();
		}

		// Token: 0x06001000 RID: 4096 RVA: 0x0000D251 File Offset: 0x0000B451
		private void OnModesDropdownValueChanged(int value)
		{
			base._controller.SetMode(this._modeIndexes[value]);
			base._controller.UpdateServerList();
		}

		// Token: 0x06001001 RID: 4097 RVA: 0x0000D275 File Offset: 0x0000B475
		private void OnLatencyDropdownValueChanged(int value)
		{
			base._controller.SetLatency(this._latencyIndexes[value]);
			base._controller.UpdateServerList();
		}

		// Token: 0x06001002 RID: 4098 RVA: 0x0000D299 File Offset: 0x0000B499
		private void OnRefreshClick()
		{
			base._controller.RefreshServerList();
		}

		// Token: 0x04001527 RID: 5415
		public InputField ServerNameInputField;

		// Token: 0x04001528 RID: 5416
		public Dropdown MapDropdown;

		// Token: 0x04001529 RID: 5417
		public Dropdown ModeDropdown;

		// Token: 0x0400152A RID: 5418
		public Dropdown LatencyDropdown;

		// Token: 0x0400152B RID: 5419
		public Toggle FriendsOnlyToggle;

		// Token: 0x0400152C RID: 5420
		public Button RefreshButton;

		// Token: 0x0400152D RID: 5421
		private LocalizationService _locationService;

		// Token: 0x0400152E RID: 5422
		private List<GameMapConfig> _mapIndexes;

		// Token: 0x0400152F RID: 5423
		private List<EGameMode> _modeIndexes;

		// Token: 0x04001530 RID: 5424
		private List<ELatency> _latencyIndexes;
	}
}
