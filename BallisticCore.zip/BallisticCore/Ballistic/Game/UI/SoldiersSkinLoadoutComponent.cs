﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200020A RID: 522
	public class SoldiersSkinLoadoutComponent : MonoBehaviour
	{
		// Token: 0x06000A82 RID: 2690 RVA: 0x0003D640 File Offset: 0x0003B840
		internal void SetData(HeroSkin heroSkin)
		{
			if (heroSkin == null)
			{
				return;
			}
			if (this.WeaponImage != null)
			{
				string classSkinLoadoutImagePath = TextureHelper.GetClassSkinLoadoutImagePath(heroSkin.ItemName);
				TextureHelper.LoadImageAsync(classSkinLoadoutImagePath, this.WeaponImage, false, EImageSource.RESOURCES);
			}
		}

		// Token: 0x04000E04 RID: 3588
		public RawImage WeaponImage;
	}
}
