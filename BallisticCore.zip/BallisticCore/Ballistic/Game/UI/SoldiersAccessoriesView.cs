﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000312 RID: 786
	public class SoldiersAccessoriesView : BaseView<SoldiersController>
	{
		// Token: 0x06001092 RID: 4242 RVA: 0x0006024C File Offset: 0x0005E44C
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.AccessoryTemplate.Template.Dispose();
			for (int i = 0; i < this.AccessoryPreviewLists.Length; i++)
			{
				this.AccessoryPreviewLists[i].Template.Dispose();
			}
		}

		// Token: 0x06001093 RID: 4243 RVA: 0x0000DA0B File Offset: 0x0000BC0B
		internal void SetStartAccessoryList(IEnumerable<Accessory> avaliableAccessories, List<Dictionary<EHeroItemSlot, Accessory>> selectedAccessories, int currentAccessoriesSet)
		{
			this._avaliableAccessories = avaliableAccessories.ToArray<Accessory>();
			this._selectedAccessories = selectedAccessories;
			this._currentAccessoriesSet = currentAccessoriesSet;
			this.ChangeDataComplete();
		}

		// Token: 0x06001094 RID: 4244 RVA: 0x0000DA2D File Offset: 0x0000BC2D
		internal void SetAccessoryList(IEnumerable<Accessory> avaliableAccessories, List<Dictionary<EHeroItemSlot, Accessory>> selectedAccessories, int currentAccessoriesSet)
		{
			this._avaliableAccessories = avaliableAccessories.ToArray<Accessory>();
			this._selectedAccessories = selectedAccessories;
			this._currentAccessoriesSet = currentAccessoriesSet;
		}

		// Token: 0x06001095 RID: 4245 RVA: 0x000602A8 File Offset: 0x0005E4A8
		private void OnAccessorySelected(Accessory accessory)
		{
			if (!this._selectedAccessories[this._currentAccessoriesSet].ContainsValue(accessory))
			{
				base._controller.DispatchSoldierAccessoryChanged(accessory, accessory.EquippableAt);
			}
			else
			{
				base._controller.DispatchSoldierAccessoryChanged(null, accessory.EquippableAt);
			}
		}

		// Token: 0x06001096 RID: 4246 RVA: 0x000602FC File Offset: 0x0005E4FC
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.AccessoryTemplate.SetActiveCount(this._avaliableAccessories.Length);
			for (int i = 0; i < this._avaliableAccessories.Length; i++)
			{
				SoldiersAccessoryComponent soldiersAccessoryComponent = (SoldiersAccessoryComponent)this.AccessoryTemplate[i];
				bool flag = this._selectedAccessories[this._currentAccessoriesSet].ContainsValue(this._avaliableAccessories[i]);
				this._comparableSlot = this._avaliableAccessories[i].EquippableAt;
				bool flag2 = this._selectedAccessories[this._currentAccessoriesSet].Values.All(new Func<Accessory, bool>(this.IsSlotFree));
				soldiersAccessoryComponent.SetData(this._avaliableAccessories[i], flag, flag || flag2);
				soldiersAccessoryComponent.OnToggleClicked = new Action<Accessory>(this.OnAccessorySelected);
			}
			int num = 0;
			while (num < this.AccessoryPreviewLists.Length && num < this._selectedAccessories.Count)
			{
				this.AccessoryPreviewLists[num].SetActiveCount(this._avaliableAccessories.Length);
				for (int j = 0; j < this._avaliableAccessories.Length; j++)
				{
					SoldiersAccessoryComponent soldiersAccessoryComponent2 = (SoldiersAccessoryComponent)this.AccessoryPreviewLists[num][j];
					bool flag3 = this._selectedAccessories[num].ContainsValue(this._avaliableAccessories[j]);
					this._comparableSlot = this._avaliableAccessories[j].EquippableAt;
					bool flag4 = this._selectedAccessories[num].Values.All(new Func<Accessory, bool>(this.IsSlotFree));
					soldiersAccessoryComponent2.SetData(this._avaliableAccessories[j], flag3, flag3 || flag4);
					soldiersAccessoryComponent2.OnToggleClicked = null;
				}
				num++;
			}
		}

		// Token: 0x06001097 RID: 4247 RVA: 0x0000DA49 File Offset: 0x0000BC49
		private bool IsSlotFree(Accessory accessory)
		{
			return accessory.IsDefaultAccessory || accessory.EquippableAt != this._comparableSlot;
		}

		// Token: 0x040015CC RID: 5580
		public PoolableList AccessoryTemplate;

		// Token: 0x040015CD RID: 5581
		public PoolableList[] AccessoryPreviewLists;

		// Token: 0x040015CE RID: 5582
		private Accessory[] _avaliableAccessories;

		// Token: 0x040015CF RID: 5583
		private List<Dictionary<EHeroItemSlot, Accessory>> _selectedAccessories;

		// Token: 0x040015D0 RID: 5584
		private int _currentAccessoriesSet;

		// Token: 0x040015D1 RID: 5585
		private EHeroItemSlot _comparableSlot;
	}
}
