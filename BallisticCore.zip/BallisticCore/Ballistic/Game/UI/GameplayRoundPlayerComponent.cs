﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001CC RID: 460
	public class GameplayRoundPlayerComponent : PoolableComponent
	{
		// Token: 0x0600098A RID: 2442 RVA: 0x0000894C File Offset: 0x00006B4C
		internal void SetState(bool InMatch, bool IsAlive)
		{
			this._inMatch = InMatch;
			this._isAlive = IsAlive;
		}

		// Token: 0x0600098B RID: 2443 RVA: 0x0000895C File Offset: 0x00006B5C
		public void Update()
		{
			if (this.Animator.isInitialized)
			{
				this.Animator.SetBool(GameplayRoundPlayerComponent._anim_param_inmatch, this._inMatch);
				this.Animator.SetBool(GameplayRoundPlayerComponent._anim_param_isalive, this._isAlive);
			}
		}

		// Token: 0x04000CA7 RID: 3239
		private static readonly int _anim_param_inmatch = Animator.StringToHash("inMatch");

		// Token: 0x04000CA8 RID: 3240
		private static readonly int _anim_param_isalive = Animator.StringToHash("isAlive");

		// Token: 0x04000CA9 RID: 3241
		public Animator Animator;

		// Token: 0x04000CAA RID: 3242
		private bool _inMatch;

		// Token: 0x04000CAB RID: 3243
		private bool _isAlive;
	}
}
