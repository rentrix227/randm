﻿using System;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F9 RID: 505
	[Serializable]
	public class PoolableList : PoolableList<PoolableComponent>
	{
	}
}
