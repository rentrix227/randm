﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001BD RID: 445
	public class AwardedXpComponent : PoolableComponent
	{
		// Token: 0x0600092E RID: 2350 RVA: 0x00038914 File Offset: 0x00036B14
		public void SetData(EAwardedXpCategory category, int amount)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.Description.text = service.GetAwardedXpCategoryName(category);
			this.Amount.text = service.GetAwardedXpWithSuffix(amount);
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x0003894C File Offset: 0x00036B4C
		public void SkipAnimation()
		{
			Animator component = base.GetComponent<Animator>();
			if (component != null)
			{
				component.SetBool("isAnimating", false);
			}
		}

		// Token: 0x04000C22 RID: 3106
		public Text Description;

		// Token: 0x04000C23 RID: 3107
		public Text Amount;
	}
}
