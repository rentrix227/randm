﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Game.Weapon;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002A2 RID: 674
	public class GameplayWeaponView : BaseView<GameplayWeaponController>
	{
		// Token: 0x06000E50 RID: 3664 RVA: 0x00055290 File Offset: 0x00053490
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._cooldownParameterHash = Animator.StringToHash("cooldown");
			this._fillParameterHash = Shader.PropertyToID("_Fill");
			for (int i = 0; i < this.WeaponIcons.Count; i++)
			{
				this.WeaponIcons[i].material = Object.Instantiate<Material>(this.WeaponIcons[i].material);
			}
		}

		// Token: 0x06000E51 RID: 3665 RVA: 0x00055314 File Offset: 0x00053514
		internal void SetWeaponModel(string model)
		{
			if (this._currentWeapon != model)
			{
				this._currentWeapon = model;
				string weaponIconPath = TextureHelper.GetWeaponIconPath(model, EImageSize.SMALL, "default");
				for (int i = 0; i < this.WeaponIcons.Count; i++)
				{
					TextureHelper.LoadImageAsync(weaponIconPath, this.WeaponIcons[i], true, EImageSource.METADATA);
				}
			}
		}

		// Token: 0x06000E52 RID: 3666 RVA: 0x00055378 File Offset: 0x00053578
		internal void SetAmmo(int currentAmmo, int totalAmmo)
		{
			if (currentAmmo == this._lastAmmo)
			{
				return;
			}
			this._lastAmmo = currentAmmo;
			for (int i = 0; i < this.WeaponIcons.Count; i++)
			{
				this.WeaponIcons[i].material.SetFloat(this._fillParameterHash, (float)currentAmmo / (float)totalAmmo);
			}
			this.CurrentAmmo.text = currentAmmo.ToString();
			this.TotalAmmo.text = totalAmmo.ToString();
		}

		// Token: 0x06000E53 RID: 3667 RVA: 0x0000BAF8 File Offset: 0x00009CF8
		internal void SetMelee(bool isMelee)
		{
			this.RegularWeaponGroup.SetActive(!isMelee);
			this.MeleeWeaponGroup.SetActive(isMelee);
		}

		// Token: 0x06000E54 RID: 3668 RVA: 0x00055408 File Offset: 0x00053608
		internal void SetSecondaryFunction(SecondaryFunctionType type)
		{
			this.SecondaryCooldownGroup.SetActive(type != SecondaryFunctionType.None);
			this.SecondaryNoCooldownGroup.SetActive(type == SecondaryFunctionType.None);
			this.SecondaryIconShotgun.SetActive(type == SecondaryFunctionType.Shotgun);
			this.SecondaryIconLauncher.SetActive(type == SecondaryFunctionType.GrenadeLauncher);
		}

		// Token: 0x06000E55 RID: 3669 RVA: 0x00055454 File Offset: 0x00053654
		internal void SetGrenadeCooldown(float cooldown)
		{
			if (cooldown == this._lastGrenadeCooldown)
			{
				return;
			}
			this._lastGrenadeCooldown = cooldown;
			this.GrenadeFill.fillAmount = cooldown;
			if (this.GrenadeAnimator.isInitialized)
			{
				this.GrenadeAnimator.SetBool(this._cooldownParameterHash, cooldown < 1f);
			}
		}

		// Token: 0x06000E56 RID: 3670 RVA: 0x000554AC File Offset: 0x000536AC
		internal void SetSecondaryFunctionCooldown(float cooldown)
		{
			if (cooldown == this._lastSecondaryFunctionCooldown)
			{
				return;
			}
			this._lastSecondaryFunctionCooldown = cooldown;
			this.SecondaryFill.fillAmount = cooldown;
			if (this.SecondaryAnimator.isInitialized)
			{
				this.SecondaryAnimator.SetBool(this._cooldownParameterHash, cooldown < 1f);
			}
		}

		// Token: 0x04001275 RID: 4725
		[Header("UI elements")]
		public List<Image> WeaponIcons;

		// Token: 0x04001276 RID: 4726
		public Text CurrentAmmo;

		// Token: 0x04001277 RID: 4727
		public Text TotalAmmo;

		// Token: 0x04001278 RID: 4728
		public GameObject RegularWeaponGroup;

		// Token: 0x04001279 RID: 4729
		public GameObject MeleeWeaponGroup;

		// Token: 0x0400127A RID: 4730
		public GameObject SecondaryCooldownGroup;

		// Token: 0x0400127B RID: 4731
		public GameObject SecondaryNoCooldownGroup;

		// Token: 0x0400127C RID: 4732
		public GameObject SecondaryIconShotgun;

		// Token: 0x0400127D RID: 4733
		public GameObject SecondaryIconLauncher;

		// Token: 0x0400127E RID: 4734
		public Image GrenadeFill;

		// Token: 0x0400127F RID: 4735
		public Image SecondaryFill;

		// Token: 0x04001280 RID: 4736
		public Animator GrenadeAnimator;

		// Token: 0x04001281 RID: 4737
		public Animator SecondaryAnimator;

		// Token: 0x04001282 RID: 4738
		private int _cooldownParameterHash;

		// Token: 0x04001283 RID: 4739
		private int _fillParameterHash;

		// Token: 0x04001284 RID: 4740
		private string _currentWeapon;

		// Token: 0x04001285 RID: 4741
		private int _lastAmmo = -1;

		// Token: 0x04001286 RID: 4742
		private float _lastGrenadeCooldown = -1f;

		// Token: 0x04001287 RID: 4743
		private float _lastSecondaryFunctionCooldown = -1f;
	}
}
