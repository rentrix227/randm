﻿using System;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001E1 RID: 481
	public class InventoryNotificationComponent : PoolableComponent
	{
		// Token: 0x060009C3 RID: 2499 RVA: 0x00008C8A File Offset: 0x00006E8A
		internal void SetData(int amount)
		{
			this.AmountText.text = amount.ToString();
		}

		// Token: 0x04000D0D RID: 3341
		public Text AmountText;
	}
}
