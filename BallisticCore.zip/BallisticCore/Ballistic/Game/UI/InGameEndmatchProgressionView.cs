﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.UI.Helper;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002A8 RID: 680
	public class InGameEndmatchProgressionView : BaseView<InGameEndmatchProgressionController>
	{
		// Token: 0x06000E78 RID: 3704 RVA: 0x0000BCE9 File Offset: 0x00009EE9
		protected override void Awake()
		{
			base.Awake();
			this._EventTime = 0f;
			this.ClassCardComponents.Template.Dispose();
			this.AwardedXpComponents.Template.Dispose();
		}

		// Token: 0x06000E79 RID: 3705 RVA: 0x00056114 File Offset: 0x00054314
		internal void SetData(Dictionary<EAwardedXpCategory, int> xpCategories, List<ClassProgressionData> classProgressions)
		{
			this._eventStructs.Clear();
			this._eventStructs.Add(new ProgressionEventStruct
			{
				Type = ProgressionEventStruct.EventStructType.XP_IN,
				StartTime = this.GetLastTimedEvent(),
				Duration = 2.5f
			});
			this.AwardedXpTotal.text = xpCategories.Sum((KeyValuePair<EAwardedXpCategory, int> t) => t.Value).ToString();
			this.AwardedXpComponents.SetActiveCount(xpCategories.Count);
			int num = 0;
			foreach (KeyValuePair<EAwardedXpCategory, int> keyValuePair in xpCategories)
			{
				this.AwardedXpComponents[num].gameObject.SetActive(false);
				this.AwardedXpComponents[num].SetData(keyValuePair.Key, keyValuePair.Value);
				this._eventStructs.Add(new ProgressionEventStruct
				{
					Type = ProgressionEventStruct.EventStructType.XP,
					StartTime = this.GetLastTimedEvent(),
					Duration = 0.25f,
					XpAwardedComponent = this.AwardedXpComponents[num]
				});
				num++;
			}
			if (classProgressions.Count > 0)
			{
				this._eventStructs.Add(new ProgressionEventStruct
				{
					Type = ProgressionEventStruct.EventStructType.XP_EXIT,
					StartTime = this.GetLastTimedEvent() + 1f,
					Duration = 1f
				});
			}
			this.ClassCardComponents.SetActiveCount(classProgressions.Count);
			int num2 = 0;
			foreach (ClassProgressionData classProgressionData in classProgressions)
			{
				this.ClassCardComponents[num2].SetData(classProgressionData, classProgressions.Count > this.MaxCardsForLargeSize);
				this.ClassCardComponents[num2].OnCardClicked = new Action<ClassProgressionData>(this.HandleCardClicked);
				this._eventStructs.Add(new ProgressionEventStruct
				{
					Type = ProgressionEventStruct.EventStructType.CARD_IN,
					StartTime = this.GetLastTimedEvent(),
					Duration = 0f,
					ClassCardComponent = this.ClassCardComponents[num2]
				});
				float num3 = (float)ProgressionData.GetStepXpToReachLevel(classProgressionData.OldLevel + 1);
				this._eventStructs.Add(new ProgressionEventStruct
				{
					Type = ProgressionEventStruct.EventStructType.CARD_XP_ROUTINE,
					StartTime = this.GetLastTimedEvent(),
					Duration = 0.5f + 0.5f * ((classProgressionData.OldLevel != classProgressionData.NewLevel) ? 1f : ((float)(classProgressionData.OldXp + classProgressionData.XpGained) / num3)),
					ClassCardComponent = this.ClassCardComponents[num2],
					ClassCardProgressFrom = (float)classProgressionData.OldXp / num3,
					ClassCardProgressTo = ((classProgressionData.OldLevel != classProgressionData.NewLevel) ? 1f : ((float)(classProgressionData.OldXp + classProgressionData.XpGained) / num3))
				});
				bool flag = true;
				for (int i = classProgressionData.OldLevel + 1; i <= classProgressionData.NewLevel; i++)
				{
					bool flag2 = classProgressionData.UnlockTypes[i - classProgressionData.OldLevel - 1] != EUnlockType.NONE;
					ProgressionEventStruct.EventStructType eventStructType = ((!flag2) ? ((!flag) ? ProgressionEventStruct.EventStructType.CARD_RE_LEVELUP : ProgressionEventStruct.EventStructType.CARD_LEVELUP) : ((!flag) ? ProgressionEventStruct.EventStructType.CARD_RE_UNLOCKEDUP : ProgressionEventStruct.EventStructType.CARD_UNLOCKEDUP));
					flag = false;
					float lastTimedEvent = this.GetLastTimedEvent();
					this._eventStructs.Add(new ProgressionEventStruct
					{
						Type = eventStructType,
						StartTime = lastTimedEvent,
						Duration = 2f,
						ClassCardComponent = this.ClassCardComponents[num2],
						ClassCardLevel = i
					});
					if (flag2)
					{
						this._eventStructs.Add(new ProgressionEventStruct
						{
							Type = ProgressionEventStruct.EventStructType.POP_SHOW_ITEM,
							StartTime = lastTimedEvent,
							Duration = ((classProgressionData.UnlockTypes[i - classProgressionData.OldLevel - 1] != EUnlockType.SKILL) ? 2f : 3f),
							PopupHeroClass = classProgressionData.HeroClass,
							PopupType = classProgressionData.UnlockTypes[i - classProgressionData.OldLevel - 1],
							PopupItem = classProgressionData.UnlockedItems[i - classProgressionData.OldLevel - 1],
							PopupIndex = classProgressionData.UnlockedItemIndexes[i - classProgressionData.OldLevel - 1]
						});
						this._eventStructs.Add(new ProgressionEventStruct
						{
							Type = ProgressionEventStruct.EventStructType.POP_HIDDEN_ITEM,
							StartTime = this.GetLastTimedEvent(),
							Duration = 0f
						});
					}
					float num4 = (float)ProgressionData.GetStepXpToReachLevel(i + 1);
					this._eventStructs.Add(new ProgressionEventStruct
					{
						Type = ProgressionEventStruct.EventStructType.CARD_XP_ROUTINE,
						StartTime = this.GetLastTimedEvent(),
						Duration = 0.5f + 0.5f * ((i != classProgressionData.NewLevel) ? 1f : ((float)classProgressionData.XpAccumulatedToNextLevel / num4)),
						ClassCardComponent = this.ClassCardComponents[num2],
						ClassCardProgressFrom = 0f,
						ClassCardProgressTo = ((i != classProgressionData.NewLevel) ? 1f : ((float)classProgressionData.XpAccumulatedToNextLevel / num4))
					});
				}
				this._eventStructs.Add(new ProgressionEventStruct
				{
					Type = ProgressionEventStruct.EventStructType.CARD_SET,
					StartTime = this.GetLastTimedEvent(),
					Duration = 0.5f,
					ClassCardComponent = this.ClassCardComponents[num2]
				});
				num2++;
			}
			this._eventStructs.Add(new ProgressionEventStruct
			{
				Type = ProgressionEventStruct.EventStructType.CARD_ALL_FINISHED,
				StartTime = this.GetLastTimedEvent(),
				Duration = 0f
			});
			this._canRun = true;
		}

		// Token: 0x06000E7A RID: 3706 RVA: 0x00056758 File Offset: 0x00054958
		public void Update()
		{
			if (this._test)
			{
				Dictionary<EAwardedXpCategory, int> dictionary = new Dictionary<EAwardedXpCategory, int>();
				for (int i = 0; i < this._xpCategoriesTest.Length; i++)
				{
					dictionary.Add(this._xpCategoriesTest[i], this._xpAmountsTest[i]);
				}
				this._classProgressionDataTest = new ClassProgressionData[this._xpHeroes.Length];
				for (int j = 0; j < this._xpHeroes.Length; j++)
				{
					ClassProgressionData classProgressionData = new ClassProgressionData
					{
						HeroClass = this._xpHeroes[j],
						XpGained = (int)(this._xpHeroesFromTo[j].y - this._xpHeroesFromTo[j].x),
						XpAccumulatedToNextLevel = (int)this._xpHeroesFromTo[j].y - ProgressionData.GetTotalXpToReachLevel(ProgressionData.GetLevelForXp((int)this._xpHeroesFromTo[j].y)),
						OldXp = (int)this._xpHeroesFromTo[j].x - ProgressionData.GetTotalXpToReachLevel(ProgressionData.GetLevelForXp((int)this._xpHeroesFromTo[j].x)),
						OldLevel = ProgressionData.GetLevelForXp((int)this._xpHeroesFromTo[j].x),
						NewLevel = ProgressionData.GetLevelForXp((int)this._xpHeroesFromTo[j].y),
						UnlockTypes = new List<EUnlockType>(),
						UnlockedItems = new List<string>(),
						UnlockedItemIndexes = new List<int>()
					};
					for (int k = classProgressionData.OldLevel + 1; k <= classProgressionData.NewLevel; k++)
					{
						LevelUnlockData unlockForLevel = ProgressionData.GetUnlockForLevel(classProgressionData.HeroClass, k);
						classProgressionData.UnlockTypes.Add(unlockForLevel.UnlockType);
						classProgressionData.UnlockedItems.Add(unlockForLevel.UnlockedItemName);
						classProgressionData.UnlockedItemIndexes.Add(unlockForLevel.UnlockedItemIndex);
					}
					this._classProgressionDataTest[j] = classProgressionData;
				}
				this.SetData(dictionary, this._classProgressionDataTest.ToList<ClassProgressionData>());
				this._EventTime = 0f;
				this._test = false;
			}
			if (this._canRun)
			{
				this._EventTime += Time.deltaTime;
				if (this._eventStructs.Count > 0)
				{
					this._canRun = EventUpdateHelper.IsTimeReady(this._EventTime, this.GetLastTimedEvent(), true, false);
				}
				else
				{
					this._canRun = false;
				}
			}
			if (this.AwardedXpAnimator.isInitialized)
			{
				this.AwardedXpAnimator.SetBool(InGameEndmatchProgressionView.animator_xp_animating, this._AwardedXpSet);
				this.AwardedXpAnimator.SetBool(InGameEndmatchProgressionView.animator_xp_exit, this._AwardedXpExitSet);
			}
			foreach (ProgressionEventStruct progressionEventStruct in this._eventStructs)
			{
				switch (progressionEventStruct.Type)
				{
				case ProgressionEventStruct.EventStructType.XP_IN:
					this._AwardedXpSet = EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true);
					break;
				case ProgressionEventStruct.EventStructType.XP:
					if (progressionEventStruct.XpAwardedComponent.gameObject.activeSelf != EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true))
					{
						progressionEventStruct.XpAwardedComponent.gameObject.SetActive(EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true));
					}
					break;
				case ProgressionEventStruct.EventStructType.XP_EXIT:
					this._AwardedXpExitSet = EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true);
					break;
				case ProgressionEventStruct.EventStructType.CARD_IN:
					progressionEventStruct.ClassCardComponent.SetCardIn(EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true));
					break;
				case ProgressionEventStruct.EventStructType.CARD_XP_ROUTINE:
					if (EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true))
					{
						progressionEventStruct.ClassCardComponent.SetXpCar(progressionEventStruct.ClassCardProgressFrom, EventUpdateHelper.LerpFloatValue(this._EventTime, progressionEventStruct.ClassCardProgressFrom, progressionEventStruct.ClassCardProgressTo, progressionEventStruct.StartTime, progressionEventStruct.StartTime + progressionEventStruct.Duration));
						EventUpdateHelper.PlayBarFill(this.XpBarSound, this._EventTime, progressionEventStruct.StartTime, progressionEventStruct.StartTime + progressionEventStruct.Duration, true);
					}
					break;
				case ProgressionEventStruct.EventStructType.CARD_LEVELUP:
					progressionEventStruct.ClassCardComponent.SetCardLevelUp(EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true));
					if (EventUpdateHelper.IsTimeReadyOnce(this._EventTime, progressionEventStruct.StartTime, false, true, ref progressionEventStruct.Once))
					{
						progressionEventStruct.ClassCardComponent.SetLevel(progressionEventStruct.ClassCardLevel);
					}
					break;
				case ProgressionEventStruct.EventStructType.CARD_RE_LEVELUP:
					if (EventUpdateHelper.IsTimeReadyOnce(this._EventTime, progressionEventStruct.StartTime, false, true, ref progressionEventStruct.Once))
					{
						progressionEventStruct.ClassCardComponent.SetRetriggerLevel();
						progressionEventStruct.ClassCardComponent.SetLevel(progressionEventStruct.ClassCardLevel);
					}
					break;
				case ProgressionEventStruct.EventStructType.CARD_UNLOCKEDUP:
					progressionEventStruct.ClassCardComponent.SetCardLevelUpWithUnlock(EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true));
					if (EventUpdateHelper.IsTimeReadyOnce(this._EventTime, progressionEventStruct.StartTime, false, true, ref progressionEventStruct.Once))
					{
						progressionEventStruct.ClassCardComponent.SetLevel(progressionEventStruct.ClassCardLevel);
					}
					break;
				case ProgressionEventStruct.EventStructType.CARD_RE_UNLOCKEDUP:
					if (EventUpdateHelper.IsTimeReadyOnce(this._EventTime, progressionEventStruct.StartTime, false, true, ref progressionEventStruct.Once))
					{
						progressionEventStruct.ClassCardComponent.SetRetriggerLevelWithUnlock();
						progressionEventStruct.ClassCardComponent.SetLevel(progressionEventStruct.ClassCardLevel);
					}
					break;
				case ProgressionEventStruct.EventStructType.CARD_SET:
					progressionEventStruct.ClassCardComponent.SetCardFitSquad(EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true));
					break;
				case ProgressionEventStruct.EventStructType.POP_SHOW_ITEM:
					if (EventUpdateHelper.IsTimeReadyOnce(this._EventTime, progressionEventStruct.StartTime, false, true, ref progressionEventStruct.Once))
					{
						ServiceProvider.GetService<PopupService>().ShowItemUnlock(progressionEventStruct.PopupHeroClass, progressionEventStruct.PopupType, progressionEventStruct.PopupItem, progressionEventStruct.PopupIndex);
					}
					break;
				case ProgressionEventStruct.EventStructType.POP_HIDDEN_ITEM:
					if (EventUpdateHelper.IsTimeReadyOnce(this._EventTime, progressionEventStruct.StartTime, false, true, ref progressionEventStruct.Once))
					{
						ServiceProvider.GetService<PopupService>().HiddenItemUnlock();
					}
					break;
				case ProgressionEventStruct.EventStructType.CARD_ALL_FINISHED:
				{
					for (int l = 0; l < this.ClassCardComponents.Lenght; l++)
					{
						this.ClassCardComponents[l].SetCardFinished(EventUpdateHelper.IsTimeReady(this._EventTime, progressionEventStruct.StartTime, false, true));
					}
					break;
				}
				}
			}
		}

		// Token: 0x06000E7B RID: 3707 RVA: 0x0000BD1C File Offset: 0x00009F1C
		private void HandleCardClicked(ClassProgressionData heroProgression)
		{
			base._controller.DispatchClassCardClicked(heroProgression);
		}

		// Token: 0x06000E7C RID: 3708 RVA: 0x00056E04 File Offset: 0x00055004
		private float GetLastTimedEvent()
		{
			if (this._eventStructs.Count <= 0)
			{
				return 0f;
			}
			float num = -1f;
			float num2 = -1f;
			foreach (ProgressionEventStruct progressionEventStruct in this._eventStructs)
			{
				if (num + num2 < progressionEventStruct.StartTime + progressionEventStruct.Duration)
				{
					num = progressionEventStruct.StartTime;
					num2 = progressionEventStruct.Duration;
				}
			}
			return num + num2;
		}

		// Token: 0x040012BB RID: 4795
		private static int animator_xp_animating = Animator.StringToHash("animating");

		// Token: 0x040012BC RID: 4796
		private static int animator_xp_exit = Animator.StringToHash("exit");

		// Token: 0x040012BD RID: 4797
		public InGameEndmatchProgressionView.EndMatchProgressionCardComponentList ClassCardComponents;

		// Token: 0x040012BE RID: 4798
		public int MaxCardsForLargeSize = 4;

		// Token: 0x040012BF RID: 4799
		public GameObject AwardedXpRoot;

		// Token: 0x040012C0 RID: 4800
		public Animator AwardedXpAnimator;

		// Token: 0x040012C1 RID: 4801
		public Text AwardedXpTotal;

		// Token: 0x040012C2 RID: 4802
		public InGameEndmatchProgressionView.AwardedXpComponentList AwardedXpComponents;

		// Token: 0x040012C3 RID: 4803
		public VariedPitchAudioComponent XpBarSound;

		// Token: 0x040012C4 RID: 4804
		public float _EventTime;

		// Token: 0x040012C5 RID: 4805
		private List<ProgressionEventStruct> _eventStructs = new List<ProgressionEventStruct>();

		// Token: 0x040012C6 RID: 4806
		[Header("Testing...")]
		public bool _test;

		// Token: 0x040012C7 RID: 4807
		public bool _canRun;

		// Token: 0x040012C8 RID: 4808
		public EAwardedXpCategory[] _xpCategoriesTest;

		// Token: 0x040012C9 RID: 4809
		public int[] _xpAmountsTest;

		// Token: 0x040012CA RID: 4810
		public EHeroClass[] _xpHeroes;

		// Token: 0x040012CB RID: 4811
		public Vector2[] _xpHeroesFromTo;

		// Token: 0x040012CC RID: 4812
		public ClassProgressionData[] _classProgressionDataTest;

		// Token: 0x040012CD RID: 4813
		private bool _AwardedXpSet;

		// Token: 0x040012CE RID: 4814
		private bool _AwardedXpExitSet;

		// Token: 0x020002A9 RID: 681
		[Serializable]
		public class EndMatchProgressionCardComponentList : PoolableList<EndMatchProgressionCardComponent>
		{
		}

		// Token: 0x020002AA RID: 682
		[Serializable]
		public class AwardedXpComponentList : PoolableList<AwardedXpComponent>
		{
		}
	}
}
