﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C9 RID: 713
	public class InGameRoundScoreView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000EF4 RID: 3828 RVA: 0x0005A300 File Offset: 0x00058500
		internal void SetData(int yourTeamWins, int enemyTeamWins, Team yourTeam)
		{
			Team team = ((yourTeam != Team.MFA) ? Team.MFA : Team.SMOKE);
			this.YourTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(yourTeam, ELocalizedTextCase.UPPER_CASE);
			this.YourTeamLogo.texture = this.TeamLogos[(int)yourTeam];
			this.YourTeamScoreText.text = yourTeamWins.ToString();
			this.EnemyTeamNameText.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(team, ELocalizedTextCase.UPPER_CASE);
			this.EnemyTeamLogo.texture = this.TeamLogos[(int)team];
			this.EnemyTeamScoreText.text = enemyTeamWins.ToString();
		}

		// Token: 0x0400140B RID: 5131
		public RawImage YourTeamLogo;

		// Token: 0x0400140C RID: 5132
		public Text YourTeamNameText;

		// Token: 0x0400140D RID: 5133
		public Text YourTeamScoreText;

		// Token: 0x0400140E RID: 5134
		public RawImage EnemyTeamLogo;

		// Token: 0x0400140F RID: 5135
		public Text EnemyTeamNameText;

		// Token: 0x04001410 RID: 5136
		public Text EnemyTeamScoreText;

		// Token: 0x04001411 RID: 5137
		public Texture[] TeamLogos;
	}
}
