﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C3 RID: 707
	public class InGamePopupJoinMatchView : BaseView<InGameHeaderController>
	{
		// Token: 0x06000ECE RID: 3790 RVA: 0x00059700 File Offset: 0x00057900
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Accept.onClick.AddListener(new UnityAction(this.OnAcceptClicked));
			this.Cancel.onClick.AddListener(new UnityAction(this.OnCancelClicked));
		}

		// Token: 0x06000ECF RID: 3791 RVA: 0x00059758 File Offset: 0x00057958
		internal void SetData(EGameMode gameMode, ETeamMode teamMode, int playerCount, int maxPlayerCount, int remainingTime)
		{
			this._isActive = true;
			this._remainingTime = (float)remainingTime;
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				this.FFARoot.SetActive(false);
				this.TeamRoot.SetActive(true);
				if (teamMode == ETeamMode.MFA)
				{
					this.TeamName.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(Team.MFA, ELocalizedTextCase.UPPER_CASE);
				}
				if (teamMode == ETeamMode.SMOKE)
				{
					this.TeamName.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(Team.MFA, ELocalizedTextCase.UPPER_CASE);
				}
				this.TeamSize.text = playerCount.ToString() + "/" + maxPlayerCount.ToString();
				this.QueueTeamLogo.sprite = this.TeamLogos[(int)teamMode];
			}
			else
			{
				this.FFARoot.SetActive(true);
				this.TeamRoot.SetActive(false);
				this.FFAMatchSize.text = playerCount + "/" + maxPlayerCount;
			}
		}

		// Token: 0x06000ED0 RID: 3792 RVA: 0x00059864 File Offset: 0x00057A64
		public void Update()
		{
			if (!this._isActive)
			{
				return;
			}
			if (this._remainingTime > 0f)
			{
				this._remainingTime -= Time.deltaTime;
			}
			else
			{
				this._isActive = false;
				this._remainingTime = 0f;
				base._controller.DispatchTeamCallDismiss(false);
			}
			this.AcceptText.text = ((int)this._remainingTime).ToString();
		}

		// Token: 0x06000ED1 RID: 3793 RVA: 0x0000C0F5 File Offset: 0x0000A2F5
		private void OnAcceptClicked()
		{
			base._controller.DispatchTeamCallResponse();
		}

		// Token: 0x06000ED2 RID: 3794 RVA: 0x0000C102 File Offset: 0x0000A302
		private void OnCancelClicked()
		{
			base._controller.DispatchTeamCallDismiss(true);
		}

		// Token: 0x040013D0 RID: 5072
		[Header("Team")]
		public GameObject TeamRoot;

		// Token: 0x040013D1 RID: 5073
		public Text TeamName;

		// Token: 0x040013D2 RID: 5074
		public Text TeamSize;

		// Token: 0x040013D3 RID: 5075
		public Image QueueTeamLogo;

		// Token: 0x040013D4 RID: 5076
		[Header("FFA")]
		public GameObject FFARoot;

		// Token: 0x040013D5 RID: 5077
		public Text FFAMatchSize;

		// Token: 0x040013D6 RID: 5078
		public Sprite[] TeamLogos;

		// Token: 0x040013D7 RID: 5079
		public Text AcceptText;

		// Token: 0x040013D8 RID: 5080
		public Button Accept;

		// Token: 0x040013D9 RID: 5081
		public Button Cancel;

		// Token: 0x040013DA RID: 5082
		private bool _isActive;

		// Token: 0x040013DB RID: 5083
		private float _remainingTime;
	}
}
