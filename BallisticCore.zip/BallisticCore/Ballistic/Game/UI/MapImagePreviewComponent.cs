﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F3 RID: 499
	public class MapImagePreviewComponent : EnumImagePreviewComponent<GameMapConfig>
	{
		// Token: 0x06000A14 RID: 2580 RVA: 0x0003B8D8 File Offset: 0x00039AD8
		public void Start()
		{
			foreach (KeyValuePair<GameMapConfig, Animator> keyValuePair in this._animators)
			{
				string text = keyValuePair.Key.MapName.ToString();
				if (!(text == GameMapModeConfigService.DefaultAnyMap.MapName))
				{
					TextureHelper.LoadImageAsync(TextureHelper.GetMapIconPath(keyValuePair.Key, EImageSize.MEDIUM), keyValuePair.Value.GetComponent<RawImage>(), false, EImageSource.STREAMINGASSETS);
				}
			}
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x0003B97C File Offset: 0x00039B7C
		protected override List<GameMapConfig> LoadAvailableItems()
		{
			List<GameMapConfig> list = ServiceProvider.GetService<GameMapModeConfigService>().GetAvaliableGameMapConfigList().ToList<GameMapConfig>();
			list.Insert(0, GameMapModeConfigService.DefaultAnyMap);
			return list;
		}

		// Token: 0x06000A16 RID: 2582 RVA: 0x0000914A File Offset: 0x0000734A
		protected override string UpdateText(GameMapConfig newText)
		{
			return ServiceProvider.GetService<LocalizationService>().GetMapName(newText.MapId, ELocalizedTextCase.NONE);
		}
	}
}
