﻿using System;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001B9 RID: 441
	public class AccessoryRequirementComponent : PoolableComponent
	{
		// Token: 0x06000922 RID: 2338 RVA: 0x000084A1 File Offset: 0x000066A1
		internal virtual void SetData(string requirement)
		{
			this.RequirementText.text = requirement;
		}

		// Token: 0x04000BF6 RID: 3062
		public Text RequirementText;
	}
}
