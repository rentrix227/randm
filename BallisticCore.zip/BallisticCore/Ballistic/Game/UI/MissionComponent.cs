﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Network.Transport.Gameplay.Missions;
using Aquiris.DataModel.ItemModel.ConfigItemModel.GameMapModel.GameModeModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F4 RID: 500
	public class MissionComponent : PoolableComponent
	{
		// Token: 0x06000A18 RID: 2584 RVA: 0x0003B9A8 File Offset: 0x00039BA8
		internal void SetInfo(bool missionsEnabled, bool autoHidden, int missionid, int progress, int lastmissionid, bool triggerCompleted, bool rewarded)
		{
			this._autoHidden = autoHidden;
			this._isVisible = missionid != 0 && missionsEnabled;
			this._isNext = false;
			this._isSpecial = false;
			if (missionid < 10000)
			{
				return;
			}
			int num = missionid % 10000;
			MissionConfig itemById = ServiceProvider.GetService<ConfigItemService>().GetItemById<MissionConfig>(num);
			if (itemById == null)
			{
				Debug.LogWarning("MissionID doesn't exist on current database:" + missionid);
				return;
			}
			this._isSpecial = itemById.Category == EMissionCategory.GOLD;
			this._isCompleted = (long)progress >= (long)((ulong)itemById.EventCount) && triggerCompleted;
			this._isCompletedAlready = (long)progress >= (long)((ulong)itemById.EventCount) && !triggerCompleted;
			this._isNew = missionid != lastmissionid;
			this._isRewardReceived = this._isRewardReceived || rewarded;
			if ((long)progress % (long)((ulong)itemById.EventUpdate) == 0L && progress != 0)
			{
				this._isVisibleLastTime = Time.realtimeSinceStartup;
			}
			this.Description.text = ServiceProvider.GetService<LocalizationService>().GetMissionDescription(itemById.ItemName, ELocalizedTextCase.NONE);
			this.Progression.fillAmount = (float)progress / itemById.EventCount;
			this.ProgressionCount.text = progress + "/" + itemById.EventCount.ToString();
			switch (itemById.Category)
			{
			case EMissionCategory.EASY:
				this.RewardScraps.gameObject.SetActive(true);
				this.RewardLockbox.gameObject.SetActive(false);
				this.RewardAmount.text = "2";
				break;
			case EMissionCategory.MEDIUM:
				this.RewardScraps.gameObject.SetActive(true);
				this.RewardLockbox.gameObject.SetActive(false);
				this.RewardAmount.text = "3";
				break;
			case EMissionCategory.HARD:
				this.RewardScraps.gameObject.SetActive(true);
				this.RewardLockbox.gameObject.SetActive(false);
				this.RewardAmount.text = "4";
				break;
			case EMissionCategory.GOLD:
				this.RewardScraps.gameObject.SetActive(false);
				this.RewardLockbox.gameObject.SetActive(true);
				this.RewardAmount.text = "1";
				break;
			}
		}

		// Token: 0x06000A19 RID: 2585 RVA: 0x0003BBFC File Offset: 0x00039DFC
		internal void SetNext(bool missionEnabled, TimeSpan timeSpan)
		{
			this._isNext = missionEnabled;
			if (missionEnabled)
			{
				int num = ((timeSpan.Hours <= 0) ? 0 : timeSpan.Hours);
				int num2 = ((timeSpan.Minutes <= 0) ? 0 : timeSpan.Minutes);
				this.NextMissionText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("mss_nextmission", ELocalizedTextCase.NONE), num.ToString("00"), num2.ToString("00"));
			}
		}

		// Token: 0x06000A1A RID: 2586 RVA: 0x0000915D File Offset: 0x0000735D
		internal void ForgetReward()
		{
			this._isRewardReceived = false;
		}

		// Token: 0x06000A1B RID: 2587 RVA: 0x0003BC84 File Offset: 0x00039E84
		internal void Update()
		{
			if (this.Animator.isInitialized)
			{
				this.Animator.SetBool(MissionComponent._animhash_visible, (this._isVisible && (!this._autoHidden || this._isVisibleLastTime + 2.5f > Time.realtimeSinceStartup)) || this._isRewardReceived);
				this.Animator.SetBool(MissionComponent._animhash_next, this._isNext && (!this._autoHidden || this._isVisibleLastTime + 2.5f > Time.realtimeSinceStartup) && !this._isRewardReceived);
				this.Animator.SetBool(MissionComponent._animhash_is_special, this._isSpecial);
				this.Animator.SetBool(MissionComponent._animhash_completed, this._isCompleted);
				this.Animator.SetBool(MissionComponent._animhash_completed_already, this._isCompletedAlready);
				this.Animator.SetBool(MissionComponent._animhash_new, this._isNew);
				this.Animator.SetBool(MissionComponent._animhash_collect_reward, this._isRewardReceived);
			}
		}

		// Token: 0x04000D76 RID: 3446
		private const float _triggerVisibleTime = 2.5f;

		// Token: 0x04000D77 RID: 3447
		private static readonly int _animhash_visible = Animator.StringToHash("visible");

		// Token: 0x04000D78 RID: 3448
		private static readonly int _animhash_completed = Animator.StringToHash("completed");

		// Token: 0x04000D79 RID: 3449
		private static readonly int _animhash_completed_already = Animator.StringToHash("completed_already");

		// Token: 0x04000D7A RID: 3450
		private static readonly int _animhash_collect_reward = Animator.StringToHash("collect_reward");

		// Token: 0x04000D7B RID: 3451
		private static readonly int _animhash_new = Animator.StringToHash("new");

		// Token: 0x04000D7C RID: 3452
		private static readonly int _animhash_next = Animator.StringToHash("next");

		// Token: 0x04000D7D RID: 3453
		private static readonly int _animhash_is_special = Animator.StringToHash("is_special");

		// Token: 0x04000D7E RID: 3454
		public Animator Animator;

		// Token: 0x04000D7F RID: 3455
		public Text Description;

		// Token: 0x04000D80 RID: 3456
		public Image Progression;

		// Token: 0x04000D81 RID: 3457
		public Text ProgressionCount;

		// Token: 0x04000D82 RID: 3458
		public Image RewardLockbox;

		// Token: 0x04000D83 RID: 3459
		public Image RewardScraps;

		// Token: 0x04000D84 RID: 3460
		public Text RewardAmount;

		// Token: 0x04000D85 RID: 3461
		public Text NextMissionText;

		// Token: 0x04000D86 RID: 3462
		private float _isVisibleLastTime;

		// Token: 0x04000D87 RID: 3463
		private bool _autoHidden;

		// Token: 0x04000D88 RID: 3464
		private bool _isVisible;

		// Token: 0x04000D89 RID: 3465
		private bool _isNext;

		// Token: 0x04000D8A RID: 3466
		private bool _isSpecial;

		// Token: 0x04000D8B RID: 3467
		private bool _isCompleted;

		// Token: 0x04000D8C RID: 3468
		private bool _isCompletedAlready;

		// Token: 0x04000D8D RID: 3469
		private bool _isNew;

		// Token: 0x04000D8E RID: 3470
		private bool _isRewardReceived;
	}
}
