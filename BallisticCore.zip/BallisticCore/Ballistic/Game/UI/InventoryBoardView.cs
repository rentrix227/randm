﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002CC RID: 716
	public class InventoryBoardView : BaseView<InventoryController>
	{
		// Token: 0x06000EFD RID: 3837 RVA: 0x0005A598 File Offset: 0x00058798
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.LockboxSortList.Template.Dispose();
			this.SkinSortList.Template.Dispose();
			this.ScrapLockboxList.Template.Dispose();
			this.GoldScrapLockboxList.Template.Dispose();
			this.AccessorySortList.Template.Dispose();
			this.LockboxSortByClassToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnLockboxSortByClass));
			this.LockboxSortByClassAscending.onValueChanged.AddListener(new UnityAction<bool>(this.OnLockboxSortByClass));
			this.LockboxSortBySeasonToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnLockboxSortBySeason));
			this.LockboxSortBySeasonAscending.onValueChanged.AddListener(new UnityAction<bool>(this.OnLockboxSortBySeason));
			this.SkinSortByRarityToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSkinSortByRarity));
			this.SkinSortByRarityAscending.onValueChanged.AddListener(new UnityAction<bool>(this.OnSkinSortByRarity));
			this.SkinSortByNameToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSkinSortByName));
			this.SkinSortByNameAscending.onValueChanged.AddListener(new UnityAction<bool>(this.OnSkinSortByName));
			this.SkinSortBySkinTypeToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSkinSortBySkin));
			this.SkinSortBySkinTypeAscending.onValueChanged.AddListener(new UnityAction<bool>(this.OnSkinSortBySkin));
			this.AccessorySortByNameToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnAccessoryName));
			this.AccessorySortByNameAscending.onValueChanged.AddListener(new UnityAction<bool>(this.OnAccessoryName));
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x0000C387 File Offset: 0x0000A587
		internal void SetRoot(EInventoryBoard board)
		{
			this._inventoryBoard = board;
		}

		// Token: 0x06000EFF RID: 3839 RVA: 0x0005A758 File Offset: 0x00058958
		internal void SetSorting(ELockboxSorting lockboxSortingActive, bool lockboxSortingAscending, EWeaponSkinSorting weaponSortingActive, bool weaponSortingAscending, EAccessorySorting accessorySorting, bool accessorySortingAscending)
		{
			this._isSettings = true;
			this.LockboxSortByClassToggle.isOn = lockboxSortingActive == ELockboxSorting.CLASS;
			this.LockboxSortByClassAscending.isOn = lockboxSortingActive == ELockboxSorting.CLASS && lockboxSortingAscending;
			this.LockboxSortBySeasonToggle.isOn = lockboxSortingActive == ELockboxSorting.SEASON;
			this.LockboxSortBySeasonAscending.isOn = lockboxSortingActive == ELockboxSorting.SEASON && lockboxSortingAscending;
			this.SkinSortByRarityToggle.isOn = weaponSortingActive == EWeaponSkinSorting.RARITY;
			this.SkinSortByRarityAscending.isOn = weaponSortingActive == EWeaponSkinSorting.RARITY && weaponSortingAscending;
			this.SkinSortByNameToggle.isOn = weaponSortingActive == EWeaponSkinSorting.NAME;
			this.SkinSortByNameAscending.isOn = weaponSortingActive == EWeaponSkinSorting.NAME && weaponSortingAscending;
			this.SkinSortBySkinTypeToggle.isOn = weaponSortingActive == EWeaponSkinSorting.SKIN;
			this.SkinSortBySkinTypeAscending.isOn = weaponSortingActive == EWeaponSkinSorting.SKIN && weaponSortingAscending;
			this.AccessorySortByNameToggle.isOn = accessorySorting == EAccessorySorting.NAME;
			this.AccessorySortByNameAscending.isOn = accessorySorting == EAccessorySorting.NAME && accessorySortingAscending;
			this._isSettings = false;
		}

		// Token: 0x06000F00 RID: 3840 RVA: 0x0005A858 File Offset: 0x00058A58
		internal void SetData(InventoryData inventoryData, NotificationsContainer notifications, bool lockboxSortingAscending, bool weaponSkinSortingAscending, bool accessorySortingAscending)
		{
			this._inventoryData = inventoryData;
			int i = 0;
			foreach (KeyValuePair<string, List<LockboxData>> keyValuePair in inventoryData.LockboxDictionary)
			{
				if (keyValuePair.Value.Any((LockboxData t) => t.Visible))
				{
					i++;
				}
			}
			this.LockboxSortList.SetActiveCount(i);
			if (lockboxSortingAscending)
			{
				i = 0;
			}
			else
			{
				i--;
			}
			foreach (KeyValuePair<string, List<LockboxData>> keyValuePair2 in this._inventoryData.LockboxDictionary)
			{
				if (keyValuePair2.Value.Any((LockboxData t) => t.Visible))
				{
					this.LockboxSortList[i].SetData(keyValuePair2.Key, keyValuePair2.Value, notifications.NewLockboxes);
					this.LockboxSortList[i].OnLockboxClick = new Action<LockboxData>(this.OnLockboxClick);
					if (lockboxSortingAscending)
					{
						i++;
					}
					else
					{
						i--;
					}
				}
			}
			i = 0;
			foreach (KeyValuePair<string, List<WeaponSkinData>> keyValuePair3 in inventoryData.WeaponSkinDictionary)
			{
				if (keyValuePair3.Value.Any((WeaponSkinData t) => t.Visible))
				{
					i++;
				}
			}
			this.SkinSortList.SetActiveCount(i);
			if (weaponSkinSortingAscending)
			{
				i = 0;
			}
			else
			{
				i--;
			}
			foreach (KeyValuePair<string, List<WeaponSkinData>> keyValuePair4 in this._inventoryData.WeaponSkinDictionary)
			{
				if (keyValuePair4.Value.Any((WeaponSkinData t) => t.Visible))
				{
					this.SkinSortList[i].SetData(keyValuePair4.Key, keyValuePair4.Value, notifications.NewWeaponSkins, false);
					this.SkinSortList[i].OnWeaponSkinClick = new Action<WeaponSkinData>(this.OnWeaponSkinClick);
					if (weaponSkinSortingAscending)
					{
						i++;
					}
					else
					{
						i--;
					}
				}
			}
			int num = (int)((this._inventoryData.Scraps.Count <= 0) ? 0U : (this._inventoryData.Scraps[0].Quantity / 10U));
			int num2 = (int)((this._inventoryData.Scraps.Count <= 0) ? 0U : (this._inventoryData.Scraps[0].Quantity % 10U));
			this.ScrapAmountText.text = "x " + num2;
			this.ScrapLockboxList.SetActiveCount(num + 1);
			for (i = 0; i < num + 1; i++)
			{
				this.ScrapLockboxList[i].SetData(i < num, num2);
				this.ScrapLockboxList[i].OnScrapLockboxClick = new Action(this.OnScrapLockboxClick);
			}
			int num3 = this._inventoryData.GoldScraps.Count / 10;
			int num4 = this._inventoryData.GoldScraps.Count % 10;
			this.GoldScrapAmountText.text = "x " + num4;
			this.GoldScrapLockboxList.SetActiveCount(num3 + 1);
			for (i = 0; i < num3 + 1; i++)
			{
				this.GoldScrapLockboxList[i].SetData(i < num3, num4);
				this.GoldScrapLockboxList[i].OnScrapLockboxClick = new Action(this.OnGoldScrapLockboxClick);
			}
			i = inventoryData.Accessories.Count;
			if (accessorySortingAscending)
			{
				i = 0;
			}
			else
			{
				i--;
			}
			this.AccessorySortList.SetActiveCount(inventoryData.Accessories.Count);
			foreach (Accessory accessory in this._inventoryData.Accessories)
			{
				this.AccessorySortList[i].SetData(accessory);
				this.AccessorySortList[i].OnAccessoryClick = new Action<Accessory>(this.OnAccessoryClick);
				if (accessorySortingAscending)
				{
					i++;
				}
				else
				{
					i--;
				}
			}
		}

		// Token: 0x06000F01 RID: 3841 RVA: 0x0000C390 File Offset: 0x0000A590
		private void OnAccessoryName(bool value)
		{
			if (this._isSettings)
			{
			}
			base._controller.SetSorting(EAccessorySorting.NAME, this.AccessorySortByNameAscending.isOn);
			base._controller.RefreshInventorySorting();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F02 RID: 3842 RVA: 0x0000C3CA File Offset: 0x0000A5CA
		private void OnLockboxSortByClass(bool value)
		{
			if (this._isSettings)
			{
				return;
			}
			base._controller.SetSorting(ELockboxSorting.CLASS, this.LockboxSortByClassAscending.isOn);
			base._controller.RefreshInventorySorting();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F03 RID: 3843 RVA: 0x0000C405 File Offset: 0x0000A605
		private void OnLockboxSortBySeason(bool value)
		{
			if (this._isSettings)
			{
				return;
			}
			base._controller.SetSorting(ELockboxSorting.SEASON, this.LockboxSortByClassAscending.isOn);
			base._controller.RefreshInventorySorting();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F04 RID: 3844 RVA: 0x0000C440 File Offset: 0x0000A640
		private void OnSkinSortBySkin(bool value)
		{
			if (this._isSettings)
			{
				return;
			}
			base._controller.SetSorting(EWeaponSkinSorting.SKIN, this.SkinSortBySkinTypeAscending.isOn);
			base._controller.RefreshInventorySorting();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F05 RID: 3845 RVA: 0x0000C47B File Offset: 0x0000A67B
		private void OnSkinSortByName(bool value)
		{
			if (this._isSettings)
			{
				return;
			}
			base._controller.SetSorting(EWeaponSkinSorting.NAME, this.SkinSortByNameAscending.isOn);
			base._controller.RefreshInventorySorting();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F06 RID: 3846 RVA: 0x0000C4B6 File Offset: 0x0000A6B6
		private void OnSkinSortByRarity(bool value)
		{
			if (this._isSettings)
			{
				return;
			}
			base._controller.SetSorting(EWeaponSkinSorting.RARITY, this.SkinSortByRarityAscending.isOn);
			base._controller.RefreshInventorySorting();
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x06000F07 RID: 3847 RVA: 0x0000C4F1 File Offset: 0x0000A6F1
		private void OnLockboxClick(LockboxData lockboxData)
		{
			base._controller.DispatchLockboxClicked(lockboxData);
		}

		// Token: 0x06000F08 RID: 3848 RVA: 0x0000C4FF File Offset: 0x0000A6FF
		private void OnWeaponSkinClick(WeaponSkinData weaponSkinData)
		{
			base._controller.DispatchWeaponSkinClicked(weaponSkinData);
		}

		// Token: 0x06000F09 RID: 3849 RVA: 0x0000C50D File Offset: 0x0000A70D
		private void OnScrapLockboxClick()
		{
			base._controller.ClaimLockbox();
		}

		// Token: 0x06000F0A RID: 3850 RVA: 0x0000C51A File Offset: 0x0000A71A
		private void OnGoldScrapLockboxClick()
		{
			base._controller.ClaimGoldLockbox();
		}

		// Token: 0x06000F0B RID: 3851 RVA: 0x0000C527 File Offset: 0x0000A727
		private void OnAccessoryClick(Accessory accessory)
		{
			base._controller.DispatchAccessoryClicked(accessory);
		}

		// Token: 0x06000F0C RID: 3852 RVA: 0x0005AD80 File Offset: 0x00058F80
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.LockboxRoot.SetActive(this._inventoryBoard == EInventoryBoard.LOCKBOX);
			this.WeaponSkinRoot.SetActive(this._inventoryBoard == EInventoryBoard.WEAPONSKIN);
			this.ScrapsRoot.SetActive(this._inventoryBoard == EInventoryBoard.SCRAPS);
			this.VanityRoot.SetActive(this._inventoryBoard == EInventoryBoard.VANITY);
			base._controller.UpdateInventoryBoard();
		}

		// Token: 0x0400141F RID: 5151
		public GameObject LockboxRoot;

		// Token: 0x04001420 RID: 5152
		public GameObject WeaponSkinRoot;

		// Token: 0x04001421 RID: 5153
		public GameObject VanityRoot;

		// Token: 0x04001422 RID: 5154
		public GameObject ScrapsRoot;

		// Token: 0x04001423 RID: 5155
		[Header("Lockbox")]
		public Toggle LockboxSortByClassToggle;

		// Token: 0x04001424 RID: 5156
		public Toggle LockboxSortByClassAscending;

		// Token: 0x04001425 RID: 5157
		public Toggle LockboxSortBySeasonToggle;

		// Token: 0x04001426 RID: 5158
		public Toggle LockboxSortBySeasonAscending;

		// Token: 0x04001427 RID: 5159
		public InventoryBoardView.InventoryLockboxSortList LockboxSortList;

		// Token: 0x04001428 RID: 5160
		[Header("WeaponSkin")]
		public Toggle SkinSortByRarityToggle;

		// Token: 0x04001429 RID: 5161
		public Toggle SkinSortByRarityAscending;

		// Token: 0x0400142A RID: 5162
		public Toggle SkinSortByNameToggle;

		// Token: 0x0400142B RID: 5163
		public Toggle SkinSortByNameAscending;

		// Token: 0x0400142C RID: 5164
		public Toggle SkinSortBySkinTypeToggle;

		// Token: 0x0400142D RID: 5165
		public Toggle SkinSortBySkinTypeAscending;

		// Token: 0x0400142E RID: 5166
		public InventoryBoardView.InventorySkinSortList SkinSortList;

		// Token: 0x0400142F RID: 5167
		[Header("Scraps")]
		public Text ScrapAmountText;

		// Token: 0x04001430 RID: 5168
		public InventoryBoardView.InventoryScrapLockboxList ScrapLockboxList;

		// Token: 0x04001431 RID: 5169
		public Text GoldScrapAmountText;

		// Token: 0x04001432 RID: 5170
		public InventoryBoardView.InventoryScrapLockboxList GoldScrapLockboxList;

		// Token: 0x04001433 RID: 5171
		[Header("Accessories")]
		public Toggle AccessorySortByNameToggle;

		// Token: 0x04001434 RID: 5172
		public Toggle AccessorySortByNameAscending;

		// Token: 0x04001435 RID: 5173
		public InventoryBoardView.InventoryAccessorySortList AccessorySortList;

		// Token: 0x04001436 RID: 5174
		private InventoryData _inventoryData;

		// Token: 0x04001437 RID: 5175
		private EInventoryBoard _inventoryBoard;

		// Token: 0x04001438 RID: 5176
		private bool _isSettings;

		// Token: 0x020002CD RID: 717
		[Serializable]
		public class InventoryLockboxSortList : PoolableList<InventoryLockboxSortComponent>
		{
		}

		// Token: 0x020002CE RID: 718
		[Serializable]
		public class InventorySkinSortList : PoolableList<InventorySkinSortComponent>
		{
		}

		// Token: 0x020002CF RID: 719
		[Serializable]
		public class InventoryScrapLockboxList : PoolableList<InventoryScrapLockboxComponent>
		{
		}

		// Token: 0x020002D0 RID: 720
		[Serializable]
		public class InventoryAccessorySortList : PoolableList<InventoryAccessorySortComponent>
		{
		}
	}
}
