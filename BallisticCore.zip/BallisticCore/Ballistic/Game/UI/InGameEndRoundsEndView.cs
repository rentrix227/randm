﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002BA RID: 698
	public class InGameEndRoundsEndView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000EA4 RID: 3748 RVA: 0x00058A48 File Offset: 0x00056C48
		internal void RoundsDispatchEnded(EWinningTeam winning, int yourTeamScore, int enemyTeamScore)
		{
			this._winning = winning;
			if (winning != EWinningTeam.MINE)
			{
				if (winning != EWinningTeam.ENEMY)
				{
					this.RoundsTeamStatus.text = ServiceProvider.GetService<LocalizationService>().Get("team_endgame_status_1", ELocalizedTextCase.UPPER_CASE);
				}
				else
				{
					this.RoundsTeamStatus.text = ServiceProvider.GetService<LocalizationService>().Get("team_endgame_status_0", ELocalizedTextCase.UPPER_CASE);
				}
			}
			else
			{
				this.RoundsTeamStatus.text = ServiceProvider.GetService<LocalizationService>().Get("team_endgame_status_2", ELocalizedTextCase.UPPER_CASE);
			}
			this.RoundsYourTeamScore.text = yourTeamScore.ToString();
			this.RoundsEnemyTeamScore.text = enemyTeamScore.ToString();
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x00058B00 File Offset: 0x00056D00
		public void Update()
		{
			if (this.RoundsEndedAnimator.isInitialized)
			{
				this.RoundsEndedAnimator.SetBool("victory", this._winning == EWinningTeam.MINE);
				this.RoundsEndedAnimator.SetBool("defeat", this._winning == EWinningTeam.ENEMY);
				this.RoundsEndedAnimator.SetBool("tied", this._winning == EWinningTeam.NONE);
			}
		}

		// Token: 0x0400137D RID: 4989
		public Text RoundsTeamStatus;

		// Token: 0x0400137E RID: 4990
		public Text RoundsYourTeamScore;

		// Token: 0x0400137F RID: 4991
		public Text RoundsEnemyTeamScore;

		// Token: 0x04001380 RID: 4992
		public Animator RoundsEndedAnimator;

		// Token: 0x04001381 RID: 4993
		private EWinningTeam _winning = EWinningTeam.UNDEFINED;
	}
}
