﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000300 RID: 768
	public class SeasonInfoSkinsView : BaseView<SeasonController>
	{
		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000FEA RID: 4074 RVA: 0x0000D1A3 File Offset: 0x0000B3A3
		// (set) Token: 0x06000FEB RID: 4075 RVA: 0x0000D1AB File Offset: 0x0000B3AB
		internal EHeroClass DefaultClass { get; private set; }

		// Token: 0x06000FEC RID: 4076 RVA: 0x0000D1B4 File Offset: 0x0000B3B4
		protected override void Awake()
		{
			base.Awake();
			this._localization = ServiceProvider.GetService<LocalizationService>();
			this.InitClassesDropdown();
		}

		// Token: 0x06000FED RID: 4077 RVA: 0x0005D6F4 File Offset: 0x0005B8F4
		private void InitClassesDropdown()
		{
			this._classesList = new List<EHeroClass>();
			List<Dropdown.OptionData> options = this.ClassesDropdown.options;
			foreach (Dropdown.OptionData optionData in options)
			{
				EHeroClass eheroClass = (EHeroClass)Enum.Parse(typeof(EHeroClass), optionData.text);
				this._classesList.Add(eheroClass);
				optionData.text = this._localization.GetClassName(eheroClass, ELocalizedTextCase.UPPER_CASE);
			}
			this.ClassesDropdown.options = options;
			this.DefaultClass = this._classesList[0];
			this.ClassesDropdown.onValueChanged.AddListener(new UnityAction<int>(this.HandleClassesDropdownValueChanged));
		}

		// Token: 0x06000FEE RID: 4078 RVA: 0x0005D7D0 File Offset: 0x0005B9D0
		private void HandleClassesDropdownValueChanged(int classIndex)
		{
			EHeroClass eheroClass = this._classesList[classIndex];
			if (this.OnClassSelected != null)
			{
				this.OnClassSelected(eheroClass);
			}
		}

		// Token: 0x06000FEF RID: 4079 RVA: 0x0005D804 File Offset: 0x0005BA04
		internal void SetClass(ESeason season, EHeroClass heroClass)
		{
			string lockboxIconPath = TextureHelper.GetLockboxIconPath(season, heroClass, EImageSize.SMALL);
			TextureHelper.LoadImageAsync(lockboxIconPath, this.LockboxIcon, false, EImageSource.RESOURCES);
		}

		// Token: 0x06000FF0 RID: 4080 RVA: 0x0005D828 File Offset: 0x0005BA28
		internal void SetAvailableSkins(List<WeaponSkinData> skins)
		{
			if (skins == null || skins.Count == 0)
			{
				this.SkinRarityGroupList.SetActiveCount(0);
				return;
			}
			List<IGrouping<ERarity, WeaponSkinData>> list = (from skinData in skins
				orderby skinData.WeaponSkin.Rarity descending
				group skinData by skinData.WeaponSkin.Rarity).ToList<IGrouping<ERarity, WeaponSkinData>>();
			bool flag = false;
			this.PreviewWeaponGroup.SetActive(false);
			this.SkinRarityGroupList.SetActiveCount(list.Count);
			for (int i = 0; i < list.Count; i++)
			{
				IGrouping<ERarity, WeaponSkinData> grouping = list[i];
				List<WeaponSkinData> list2 = grouping.ToList<WeaponSkinData>();
				bool flag2 = false;
				if (list2.Count > 0 && !flag)
				{
					flag = true;
					flag2 = true;
					this.OnWeaponSkinPreview(list2[0]);
				}
				this.SkinRarityGroupList[i].OnWeaponSkinPreview = new Action<WeaponSkinData>(this.OnWeaponSkinPreview);
				if (grouping.Key == ERarity.LEGENDARY)
				{
					this.SkinRarityGroupList[i].SetData(list2, flag2);
					this.SkinRarityGroupList[i].ShowLegendaryMistery();
				}
				else
				{
					this.SkinRarityGroupList[i].SetData(list2, flag2);
				}
			}
		}

		// Token: 0x06000FF1 RID: 4081 RVA: 0x0000D1CD File Offset: 0x0000B3CD
		private void OnWeaponSkinPreview(WeaponSkinData weaponSkin)
		{
			if (this.OnSkinSelected != null)
			{
				this.OnSkinSelected(weaponSkin);
			}
		}

		// Token: 0x06000FF2 RID: 4082 RVA: 0x0005D978 File Offset: 0x0005BB78
		internal void SelectSkin(WeaponSkinData skinData)
		{
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			if (skinData.WeaponSkin.Rarity == ERarity.LEGENDARY)
			{
				this.PreviewWeaponIcon.gameObject.SetActive(false);
				this.LegendaryWeaponPreviewGroup.SetActive(true);
				this.PreviewWeaponSkinName.text = service.Get("unexpected", ELocalizedTextCase.UPPER_CASE);
			}
			else
			{
				this.PreviewWeaponIcon.gameObject.SetActive(true);
				this.LegendaryWeaponPreviewGroup.SetActive(false);
				string weaponIconPath = TextureHelper.GetWeaponIconPath(skinData.Weapon.ItemModel, EImageSize.SMALL, skinData.WeaponSkin.WeaponSkinName);
				TextureHelper.LoadImageAsync(weaponIconPath, this.PreviewWeaponIcon, false, EImageSource.METADATA);
				this.PreviewWeaponSkinName.text = service.GetWeaponName(skinData.Weapon.ItemName, skinData.WeaponSkin.WeaponSkinName, ELocalizedTextCase.UPPER_CASE);
			}
			this.PreviewWeaponGroup.SetActive(true);
			this.PreviewRarityName.text = service.GetRarityName(skinData.WeaponSkin.Rarity);
		}

		// Token: 0x04001516 RID: 5398
		public Image LockboxIcon;

		// Token: 0x04001517 RID: 5399
		public Dropdown ClassesDropdown;

		// Token: 0x04001518 RID: 5400
		public GameObject PreviewWeaponGroup;

		// Token: 0x04001519 RID: 5401
		public RawImage PreviewWeaponIcon;

		// Token: 0x0400151A RID: 5402
		public Text PreviewWeaponSkinName;

		// Token: 0x0400151B RID: 5403
		public Text PreviewRarityName;

		// Token: 0x0400151C RID: 5404
		public GameObject LegendaryWeaponPreviewGroup;

		// Token: 0x0400151D RID: 5405
		public SeasonInfoSkinsView.SkinSortComponentList SkinRarityGroupList;

		// Token: 0x0400151F RID: 5407
		internal Action<EHeroClass> OnClassSelected;

		// Token: 0x04001520 RID: 5408
		internal Action<WeaponSkinData> OnSkinSelected;

		// Token: 0x04001521 RID: 5409
		private List<EHeroClass> _classesList;

		// Token: 0x04001522 RID: 5410
		private LocalizationService _localization;

		// Token: 0x02000301 RID: 769
		[Serializable]
		public class SkinSortComponentList : PoolableList<InventorySkinSortComponent>
		{
		}
	}
}
