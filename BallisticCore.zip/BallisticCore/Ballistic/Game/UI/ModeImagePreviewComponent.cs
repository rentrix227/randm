﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F5 RID: 501
	public class ModeImagePreviewComponent : EnumImagePreviewComponent<EGameMode>
	{
		// Token: 0x06000A1E RID: 2590 RVA: 0x0003BE14 File Offset: 0x0003A014
		public void Start()
		{
			foreach (KeyValuePair<EGameMode, Animator> keyValuePair in this._animators)
			{
				TextureHelper.LoadImageAsync(TextureHelper.GetModeIconPath(keyValuePair.Key.ToString().ToLowerInvariant(), EImageSize.MEDIUM), keyValuePair.Value.GetComponent<RawImage>(), false, EImageSource.RESOURCES);
			}
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0003BE9C File Offset: 0x0003A09C
		internal void UpdateAvaliableItems(GameMapConfig gameMap)
		{
			if (base.GetCurrentValue() == EGameMode.Any && gameMap.MapName == GameMapModeConfigService.DefaultAnyMap.MapName)
			{
				this._availableItems = ServiceProvider.GetService<GameMapModeConfigService>().GetAllPossibleGameModeList().ToList<EGameMode>();
			}
			else
			{
				this._availableItems = ServiceProvider.GetService<GameMapModeConfigService>().GetAvailableGameModeList(gameMap).ToList<EGameMode>();
			}
			this._availableItems.Insert(0, EGameMode.Any);
			if (!this._availableItems.Contains(this._currentItem))
			{
				base.Reset(EGameMode.Any, false);
			}
		}

		// Token: 0x06000A20 RID: 2592 RVA: 0x0003BF2C File Offset: 0x0003A12C
		protected override List<EGameMode> LoadAvailableItems()
		{
			List<EGameMode> list = ServiceProvider.GetService<GameMapModeConfigService>().GetAvailableGameModeList(GameMapModeConfigService.DefaultAnyMap).ToList<EGameMode>();
			list.Insert(0, EGameMode.Any);
			return list;
		}

		// Token: 0x06000A21 RID: 2593 RVA: 0x0003BF58 File Offset: 0x0003A158
		internal EGameMode GetFinalMode()
		{
			EGameMode currentValue = base.GetCurrentValue();
			return (currentValue != EGameMode.Any) ? currentValue : this._availableItems[Random.Range(1, this._availableItems.Count)];
		}

		// Token: 0x06000A22 RID: 2594 RVA: 0x0000916E File Offset: 0x0000736E
		protected override string UpdateText(EGameMode newText)
		{
			return ServiceProvider.GetService<LocalizationService>().GetModeName(newText, ELocalizedTextCase.NONE);
		}
	}
}
