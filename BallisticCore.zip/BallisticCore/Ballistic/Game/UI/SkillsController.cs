﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000252 RID: 594
	public class SkillsController : BaseController
	{
		// Token: 0x06000CBA RID: 3258 RVA: 0x0004C890 File Offset: 0x0004AA90
		public SkillsController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldiersService = ServiceProvider.GetService<SoldiersService>();
			this._soldiersService.OnSoldierChanged += this.OnSoldiersChanged;
			this._soldiersService.OnLoadoutChanged += this.OnLoadoutChanged;
			this._soldiersService.OnSkillChangeRequest += this.OnSkillChangeRequest;
			this._soldiersService.OnSkillSelected += this.OnSkillSelected;
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange += this.OnLanguageChange;
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x0004C92C File Offset: 0x0004AB2C
		private void OnSkillSelected(HeroSkillData skill1, HeroSkillData skill2)
		{
			SoldiersSkillsView view = base.GetView<SoldiersSkillsView>();
			if (view != null)
			{
				view.SetImediateSkills(skill1, skill2);
			}
		}

		// Token: 0x06000CBC RID: 3260 RVA: 0x0004C954 File Offset: 0x0004AB54
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldiersService.OnSoldierChanged -= this.OnSoldiersChanged;
			this._soldiersService.OnLoadoutChanged -= this.OnLoadoutChanged;
			this._soldiersService.OnSkillChangeRequest -= this.OnSkillChangeRequest;
			this._soldiersService.OnSkillSelected -= this.OnSkillSelected;
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange -= this.OnLanguageChange;
		}

		// Token: 0x06000CBD RID: 3261 RVA: 0x0004C9E4 File Offset: 0x0004ABE4
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			SoldiersSkillsView soldiersSkillsView = view as SoldiersSkillsView;
			if (soldiersSkillsView != null)
			{
				PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
				List<PlayerLoadoutData> currentClassPlayerLoadouts = this._soldiersService.GetCurrentClassPlayerLoadouts();
				int num = 0;
				List<List<HeroSkillData>> list = new List<List<HeroSkillData>>();
				for (int i = 0; i < currentClassPlayerLoadouts.Count; i++)
				{
					list.Add(this._soldiersService.GetSelectedHeroSkills(currentClassPlayerLoadouts[i]).ToList<HeroSkillData>());
					if (currentClassPlayerLoadout.PlayerItem.ItemId == currentClassPlayerLoadouts[i].PlayerItem.ItemId)
					{
						num = i;
					}
				}
				soldiersSkillsView.SetStartSkills(list, num);
			}
		}

		// Token: 0x06000CBE RID: 3262 RVA: 0x0004CAA0 File Offset: 0x0004ACA0
		private void OnLanguageChange()
		{
			SoldiersSkillsView view = base.GetView<SoldiersSkillsView>();
			if (view != null)
			{
				PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
				List<PlayerLoadoutData> currentClassPlayerLoadouts = this._soldiersService.GetCurrentClassPlayerLoadouts();
				int num = 0;
				List<List<HeroSkillData>> list = new List<List<HeroSkillData>>();
				for (int i = 0; i < currentClassPlayerLoadouts.Count; i++)
				{
					list.Add(this._soldiersService.GetSelectedHeroSkills(currentClassPlayerLoadouts[i]).ToList<HeroSkillData>());
					if (currentClassPlayerLoadout.PlayerItem.ItemId == currentClassPlayerLoadouts[i].PlayerItem.ItemId)
					{
						num = i;
					}
				}
				view.SetStartSkills(list, num);
			}
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x0004CB4C File Offset: 0x0004AD4C
		private void OnSoldiersChanged(EHeroClass heroClass)
		{
			SoldiersSkillsView view = base.GetView<SoldiersSkillsView>();
			if (view != null)
			{
				PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
				List<PlayerLoadoutData> currentClassPlayerLoadouts = this._soldiersService.GetCurrentClassPlayerLoadouts();
				int num = 0;
				List<List<HeroSkillData>> list = new List<List<HeroSkillData>>();
				for (int i = 0; i < currentClassPlayerLoadouts.Count; i++)
				{
					list.Add(this._soldiersService.GetSelectedHeroSkills(currentClassPlayerLoadouts[i]).ToList<HeroSkillData>());
					if (currentClassPlayerLoadout.PlayerItem.ItemId == currentClassPlayerLoadouts[i].PlayerItem.ItemId)
					{
						num = i;
					}
				}
				view.SetSkills(list, num);
			}
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x0004CBF8 File Offset: 0x0004ADF8
		private void OnLoadoutChanged(PlayerLoadoutData loadout)
		{
			SoldiersSkillsView view = base.GetView<SoldiersSkillsView>();
			if (view != null)
			{
				List<PlayerLoadoutData> currentClassPlayerLoadouts = this._soldiersService.GetCurrentClassPlayerLoadouts();
				int num = 0;
				List<List<HeroSkillData>> list = new List<List<HeroSkillData>>();
				for (int i = 0; i < currentClassPlayerLoadouts.Count; i++)
				{
					list.Add(this._soldiersService.GetSelectedHeroSkills(currentClassPlayerLoadouts[i]).ToList<HeroSkillData>());
					if (loadout.PlayerItem.ItemId == currentClassPlayerLoadouts[i].PlayerItem.ItemId)
					{
						num = i;
					}
				}
				view.SetSkills(list, num);
			}
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x0004CC94 File Offset: 0x0004AE94
		private void OnSkillChangeRequest(int skillslot)
		{
			PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
			List<HeroSkillData> list = this._soldiersService.GetSelectedHeroSkills(currentClassPlayerLoadout).ToList<HeroSkillData>();
			if (list.Count < 2)
			{
				Debug.Log(string.Concat(new object[]
				{
					"Loadout [",
					currentClassPlayerLoadout.GameItemData.GameItem.UniqueIdentifier,
					currentClassPlayerLoadout.PlayerItem.Number,
					"] has missing selectable skills."
				}));
				return;
			}
			this._currentSkillSlot = skillslot;
			this._skill1 = list[0];
			this._skill2 = list[1];
			EditSkillCurrentView view = base.GetView<EditSkillCurrentView>();
			if (view != null)
			{
				view.SetSkills(list[0], list[1], skillslot);
			}
			EditSkillAvaliableView view2 = base.GetView<EditSkillAvaliableView>();
			if (view2 != null)
			{
				view2.SetAvaliableSkills(this._soldiersService.GetCurrentClass(), this._soldiersService.GetAvailableHeroSkills().ToList<HeroSkillData>(), this._soldiersService.GetAllHeroSkills().ToList<HeroSkillData>(), (skillslot != 0) ? this._skill2 : this._skill1);
			}
			EditSkillDescriptionView view3 = base.GetView<EditSkillDescriptionView>();
			if (view3)
			{
				view3.SetStartDescription(list[skillslot]);
			}
		}

		// Token: 0x06000CC2 RID: 3266 RVA: 0x0000AB50 File Offset: 0x00008D50
		public void RequestSkillChange(int skillslot)
		{
			this._soldiersService.RequestSkillChange(skillslot);
		}

		// Token: 0x06000CC3 RID: 3267 RVA: 0x0004CDE0 File Offset: 0x0004AFE0
		public void SetTemporarySlot(int skillslot)
		{
			this._currentSkillSlot = skillslot;
			EditSkillCurrentView view = base.GetView<EditSkillCurrentView>();
			if (view != null)
			{
				view.SetSkills(this._skill1, this._skill2, skillslot);
			}
			EditSkillAvaliableView view2 = base.GetView<EditSkillAvaliableView>();
			if (view2 != null)
			{
				view2.SetAvaliableSkills(this._soldiersService.GetCurrentClass(), this._soldiersService.GetAvailableHeroSkills().ToList<HeroSkillData>(), this._soldiersService.GetAllHeroSkills().ToList<HeroSkillData>(), (skillslot != 0) ? this._skill2 : this._skill1);
			}
			EditSkillDescriptionView view3 = base.GetView<EditSkillDescriptionView>();
			if (view3)
			{
				view3.SetStartDescription((skillslot != 0) ? this._skill2 : this._skill1);
			}
		}

		// Token: 0x06000CC4 RID: 3268 RVA: 0x0004CEA4 File Offset: 0x0004B0A4
		public void SetTemporarySkill(HeroSkillData skill)
		{
			if (this._currentSkillSlot == 0)
			{
				if (skill.Skill == this._skill1.Skill)
				{
					return;
				}
				if (skill.Skill == this._skill2.Skill)
				{
					this._skill2 = this._skill1;
					this._skill1 = skill;
				}
				else
				{
					this._skill1 = skill;
				}
			}
			else
			{
				if (skill.Skill == this._skill2.Skill)
				{
					return;
				}
				if (skill.Skill == this._skill1.Skill)
				{
					this._skill1 = this._skill2;
					this._skill2 = skill;
				}
				else
				{
					this._skill2 = skill;
				}
			}
			EditSkillCurrentView view = base.GetView<EditSkillCurrentView>();
			if (view != null)
			{
				view.SetSkills(this._skill1, this._skill2, this._currentSkillSlot);
			}
			EditSkillAvaliableView view2 = base.GetView<EditSkillAvaliableView>();
			if (view2 != null)
			{
				view2.SetAvaliableSkills(this._soldiersService.GetCurrentClass(), this._soldiersService.GetAvailableHeroSkills().ToList<HeroSkillData>(), this._soldiersService.GetAllHeroSkills().ToList<HeroSkillData>(), (this._currentSkillSlot != 0) ? this._skill2 : this._skill1);
			}
			EditSkillDescriptionView view3 = base.GetView<EditSkillDescriptionView>();
			if (view3)
			{
				view3.SetStartDescription((this._currentSkillSlot != 0) ? this._skill2 : this._skill1);
			}
		}

		// Token: 0x06000CC5 RID: 3269 RVA: 0x0000AB5E File Offset: 0x00008D5E
		public void SaveSelectedSkills()
		{
			this._soldiersService.DispatchSkillSelected(this._skill1, this._skill2);
		}

		// Token: 0x04000FAB RID: 4011
		private readonly SoldiersService _soldiersService;

		// Token: 0x04000FAC RID: 4012
		private int _currentSkillSlot;

		// Token: 0x04000FAD RID: 4013
		private HeroSkillData _skill1;

		// Token: 0x04000FAE RID: 4014
		private HeroSkillData _skill2;
	}
}
