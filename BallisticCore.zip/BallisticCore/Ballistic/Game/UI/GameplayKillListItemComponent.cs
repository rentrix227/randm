﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001C8 RID: 456
	public class GameplayKillListItemComponent : PoolableComponent
	{
		// Token: 0x06000981 RID: 2433 RVA: 0x000088FE File Offset: 0x00006AFE
		private Color GetTeamColor(UITeam team)
		{
			return (team != UITeam.Mine) ? this.OtherTeamColor : this.MyTeamColor;
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x00008918 File Offset: 0x00006B18
		internal void SetTeams(UITeam killerTeam, UITeam victimTeam)
		{
			this.Killer.color = this.GetTeamColor(killerTeam);
			this.Victim.color = this.GetTeamColor(victimTeam);
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x00039A1C File Offset: 0x00037C1C
		internal void SetInfoEvent(string player, UserUpdateType eventType)
		{
			this.Killer.text = player;
			this.Victim.text = ServiceProvider.GetService<LocalizationService>().Get("hud_kill_list_event_" + eventType.ToString().ToLowerInvariant(), ELocalizedTextCase.UPPER_CASE);
			this.Victim.color = Color.white;
			this.Icon.enabled = false;
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x00039A84 File Offset: 0x00037C84
		internal void SetInfoKill(string killer, string victim, EWeaponCategory weaponCategory, bool isHeadshot, bool isLongShot)
		{
			bool flag = killer == victim;
			if (flag)
			{
				victim = ServiceProvider.GetService<LocalizationService>().Get("hud_kill_list_suicided", ELocalizedTextCase.UPPER_CASE);
				this.Victim.color = Color.white;
			}
			this.Killer.text = killer;
			this.Victim.text = victim;
			this.Icon.enabled = true;
			if (flag)
			{
				this.Icon.sprite = this.SuicideSprite;
			}
			else if (weaponCategory == EWeaponCategory.Explosive)
			{
				this.Icon.sprite = this.GrenadeSprite;
			}
			else if (weaponCategory == EWeaponCategory.Melee || weaponCategory == EWeaponCategory.MeleeSpecial)
			{
				this.Icon.sprite = this.MeleeSprite;
			}
			else if (weaponCategory == EWeaponCategory.Concussion)
			{
				this.Icon.sprite = this.ConcussionSprite;
			}
			else if (isHeadshot)
			{
				this.Icon.sprite = this.HeadshotSprite;
			}
			else if (isLongShot)
			{
				this.Icon.sprite = this.LongshotSprite;
			}
			else
			{
				this.Icon.sprite = this.KillSprite;
			}
		}

		// Token: 0x04000C92 RID: 3218
		public Text Killer;

		// Token: 0x04000C93 RID: 3219
		public Text Victim;

		// Token: 0x04000C94 RID: 3220
		public Image Icon;

		// Token: 0x04000C95 RID: 3221
		public Color MyTeamColor;

		// Token: 0x04000C96 RID: 3222
		public Color OtherTeamColor;

		// Token: 0x04000C97 RID: 3223
		[Header("Kill type icons")]
		public Sprite KillSprite;

		// Token: 0x04000C98 RID: 3224
		public Sprite HeadshotSprite;

		// Token: 0x04000C99 RID: 3225
		public Sprite LongshotSprite;

		// Token: 0x04000C9A RID: 3226
		public Sprite GrenadeSprite;

		// Token: 0x04000C9B RID: 3227
		public Sprite MeleeSprite;

		// Token: 0x04000C9C RID: 3228
		public Sprite SuicideSprite;

		// Token: 0x04000C9D RID: 3229
		public Sprite ConcussionSprite;
	}
}
