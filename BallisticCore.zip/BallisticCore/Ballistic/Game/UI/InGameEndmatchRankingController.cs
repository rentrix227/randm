﻿using System;
using System.IO;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Leaderboards.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Services;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000227 RID: 551
	public class InGameEndmatchRankingController : BaseController
	{
		// Token: 0x06000B6B RID: 2923 RVA: 0x000447C8 File Offset: 0x000429C8
		public InGameEndmatchRankingController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._statisticsService = ServiceProvider.GetService<StatisticsService>();
			this._currentLeaderboardRating = null;
			this._fetchCompleted = false;
			this._oldMatches = new int[5];
			this._newMatches = new int[5];
			this._playerName = ((!string.IsNullOrEmpty(File.ReadAllText(Application.dataPath + "/NameTag.txt").Trim())) ? File.ReadAllText(Application.dataPath + "/NameTag.txt") : SteamFriends.GetPersonaName());
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(SteamUser.GetSteamID(), new Action<ulong, Texture2D>(this.OnLoadAvatar), true);
			ServiceProvider.GetService<NetworkGameService>().OnLeaderboardUpload.AddListener(new Action<LeaderboardUploadEvent>(this.OnLeaderboardCalculatedRank));
		}

		// Token: 0x06000B6C RID: 2924 RVA: 0x000448B4 File Offset: 0x00042AB4
		private void OnLeaderboardCalculatedRank(LeaderboardUploadEvent evt)
		{
			this._currentLeaderboardRating = evt;
			Debug.Log(string.Concat(new object[] { "Ranked Current[", evt.CurrentRating, "] Last [", evt.LastRating, "]" }));
		}

		// Token: 0x06000B6D RID: 2925 RVA: 0x0004490C File Offset: 0x00042B0C
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			this._oldMatches[0] = this._statisticsService.GeneralUserData.GetLeaderboardMatchs(EGameMode.TeamDeathMatch);
			this._oldMatches[1] = this._statisticsService.GeneralUserData.GetLeaderboardMatchs(EGameMode.FreeForAll);
			this._oldMatches[2] = this._statisticsService.GeneralUserData.GetLeaderboardMatchs(EGameMode.Conquest);
			this._oldMatches[3] = this._statisticsService.GeneralUserData.GetLeaderboardMatchs(EGameMode.KingOfTheHill);
			this._oldMatches[4] = this._statisticsService.GeneralUserData.GetLeaderboardMatchs(EGameMode.Rounds);
		}

		// Token: 0x06000B6E RID: 2926 RVA: 0x00009E33 File Offset: 0x00008033
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
		}

		// Token: 0x06000B6F RID: 2927 RVA: 0x00009E46 File Offset: 0x00008046
		private void OnLoadAvatar(ulong steamId, Texture2D texture)
		{
			this._playerAvatar = texture;
		}

		// Token: 0x06000B70 RID: 2928 RVA: 0x00044998 File Offset: 0x00042B98
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameEndmatchRankingView inGameEndmatchRankingView = view as InGameEndmatchRankingView;
			if (inGameEndmatchRankingView != null)
			{
				if (!this._fetchCompleted)
				{
					inGameEndmatchRankingView.SetStartData();
					this._statisticsService.RequestCurrentStats(new Action<StatisticsGeneralData>(this.OnRequestUserDataSucess));
				}
				else if (this._currentLeaderboardRating != null)
				{
					inGameEndmatchRankingView.SetData(this._playerName, this._playerAvatar, this._oldMatches, this._newMatches, (int)this._currentLeaderboardRating.LastRating, (int)this._currentLeaderboardRating.CurrentRating);
				}
				else
				{
					inGameEndmatchRankingView.SetData(this._playerName, this._playerAvatar, this._oldMatches, this._newMatches, 0, 0);
				}
			}
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x00044A5C File Offset: 0x00042C5C
		private void OnRequestUserDataSucess(StatisticsGeneralData evt)
		{
			this._newMatches[0] = evt.GetLeaderboardMatchs(EGameMode.TeamDeathMatch);
			this._newMatches[1] = evt.GetLeaderboardMatchs(EGameMode.FreeForAll);
			this._newMatches[2] = evt.GetLeaderboardMatchs(EGameMode.Conquest);
			this._newMatches[3] = evt.GetLeaderboardMatchs(EGameMode.KingOfTheHill);
			this._newMatches[4] = evt.GetLeaderboardMatchs(EGameMode.Rounds);
			this._fetchCompleted = true;
			Debug.Log(string.Format("RequestStats fetch completed: TDM[{0}] FFA[{1}] CTP[{2}] KOTH[{3}] RND[{4}]", new object[]
			{
				this._newMatches[0],
				this._newMatches[1],
				this._newMatches[2],
				this._newMatches[3],
				this._newMatches[4]
			}));
			InGameEndmatchRankingView view = base.GetView<InGameEndmatchRankingView>();
			if (view != null)
			{
				if (this._currentLeaderboardRating != null)
				{
					view.SetData(this._playerName, this._playerAvatar, this._oldMatches, this._newMatches, (int)this._currentLeaderboardRating.LastRating, (int)this._currentLeaderboardRating.CurrentRating);
				}
				else
				{
					view.SetData(this._playerName, this._playerAvatar, this._oldMatches, this._newMatches, 0, 0);
				}
			}
		}

		// Token: 0x04000EDA RID: 3802
		private StatisticsService _statisticsService;

		// Token: 0x04000EDB RID: 3803
		private NetworkGameService _networkGameService;

		// Token: 0x04000EDC RID: 3804
		private readonly string _playerName;

		// Token: 0x04000EDD RID: 3805
		private readonly int[] _oldMatches;

		// Token: 0x04000EDE RID: 3806
		private readonly int[] _newMatches;

		// Token: 0x04000EDF RID: 3807
		private bool _fetchCompleted;

		// Token: 0x04000EE0 RID: 3808
		private Texture2D _playerAvatar;

		// Token: 0x04000EE1 RID: 3809
		private LeaderboardUploadEvent _currentLeaderboardRating;
	}
}
