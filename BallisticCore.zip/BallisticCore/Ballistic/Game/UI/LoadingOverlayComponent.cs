﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001EE RID: 494
	public class LoadingOverlayComponent : MonoBehaviour
	{
		// Token: 0x060009EB RID: 2539 RVA: 0x00008F4C File Offset: 0x0000714C
		public void Start()
		{
			Object.DontDestroyOnLoad(base.gameObject);
			ServiceProvider.GetService<SceneService>().OnMapLoading += this.OnMapLoading;
			ServiceProvider.GetService<SceneService>().OnSceneLoaded += this.OnSceneLoaded;
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x0003AEF8 File Offset: 0x000390F8
		private void OnSceneLoaded(EBaseScene scene)
		{
			if (scene == EBaseScene.Main || scene == EBaseScene.InGame)
			{
				float num = 0f;
				if (scene == EBaseScene.InGame)
				{
					num = 1f;
				}
				base.StartCoroutine(LoadingOverlayComponent.HideMeAfterSomeTimeRoutine(num));
			}
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x0003AF34 File Offset: 0x00039134
		private static IEnumerator HideMeAfterSomeTimeRoutine(float time)
		{
			yield return new WaitForSeconds(time);
			UIManager.Instance.DisableLayer(5);
			yield break;
		}

		// Token: 0x060009EE RID: 2542 RVA: 0x0003AF50 File Offset: 0x00039150
		private void OnMapLoading(MapLoadProgress mapLoadProgress)
		{
			if (!UIManager.Instance.CurrentStates.Contains("MAP_LOADING"))
			{
				UIManager.Instance.ChangeState("MAP_LOADING");
				this.SetMap(mapLoadProgress.Map);
				this.SetMode(mapLoadProgress.Mode);
				this.SetTip(mapLoadProgress.Tip);
			}
			this.SetLoadingProgress(mapLoadProgress.Progress);
		}

		// Token: 0x060009EF RID: 2543 RVA: 0x00008F85 File Offset: 0x00007185
		public void OnDestroy()
		{
			ServiceProvider.GetService<SceneService>().OnMapLoading -= this.OnMapLoading;
			ServiceProvider.GetService<SceneService>().OnSceneLoaded -= this.OnSceneLoaded;
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x00008FB3 File Offset: 0x000071B3
		private void SetMap(GameMapConfig p_map)
		{
			this.SetMapName(p_map);
			this.SetMapImage(p_map);
			this.SetMiniMap(p_map);
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x00008FCA File Offset: 0x000071CA
		private void SetMode(EGameMode p_mode)
		{
			this.SetModeName(p_mode);
			this.SetModeDesc(p_mode);
			this.SetModeMinimap(p_mode);
		}

		// Token: 0x060009F2 RID: 2546 RVA: 0x00008FE1 File Offset: 0x000071E1
		private void SetMapImage(GameMapConfig p_map)
		{
			TextureHelper.LoadImageAsync(TextureHelper.GetMapIconPath(p_map, EImageSize.LARGE), this.m_mapImage, false, EImageSource.STREAMINGASSETS);
		}

		// Token: 0x060009F3 RID: 2547 RVA: 0x00008FF7 File Offset: 0x000071F7
		private void SetMapName(GameMapConfig p_map)
		{
			this.m_mapName.text = ServiceProvider.GetService<LocalizationService>().GetMapName(p_map.MapId, ELocalizedTextCase.NONE);
		}

		// Token: 0x060009F4 RID: 2548 RVA: 0x00009015 File Offset: 0x00007215
		private void SetModeName(EGameMode p_mode)
		{
			this.m_gameMode.text = ServiceProvider.GetService<LocalizationService>().GetModeName(p_mode, ELocalizedTextCase.NONE);
		}

		// Token: 0x060009F5 RID: 2549 RVA: 0x0000902E File Offset: 0x0000722E
		private void SetModeDesc(EGameMode p_mode)
		{
			this.m_gameModeDesc.text = ServiceProvider.GetService<LocalizationService>().GetModeDescription(p_mode, ELocalizedTextCase.NONE);
		}

		// Token: 0x060009F6 RID: 2550 RVA: 0x00009047 File Offset: 0x00007247
		private void SetTip(string p_key)
		{
			this.m_loadingTip.text = ServiceProvider.GetService<LocalizationService>().Get(p_key, ELocalizedTextCase.NONE);
		}

		// Token: 0x060009F7 RID: 2551 RVA: 0x0003AFBC File Offset: 0x000391BC
		private void SetMiniMap(GameMapConfig p_map)
		{
			IEnumerator enumerator = this.m_miniMaps.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					Transform transform = (Transform)obj;
					transform.gameObject.SetActive(false);
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			Transform transform2 = this.m_miniMaps.Find(p_map.MapName);
			if (transform2 != null)
			{
				transform2.gameObject.SetActive(true);
			}
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0003B050 File Offset: 0x00039250
		private void SetModeMinimap(EGameMode pMode)
		{
			switch (pMode)
			{
			case EGameMode.TeamDeathMatch:
			{
				IEnumerator enumerator = this.m_miniMaps.GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						Transform transform = (Transform)obj;
						for (int i = 0; i < transform.childCount; i++)
						{
							string text = transform.GetChild(i).gameObject.name.ToLower();
							transform.GetChild(i).gameObject.SetActive(text.Contains("team_") || text == "image");
						}
					}
				}
				finally
				{
					IDisposable disposable;
					if ((disposable = enumerator as IDisposable) != null)
					{
						disposable.Dispose();
					}
				}
				return;
			}
			case EGameMode.Conquest:
			{
				IEnumerator enumerator2 = this.m_miniMaps.GetEnumerator();
				try
				{
					while (enumerator2.MoveNext())
					{
						object obj2 = enumerator2.Current;
						Transform transform2 = (Transform)obj2;
						for (int j = 0; j < transform2.childCount; j++)
						{
							string text2 = transform2.GetChild(j).gameObject.name.ToLower();
							transform2.GetChild(j).gameObject.SetActive(text2.Contains("team_") || text2.Contains("capture_") || text2 == "image");
						}
					}
				}
				finally
				{
					IDisposable disposable2;
					if ((disposable2 = enumerator2 as IDisposable) != null)
					{
						disposable2.Dispose();
					}
				}
				return;
			}
			case EGameMode.KingOfTheHill:
			{
				IEnumerator enumerator3 = this.m_miniMaps.GetEnumerator();
				try
				{
					while (enumerator3.MoveNext())
					{
						object obj3 = enumerator3.Current;
						Transform transform3 = (Transform)obj3;
						for (int k = 0; k < transform3.childCount; k++)
						{
							string text3 = transform3.GetChild(k).gameObject.name.ToLower();
							transform3.GetChild(k).gameObject.SetActive(text3.Contains("team_") || text3.Contains("king_") || text3 == "image");
						}
					}
				}
				finally
				{
					IDisposable disposable3;
					if ((disposable3 = enumerator3 as IDisposable) != null)
					{
						disposable3.Dispose();
					}
				}
				return;
			}
			case EGameMode.FreeForAll:
			case EGameMode.Juggernaut:
			{
				IEnumerator enumerator4 = this.m_miniMaps.GetEnumerator();
				try
				{
					while (enumerator4.MoveNext())
					{
						object obj4 = enumerator4.Current;
						Transform transform4 = (Transform)obj4;
						for (int l = 0; l < transform4.childCount; l++)
						{
							string text4 = transform4.GetChild(l).gameObject.name.ToLower();
							transform4.GetChild(l).gameObject.SetActive(text4 == "image");
						}
					}
				}
				finally
				{
					IDisposable disposable4;
					if ((disposable4 = enumerator4 as IDisposable) != null)
					{
						disposable4.Dispose();
					}
				}
				return;
			}
			}
			IEnumerator enumerator5 = this.m_miniMaps.GetEnumerator();
			try
			{
				while (enumerator5.MoveNext())
				{
					object obj5 = enumerator5.Current;
					Transform transform5 = (Transform)obj5;
					for (int m = 0; m < transform5.childCount; m++)
					{
						string text5 = transform5.GetChild(m).gameObject.name.ToLower();
						transform5.GetChild(m).gameObject.SetActive(text5 == "image");
					}
				}
			}
			finally
			{
				IDisposable disposable5;
				if ((disposable5 = enumerator5 as IDisposable) != null)
				{
					disposable5.Dispose();
				}
			}
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x00009060 File Offset: 0x00007260
		private void SetLoadingProgress(float p_value)
		{
			this.m_loadingBarImage.fillAmount = Mathf.Clamp01(p_value);
		}

		// Token: 0x04000D4F RID: 3407
		public RawImage m_mapImage;

		// Token: 0x04000D50 RID: 3408
		public Transform m_miniMaps;

		// Token: 0x04000D51 RID: 3409
		public Image m_loadingBarImage;

		// Token: 0x04000D52 RID: 3410
		public Text m_mapName;

		// Token: 0x04000D53 RID: 3411
		public Text m_gameMode;

		// Token: 0x04000D54 RID: 3412
		public Text m_gameModeDesc;

		// Token: 0x04000D55 RID: 3413
		public Text m_loadingTip;
	}
}
