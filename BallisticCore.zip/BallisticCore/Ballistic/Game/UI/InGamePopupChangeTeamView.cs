﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C2 RID: 706
	public class InGamePopupChangeTeamView : BaseView<InGameHeaderController>
	{
		// Token: 0x06000EC9 RID: 3785 RVA: 0x0000C0B9 File Offset: 0x0000A2B9
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Accept.onClick.AddListener(new UnityAction(this.OnAcceptClicked));
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x000595E4 File Offset: 0x000577E4
		internal void SetData(ETeamMode teamMode, int playerCount, int maxPlayerCount, int remainingTime)
		{
			this._isActive = true;
			this._remainingTime = (float)remainingTime;
			if (teamMode == ETeamMode.MFA)
			{
				this.TeamName.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(Team.MFA, ELocalizedTextCase.UPPER_CASE);
			}
			if (teamMode == ETeamMode.SMOKE)
			{
				this.TeamName.text = ServiceProvider.GetService<LocalizationService>().GetTeamName(Team.MFA, ELocalizedTextCase.UPPER_CASE);
			}
			this.TeamSize.text = playerCount.ToString() + "/" + maxPlayerCount.ToString();
			this.QueueTeamLogo.sprite = this.TeamLogos[(int)teamMode];
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x00059680 File Offset: 0x00057880
		public void Update()
		{
			if (!this._isActive)
			{
				return;
			}
			if (this._remainingTime > 0f)
			{
				this._remainingTime -= Time.deltaTime;
			}
			else
			{
				this._isActive = false;
				this._remainingTime = 0f;
				base._controller.DispatchClearPopupLayer();
			}
			this.AcceptText.text = ((int)this._remainingTime).ToString();
		}

		// Token: 0x06000ECC RID: 3788 RVA: 0x0000C0E8 File Offset: 0x0000A2E8
		private void OnAcceptClicked()
		{
			base._controller.DispatchRebalanceCallResponse();
		}

		// Token: 0x040013C8 RID: 5064
		[Header("Team")]
		public Text TeamName;

		// Token: 0x040013C9 RID: 5065
		public Text TeamSize;

		// Token: 0x040013CA RID: 5066
		public Image QueueTeamLogo;

		// Token: 0x040013CB RID: 5067
		public Sprite[] TeamLogos;

		// Token: 0x040013CC RID: 5068
		public Text AcceptText;

		// Token: 0x040013CD RID: 5069
		public Button Accept;

		// Token: 0x040013CE RID: 5070
		private bool _isActive;

		// Token: 0x040013CF RID: 5071
		private float _remainingTime;
	}
}
