﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.UI.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001FF RID: 511
	public class ScoreboardPlayerComponent : PoolableComponent
	{
		// Token: 0x06000A45 RID: 2629 RVA: 0x0003C638 File Offset: 0x0003A838
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Toggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnToggleClick));
			if (this.Score != null)
			{
				this._originalScoreColor = this.Score.color;
			}
		}

		// Token: 0x06000A46 RID: 2630 RVA: 0x0003C690 File Offset: 0x0003A890
		internal void SetData(int number, ClientCommonMetaData metaData, bool isActive, bool isSpectator, float averagePing)
		{
			this._isSetting = true;
			this._playerId = metaData.User;
			if (this.PlayerNumber != null)
			{
				this.PlayerNumber.text = number.ToString();
			}
			if (this.ClassIcon != null)
			{
				EHeroClass heroClass = LoadoutUtil.GetHeroClass(metaData.LoadoutInfo);
				foreach (ClassSprite classSprite in this.ClassSprites)
				{
					if (classSprite.HeroClass == heroClass)
					{
						if (metaData.Levels.ContainsKey((short)heroClass))
						{
							bool flag = ServiceProvider.GetService<ProgressionService>().CheckGoldClass((int)metaData.Levels[(short)heroClass]);
							this.ClassIcon.sprite = ((!flag) ? classSprite.HeroIcon : classSprite.GoldIcon);
							this.ClassIcon.color = ((!flag) ? new Color32(200, 203, 207, byte.MaxValue) : new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue));
						}
						else
						{
							this.ClassIcon.sprite = classSprite.HeroIcon;
						}
						this.ClassIcon.SetNativeSize();
						break;
					}
				}
			}
			if (this.SpectatorCameraImage != null && this.SpectatorCameraImage.gameObject.activeSelf != isSpectator)
			{
				this.SpectatorCameraImage.gameObject.SetActive(isSpectator);
			}
			if (this.PlayerName != null)
			{
				this.PlayerName.text = metaData.Nickname;
			}
			if (this.Kills != null)
			{
				this.Kills.text = metaData.Kills.ToString();
			}
			if (this.Assists != null)
			{
				this.Assists.text = ((int)(metaData.Assists + metaData.Criticalassists)).ToString();
			}
			if (this.Score != null)
			{
				this._score = (int)metaData.Score;
				this._ping = (uint)Mathf.RoundToInt(averagePing);
				this.UpdateScoreDisplay();
			}
			if (this.Toggle != null)
			{
				this.Toggle.interactable = isSpectator;
				this.Toggle.isOn = isActive;
			}
			this._isSetting = false;
		}

		// Token: 0x06000A47 RID: 2631 RVA: 0x0003C91C File Offset: 0x0003AB1C
		private void UpdateScoreDisplay()
		{
			if (Input.GetKey(282))
			{
				this.Score.text = ((this._ping <= 0U) ? string.Empty : this._ping.ToString());
				this.Score.color = LatencyDefinitionData.GetLatency(this._ping).UiColor;
			}
			else
			{
				this.Score.text = this._score.ToString();
				this.Score.color = this._originalScoreColor;
			}
		}

		// Token: 0x06000A48 RID: 2632 RVA: 0x00009322 File Offset: 0x00007522
		public void Update()
		{
			if (Input.GetKeyDown(282) || Input.GetKeyUp(282))
			{
				this.UpdateScoreDisplay();
			}
		}

		// Token: 0x06000A49 RID: 2633 RVA: 0x00009348 File Offset: 0x00007548
		private void OnToggleClick(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			if (this.OnPlayerClick != null)
			{
				this.OnPlayerClick(this._playerId);
			}
		}

		// Token: 0x04000DAE RID: 3502
		public Text PlayerNumber;

		// Token: 0x04000DAF RID: 3503
		public Image ClassIcon;

		// Token: 0x04000DB0 RID: 3504
		public Image SpectatorCameraImage;

		// Token: 0x04000DB1 RID: 3505
		public Text PlayerName;

		// Token: 0x04000DB2 RID: 3506
		public Text Kills;

		// Token: 0x04000DB3 RID: 3507
		public Text Assists;

		// Token: 0x04000DB4 RID: 3508
		public Text Score;

		// Token: 0x04000DB5 RID: 3509
		public Toggle Toggle;

		// Token: 0x04000DB6 RID: 3510
		public ClassSprite[] ClassSprites;

		// Token: 0x04000DB7 RID: 3511
		public Action<long> OnPlayerClick;

		// Token: 0x04000DB8 RID: 3512
		private long _playerId;

		// Token: 0x04000DB9 RID: 3513
		private bool _isSetting;

		// Token: 0x04000DBA RID: 3514
		private Color _originalScoreColor;

		// Token: 0x04000DBB RID: 3515
		private int _score;

		// Token: 0x04000DBC RID: 3516
		private uint _ping;
	}
}
