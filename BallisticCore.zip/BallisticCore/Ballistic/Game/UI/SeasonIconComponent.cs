﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000200 RID: 512
	public class SeasonIconComponent : MonoBehaviour
	{
		// Token: 0x06000A4B RID: 2635 RVA: 0x0003C9B8 File Offset: 0x0003ABB8
		public void OnEnable()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			string seasonIconPath = TextureHelper.GetSeasonIconPath(ServiceProvider.GetService<SeasonService>().GetCurrentSeasonInfo().Season, EImageSize.MEDIUM);
			TextureHelper.LoadImageAsync(seasonIconPath, this.SeasonIconImage, false, EImageSource.RESOURCES);
		}

		// Token: 0x04000DBD RID: 3517
		public Image SeasonIconImage;
	}
}
