﻿using System;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002BC RID: 700
	public class InGameFreecamView : BaseView<InGameFreecamController>
	{
	}
}
