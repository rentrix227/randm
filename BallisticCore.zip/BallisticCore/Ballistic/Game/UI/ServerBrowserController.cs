﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Connection;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200024F RID: 591
	public class ServerBrowserController : BaseController
	{
		// Token: 0x06000C6F RID: 3183 RVA: 0x0004B1CC File Offset: 0x000493CC
		public ServerBrowserController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._filters = new ServerBrowserSearchFilters();
			this._filters.Name = string.Empty;
			this._filters.Map = GameMapModeConfigService.DefaultAnyMap;
			this._filters.Mode = EGameMode.Any;
			this._filters.Latency = ELatency.ALL;
			this._filters.FriendsOnly = false;
			this._filters.Officials = true;
			this._filters.OfficialsSearchFilterMode = EServerFilterMode.AVALIABLE;
			this._hostItemRequested = null;
			this._sortFriends = true;
			this._sortClan = false;
			this._quickMatchIsRunning = false;
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._quickMatchService = ServiceProvider.GetService<QuickMatchService>();
			this._quickMatchService.OnStart += this.OnQuickMatchStart;
			this._quickMatchService.OnFinish += this.OnQuickMatchFinish;
			this._serverService = ServiceProvider.GetService<ServerBrowserService>();
			this._serverService.ListenSearchEvents(new Action(this.OnSearchStarted), new Action(this.OnSearchCancelled), new Action(this.OnSearchEnded), new Action<HostItem>(this.OnServerFound), new Action<List<HostItem>>(this.OnUpdateListRequest));
			this._serverService.SearchServers(this._filters);
			this._remainingTime = 17f;
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._eventProxy.EUpdate.AddListener(new Action(this.UpdateServerBrowser));
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange += this.OnLanguageChange;
			this._popupService = ServiceProvider.GetService<PopupService>();
		}

		// Token: 0x06000C70 RID: 3184 RVA: 0x0004B37C File Offset: 0x0004957C
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._quickMatchService.OnStart -= this.OnQuickMatchStart;
			this._quickMatchService.OnFinish -= this.OnQuickMatchFinish;
			this._serverService.ClearSearchEvents(new Action(this.OnSearchStarted), new Action(this.OnSearchCancelled), new Action(this.OnSearchEnded), new Action<HostItem>(this.OnServerFound), new Action<List<HostItem>>(this.OnUpdateListRequest));
			this._serverService.StopSearch();
			this._eventProxy.EUpdate.RemoveListener(new Action(this.UpdateServerBrowser));
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange -= this.OnLanguageChange;
		}

		// Token: 0x06000C71 RID: 3185 RVA: 0x0004B44C File Offset: 0x0004964C
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			ServerBrowserFilterSettingsView serverBrowserFilterSettingsView = view as ServerBrowserFilterSettingsView;
			if (serverBrowserFilterSettingsView != null)
			{
				serverBrowserFilterSettingsView.SetMapDropdown(this.GetAvailableMaps(), this._filters.Map);
				serverBrowserFilterSettingsView.SetModeDropdown(this.GetAvailableModes(), this._filters.Mode);
				serverBrowserFilterSettingsView.SetLatencyDropdown(ServerBrowserController.GetAvaliableLatencies(), LatencyDefinitionData.GetLatency(this._filters.Latency).Latency);
				if (!this._quickMatchIsRunning)
				{
					this.RefreshServerList();
				}
			}
			if (view as ServerFriendsView != null && !this._quickMatchIsRunning)
			{
				this.RefreshServerList();
			}
			ServerFriendJoinView serverFriendJoinView = view as ServerFriendJoinView;
			if (serverFriendJoinView != null)
			{
				serverFriendJoinView.SetFriendServer(this._friendSelected, this._friendHostSelected);
			}
		}

		// Token: 0x06000C72 RID: 3186 RVA: 0x0004B514 File Offset: 0x00049714
		private void OnLanguageChange()
		{
			ServerBrowserFilterSettingsView view = base.GetView<ServerBrowserFilterSettingsView>();
			if (view != null)
			{
				view.SetMapDropdown(this.GetAvailableMaps(), this._filters.Map);
				view.SetModeDropdown(this.GetAvailableModes(), this._filters.Mode);
				view.SetLatencyDropdown(ServerBrowserController.GetAvaliableLatencies(), LatencyDefinitionData.GetLatency(this._filters.Latency).Latency);
			}
		}

		// Token: 0x06000C73 RID: 3187 RVA: 0x0000A6F9 File Offset: 0x000088F9
		private void UpdateServerBrowser()
		{
			this._remainingTime -= Time.deltaTime;
			if (this._remainingTime > 0f)
			{
				return;
			}
			this.RefreshServerList();
		}

		// Token: 0x06000C74 RID: 3188 RVA: 0x0000A721 File Offset: 0x00008921
		private void OnQuickMatchFinish()
		{
			this._quickMatchIsRunning = false;
			this.OnUpdateListRequest(this._serverService.GetServersFound());
		}

		// Token: 0x06000C75 RID: 3189 RVA: 0x0000A73B File Offset: 0x0000893B
		private void OnQuickMatchStart()
		{
			this._quickMatchIsRunning = true;
			this.OnUpdateListRequest(this._serverService.GetServersFound());
		}

		// Token: 0x06000C76 RID: 3190 RVA: 0x0000A755 File Offset: 0x00008955
		internal void SetOfficials(EServerFilterMode filter)
		{
			this._filters.OfficialsSearchFilterMode = filter;
		}

		// Token: 0x06000C77 RID: 3191 RVA: 0x0000A763 File Offset: 0x00008963
		internal void SetServerName(string name)
		{
			this._filters.Name = name;
		}

		// Token: 0x06000C78 RID: 3192 RVA: 0x0000A771 File Offset: 0x00008971
		internal void SetMap(GameMapConfig map)
		{
			this._filters.Map = map;
		}

		// Token: 0x06000C79 RID: 3193 RVA: 0x0000A77F File Offset: 0x0000897F
		internal void SetMode(EGameMode mode)
		{
			this._filters.Mode = mode;
		}

		// Token: 0x06000C7A RID: 3194 RVA: 0x0000A78D File Offset: 0x0000898D
		internal void SetLatency(ELatency latency)
		{
			this._filters.Latency = latency;
		}

		// Token: 0x06000C7B RID: 3195 RVA: 0x0000A79B File Offset: 0x0000899B
		internal void SetFriendsOnly(bool friendsOnly)
		{
			this._filters.FriendsOnly = friendsOnly;
		}

		// Token: 0x06000C7C RID: 3196 RVA: 0x0000A7A9 File Offset: 0x000089A9
		internal GameMapConfig[] GetAvailableMaps()
		{
			List<GameMapConfig> list = ServiceProvider.GetService<GameMapModeConfigService>().GetAvaliableGameMapConfigList().ToList<GameMapConfig>();
			list.Insert(0, GameMapModeConfigService.DefaultAnyMap);
			return list.ToArray();
		}

		// Token: 0x06000C7D RID: 3197 RVA: 0x0000A7CB File Offset: 0x000089CB
		internal EGameMode[] GetAvailableModes()
		{
			List<EGameMode> list = ServiceProvider.GetService<GameMapModeConfigService>().GetAllPossibleGameModeList().ToList<EGameMode>();
			list.Insert(0, EGameMode.Any);
			return list.ToArray();
		}

		// Token: 0x06000C7E RID: 3198 RVA: 0x0000A7E9 File Offset: 0x000089E9
		private static ELatency[] GetAvaliableLatencies()
		{
			return new ELatency[]
			{
				ELatency.ALL,
				ELatency.EXCELLENT,
				ELatency.GOOD,
				ELatency.AVERAGE,
				ELatency.POOR,
				ELatency.BAD
			};
		}

		// Token: 0x06000C7F RID: 3199 RVA: 0x0000A7FC File Offset: 0x000089FC
		internal void UpdateServerList()
		{
			this._serverService.SetFilterRules(this._filters);
		}

		// Token: 0x06000C80 RID: 3200 RVA: 0x0000A80F File Offset: 0x00008A0F
		internal void RefreshServerList()
		{
			this._remainingTime = 17f;
			this._serverService.SearchServers(this._filters);
		}

		// Token: 0x06000C81 RID: 3201 RVA: 0x00002A31 File Offset: 0x00000C31
		private void OnSearchStarted()
		{
		}

		// Token: 0x06000C82 RID: 3202 RVA: 0x00002A31 File Offset: 0x00000C31
		private void OnSearchCancelled()
		{
		}

		// Token: 0x06000C83 RID: 3203 RVA: 0x00002A31 File Offset: 0x00000C31
		private void OnSearchEnded()
		{
		}

		// Token: 0x06000C84 RID: 3204 RVA: 0x0000A82D File Offset: 0x00008A2D
		private void OnServerFound(HostItem hostItem)
		{
			if (!this._serverService.IsServerValid(hostItem))
			{
				return;
			}
			this._serverService.SortServers();
		}

		// Token: 0x06000C85 RID: 3205 RVA: 0x0004B580 File Offset: 0x00049780
		private void OnUpdateListRequest(List<HostItem> servers)
		{
			ServerBrowserListView view = base.GetView<ServerBrowserListView>();
			if (view != null)
			{
				view.UpdateServers(servers);
			}
			ServerFriendsView view2 = base.GetView<ServerFriendsView>();
			if (view2 != null)
			{
				this._friendServerList.Clear();
				this._clanServerList.Clear();
				foreach (HostItem hostItem in servers)
				{
					foreach (CSteamID csteamID in hostItem.SteamUsers)
					{
						if (SteamFriends.HasFriend(csteamID, 4))
						{
							this._friendServerList.Add(new FriendHostItem
							{
								friend = csteamID,
								hostItem = hostItem
							});
						}
						if (SteamFriends.HasFriend(csteamID, 8))
						{
							this._clanServerList.Add(new FriendHostItem
							{
								friend = csteamID,
								hostItem = hostItem
							});
						}
					}
				}
				if (this._sortFriends)
				{
					this._friendServerList.Sort(new Comparison<FriendHostItem>(this.FriendNameComparer));
					if (!this._sortFriendsAscending)
					{
						this._friendServerList.Reverse();
					}
				}
				if (this._sortClan)
				{
					this._clanServerList.Sort(new Comparison<FriendHostItem>(this.FriendNameComparer));
					if (!this._sortClanAscending)
					{
						this._clanServerList.Reverse();
					}
				}
				view2.UpdateFriends(this._friendServerList, this._clanServerList, this._sortFriends, this._sortClan, this._quickMatchIsRunning);
			}
			ServerFriendJoinView view3 = base.GetView<ServerFriendJoinView>();
			if (view3 != null && view3.isActiveAndEnabled && this._friendHostSelected != null)
			{
				HostItem hostItem2 = servers.Find((HostItem t) => t.SteamId == this._friendHostSelected.SteamId);
				if (hostItem2 != null)
				{
					view3.SetFriendServer(this._friendSelected, hostItem2);
				}
			}
		}

		// Token: 0x06000C86 RID: 3206 RVA: 0x0000A849 File Offset: 0x00008A49
		private int FriendNameComparer(FriendHostItem x, FriendHostItem y)
		{
			return StringComparer.OrdinalIgnoreCase.Compare(SteamFriends.GetPlayerNickname(x.friend), SteamFriends.GetPlayerNickname(y.friend));
		}

		// Token: 0x06000C87 RID: 3207 RVA: 0x0004B768 File Offset: 0x00049968
		internal void SortServers(ESortByCategories category, bool ascOrDesc)
		{
			ISortCategory sortCategory = null;
			switch (category)
			{
			case ESortByCategories.NAME:
				sortCategory = new SortByName();
				break;
			case ESortByCategories.MAP:
				sortCategory = new SortByMap();
				break;
			case ESortByCategories.GAMEMODE:
				sortCategory = new SortByMode();
				break;
			case ESortByCategories.PLAYERS:
				sortCategory = new SortByPlayers();
				break;
			case ESortByCategories.LATENCY:
				sortCategory = new SortByLatency();
				break;
			case ESortByCategories.STATUS:
				sortCategory = new SortByStatus();
				break;
			}
			this._serverService.SetSortCategory(sortCategory, ascOrDesc);
		}

		// Token: 0x06000C88 RID: 3208 RVA: 0x0000A86B File Offset: 0x00008A6B
		internal void Join(HostItem id, EClientMode clientMode)
		{
			ServiceProvider.GetService<WorkshopService>().VerifyHost(id, clientMode, new Action<HostItem, EClientMode>(this.JoinVerified));
		}

		// Token: 0x06000C89 RID: 3209 RVA: 0x0004B7D4 File Offset: 0x000499D4
		private void JoinVerified(HostItem id, EClientMode clientMode)
		{
			if ((clientMode == EClientMode.PLAYER && id.NumPlayers >= id.MaxPlayers) || (clientMode == EClientMode.SPECTATOR && id.NumSpectators >= id.MaxSpectators))
			{
				this._popupService.ShowConnectionFail(LeaveGameMotivation.SERVERFULL);
				return;
			}
			if (id.MaxPing > 0 && (ulong)id.Ping > (ulong)((long)id.MaxPing))
			{
				this._popupService.ShowConnectionFail(LeaveGameMotivation.MAXPING);
				return;
			}
			if (id.Password)
			{
				this._hostItemRequested = id;
				this._clientMode = clientMode;
				this._popupService.Show(EPopupType.PASSWORD_REQUIRED, null, null, new Action<int, string>(this.OnPasswordCallback), 0f);
				return;
			}
			if (id.Status == EServerStatus.DEDICATED || id.Status == EServerStatus.OFFICIAL)
			{
				this.RegisterEvents();
				this._networkGameService.ConnectToServer(id.SteamId, clientMode, null, true);
				return;
			}
			UIManager.Instance.FindController<CustomMatchController>().JoinLobby(id.SteamId, null, clientMode);
		}

		// Token: 0x06000C8A RID: 3210 RVA: 0x0004B8B4 File Offset: 0x00049AB4
		private void OnPasswordCallback(int value, string password)
		{
			if (value != 2)
			{
				this._popupService.Hide(EPopupType.PASSWORD_REQUIRED);
				return;
			}
			if (this._hostItemRequested.Status == EServerStatus.DEDICATED)
			{
				this.RegisterEvents();
				this._networkGameService.ConnectToServer(this._hostItemRequested.SteamId, this._clientMode, Crypto.ComputeMd5Hash(password), true);
				return;
			}
			if (this._hostItemRequested.PasswordData == Crypto.ComputeMd5Hash(password))
			{
				this._popupService.Hide(EPopupType.PASSWORD_REQUIRED);
				UIManager.Instance.FindController<CustomMatchController>().JoinLobby(this._hostItemRequested.SteamId, password, this._clientMode);
				return;
			}
			this._popupService.ShowConnectionFail(LeaveGameMotivation.WRONGPASSWORD);
		}

		// Token: 0x06000C8B RID: 3211 RVA: 0x0000A885 File Offset: 0x00008A85
		private void OnClientConnectionStarted()
		{
			this._popupService.Show(EPopupType.JOINING_MATCH, null, new Action<int>(this.OnPopupCancelJoin), null, 0f);
		}

		// Token: 0x06000C8C RID: 3212 RVA: 0x0000A8A6 File Offset: 0x00008AA6
		private void OnClientConnectionReady()
		{
			this._popupService.Hide(EPopupType.JOINING_MATCH);
			this.ClearEvents();
		}

		// Token: 0x06000C8D RID: 3213 RVA: 0x0000A8BA File Offset: 0x00008ABA
		private void OnClientConnectionFail(LeaveGameMotivation motivation)
		{
			this._popupService.ShowConnectionFail(motivation);
			this.ClearEvents();
		}

		// Token: 0x06000C8E RID: 3214 RVA: 0x0004B960 File Offset: 0x00049B60
		private void RegisterEvents()
		{
			this._networkGameService.OnClientConnectionStarted.AddListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnClientConnectionEstablished.AddListener(new Action(this.OnClientConnectionReady));
			this._networkGameService.OnClientConnectionFail.AddListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
		}

		// Token: 0x06000C8F RID: 3215 RVA: 0x0004B9C4 File Offset: 0x00049BC4
		private void ClearEvents()
		{
			this._networkGameService.OnClientConnectionStarted.RemoveListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnClientConnectionEstablished.RemoveListener(new Action(this.OnClientConnectionReady));
			this._networkGameService.OnClientConnectionFail.RemoveListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
		}

		// Token: 0x06000C90 RID: 3216 RVA: 0x0000A8CE File Offset: 0x00008ACE
		private void OnPopupCancelJoin(int value)
		{
			this.ClearEvents();
			this._networkGameService.DisconnectFromServer();
			UIManager.Instance.DisableLayer(4);
		}

		// Token: 0x06000C91 RID: 3217 RVA: 0x0000A8EC File Offset: 0x00008AEC
		internal void SetFriendServer(CSteamID friend, HostItem hostItem)
		{
			this._friendSelected = friend;
			this._friendHostSelected = hostItem;
			this.RefreshServerList();
		}

		// Token: 0x06000C92 RID: 3218 RVA: 0x0000A902 File Offset: 0x00008B02
		internal void DispatchSortFriends(bool sortFriends, bool sortFriendsAscending, bool sortClan, bool sortClanAscending)
		{
			this._sortFriends = sortFriends;
			this._sortFriendsAscending = sortFriendsAscending;
			this._sortClan = sortClan;
			this._sortClanAscending = sortClanAscending;
			this.OnUpdateListRequest(this._serverService.GetServersFound());
		}

		// Token: 0x04000F79 RID: 3961
		private const float _refreshTime = 17f;

		// Token: 0x04000F7A RID: 3962
		private readonly List<FriendHostItem> _friendServerList = new List<FriendHostItem>();

		// Token: 0x04000F7B RID: 3963
		private readonly List<FriendHostItem> _clanServerList = new List<FriendHostItem>();

		// Token: 0x04000F7C RID: 3964
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000F7D RID: 3965
		private readonly ServerBrowserService _serverService;

		// Token: 0x04000F7E RID: 3966
		private readonly QuickMatchService _quickMatchService;

		// Token: 0x04000F7F RID: 3967
		private readonly PopupService _popupService;

		// Token: 0x04000F80 RID: 3968
		private readonly EventProxy _eventProxy;

		// Token: 0x04000F81 RID: 3969
		private ServerBrowserSearchFilters _filters;

		// Token: 0x04000F82 RID: 3970
		private float _remainingTime;

		// Token: 0x04000F83 RID: 3971
		private HostItem _hostItemRequested;

		// Token: 0x04000F84 RID: 3972
		private EClientMode _clientMode;

		// Token: 0x04000F85 RID: 3973
		private CSteamID _friendSelected;

		// Token: 0x04000F86 RID: 3974
		private HostItem _friendHostSelected;

		// Token: 0x04000F87 RID: 3975
		private bool _sortFriends;

		// Token: 0x04000F88 RID: 3976
		private bool _sortFriendsAscending;

		// Token: 0x04000F89 RID: 3977
		private bool _sortClan;

		// Token: 0x04000F8A RID: 3978
		private bool _sortClanAscending;

		// Token: 0x04000F8B RID: 3979
		private bool _quickMatchIsRunning;
	}
}
