﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C4 RID: 708
	public class InGamePopupLeaderboardsView : BaseView<InGameEndmatchRankingController>
	{
		// Token: 0x06000ED4 RID: 3796 RVA: 0x0000C118 File Offset: 0x0000A318
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
		}

		// Token: 0x040013DC RID: 5084
		public Text MonthText;
	}
}
