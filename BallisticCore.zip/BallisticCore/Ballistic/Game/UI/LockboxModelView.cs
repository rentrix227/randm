﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002E4 RID: 740
	public class LockboxModelView : BaseView<InventoryController>
	{
		// Token: 0x06000F87 RID: 3975 RVA: 0x0000C118 File Offset: 0x0000A318
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
		}

		// Token: 0x06000F88 RID: 3976 RVA: 0x0005C414 File Offset: 0x0005A614
		internal void SetModel(LockboxData lockbox)
		{
			this.UpdateCurrentKey(lockbox);
			if (!this._lockboxCache.ContainsKey(this._currentKey))
			{
				foreach (KeyValuePair<string, GameObject> keyValuePair in this._lockboxCache)
				{
					keyValuePair.Value.SetActive(false);
				}
				this._lockboxCache[this._currentKey] = null;
				ServiceProvider.GetService<EventProxy>().StartCoroutine(this.LoadAsync(this._currentKey, this.Root));
			}
			else
			{
				foreach (KeyValuePair<string, GameObject> keyValuePair2 in this._lockboxCache)
				{
					keyValuePair2.Value.SetActive(this._currentKey == keyValuePair2.Key);
				}
			}
		}

		// Token: 0x06000F89 RID: 3977 RVA: 0x0005C52C File Offset: 0x0005A72C
		private IEnumerator LoadAsync(string modelPath, Transform parent)
		{
			ResourceRequest rqt = Resources.LoadAsync<GameObject>(modelPath);
			while (!rqt.isDone)
			{
				yield return null;
			}
			this._lockboxCache[modelPath] = Object.Instantiate<GameObject>(rqt.asset as GameObject, parent);
			yield break;
		}

		// Token: 0x06000F8A RID: 3978 RVA: 0x0000CC8B File Offset: 0x0000AE8B
		internal void SetData(LockboxData lockbox, WeaponSkinData skinData)
		{
			this.UpdateCurrentKey(lockbox);
			if (!this._lockboxCache.ContainsKey(this._currentKey))
			{
				return;
			}
			this._lockboxCache[this._currentKey].GetComponent<InventoryLockboxModelComponent>().SetData(skinData);
		}

		// Token: 0x06000F8B RID: 3979 RVA: 0x0005C558 File Offset: 0x0005A758
		private void UpdateCurrentKey(LockboxData lockbox)
		{
			ESeason season = lockbox.Lockbox.Season;
			if (season != ESeason.LADDER)
			{
				if (season != ESeason.MSS1)
				{
					this._currentKey = "lockbox_" + lockbox.Lockbox.HeroClass.ToString().ToLowerInvariant();
				}
				else
				{
					this._currentKey = "lockbox_mission";
				}
			}
			else
			{
				this._currentKey = "lockbox_gold";
			}
		}

		// Token: 0x040014B1 RID: 5297
		public Transform Root;

		// Token: 0x040014B2 RID: 5298
		private readonly Dictionary<string, GameObject> _lockboxCache = new Dictionary<string, GameObject>();

		// Token: 0x040014B3 RID: 5299
		private string _currentKey;
	}
}
