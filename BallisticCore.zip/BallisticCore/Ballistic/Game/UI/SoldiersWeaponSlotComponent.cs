﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200020D RID: 525
	public class SoldiersWeaponSlotComponent : MonoBehaviour
	{
		// Token: 0x06000A91 RID: 2705 RVA: 0x000096CB File Offset: 0x000078CB
		public void Start()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._service = ServiceProvider.GetService<SoldiersService>();
			this.Button.onClick.AddListener(new UnityAction(this.OnRequestWeaponChangeClick));
		}

		// Token: 0x06000A92 RID: 2706 RVA: 0x000096FF File Offset: 0x000078FF
		private void OnRequestWeaponChangeClick()
		{
			this._service.RequestWeaponChange(this.Slot);
		}

		// Token: 0x04000E1B RID: 3611
		public Button Button;

		// Token: 0x04000E1C RID: 3612
		public EHeroItemSlot Slot;

		// Token: 0x04000E1D RID: 3613
		private SoldiersService _service;
	}
}
