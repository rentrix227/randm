﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200020B RID: 523
	public class SoldiersWeaponComponent : MonoBehaviour
	{
		// Token: 0x06000A84 RID: 2692 RVA: 0x0003D680 File Offset: 0x0003B880
		internal void SetData(PlayerWeaponData data, PlayerLoadoutV2 loadout)
		{
			if (data == null)
			{
				return;
			}
			WeaponSkin skinForLoadout = data.PlayerItem.GetSkinForLoadout(loadout);
			if (this.WeaponImage != null)
			{
				string weaponIconPath = TextureHelper.GetWeaponIconPath(data.GameItemData.GameItem.ItemModel, EImageSize.SMALL, skinForLoadout.WeaponSkinName);
				TextureHelper.LoadImageAsync(weaponIconPath, this.WeaponImage, true, EImageSource.METADATA);
				TextureHelper.LoadImageAsync(weaponIconPath, this.WeaponShadow, true, EImageSource.METADATA);
			}
			if (this.WeaponNameLabel == null)
			{
				return;
			}
			this.WeaponNameLabel.text = ServiceProvider.GetService<LocalizationService>().GetWeaponName(data.GameItemData.GameItem.ItemName, skinForLoadout.WeaponSkinName, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x06000A85 RID: 2693 RVA: 0x0003D72C File Offset: 0x0003B92C
		internal void SetData(WeaponV4 data, PlayerLoadoutV2 loadout)
		{
			if (data == null)
			{
				return;
			}
			if (this.WeaponImage != null)
			{
				string weaponIconPath = TextureHelper.GetWeaponIconPath(data.ItemModel, EImageSize.SMALL, "default");
				TextureHelper.LoadImageAsync(weaponIconPath, this.WeaponImage, true, EImageSource.METADATA);
				TextureHelper.LoadImageAsync(weaponIconPath, this.WeaponShadow, true, EImageSource.METADATA);
			}
			if (this.WeaponRequirement != null)
			{
				EHeroClass uniqueIdentifier = ServiceProvider.GetService<LoadoutService>().GetLoadout(loadout).GameItem.UniqueIdentifier;
				this.WeaponRequirement.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("requires_level", ELocalizedTextCase.UPPER_CASE), ProgressionData.GetLevelForWeaponUnlock(uniqueIdentifier, data.ItemName));
			}
			if (this.WeaponNameLabel == null)
			{
				return;
			}
			this.WeaponNameLabel.text = ServiceProvider.GetService<LocalizationService>().GetWeaponName(data.ItemName, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x04000E05 RID: 3589
		public RawImage WeaponImage;

		// Token: 0x04000E06 RID: 3590
		public RawImage WeaponShadow;

		// Token: 0x04000E07 RID: 3591
		public Text WeaponNameLabel;

		// Token: 0x04000E08 RID: 3592
		public Text WeaponRequirement;

		// Token: 0x04000E09 RID: 3593
		protected PlayerWeaponData _data;
	}
}
