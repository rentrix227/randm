﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Capture.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200021B RID: 539
	public class GameplayScoreboardController : BaseController
	{
		// Token: 0x06000AF2 RID: 2802 RVA: 0x000404BC File Offset: 0x0003E6BC
		public GameplayScoreboardController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._soldierService = ServiceProvider.GetService<SoldiersService>();
			this._statisticsService = ServiceProvider.GetService<StatisticsService>();
			this._capturePointService = ServiceProvider.GetService<CapturePointService>();
			this._spectatorService = ServiceProvider.GetService<SpectatorService>();
			this._currentMatchService = ServiceProvider.GetService<CurrentMatchService>();
			this._capturePointMode = this._gameModeService.CustomGameMode as ModeCapturePoint;
			this._networkGameService.OnTeamScoreEvent.AddListener(new Action<TeamScoreEvent>(this.OnTeamScoreEvent));
			this._networkGameService.OnCapturedPoint.AddListener(new Action<CapturedPointEvent>(this.OnCapturedPoint));
			this._networkGameService.OnCapturePointUpdate.AddListener(new Action<CapturePointUpdateStateEvent>(this.OnCapturePointUpdate));
			this._networkGameService.OnTeamQueueChanged.AddListener(new Action<TeamQueueChangedEvent>(this.OnTeamQueueChanged));
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnTimeRemaining.AddListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._localCaptures = 0;
			this._localGuardKills = 0;
			this._localGuardTime = 0f;
			this._localMaxKillStreak = 0;
			this._totalDamage = 0f;
			this._includePlayerAtEndOfMfa = false;
			this._includePlayerAtEndOfSmk = false;
		}

		// Token: 0x06000AF3 RID: 2803 RVA: 0x0004063C File Offset: 0x0003E83C
		private void OnUserHit(HitEvent evt)
		{
			if (UserProfile.IsMe(evt.SenderId) && !UserProfile.IsMe(evt.VictimGameClientId))
			{
				this._totalDamage += (float)Mathf.RoundToInt(evt.DeltaLife * 100f);
			}
		}

		// Token: 0x06000AF4 RID: 2804 RVA: 0x00040688 File Offset: 0x0003E888
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnTeamScoreEvent.RemoveListener(new Action<TeamScoreEvent>(this.OnTeamScoreEvent));
			this._networkGameService.OnCapturedPoint.RemoveListener(new Action<CapturedPointEvent>(this.OnCapturedPoint));
			this._networkGameService.OnCapturePointUpdate.RemoveListener(new Action<CapturePointUpdateStateEvent>(this.OnCapturePointUpdate));
			this._networkGameService.OnTeamQueueChanged.RemoveListener(new Action<TeamQueueChangedEvent>(this.OnTeamQueueChanged));
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnTimeRemaining.RemoveListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
		}

		// Token: 0x06000AF5 RID: 2805 RVA: 0x0004076C File Offset: 0x0003E96C
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayScoreboardView gameplayScoreboardView = view as GameplayScoreboardView;
			if (gameplayScoreboardView != null)
			{
				this.UpdateScoreboardView(gameplayScoreboardView);
			}
			GameplayScoreView gameplayScoreView = view as GameplayScoreView;
			if (gameplayScoreView != null)
			{
				this.UpdateScoreView(gameplayScoreView);
			}
			GameplayScoreboardStatsView gameplayScoreboardStatsView = view as GameplayScoreboardStatsView;
			if (gameplayScoreboardStatsView != null)
			{
				this.UpdateStatView(gameplayScoreboardStatsView);
			}
			InGameChooseTeamView inGameChooseTeamView = view as InGameChooseTeamView;
			if (inGameChooseTeamView != null)
			{
				this.UpdateChooseView(inGameChooseTeamView);
			}
		}

		// Token: 0x06000AF6 RID: 2806 RVA: 0x000407F4 File Offset: 0x0003E9F4
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			InGameChooseTeamView inGameChooseTeamView = view as InGameChooseTeamView;
			if (inGameChooseTeamView != null)
			{
				this._includePlayerAtEndOfMfa = false;
				this._includePlayerAtEndOfSmk = false;
			}
		}

		// Token: 0x06000AF7 RID: 2807 RVA: 0x0004082C File Offset: 0x0003EA2C
		private void OnTimeRemaining(TimeRemainingEvent evt)
		{
			GameplayScoreView view = base.GetView<GameplayScoreView>();
			if (view != null && view.isActiveAndEnabled)
			{
				this.UpdateScoreView(view);
			}
		}

		// Token: 0x06000AF8 RID: 2808 RVA: 0x00040860 File Offset: 0x0003EA60
		private void OnTeamScoreEvent(TeamScoreEvent evt)
		{
			GameplayScoreboardView view = base.GetView<GameplayScoreboardView>();
			if (view != null && view.isActiveAndEnabled)
			{
				this.UpdateScoreboardView(view);
			}
			GameplayScoreView view2 = base.GetView<GameplayScoreView>();
			if (view2 != null && view2.isActiveAndEnabled)
			{
				this.UpdateScoreView(view2);
			}
			GameplayScoreboardStatsView view3 = base.GetView<GameplayScoreboardStatsView>();
			if (view3 != null)
			{
				this.UpdateStatView(view3);
			}
			InGameChooseTeamView view4 = base.GetView<InGameChooseTeamView>();
			if (view4 != null)
			{
				this.UpdateChooseView(view4);
			}
		}

		// Token: 0x06000AF9 RID: 2809 RVA: 0x000408EC File Offset: 0x0003EAEC
		internal void ForceUpdateStatsView()
		{
			GameplayScoreboardStatsView view = base.GetView<GameplayScoreboardStatsView>();
			if (view != null)
			{
				this.UpdateStatView(view);
			}
		}

		// Token: 0x06000AFA RID: 2810 RVA: 0x00040914 File Offset: 0x0003EB14
		private void OnTeamQueueChanged(TeamQueueChangedEvent evt)
		{
			InGameChooseTeamView view = base.GetView<InGameChooseTeamView>();
			if (view != null)
			{
				this.UpdateChooseView(view);
			}
		}

		// Token: 0x06000AFB RID: 2811 RVA: 0x0004093C File Offset: 0x0003EB3C
		private void UpdateChooseView(InGameChooseTeamView view)
		{
			if (!view.isActiveAndEnabled)
			{
				return;
			}
			MatchStandingsData matchStandings = this._currentMatchService.GetMatchStandings();
			QueueState queueState = ((UserProfile.LocalGameClient.ClientCommonMetaData.ClientMode != EClientMode.PLAYER || (int)UserProfile.LocalGameClient.ClientCommonMetaData.Team != 1) ? this._gameModeService.MatchIsFull(ETeamMode.MFA) : QueueState.OPEN);
			QueueState queueState2 = ((UserProfile.LocalGameClient.ClientCommonMetaData.ClientMode != EClientMode.PLAYER || (int)UserProfile.LocalGameClient.ClientCommonMetaData.Team != 2) ? this._gameModeService.MatchIsFull(ETeamMode.SMOKE) : QueueState.OPEN);
			view.SetData(UserProfile.LocalGameClient.team, UserProfile.LocalGameClient.requestMode, (matchStandings.YourTeam != Team.MFA) ? matchStandings.EnemyTeamScore : matchStandings.YourTeamScore, queueState, this._gameModeService.GetWaitingForTeam(ETeamMode.MFA, true), (matchStandings.YourTeam != Team.SMOKE) ? matchStandings.EnemyTeamScore : matchStandings.YourTeamScore, queueState2, this._gameModeService.GetWaitingForTeam(ETeamMode.SMOKE, true), this._includePlayerAtEndOfMfa, this._includePlayerAtEndOfSmk, this._networkGameService.GetGameModeMetaData().ClientMetaDataMap);
		}

		// Token: 0x06000AFC RID: 2812 RVA: 0x00040A70 File Offset: 0x0003EC70
		internal void SetChooseViewIncludeData(bool includePlayerAtEndOfMfa, bool includePlayerAtEndOfSmk)
		{
			this._includePlayerAtEndOfMfa = includePlayerAtEndOfMfa;
			this._includePlayerAtEndOfSmk = includePlayerAtEndOfSmk;
			InGameChooseTeamView view = base.GetView<InGameChooseTeamView>();
			if (view != null)
			{
				this.UpdateChooseView(view);
			}
		}

		// Token: 0x06000AFD RID: 2813 RVA: 0x00040AA8 File Offset: 0x0003ECA8
		private void UpdateStatView(GameplayScoreboardStatsView view)
		{
			if (!view.isActiveAndEnabled)
			{
				return;
			}
			view.SetData(UserProfile.LocalGameClient.clientMode, this._gameModeService.GameMode, UserProfile.LocalGameClient.nickname, this._soldierService.GetCurrentClass());
			if (UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR)
			{
				view.SetSpectatorData(this._spectatorService.HasFreeSpawned(), this._spectatorService.GetAutoCycle(), this._spectatorService.GetShowInfo(), this._spectatorService.HasOrbitSpawned());
			}
			switch (this._gameModeService.GameMode)
			{
			case EGameMode.TeamDeathMatch:
				view.TdmUpdateData(this._localMaxKillStreak, this._statisticsService.LocalMatchUserData.KillRatio * 100f, (int)this._totalDamage, this._statisticsService.LocalMatchUserData.KillDeathRatio);
				break;
			case EGameMode.Conquest:
				view.CtpUpdateData(this._localMaxKillStreak, this._localCaptures, this._localGuardKills, this._statisticsService.LocalMatchUserData.KillDeathRatio);
				break;
			case EGameMode.KingOfTheHill:
				view.KothUpdateData(this._localMaxKillStreak, (int)this._localGuardTime, this._localGuardKills, this._statisticsService.LocalMatchUserData.KillDeathRatio);
				break;
			case EGameMode.Rounds:
				view.RoundsUpdateData(this._localMaxKillStreak, this._statisticsService.LocalMatchUserData.KillRatio * 100f, (int)this._totalDamage, this._statisticsService.LocalMatchUserData.KillDeathRatio);
				break;
			case EGameMode.FreeForAll:
				view.FfaUpdateData(this._localMaxKillStreak, this._statisticsService.LocalMatchUserData.KillRatio * 100f, (int)this._totalDamage, this._statisticsService.LocalMatchUserData.KillDeathRatio);
				break;
			case EGameMode.Juggernaut:
				view.JugUpdateData(this._localMaxKillStreak, this._statisticsService.LocalMatchUserData.KillRatio * 100f, (int)this._totalDamage, this._statisticsService.LocalMatchUserData.KillDeathRatio);
				break;
			}
		}

		// Token: 0x06000AFE RID: 2814 RVA: 0x00040CB8 File Offset: 0x0003EEB8
		private void UpdateScoreView(GameplayScoreView view)
		{
			if (!view.isActiveAndEnabled)
			{
				return;
			}
			MatchStandingsData matchStandings = this._currentMatchService.GetMatchStandings();
			view.SetGameMode(this._gameModeService.GameMode);
			switch (this._gameModeService.GameMode)
			{
			case EGameMode.TeamDeathMatch:
				view.TdmUpdateData(Mathf.CeilToInt(this._gameModeService.TimeLeft), matchStandings.YourTeamScore, matchStandings.EnemyTeamScore);
				break;
			case EGameMode.Conquest:
			{
				view.CtpUpdateData(Mathf.CeilToInt(this._gameModeService.TimeLeft), matchStandings.YourTeamScore, matchStandings.EnemyTeamScore, matchStandings.MaxTeamScore);
				List<CapturePointService.PointData> pointsData = this._capturePointService.PointsData;
				if (pointsData != null && pointsData.Count > 0)
				{
					view.CtpSetNumberOfCapturePoints(pointsData.Count);
					for (int i = 0; i < pointsData.Count; i++)
					{
						bool flag = this._capturePointMode.IsPlayerCapturingPoint(pointsData[i].PointName);
						view.CtpUpdatePointState(i, pointsData[i].OwnerTeam, pointsData[i].CapturingTeam, pointsData[i].CaptureAmount, pointsData[i].IsProtected, flag);
					}
				}
				break;
			}
			case EGameMode.KingOfTheHill:
				foreach (PointInfo pointInfo in this._networkGameService.GetGameModeMetaData().GameMetaData.PointInfo)
				{
					if (!(pointInfo.PointName != "A"))
					{
						sbyte b = pointInfo.PlayersOnPoint[(sbyte)matchStandings.YourTeam];
						sbyte b2 = pointInfo.PlayersOnPoint[(sbyte)matchStandings.EnemyTeam];
						view.KothUpdateData(Mathf.CeilToInt(this._gameModeService.TimeLeft), matchStandings.YourTeamScore, matchStandings.EnemyTeamScore, (int)b, (int)b2, matchStandings.MaxTeamScore);
						break;
					}
				}
				break;
			case EGameMode.Rounds:
				view.RoundsUpdateData(this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType, Mathf.CeilToInt(this._gameModeService.TimeLeft), matchStandings.YourTeamWins, matchStandings.EnemyTeamWins);
				view.RoundsUpdateTeams(matchStandings.YourPlayerData, matchStandings.EnemyPlayerData);
				break;
			case EGameMode.FreeForAll:
				view.FfaUpdateData(Mathf.CeilToInt(this._gameModeService.TimeLeft), matchStandings.PlayerRanking, matchStandings.YourPlayerData.Length);
				break;
			case EGameMode.Juggernaut:
				view.JugUpdateData(Mathf.CeilToInt(this._gameModeService.TimeLeft), matchStandings.PlayerRanking, matchStandings.YourPlayerData.Length);
				break;
			}
		}

		// Token: 0x06000AFF RID: 2815 RVA: 0x00040FA4 File Offset: 0x0003F1A4
		private void UpdateScoreboardView(GameplayScoreboardView view)
		{
			if (!view.isActiveAndEnabled)
			{
				return;
			}
			MatchStandingsData matchStandings = this._currentMatchService.GetMatchStandings();
			view.SetGameMode(this._gameModeService.GameMode);
			switch (this._gameModeService.GameMode)
			{
			case EGameMode.TeamDeathMatch:
				view.TdmUpdateData(UserProfile.LocalGameClient.clientMode, matchStandings.WinningTeam, matchStandings.YourTeam, matchStandings.EnemyTeam, matchStandings.YourTeamScore, matchStandings.EnemyTeamScore);
				break;
			case EGameMode.Conquest:
			{
				int num = 0;
				int num2 = 0;
				List<CapturePointService.PointData> pointsData = this._capturePointService.PointsData;
				if (pointsData != null && pointsData.Count > 0)
				{
					view.CtpSetNumberOfCapturePoints(pointsData.Count);
					for (int i = 0; i < pointsData.Count; i++)
					{
						bool flag = this._capturePointMode.IsPlayerCapturingPoint(pointsData[i].PointName);
						view.CtpUpdatePointState(i, pointsData[i].OwnerTeam, pointsData[i].CapturingTeam, pointsData[i].CaptureAmount, pointsData[i].IsProtected, flag);
						if (pointsData[i].OwnerTeam == UITeam.Mine)
						{
							num++;
						}
						else if (pointsData[i].OwnerTeam == UITeam.Other)
						{
							num2++;
						}
					}
				}
				view.CtpUpdateData(UserProfile.LocalGameClient.clientMode, matchStandings.WinningTeam, matchStandings.YourTeam, matchStandings.EnemyTeam, matchStandings.YourTeamScore, matchStandings.EnemyTeamScore, matchStandings.MaxTeamScore, num, num2);
				break;
			}
			case EGameMode.KingOfTheHill:
				foreach (PointInfo pointInfo in this._networkGameService.GetGameModeMetaData().GameMetaData.PointInfo)
				{
					if (!(pointInfo.PointName != "A"))
					{
						sbyte b = pointInfo.PlayersOnPoint[(sbyte)matchStandings.YourTeam];
						sbyte b2 = pointInfo.PlayersOnPoint[(sbyte)matchStandings.EnemyTeam];
						view.KothUpdateData(UserProfile.LocalGameClient.clientMode, matchStandings.WinningTeam, matchStandings.YourTeam, matchStandings.EnemyTeam, matchStandings.YourTeamScore, matchStandings.EnemyTeamScore, (int)b, (int)b2, matchStandings.MaxTeamScore);
						break;
					}
				}
				break;
			case EGameMode.Rounds:
				view.RoundsUpdateData(UserProfile.LocalGameClient.clientMode, matchStandings.WinningTeam, matchStandings.YourTeam, matchStandings.EnemyTeam, this._networkGameService.GetGameModeMetaData().GameMetaData.CurrentRound, matchStandings.YourTeamScore, matchStandings.EnemyTeamScore, matchStandings.YourTeamWins, matchStandings.EnemyTeamWins);
				view.RoundsUpdateTeams(matchStandings.YourPlayerData, matchStandings.EnemyPlayerData);
				break;
			case EGameMode.FreeForAll:
				view.FfaUpdateData(UserProfile.LocalGameClient.clientMode, matchStandings.PlayerRanking);
				break;
			case EGameMode.Juggernaut:
				view.FfaUpdateData(UserProfile.LocalGameClient.clientMode, matchStandings.PlayerRanking);
				break;
			}
			EGameMode gameMode = this._gameModeService.GameMode;
			if (gameMode != EGameMode.Juggernaut && gameMode != EGameMode.FreeForAll)
			{
				view.UpdateYourTeamList(this._gameModeService.GameMode, matchStandings.YourPlayerData, UserProfile.LocalGameClient.clientMode, this._spectatorService.GetCurrentUser());
				view.UpdateEnemyTeamList(this._gameModeService.GameMode, matchStandings.EnemyPlayerData, UserProfile.LocalGameClient.clientMode, this._spectatorService.GetCurrentUser());
			}
			else
			{
				view.UpdateYourTeamList(this._gameModeService.GameMode, matchStandings.YourPlayerData, UserProfile.LocalGameClient.clientMode, this._spectatorService.GetCurrentUser());
			}
		}

		// Token: 0x06000B00 RID: 2816 RVA: 0x000413AC File Offset: 0x0003F5AC
		private void OnDie(DieEvent dieEvent)
		{
			if (UserProfile.IsMe(dieEvent.KillerId) && !UserProfile.IsMe(dieEvent.SenderId))
			{
				if (dieEvent.KillerKillStreak > this._localMaxKillStreak)
				{
					this._localMaxKillStreak = dieEvent.KillerKillStreak;
				}
				if (dieEvent.DefenseKill || dieEvent.OffensiveKill)
				{
					this._localGuardKills++;
				}
			}
		}

		// Token: 0x06000B01 RID: 2817 RVA: 0x0004141C File Offset: 0x0003F61C
		private void OnCapturePointUpdate(CapturePointUpdateStateEvent evt)
		{
			if (this._gameModeService.GameMode != EGameMode.KingOfTheHill)
			{
				return;
			}
			for (int i = 0; i < evt.StandingPlayers.Count; i++)
			{
				if (evt.StandingPlayers[i] == UserProfile.LocalGameClient.gameClientId)
				{
					this._localGuardTime += 0.5f * (float)evt.StandingScoreChanges[i] / 1f;
				}
			}
		}

		// Token: 0x06000B02 RID: 2818 RVA: 0x00009B01 File Offset: 0x00007D01
		private void OnCapturedPoint(CapturedPointEvent evt)
		{
			if (this._gameModeService.GameMode != EGameMode.Conquest)
			{
				return;
			}
			this._localCaptures++;
		}

		// Token: 0x06000B03 RID: 2819 RVA: 0x00009B23 File Offset: 0x00007D23
		internal void DispatchSpectatorFreeCamera()
		{
			this._spectatorService.SpawnFreeCamFromCutCamera();
		}

		// Token: 0x06000B04 RID: 2820 RVA: 0x00009B30 File Offset: 0x00007D30
		internal void DispatchSpectatorOrbit(long user)
		{
			this._spectatorService.SpawnOrbitSpectator(user);
		}

		// Token: 0x06000B05 RID: 2821 RVA: 0x00009B3F File Offset: 0x00007D3F
		internal void SetSpectatorShowInfo(bool value)
		{
			this._spectatorService.SetShowInfo(value);
		}

		// Token: 0x06000B06 RID: 2822 RVA: 0x00009B4D File Offset: 0x00007D4D
		internal void SetSpectatorAutoCycle(bool value)
		{
			this._spectatorService.SetAutoCycle(value);
		}

		// Token: 0x06000B07 RID: 2823 RVA: 0x00009B5B File Offset: 0x00007D5B
		internal void SpectatorCycleNext()
		{
			this._spectatorService.CycleNext();
		}

		// Token: 0x06000B08 RID: 2824 RVA: 0x00009B68 File Offset: 0x00007D68
		internal void SpectatorCyclePrevious()
		{
			this._spectatorService.CyclePrevious();
		}

		// Token: 0x06000B09 RID: 2825 RVA: 0x00041498 File Offset: 0x0003F698
		internal void DispatchRequestMode(ETeamMode teamMode)
		{
			UserProfile.LocalGameClient.ClientCommonMetaData.Team = (sbyte)teamMode;
			UserProfile.LocalGameClient.ClientCommonMetaData.RequestMode = teamMode;
			SelectTeamRequest selectTeamRequest = new SelectTeamRequest
			{
				RequestedTeam = teamMode
			};
			this._networkGameService.RaiseNetworkEvent(selectTeamRequest);
		}

		// Token: 0x04000E71 RID: 3697
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E72 RID: 3698
		private readonly GameModeService _gameModeService;

		// Token: 0x04000E73 RID: 3699
		private readonly CurrentMatchService _currentMatchService;

		// Token: 0x04000E74 RID: 3700
		private readonly SoldiersService _soldierService;

		// Token: 0x04000E75 RID: 3701
		private readonly StatisticsService _statisticsService;

		// Token: 0x04000E76 RID: 3702
		private readonly CapturePointService _capturePointService;

		// Token: 0x04000E77 RID: 3703
		private readonly SpectatorService _spectatorService;

		// Token: 0x04000E78 RID: 3704
		private readonly ModeCapturePoint _capturePointMode;

		// Token: 0x04000E79 RID: 3705
		private int _localGuardKills;

		// Token: 0x04000E7A RID: 3706
		private float _localGuardTime;

		// Token: 0x04000E7B RID: 3707
		private int _localCaptures;

		// Token: 0x04000E7C RID: 3708
		private int _localMaxKillStreak;

		// Token: 0x04000E7D RID: 3709
		private float _totalDamage;

		// Token: 0x04000E7E RID: 3710
		private bool _includePlayerAtEndOfMfa;

		// Token: 0x04000E7F RID: 3711
		private bool _includePlayerAtEndOfSmk;
	}
}
