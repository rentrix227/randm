﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001FD RID: 509
	public class RespawnQueuePlayerComponent : PoolableComponent
	{
		// Token: 0x06000A3D RID: 2621 RVA: 0x00008592 File Offset: 0x00006792
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
		}

		// Token: 0x06000A3E RID: 2622 RVA: 0x0003C2F0 File Offset: 0x0003A4F0
		internal void SetData(int number, ClientCommonMetaData metaData, bool isActive, bool isFriend)
		{
			this._isPlayer = isActive;
			this._isFriend = isFriend;
			if (this.PlayerNumber != null)
			{
				this.PlayerNumber.text = number.ToString();
			}
			if (this.PlayerLevel != null)
			{
				if (metaData.Levels.ContainsKey(0))
				{
					this.PlayerLevel.text = metaData.Levels[0].ToString();
				}
				else
				{
					this.PlayerLevel.text = "0";
				}
			}
			if (this.PlayerBadge != null)
			{
				EPlayerRank eplayerRank = EPlayerRank.ASPIRANT;
				if (metaData.Levels.ContainsKey(0))
				{
					eplayerRank = ProgressionData.GetPlayerRankForLevel((int)metaData.Levels[0]);
				}
				int num = Mathf.Clamp((int)eplayerRank, 0, this.PlayerBadgeSprites.Length - 1);
				this.PlayerBadge.sprite = this.PlayerBadgeSprites[num];
			}
			if (this.NextPlayer != null && this.NextPlayer.activeSelf != (number == 1))
			{
				this.NextPlayer.SetActive(number == 1);
			}
			if (this.PlayerName != null)
			{
				this.PlayerName.text = metaData.Nickname;
			}
		}

		// Token: 0x06000A3F RID: 2623 RVA: 0x000092A5 File Offset: 0x000074A5
		public void Update()
		{
			if (this.Animator.isInitialized)
			{
				this.Animator.SetBool(RespawnQueuePlayerComponent._anim_hash_isPlayer, this._isPlayer);
				this.Animator.SetBool(RespawnQueuePlayerComponent._anim_hash_isFriend, this._isFriend);
			}
		}

		// Token: 0x04000D98 RID: 3480
		private static readonly int _anim_hash_isPlayer = Animator.StringToHash("isPlayer");

		// Token: 0x04000D99 RID: 3481
		private static readonly int _anim_hash_isFriend = Animator.StringToHash("isFriend");

		// Token: 0x04000D9A RID: 3482
		public Text PlayerNumber;

		// Token: 0x04000D9B RID: 3483
		public GameObject NextPlayer;

		// Token: 0x04000D9C RID: 3484
		public Text PlayerLevel;

		// Token: 0x04000D9D RID: 3485
		public Image PlayerBadge;

		// Token: 0x04000D9E RID: 3486
		public Text PlayerName;

		// Token: 0x04000D9F RID: 3487
		public Sprite[] PlayerBadgeSprites;

		// Token: 0x04000DA0 RID: 3488
		public Animator Animator;

		// Token: 0x04000DA1 RID: 3489
		private bool _isPlayer;

		// Token: 0x04000DA2 RID: 3490
		private bool _isFriend;
	}
}
