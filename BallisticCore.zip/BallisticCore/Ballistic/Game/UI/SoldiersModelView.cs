﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000317 RID: 791
	public class SoldiersModelView : BaseView<SoldiersController>
	{
		// Token: 0x060010B8 RID: 4280 RVA: 0x00060B00 File Offset: 0x0005ED00
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				HeroSkin heroSkin = new HeroSkin
				{
					ItemName = "berserker_default",
					ItemModel = "berserker_default"
				};
				Dictionary<EHeroItemSlot, Accessory> dictionary = new Dictionary<EHeroItemSlot, Accessory>();
				Accessory accessory = new Accessory
				{
					ItemId = 130,
					ItemName = "accessory_default",
					ItemModel = "accessory_default",
					AccessorySteamId = 0,
					AccountLevel = 0
				};
				dictionary[EHeroItemSlot.AccessoryHead] = accessory;
				dictionary[EHeroItemSlot.AccessoryChest] = accessory;
				dictionary[EHeroItemSlot.AccessoryPelvis] = accessory;
				dictionary[EHeroItemSlot.AccessoryBack] = accessory;
				dictionary[EHeroItemSlot.AccessoryFeet] = accessory;
				this.SetStartModel(heroSkin, dictionary);
			}
		}

		// Token: 0x060010B9 RID: 4281 RVA: 0x0000DD63 File Offset: 0x0000BF63
		internal void SetStartModel(HeroSkin heroClass, Dictionary<EHeroItemSlot, Accessory> accessories)
		{
			this.SetModel(heroClass, accessories);
			this.ChangeDataComplete();
		}

		// Token: 0x060010BA RID: 4282 RVA: 0x00060BB4 File Offset: 0x0005EDB4
		internal void SetModel(HeroSkin heroClass, Dictionary<EHeroItemSlot, Accessory> accessories)
		{
			this._currentHeroClass = heroClass;
			if (!this._characterLib.ContainsKey(heroClass.ItemName))
			{
				for (int i = 0; i < this.HeroModels.Length; i++)
				{
					if (string.Equals(this.HeroModels[i].name, heroClass.ItemName))
					{
						ServiceProvider.GetService<EventProxy>().StartCoroutine(this.LoadModelAsync(heroClass.ItemName, this.HeroModels[i].transform));
						break;
					}
				}
			}
			if (!this._accessoryLib.ContainsKey(heroClass.ItemName))
			{
				this._accessoryLib[heroClass.ItemName] = new Dictionary<string, GameObject>();
			}
			this._accessoryModels.Clear();
			foreach (KeyValuePair<EHeroItemSlot, Accessory> keyValuePair in accessories)
			{
				if (!keyValuePair.Value.IsDefaultAccessory)
				{
					this._accessoryModels.AddRange(keyValuePair.Value.ItemModel.Split(new char[] { ';' }));
				}
			}
			foreach (string text in this._accessoryModels)
			{
				if (!this._accessoryLib[heroClass.ItemName].ContainsKey(text))
				{
					for (int j = 0; j < this.HeroModels.Length; j++)
					{
						if (string.Equals(this.HeroModels[j].name, heroClass.ItemName))
						{
							ServiceProvider.GetService<EventProxy>().StartCoroutine(this.LoadAccessoryAsync(heroClass.ItemName, text));
							break;
						}
					}
				}
			}
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x0000DD73 File Offset: 0x0000BF73
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			ServiceProvider.GetService<EventProxy>().StartCoroutine(this.Sync());
		}

		// Token: 0x060010BC RID: 4284 RVA: 0x00060DB0 File Offset: 0x0005EFB0
		private IEnumerator Sync()
		{
			while (this._lockState > 0)
			{
				yield return null;
			}
			for (int i = 0; i < this.HeroModels.Length; i++)
			{
				bool flag = string.Equals(this.HeroModels[i].name, this._currentHeroClass.ItemName);
				this.HeroModels[i].SetActive(flag);
				if (flag)
				{
					foreach (KeyValuePair<string, Dictionary<string, GameObject>> keyValuePair in this._accessoryLib)
					{
						foreach (KeyValuePair<string, GameObject> keyValuePair2 in keyValuePair.Value)
						{
							this._accessoryLib[keyValuePair.Key][keyValuePair2.Key].SetActive(this._accessoryModels.Contains(keyValuePair2.Key));
						}
					}
				}
			}
			yield break;
		}

		// Token: 0x060010BD RID: 4285 RVA: 0x00060DCC File Offset: 0x0005EFCC
		private IEnumerator LoadModelAsync(string model, Transform parent)
		{
			this._lockState++;
			this._characterLib[model] = null;
			ResourceRequest rqt = Resources.LoadAsync<GameObject>(model + "_high");
			while (!rqt.isDone)
			{
				yield return null;
			}
			GameObject go = Object.Instantiate<GameObject>(rqt.asset as GameObject);
			go.transform.SetParent(parent, false);
			this._characterLib[model] = go;
			this._lockState--;
			yield break;
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x00060DF8 File Offset: 0x0005EFF8
		private IEnumerator LoadAccessoryAsync(string model, string accessory)
		{
			this._lockState++;
			this._accessoryLib[model][accessory] = null;
			while (this._characterLib[model] == null)
			{
				yield return null;
			}
			Transform parent = SoldiersModelView.RecursiveSearch(accessory, this._characterLib[model].transform);
			if (parent == null)
			{
				Debug.LogError(string.Concat(new string[] { "Could not find accessory[", accessory, "] root on character [", model, "]" }));
			}
			ResourceRequest rqt = Resources.LoadAsync<GameObject>("accessories/" + accessory);
			while (!rqt.isDone)
			{
				yield return null;
			}
			GameObject go = Object.Instantiate<GameObject>(rqt.asset as GameObject);
			go.transform.SetParent(parent, false);
			this._accessoryLib[model][accessory] = go;
			this._lockState--;
			yield break;
		}

		// Token: 0x060010BF RID: 4287 RVA: 0x00060E24 File Offset: 0x0005F024
		private static Transform RecursiveSearch(string parentName, Transform root)
		{
			if (root.name == parentName)
			{
				return root;
			}
			for (int i = 0; i < root.childCount; i++)
			{
				Transform transform = SoldiersModelView.RecursiveSearch(parentName, root.GetChild(i));
				if (transform != null)
				{
					return transform;
				}
			}
			return null;
		}

		// Token: 0x040015F0 RID: 5616
		public GameObject[] HeroModels;

		// Token: 0x040015F1 RID: 5617
		private HeroSkin _currentHeroClass;

		// Token: 0x040015F2 RID: 5618
		private readonly Dictionary<string, GameObject> _characterLib = new Dictionary<string, GameObject>();

		// Token: 0x040015F3 RID: 5619
		private readonly Dictionary<string, Dictionary<string, GameObject>> _accessoryLib = new Dictionary<string, Dictionary<string, GameObject>>();

		// Token: 0x040015F4 RID: 5620
		private readonly List<string> _accessoryModels = new List<string>();

		// Token: 0x040015F5 RID: 5621
		private int _lockState;
	}
}
