﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D5 RID: 469
	public class InventoryAccessoryRequirementComponent : PoolableComponent
	{
		// Token: 0x060009AA RID: 2474 RVA: 0x0003A0B4 File Offset: 0x000382B4
		internal void SetData(RequirementConfig requirement)
		{
			this._type = requirement.Type;
			this.SkinRoot.SetActive(requirement.Type == ERequirementType.SPECIFIC);
			this.CollectionRoot.SetActive(requirement.Type == ERequirementType.COLLECTION);
			if (requirement.Type == ERequirementType.SPECIFIC)
			{
				this._isCompleted = requirement.SpecificCompleted;
				WeaponSkinData weaponSkinData = new WeaponSkinData
				{
					Weapon = requirement.SpecificWeapon,
					WeaponSkin = requirement.SpecificSkin
				};
				this.SkinComponent.SetData(weaponSkinData, false, false);
			}
			else if (requirement.Type == ERequirementType.COLLECTION)
			{
				this.CollectionNameText.text = ServiceProvider.GetService<LocalizationService>().GetWeaponSkinName(requirement.CollectionWeaponSkinName, ELocalizedTextCase.NONE);
				this.CollectionAmountText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("collection_needed", ELocalizedTextCase.NONE), requirement.CollectionAmountRemaining);
				Color rarityColor = RarityHelper.GetRarityColor(WeaponSkin.GetSkinRarity(requirement.CollectionWeaponSkinName));
				this.CollectionColor.color = rarityColor;
				this.CollectionGlor.color = rarityColor;
			}
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x00008B3C File Offset: 0x00006D3C
		public void Update()
		{
			if (this._type == ERequirementType.SPECIFIC)
			{
				this.SkinAnimator.SetBool(InventoryAccessoryRequirementComponent._isAvailableHash, this._isCompleted);
			}
		}

		// Token: 0x04000CD6 RID: 3286
		private static readonly int _isAvailableHash = Animator.StringToHash("isAvailable");

		// Token: 0x04000CD7 RID: 3287
		public GameObject SkinRoot;

		// Token: 0x04000CD8 RID: 3288
		public Animator SkinAnimator;

		// Token: 0x04000CD9 RID: 3289
		public WeaponSkinComponent SkinComponent;

		// Token: 0x04000CDA RID: 3290
		public GameObject CollectionRoot;

		// Token: 0x04000CDB RID: 3291
		public Text CollectionNameText;

		// Token: 0x04000CDC RID: 3292
		public Text CollectionAmountText;

		// Token: 0x04000CDD RID: 3293
		public Image CollectionColor;

		// Token: 0x04000CDE RID: 3294
		public Image CollectionGlor;

		// Token: 0x04000CDF RID: 3295
		private bool _isCompleted;

		// Token: 0x04000CE0 RID: 3296
		private ERequirementType _type;
	}
}
