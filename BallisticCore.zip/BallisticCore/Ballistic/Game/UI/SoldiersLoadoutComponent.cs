﻿using System;
using System.Collections.Generic;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000206 RID: 518
	public class SoldiersLoadoutComponent : PoolableComponent
	{
		// Token: 0x06000A72 RID: 2674 RVA: 0x0003D0B4 File Offset: 0x0003B2B4
		internal void UpdateLoadoutInfo(string loadoutName, HeroSkin heroClass, Accessory accessory, Dictionary<EHeroItemSlot, PlayerWeaponData> loadoutData, PlayerLoadoutV2 loadout, HeroSkillData skill1, HeroSkillData skill2)
		{
			if (this.LoadoutNameText != null)
			{
				this.LoadoutNameText.text = loadoutName;
			}
			if (this.LoadoutNumberText != null)
			{
				this.LoadoutNumberText.text = loadout.Number.ToString();
			}
			if (this.PrimaryWeapon != null)
			{
				this.PrimaryWeapon.SetData(loadoutData[EHeroItemSlot.PrimaryWeapon], loadout);
			}
			if (this.SecondaryWeapon != null)
			{
				this.SecondaryWeapon.SetData(loadoutData[EHeroItemSlot.SecondaryWeapon], loadout);
			}
			if (this.MeleeWeapon != null)
			{
				this.MeleeWeapon.SetData(loadoutData[EHeroItemSlot.MeleeWeapon], loadout);
			}
			if (this.ExplosiveWeapon != null)
			{
				this.ExplosiveWeapon.SetData(loadoutData[EHeroItemSlot.Explosive], loadout);
			}
			if (this.LoadoutSkin != null)
			{
				this.LoadoutSkin.SetData(heroClass);
			}
			if (this.SkillComponent1 != null)
			{
				this.SkillComponent1.SetData(skill1, false, true, -1);
			}
			if (this.SkillComponent2 != null)
			{
				this.SkillComponent2.SetData(skill2, false, true, -1);
			}
			if (this.PrimaryWeaponInfo != null)
			{
				this.PrimaryWeaponInfo.SetData(loadoutData[EHeroItemSlot.PrimaryWeapon], loadout);
			}
			if (this.SecondaryWeaponInfo != null)
			{
				this.SecondaryWeaponInfo.SetData(loadoutData[EHeroItemSlot.SecondaryWeapon], loadout);
			}
			if (this.AccessoryComponent != null)
			{
				this.AccessoryComponent.gameObject.SetActive(false);
			}
		}

		// Token: 0x04000DE2 RID: 3554
		public Text LoadoutNameText;

		// Token: 0x04000DE3 RID: 3555
		public Text LoadoutNumberText;

		// Token: 0x04000DE4 RID: 3556
		public SoldiersWeaponComponent PrimaryWeapon;

		// Token: 0x04000DE5 RID: 3557
		public SoldiersWeaponComponent SecondaryWeapon;

		// Token: 0x04000DE6 RID: 3558
		public SoldiersWeaponComponent MeleeWeapon;

		// Token: 0x04000DE7 RID: 3559
		public SoldiersWeaponComponent ExplosiveWeapon;

		// Token: 0x04000DE8 RID: 3560
		public SoldiersSkinLoadoutComponent LoadoutSkin;

		// Token: 0x04000DE9 RID: 3561
		public SoldiersSkillComponent SkillComponent1;

		// Token: 0x04000DEA RID: 3562
		public SoldiersSkillComponent SkillComponent2;

		// Token: 0x04000DEB RID: 3563
		public SoldiersWeaponInfoComponent PrimaryWeaponInfo;

		// Token: 0x04000DEC RID: 3564
		public SoldiersWeaponInfoComponent SecondaryWeaponInfo;

		// Token: 0x04000DED RID: 3565
		public SoldiersAccessoryComponent AccessoryComponent;
	}
}
