﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000316 RID: 790
	public class SoldiersLoadoutsView : BaseView<SoldiersController>
	{
		// Token: 0x060010B0 RID: 4272 RVA: 0x00060978 File Offset: 0x0005EB78
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Toggles[0].onValueChanged.AddListener(new UnityAction<bool>(this.OnLoadoutClickedOne));
			this.Toggles[1].onValueChanged.AddListener(new UnityAction<bool>(this.OnLoadoutClickedTwo));
			this.Toggles[2].onValueChanged.AddListener(new UnityAction<bool>(this.OnLoadoutClickedThree));
		}

		// Token: 0x060010B1 RID: 4273 RVA: 0x0000DC62 File Offset: 0x0000BE62
		private void OnLoadoutClickedOne(bool value)
		{
			if (!value || this._isSetting || this._loadoutSelected == 0)
			{
				return;
			}
			base._controller.DispatchLoadoutChanged(this._loadouts[0]);
		}

		// Token: 0x060010B2 RID: 4274 RVA: 0x0000DC98 File Offset: 0x0000BE98
		private void OnLoadoutClickedTwo(bool value)
		{
			if (!value || this._isSetting || this._loadoutSelected == 1)
			{
				return;
			}
			base._controller.DispatchLoadoutChanged(this._loadouts[1]);
		}

		// Token: 0x060010B3 RID: 4275 RVA: 0x0000DCCF File Offset: 0x0000BECF
		private void OnLoadoutClickedThree(bool value)
		{
			if (!value || this._isSetting || this._loadoutSelected == 2)
			{
				return;
			}
			base._controller.DispatchLoadoutChanged(this._loadouts[2]);
		}

		// Token: 0x060010B4 RID: 4276 RVA: 0x000609F0 File Offset: 0x0005EBF0
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._isSetting = true;
			int num = 0;
			while (num < this.LoadoutComponents.Length && num < this._loadouts.Count)
			{
				this.LoadoutComponents[num].UpdateLoadoutInfo(this._loadouts[num].PlayerItem.ItemName, null, null, this._loadoutInfoList[num], this._loadouts[num].PlayerItem, null, null);
				num++;
			}
			for (int i = 0; i < this.Toggles.Length; i++)
			{
				bool flag = i < this._loadouts.Count;
				if (this.Toggles[i].gameObject.activeSelf != flag)
				{
					this.Toggles[i].gameObject.SetActive(i < this._loadouts.Count);
				}
				if (flag)
				{
					this.Toggles[i].isOn = i == this._loadoutSelected;
				}
			}
			this._isSetting = false;
		}

		// Token: 0x060010B5 RID: 4277 RVA: 0x0000DD06 File Offset: 0x0000BF06
		internal void SetStartAllLoadouts(List<PlayerLoadoutData> loadouts, List<Dictionary<EHeroItemSlot, PlayerWeaponData>> loadoutInfoList, int loadoutIndex)
		{
			this._loadouts = loadouts;
			this._loadoutInfoList = loadoutInfoList;
			this._loadoutSelected = loadoutIndex;
			this.ChangeDataComplete();
		}

		// Token: 0x060010B6 RID: 4278 RVA: 0x0000DD23 File Offset: 0x0000BF23
		internal void SetAllLoadouts(List<PlayerLoadoutData> loadouts, List<Dictionary<EHeroItemSlot, PlayerWeaponData>> loadoutInfoList, int loadoutIndex)
		{
			this._loadouts = loadouts;
			this._loadoutInfoList = loadoutInfoList;
			this._loadoutSelected = loadoutIndex;
		}

		// Token: 0x040015EA RID: 5610
		public Toggle[] Toggles;

		// Token: 0x040015EB RID: 5611
		public SoldiersLoadoutComponent[] LoadoutComponents;

		// Token: 0x040015EC RID: 5612
		private List<PlayerLoadoutData> _loadouts;

		// Token: 0x040015ED RID: 5613
		private List<Dictionary<EHeroItemSlot, PlayerWeaponData>> _loadoutInfoList;

		// Token: 0x040015EE RID: 5614
		private int _loadoutSelected;

		// Token: 0x040015EF RID: 5615
		private bool _isSetting;
	}
}
