﻿using System;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200021A RID: 538
	public class GameplayMapController : BaseController
	{
		// Token: 0x06000AEB RID: 2795 RVA: 0x00040030 File Offset: 0x0003E230
		public GameplayMapController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._remoteCharacterService = ServiceProvider.GetService<RemoteCharactersService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._networkGameService.OnSelectTeamCompleted.AddListener(new Action<SelectTeamCompletedResponse>(this.HandleSelectTeamCompleted));
			this._networkGameService.OnWeaponStationEvent.AddListener(new Action<WeaponStationEvent>(this.HandleWeaponStationEvent));
			this._eventProxy.EUpdate.AddListener(new Action(this.Update));
		}

		// Token: 0x06000AEC RID: 2796 RVA: 0x000400E8 File Offset: 0x0003E2E8
		private void HandleSelectTeamCompleted(SelectTeamCompletedResponse evt)
		{
			GameplayMapView view = base.GetView<GameplayMapView>();
			if (view != null)
			{
				view.RemoveAllRemotePlayers();
			}
		}

		// Token: 0x06000AED RID: 2797 RVA: 0x00040110 File Offset: 0x0003E310
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnSelectTeamCompleted.RemoveListener(new Action<SelectTeamCompletedResponse>(this.HandleSelectTeamCompleted));
			this._networkGameService.OnWeaponStationEvent.RemoveListener(new Action<WeaponStationEvent>(this.HandleWeaponStationEvent));
			this._eventProxy.EUpdate.RemoveListener(new Action(this.Update));
			this._mapView = null;
		}

		// Token: 0x06000AEE RID: 2798 RVA: 0x0004018C File Offset: 0x0003E38C
		private void HandleWeaponStationEvent(WeaponStationEvent evt)
		{
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			if (gameModeMetaData != null)
			{
				for (int i = 0; i < gameModeMetaData.GameMetaData.WeaponInfo.Count; i++)
				{
					this._mapView.SetWeaponPointStatus(i, evt.WeaponStationInfo);
				}
			}
		}

		// Token: 0x06000AEF RID: 2799 RVA: 0x000401E0 File Offset: 0x0003E3E0
		public override void OnShow(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayMapView gameplayMapView = view as GameplayMapView;
			if (gameplayMapView != null)
			{
				this._mapView = gameplayMapView;
				this._mapView.Initialize(ServiceProvider.GetService<GameModeService>().GameMode);
			}
		}

		// Token: 0x06000AF0 RID: 2800 RVA: 0x00009AE2 File Offset: 0x00007CE2
		public override void OnHide(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (view is GameplayScoreView)
			{
				this._mapView = null;
			}
		}

		// Token: 0x06000AF1 RID: 2801 RVA: 0x00040228 File Offset: 0x0003E428
		public void Update()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this._mapView != null)
			{
				this._mapView.SetPlayerData(this._localCharacterService.WorldPosition, this._localCharacterService.WorldRotation * Vector3.forward, this._localCharacterService.IsVisible || (this._gameModeService.GameMode == EGameMode.Juggernaut && UserProfile.LocalGameClient.team == Team.SMOKE));
				this._mapView.WorldScaleFactor = this._localCharacterService.MinimapScaleFactor;
				for (int i = 0; i < this._activePlayerIds.Length; i++)
				{
					long num = this._activePlayerIds[i];
					if (this._remoteCharacterService.GetCharacterInfo(num) == null)
					{
						this._mapView.RemoveRemotePlayer(num);
					}
				}
				Team team = UserProfile.LocalGameClient.team;
				Team team2 = ((team != Team.MFA) ? Team.MFA : Team.SMOKE);
				this._activePlayerIds.Clear();
				for (int j = 0; j < this._remoteCharacterService.ActivePlayers.Length; j++)
				{
					RemoteCharacterInfo remoteCharacterInfo = this._remoteCharacterService.ActivePlayers[j];
					this._activePlayerIds.Add(remoteCharacterInfo.PlayerId);
					if (remoteCharacterInfo.Team == team)
					{
						this._mapView.SetRemotePlayerData(remoteCharacterInfo.PlayerId, UITeam.Mine, remoteCharacterInfo.WorldPosition, true, false, remoteCharacterInfo.WorldRotation * Vector3.forward);
					}
					else
					{
						bool flag = this._gameModeService.GameMode == EGameMode.Juggernaut && remoteCharacterInfo.Team == Team.SMOKE;
						this._mapView.SetRemotePlayerData(remoteCharacterInfo.PlayerId, UITeam.Other, remoteCharacterInfo.WorldPosition, remoteCharacterInfo.IsVisibleOnRadar || flag, flag, Vector3.zero);
					}
				}
				GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
				if (gameModeMetaData == null)
				{
					return;
				}
				if (gameModeMetaData.GameMetaData.PointInfo == null)
				{
					return;
				}
				for (int k = 0; k < gameModeMetaData.GameMetaData.PointInfo.Count; k++)
				{
					UITeam uiteam = UITeam.None;
					if ((int)gameModeMetaData.GameMetaData.PointInfo[k].CurrentTeamOwner == (int)((sbyte)team))
					{
						uiteam = UITeam.Mine;
					}
					else if ((int)gameModeMetaData.GameMetaData.PointInfo[k].CurrentTeamOwner == (int)((sbyte)team2))
					{
						uiteam = UITeam.Other;
					}
					this._mapView.SetCapturePointStatus(k, uiteam);
				}
			}
		}

		// Token: 0x04000E6A RID: 3690
		private GameplayMapView _mapView;

		// Token: 0x04000E6B RID: 3691
		private readonly LocalCharacterService _localCharacterService;

		// Token: 0x04000E6C RID: 3692
		private readonly RemoteCharactersService _remoteCharacterService;

		// Token: 0x04000E6D RID: 3693
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E6E RID: 3694
		private readonly GameModeService _gameModeService;

		// Token: 0x04000E6F RID: 3695
		private readonly EventProxy _eventProxy;

		// Token: 0x04000E70 RID: 3696
		private readonly HighSpeedArray<long> _activePlayerIds = new HighSpeedArray<long>(60);
	}
}
