﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D8 RID: 472
	public class InventoryAccessorySortComponent : PoolableComponent
	{
		// Token: 0x060009AE RID: 2478 RVA: 0x0003A1C8 File Offset: 0x000383C8
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.RequirementList.Template.Dispose();
			if (this.Button != null)
			{
				this.Button.onClick.AddListener(new UnityAction(this.OnAccessoryClicked));
			}
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x00008B89 File Offset: 0x00006D89
		private void OnAccessoryClicked()
		{
			if (this.OnAccessoryClick != null)
			{
				this.OnAccessoryClick(this._accessory);
			}
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x0003A220 File Offset: 0x00038420
		internal void SetData(Accessory accessory)
		{
			this._accessory = accessory;
			this.Name.text = ServiceProvider.GetService<LocalizationService>().GetAccessoryName(accessory.ItemName);
			this.Description.text = ServiceProvider.GetService<LocalizationService>().GetAcessoryDescription(accessory.ItemName);
			string accessoryIconPath = TextureHelper.GetAccessoryIconPath(accessory.ItemName, EImageSize.SMALL);
			TextureHelper.LoadImageAsync(accessoryIconPath, this.Icon, false, EImageSource.RESOURCES);
			TextureHelper.LoadImageAsync(accessoryIconPath, this.IconFillBar, false, EImageSource.RESOURCES);
			if (accessory.AccountLevel > 0)
			{
				bool flag = ServiceProvider.GetService<ProgressionService>().GetPlayerAccountLevelAcc() < accessory.AccountLevel;
				this.LevelRequiremenText.gameObject.SetActive(flag);
				if (flag)
				{
					this.LevelRequiremenText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("require_level_to_unlock", ELocalizedTextCase.NONE), accessory.AccountLevel);
				}
			}
			else
			{
				this.LevelRequiremenText.gameObject.SetActive(false);
			}
			int num;
			int num2;
			List<RequirementConfig> requirementList = InventoryController.GetRequirementList(accessory, out num, out num2);
			this.RequirementList.SetActiveCount(requirementList.Count);
			for (int i = 0; i < requirementList.Count; i++)
			{
				this.RequirementList[i].SetData(requirementList[i]);
			}
			this.CompletionAmountText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("collection_progress", ELocalizedTextCase.NONE), num2, num);
			this._isCompleted = num2 == num;
			this.IconFillBar.fillAmount = ((num <= 0) ? 1f : ((float)num2 / (float)num));
			this.IconRingBar.fillAmount = ((num <= 0) ? 1f : ((float)num2 / (float)num));
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x00008BA7 File Offset: 0x00006DA7
		public void Update()
		{
			if (this.ButtonAnimator.isInitialized)
			{
				this.ButtonAnimator.SetBool(this._animatorHashIsOn, this._isCompleted);
			}
		}

		// Token: 0x04000CEB RID: 3307
		public int _animatorHashIsOn = Animator.StringToHash("isOn");

		// Token: 0x04000CEC RID: 3308
		public Text Name;

		// Token: 0x04000CED RID: 3309
		public Text Description;

		// Token: 0x04000CEE RID: 3310
		public Text CompletionAmountText;

		// Token: 0x04000CEF RID: 3311
		public Button Button;

		// Token: 0x04000CF0 RID: 3312
		public Animator ButtonAnimator;

		// Token: 0x04000CF1 RID: 3313
		public Image Icon;

		// Token: 0x04000CF2 RID: 3314
		public Image IconFillBar;

		// Token: 0x04000CF3 RID: 3315
		public Image IconRingBar;

		// Token: 0x04000CF4 RID: 3316
		public Text LevelRequiremenText;

		// Token: 0x04000CF5 RID: 3317
		public InventoryAccessorySortComponent.InventoryAccessoryRequirementList RequirementList;

		// Token: 0x04000CF6 RID: 3318
		internal Action<Accessory> OnAccessoryClick;

		// Token: 0x04000CF7 RID: 3319
		private Accessory _accessory;

		// Token: 0x04000CF8 RID: 3320
		public bool _isCompleted;

		// Token: 0x020001D9 RID: 473
		[Serializable]
		public class InventoryAccessoryRequirementList : PoolableList<InventoryAccessoryRequirementComponent>
		{
		}
	}
}
