﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000309 RID: 777
	public class SettingsButtonsView : BaseView<SettingsController>
	{
		// Token: 0x0600101A RID: 4122 RVA: 0x0005E384 File Offset: 0x0005C584
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.DiscartButton.onClick.AddListener(new UnityAction(this.OnDiscardChangesClick));
			this.DefaultButton.onClick.AddListener(new UnityAction(this.OnDefaultClick));
			this.SaveButton.onClick.AddListener(new UnityAction(this.OnSaveChangesClick));
		}

		// Token: 0x0600101B RID: 4123 RVA: 0x0000D44A File Offset: 0x0000B64A
		private void OnDiscardChangesClick()
		{
			base._controller.OnDiscard();
		}

		// Token: 0x0600101C RID: 4124 RVA: 0x0000D457 File Offset: 0x0000B657
		private void OnDefaultClick()
		{
			base._controller.OnReset();
		}

		// Token: 0x0600101D RID: 4125 RVA: 0x0000D464 File Offset: 0x0000B664
		private void OnSaveChangesClick()
		{
			base._controller.OnSave();
		}

		// Token: 0x0400154C RID: 5452
		public Button DiscartButton;

		// Token: 0x0400154D RID: 5453
		public Button DefaultButton;

		// Token: 0x0400154E RID: 5454
		public Button SaveButton;
	}
}
