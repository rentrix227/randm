﻿using System;
using System.Diagnostics;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200024C RID: 588
	public class PopupController : BaseController
	{
		// Token: 0x06000C53 RID: 3155 RVA: 0x0004AA98 File Offset: 0x00048C98
		public PopupController()
		{
			this._popupService = ServiceProvider.GetService<PopupService>();
			PopupService popupService = this._popupService;
			popupService.OnPopupDataUpdate = (Action<PopupData>)Delegate.Combine(popupService.OnPopupDataUpdate, new Action<PopupData>(this.OnPopupDataUpdate));
			PopupService popupService2 = this._popupService;
			popupService2.OnUnlockItemPopupDataUpdate = (Action<UnlockItemPopupData>)Delegate.Combine(popupService2.OnUnlockItemPopupDataUpdate, new Action<UnlockItemPopupData>(this.OnUnlockItemPopupDataUpdate));
			PopupService popupService3 = this._popupService;
			popupService3.OnUnlockLockboxDataUpdate = (Action<LockboxData>)Delegate.Combine(popupService3.OnUnlockLockboxDataUpdate, new Action<LockboxData>(this.OnUnlockLockboxDataUpdate));
			PopupService popupService4 = this._popupService;
			popupService4.OnUnlockScrapDataUpdate = (Action<ScrapData>)Delegate.Combine(popupService4.OnUnlockScrapDataUpdate, new Action<ScrapData>(this.OnUnlockScrapDataUpdate));
		}

		// Token: 0x14000027 RID: 39
		// (add) Token: 0x06000C54 RID: 3156 RVA: 0x0004AB54 File Offset: 0x00048D54
		// (remove) Token: 0x06000C55 RID: 3157 RVA: 0x0004AB8C File Offset: 0x00048D8C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action<int> OnButtonClick;

		// Token: 0x14000028 RID: 40
		// (add) Token: 0x06000C56 RID: 3158 RVA: 0x0004ABC4 File Offset: 0x00048DC4
		// (remove) Token: 0x06000C57 RID: 3159 RVA: 0x0004ABFC File Offset: 0x00048DFC
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action<int, string> OnPasswordClick;

		// Token: 0x06000C58 RID: 3160 RVA: 0x0004AC34 File Offset: 0x00048E34
		public override void DisableController()
		{
			base.DisableController();
			PopupService popupService = this._popupService;
			popupService.OnPopupDataUpdate = (Action<PopupData>)Delegate.Remove(popupService.OnPopupDataUpdate, new Action<PopupData>(this.OnPopupDataUpdate));
			PopupService popupService2 = this._popupService;
			popupService2.OnUnlockItemPopupDataUpdate = (Action<UnlockItemPopupData>)Delegate.Remove(popupService2.OnUnlockItemPopupDataUpdate, new Action<UnlockItemPopupData>(this.OnUnlockItemPopupDataUpdate));
			PopupService popupService3 = this._popupService;
			popupService3.OnUnlockLockboxDataUpdate = (Action<LockboxData>)Delegate.Remove(popupService3.OnUnlockLockboxDataUpdate, new Action<LockboxData>(this.OnUnlockLockboxDataUpdate));
			PopupService popupService4 = this._popupService;
			popupService4.OnUnlockScrapDataUpdate = (Action<ScrapData>)Delegate.Remove(popupService4.OnUnlockScrapDataUpdate, new Action<ScrapData>(this.OnUnlockScrapDataUpdate));
		}

		// Token: 0x06000C59 RID: 3161 RVA: 0x0000A624 File Offset: 0x00008824
		public override void OnHide(AbstractView view)
		{
			this.OnButtonClick = null;
		}

		// Token: 0x06000C5A RID: 3162 RVA: 0x0000A62D File Offset: 0x0000882D
		internal void ButtonClick(int button)
		{
			if (this.OnButtonClick != null)
			{
				this.OnButtonClick(button);
			}
		}

		// Token: 0x06000C5B RID: 3163 RVA: 0x0000A646 File Offset: 0x00008846
		internal void PasswordClick(int button, string text)
		{
			if (this.OnPasswordClick != null)
			{
				this.OnPasswordClick(button, text);
			}
		}

		// Token: 0x06000C5C RID: 3164 RVA: 0x0004ACE4 File Offset: 0x00048EE4
		private static bool ViewContainsType(PopupView view, EPopupType type)
		{
			foreach (EPopupType epopupType in view.GetPopupTypes())
			{
				if (type == epopupType)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x0004AD1C File Offset: 0x00048F1C
		private void OnPopupDataUpdate(PopupData data)
		{
			foreach (AbstractView abstractView in this._view)
			{
				PopupView popupView = abstractView as PopupView;
				if (popupView != null)
				{
					if (PopupController.ViewContainsType(popupView, data.Type))
					{
						popupView.UpdateInfo(data);
						this.OnButtonClick = data.ButtonCallback;
						this.OnPasswordClick = data.PasswordCallback;
					}
				}
			}
		}

		// Token: 0x06000C5E RID: 3166 RVA: 0x0004ADBC File Offset: 0x00048FBC
		private void OnUnlockItemPopupDataUpdate(UnlockItemPopupData data)
		{
			foreach (AbstractView abstractView in this._view)
			{
				ItemUnlockPopupView itemUnlockPopupView = abstractView as ItemUnlockPopupView;
				if (itemUnlockPopupView != null)
				{
					itemUnlockPopupView.UpdateInfo(data);
				}
			}
		}

		// Token: 0x06000C5F RID: 3167 RVA: 0x0004AE2C File Offset: 0x0004902C
		private void OnUnlockLockboxDataUpdate(LockboxData lockboxData)
		{
			foreach (AbstractView abstractView in this._view)
			{
				NewLockboxPopupView newLockboxPopupView = abstractView as NewLockboxPopupView;
				if (newLockboxPopupView != null)
				{
					newLockboxPopupView.SetData(lockboxData);
				}
			}
		}

		// Token: 0x06000C60 RID: 3168 RVA: 0x0004AE9C File Offset: 0x0004909C
		private void OnUnlockScrapDataUpdate(ScrapData scrapData)
		{
			foreach (AbstractView abstractView in this._view)
			{
				NewScrapPopupView newScrapPopupView = abstractView as NewScrapPopupView;
				if (newScrapPopupView != null)
				{
					newScrapPopupView.SetData(scrapData);
				}
			}
		}

		// Token: 0x04000F6E RID: 3950
		private readonly PopupService _popupService;
	}
}
