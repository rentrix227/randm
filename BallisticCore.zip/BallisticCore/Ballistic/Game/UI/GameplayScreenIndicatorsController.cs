﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200021C RID: 540
	public class GameplayScreenIndicatorsController : BaseController
	{
		// Token: 0x06000B0A RID: 2826 RVA: 0x000414E4 File Offset: 0x0003F6E4
		public GameplayScreenIndicatorsController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			ServiceProvider.GetService<EventProxy>().EUpdate.AddListener(new Action(this.UpdateView));
			ServiceProvider.GetService<TransmissionService>().OnProjectileEnterPlayerRange.AddListener(new Action<OnProjectileEnterPlayerRangeData>(this.HandleProjectileEnterPlayerRange));
			this._remoteCharacterService = ServiceProvider.GetService<RemoteCharactersService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._capturePointService = ServiceProvider.GetService<CapturePointService>();
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.HandleUserHit));
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.HandleDie));
			this._networkGameService.OnVoiceRequest.AddListener(new Action<VoiceRequest>(this.HandleVoiceRequest));
			this._characterIndicatorsKeys = this._characterIndicators.Keys;
			this._damageIndicatorsKeys = this._damageIndicators.Keys;
		}

		// Token: 0x06000B0B RID: 2827 RVA: 0x00041634 File Offset: 0x0003F834
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			ServiceProvider.GetService<EventProxy>().EUpdate.RemoveListener(new Action(this.UpdateView));
			ServiceProvider.GetService<TransmissionService>().OnProjectileEnterPlayerRange.RemoveListener(new Action<OnProjectileEnterPlayerRangeData>(this.HandleProjectileEnterPlayerRange));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.HandleUserHit));
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.HandleDie));
			this._networkGameService.OnVoiceRequest.RemoveListener(new Action<VoiceRequest>(this.HandleVoiceRequest));
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x000416DC File Offset: 0x0003F8DC
		public override void OnShow(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayScreenIndicatorsView gameplayScreenIndicatorsView = view as GameplayScreenIndicatorsView;
			if (gameplayScreenIndicatorsView != null)
			{
				this._gameplayScreenIndicatorsView = gameplayScreenIndicatorsView;
				if (!this._capturePointsInitialized)
				{
					this.InitializeCapturePoints();
				}
			}
		}

		// Token: 0x06000B0D RID: 2829 RVA: 0x00041720 File Offset: 0x0003F920
		private void InitializeCapturePoints()
		{
			EGameMode gameMode = ServiceProvider.GetService<GameModeService>().GameMode;
			GameObject[] rootGameObjects = SceneManager.GetActiveScene().GetRootGameObjects();
			for (int i = 0; i < rootGameObjects.Length; i++)
			{
				if (rootGameObjects[i].name == "_minimap")
				{
					Transform transform = rootGameObjects[i].transform;
					if (gameMode == EGameMode.Conquest)
					{
						Transform transform2 = transform.Find("modes/capture_point");
						if (transform2 != null)
						{
							for (int j = 0; j < transform2.childCount; j++)
							{
								Transform child = transform2.GetChild(j);
								CapturePointScreenIndicator capturePointScreenIndicator = this._gameplayScreenIndicatorsView.CreateCapturePointIndicator(child.name);
								this._capturePointIndicators.Add(capturePointScreenIndicator);
								this._capturePointWorldPositions.Add(child.position);
							}
						}
					}
					if (gameMode == EGameMode.KingOfTheHill)
					{
						Transform transform3 = transform.Find("modes/king_of_the_hill");
						if (transform3 != null && transform3.childCount > 0)
						{
							Transform child2 = transform3.GetChild(0);
							CapturePointScreenIndicator capturePointScreenIndicator2 = this._gameplayScreenIndicatorsView.CreateCapturePointIndicator("koth");
							this._capturePointIndicators.Add(capturePointScreenIndicator2);
							this._capturePointWorldPositions.Add(child2.position);
						}
					}
				}
			}
			this._capturePointsInitialized = true;
		}

		// Token: 0x06000B0E RID: 2830 RVA: 0x00041868 File Offset: 0x0003FA68
		private void HandleProjectileEnterPlayerRange(OnProjectileEnterPlayerRangeData data)
		{
			if (this._gameplayScreenIndicatorsView == null)
			{
				return;
			}
			GrenadeScreenIndicator grenadeScreenIndicator = this._gameplayScreenIndicatorsView.CreateGrenadeIndicator(data.ProjectileTransform);
			Team team = UserProfile.LocalGameClient.team;
			bool launcherIsLocalCharacter = data.LauncherIsLocalCharacter;
			grenadeScreenIndicator.SetTeam((data.LauncherTeam != team || launcherIsLocalCharacter) ? UITeam.Other : UITeam.Mine);
			this._grenadeIndicators.Add(grenadeScreenIndicator);
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x000418DC File Offset: 0x0003FADC
		private void HandleUserHit(HitEvent hitEvent)
		{
			if (this._gameplayScreenIndicatorsView == null)
			{
				return;
			}
			if (hitEvent.Sender.isMe && !hitEvent.VictimGameClient.isMe)
			{
				long victimGameClientId = hitEvent.VictimGameClientId;
				DamageScreenIndicator damageScreenIndicator;
				if (!this._damageIndicators.TryGetValue(victimGameClientId, out damageScreenIndicator))
				{
					damageScreenIndicator = this._gameplayScreenIndicatorsView.CreateDamageIndicator();
					this._damageIndicators.Add(victimGameClientId, damageScreenIndicator);
				}
				bool flag = hitEvent.WeaponCategory == EWeaponCategory.Shotgun;
				float num = ((!flag) ? 0f : 0.15f);
				DamageAmount damageAmount = DamageAmount.Medium;
				if (hitEvent.DamageType == EDamageType.PROJECTILE_HEAD || hitEvent.DamageType == EDamageType.BACKSTAB || hitEvent.DamageType == EDamageType.HEADSHOT)
				{
					damageAmount = DamageAmount.High;
				}
				else if (hitEvent.BodyPartHit == 9 || hitEvent.BodyPartHit == 8 || hitEvent.BodyPartHit == 7)
				{
					damageAmount = DamageAmount.Low;
				}
				damageScreenIndicator.SpawnDamage(hitEvent.Damage, num, damageAmount);
			}
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x000419D4 File Offset: 0x0003FBD4
		private void HandleDie(DieEvent dieEvent)
		{
			if (this._gameplayScreenIndicatorsView == null)
			{
				return;
			}
			Team team = UserProfile.LocalGameClient.team;
			if (!dieEvent.Sender.isMe && dieEvent.Sender.team == team)
			{
				DeathScreenIndicator deathScreenIndicator = this._gameplayScreenIndicatorsView.CreateDeathIndicator(dieEvent.Sender.nicknamePlainText);
				this._deathIndicators.Add(deathScreenIndicator, dieEvent.VictimPosition);
			}
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x00041A48 File Offset: 0x0003FC48
		private void HandleVoiceRequest(VoiceRequest evt)
		{
			CharacterScreenIndicator characterScreenIndicator;
			if (!this._characterIndicators.TryGetValue(evt.User, out characterScreenIndicator))
			{
				return;
			}
			characterScreenIndicator.TriggerVoice();
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x00041A74 File Offset: 0x0003FC74
		private void UpdateView()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			for (int i = 0; i < this._grenadeIndicators.Count; i++)
			{
				if (this._grenadeIndicators[i].GrenadeTransform == null)
				{
					this._grenadeIndicators[i].Destroy(0f);
					this._grenadeIndicators.RemoveAt(i);
					i--;
				}
				else
				{
					this._grenadeIndicators[i].UpdateMarker();
				}
			}
			this._playersToRemove.Clear();
			foreach (long num in this._characterIndicatorsKeys)
			{
				if (this._remoteCharacterService.GetCharacterInfo(num) == null)
				{
					this._playersToRemove.Add(num);
				}
				else
				{
					RemoteCharacterInfo characterInfo = this._remoteCharacterService.GetCharacterInfo(num);
					UITeam relativeTeam = UIEnums.GetRelativeTeam(characterInfo.Team);
					CharacterScreenIndicator characterScreenIndicator = this._characterIndicators[num];
					if (relativeTeam != characterScreenIndicator.Team)
					{
						this._playersToRemove.Add(num);
					}
				}
			}
			for (int j = 0; j < this._playersToRemove.Count; j++)
			{
				long num2 = this._playersToRemove[j];
				this._characterIndicators[num2].Destroy(0f);
				this._characterIndicators.Remove(num2);
			}
			this._playersToRemove.Clear();
			foreach (long num3 in this._damageIndicatorsKeys)
			{
				if (this._remoteCharacterService.GetCharacterInfo(num3) == null)
				{
					this._playersToRemove.Add(num3);
				}
			}
			for (int k = 0; k < this._playersToRemove.Count; k++)
			{
				long num4 = this._playersToRemove[k];
				this._damageIndicators[num4].Destroy(2.5f);
				this._damageIndicators.Remove(num4);
			}
			if (this._gameplayScreenIndicatorsView != null)
			{
				for (int l = 0; l < this._remoteCharacterService.ActivePlayers.Length; l++)
				{
					RemoteCharacterInfo remoteCharacterInfo = this._remoteCharacterService.ActivePlayers[l];
					if (remoteCharacterInfo != null)
					{
						UITeam relativeTeam2 = UIEnums.GetRelativeTeam(remoteCharacterInfo.Team);
						bool flag = this._gameModeService.GameMode == EGameMode.Juggernaut && remoteCharacterInfo.Team == Team.SMOKE;
						CharacterScreenIndicator characterScreenIndicator2;
						if (!this._characterIndicators.TryGetValue(remoteCharacterInfo.PlayerId, out characterScreenIndicator2))
						{
							characterScreenIndicator2 = this._gameplayScreenIndicatorsView.CreateCharacterIndicator(relativeTeam2, remoteCharacterInfo.NicknamePlainText, flag);
							this._characterIndicators.Add(remoteCharacterInfo.PlayerId, characterScreenIndicator2);
						}
						characterScreenIndicator2.UpdateMarker(remoteCharacterInfo.WorldPosition, remoteCharacterInfo.IsTargetedByPlayer, remoteCharacterInfo.IsCamouflaged, remoteCharacterInfo.Health, remoteCharacterInfo.MaxHealth, remoteCharacterInfo.HeroClass, relativeTeam2 == UITeam.Mine, flag, remoteCharacterInfo.IsVisibleOnScreen);
						DamageScreenIndicator damageScreenIndicator;
						if (this._damageIndicators.TryGetValue(remoteCharacterInfo.PlayerId, out damageScreenIndicator))
						{
							damageScreenIndicator.UpdateMarker(remoteCharacterInfo.WorldPosition);
						}
					}
				}
			}
			this._deathIndicatorsToRemove.Clear();
			foreach (KeyValuePair<DeathScreenIndicator, Vector3> keyValuePair in this._deathIndicators)
			{
				DeathScreenIndicator key = keyValuePair.Key;
				Vector3 value = keyValuePair.Value;
				if (key == null || key.Marker == null)
				{
					this._deathIndicatorsToRemove.Add(key);
				}
				else
				{
					key.UpdateMarker(value);
				}
			}
			for (int m = 0; m < this._deathIndicatorsToRemove.Count; m++)
			{
				this._deathIndicators.Remove(this._deathIndicatorsToRemove[m]);
			}
			for (int n = 0; n < this._capturePointIndicators.Count; n++)
			{
				CapturePointScreenIndicator capturePointScreenIndicator = this._capturePointIndicators[n];
				string text = ((!(capturePointScreenIndicator.PointName == "koth")) ? capturePointScreenIndicator.PointName : "A");
				CapturePointService.PointData pointData = this._capturePointService.GetPointData(text);
				if (pointData != null)
				{
					capturePointScreenIndicator.UpdateMarker(this._capturePointWorldPositions[n], pointData.OwnerTeam, pointData.CapturingTeam, pointData.CaptureAmount);
				}
			}
		}

		// Token: 0x04000E80 RID: 3712
		private readonly RemoteCharactersService _remoteCharacterService;

		// Token: 0x04000E81 RID: 3713
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E82 RID: 3714
		private readonly GameModeService _gameModeService;

		// Token: 0x04000E83 RID: 3715
		private readonly CapturePointService _capturePointService;

		// Token: 0x04000E84 RID: 3716
		private GameplayScreenIndicatorsView _gameplayScreenIndicatorsView;

		// Token: 0x04000E85 RID: 3717
		private readonly List<GrenadeScreenIndicator> _grenadeIndicators = new List<GrenadeScreenIndicator>();

		// Token: 0x04000E86 RID: 3718
		private readonly Dictionary<long, CharacterScreenIndicator> _characterIndicators = new Dictionary<long, CharacterScreenIndicator>();

		// Token: 0x04000E87 RID: 3719
		private readonly Dictionary<long, DamageScreenIndicator> _damageIndicators = new Dictionary<long, DamageScreenIndicator>();

		// Token: 0x04000E88 RID: 3720
		private readonly Dictionary<DeathScreenIndicator, Vector3> _deathIndicators = new Dictionary<DeathScreenIndicator, Vector3>();

		// Token: 0x04000E89 RID: 3721
		private readonly List<CapturePointScreenIndicator> _capturePointIndicators = new List<CapturePointScreenIndicator>();

		// Token: 0x04000E8A RID: 3722
		private readonly Dictionary<long, CharacterScreenIndicator>.KeyCollection _characterIndicatorsKeys;

		// Token: 0x04000E8B RID: 3723
		private readonly Dictionary<long, DamageScreenIndicator>.KeyCollection _damageIndicatorsKeys;

		// Token: 0x04000E8C RID: 3724
		private readonly List<long> _playersToRemove = new List<long>();

		// Token: 0x04000E8D RID: 3725
		private readonly List<DeathScreenIndicator> _deathIndicatorsToRemove = new List<DeathScreenIndicator>();

		// Token: 0x04000E8E RID: 3726
		private bool _capturePointsInitialized;

		// Token: 0x04000E8F RID: 3727
		private readonly List<Vector3> _capturePointWorldPositions = new List<Vector3>();
	}
}
