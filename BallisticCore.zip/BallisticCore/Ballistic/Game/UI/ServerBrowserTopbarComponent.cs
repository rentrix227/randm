﻿using System;
using System.Linq;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000202 RID: 514
	public class ServerBrowserTopbarComponent : MonoBehaviour
	{
		// Token: 0x06000A5B RID: 2651 RVA: 0x0003CD5C File Offset: 0x0003AF5C
		public void Start()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._listView = base.GetComponentInParent<ServerBrowserListView>();
			this._sortTypeGroup = base.GetComponent<ToggleGroup>();
			Toggle[] componentsInChildren = base.GetComponentsInChildren<Toggle>(true);
			foreach (Toggle toggle in componentsInChildren)
			{
				toggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSortByClicked));
			}
		}

		// Token: 0x06000A5C RID: 2652 RVA: 0x0003CDC8 File Offset: 0x0003AFC8
		private void OnSortByClicked(bool newBool)
		{
			if (this._sortTypeGroup == null)
			{
				return;
			}
			if (this._listView == null)
			{
				return;
			}
			Toggle toggle = this._sortTypeGroup.ActiveToggles().FirstOrDefault<Toggle>();
			if (toggle == null)
			{
				return;
			}
			bool isOn = toggle.transform.GetChild(0).GetComponent<Toggle>().isOn;
			ESortByCategories esortByCategories = (ESortByCategories)Enum.Parse(typeof(ESortByCategories), toggle.gameObject.name, true);
			this._listView.SortBy(esortByCategories, isOn);
		}

		// Token: 0x04000DCE RID: 3534
		private ServerBrowserListView _listView;

		// Token: 0x04000DCF RID: 3535
		private ToggleGroup _sortTypeGroup;
	}
}
