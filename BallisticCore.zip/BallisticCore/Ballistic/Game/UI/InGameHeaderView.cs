﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Requests;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002BD RID: 701
	public class InGameHeaderView : GameplayBaseChatView
	{
		// Token: 0x06000EAE RID: 3758 RVA: 0x00058C60 File Offset: 0x00056E60
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._chatEntries = new HighSpeedArray<ChatEntry>(40);
			this.ChannelAll.onValueChanged.AddListener(new UnityAction<bool>(this.OnSetChannelAll));
			this.ChannelTeam.onValueChanged.AddListener(new UnityAction<bool>(this.OnSetChannelTeam));
			this.QuitButton.onClick.AddListener(new UnityAction(this.RequestQuitPopUp));
			this.FriendsButton.onClick.AddListener(new UnityAction(this.RequestInviteFriends));
			this.InputField.onValueChanged.AddListener(new UnityAction<string>(this.OnInputTextChange));
			this.InputField.onEndEdit.AddListener(new UnityAction<string>(this.OnSubmitText));
			this.HideInputField();
			this.ChatText.text = string.Empty;
		}

		// Token: 0x06000EAF RID: 3759 RVA: 0x00058D4C File Offset: 0x00056F4C
		private static void RequestTeamChange()
		{
			SelectTeamRequest selectTeamRequest = new SelectTeamRequest();
			Team team = UserProfile.LocalGameClient.team;
			if (team != Team.MFA)
			{
				if (team != Team.SMOKE)
				{
					return;
				}
				selectTeamRequest.RequestedTeam = ETeamMode.MFA;
			}
			else
			{
				selectTeamRequest.RequestedTeam = ETeamMode.SMOKE;
			}
			ServiceProvider.GetService<NetworkGameService>().RaiseNetworkEvent(selectTeamRequest);
		}

		// Token: 0x06000EB0 RID: 3760 RVA: 0x0000BF53 File Offset: 0x0000A153
		private void OnSetChannelTeam(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.SetTeamOnly(true);
		}

		// Token: 0x06000EB1 RID: 3761 RVA: 0x0000BF73 File Offset: 0x0000A173
		private void OnSetChannelAll(bool value)
		{
			if (!value || this._isSetting)
			{
				return;
			}
			base._controller.SetTeamOnly(false);
		}

		// Token: 0x06000EB2 RID: 3762 RVA: 0x00058DA4 File Offset: 0x00056FA4
		internal override void AddTextEntry(string entryText)
		{
			if (!this.ChatBox.isOn)
			{
				this.ChatBox.isOn = true;
			}
			ChatEntry chatEntry = new ChatEntry
			{
				EntryText = entryText,
				Timestamp = Time.time
			};
			this._chatEntries.Add(chatEntry);
			while (this._chatEntries.Length > 30)
			{
				this._chatEntries.RemoveAt(0);
			}
			string text = string.Empty;
			for (int i = 0; i < this._chatEntries.Length; i++)
			{
				text += this._chatEntries[i].EntryText;
			}
			this.ChatText.text = text;
		}

		// Token: 0x06000EB3 RID: 3763 RVA: 0x0000BF93 File Offset: 0x0000A193
		internal override bool IsTyping()
		{
			return this.InputField.isFocused;
		}

		// Token: 0x06000EB4 RID: 3764 RVA: 0x0000BFA0 File Offset: 0x0000A1A0
		internal override void SetTeamOnly(bool teamOnly)
		{
			this._isSetting = true;
			this._teamOnly = teamOnly;
			this.ChannelAll.isOn = !teamOnly;
			this.ChannelTeam.isOn = teamOnly;
			this._isSetting = false;
		}

		// Token: 0x06000EB5 RID: 3765 RVA: 0x0000BFD2 File Offset: 0x0000A1D2
		internal override void FocusInputField()
		{
			if (EventSystem.current != null)
			{
				EventSystem.current.SetSelectedGameObject(this.InputField.gameObject);
			}
			this.InputField.OnPointerClick(new PointerEventData(EventSystem.current));
		}

		// Token: 0x06000EB6 RID: 3766 RVA: 0x0000C00E File Offset: 0x0000A20E
		internal override void HideInputField()
		{
			this.ClearInputField();
		}

		// Token: 0x06000EB7 RID: 3767 RVA: 0x0000C016 File Offset: 0x0000A216
		private void ClearInputField()
		{
			this.InputField.text = string.Empty;
			this.InputField.ForceLabelUpdate();
		}

		// Token: 0x06000EB8 RID: 3768 RVA: 0x00058E64 File Offset: 0x00057064
		private void OnSubmitText(string text)
		{
			string text2 = text.Trim();
			if (string.IsNullOrEmpty(text2))
			{
				return;
			}
			base._controller.OnTextInput(text2, this._teamOnly && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER);
			this.ClearInputField();
			this.FocusInputField();
		}

		// Token: 0x06000EB9 RID: 3769 RVA: 0x00058EB8 File Offset: 0x000570B8
		private void OnInputTextChange(string text)
		{
			if (text == "/all")
			{
				base._controller.SetTeamOnly(false);
				this.ClearInputField();
			}
			else if (text == "/team")
			{
				base._controller.SetTeamOnly(true);
				this.ClearInputField();
			}
		}

		// Token: 0x06000EBA RID: 3770 RVA: 0x00058F10 File Offset: 0x00057110
		internal void SetData(EClientMode mode, ETeamMode teamMode, EGameMode gameMode, bool spawned, bool canChangeTeam, bool isLobby, bool autoBalance)
		{
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				this.ChooseTeamToggle.interactable = (teamMode == ETeamMode.UNDEFINED || !canChangeTeam) && !autoBalance;
				this.RespawnToggle.interactable = (teamMode != ETeamMode.UNDEFINED || autoBalance) && !spawned;
				this.ChangeTeamInfo.text = ServiceProvider.GetService<LocalizationService>().Get("change_team_tooltip_ending", ELocalizedTextCase.NONE);
			}
			else
			{
				this.ChooseTeamToggle.interactable = false;
				this.RespawnToggle.interactable = !spawned;
				this.ChangeTeamInfo.text = ServiceProvider.GetService<LocalizationService>().Get("change_team_tooltip_ffa", ELocalizedTextCase.NONE);
			}
			this.MatchInfoToggle.interactable = teamMode != ETeamMode.UNDEFINED;
			this.FriendsButton.interactable = isLobby;
		}

		// Token: 0x06000EBB RID: 3771 RVA: 0x0000BCBA File Offset: 0x00009EBA
		private void RequestQuitPopUp()
		{
			base._controller.RequestPopupQuit();
		}

		// Token: 0x06000EBC RID: 3772 RVA: 0x0000C033 File Offset: 0x0000A233
		private void RequestInviteFriends()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			base._controller.InviteFriends();
		}

		// Token: 0x0400138C RID: 5004
		public Toggle ChatBox;

		// Token: 0x0400138D RID: 5005
		public Toggle ChannelAll;

		// Token: 0x0400138E RID: 5006
		public Toggle ChannelTeam;

		// Token: 0x0400138F RID: 5007
		public InputField InputField;

		// Token: 0x04001390 RID: 5008
		public Text ChatText;

		// Token: 0x04001391 RID: 5009
		public Toggle ChooseTeamToggle;

		// Token: 0x04001392 RID: 5010
		public Toggle RespawnToggle;

		// Token: 0x04001393 RID: 5011
		public Toggle MatchInfoToggle;

		// Token: 0x04001394 RID: 5012
		public Button FriendsButton;

		// Token: 0x04001395 RID: 5013
		public Button QuitButton;

		// Token: 0x04001396 RID: 5014
		public Text ChangeTeamInfo;

		// Token: 0x04001397 RID: 5015
		private HighSpeedArray<ChatEntry> _chatEntries;

		// Token: 0x04001398 RID: 5016
		private bool _teamOnly;

		// Token: 0x04001399 RID: 5017
		private bool _isSetting;
	}
}
