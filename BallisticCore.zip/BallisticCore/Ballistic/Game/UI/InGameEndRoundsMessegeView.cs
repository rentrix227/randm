﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002BB RID: 699
	public class InGameEndRoundsMessegeView : BaseView<InGameEndmatchController>
	{
		// Token: 0x06000EA7 RID: 3751 RVA: 0x0000BEFE File Offset: 0x0000A0FE
		internal void RoundsTimeUpdate(EGameState state, int totalSeconds)
		{
			this._lastState = state;
			this._lastTotalSeconds = totalSeconds;
			this._lastRealtimeSinceUpdate = Time.realtimeSinceStartup;
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x0000BF19 File Offset: 0x0000A119
		internal void RoundsDispatchStarted()
		{
			this.RoundsStartedAnimator.SetTrigger("round_started");
		}

		// Token: 0x06000EA9 RID: 3753 RVA: 0x00058B68 File Offset: 0x00056D68
		public void Update()
		{
			this._isRoundStarting = this._lastTotalSeconds <= this.SecondsToConsiderRoundIsStarting && this._lastState == EGameState.ROUNDUP;
			if (this._isRoundStarting)
			{
				float num = (float)this._lastTotalSeconds - (Time.realtimeSinceStartup - this._lastRealtimeSinceUpdate);
				this.UpdateTimeMiliseconds(this.RoundsCountdownText, num);
			}
			if (this.RoundsCountdownAnimator.isInitialized)
			{
				this.RoundsCountdownAnimator.SetBool(InGameEndRoundsMessegeView._anim_param_countdown_in, this._isRoundStarting);
				this.RoundsCountdownAnimator.SetBool(InGameEndRoundsMessegeView._anim_param_round_wait, this._lastState == EGameState.ROUNDUP);
			}
		}

		// Token: 0x06000EAA RID: 3754 RVA: 0x00058C04 File Offset: 0x00056E04
		private void UpdateTimeMiliseconds(Text timerText, float totalSeconds)
		{
			if (totalSeconds < 0f)
			{
				timerText.text = string.Empty;
				return;
			}
			int num = (int)totalSeconds % 60;
			int num2 = (int)(Mathf.Repeat(totalSeconds, 1f) * 100f);
			timerText.text = StringUtils.Time00to99[num] + ":" + StringUtils.Time00to99[num2];
		}

		// Token: 0x04001382 RID: 4994
		private static readonly int _anim_param_countdown_in = Animator.StringToHash("countdown_in");

		// Token: 0x04001383 RID: 4995
		private static readonly int _anim_param_round_wait = Animator.StringToHash("round_wait");

		// Token: 0x04001384 RID: 4996
		public int SecondsToConsiderRoundIsStarting = 5;

		// Token: 0x04001385 RID: 4997
		public Animator RoundsCountdownAnimator;

		// Token: 0x04001386 RID: 4998
		public Text RoundsCountdownText;

		// Token: 0x04001387 RID: 4999
		public Animator RoundsStartedAnimator;

		// Token: 0x04001388 RID: 5000
		private int _lastTotalSeconds = -1;

		// Token: 0x04001389 RID: 5001
		private bool _isRoundStarting;

		// Token: 0x0400138A RID: 5002
		private float _lastRealtimeSinceUpdate;

		// Token: 0x0400138B RID: 5003
		private EGameState _lastState;
	}
}
