﻿using System;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000218 RID: 536
	public class GameplayHeroController : BaseController
	{
		// Token: 0x06000AD5 RID: 2773 RVA: 0x0003F198 File Offset: 0x0003D398
		public GameplayHeroController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._inputControlService = ServiceProvider.GetService<InputControlService>();
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnWeaponStationEvent.AddListener(new Action<WeaponStationEvent>(this.OnWeaponStation));
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000AD6 RID: 2774 RVA: 0x00009A25 File Offset: 0x00007C25
		internal bool PlayerIsDead
		{
			get
			{
				return !OfflineInformation.OfflineUi && this._localCharacterService.IsDead;
			}
		}

		// Token: 0x06000AD7 RID: 2775 RVA: 0x0003F238 File Offset: 0x0003D438
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnWeaponStationEvent.RemoveListener(new Action<WeaponStationEvent>(this.OnWeaponStation));
		}

		// Token: 0x06000AD8 RID: 2776 RVA: 0x0003F2AC File Offset: 0x0003D4AC
		private void OnWeaponStation(WeaponStationEvent evt)
		{
			if (UserProfile.IsMe(evt.User))
			{
				GameplayHeroDamageFeedbackView view = base.GetView<GameplayHeroDamageFeedbackView>();
				if (view != null)
				{
					view.SetJuggernautMode(true);
				}
			}
		}

		// Token: 0x06000AD9 RID: 2777 RVA: 0x0003F2E4 File Offset: 0x0003D4E4
		private void OnSpawn(SpawnEvent spawnEvent)
		{
			if (!UserProfile.IsMe(spawnEvent.User))
			{
				return;
			}
			GameplayHeroDamageFeedbackView view = base.GetView<GameplayHeroDamageFeedbackView>();
			if (view != null)
			{
				view.ClearDamage();
				view.SetJuggernautMode(false);
			}
		}

		// Token: 0x06000ADA RID: 2778 RVA: 0x0003F324 File Offset: 0x0003D524
		private void OnUserHit(HitEvent hitEvent)
		{
			if (!UserProfile.IsMe(hitEvent.VictimGameClientId))
			{
				return;
			}
			GameplayHeroDamageFeedbackView view = base.GetView<GameplayHeroDamageFeedbackView>();
			if (view != null)
			{
				if (UserProfile.IsMe(hitEvent.SenderId))
				{
					view.SetInternalDamage(hitEvent.Damage / 200f);
				}
				else
				{
					RemoteCharacterInfo characterInfo = ServiceProvider.GetService<RemoteCharactersService>().GetCharacterInfo(hitEvent.SenderId);
					Vector3 vector;
					if (characterInfo == null || hitEvent.DamageType == EDamageType.EXPLOSIVE)
					{
						vector = hitEvent.ShooterPosition;
					}
					else
					{
						vector = characterInfo.WorldPosition;
						vector += 0.7f * Vector3.up;
					}
					if (this._gameModeService.GameMode == EGameMode.Juggernaut && UserProfile.LocalGameClient.team == Team.SMOKE)
					{
						view.SetExternalDamage(this._localCharacterService.StageCamera, vector, Mathf.Clamp(0.1f, 2f, hitEvent.Damage / 250f));
					}
					else
					{
						view.SetExternalDamage(this._localCharacterService.StageCamera, vector, Mathf.Clamp(0.1f, 2f, hitEvent.Damage / 75f));
					}
				}
			}
		}

		// Token: 0x06000ADB RID: 2779 RVA: 0x00009A3E File Offset: 0x00007C3E
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (view is GameplayHeroDamageFeedbackView)
			{
				this._inputControlService.SetMouse(view, false);
			}
		}

		// Token: 0x06000ADC RID: 2780 RVA: 0x00009A6A File Offset: 0x00007C6A
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (view is GameplayHeroDamageFeedbackView)
			{
				this._inputControlService.RemoveMouse(view);
			}
		}

		// Token: 0x04000E5E RID: 3678
		private readonly LocalCharacterService _localCharacterService;

		// Token: 0x04000E5F RID: 3679
		private readonly InputControlService _inputControlService;

		// Token: 0x04000E60 RID: 3680
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000E61 RID: 3681
		private readonly GameModeService _gameModeService;
	}
}
