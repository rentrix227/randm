﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001DA RID: 474
	public class InventoryLockboxComponent : PoolableComponent
	{
		// Token: 0x060009B4 RID: 2484 RVA: 0x00008BD8 File Offset: 0x00006DD8
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.LockboxButton.onClick.AddListener(new UnityAction(this.OnLockboxClicked));
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x0003A3B8 File Offset: 0x000385B8
		internal void SetData(LockboxData data, bool isNew)
		{
			this._data = data;
			if (this.LockboxImage != null)
			{
				string lockboxIconPath = TextureHelper.GetLockboxIconPath(data.Lockbox.Season, data.Lockbox.HeroClass, EImageSize.SMALL);
				TextureHelper.LoadImageAsync(lockboxIconPath, this.LockboxImage, false, EImageSource.RESOURCES);
			}
			if (this.LockboxSeasonImage != null)
			{
				string text;
				if (data.Lockbox.Season == ESeason.LADDER)
				{
					text = TextureHelper.GetRewardsIconPath(data.Lockbox.HeroClass, EImageSize.SMALL);
				}
				else
				{
					text = TextureHelper.GetSeasonIconPath(data.Lockbox.Season, EImageSize.SMALL);
				}
				TextureHelper.LoadImageAsync(text, this.LockboxSeasonImage, false, EImageSource.RESOURCES);
			}
			this.LockboxName.text = data.CurrentName;
			this.LockboxSeason.text = ServiceProvider.GetService<LocalizationService>().GetSeasonName(data.Lockbox.Season, ELocalizedTextCase.UPPER_CASE);
			if (this.NewNotification != null)
			{
				this.NewNotification.SetActive(isNew);
			}
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x00008C01 File Offset: 0x00006E01
		private void OnLockboxClicked()
		{
			if (this.OnLockboxClick != null)
			{
				this.OnLockboxClick(this._data);
			}
		}

		// Token: 0x04000CF9 RID: 3321
		public Image LockboxImage;

		// Token: 0x04000CFA RID: 3322
		public Image LockboxSeasonImage;

		// Token: 0x04000CFB RID: 3323
		public Text LockboxName;

		// Token: 0x04000CFC RID: 3324
		public Text LockboxSeason;

		// Token: 0x04000CFD RID: 3325
		public Button LockboxButton;

		// Token: 0x04000CFE RID: 3326
		public GameObject NewNotification;

		// Token: 0x04000CFF RID: 3327
		internal Action<LockboxData> OnLockboxClick;

		// Token: 0x04000D00 RID: 3328
		private LockboxData _data;
	}
}
