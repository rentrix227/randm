﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001F6 RID: 502
	public class PlayerProfileLevelComponent : MonoBehaviour
	{
		// Token: 0x06000A24 RID: 2596 RVA: 0x0003BF94 File Offset: 0x0003A194
		internal void SetSubLevel(int subLevel, bool instant)
		{
			for (int i = 0; i < this.SubLevelItems.Count; i++)
			{
				this.SubLevelItems[i].SetBool("isUnlocked", i < subLevel);
				if (i < subLevel && !instant)
				{
					this.SubLevelItems[i].SetTrigger("unlocked_now");
				}
			}
		}

		// Token: 0x04000D8F RID: 3471
		public List<Animator> SubLevelItems = new List<Animator>();
	}
}
