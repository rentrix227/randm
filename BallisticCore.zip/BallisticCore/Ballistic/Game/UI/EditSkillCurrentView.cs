﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200026B RID: 619
	public class EditSkillCurrentView : BaseView<SkillsController>
	{
		// Token: 0x06000D41 RID: 3393 RVA: 0x0004E968 File Offset: 0x0004CB68
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.Skill1 != null)
			{
				SoldiersSkillComponent skill = this.Skill1;
				skill.OnSkillClicked = (Action<HeroSkillData>)Delegate.Combine(skill.OnSkillClicked, new Action<HeroSkillData>(this.OnSkill1Selected));
			}
			if (this.Skill2 != null)
			{
				SoldiersSkillComponent skill2 = this.Skill2;
				skill2.OnSkillClicked = (Action<HeroSkillData>)Delegate.Combine(skill2.OnSkillClicked, new Action<HeroSkillData>(this.OnSkill2Selected));
			}
		}

		// Token: 0x06000D42 RID: 3394 RVA: 0x0000B105 File Offset: 0x00009305
		private void OnSkill1Selected(HeroSkillData skillData)
		{
			base._controller.SetTemporarySlot(0);
		}

		// Token: 0x06000D43 RID: 3395 RVA: 0x0000B113 File Offset: 0x00009313
		private void OnSkill2Selected(HeroSkillData skillData)
		{
			base._controller.SetTemporarySlot(1);
		}

		// Token: 0x06000D44 RID: 3396 RVA: 0x0000B121 File Offset: 0x00009321
		internal void SetSkills(HeroSkillData skill1, HeroSkillData skill2, int slot)
		{
			this.Skill1.SetData(skill1, slot == 0, true, -1);
			this.Skill2.SetData(skill2, slot == 1, true, -1);
		}

		// Token: 0x0400100D RID: 4109
		public SoldiersSkillComponent Skill1;

		// Token: 0x0400100E RID: 4110
		public SoldiersSkillComponent Skill2;
	}
}
