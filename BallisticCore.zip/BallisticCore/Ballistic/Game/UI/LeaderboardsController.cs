﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000506 RID: 1286
	public class LeaderboardsController : BaseController
	{
		// Token: 0x06001B4F RID: 6991 RVA: 0x0008CF90 File Offset: 0x0008B190
		public LeaderboardsController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._currentLeaderboard = Leaderboards.SKIN_LEGENDARY_LADDER;
			this._currentMethod = LeaderboardMethod.GLOBAL;
			this._playerName = SteamFriends.GetPersonaName();
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(SteamUser.GetSteamID(), new Action<ulong, Texture2D>(this.OnLoadAvatar), true);
			this._statisticService = ServiceProvider.GetService<StatisticsService>();
			this._leaderboardService = ServiceProvider.GetService<LeaderboardService>();
			LeaderboardService leaderboardService = this._leaderboardService;
			leaderboardService.OnFriendsLeaderboardReceived = (Action<Leaderboards, LeaderboardEntry[]>)Delegate.Combine(leaderboardService.OnFriendsLeaderboardReceived, new Action<Leaderboards, LeaderboardEntry[]>(this.OnFriendsLeaderboardReceived));
			LeaderboardService leaderboardService2 = this._leaderboardService;
			leaderboardService2.OnGlobalLeaderboardReceived = (Action<Leaderboards, LeaderboardEntry[]>)Delegate.Combine(leaderboardService2.OnGlobalLeaderboardReceived, new Action<Leaderboards, LeaderboardEntry[]>(this.OnGlobalLeaderboardReceived));
			LeaderboardService leaderboardService3 = this._leaderboardService;
			leaderboardService3.OnNeightboursLeaderboardReceived = (Action<Leaderboards, LeaderboardEntry[]>)Delegate.Combine(leaderboardService3.OnNeightboursLeaderboardReceived, new Action<Leaderboards, LeaderboardEntry[]>(this.OnNeightboursLeaderboardReceived));
		}

		// Token: 0x06001B50 RID: 6992 RVA: 0x00013F41 File Offset: 0x00012141
		private void OnLoadAvatar(ulong steamId, Texture2D texture)
		{
			this._playerAvatar = texture;
		}

		// Token: 0x06001B51 RID: 6993 RVA: 0x0008D070 File Offset: 0x0008B270
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			LeaderboardService leaderboardService = this._leaderboardService;
			leaderboardService.OnFriendsLeaderboardReceived = (Action<Leaderboards, LeaderboardEntry[]>)Delegate.Remove(leaderboardService.OnFriendsLeaderboardReceived, new Action<Leaderboards, LeaderboardEntry[]>(this.OnFriendsLeaderboardReceived));
			LeaderboardService leaderboardService2 = this._leaderboardService;
			leaderboardService2.OnGlobalLeaderboardReceived = (Action<Leaderboards, LeaderboardEntry[]>)Delegate.Remove(leaderboardService2.OnGlobalLeaderboardReceived, new Action<Leaderboards, LeaderboardEntry[]>(this.OnGlobalLeaderboardReceived));
			LeaderboardService leaderboardService3 = this._leaderboardService;
			leaderboardService3.OnNeightboursLeaderboardReceived = (Action<Leaderboards, LeaderboardEntry[]>)Delegate.Remove(leaderboardService3.OnNeightboursLeaderboardReceived, new Action<Leaderboards, LeaderboardEntry[]>(this.OnNeightboursLeaderboardReceived));
		}

		// Token: 0x06001B52 RID: 6994 RVA: 0x0008D100 File Offset: 0x0008B300
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			LeaderboardsCategoriesView leaderboardsCategoriesView = view as LeaderboardsCategoriesView;
			if (leaderboardsCategoriesView != null)
			{
				leaderboardsCategoriesView.SetData(this._currentLeaderboard);
			}
			LeaderboardsFiltersView leaderboardsFiltersView = view as LeaderboardsFiltersView;
			if (leaderboardsFiltersView != null)
			{
				leaderboardsFiltersView.SetData(this._currentMethod);
			}
			LeaderboardsPlayersView leaderboardsPlayersView = view as LeaderboardsPlayersView;
			if (leaderboardsPlayersView != null)
			{
				leaderboardsPlayersView.ClearData();
				this.UpdateLeaderboard();
			}
			LeaderboardsFooterView leaderboardsFooterView = view as LeaderboardsFooterView;
			if (leaderboardsFooterView != null)
			{
				this.UpdateStatistics(leaderboardsFooterView);
			}
			LeaderboardsRewardsView leaderboardsRewardsView = view as LeaderboardsRewardsView;
			if (leaderboardsRewardsView != null)
			{
				leaderboardsRewardsView.SetStartData(this._currentLeaderboard);
			}
		}

		// Token: 0x06001B53 RID: 6995 RVA: 0x00013F4A File Offset: 0x0001214A
		private void UpdateStatistics(LeaderboardsFooterView footer)
		{
			footer.SetLoading();
			this._statisticService.RequestCurrentStats(new Action<StatisticsGeneralData>(this.OnRequestUserDataSucess));
		}

		// Token: 0x06001B54 RID: 6996 RVA: 0x0008D1A8 File Offset: 0x0008B3A8
		private void OnRequestUserDataSucess(StatisticsGeneralData evt)
		{
			this._currentStatistics = evt;
			this._currentEntry = this._leaderboardService.GetLastSelfLeaderboardEntry();
			LeaderboardsFooterView view = base.GetView<LeaderboardsFooterView>();
			if (view != null && this._currentStatistics != null)
			{
				view.SetPlayerData(this._playerName, this._playerAvatar, this._currentStatistics, this._currentEntry);
			}
		}

		// Token: 0x06001B55 RID: 6997 RVA: 0x00013F6A File Offset: 0x0001216A
		internal void DispatchLeaderboardChange(Leaderboards leaderboards)
		{
			this._currentLeaderboard = leaderboards;
			this.UpdateLeaderboard();
		}

		// Token: 0x06001B56 RID: 6998 RVA: 0x00013F79 File Offset: 0x00012179
		internal void DispatchLeaderboadMethodChange(LeaderboardMethod method)
		{
			this._currentMethod = method;
			this.UpdateLeaderboard();
		}

		// Token: 0x06001B57 RID: 6999 RVA: 0x0008D204 File Offset: 0x0008B404
		private void UpdateLeaderboard()
		{
			LeaderboardsPlayersView view = base.GetView<LeaderboardsPlayersView>();
			if (view != null)
			{
				view.SetLoading();
			}
			LeaderboardsRewardsView view2 = base.GetView<LeaderboardsRewardsView>();
			if (view2 != null)
			{
				view2.SetData(this._currentLeaderboard);
			}
			LeaderboardMethod currentMethod = this._currentMethod;
			if (currentMethod != LeaderboardMethod.GLOBAL)
			{
				if (currentMethod == LeaderboardMethod.NEIGHTBOURS)
				{
					this._leaderboardService.RequestNeightboursLeaderboardScore(this._currentLeaderboard, -4, 5);
					return;
				}
				if (currentMethod == LeaderboardMethod.FRIENDS)
				{
					this._leaderboardService.RequestFriendsLeaderboardScore(this._currentLeaderboard, (this._currentLeaderboard != Leaderboards.SKIN_LEGENDARY_LADDER) ? 100 : 200);
					return;
				}
			}
			else
			{
				this._leaderboardService.RequestGlobalLeaderboardScores(this._currentLeaderboard, (this._currentLeaderboard != Leaderboards.SKIN_LEGENDARY_LADDER) ? 100 : 200);
			}
		}

		// Token: 0x06001B58 RID: 7000 RVA: 0x00013F88 File Offset: 0x00012188
		private void OnNeightboursLeaderboardReceived(Leaderboards leaderboard, LeaderboardEntry[] list)
		{
			this.UpdatePages(leaderboard, list);
		}

		// Token: 0x06001B59 RID: 7001 RVA: 0x00013F88 File Offset: 0x00012188
		private void OnFriendsLeaderboardReceived(Leaderboards leaderboard, LeaderboardEntry[] list)
		{
			this.UpdatePages(leaderboard, list);
		}

		// Token: 0x06001B5A RID: 7002 RVA: 0x00013F88 File Offset: 0x00012188
		private void OnGlobalLeaderboardReceived(Leaderboards leaderboard, LeaderboardEntry[] list)
		{
			this.UpdatePages(leaderboard, list);
		}

		// Token: 0x06001B5B RID: 7003 RVA: 0x0008D2BC File Offset: 0x0008B4BC
		private void UpdatePages(Leaderboards leaderboard, LeaderboardEntry[] list)
		{
			LeaderboardsFooterView view = base.GetView<LeaderboardsFooterView>();
			if (view != null)
			{
				view.SetData(leaderboard, list);
			}
			LeaderboardsPlayersView view2 = base.GetView<LeaderboardsPlayersView>();
			if (view2 != null)
			{
				view2.SetData(leaderboard, list);
			}
		}

		// Token: 0x06001B5C RID: 7004 RVA: 0x0008D2FC File Offset: 0x0008B4FC
		internal void DispatchPageDown()
		{
			LeaderboardsPlayersView view = base.GetView<LeaderboardsPlayersView>();
			LeaderboardsFooterView view2 = base.GetView<LeaderboardsFooterView>();
			if (view != null && view2 != null)
			{
				int num = view.GetCurrentPage() - 1;
				view.SetPage(num);
				view2.SetPage(num);
			}
		}

		// Token: 0x06001B5D RID: 7005 RVA: 0x0008D340 File Offset: 0x0008B540
		internal void DispatchPageUp()
		{
			LeaderboardsPlayersView view = base.GetView<LeaderboardsPlayersView>();
			LeaderboardsFooterView view2 = base.GetView<LeaderboardsFooterView>();
			if (view != null && view2 != null)
			{
				int num = view.GetCurrentPage() + 1;
				view.SetPage(num);
				view2.SetPage(num);
			}
		}

		// Token: 0x06001B5E RID: 7006 RVA: 0x0008D384 File Offset: 0x0008B584
		internal void DispatchPageSet(int page)
		{
			LeaderboardsPlayersView view = base.GetView<LeaderboardsPlayersView>();
			LeaderboardsFooterView view2 = base.GetView<LeaderboardsFooterView>();
			if (view != null && view2 != null)
			{
				view.SetPage(page);
				view2.SetPage(page);
			}
		}

		// Token: 0x04001D27 RID: 7463
		private LeaderboardService _leaderboardService;

		// Token: 0x04001D28 RID: 7464
		private StatisticsService _statisticService;

		// Token: 0x04001D29 RID: 7465
		private Leaderboards _currentLeaderboard;

		// Token: 0x04001D2A RID: 7466
		private LeaderboardMethod _currentMethod;

		// Token: 0x04001D2B RID: 7467
		private readonly string _playerName;

		// Token: 0x04001D2C RID: 7468
		private Texture2D _playerAvatar;

		// Token: 0x04001D2D RID: 7469
		private StatisticsGeneralData _currentStatistics;

		// Token: 0x04001D2E RID: 7470
		private LeaderboardEntry _currentEntry;
	}
}
