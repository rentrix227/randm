﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Profile;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200025B RID: 603
	internal static class UIEnums
	{
		// Token: 0x06000D13 RID: 3347 RVA: 0x0004DDA0 File Offset: 0x0004BFA0
		internal static UITeam GetRelativeTeam(Team absoluteTeam)
		{
			Team team = UserProfile.LocalGameClient.team;
			Team team2 = ((team != Team.MFA) ? Team.MFA : Team.SMOKE);
			if (absoluteTeam == team)
			{
				return UITeam.Mine;
			}
			return (absoluteTeam != team2) ? UITeam.None : UITeam.Other;
		}
	}
}
