﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200025C RID: 604
	public class AccessoryModelView : BaseView<InventoryController>
	{
		// Token: 0x06000D15 RID: 3349 RVA: 0x0004DDE0 File Offset: 0x0004BFE0
		internal void SetData(Accessory accessory)
		{
			this.Root.localRotation = Quaternion.Euler(0f, 180f, 0f);
			for (int i = 0; i < this.Root.childCount; i++)
			{
				Object.Destroy(this.Root.GetChild(i).gameObject);
			}
			ServiceProvider.GetService<EventProxy>().StartCoroutine(this.LoadAsync(accessory, this.Root));
			this.Camera.backgroundColor = accessory.AccessoryCameraColor;
		}

		// Token: 0x06000D16 RID: 3350 RVA: 0x0004DE6C File Offset: 0x0004C06C
		private IEnumerator LoadAsync(Accessory accessory, Transform parent)
		{
			string[] accessories = accessory.ItemModel.Split(new char[] { ';' });
			if (accessories.Length == 1)
			{
				ResourceRequest rqt = Resources.LoadAsync<GameObject>("accessories/" + accessories[0]);
				while (!rqt.isDone)
				{
					yield return null;
				}
				GameObject accessoryInstance = Object.Instantiate<GameObject>(rqt.asset as GameObject, parent);
				if (accessoryInstance != null)
				{
					foreach (MonoBehaviour monoBehaviour in accessoryInstance.GetComponentsInChildren<MonoBehaviour>())
					{
						Object.Destroy(monoBehaviour);
					}
					accessoryInstance.transform.localPosition = Vector3.up * accessory.AccessoryModelYOffset;
					accessoryInstance.transform.localRotation = Quaternion.identity;
					accessoryInstance.transform.localScale = Vector3.one * accessory.AccessoryModelSize;
				}
			}
			else
			{
				GameObject accessoryObjects = new GameObject("AccessoryObjects");
				accessoryObjects.transform.SetParent(parent, false);
				accessoryObjects.transform.localScale = Vector3.one * accessory.AccessoryModelSize;
				for (int i = 0; i < accessories.Length; i++)
				{
					ResourceRequest rqt2 = Resources.LoadAsync<GameObject>("accessories/" + accessories[i]);
					while (!rqt2.isDone)
					{
						yield return null;
					}
					GameObject accessoryInstance2 = Object.Instantiate<GameObject>(rqt2.asset as GameObject, accessoryObjects.transform);
					if (accessoryInstance2 != null)
					{
						foreach (MonoBehaviour monoBehaviour2 in accessoryInstance2.GetComponentsInChildren<MonoBehaviour>())
						{
							Object.Destroy(monoBehaviour2);
						}
						accessoryInstance2.transform.localPosition = Vector3.right * accessory.AccessoryModelDistance * (float)i;
						accessoryInstance2.transform.localRotation = Quaternion.identity;
						accessoryInstance2.transform.localScale = Vector3.one;
					}
				}
				Renderer[] ths = accessoryObjects.GetComponentsInChildren<Renderer>();
				if (ths.Length <= 0)
				{
					yield break;
				}
				Vector3 center = Vector3.zero;
				int count = 0;
				foreach (Renderer renderer in ths)
				{
					if (renderer is MeshRenderer)
					{
						center += renderer.bounds.center;
						count++;
					}
					else if (renderer is SkinnedMeshRenderer)
					{
						center += renderer.bounds.center;
						count++;
					}
				}
				if (count > 0)
				{
					accessoryObjects.transform.position = accessoryObjects.transform.position - center / (float)count;
				}
				accessoryObjects.transform.position += Vector3.up * accessory.AccessoryModelYOffset;
			}
			yield break;
		}

		// Token: 0x04000FCA RID: 4042
		public Transform Root;

		// Token: 0x04000FCB RID: 4043
		public Camera Camera;
	}
}
