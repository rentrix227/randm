﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Lockbox;
using Aquiris.Services;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200024D RID: 589
	public class SeasonController : BaseController
	{
		// Token: 0x06000C61 RID: 3169 RVA: 0x0000A660 File Offset: 0x00008860
		public SeasonController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._seasonService = ServiceProvider.GetService<SeasonService>();
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange += this.OnLanguageChange;
		}

		// Token: 0x06000C62 RID: 3170 RVA: 0x0000A694 File Offset: 0x00008894
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange -= this.OnLanguageChange;
		}

		// Token: 0x06000C63 RID: 3171 RVA: 0x0004AF0C File Offset: 0x0004910C
		private void OnLanguageChange()
		{
			SeasonHomeButtonView view = base.GetView<SeasonHomeButtonView>();
			if (view != null)
			{
				this._homeButtonView = view;
				ServiceProvider.GetService<EventProxy>().StartCoroutine(this.CheckForSeasonRoutine());
			}
		}

		// Token: 0x06000C64 RID: 3172 RVA: 0x0004AF44 File Offset: 0x00049144
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			SeasonHomeButtonView seasonHomeButtonView = view as SeasonHomeButtonView;
			if (seasonHomeButtonView != null)
			{
				this._homeButtonView = seasonHomeButtonView;
				ServiceProvider.GetService<EventProxy>().StartCoroutine(this.CheckForSeasonRoutine());
			}
			SeasonInfoTitleView seasonInfoTitleView = view as SeasonInfoTitleView;
			if (seasonInfoTitleView != null)
			{
				seasonInfoTitleView.SetData(this._seasonService.GetCurrentSeasonInfo());
			}
			SeasonInfoSkinsView seasonInfoSkinsView = view as SeasonInfoSkinsView;
			if (seasonInfoSkinsView != null)
			{
				bool flag = this._skinsView == null;
				this._skinsView = seasonInfoSkinsView;
				seasonInfoSkinsView.OnClassSelected = new Action<EHeroClass>(this.OnClassSelected);
				seasonInfoSkinsView.OnSkinSelected = new Action<WeaponSkinData>(this.OnSkinSelected);
				if (flag)
				{
					this.OnClassSelected(seasonInfoSkinsView.DefaultClass);
				}
			}
			SeasonInfoAccessoriesView seasonInfoAccessoriesView = view as SeasonInfoAccessoriesView;
			if (seasonInfoAccessoriesView != null)
			{
				SeasonInfo currentSeasonInfo = this._seasonService.GetCurrentSeasonInfo();
				MasterGenerator generatorForSeason = this._seasonService.GetGeneratorForSeason(currentSeasonInfo.Season);
				seasonInfoAccessoriesView.SetAccessories(generatorForSeason.GetSeasonAccessories());
			}
		}

		// Token: 0x06000C65 RID: 3173 RVA: 0x0004B054 File Offset: 0x00049254
		private IEnumerator CheckForSeasonRoutine()
		{
			while (this._seasonService.GetCurrentSeasonInfo().Season == ESeason.UNDEFINED)
			{
				yield return null;
			}
			if (this._homeButtonView != null && this._homeButtonView.isActiveAndEnabled)
			{
				this._homeButtonView.ShowSeasonButton(this._seasonService.GetCurrentSeasonInfo());
			}
			yield break;
		}

		// Token: 0x06000C66 RID: 3174 RVA: 0x0004B070 File Offset: 0x00049270
		private void OnClassSelected(EHeroClass heroClass)
		{
			SeasonInfo currentSeasonInfo = this._seasonService.GetCurrentSeasonInfo();
			MasterGenerator generatorForSeason = this._seasonService.GetGeneratorForSeason(currentSeasonInfo.Season);
			Lockbox lockboxForClass = generatorForSeason.GetLockboxForClass(heroClass);
			if (lockboxForClass == null)
			{
				this._skinsView.SetAvailableSkins(null);
			}
			else
			{
				List<WeaponSkinData> list = lockboxForClass.ItemDropList.Select((WeaponDropItem skinDrop) => new WeaponSkinData(skinDrop.WeaponIndex, skinDrop.SkinName, true)).ToList<WeaponSkinData>();
				this._skinsView.SetAvailableSkins(list);
			}
			this._skinsView.SetClass(currentSeasonInfo.Season, heroClass);
		}

		// Token: 0x06000C67 RID: 3175 RVA: 0x0000A6BD File Offset: 0x000088BD
		private void OnSkinSelected(WeaponSkinData skinData)
		{
			this._skinsView.SelectSkin(skinData);
		}

		// Token: 0x04000F71 RID: 3953
		private readonly SeasonService _seasonService;

		// Token: 0x04000F72 RID: 3954
		private SeasonHomeButtonView _homeButtonView;

		// Token: 0x04000F73 RID: 3955
		private SeasonInfoSkinsView _skinsView;
	}
}
