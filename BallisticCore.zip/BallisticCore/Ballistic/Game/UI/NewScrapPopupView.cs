﻿using System;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002F7 RID: 759
	public class NewScrapPopupView : BaseView<PopupController>
	{
		// Token: 0x06000FCD RID: 4045 RVA: 0x0005CFA0 File Offset: 0x0005B1A0
		internal void SetData(ScrapData data)
		{
			this.GoldScrapRoot.SetActive(data.SteamItem.IdentityId == 910);
			this.NormalScrapRoot.SetActive(data.SteamItem.IdentityId == 900);
			this.ScrapAmount.text = "x " + data.Amount.ToString();
			this.Description.text = data.CurrentName;
			this.MissionAccomplished.SetActive(data.Visible);
		}

		// Token: 0x040014F7 RID: 5367
		public GameObject GoldScrapRoot;

		// Token: 0x040014F8 RID: 5368
		public GameObject NormalScrapRoot;

		// Token: 0x040014F9 RID: 5369
		public Text ScrapAmount;

		// Token: 0x040014FA RID: 5370
		public Text Description;

		// Token: 0x040014FB RID: 5371
		public GameObject MissionAccomplished;
	}
}
