﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000313 RID: 787
	public class SoldiersArsenalView : BaseView<SoldiersController>
	{
		// Token: 0x06001099 RID: 4249 RVA: 0x0000DA6A File Offset: 0x0000BC6A
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._progressionService = ServiceProvider.GetService<ProgressionService>();
			this.HeroLoadoutName.onEndEdit.AddListener(new UnityAction<string>(this.OnLoadoutNameChanged));
		}

		// Token: 0x0600109A RID: 4250 RVA: 0x0000DAA4 File Offset: 0x0000BCA4
		private void OnLoadoutNameChanged(string loadoutName)
		{
			base._controller.DispatchLoadoutNameChanged(loadoutName, this._loadout);
		}

		// Token: 0x0600109B RID: 4251 RVA: 0x0000DAB8 File Offset: 0x0000BCB8
		internal void SetStartData(PlayerHeroData playerHero, string loadoutName, HeroSkin heroSkin, Dictionary<EHeroItemSlot, PlayerWeaponData> loadoutData, PlayerLoadoutData loadout)
		{
			this._playerHero = playerHero;
			this._loadoutName = loadoutName;
			this._heroSkin = heroSkin;
			this._loadoutData = loadoutData;
			this._loadout = loadout;
			this.ChangeDataComplete();
		}

		// Token: 0x0600109C RID: 4252 RVA: 0x0000DAE5 File Offset: 0x0000BCE5
		internal void SetData(PlayerHeroData playerHero, string loadoutName, HeroSkin heroSkin, Dictionary<EHeroItemSlot, PlayerWeaponData> loadoutData, PlayerLoadoutData loadout)
		{
			this._playerHero = playerHero;
			this._loadoutName = loadoutName;
			this._heroSkin = heroSkin;
			this._loadoutData = loadoutData;
			this._loadout = loadout;
		}

		// Token: 0x0600109D RID: 4253 RVA: 0x000604CC File Offset: 0x0005E6CC
		public void ChangeDataComplete()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.HeroLoadoutName != null)
			{
				this.HeroLoadoutName.text = this._loadoutName;
				this.HeroLoadoutName.ForceLabelUpdate();
			}
			if (this.HeroLevelText != null)
			{
				this.HeroLevelText.text = ServiceProvider.GetService<LocalizationService>().Get("level", ELocalizedTextCase.UPPER_CASE) + " " + this._progressionService.GetHeroClassLevel(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
			}
			int heroClassLevelXp = this._progressionService.GetHeroClassLevelXp(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
			int heroClassMaxLevelXp = this._progressionService.GetHeroClassMaxLevelXp(this._playerHero.GameItemData.GameItem.UniqueIdentifier);
			if (this.HeroXpText != null)
			{
				this.HeroXpText.text = heroClassLevelXp.ToString() + "/" + heroClassMaxLevelXp.ToString();
			}
			if (this.HeroProgressBar != null)
			{
				this.HeroProgressBar.material.SetFloat("_Scroll", (float)heroClassLevelXp / (float)((heroClassMaxLevelXp <= 0) ? 1 : heroClassMaxLevelXp));
			}
			if (this.HeroLoadout != null)
			{
				this.HeroLoadout.UpdateLoadoutInfo(this._loadoutName, this._heroSkin, null, this._loadoutData, this._loadout.PlayerItem, null, null);
			}
		}

		// Token: 0x0600109E RID: 4254 RVA: 0x0000DB0C File Offset: 0x0000BD0C
		public void OnLoadoutChangeAnimEnd()
		{
			this.ChangeDataComplete();
		}

		// Token: 0x040015D2 RID: 5586
		private ProgressionService _progressionService;

		// Token: 0x040015D3 RID: 5587
		public Text HeroLevelText;

		// Token: 0x040015D4 RID: 5588
		public Text HeroXpText;

		// Token: 0x040015D5 RID: 5589
		public MeshRenderer HeroProgressBar;

		// Token: 0x040015D6 RID: 5590
		public SoldiersLoadoutComponent HeroLoadout;

		// Token: 0x040015D7 RID: 5591
		public InputField HeroLoadoutName;

		// Token: 0x040015D8 RID: 5592
		private PlayerHeroData _playerHero;

		// Token: 0x040015D9 RID: 5593
		private string _loadoutName;

		// Token: 0x040015DA RID: 5594
		private HeroSkin _heroSkin;

		// Token: 0x040015DB RID: 5595
		private Dictionary<EHeroItemSlot, PlayerWeaponData> _loadoutData;

		// Token: 0x040015DC RID: 5596
		private PlayerLoadoutData _loadout;
	}
}
