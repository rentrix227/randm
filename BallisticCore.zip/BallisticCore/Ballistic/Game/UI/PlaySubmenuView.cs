﻿using System;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002F9 RID: 761
	public class PlaySubmenuView : BaseView<PlaySubmenuController>
	{
	}
}
