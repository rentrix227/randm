﻿using System;
using System.Globalization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200030A RID: 778
	public class SettingsControlsView : BaseView<SettingsController>
	{
		// Token: 0x0600101F RID: 4127 RVA: 0x0005E3F8 File Offset: 0x0005C5F8
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			SettingsKeyDefineComponent forwardButton = this.ForwardButton;
			forwardButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(forwardButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent forwardButton2 = this.ForwardButton;
			forwardButton2.OnKeyCancelled = (Action)Delegate.Combine(forwardButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent backButton = this.BackButton;
			backButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(backButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent backButton2 = this.BackButton;
			backButton2.OnKeyCancelled = (Action)Delegate.Combine(backButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent leftButton = this.LeftButton;
			leftButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(leftButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent leftButton2 = this.LeftButton;
			leftButton2.OnKeyCancelled = (Action)Delegate.Combine(leftButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent rightButton = this.RightButton;
			rightButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(rightButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent rightButton2 = this.RightButton;
			rightButton2.OnKeyCancelled = (Action)Delegate.Combine(rightButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent jumpButton = this.JumpButton;
			jumpButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(jumpButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent jumpButton2 = this.JumpButton;
			jumpButton2.OnKeyCancelled = (Action)Delegate.Combine(jumpButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent sprintButton = this.SprintButton;
			sprintButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(sprintButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent sprintButton2 = this.SprintButton;
			sprintButton2.OnKeyCancelled = (Action)Delegate.Combine(sprintButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent crouchButton = this.CrouchButton;
			crouchButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(crouchButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent crouchButton2 = this.CrouchButton;
			crouchButton2.OnKeyCancelled = (Action)Delegate.Combine(crouchButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent shootButton = this.ShootButton;
			shootButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(shootButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent shootButton2 = this.ShootButton;
			shootButton2.OnKeyCancelled = (Action)Delegate.Combine(shootButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent aimButton = this.AimButton;
			aimButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(aimButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent aimButton2 = this.AimButton;
			aimButton2.OnKeyCancelled = (Action)Delegate.Combine(aimButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent primaryWeaponButton = this.PrimaryWeaponButton;
			primaryWeaponButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(primaryWeaponButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent primaryWeaponButton2 = this.PrimaryWeaponButton;
			primaryWeaponButton2.OnKeyCancelled = (Action)Delegate.Combine(primaryWeaponButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent secondaryWeaponButton = this.SecondaryWeaponButton;
			secondaryWeaponButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(secondaryWeaponButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent secondaryWeaponButton2 = this.SecondaryWeaponButton;
			secondaryWeaponButton2.OnKeyCancelled = (Action)Delegate.Combine(secondaryWeaponButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent alternateFunctionButton = this.AlternateFunctionButton;
			alternateFunctionButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(alternateFunctionButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent alternateFunctionButton2 = this.AlternateFunctionButton;
			alternateFunctionButton2.OnKeyCancelled = (Action)Delegate.Combine(alternateFunctionButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent grenadeButton = this.GrenadeButton;
			grenadeButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(grenadeButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent grenadeButton2 = this.GrenadeButton;
			grenadeButton2.OnKeyCancelled = (Action)Delegate.Combine(grenadeButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent meleeButton = this.MeleeButton;
			meleeButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(meleeButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent meleeButton2 = this.MeleeButton;
			meleeButton2.OnKeyCancelled = (Action)Delegate.Combine(meleeButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent reloadButton = this.ReloadButton;
			reloadButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(reloadButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent reloadButton2 = this.ReloadButton;
			reloadButton2.OnKeyCancelled = (Action)Delegate.Combine(reloadButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent quickSwapButton = this.QuickSwapButton;
			quickSwapButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(quickSwapButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent quickSwapButton2 = this.QuickSwapButton;
			quickSwapButton2.OnKeyCancelled = (Action)Delegate.Combine(quickSwapButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent teamChatButton = this.TeamChatButton;
			teamChatButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(teamChatButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent teamChatButton2 = this.TeamChatButton;
			teamChatButton2.OnKeyCancelled = (Action)Delegate.Combine(teamChatButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent generalChatButton = this.GeneralChatButton;
			generalChatButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(generalChatButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent generalChatButton2 = this.GeneralChatButton;
			generalChatButton2.OnKeyCancelled = (Action)Delegate.Combine(generalChatButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent scoreBoardButton = this.ScoreBoardButton;
			scoreBoardButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(scoreBoardButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent scoreBoardButton2 = this.ScoreBoardButton;
			scoreBoardButton2.OnKeyCancelled = (Action)Delegate.Combine(scoreBoardButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent menuButton = this.MenuButton;
			menuButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(menuButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent menuButton2 = this.MenuButton;
			menuButton2.OnKeyCancelled = (Action)Delegate.Combine(menuButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent suicideButton = this.SuicideButton;
			suicideButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(suicideButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent suicideButton2 = this.SuicideButton;
			suicideButton2.OnKeyCancelled = (Action)Delegate.Combine(suicideButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent voiceButton = this.VoiceButton;
			voiceButton.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(voiceButton.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent voiceButton2 = this.VoiceButton;
			voiceButton2.OnKeyCancelled = (Action)Delegate.Combine(voiceButton2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent voiceCommandMove = this.VoiceCommandMove;
			voiceCommandMove.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(voiceCommandMove.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent voiceCommandMove2 = this.VoiceCommandMove;
			voiceCommandMove2.OnKeyCancelled = (Action)Delegate.Combine(voiceCommandMove2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent voiceCommandFollow = this.VoiceCommandFollow;
			voiceCommandFollow.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(voiceCommandFollow.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent voiceCommandFollow2 = this.VoiceCommandFollow;
			voiceCommandFollow2.OnKeyCancelled = (Action)Delegate.Combine(voiceCommandFollow2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent voiceCommandLaugh = this.VoiceCommandLaugh;
			voiceCommandLaugh.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(voiceCommandLaugh.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent voiceCommandLaugh2 = this.VoiceCommandLaugh;
			voiceCommandLaugh2.OnKeyCancelled = (Action)Delegate.Combine(voiceCommandLaugh2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent voiceCommandHelp = this.VoiceCommandHelp;
			voiceCommandHelp.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(voiceCommandHelp.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent voiceCommandHelp2 = this.VoiceCommandHelp;
			voiceCommandHelp2.OnKeyCancelled = (Action)Delegate.Combine(voiceCommandHelp2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent voiceCommandDefend = this.VoiceCommandDefend;
			voiceCommandDefend.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(voiceCommandDefend.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent voiceCommandDefend2 = this.VoiceCommandDefend;
			voiceCommandDefend2.OnKeyCancelled = (Action)Delegate.Combine(voiceCommandDefend2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			SettingsKeyDefineComponent voiceCommandTaunt = this.VoiceCommandTaunt;
			voiceCommandTaunt.OnKeyBound = (Action<KeyType, KeyCode>)Delegate.Combine(voiceCommandTaunt.OnKeyBound, new Action<KeyType, KeyCode>(this.OnKeyBound));
			SettingsKeyDefineComponent voiceCommandTaunt2 = this.VoiceCommandTaunt;
			voiceCommandTaunt2.OnKeyCancelled = (Action)Delegate.Combine(voiceCommandTaunt2.OnKeyCancelled, new Action(SettingsControlsView.OnKeyCancelled));
			this.SensitivityMinusButton.onClick.AddListener(new UnityAction(this.OnSensitivityMinusClick));
			this.SensitivityPlusButton.onClick.AddListener(new UnityAction(this.OnSensitivityPlusClick));
			this.SensitivitySlider.onValueChanged.AddListener(new UnityAction<float>(this.OnSensitivitySliderChange));
			this.SensitivityIronSightMinusButton.onClick.AddListener(new UnityAction(this.OnSensitivityIronSightMinusClick));
			this.SensitivityIronSightPlusButton.onClick.AddListener(new UnityAction(this.OnSensitivityIronSightPlusClick));
			this.SensitivityIronSightSlider.onValueChanged.AddListener(new UnityAction<float>(this.OnSensitivityIronSightSliderChange));
			this.SensitivityTelescopicMinusButton.onClick.AddListener(new UnityAction(this.OnSensitivityTelescopicMinusClick));
			this.SensitivityTelescopicPlusButton.onClick.AddListener(new UnityAction(this.OnSensitivityTelescopicPlusClick));
			this.SensitivityTelescopicSlider.onValueChanged.AddListener(new UnityAction<float>(this.OnSensitivityTelescopicSliderChange));
			this.FovMinusButton.onClick.AddListener(new UnityAction(this.OnFovMinusClick));
			this.FovPlusButton.onClick.AddListener(new UnityAction(this.OnFovPlusClick));
			this.FovSlider.onValueChanged.AddListener(new UnityAction<float>(this.OnFovSliderChange));
			this.InvertAimToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnInvertAimChange));
			this.SprintToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSprintToggleChange));
			this.AimToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnAimChange));
			this.CrouchToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnCrouchChange));
			this.UseMouseWheel.onValueChanged.AddListener(new UnityAction<bool>(this.OnUseMouseWheel));
		}

		// Token: 0x06001020 RID: 4128 RVA: 0x0000D471 File Offset: 0x0000B671
		internal void SetInvertAim(bool value)
		{
			this.InvertAimToggle.isOn = value;
		}

		// Token: 0x06001021 RID: 4129 RVA: 0x0000D47F File Offset: 0x0000B67F
		internal void SetSprintToggle(bool value)
		{
			this.SprintToggle.isOn = value;
		}

		// Token: 0x06001022 RID: 4130 RVA: 0x0000D48D File Offset: 0x0000B68D
		internal void SetAim(bool value)
		{
			this.AimToggle.isOn = value;
		}

		// Token: 0x06001023 RID: 4131 RVA: 0x0000D49B File Offset: 0x0000B69B
		internal void SetCrouch(bool value)
		{
			this.CrouchToggle.isOn = value;
		}

		// Token: 0x06001024 RID: 4132 RVA: 0x0000D4A9 File Offset: 0x0000B6A9
		internal void SetSensitivitySlider(float value)
		{
			this.SensitivitySlider.value = value;
			this.UpdateSensitivityText();
		}

		// Token: 0x06001025 RID: 4133 RVA: 0x0000D4BD File Offset: 0x0000B6BD
		internal void SetSensitivityIronSightSlider(float value)
		{
			this.SensitivityIronSightSlider.value = value;
			this.UpdateSensitivityIronSightText();
		}

		// Token: 0x06001026 RID: 4134 RVA: 0x0000D4D1 File Offset: 0x0000B6D1
		internal void SetSensitivityTelescopicSlider(float value)
		{
			this.SensitivityTelescopicSlider.value = value;
			this.UpdateSensitivityTelescopicText();
		}

		// Token: 0x06001027 RID: 4135 RVA: 0x0000D4E5 File Offset: 0x0000B6E5
		internal void SetFovSlider(float value)
		{
			this.FovSlider.value = value;
			this.UpdateFovText();
		}

		// Token: 0x06001028 RID: 4136 RVA: 0x0000D4F9 File Offset: 0x0000B6F9
		internal void SetUseMouseWheel(bool value)
		{
			this.UseMouseWheel.isOn = value;
		}

		// Token: 0x06001029 RID: 4137 RVA: 0x0000D507 File Offset: 0x0000B707
		private void OnInvertAimChange(bool value)
		{
			this._optionControlService.Container.InvertMouse = this.InvertAimToggle.isOn;
		}

		// Token: 0x0600102A RID: 4138 RVA: 0x0000D524 File Offset: 0x0000B724
		private void OnSprintToggleChange(bool value)
		{
			this._optionControlService.Container.ToggleSprint = this.SprintToggle.isOn;
		}

		// Token: 0x0600102B RID: 4139 RVA: 0x0000D541 File Offset: 0x0000B741
		private void OnAimChange(bool value)
		{
			this._optionControlService.Container.ToggleAim = this.AimToggle.isOn;
		}

		// Token: 0x0600102C RID: 4140 RVA: 0x0000D55E File Offset: 0x0000B75E
		private void OnCrouchChange(bool value)
		{
			this._optionControlService.Container.ToggleCrouch = this.CrouchToggle.isOn;
		}

		// Token: 0x0600102D RID: 4141 RVA: 0x0000D57B File Offset: 0x0000B77B
		private void OnSensitivitySliderChange(float value)
		{
			this._optionControlService.Container.MouseSensitivityNormal = Mathf.Clamp(value, 0f, 1f);
			this.UpdateSensitivityText();
		}

		// Token: 0x0600102E RID: 4142 RVA: 0x0000D5A3 File Offset: 0x0000B7A3
		private void OnSensitivityIronSightSliderChange(float value)
		{
			this._optionControlService.Container.MouseSensitivityIronSight = Mathf.Clamp(value, 0f, 1f);
			this.UpdateSensitivityIronSightText();
		}

		// Token: 0x0600102F RID: 4143 RVA: 0x0000D5CB File Offset: 0x0000B7CB
		private void OnSensitivityTelescopicSliderChange(float value)
		{
			this._optionControlService.Container.MouseSensitivityTelescopic = Mathf.Clamp(value, 0f, 1f);
			this.UpdateSensitivityTelescopicText();
		}

		// Token: 0x06001030 RID: 4144 RVA: 0x0000D5F3 File Offset: 0x0000B7F3
		private void OnFovSliderChange(float value)
		{
			this._optionControlService.Container.NormalStageFov = (int)this.FovSlider.value;
			this.UpdateFovText();
		}

		// Token: 0x06001031 RID: 4145 RVA: 0x0005F064 File Offset: 0x0005D264
		private void OnSensitivityMinusClick()
		{
			this.SensitivitySlider.value -= 0.01f;
			this._optionControlService.Container.MouseSensitivityNormal = Mathf.Clamp(this.SensitivitySlider.value, 0f, 1f);
			this.UpdateSensitivityText();
		}

		// Token: 0x06001032 RID: 4146 RVA: 0x0005F0B8 File Offset: 0x0005D2B8
		private void OnSensitivityPlusClick()
		{
			this.SensitivitySlider.value += 0.01f;
			this._optionControlService.Container.MouseSensitivityNormal = Mathf.Clamp(this.SensitivitySlider.value, 0f, 1f);
			this.UpdateSensitivityText();
		}

		// Token: 0x06001033 RID: 4147 RVA: 0x0005F10C File Offset: 0x0005D30C
		private void OnSensitivityIronSightMinusClick()
		{
			this.SensitivityIronSightSlider.value -= 0.01f;
			this._optionControlService.Container.MouseSensitivityIronSight = Mathf.Clamp(this.SensitivityIronSightSlider.value, 0f, 1f);
			this.UpdateSensitivityIronSightText();
		}

		// Token: 0x06001034 RID: 4148 RVA: 0x0005F160 File Offset: 0x0005D360
		private void OnSensitivityIronSightPlusClick()
		{
			this.SensitivityIronSightSlider.value += 0.01f;
			this._optionControlService.Container.MouseSensitivityIronSight = Mathf.Clamp(this.SensitivityIronSightSlider.value, 0f, 1f);
			this.UpdateSensitivityIronSightText();
		}

		// Token: 0x06001035 RID: 4149 RVA: 0x0005F1B4 File Offset: 0x0005D3B4
		private void OnSensitivityTelescopicMinusClick()
		{
			this.SensitivityTelescopicSlider.value -= 0.01f;
			this._optionControlService.Container.MouseSensitivityTelescopic = Mathf.Clamp(this.SensitivityTelescopicSlider.value, 0f, 1f);
			this.UpdateSensitivityTelescopicText();
		}

		// Token: 0x06001036 RID: 4150 RVA: 0x0005F208 File Offset: 0x0005D408
		private void OnSensitivityTelescopicPlusClick()
		{
			this.SensitivityTelescopicSlider.value += 0.01f;
			this._optionControlService.Container.MouseSensitivityTelescopic = Mathf.Clamp(this.SensitivityTelescopicSlider.value, 0f, 1f);
			this.UpdateSensitivityTelescopicText();
		}

		// Token: 0x06001037 RID: 4151 RVA: 0x0000D617 File Offset: 0x0000B817
		private void OnFovMinusClick()
		{
			this.FovSlider.value -= 5f;
			this._optionControlService.Container.NormalStageFov = (int)this.FovSlider.value;
			this.UpdateFovText();
		}

		// Token: 0x06001038 RID: 4152 RVA: 0x0000D652 File Offset: 0x0000B852
		private void OnFovPlusClick()
		{
			this.FovSlider.value += 5f;
			this._optionControlService.Container.NormalStageFov = (int)this.FovSlider.value;
			this.UpdateFovText();
		}

		// Token: 0x06001039 RID: 4153 RVA: 0x0000D68D File Offset: 0x0000B88D
		private void OnUseMouseWheel(bool value)
		{
			this._optionControlService.Container.MouseWheel = value;
		}

		// Token: 0x0600103A RID: 4154 RVA: 0x0005F25C File Offset: 0x0005D45C
		private void OnKeyBound(KeyType type, KeyCode code)
		{
			OptionControlContainer container = ServiceProvider.GetService<OptionControlService>().Container;
			container.RemoveKeys(code);
			container[type] = code;
			this.UpdateKeysText();
		}

		// Token: 0x0600103B RID: 4155 RVA: 0x00002A31 File Offset: 0x00000C31
		private static void OnKeyCancelled()
		{
		}

		// Token: 0x0600103C RID: 4156 RVA: 0x0005F28C File Offset: 0x0005D48C
		private void UpdateSensitivityText()
		{
			this.SensitivityText.text = this.SensitivitySlider.value.ToString("0.00");
		}

		// Token: 0x0600103D RID: 4157 RVA: 0x0005F2BC File Offset: 0x0005D4BC
		private void UpdateSensitivityIronSightText()
		{
			this.SensitivityIronSightText.text = this.SensitivityIronSightSlider.value.ToString("0.00");
		}

		// Token: 0x0600103E RID: 4158 RVA: 0x0005F2EC File Offset: 0x0005D4EC
		private void UpdateSensitivityTelescopicText()
		{
			this.SensitivityTelescopicText.text = this.SensitivityTelescopicSlider.value.ToString("0.00");
		}

		// Token: 0x0600103F RID: 4159 RVA: 0x0005F31C File Offset: 0x0005D51C
		private void UpdateFovText()
		{
			this.FovText.text = this.FovSlider.value.ToString(CultureInfo.InvariantCulture);
		}

		// Token: 0x06001040 RID: 4160 RVA: 0x0005F34C File Offset: 0x0005D54C
		internal void UpdateKeysText()
		{
			this.ForwardButton.SetupType(KeyType.FORWARD);
			this.BackButton.SetupType(KeyType.BACKWARD);
			this.LeftButton.SetupType(KeyType.LEFT);
			this.RightButton.SetupType(KeyType.RIGHT);
			this.JumpButton.SetupType(KeyType.JUMP);
			this.SprintButton.SetupType(KeyType.SPRINT);
			this.CrouchButton.SetupType(KeyType.CROUCH);
			this.ShootButton.SetupType(KeyType.SHOOT);
			this.AimButton.SetupType(KeyType.AIM);
			this.PrimaryWeaponButton.SetupType(KeyType.GET_PRIMARY_WEAPON);
			this.SecondaryWeaponButton.SetupType(KeyType.GET_SECONDARY_WEAPON);
			this.AlternateFunctionButton.SetupType(KeyType.WEAPON_SECOND_FUNCTION);
			this.GrenadeButton.SetupType(KeyType.GRENADE);
			this.MeleeButton.SetupType(KeyType.MELEE);
			this.ReloadButton.SetupType(KeyType.RELOAD);
			this.QuickSwapButton.SetupType(KeyType.QUICK_CHANGE_WEAPON);
			this.TeamChatButton.SetupType(KeyType.CHAT_TEAM);
			this.GeneralChatButton.SetupType(KeyType.CHAT_ALL);
			this.ScoreBoardButton.SetupType(KeyType.SCORES);
			this.MenuButton.SetupType(KeyType.MENU);
			this.SuicideButton.SetupType(KeyType.SUICIDE);
			this.VoiceButton.SetupType(KeyType.VOICE_WHEEL);
			this.VoiceCommandMove.SetupType(KeyType.VOICE_MOVE);
			this.VoiceCommandFollow.SetupType(KeyType.VOICE_FOLLOW);
			this.VoiceCommandLaugh.SetupType(KeyType.VOICE_LAUGH);
			this.VoiceCommandHelp.SetupType(KeyType.VOICE_HELP);
			this.VoiceCommandDefend.SetupType(KeyType.VOICE_DEFEND);
			this.VoiceCommandTaunt.SetupType(KeyType.VOICE_TAUNT);
		}

		// Token: 0x0400154F RID: 5455
		public Button SensitivityMinusButton;

		// Token: 0x04001550 RID: 5456
		public Button SensitivityPlusButton;

		// Token: 0x04001551 RID: 5457
		public Slider SensitivitySlider;

		// Token: 0x04001552 RID: 5458
		public Text SensitivityText;

		// Token: 0x04001553 RID: 5459
		public Button FovMinusButton;

		// Token: 0x04001554 RID: 5460
		public Button FovPlusButton;

		// Token: 0x04001555 RID: 5461
		public Slider FovSlider;

		// Token: 0x04001556 RID: 5462
		public Text FovText;

		// Token: 0x04001557 RID: 5463
		public Button SensitivityIronSightMinusButton;

		// Token: 0x04001558 RID: 5464
		public Button SensitivityIronSightPlusButton;

		// Token: 0x04001559 RID: 5465
		public Slider SensitivityIronSightSlider;

		// Token: 0x0400155A RID: 5466
		public Text SensitivityIronSightText;

		// Token: 0x0400155B RID: 5467
		public Button SensitivityTelescopicMinusButton;

		// Token: 0x0400155C RID: 5468
		public Button SensitivityTelescopicPlusButton;

		// Token: 0x0400155D RID: 5469
		public Slider SensitivityTelescopicSlider;

		// Token: 0x0400155E RID: 5470
		public Text SensitivityTelescopicText;

		// Token: 0x0400155F RID: 5471
		public Toggle InvertAimToggle;

		// Token: 0x04001560 RID: 5472
		public Toggle SprintToggle;

		// Token: 0x04001561 RID: 5473
		public SettingsKeyDefineComponent ForwardButton;

		// Token: 0x04001562 RID: 5474
		public SettingsKeyDefineComponent BackButton;

		// Token: 0x04001563 RID: 5475
		public SettingsKeyDefineComponent LeftButton;

		// Token: 0x04001564 RID: 5476
		public SettingsKeyDefineComponent RightButton;

		// Token: 0x04001565 RID: 5477
		public SettingsKeyDefineComponent JumpButton;

		// Token: 0x04001566 RID: 5478
		public SettingsKeyDefineComponent SprintButton;

		// Token: 0x04001567 RID: 5479
		public SettingsKeyDefineComponent CrouchButton;

		// Token: 0x04001568 RID: 5480
		public Toggle CrouchToggle;

		// Token: 0x04001569 RID: 5481
		public SettingsKeyDefineComponent ShootButton;

		// Token: 0x0400156A RID: 5482
		public SettingsKeyDefineComponent AimButton;

		// Token: 0x0400156B RID: 5483
		public Toggle AimToggle;

		// Token: 0x0400156C RID: 5484
		public SettingsKeyDefineComponent PrimaryWeaponButton;

		// Token: 0x0400156D RID: 5485
		public SettingsKeyDefineComponent SecondaryWeaponButton;

		// Token: 0x0400156E RID: 5486
		public SettingsKeyDefineComponent AlternateFunctionButton;

		// Token: 0x0400156F RID: 5487
		public SettingsKeyDefineComponent GrenadeButton;

		// Token: 0x04001570 RID: 5488
		public SettingsKeyDefineComponent MeleeButton;

		// Token: 0x04001571 RID: 5489
		public SettingsKeyDefineComponent ReloadButton;

		// Token: 0x04001572 RID: 5490
		public SettingsKeyDefineComponent QuickSwapButton;

		// Token: 0x04001573 RID: 5491
		public SettingsKeyDefineComponent TeamChatButton;

		// Token: 0x04001574 RID: 5492
		public SettingsKeyDefineComponent GeneralChatButton;

		// Token: 0x04001575 RID: 5493
		public SettingsKeyDefineComponent ScoreBoardButton;

		// Token: 0x04001576 RID: 5494
		public SettingsKeyDefineComponent MenuButton;

		// Token: 0x04001577 RID: 5495
		public SettingsKeyDefineComponent SuicideButton;

		// Token: 0x04001578 RID: 5496
		public SettingsKeyDefineComponent VoiceButton;

		// Token: 0x04001579 RID: 5497
		public SettingsKeyDefineComponent VoiceCommandMove;

		// Token: 0x0400157A RID: 5498
		public SettingsKeyDefineComponent VoiceCommandFollow;

		// Token: 0x0400157B RID: 5499
		public SettingsKeyDefineComponent VoiceCommandLaugh;

		// Token: 0x0400157C RID: 5500
		public SettingsKeyDefineComponent VoiceCommandHelp;

		// Token: 0x0400157D RID: 5501
		public SettingsKeyDefineComponent VoiceCommandDefend;

		// Token: 0x0400157E RID: 5502
		public SettingsKeyDefineComponent VoiceCommandTaunt;

		// Token: 0x0400157F RID: 5503
		public Toggle UseMouseWheel;

		// Token: 0x04001580 RID: 5504
		private OptionControlService _optionControlService;

		// Token: 0x04001581 RID: 5505
		private const float _sensivityStep = 0.01f;
	}
}
