﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000213 RID: 531
	public class CreditsController : BaseController
	{
		// Token: 0x06000AAA RID: 2730 RVA: 0x000098C3 File Offset: 0x00007AC3
		public CreditsController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
		}

		// Token: 0x06000AAB RID: 2731 RVA: 0x000098E1 File Offset: 0x00007AE1
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._eventProxy.EUpdate.RemoveListener(new Action(this.OnUpdate));
		}

		// Token: 0x06000AAC RID: 2732 RVA: 0x0003E348 File Offset: 0x0003C548
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			CreditsView creditsView = view as CreditsView;
			if (creditsView != null)
			{
				this._eventProxy.EUpdate.AddListener(new Action(this.OnUpdate));
			}
		}

		// Token: 0x06000AAD RID: 2733 RVA: 0x0003E398 File Offset: 0x0003C598
		public override void OnHide(AbstractView view)
		{
			base.OnHide(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			CreditsView creditsView = view as CreditsView;
			if (creditsView != null)
			{
				this._eventProxy.EUpdate.RemoveListener(new Action(this.OnUpdate));
			}
		}

		// Token: 0x06000AAE RID: 2734 RVA: 0x0003E3E8 File Offset: 0x0003C5E8
		private void OnUpdate()
		{
			if (!Input.GetMouseButton(0))
			{
				CreditsView view = base.GetView<CreditsView>();
				if (view != null)
				{
					view.ScrollUp(Time.deltaTime);
				}
			}
		}

		// Token: 0x04000E47 RID: 3655
		private readonly EventProxy _eventProxy;
	}
}
