﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.DataModel.ItemModel.GameItemModel.Reward;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200024A RID: 586
	internal class RewardPackData
	{
		// Token: 0x04000F6B RID: 3947
		internal Reward reward;

		// Token: 0x04000F6C RID: 3948
		internal SteamItem steamItem;
	}
}
