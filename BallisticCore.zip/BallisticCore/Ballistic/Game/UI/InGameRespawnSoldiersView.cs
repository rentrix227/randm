﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002C8 RID: 712
	public class InGameRespawnSoldiersView : BaseView<InGameRespawnController>
	{
		// Token: 0x06000EE8 RID: 3816 RVA: 0x0005A06C File Offset: 0x0005826C
		protected override void Start()
		{
			base.Start();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.BerserkerToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnBerserkerSelected));
			this.VanguardToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnVanguardSelected));
			this.WraithToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnWraithSelected));
			this.ShadowToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnShadowSelected));
			this.TankToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnTankSelected));
			this.GrenadierToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnGrenadierSelected));
			this.MarksmanToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnMarksmanSelected));
			this.SpectatorToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnSpectatorSelected));
		}

		// Token: 0x06000EE9 RID: 3817 RVA: 0x0005A16C File Offset: 0x0005836C
		internal void SetSoldier(bool isSpectator, EClientMode clientMode, HighSpeedArray<EHeroClass> avaliableHeroes, EHeroClass heroClass)
		{
			this._isSetting = true;
			this.BerserkerToggle.interactable = clientMode == EClientMode.PLAYER && avaliableHeroes.Contains(EHeroClass.BERSERKER);
			this.VanguardToggle.interactable = clientMode == EClientMode.PLAYER && avaliableHeroes.Contains(EHeroClass.VANGUARD);
			this.WraithToggle.interactable = clientMode == EClientMode.PLAYER && avaliableHeroes.Contains(EHeroClass.WRAITH);
			this.ShadowToggle.interactable = clientMode == EClientMode.PLAYER && avaliableHeroes.Contains(EHeroClass.SHADOW);
			this.TankToggle.interactable = clientMode == EClientMode.PLAYER && avaliableHeroes.Contains(EHeroClass.TANK);
			this.GrenadierToggle.interactable = clientMode == EClientMode.PLAYER && avaliableHeroes.Contains(EHeroClass.GRENADIER);
			this.MarksmanToggle.interactable = clientMode == EClientMode.PLAYER && avaliableHeroes.Contains(EHeroClass.MARKSMAN);
			this.BerserkerToggle.isOn = !isSpectator && heroClass == EHeroClass.BERSERKER;
			this.VanguardToggle.isOn = !isSpectator && heroClass == EHeroClass.VANGUARD;
			this.WraithToggle.isOn = !isSpectator && heroClass == EHeroClass.WRAITH;
			this.ShadowToggle.isOn = !isSpectator && heroClass == EHeroClass.SHADOW;
			this.TankToggle.isOn = !isSpectator && heroClass == EHeroClass.TANK;
			this.GrenadierToggle.isOn = !isSpectator && heroClass == EHeroClass.GRENADIER;
			this.MarksmanToggle.isOn = !isSpectator && heroClass == EHeroClass.MARKSMAN;
			this.SpectatorToggle.isOn = isSpectator;
			this._isSetting = false;
		}

		// Token: 0x06000EEA RID: 3818 RVA: 0x0000C200 File Offset: 0x0000A400
		private void OnBerserkerSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSoldierChanged(EHeroClass.BERSERKER);
			}
		}

		// Token: 0x06000EEB RID: 3819 RVA: 0x0000C21F File Offset: 0x0000A41F
		private void OnVanguardSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSoldierChanged(EHeroClass.VANGUARD);
			}
		}

		// Token: 0x06000EEC RID: 3820 RVA: 0x0000C23E File Offset: 0x0000A43E
		private void OnWraithSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSoldierChanged(EHeroClass.WRAITH);
			}
		}

		// Token: 0x06000EED RID: 3821 RVA: 0x0000C25D File Offset: 0x0000A45D
		private void OnShadowSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSoldierChanged(EHeroClass.SHADOW);
			}
		}

		// Token: 0x06000EEE RID: 3822 RVA: 0x0000C27C File Offset: 0x0000A47C
		private void OnTankSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSoldierChanged(EHeroClass.TANK);
			}
		}

		// Token: 0x06000EEF RID: 3823 RVA: 0x0000C29B File Offset: 0x0000A49B
		private void OnGrenadierSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSoldierChanged(EHeroClass.GRENADIER);
			}
		}

		// Token: 0x06000EF0 RID: 3824 RVA: 0x0000C2BA File Offset: 0x0000A4BA
		private void OnMarksmanSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSoldierChanged(EHeroClass.MARKSMAN);
			}
		}

		// Token: 0x06000EF1 RID: 3825 RVA: 0x0000C2D9 File Offset: 0x0000A4D9
		private void OnSpectatorSelected(bool value)
		{
			if (value && !this._isSetting)
			{
				base._controller.DispatchSpectatorSelected();
			}
		}

		// Token: 0x06000EF2 RID: 3826 RVA: 0x00002A31 File Offset: 0x00000C31
		public void ChangeDataComplete()
		{
		}

		// Token: 0x04001402 RID: 5122
		public Toggle BerserkerToggle;

		// Token: 0x04001403 RID: 5123
		public Toggle VanguardToggle;

		// Token: 0x04001404 RID: 5124
		public Toggle WraithToggle;

		// Token: 0x04001405 RID: 5125
		public Toggle ShadowToggle;

		// Token: 0x04001406 RID: 5126
		public Toggle TankToggle;

		// Token: 0x04001407 RID: 5127
		public Toggle GrenadierToggle;

		// Token: 0x04001408 RID: 5128
		public Toggle MarksmanToggle;

		// Token: 0x04001409 RID: 5129
		public Toggle SpectatorToggle;

		// Token: 0x0400140A RID: 5130
		private bool _isSetting;
	}
}
