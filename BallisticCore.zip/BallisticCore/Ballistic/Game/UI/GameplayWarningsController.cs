﻿using System;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000220 RID: 544
	public class GameplayWarningsController : BaseController
	{
		// Token: 0x06000B2D RID: 2861 RVA: 0x00009C55 File Offset: 0x00007E55
		public GameplayWarningsController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			ServiceProvider.GetService<EventProxy>().EUpdate.AddListener(new Action(this.Update));
		}

		// Token: 0x06000B2E RID: 2862 RVA: 0x00009C83 File Offset: 0x00007E83
		public override void DisableController()
		{
			base.DisableController();
			ServiceProvider.GetService<EventProxy>().EUpdate.RemoveListener(new Action(this.Update));
		}

		// Token: 0x06000B2F RID: 2863 RVA: 0x00042F2C File Offset: 0x0004112C
		public override void OnShow(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			GameplayWarningsView gameplayWarningsView = view as GameplayWarningsView;
			if (gameplayWarningsView != null)
			{
				this._gameplayWarningsView = gameplayWarningsView;
			}
		}

		// Token: 0x06000B30 RID: 2864 RVA: 0x00009CA6 File Offset: 0x00007EA6
		public override void OnHide(AbstractView view)
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (view is GameplayWarningsView && this._gameplayWarningsView != null)
			{
				this._gameplayWarningsView.ClearWarning();
				this._gameplayWarningsView = null;
			}
		}

		// Token: 0x06000B31 RID: 2865 RVA: 0x00042F60 File Offset: 0x00041160
		public void Update()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this._gameplayWarningsView == null)
			{
				return;
			}
			if (this._gameplayWarningsView.isActiveAndEnabled)
			{
				if (LocalCharacterService.IsPositionOnEnemyArea(ServiceProvider.GetService<LocalCharacterService>().WorldPosition, UserProfile.LocalGameClient.team))
				{
					this._gameplayWarningsView.SetWarning(WarningType.EnemyArea, WarningColor.White);
				}
				else
				{
					this._gameplayWarningsView.ClearWarning();
				}
			}
		}

		// Token: 0x04000EB0 RID: 3760
		private const float _distanceToTriggerEnemyAreaWarning = 10f;

		// Token: 0x04000EB1 RID: 3761
		private GameplayWarningsView _gameplayWarningsView;
	}
}
