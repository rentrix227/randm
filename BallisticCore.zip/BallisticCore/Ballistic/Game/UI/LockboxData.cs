﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.Lockbox;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200023D RID: 573
	internal class LockboxData : SteamItemData
	{
		// Token: 0x04000F4C RID: 3916
		internal Lockbox Lockbox;
	}
}
