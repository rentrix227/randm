﻿using System;
using System.Linq;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Services;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200022C RID: 556
	public class InGameMatchTimeController : BaseController
	{
		// Token: 0x06000BBC RID: 3004 RVA: 0x000473FC File Offset: 0x000455FC
		public InGameMatchTimeController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnTimeRemaining.AddListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnUserListChanged.AddListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			ServiceProvider.GetService<EventProxy>().EUpdate.AddListener(new Action(this.Update));
		}

		// Token: 0x06000BBD RID: 3005 RVA: 0x00047478 File Offset: 0x00045678
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnTimeRemaining.RemoveListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnUserListChanged.RemoveListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			ServiceProvider.GetService<EventProxy>().EUpdate.RemoveListener(new Action(this.Update));
		}

		// Token: 0x06000BBE RID: 3006 RVA: 0x000474EC File Offset: 0x000456EC
		public void Update()
		{
			InGameServerInfoView view = base.GetView<InGameServerInfoView>();
			if (view != null && view.isActiveAndEnabled)
			{
				if (this._networkGameService.BallisticClient == null)
				{
					return;
				}
				if (this._networkGameService.BallisticClient.Latency != this._lastPing)
				{
					this._lastPing = this._networkGameService.BallisticClient.Latency;
					view.SetPingData(this._networkGameService.BallisticClient.Latency);
				}
			}
		}

		// Token: 0x06000BBF RID: 3007 RVA: 0x00047570 File Offset: 0x00045770
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			InGameServerInfoView inGameServerInfoView = view as InGameServerInfoView;
			if (inGameServerInfoView != null)
			{
				GameConfig gameConfig = this._networkGameService.GetGameModeMetaData().GameConfig;
				inGameServerInfoView.SetServerData(gameConfig.ServerName, gameConfig.ServerType, false, ServiceProvider.GetService<ServerInfoService>().BannerTexture);
			}
			InGameSpectatorCountView inGameSpectatorCountView = view as InGameSpectatorCountView;
			if (inGameSpectatorCountView != null)
			{
				inGameSpectatorCountView.SetData(this._networkGameService.GameClients.Count((GameClient t) => t.clientMode == EClientMode.SPECTATOR));
			}
		}

		// Token: 0x06000BC0 RID: 3008 RVA: 0x00047618 File Offset: 0x00045818
		private void OnUserListChanged(UserListChangedEvent userListChangedEvent)
		{
			InGameSpectatorCountView view = base.GetView<InGameSpectatorCountView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.SetData(this._networkGameService.GameClients.Count((GameClient t) => t.clientMode == EClientMode.SPECTATOR));
			}
		}

		// Token: 0x06000BC1 RID: 3009 RVA: 0x00047678 File Offset: 0x00045878
		private void OnTimeRemaining(TimeRemainingEvent evt)
		{
			InGameMatchTimeView view = base.GetView<InGameMatchTimeView>();
			if (view != null && view.isActiveAndEnabled)
			{
				view.UpdateTimeRemaining(this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, (int)evt.RemainingTime);
			}
		}

		// Token: 0x04000F00 RID: 3840
		private readonly NetworkGameService _networkGameService;

		// Token: 0x04000F01 RID: 3841
		private uint _lastPing;
	}
}
