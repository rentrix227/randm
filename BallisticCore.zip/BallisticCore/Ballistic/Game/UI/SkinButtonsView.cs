﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200030D RID: 781
	public class SkinButtonsView : BaseView<InventoryController>
	{
		// Token: 0x06001083 RID: 4227 RVA: 0x0000D99D File Offset: 0x0000BB9D
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.DisassemblyButton.onClick.AddListener(new UnityAction(this.OnDisassemblyClick));
		}

		// Token: 0x06001084 RID: 4228 RVA: 0x0005FA88 File Offset: 0x0005DC88
		internal void SetData(WeaponSkinData weaponSkinData, bool canDisassembly)
		{
			this._weaponSkinData = weaponSkinData;
			this.DisassemblyRarityText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("skin", ELocalizedTextCase.NONE), ServiceProvider.GetService<LocalizationService>().Get("rarity_" + weaponSkinData.WeaponSkin.Rarity.ToString().ToLowerInvariant(), ELocalizedTextCase.NONE));
			this.DisassemblyRarityText.color = RarityHelper.GetRarityColor(weaponSkinData.WeaponSkin.Rarity);
			for (int i = 0; i < InventoryHelper.Rarities.Length; i++)
			{
				if (InventoryHelper.Rarities[i] == weaponSkinData.WeaponSkin.Rarity)
				{
					string text = ServiceProvider.GetService<LocalizationService>().Get((weaponSkinData.WeaponSkin.Rarity != ERarity.RANKED) ? "scraps" : "goldscraps", ELocalizedTextCase.NONE);
					if (InventoryHelper.ScrapVarDrop[i] > 0)
					{
						this.DisassemblyScrapText.text = string.Concat(new object[]
						{
							InventoryHelper.ScrapBaseDrop[i],
							"-",
							InventoryHelper.ScrapBaseDrop[i] + InventoryHelper.ScrapVarDrop[i],
							" ",
							text
						});
					}
					else
					{
						this.DisassemblyScrapText.text = InventoryHelper.ScrapBaseDrop[i] + " " + text;
					}
					break;
				}
			}
			this.DisassemblyButton.interactable = canDisassembly;
		}

		// Token: 0x06001085 RID: 4229 RVA: 0x0000D9CC File Offset: 0x0000BBCC
		private void OnDisassemblyClick()
		{
			this.DisassemblyButton.interactable = false;
			base._controller.DisassemblyWeaponSkin(this._weaponSkinData);
		}

		// Token: 0x040015BB RID: 5563
		public Button DisassemblyButton;

		// Token: 0x040015BC RID: 5564
		public Text DisassemblyRarityText;

		// Token: 0x040015BD RID: 5565
		public Text DisassemblyScrapText;

		// Token: 0x040015BE RID: 5566
		private WeaponSkinData _weaponSkinData;
	}
}
