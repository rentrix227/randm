﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002F0 RID: 752
	public class MainRewardMonthlyView : BaseView<MainController>
	{
		// Token: 0x06000FBA RID: 4026 RVA: 0x0000CFA8 File Offset: 0x0000B1A8
		protected override void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.MainRewardList.Template.Dispose();
		}

		// Token: 0x06000FBB RID: 4027 RVA: 0x0000CFC5 File Offset: 0x0000B1C5
		private void OnClaimReward(RewardPackData rewardData, Action<bool, SteamItem[]> OnExchangeResponse)
		{
			base._controller.ClaimReward(rewardData, OnExchangeResponse);
		}

		// Token: 0x06000FBC RID: 4028 RVA: 0x0005CC68 File Offset: 0x0005AE68
		private void OnFinish(MainRewardPackComponent pack)
		{
			for (int i = 0; i < this.MainRewardList.Count; i++)
			{
				if (pack == this.MainRewardList[i])
				{
					this.MainRewardList[i].Dispose();
				}
			}
			this.UpdateRewardList();
			if (this._currentRewards.Count <= 0 && this.MainRewardList.Lenght <= 0)
			{
				UIManager.Instance.DisableLayer(1);
				base._controller.CheckRewards();
			}
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x0005CCF8 File Offset: 0x0005AEF8
		internal void SetData(IEnumerable<RewardPackData> rewards)
		{
			if (rewards.FirstOrDefault<RewardPackData>() != null)
			{
				this.MainText.text = string.Format(ServiceProvider.GetService<LocalizationService>().Get("monthly", ELocalizedTextCase.UPPER_CASE), ServiceProvider.GetService<LocalizationService>().Get("leaderboards", ELocalizedTextCase.UPPER_CASE));
			}
			this._currentRewards = rewards.ToList<RewardPackData>();
			this.UpdateRewardList();
		}

		// Token: 0x06000FBE RID: 4030 RVA: 0x0005CD54 File Offset: 0x0005AF54
		private void UpdateRewardList()
		{
			while (this._currentRewards.Count > 0 && this.MainRewardList.Lenght < 3)
			{
				this.MainRewardList.Instantiate().SetData(this._currentRewards.First<RewardPackData>(), new Action<RewardPackData, Action<bool, SteamItem[]>>(this.OnClaimReward), new Action<MainRewardPackComponent>(this.OnFinish));
				this._currentRewards.RemoveAt(0);
			}
		}

		// Token: 0x040014ED RID: 5357
		public Text MainText;

		// Token: 0x040014EE RID: 5358
		public MainRewardMonthlyView.MainRewardPackList MainRewardList;

		// Token: 0x040014EF RID: 5359
		private List<RewardPackData> _currentRewards;

		// Token: 0x020002F1 RID: 753
		[Serializable]
		public class MainRewardPackList : PoolableList<MainRewardPackComponent>
		{
		}
	}
}
