﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Pattern.Singleton;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroSkinModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000253 RID: 595
	public class SoldiersController : BaseController
	{
		// Token: 0x06000CC6 RID: 3270 RVA: 0x0004D018 File Offset: 0x0004B218
		public SoldiersController()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldiersService = ServiceProvider.GetService<SoldiersService>();
			this._playerHeroSkinService = ServiceProvider.GetService<PlayerHeroSkinService>();
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange += this.OnLanguageChange;
			this._soldiersService.OnSoldierChanged += this.OnSoldierChanged;
			this._soldiersService.OnLoadoutChanged += this.OnLoadoutChanged;
			this._soldiersService.OnSkinChanged += this.OnSkinChanged;
			this._soldiersService.OnAccessoryChanged += this.OnAccessoryChanged;
			this._soldiersService.OnWeaponSelected += this.OnWeaponSelected;
		}

		// Token: 0x06000CC7 RID: 3271 RVA: 0x0004D0D8 File Offset: 0x0004B2D8
		public override void DisableController()
		{
			base.DisableController();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._soldiersService.OnSoldierChanged -= this.OnSoldierChanged;
			this._soldiersService.OnLoadoutChanged -= this.OnLoadoutChanged;
			this._soldiersService.OnSkinChanged -= this.OnSkinChanged;
			this._soldiersService.OnWeaponSelected -= this.OnWeaponSelected;
			ServiceProvider.GetService<LocalizationService>().OnLanguageChange -= this.OnLanguageChange;
		}

		// Token: 0x06000CC8 RID: 3272 RVA: 0x0004D168 File Offset: 0x0004B368
		public override void OnShow(AbstractView view)
		{
			base.OnShow(view);
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.UpdateSoldiesTitleView(view, true);
			this.UpdateSoldierStatsView(view, true);
			this.UpdateSoldierClassesView(view);
			this.UpdateSoldierModelView(view, true);
			this.UpdateSoldierArsenalView(view, true);
			this.UpdateSoldierLoadoutsView(view, true);
			this.UpdateSoldierSkinView(view, true);
			this.UpdateSoldiersAccessoryView(view, true);
		}

		// Token: 0x06000CC9 RID: 3273 RVA: 0x0000AB77 File Offset: 0x00008D77
		private void OnLanguageChange()
		{
			this.UpdateSoldiesTitleView(base.GetView<SoldiersTitleView>(), true);
			this.UpdateSoldierStatsView(base.GetView<SoldiersStatsView>(), true);
			this.UpdateSoldierArsenalView(base.GetView<SoldiersArsenalView>(), true);
			this.UpdateSoldierLoadoutsView(base.GetView<SoldiersLoadoutsView>(), true);
		}

		// Token: 0x06000CCA RID: 3274 RVA: 0x0004D1C8 File Offset: 0x0004B3C8
		private void OnSoldierChanged(EHeroClass eHeroClass)
		{
			this.UpdateSoldiesTitleView(base.GetView<SoldiersTitleView>(), false);
			this.UpdateSoldierStatsView(base.GetView<SoldiersStatsView>(), false);
			this.UpdateSoldierClassesView(base.GetView<SoldiersClassesView>());
			this.UpdateSoldierModelView(base.GetView<SoldiersModelView>(), false);
			this.UpdateSoldierArsenalView(base.GetView<SoldiersArsenalView>(), false);
			this.UpdateSoldierSkinView(base.GetView<SoldiersHeroSkinsView>(), false);
			this.UpdateSoldiersAccessoryView(base.GetView<SoldiersAccessoriesView>(), false);
			this.UpdateSoldierLoadoutsView(base.GetView<SoldiersLoadoutsView>(), false);
		}

		// Token: 0x06000CCB RID: 3275 RVA: 0x0004D23C File Offset: 0x0004B43C
		private void OnLoadoutChanged(PlayerLoadoutData playerLoadoutData)
		{
			this.UpdateSoldierModelView(base.GetView<SoldiersModelView>(), false);
			this.UpdateSoldierArsenalView(base.GetView<SoldiersArsenalView>(), false);
			this.UpdateSoldierSkinView(base.GetView<SoldiersHeroSkinsView>(), false);
			this.UpdateSoldiersAccessoryView(base.GetView<SoldiersAccessoriesView>(), false);
			this.UpdateSoldierLoadoutsView(base.GetView<SoldiersLoadoutsView>(), true);
		}

		// Token: 0x06000CCC RID: 3276 RVA: 0x00002A31 File Offset: 0x00000C31
		private void OnWeaponSelected(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
		}

		// Token: 0x06000CCD RID: 3277 RVA: 0x0000ABAD File Offset: 0x00008DAD
		private void OnSkinChanged(HeroSkin skin, PlayerLoadoutV2 loadout)
		{
			this.UpdateSoldierModelView(base.GetView<SoldiersModelView>(), false);
			this.UpdateSoldierSkinView(base.GetView<SoldiersHeroSkinsView>(), false);
		}

		// Token: 0x06000CCE RID: 3278 RVA: 0x0000ABC9 File Offset: 0x00008DC9
		private void OnAccessoryChanged(Accessory accessory, PlayerLoadoutV2 loadout)
		{
			this.UpdateSoldierModelView(base.GetView<SoldiersModelView>(), false);
			this.UpdateSoldiersAccessoryView(base.GetView<SoldiersAccessoriesView>(), true);
		}

		// Token: 0x06000CCF RID: 3279 RVA: 0x0004D28C File Offset: 0x0004B48C
		private void UpdateSoldiersAccessoryView(AbstractView view, bool isStart)
		{
			SoldiersAccessoriesView soldiersAccessoriesView = view as SoldiersAccessoriesView;
			if (soldiersAccessoriesView != null)
			{
				List<Dictionary<EHeroItemSlot, Accessory>> list = new List<Dictionary<EHeroItemSlot, Accessory>>();
				foreach (PlayerLoadoutData playerLoadoutData in this._soldiersService.GetCurrentClassPlayerLoadouts())
				{
					list.Add(this._soldiersService.GetAccessories(playerLoadoutData));
				}
				if (isStart)
				{
					soldiersAccessoriesView.SetStartAccessoryList(this._playerHeroSkinService.GetAvailableAccessories(true), list, this._soldiersService.GetCurrentLoadoutIndex());
				}
				else
				{
					soldiersAccessoriesView.SetAccessoryList(this._playerHeroSkinService.GetAvailableAccessories(true), list, this._soldiersService.GetCurrentLoadoutIndex());
				}
			}
		}

		// Token: 0x06000CD0 RID: 3280 RVA: 0x0004D358 File Offset: 0x0004B558
		private void UpdateSoldierSkinView(AbstractView view, bool isStart)
		{
			SoldiersHeroSkinsView soldiersHeroSkinsView = view as SoldiersHeroSkinsView;
			if (soldiersHeroSkinsView != null)
			{
				List<HeroSkin> list = new List<HeroSkin>();
				PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
				List<PlayerLoadoutData> currentClassPlayerLoadouts = this._soldiersService.GetCurrentClassPlayerLoadouts();
				int num = 0;
				for (int i = 0; i < currentClassPlayerLoadouts.Count; i++)
				{
					list.Add(this._soldiersService.GetHeroSkin(currentClassPlayerLoadouts[i]));
					if (currentClassPlayerLoadouts[i].PlayerItem.ItemId == currentClassPlayerLoadout.PlayerItem.ItemId)
					{
						num = i;
					}
				}
				if (isStart)
				{
					soldiersHeroSkinsView.SetStartSkinList(this._playerHeroSkinService.GetAvailableSkins(this._soldiersService.GetCurrentClass()), list, num);
				}
				else
				{
					soldiersHeroSkinsView.SetSkinList(this._playerHeroSkinService.GetAvailableSkins(this._soldiersService.GetCurrentClass()), list, num);
				}
			}
		}

		// Token: 0x06000CD1 RID: 3281 RVA: 0x0004D43C File Offset: 0x0004B63C
		private void UpdateSoldierArsenalView(AbstractView view, bool isStart)
		{
			SoldiersArsenalView soldiersArsenalView = view as SoldiersArsenalView;
			if (soldiersArsenalView != null)
			{
				PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
				HeroSkin heroSkin = this._soldiersService.GetHeroSkin(currentClassPlayerLoadout);
				if (isStart)
				{
					soldiersArsenalView.SetStartData(this._soldiersService.GetCurrentPlayerHero(), currentClassPlayerLoadout.PlayerItem.ItemName, heroSkin, this._soldiersService.GetLoadoutInfo(currentClassPlayerLoadout), currentClassPlayerLoadout);
				}
				else
				{
					soldiersArsenalView.SetData(this._soldiersService.GetCurrentPlayerHero(), currentClassPlayerLoadout.PlayerItem.ItemName, heroSkin, this._soldiersService.GetLoadoutInfo(currentClassPlayerLoadout), currentClassPlayerLoadout);
				}
			}
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x0004D4D4 File Offset: 0x0004B6D4
		private void UpdateSoldierLoadoutsView(AbstractView view, bool isStart)
		{
			SoldiersLoadoutsView soldiersLoadoutsView = view as SoldiersLoadoutsView;
			if (soldiersLoadoutsView != null)
			{
				PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
				List<PlayerLoadoutData> currentClassPlayerLoadouts = this._soldiersService.GetCurrentClassPlayerLoadouts();
				List<Dictionary<EHeroItemSlot, PlayerWeaponData>> list = new List<Dictionary<EHeroItemSlot, PlayerWeaponData>>();
				int num = 0;
				for (int i = 0; i < currentClassPlayerLoadouts.Count; i++)
				{
					list.Add(this._soldiersService.GetLoadoutInfo(currentClassPlayerLoadouts[i]));
					if (currentClassPlayerLoadouts[i].PlayerItem.ItemId == currentClassPlayerLoadout.PlayerItem.ItemId)
					{
						num = i;
					}
				}
				if (isStart)
				{
					soldiersLoadoutsView.SetStartAllLoadouts(currentClassPlayerLoadouts, list, num);
				}
				else
				{
					soldiersLoadoutsView.SetAllLoadouts(currentClassPlayerLoadouts, list, num);
				}
			}
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x0004D590 File Offset: 0x0004B790
		private void UpdateSoldierModelView(AbstractView view, bool isStart)
		{
			SoldiersModelView soldiersModelView = view as SoldiersModelView;
			if (soldiersModelView != null)
			{
				PlayerLoadoutData currentClassPlayerLoadout = this._soldiersService.GetCurrentClassPlayerLoadout();
				if (isStart)
				{
					soldiersModelView.SetStartModel(this._soldiersService.GetHeroSkin(currentClassPlayerLoadout), this._soldiersService.GetAccessories(currentClassPlayerLoadout));
				}
				else
				{
					soldiersModelView.SetModel(this._soldiersService.GetHeroSkin(currentClassPlayerLoadout), this._soldiersService.GetAccessories(currentClassPlayerLoadout));
				}
			}
		}

		// Token: 0x06000CD4 RID: 3284 RVA: 0x0004D604 File Offset: 0x0004B804
		private void UpdateSoldierClassesView(AbstractView view)
		{
			SoldiersClassesView soldiersClassesView = view as SoldiersClassesView;
			if (soldiersClassesView != null)
			{
				soldiersClassesView.SetSoldier(this._soldiersService.GetCurrentClass());
			}
		}

		// Token: 0x06000CD5 RID: 3285 RVA: 0x0004D638 File Offset: 0x0004B838
		private void UpdateSoldiesTitleView(AbstractView view, bool isStart)
		{
			SoldiersTitleView soldiersTitleView = view as SoldiersTitleView;
			if (soldiersTitleView != null)
			{
				if (isStart)
				{
					soldiersTitleView.SetStartTitle(this._soldiersService.GetCurrentClass());
				}
				else
				{
					soldiersTitleView.SetTitle(this._soldiersService.GetCurrentClass());
				}
			}
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x0004D688 File Offset: 0x0004B888
		private void UpdateSoldierStatsView(AbstractView view, bool isStart)
		{
			SoldiersStatsView soldiersStatsView = view as SoldiersStatsView;
			if (soldiersStatsView != null)
			{
				if (isStart)
				{
					soldiersStatsView.SetStartStats(this._soldiersService.GetCurrentPlayerHero());
				}
				else
				{
					soldiersStatsView.SetStats(this._soldiersService.GetCurrentPlayerHero());
				}
			}
		}

		// Token: 0x06000CD7 RID: 3287 RVA: 0x0000ABE5 File Offset: 0x00008DE5
		internal void DispatchLoadoutNameChanged(string loadoutName, PlayerLoadoutData loadout)
		{
			this._soldiersService.LoadoutChangeName(loadout, loadoutName);
		}

		// Token: 0x06000CD8 RID: 3288 RVA: 0x0000ABF4 File Offset: 0x00008DF4
		internal void DispatchSoldierChanged(EHeroClass soldier)
		{
			this._soldiersService.DispatchSoldierChanged(soldier);
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x0000AC02 File Offset: 0x00008E02
		internal void DispatchLoadoutChanged(PlayerLoadoutData loadout)
		{
			this._soldiersService.DispatchLoadoutChanged(loadout);
			Singleton<UIEventSystem>.Instance.DispatchEvent("change_loadout", new object[] { true });
		}

		// Token: 0x06000CDA RID: 3290 RVA: 0x0000AC2E File Offset: 0x00008E2E
		internal void DispatchSoldierSkinChanged(HeroSkin skin)
		{
			this._soldiersService.DispatchSoldierSkinChanged(skin);
			Singleton<UIEventSystem>.Instance.DispatchEvent("change_skin", new object[] { true });
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x0000AC5A File Offset: 0x00008E5A
		public void DispatchSoldierAccessoryChanged(Accessory accessory, EHeroItemSlot slot)
		{
			this._soldiersService.DispatchAccessoryChanged(accessory, slot);
			Singleton<UIEventSystem>.Instance.DispatchEvent("change_skin", new object[] { true });
		}

		// Token: 0x04000FAF RID: 4015
		private readonly SoldiersService _soldiersService;

		// Token: 0x04000FB0 RID: 4016
		private readonly PlayerHeroSkinService _playerHeroSkinService;
	}
}
