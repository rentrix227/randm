﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.UI.Base;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002F4 RID: 756
	public class MissionsView : BaseView<BaseController>
	{
		// Token: 0x06000FC8 RID: 4040 RVA: 0x0000D015 File Offset: 0x0000B215
		protected override void Awake()
		{
			base.Awake();
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Missions.Template.Dispose();
		}

		// Token: 0x040014F2 RID: 5362
		public MissionsView.MissionComponentList Missions;

		// Token: 0x020002F5 RID: 757
		[Serializable]
		public class MissionComponentList : PoolableList<MissionComponent>
		{
		}
	}
}
