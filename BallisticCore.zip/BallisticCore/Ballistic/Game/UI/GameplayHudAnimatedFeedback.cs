﻿using System;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000280 RID: 640
	public class GameplayHudAnimatedFeedback : MonoBehaviour
	{
		// Token: 0x06000D8E RID: 3470 RVA: 0x0000B4C8 File Offset: 0x000096C8
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x00050004 File Offset: 0x0004E204
		public void Update()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.SetMouseDelta(new Vector2(this._optionControlService.GetAxisL(AxisType.MOUSE_X) * this._optionControlService.Container.RawSensitivity, this._optionControlService.GetAxisL(AxisType.MOUSE_Y) * this._optionControlService.Container.RawSensitivity));
			this._mouseDeltaFeedback = Vector2.SmoothDamp(this._mouseDeltaFeedback, Vector2.zero, ref this._mouseCurrentVelocity, this.MouseSmoothDamp, float.PositiveInfinity, Time.deltaTime);
			if (!this.HudAnimator.isInitialized)
			{
				return;
			}
			this.HudAnimator.SetFloat(this._animatorHorizontalHash, -this._mouseDeltaFeedback.x);
			this.HudAnimator.SetFloat(this._animatorVerticalHash, -this._mouseDeltaFeedback.y);
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x0000B507 File Offset: 0x00009707
		public void OnDestroy()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x000500D8 File Offset: 0x0004E2D8
		private void OnUserHit(HitEvent hitEvent)
		{
			if (!UserProfile.IsMe(hitEvent.VictimGameClientId))
			{
				return;
			}
			if (hitEvent.DamageType == EDamageType.FALL)
			{
				this.SetFallDamage();
			}
			else
			{
				this.SetExternalDamage(Mathf.Clamp(0.1f, 2f, hitEvent.Damage / 100f));
			}
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x00050130 File Offset: 0x0004E330
		private void SetMouseDelta(Vector2 mouseDeltaFeedback)
		{
			this._mouseDeltaFeedback += mouseDeltaFeedback / this.MouseScale;
			if (Mathf.Abs(this._mouseDeltaFeedback.x) > 1f)
			{
				this._mouseDeltaFeedback.x = 1f * Mathf.Sign(this._mouseDeltaFeedback.x);
			}
			if (Mathf.Abs(this._mouseDeltaFeedback.y) > 1f)
			{
				this._mouseDeltaFeedback.y = 1f * Mathf.Sign(this._mouseDeltaFeedback.y);
			}
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x0000B530 File Offset: 0x00009730
		private void SetFallDamage()
		{
			if (!this.HudAnimator.isInitialized)
			{
				return;
			}
			this.HudAnimator.SetTrigger(this._animatorDamageFallHash);
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x000501D0 File Offset: 0x0004E3D0
		private void SetExternalDamage(float damageIntensity)
		{
			if (!this.HudAnimator.isInitialized)
			{
				return;
			}
			float num = Mathf.Clamp(damageIntensity, 0.1f, 2f);
			if (num < 0.28f)
			{
				this.HudAnimator.SetTrigger(this._animatorDamageMinimalHash);
			}
			else if (num < 0.99f)
			{
				this.HudAnimator.SetTrigger(this._animatorDamageMediumHash);
			}
			else
			{
				this.HudAnimator.SetTrigger(this._animatorDamageHighHash);
			}
		}

		// Token: 0x04001090 RID: 4240
		private readonly int _animatorDamageMinimalHash = Animator.StringToHash("damage_low");

		// Token: 0x04001091 RID: 4241
		private readonly int _animatorDamageMediumHash = Animator.StringToHash("damage_medium");

		// Token: 0x04001092 RID: 4242
		private readonly int _animatorDamageHighHash = Animator.StringToHash("damage_high");

		// Token: 0x04001093 RID: 4243
		private readonly int _animatorDamageFallHash = Animator.StringToHash("damage_fall");

		// Token: 0x04001094 RID: 4244
		private readonly int _animatorHorizontalHash = Animator.StringToHash("horizontal");

		// Token: 0x04001095 RID: 4245
		private readonly int _animatorVerticalHash = Animator.StringToHash("vertical");

		// Token: 0x04001096 RID: 4246
		public Animator HudAnimator;

		// Token: 0x04001097 RID: 4247
		public float MouseSmoothDamp = 1f;

		// Token: 0x04001098 RID: 4248
		public float MouseScale = 10f;

		// Token: 0x04001099 RID: 4249
		private Vector2 _mouseCurrentVelocity;

		// Token: 0x0400109A RID: 4250
		private Vector2 _mouseDeltaFeedback;

		// Token: 0x0400109B RID: 4251
		private NetworkGameService _networkGameService;

		// Token: 0x0400109C RID: 4252
		private OptionControlService _optionControlService;
	}
}
