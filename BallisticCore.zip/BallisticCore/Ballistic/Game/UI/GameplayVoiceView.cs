﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Network.Utils;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200029E RID: 670
	public class GameplayVoiceView : BaseView<GameplayVoiceController>
	{
		// Token: 0x06000E45 RID: 3653 RVA: 0x0000BA52 File Offset: 0x00009C52
		internal bool IsVisible()
		{
			return this._msgBase;
		}

		// Token: 0x06000E46 RID: 3654 RVA: 0x00054CD4 File Offset: 0x00052ED4
		internal void Show(KeyType keyPressed = KeyType.NONE)
		{
			this._mousePosition = Vector2.zero;
			this._msgBase = true;
			this._msgMove = false;
			this._msgFollow = false;
			this._msgDefend = false;
			this._msgNeedBackup = false;
			this._msgLaugh = false;
			this._msgTaunt = false;
			this._msgShouldUpdate = true;
			ServiceProvider.GetService<InputControlService>().SetPartialInput(this, false);
			if (keyPressed != KeyType.NONE)
			{
				this._msgPointerIsDisabled = true;
				switch (keyPressed)
				{
				case KeyType.VOICE_MOVE:
					this._msgMove = true;
					break;
				case KeyType.VOICE_DEFEND:
					this._msgDefend = true;
					break;
				case KeyType.VOICE_FOLLOW:
					this._msgFollow = true;
					break;
				case KeyType.VOICE_LAUGH:
					this._msgLaugh = true;
					break;
				case KeyType.VOICE_TAUNT:
					this._msgTaunt = true;
					break;
				case KeyType.VOICE_HELP:
					this._msgNeedBackup = true;
					break;
				}
			}
			else
			{
				this._msgPointerIsDisabled = false;
			}
		}

		// Token: 0x06000E47 RID: 3655 RVA: 0x00054DBC File Offset: 0x00052FBC
		internal void Hide(bool invokeSound)
		{
			this._msgBase = false;
			this._msgShouldUpdate = true;
			ServiceProvider.GetService<InputControlService>().SetPartialInput(this, true);
			if (invokeSound)
			{
				if (this._msgMove)
				{
					base._controller.InvokeSound(VoiceEnum.MOVE, true);
					this.WheelMsgMove.SetTrigger("Pressed");
				}
				else if (this._msgFollow)
				{
					base._controller.InvokeSound(VoiceEnum.FOLLOWME, true);
					this.WheelMsgFollowMe.SetTrigger("Pressed");
				}
				else if (this._msgDefend)
				{
					base._controller.InvokeSound(VoiceEnum.DEFEND, true);
					this.WheelMsgDefend.SetTrigger("Pressed");
				}
				else if (this._msgNeedBackup)
				{
					base._controller.InvokeSound(VoiceEnum.COVER, true);
					this.WheelMsgNeedBackup.SetTrigger("Pressed");
				}
				else if (this._msgLaugh)
				{
					base._controller.InvokeSound(VoiceEnum.LAUGH, true);
					this.WheelMsgLaugh.SetTrigger("Pressed");
				}
				else if (this._msgTaunt)
				{
					base._controller.InvokeSound(VoiceEnum.TAUNT, true);
					this.WheelMsgTaunt.SetTrigger("Pressed");
				}
			}
		}

		// Token: 0x06000E48 RID: 3656 RVA: 0x00054EF4 File Offset: 0x000530F4
		public void UpdatePointer(Vector2 delta)
		{
			if (this._msgPointerIsDisabled)
			{
				return;
			}
			this._mousePosition += delta / this.MouseInputSpeed;
			if (Mathf.Abs(this._mousePosition.x) > 1f)
			{
				this._mousePosition.x = Mathf.Sign(this._mousePosition.x);
			}
			if (Mathf.Abs(this._mousePosition.y) > 1f)
			{
				this._mousePosition.y = Mathf.Sign(this._mousePosition.y);
			}
			this._msgMove = false;
			this._msgFollow = false;
			this._msgDefend = false;
			this._msgNeedBackup = false;
			this._msgLaugh = false;
			this._msgTaunt = false;
			if (this._mousePosition.x < -this.DeadZoneX)
			{
				if (this._mousePosition.y < -this.DeadZoneY)
				{
					this._msgNeedBackup = true;
				}
				else if (this._mousePosition.y > this.DeadZoneY)
				{
					this._msgMove = true;
				}
			}
			else if (this._mousePosition.x > this.DeadZoneX)
			{
				if (this._mousePosition.y < -this.DeadZoneY)
				{
					this._msgTaunt = true;
				}
				else if (this._mousePosition.y > this.DeadZoneY)
				{
					this._msgLaugh = true;
				}
			}
			else if (this._mousePosition.y < -this.DeadZoneY)
			{
				this._msgDefend = true;
			}
			else if (this._mousePosition.y > this.DeadZoneY)
			{
				this._msgFollow = true;
			}
			this._msgShouldUpdate = true;
		}

		// Token: 0x06000E49 RID: 3657 RVA: 0x000550BC File Offset: 0x000532BC
		public void Update()
		{
			if (!this._msgShouldUpdate)
			{
				return;
			}
			if (this.WheelBase.isInitialized)
			{
				this.WheelBase.SetBool(GameplayVoiceView._isOn, this._msgBase);
			}
			if (this.WheelMsgDefend.isInitialized)
			{
				this.WheelMsgDefend.SetBool(GameplayVoiceView._isOn, this._msgDefend);
			}
			if (this.WheelMsgMove.isInitialized)
			{
				this.WheelMsgMove.SetBool(GameplayVoiceView._isOn, this._msgMove);
			}
			if (this.WheelMsgFollowMe.isInitialized)
			{
				this.WheelMsgFollowMe.SetBool(GameplayVoiceView._isOn, this._msgFollow);
			}
			if (this.WheelMsgNeedBackup.isInitialized)
			{
				this.WheelMsgNeedBackup.SetBool(GameplayVoiceView._isOn, this._msgNeedBackup);
			}
			if (this.WheelMsgLaugh.isInitialized)
			{
				this.WheelMsgLaugh.SetBool(GameplayVoiceView._isOn, this._msgLaugh);
			}
			if (this.WheelMsgTaunt.isInitialized)
			{
				this.WheelMsgTaunt.SetBool(GameplayVoiceView._isOn, this._msgTaunt);
			}
		}

		// Token: 0x04001251 RID: 4689
		private static readonly int _isOn = Animator.StringToHash("isOn");

		// Token: 0x04001252 RID: 4690
		public float DeadZoneX = 0.6f;

		// Token: 0x04001253 RID: 4691
		public float DeadZoneY = 0.6f;

		// Token: 0x04001254 RID: 4692
		public float MouseInputSpeed = 40f;

		// Token: 0x04001255 RID: 4693
		public Animator WheelBase;

		// Token: 0x04001256 RID: 4694
		public Animator WheelMsgMove;

		// Token: 0x04001257 RID: 4695
		public Animator WheelMsgFollowMe;

		// Token: 0x04001258 RID: 4696
		public Animator WheelMsgDefend;

		// Token: 0x04001259 RID: 4697
		public Animator WheelMsgNeedBackup;

		// Token: 0x0400125A RID: 4698
		public Animator WheelMsgLaugh;

		// Token: 0x0400125B RID: 4699
		public Animator WheelMsgTaunt;

		// Token: 0x0400125C RID: 4700
		private bool _msgBase;

		// Token: 0x0400125D RID: 4701
		private bool _msgPointerIsDisabled;

		// Token: 0x0400125E RID: 4702
		private bool _msgMove;

		// Token: 0x0400125F RID: 4703
		private bool _msgFollow;

		// Token: 0x04001260 RID: 4704
		private bool _msgDefend;

		// Token: 0x04001261 RID: 4705
		private bool _msgNeedBackup;

		// Token: 0x04001262 RID: 4706
		private bool _msgLaugh;

		// Token: 0x04001263 RID: 4707
		private bool _msgTaunt;

		// Token: 0x04001264 RID: 4708
		private bool _msgShouldUpdate;

		// Token: 0x04001265 RID: 4709
		private Vector2 _mousePosition;
	}
}
