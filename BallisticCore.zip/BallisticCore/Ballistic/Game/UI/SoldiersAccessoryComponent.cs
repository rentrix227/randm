﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000205 RID: 517
	public class SoldiersAccessoryComponent : AccessoryComponent
	{
		// Token: 0x06000A6E RID: 2670 RVA: 0x000094FE File Offset: 0x000076FE
		public void Awake()
		{
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			if (this.AccessoryToggle != null)
			{
				this.AccessoryToggle.onValueChanged.AddListener(new UnityAction<bool>(this.OnToggleClick));
			}
		}

		// Token: 0x06000A6F RID: 2671 RVA: 0x00009538 File Offset: 0x00007738
		private void OnToggleClick(bool value)
		{
			if (this._isSetting)
			{
				return;
			}
			if (this.OnToggleClicked != null)
			{
				this.OnToggleClicked(this._accessory);
			}
		}

		// Token: 0x06000A70 RID: 2672 RVA: 0x0003D060 File Offset: 0x0003B260
		internal void SetData(Accessory accessory, bool selected, bool equippable)
		{
			base.SetData(accessory);
			this._isSetting = true;
			this._accessory = accessory;
			if (this.AccessoryToggle != null)
			{
				this.AccessoryToggle.isOn = selected;
				this.AccessoryToggle.interactable = equippable;
			}
			this._isSetting = false;
		}

		// Token: 0x04000DDE RID: 3550
		public Toggle AccessoryToggle;

		// Token: 0x04000DDF RID: 3551
		internal Action<Accessory> OnToggleClicked;

		// Token: 0x04000DE0 RID: 3552
		private Accessory _accessory;

		// Token: 0x04000DE1 RID: 3553
		private bool _isSetting;
	}
}
