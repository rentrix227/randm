﻿using System;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x0200025F RID: 607
	public class AccessoryTitleView : BaseView<InventoryController>
	{
		// Token: 0x06000D20 RID: 3360 RVA: 0x0000B009 File Offset: 0x00009209
		internal void SetData(Accessory accessory)
		{
			this.AccessoryNameText.text = ServiceProvider.GetService<LocalizationService>().GetAccessoryName(accessory.ItemName);
		}

		// Token: 0x04000FE1 RID: 4065
		public Text AccessoryNameText;
	}
}
