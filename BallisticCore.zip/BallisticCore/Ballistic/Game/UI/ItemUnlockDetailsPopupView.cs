﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Services;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020002D4 RID: 724
	public class ItemUnlockDetailsPopupView : BaseItemUnlockPopupView<InGameEndmatchProgressionController>
	{
		// Token: 0x1700012E RID: 302
		// (get) Token: 0x06000F32 RID: 3890 RVA: 0x0000C82E File Offset: 0x0000AA2E
		protected override string WeaponTitleLocalizationKey
		{
			get
			{
				return "class_weapon";
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x06000F33 RID: 3891 RVA: 0x0000C835 File Offset: 0x0000AA35
		protected override string SkillTitleLocalizationKey
		{
			get
			{
				return "class_skill";
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x06000F34 RID: 3892 RVA: 0x0000C83C File Offset: 0x0000AA3C
		protected override string LoadoutTitleLocalizationKey
		{
			get
			{
				return "class_loadout";
			}
		}

		// Token: 0x06000F35 RID: 3893 RVA: 0x0005B5C8 File Offset: 0x000597C8
		protected override void Awake()
		{
			base.Awake();
			foreach (ItemDetailsSkillTooltipComponent itemDetailsSkillTooltipComponent in this.SkillTooltips)
			{
				ItemDetailsSkillTooltipComponent itemDetailsSkillTooltipComponent2 = itemDetailsSkillTooltipComponent;
				itemDetailsSkillTooltipComponent2.OnSkillClick = (Action<ItemDetailsSkillTooltipComponent, bool>)Delegate.Combine(itemDetailsSkillTooltipComponent2.OnSkillClick, new Action<ItemDetailsSkillTooltipComponent, bool>(this.HandleSkillLoadoutClick));
			}
			foreach (ItemDetailsWeaponTooltipComponent itemDetailsWeaponTooltipComponent in this.WeaponTooltips)
			{
				ItemDetailsWeaponTooltipComponent itemDetailsWeaponTooltipComponent2 = itemDetailsWeaponTooltipComponent;
				itemDetailsWeaponTooltipComponent2.OnWeaponClick = (Action<ItemDetailsWeaponTooltipComponent, bool>)Delegate.Combine(itemDetailsWeaponTooltipComponent2.OnWeaponClick, new Action<ItemDetailsWeaponTooltipComponent, bool>(this.HandleWeaponLoadoutClick));
			}
		}

		// Token: 0x06000F36 RID: 3894 RVA: 0x0005B6AC File Offset: 0x000598AC
		internal override void UpdateInfo(EUnlockType unlockType, EHeroClass heroClass, string itemName, int loadoutNumber)
		{
			base.UpdateInfo(unlockType, heroClass, itemName, loadoutNumber);
			this._itemName = itemName;
			SoldiersService service = ServiceProvider.GetService<SoldiersService>();
			List<PlayerLoadoutData> list = ServiceProvider.GetService<PlayerLoadoutService>().GetPlayerLoadouts(heroClass).ToList<PlayerLoadoutData>();
			for (int i = 0; i < this.SkillLoadoutRoots.Count; i++)
			{
				this.SkillLoadoutRoots[i].SetActive(i < list.Count);
			}
			for (int j = 0; j < this.WeaponLoadoutRoots.Count; j++)
			{
				this.WeaponLoadoutRoots[j].SetActive(j < list.Count);
			}
			for (int k = 0; k < list.Count; k++)
			{
				if (unlockType == EUnlockType.WEAPON)
				{
					WeaponV4 itemById = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(list[k].PlayerItem.ItemMap[EHeroItemSlot.PrimaryWeapon]);
					WeaponV4 itemById2 = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(list[k].PlayerItem.ItemMap[EHeroItemSlot.SecondaryWeapon]);
					bool flag = string.Equals(itemById.ItemName, this._itemName, StringComparison.InvariantCultureIgnoreCase);
					bool flag2 = string.Equals(itemById2.ItemName, this._itemName, StringComparison.InvariantCultureIgnoreCase);
					this.WeaponTooltips[2 * k].SetWeapon(itemById, flag);
					this.WeaponTooltips[2 * k + 1].SetWeapon(itemById2, flag2);
				}
				if (unlockType == EUnlockType.SKILL)
				{
					List<HeroSkillData> list2 = service.GetSelectedHeroSkills(list[k]).ToList<HeroSkillData>();
					string text = list2[0].Skill.ToString();
					string text2 = list2[1].Skill.ToString();
					bool flag3 = string.Equals(text, this._itemName, StringComparison.InvariantCultureIgnoreCase);
					bool flag4 = string.Equals(text2, this._itemName, StringComparison.InvariantCultureIgnoreCase);
					this.SkillTooltips[2 * k].SetSkill(text, flag3);
					this.SkillTooltips[2 * k + 1].SetSkill(text2, flag4);
				}
			}
		}

		// Token: 0x06000F37 RID: 3895 RVA: 0x0005B8B8 File Offset: 0x00059AB8
		private void HandleSkillLoadoutClick(ItemDetailsSkillTooltipComponent skill, bool equipNewItem)
		{
			int num = this.SkillTooltips.IndexOf(skill);
			int num2 = num / 2;
			int num3 = num % 2;
			base._controller.HandleSkillLoadoutReplace(num2, num3, equipNewItem);
		}

		// Token: 0x06000F38 RID: 3896 RVA: 0x0005B8E8 File Offset: 0x00059AE8
		private void HandleWeaponLoadoutClick(ItemDetailsWeaponTooltipComponent weapon, bool equipNewItem)
		{
			int num = this.WeaponTooltips.IndexOf(weapon);
			int num2 = num / 2;
			int num3 = num % 2;
			base._controller.HandleWeaponLoadoutReplace(num2, num3, equipNewItem);
		}

		// Token: 0x06000F39 RID: 3897 RVA: 0x0000C843 File Offset: 0x0000AA43
		public void Update()
		{
			if (this.DoTestNow)
			{
				this.DoTestNow = false;
				this.UpdateInfo(this.TestUnlockType, this.TestHeroClass, this.TestItemName, this.TestLoadoutNumber);
			}
		}

		// Token: 0x04001457 RID: 5207
		public List<GameObject> SkillLoadoutRoots = new List<GameObject>();

		// Token: 0x04001458 RID: 5208
		public List<GameObject> WeaponLoadoutRoots = new List<GameObject>();

		// Token: 0x04001459 RID: 5209
		public List<ItemDetailsSkillTooltipComponent> SkillTooltips = new List<ItemDetailsSkillTooltipComponent>();

		// Token: 0x0400145A RID: 5210
		public List<ItemDetailsWeaponTooltipComponent> WeaponTooltips = new List<ItemDetailsWeaponTooltipComponent>();

		// Token: 0x0400145B RID: 5211
		[Header("Testing")]
		public EUnlockType TestUnlockType;

		// Token: 0x0400145C RID: 5212
		public EHeroClass TestHeroClass;

		// Token: 0x0400145D RID: 5213
		public string TestItemName;

		// Token: 0x0400145E RID: 5214
		public int TestLoadoutNumber;

		// Token: 0x0400145F RID: 5215
		public bool DoTestNow;

		// Token: 0x04001460 RID: 5216
		private string _itemName;
	}
}
