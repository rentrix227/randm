﻿using System;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001ED RID: 493
	public class LeaderboardTooltipLineComponent : PoolableComponent
	{
		// Token: 0x060009E9 RID: 2537 RVA: 0x00008F3E File Offset: 0x0000713E
		internal void SetInfo(string line)
		{
			this.Line.text = line;
		}

		// Token: 0x04000D4E RID: 3406
		public Text Line;
	}
}
