﻿using System;
using Aquiris.Ballistic.Game.Services;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000241 RID: 577
	internal class SteamItemData
	{
		// Token: 0x04000F51 RID: 3921
		internal SteamItem SteamItem;

		// Token: 0x04000F52 RID: 3922
		internal bool Visible;

		// Token: 0x04000F53 RID: 3923
		internal string CurrentName;
	}
}
