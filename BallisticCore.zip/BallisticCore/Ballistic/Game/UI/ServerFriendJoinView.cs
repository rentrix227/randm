﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x02000306 RID: 774
	public class ServerFriendJoinView : BaseView<ServerBrowserController>
	{
		// Token: 0x0600100D RID: 4109 RVA: 0x0000D349 File Offset: 0x0000B549
		protected override void Awake()
		{
			base.Awake();
			this._defaultMap = this.MapImage.sprite;
			if (OfflineInformation.OfflineUi)
			{
				return;
			}
			this.Join.onClick.AddListener(new UnityAction(this.OnJoinMatch));
		}

		// Token: 0x0600100E RID: 4110 RVA: 0x0000D389 File Offset: 0x0000B589
		private void OnJoinMatch()
		{
			base._controller.Join(this._hostItem, EClientMode.SPECTATOR);
		}

		// Token: 0x0600100F RID: 4111 RVA: 0x0005DEBC File Offset: 0x0005C0BC
		internal void SetFriendServer(CSteamID friend, HostItem hostItem)
		{
			this._hostItem = hostItem;
			this.FriendName.text = SteamFriends.GetFriendPersonaName(friend);
			ServiceProvider.GetService<AvatarService>().LoadImageMedium(friend, new Action<ulong, Texture2D>(this.OnFriendAvatarLoaded), true);
			LocalizationService service = ServiceProvider.GetService<LocalizationService>();
			this.NameText.text = hostItem.Name;
			this.MapText.text = service.GetMapName(hostItem.GameMap, ELocalizedTextCase.UPPER_CASE);
			GameMapConfig gameMapConfig = ServiceProvider.GetService<GameMapModeConfigService>().FindGameMapConfig(hostItem.GameMap);
			if (gameMapConfig != null)
			{
				TextureHelper.LoadImageAsync(TextureHelper.GetMapIconPath(gameMapConfig, EImageSize.SMALL), this.MapImage, false, EImageSource.STREAMINGASSETS);
			}
			else
			{
				this.MapImage.sprite = this._defaultMap;
			}
			this.ModeText.text = service.GetModeName(hostItem.GameMode, ELocalizedTextCase.UPPER_CASE);
			this.LockImage.gameObject.SetActive(hostItem.Password);
			this.PlayersText.text = string.Format("{0}/{1}", hostItem.NumPlayers, hostItem.MaxPlayers);
			LatencyDefinitionData.LatencyDefinition definition = LatencyDefinitionData.GetDefinition(hostItem);
			this.LatencyText.text = ((definition.Value == 0U) ? definition.Region : (definition.Value + "ms"));
			this.LatencyText.color = definition.UiColor;
			this.MatchIsFullImage.SetActive(hostItem.NumPlayers >= hostItem.MaxPlayers);
		}

		// Token: 0x06001010 RID: 4112 RVA: 0x0000D39D File Offset: 0x0000B59D
		private void OnFriendAvatarLoaded(ulong steamId, Texture2D avatar)
		{
			this.FriendAvatar.texture = avatar;
		}

		// Token: 0x04001535 RID: 5429
		public Text FriendName;

		// Token: 0x04001536 RID: 5430
		public RawImage FriendAvatar;

		// Token: 0x04001537 RID: 5431
		public Image MapImage;

		// Token: 0x04001538 RID: 5432
		public Image LockImage;

		// Token: 0x04001539 RID: 5433
		public Text NameText;

		// Token: 0x0400153A RID: 5434
		public Text MapText;

		// Token: 0x0400153B RID: 5435
		public Text ModeText;

		// Token: 0x0400153C RID: 5436
		public Text PlayersText;

		// Token: 0x0400153D RID: 5437
		public Text LatencyText;

		// Token: 0x0400153E RID: 5438
		public GameObject MatchIsFullImage;

		// Token: 0x0400153F RID: 5439
		public Button Join;

		// Token: 0x04001540 RID: 5440
		private HostItem _hostItem;

		// Token: 0x04001541 RID: 5441
		private Sprite _defaultMap;
	}
}
