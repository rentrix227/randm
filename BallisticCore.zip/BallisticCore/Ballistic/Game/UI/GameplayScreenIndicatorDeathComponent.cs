﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.UI
{
	// Token: 0x020001D2 RID: 466
	public class GameplayScreenIndicatorDeathComponent : MonoBehaviour
	{
		// Token: 0x0600099B RID: 2459 RVA: 0x00008ACB File Offset: 0x00006CCB
		public void Awake()
		{
			this._remainingTime = this.TimeToLive;
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x00039DC4 File Offset: 0x00037FC4
		public void Update()
		{
			this._remainingTime -= Time.deltaTime;
			this.VisibleAnimator.SetBool(GameplayScreenIndicatorDeathComponent._visibleHash, this._visible && this._remainingTime > 0f);
			if (this._remainingTime < -2f)
			{
				Object.Destroy(base.gameObject);
			}
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x00008AD9 File Offset: 0x00006CD9
		public void SetNickname(string nickname)
		{
			this.NicknameLabel.text = nickname;
		}

		// Token: 0x0600099E RID: 2462 RVA: 0x00008AE7 File Offset: 0x00006CE7
		public void UpdateInfo(bool visible)
		{
			this._visible = visible;
		}

		// Token: 0x04000CC1 RID: 3265
		public Animator VisibleAnimator;

		// Token: 0x04000CC2 RID: 3266
		public Text NicknameLabel;

		// Token: 0x04000CC3 RID: 3267
		public float TimeToLive = 10f;

		// Token: 0x04000CC4 RID: 3268
		private static readonly int _visibleHash = Animator.StringToHash("visible");

		// Token: 0x04000CC5 RID: 3269
		private float _remainingTime;

		// Token: 0x04000CC6 RID: 3270
		private bool _visible;
	}
}
