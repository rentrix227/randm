﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000158 RID: 344
	public enum ENotifications
	{
		// Token: 0x0400094A RID: 2378
		LOCKBOX,
		// Token: 0x0400094B RID: 2379
		SCRAPS,
		// Token: 0x0400094C RID: 2380
		ACCESSORY,
		// Token: 0x0400094D RID: 2381
		WEAPONSKINS
	}
}
