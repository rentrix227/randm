﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroSkinModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000183 RID: 387
	internal class SoldiersService : IService
	{
		// Token: 0x14000017 RID: 23
		// (add) Token: 0x060007D2 RID: 2002 RVA: 0x00031978 File Offset: 0x0002FB78
		// (remove) Token: 0x060007D3 RID: 2003 RVA: 0x000319B0 File Offset: 0x0002FBB0
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<EHeroClass> OnSoldierChanged;

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x060007D4 RID: 2004 RVA: 0x000319E8 File Offset: 0x0002FBE8
		// (remove) Token: 0x060007D5 RID: 2005 RVA: 0x00031A20 File Offset: 0x0002FC20
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<PlayerLoadoutData> OnLoadoutChanged;

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x060007D6 RID: 2006 RVA: 0x00031A58 File Offset: 0x0002FC58
		// (remove) Token: 0x060007D7 RID: 2007 RVA: 0x00031A90 File Offset: 0x0002FC90
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<EHeroClass, EHeroItemSlot, PlayerWeaponData, PlayerLoadoutV2> OnWeaponChangeRequest;

		// Token: 0x1400001A RID: 26
		// (add) Token: 0x060007D8 RID: 2008 RVA: 0x00031AC8 File Offset: 0x0002FCC8
		// (remove) Token: 0x060007D9 RID: 2009 RVA: 0x00031B00 File Offset: 0x0002FD00
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<PlayerWeaponData, PlayerLoadoutV2> OnWeaponPreview;

		// Token: 0x1400001B RID: 27
		// (add) Token: 0x060007DA RID: 2010 RVA: 0x00031B38 File Offset: 0x0002FD38
		// (remove) Token: 0x060007DB RID: 2011 RVA: 0x00031B70 File Offset: 0x0002FD70
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<PlayerWeaponData, PlayerLoadoutV2> OnWeaponClick;

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x060007DC RID: 2012 RVA: 0x00031BA8 File Offset: 0x0002FDA8
		// (remove) Token: 0x060007DD RID: 2013 RVA: 0x00031BE0 File Offset: 0x0002FDE0
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<PlayerWeaponData, PlayerLoadoutV2> OnWeaponSelected;

		// Token: 0x1400001D RID: 29
		// (add) Token: 0x060007DE RID: 2014 RVA: 0x00031C18 File Offset: 0x0002FE18
		// (remove) Token: 0x060007DF RID: 2015 RVA: 0x00031C50 File Offset: 0x0002FE50
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<HeroSkin, PlayerLoadoutV2> OnSkinChanged;

		// Token: 0x1400001E RID: 30
		// (add) Token: 0x060007E0 RID: 2016 RVA: 0x00031C88 File Offset: 0x0002FE88
		// (remove) Token: 0x060007E1 RID: 2017 RVA: 0x00031CC0 File Offset: 0x0002FEC0
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<Accessory, PlayerLoadoutV2> OnAccessoryChanged;

		// Token: 0x1400001F RID: 31
		// (add) Token: 0x060007E2 RID: 2018 RVA: 0x00031CF8 File Offset: 0x0002FEF8
		// (remove) Token: 0x060007E3 RID: 2019 RVA: 0x00031D30 File Offset: 0x0002FF30
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<PlayerWeaponData, WeaponSkin, PlayerLoadoutV2> OnWeaponSkinClick;

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x060007E4 RID: 2020 RVA: 0x00031D68 File Offset: 0x0002FF68
		// (remove) Token: 0x060007E5 RID: 2021 RVA: 0x00031DA0 File Offset: 0x0002FFA0
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<int> OnSkillChangeRequest;

		// Token: 0x14000021 RID: 33
		// (add) Token: 0x060007E6 RID: 2022 RVA: 0x00031DD8 File Offset: 0x0002FFD8
		// (remove) Token: 0x060007E7 RID: 2023 RVA: 0x00031E10 File Offset: 0x00030010
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<HeroSkillData, HeroSkillData> OnSkillSelected;

		// Token: 0x060007E8 RID: 2024 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x00031E48 File Offset: 0x00030048
		internal override void Preprocess()
		{
			this._playerLoadouts = new Dictionary<EHeroClass, List<PlayerLoadoutData>>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._heroService = ServiceProvider.GetService<PlayerHeroService>();
			this._loadoutService = ServiceProvider.GetService<PlayerLoadoutService>();
			this._skillService = ServiceProvider.GetService<SkillService>();
			this._playerWeaponService = ServiceProvider.GetService<PlayerWeaponService>();
			this._weaponService = ServiceProvider.GetService<WeaponService>();
			this._gameItemService = ServiceProvider.GetService<GameItemService>();
			this._playerHeroSkinService = ServiceProvider.GetService<PlayerHeroSkinService>();
			this._inventoryService = ServiceProvider.GetService<InventoryService>();
			this._currentSoldier = EHeroClass.VANGUARD;
			this._currentLoadoutIndex = 0;
			this._defaultAcc = this._gameItemService.GetItemByName<Accessory>("accessory_default", false);
			this.LoadPlayerLoadouts(this._currentLoadoutIndex);
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x00031EF4 File Offset: 0x000300F4
		internal void LoadPlayerLoadouts(int lastLoadout)
		{
			this._playerLoadouts.Clear();
			foreach (PlayerHeroData playerHeroData in this._heroService.GetAvailablePlayerHeroes())
			{
				this._playerLoadouts.Add(playerHeroData.GameItemData.GameItem.UniqueIdentifier, this._loadoutService.GetPlayerLoadouts(playerHeroData.GameItemData.GameItem.UniqueIdentifier).ToList<PlayerLoadoutData>());
			}
			this._currentLoadout = this._playerLoadouts[this._currentSoldier][lastLoadout];
			this.DispatchLoadoutChanged(this._currentLoadout);
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x00007669 File Offset: 0x00005869
		internal void LoadPlayerLoadouts()
		{
			this.LoadPlayerLoadouts(this._currentLoadoutIndex);
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x00007677 File Offset: 0x00005877
		internal EHeroClass GetCurrentClass()
		{
			return this._currentSoldier;
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x0000767F File Offset: 0x0000587F
		internal void SetLoadoutClicked(PlayerLoadoutData loadout)
		{
			this._currentLoadout = loadout;
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x00007688 File Offset: 0x00005888
		internal Dictionary<EHeroClass, List<PlayerLoadoutData>> GetPlayerLoadouts()
		{
			return this._playerLoadouts;
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x00007690 File Offset: 0x00005890
		internal List<PlayerLoadoutData> GetPlayerClassLoadout(EHeroClass heroClass)
		{
			return this._playerLoadouts[heroClass];
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x0000769E File Offset: 0x0000589E
		internal List<PlayerLoadoutData> GetCurrentClassPlayerLoadouts()
		{
			return this._playerLoadouts[this._currentSoldier];
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x000076B1 File Offset: 0x000058B1
		internal PlayerLoadoutData GetCurrentClassPlayerLoadout()
		{
			return this._currentLoadout;
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x000076B9 File Offset: 0x000058B9
		internal int GetCurrentLoadoutIndex()
		{
			return this._currentLoadoutIndex;
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x000076C1 File Offset: 0x000058C1
		internal int GetCurrentSkillSlot()
		{
			return this._currentSkill;
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x000076C9 File Offset: 0x000058C9
		internal PlayerHeroData GetCurrentPlayerHero()
		{
			return this._heroService.GetPlayerHeroData(this._currentLoadout);
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x000076DC File Offset: 0x000058DC
		internal PlayerLoadoutData GetCurrentClassPlayerLoadout(int loadout)
		{
			return this._playerLoadouts[this._currentSoldier][loadout];
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x000076F5 File Offset: 0x000058F5
		internal IEnumerable<HeroSkillData> GetAllHeroSkills()
		{
			return this._skillService.GetSkillDataList(this.GetCurrentClassPlayerLoadout(), HeroSkillNodeV3.SkillNature.Selectable);
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x00031FBC File Offset: 0x000301BC
		internal IEnumerable<HeroSkillData> GetAvailableHeroSkills()
		{
			PlayerHero playerHero = this.GetCurrentPlayerHero().PlayerItem;
			return (from x in this.GetAllHeroSkills()
				where playerHero.UnlockedSkills.Contains(x.Skill)
				select x).ToList<HeroSkillData>();
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x00007709 File Offset: 0x00005909
		internal IEnumerable<HeroSkillData> GetSelectedHeroSkills()
		{
			return this.GetSelectedHeroSkills(this.GetCurrentClassPlayerLoadout());
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x00007717 File Offset: 0x00005917
		internal IEnumerable<HeroSkillData> GetSelectedHeroSkills(PlayerLoadoutData playerLoadoutData)
		{
			return this._skillService.GetSelectedSkillDataList(playerLoadoutData, HeroSkillNodeV3.SkillNature.Selectable);
		}

		// Token: 0x060007FA RID: 2042 RVA: 0x00031FFC File Offset: 0x000301FC
		internal Dictionary<EHeroItemSlot, PlayerWeaponData> GetLoadoutInfo(PlayerLoadoutData loadout)
		{
			Dictionary<EHeroItemSlot, PlayerWeaponData> dictionary = new Dictionary<EHeroItemSlot, PlayerWeaponData>();
			dictionary[EHeroItemSlot.PrimaryWeapon] = this._playerWeaponService.GetPlayerWeapon(this._weaponService.GetWeapon(loadout.PlayerItem.ItemMap[EHeroItemSlot.PrimaryWeapon]));
			dictionary[EHeroItemSlot.SecondaryWeapon] = this._playerWeaponService.GetPlayerWeapon(this._weaponService.GetWeapon(loadout.PlayerItem.ItemMap[EHeroItemSlot.SecondaryWeapon]));
			dictionary[EHeroItemSlot.MeleeWeapon] = this._playerWeaponService.GetPlayerWeapon(this._weaponService.GetWeapon(loadout.PlayerItem.ItemMap[EHeroItemSlot.MeleeWeapon]));
			dictionary[EHeroItemSlot.Explosive] = this._playerWeaponService.GetPlayerWeapon(this._weaponService.GetWeapon(loadout.PlayerItem.ItemMap[EHeroItemSlot.Explosive]));
			return dictionary;
		}

		// Token: 0x060007FB RID: 2043 RVA: 0x00007726 File Offset: 0x00005926
		internal HeroSkin GetHeroSkin(PlayerLoadoutData loadout)
		{
			return this._gameItemService.GetItemById<HeroSkin>(loadout.PlayerItem.ItemMap[EHeroItemSlot.Skin]);
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x000320C8 File Offset: 0x000302C8
		internal Dictionary<EHeroItemSlot, Accessory> GetAccessories(PlayerLoadoutData loadout)
		{
			Dictionary<EHeroItemSlot, Accessory> dictionary = new Dictionary<EHeroItemSlot, Accessory>();
			dictionary[EHeroItemSlot.AccessoryHead] = this._gameItemService.GetItemById<Accessory>(loadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryHead]);
			dictionary[EHeroItemSlot.AccessoryChest] = this._gameItemService.GetItemById<Accessory>(loadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryChest]);
			dictionary[EHeroItemSlot.AccessoryPelvis] = this._gameItemService.GetItemById<Accessory>(loadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryPelvis]);
			dictionary[EHeroItemSlot.AccessoryBack] = this._gameItemService.GetItemById<Accessory>(loadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryBack]);
			dictionary[EHeroItemSlot.AccessoryFeet] = this._gameItemService.GetItemById<Accessory>(loadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryFeet]);
			return dictionary;
		}

		// Token: 0x060007FD RID: 2045 RVA: 0x00007744 File Offset: 0x00005944
		internal Dictionary<EHeroItemSlot, PlayerWeaponData> GetCurrentSoldierLoadout()
		{
			return this.GetLoadoutInfo(this._currentLoadout);
		}

		// Token: 0x060007FE RID: 2046 RVA: 0x00007752 File Offset: 0x00005952
		private void EquipWeapon(EHeroItemSlot slot, PlayerLoadoutData loadout, PlayerWeaponData weapon)
		{
			this._loadoutService.EquipItem(loadout, weapon, slot);
		}

		// Token: 0x060007FF RID: 2047 RVA: 0x00007763 File Offset: 0x00005963
		private void EquipWeaponSkin(PlayerLoadoutV2 loadout, PlayerWeaponData weapon, WeaponSkin skin)
		{
			this._playerWeaponService.EquipSkin(weapon, loadout, skin);
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x00007774 File Offset: 0x00005974
		private void EquipSkills(PlayerLoadoutData loadout, HeroSkillData skill1, HeroSkillData skill2)
		{
			this._loadoutService.ClearLoadoutSkills(loadout);
			this._loadoutService.EquipSkill(loadout, skill1.Skill);
			this._loadoutService.EquipSkill(loadout, skill2.Skill);
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x000077A7 File Offset: 0x000059A7
		private void EquipSkin(PlayerLoadoutData loadout, HeroSkin skin)
		{
			this._loadoutService.EquipSkin(loadout, skin);
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x000077B6 File Offset: 0x000059B6
		private void EquipAccessory(PlayerLoadoutData loadout, EHeroItemSlot slot, Accessory accessory)
		{
			this._loadoutService.EquipAccessory(loadout, slot, accessory);
		}

		// Token: 0x06000803 RID: 2051 RVA: 0x000077C6 File Offset: 0x000059C6
		internal void EquipWeaponToCurrentSoldier(PlayerWeaponData data)
		{
			this.EquipWeapon(this._currentSlot, this._currentLoadout, data);
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x000077DB File Offset: 0x000059DB
		internal void GetWeaponsForSlot(EHeroItemSlot slot, HighSpeedArray<PlayerWeaponData> avaliableWeapon, HighSpeedArray<WeaponV4> allWeapons)
		{
			this._playerWeaponService.GetPlayerWeapons(this._currentLoadout.PlayerItem, slot, avaliableWeapon, allWeapons);
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x00032198 File Offset: 0x00030398
		internal void RequestWeaponChange(EHeroItemSlot slot)
		{
			this._currentSlot = slot;
			Dictionary<EHeroItemSlot, PlayerWeaponData> loadoutInfo = this.GetLoadoutInfo(this._currentLoadout);
			if (this.OnWeaponChangeRequest != null)
			{
				this.OnWeaponChangeRequest(this._currentSoldier, slot, loadoutInfo[this._currentSlot], this._currentLoadout.PlayerItem);
			}
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x000077F6 File Offset: 0x000059F6
		internal void RequestSkillChange(int skillslot)
		{
			this._currentSkill = skillslot;
			if (this.OnSkillChangeRequest != null)
			{
				this.OnSkillChangeRequest(skillslot);
			}
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x00007816 File Offset: 0x00005A16
		internal void DispatchWeaponPreview(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			if (this.OnWeaponPreview != null)
			{
				this.OnWeaponPreview(weapon, loadout);
			}
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x00007830 File Offset: 0x00005A30
		internal void DispatchWeaponClick(PlayerWeaponData weapon, PlayerLoadoutV2 loadout)
		{
			if (this.OnWeaponClick != null)
			{
				this.OnWeaponClick(weapon, loadout);
			}
		}

		// Token: 0x06000809 RID: 2057 RVA: 0x000321F0 File Offset: 0x000303F0
		internal void DispatchSoldierChanged(EHeroClass hero)
		{
			this._currentSoldier = hero;
			this._currentLoadout = this._playerLoadouts[this._currentSoldier][0];
			this._currentLoadoutIndex = 0;
			this._currentSkill = 0;
			if (this.OnSoldierChanged != null)
			{
				this.OnSoldierChanged(hero);
			}
		}

		// Token: 0x0600080A RID: 2058 RVA: 0x0000784A File Offset: 0x00005A4A
		internal void DispatchWeaponSelected(PlayerWeaponData weapon)
		{
			this.EquipWeaponToCurrentSoldier(weapon);
			this.LoadPlayerLoadouts(this._currentLoadoutIndex);
			if (this.OnWeaponSelected != null)
			{
				this.OnWeaponSelected(weapon, this._currentLoadout.PlayerItem);
			}
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x00032248 File Offset: 0x00030448
		internal void DispatchWeaponSkinChanged(PlayerWeaponData weapon, WeaponSkin skin)
		{
			this.EquipWeaponSkin(this._currentLoadout.PlayerItem, weapon, skin);
			this.LoadPlayerLoadouts(this._currentLoadoutIndex);
			if (this.OnWeaponSkinClick != null)
			{
				this.OnWeaponSkinClick(weapon, skin, this._currentLoadout.PlayerItem);
			}
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x00032298 File Offset: 0x00030498
		internal void DispatchLoadoutChanged(PlayerLoadoutData loadout)
		{
			if (loadout == null)
			{
				Debug.LogError("DispatchLoadoutChanged was called with an null param!");
				return;
			}
			this._currentLoadout = loadout;
			for (int i = 0; i < this._playerLoadouts[this._currentSoldier].Count; i++)
			{
				if (loadout.PlayerItem.ItemId == this._playerLoadouts[this._currentSoldier][i].PlayerItem.ItemId)
				{
					this._currentLoadoutIndex = i;
					break;
				}
			}
			if (this.OnLoadoutChanged != null)
			{
				this.OnLoadoutChanged(this._currentLoadout);
			}
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x00007881 File Offset: 0x00005A81
		internal void LoadoutChangeName(PlayerLoadoutData loadout, string loadoutName)
		{
			loadout.PlayerItem = this._loadoutService.SetName(loadout, loadoutName);
			this.DispatchLoadoutChanged(loadout);
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x0000789D File Offset: 0x00005A9D
		internal void DispatchSkillSelected(HeroSkillData skill1, HeroSkillData skill2)
		{
			this.DispatchSkillSelected(this._currentLoadout, skill1, skill2);
		}

		// Token: 0x0600080F RID: 2063 RVA: 0x000078AD File Offset: 0x00005AAD
		internal void DispatchSkillSelected(PlayerLoadoutData playerLoadoutData, HeroSkillData skill1, HeroSkillData skill2)
		{
			this.EquipSkills(playerLoadoutData, skill1, skill2);
			this.LoadPlayerLoadouts(this._currentLoadoutIndex);
			if (this.OnSkillSelected != null)
			{
				this.OnSkillSelected(skill1, skill2);
			}
		}

		// Token: 0x06000810 RID: 2064 RVA: 0x000078DC File Offset: 0x00005ADC
		internal void DispatchSoldierSkinChanged(HeroSkin skin)
		{
			this.EquipSkin(this._currentLoadout, skin);
			this.LoadPlayerLoadouts(this._currentLoadoutIndex);
			if (this.OnSkinChanged != null)
			{
				this.OnSkinChanged(skin, this._currentLoadout.PlayerItem);
			}
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x00032340 File Offset: 0x00030540
		public void DispatchAccessoryChanged(Accessory accessory, EHeroItemSlot slot)
		{
			if (accessory == null)
			{
				accessory = this._defaultAcc;
			}
			this.EquipAccessory(this._currentLoadout, slot, accessory);
			this.LoadPlayerLoadouts(this._currentLoadoutIndex);
			if (this.OnAccessoryChanged != null)
			{
				this.OnAccessoryChanged(accessory, this._currentLoadout.PlayerItem);
			}
		}

		// Token: 0x06000812 RID: 2066 RVA: 0x00032398 File Offset: 0x00030598
		internal void ValidateAll()
		{
			HighSpeedArray<PlayerWeaponData> highSpeedArray = new HighSpeedArray<PlayerWeaponData>(100);
			HighSpeedArray<WeaponV4> highSpeedArray2 = new HighSpeedArray<WeaponV4>(100);
			List<Accessory> list = this._playerHeroSkinService.GetAvailableAccessories(false).ToList<Accessory>();
			foreach (KeyValuePair<EHeroClass, List<PlayerLoadoutData>> keyValuePair in this._playerLoadouts)
			{
				this._playerWeaponService.GetPlayerWeapons(keyValuePair.Value[0].PlayerItem, EHeroItemSlot.PrimaryWeapon, highSpeedArray, highSpeedArray2);
				foreach (PlayerLoadoutData playerLoadoutData in keyValuePair.Value)
				{
					bool flag = false;
					for (int i = 0; i < highSpeedArray.Length; i++)
					{
						EWeaponSkinName skinIdForLoadout = highSpeedArray[i].PlayerItem.GetSkinIdForLoadout(playerLoadoutData.PlayerItem);
						if (!this._inventoryService.HasWeaponSkin(highSpeedArray[i].GameItemData.GameItem.GetSteamWeaponSkinId(skinIdForLoadout)))
						{
							flag = true;
						}
					}
					if (flag)
					{
						foreach (KeyValuePair<EHeroItemSlot, PlayerWeaponData> keyValuePair2 in this.GetLoadoutInfo(playerLoadoutData))
						{
						}
					}
					HeroSkin heroSkin = this.GetHeroSkin(playerLoadoutData);
					if (!this._inventoryService.HasPlayerSkin(heroSkin))
					{
						this._playerHeroSkinService.GetAvailableSkins(playerLoadoutData.GameItemData.GameItem.UniqueIdentifier).FirstOrDefault<HeroSkin>();
					}
					playerLoadoutData.PlayerItem.ItemMap.ContainsKey(EHeroItemSlot.AccessoryChest);
					using (Dictionary<EHeroItemSlot, Accessory>.Enumerator enumerator4 = this.GetAccessories(playerLoadoutData).GetEnumerator())
					{
						while (enumerator4.MoveNext())
						{
							KeyValuePair<EHeroItemSlot, Accessory> pair = enumerator4.Current;
							list.All((Accessory t) => t.ItemId != pair.Value.ItemId);
						}
					}
				}
			}
		}

		// Token: 0x06000813 RID: 2067 RVA: 0x000325F0 File Offset: 0x000307F0
		internal HighSpeedArray<EHeroClass> UpdateAndGetAvaliableClasses(EGameMode mode)
		{
			this.avaliable.Clear();
			this.avaliable.AddRange(from t in this._heroService.GetAvailablePlayerHeroes()
				select t.GameItemData.GameItem.UniqueIdentifier);
			this.toRemove.Clear();
			sbyte b = (sbyte)UserProfile.LocalGameClient.team;
			if (mode == EGameMode.Rounds)
			{
				GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
				if (gameModeMetaData != null)
				{
					foreach (EHeroClass eheroClass in this.avaliable.Array)
					{
						int num = 0;
						foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in gameModeMetaData.ClientMetaDataMap)
						{
							if (!UserProfile.IsMe(keyValuePair.Value.User) && keyValuePair.Value.ClientMode == EClientMode.PLAYER && keyValuePair.Value.CurrentState == EPlayerState.ALIVE && LoadoutUtil.GetHeroClass(keyValuePair.Value.LoadoutInfo) == eheroClass && (int)keyValuePair.Value.Team == (int)b)
							{
								num++;
							}
						}
						if (num >= 2)
						{
							this.toRemove.Add(eheroClass);
						}
					}
				}
				for (int j = 0; j < this.toRemove.Length; j++)
				{
					this.avaliable.Remove(this.toRemove[j]);
				}
				if (!this.avaliable.Contains(this._currentSoldier) && this.avaliable.Length > 0)
				{
					this.DispatchSoldierChanged(this.avaliable[0]);
				}
			}
			return this.avaliable;
		}

		// Token: 0x06000814 RID: 2068 RVA: 0x000327DC File Offset: 0x000309DC
		internal HighSpeedArray<ClientCommonMetaData> UpdateAndGetSelectedClasses()
		{
			sbyte b = (sbyte)UserProfile.LocalGameClient.team;
			this.selected.Clear();
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			if (gameModeMetaData != null)
			{
				foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in gameModeMetaData.ClientMetaDataMap)
				{
					EHeroClass heroClass = LoadoutUtil.GetHeroClass(keyValuePair.Value.LoadoutInfo);
					if (keyValuePair.Value.ClientMode == EClientMode.PLAYER && keyValuePair.Value.CurrentState == EPlayerState.ALIVE && heroClass != EHeroClass.NONE && (int)keyValuePair.Value.Team == (int)b)
					{
						this.selected.Add(keyValuePair.Value);
					}
				}
			}
			return this.selected;
		}

		// Token: 0x04000A99 RID: 2713
		private NetworkGameService _networkGameService;

		// Token: 0x04000A9A RID: 2714
		private PlayerWeaponService _playerWeaponService;

		// Token: 0x04000A9B RID: 2715
		private PlayerHeroService _heroService;

		// Token: 0x04000A9C RID: 2716
		private PlayerLoadoutService _loadoutService;

		// Token: 0x04000A9D RID: 2717
		private WeaponService _weaponService;

		// Token: 0x04000A9E RID: 2718
		private SkillService _skillService;

		// Token: 0x04000A9F RID: 2719
		private GameItemService _gameItemService;

		// Token: 0x04000AA0 RID: 2720
		private InventoryService _inventoryService;

		// Token: 0x04000AA1 RID: 2721
		private PlayerHeroSkinService _playerHeroSkinService;

		// Token: 0x04000AA2 RID: 2722
		private Dictionary<EHeroClass, List<PlayerLoadoutData>> _playerLoadouts;

		// Token: 0x04000AA3 RID: 2723
		private EHeroClass _currentSoldier;

		// Token: 0x04000AA4 RID: 2724
		private int _currentLoadoutIndex;

		// Token: 0x04000AA5 RID: 2725
		private EHeroItemSlot _currentSlot;

		// Token: 0x04000AA6 RID: 2726
		private PlayerLoadoutData _currentLoadout;

		// Token: 0x04000AA7 RID: 2727
		private int _currentSkill;

		// Token: 0x04000AA8 RID: 2728
		private Accessory _defaultAcc;

		// Token: 0x04000AB4 RID: 2740
		private HighSpeedArray<EHeroClass> avaliable = new HighSpeedArray<EHeroClass>(10);

		// Token: 0x04000AB5 RID: 2741
		private HighSpeedArray<ClientCommonMetaData> selected = new HighSpeedArray<ClientCommonMetaData>(10);

		// Token: 0x04000AB6 RID: 2742
		private HighSpeedArray<EHeroClass> toRemove = new HighSpeedArray<EHeroClass>(10);
	}
}
