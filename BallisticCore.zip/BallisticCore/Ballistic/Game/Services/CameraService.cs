﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000138 RID: 312
	public class CameraService : IService
	{
		// Token: 0x060005D5 RID: 1493 RVA: 0x000064A3 File Offset: 0x000046A3
		internal override void Preprocess()
		{
			this._sceneService = ServiceProvider.GetService<SceneService>();
			this._sceneService.OnSceneLoaded += this.OnSceneLoaded;
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060005D7 RID: 1495 RVA: 0x00028D60 File Offset: 0x00026F60
		private void OnSceneLoaded(EBaseScene scene)
		{
			if (scene != EBaseScene.InGame)
			{
				return;
			}
			this._cutsceneCameraInstance = GameObject.FindGameObjectWithTag("cutSceneCamera");
			if (!this._cutsceneCameraInstance)
			{
				this._cutsceneCameraInstance = GameObject.Find("CutSceneCamera");
			}
			this._killCameraInstance = Object.Instantiate<GameObject>(this._killCamContainer).GetComponent<KillCam>();
			this.SetCamera(Cameras.CUTSCENE, null, EHeroClass.NONE, null, -1);
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x000064C7 File Offset: 0x000046C7
		public void SetKillCamContainer(GameObject killCamContainer)
		{
			this._killCamContainer = killCamContainer;
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x00028DC8 File Offset: 0x00026FC8
		public Transform GetCurrentCameraTransform()
		{
			if (this._currentCamera == Cameras.CUTSCENE || this._currentCamera == Cameras.NONE)
			{
				if (this._cutsceneCameraInstance != null)
				{
					return this._cutsceneCameraInstance.transform;
				}
			}
			else if (this._currentCamera == Cameras.KILLCAM && this._killCameraInstance != null)
			{
				return this._killCameraInstance.transform;
			}
			return null;
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x00028E38 File Offset: 0x00027038
		public Camera GetCurrentCamera()
		{
			if (this._currentCamera == Cameras.CUTSCENE || this._currentCamera == Cameras.NONE)
			{
				if (this._cutsceneCameraInstance != null)
				{
					return this._cutsceneCameraInstance.GetComponentInChildren<Camera>(true);
				}
				return null;
			}
			else
			{
				if (this._currentCamera != Cameras.KILLCAM)
				{
					return null;
				}
				if (this._killCameraInstance != null)
				{
					return this._killCameraInstance.GetComponentInChildren<Camera>(true);
				}
				return null;
			}
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x00028EAC File Offset: 0x000270AC
		public void SetCamera(Cameras camera, Transform killer = null, EHeroClass heroClass = EHeroClass.NONE, ClientCommonMetaData metadata = null, int weaponId = -1)
		{
			this._currentCamera = camera;
			if (camera == Cameras.CUTSCENE)
			{
				this._cutsceneCameraInstance.SetActive(true);
				this._killCameraInstance.gameObject.SetActive(false);
			}
			else if (camera == Cameras.KILLCAM)
			{
				this._cutsceneCameraInstance.SetActive(false);
				this._killCameraInstance.gameObject.SetActive(true);
				UIManager.Instance.ChangeState("KILL_CAM");
				this._killCameraInstance.SetTarget(killer, heroClass);
				UIManager.Instance.FindController<InGameKillcamController>().SetTarget(metadata.User, weaponId);
			}
			else
			{
				this._cutsceneCameraInstance.SetActive(false);
				this._killCameraInstance.gameObject.SetActive(false);
			}
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x00028F64 File Offset: 0x00027164
		public static bool IsPointVisible(Camera camera, Vector3 point)
		{
			Vector3 vector = point - camera.transform.position;
			float num = Vector3.Dot(camera.transform.forward, vector.normalized);
			if (num > 0.667f)
			{
				float magnitude = vector.magnitude;
				RaycastHit raycastHit;
				return !Physics.Raycast(camera.transform.position, vector.normalized, ref raycastHit, magnitude, World.AllShootableLayers);
			}
			return false;
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x00028FD8 File Offset: 0x000271D8
		public static void ReturnToRespawn()
		{
			GameModeMetaData gameModeMetaData = ServiceProvider.GetService<NetworkGameService>().GetGameModeMetaData();
			if (gameModeMetaData == null)
			{
				return;
			}
			switch (gameModeMetaData.GameConfig.GameMode)
			{
			case EGameMode.TeamDeathMatch:
			case EGameMode.Conquest:
			case EGameMode.KingOfTheHill:
			case EGameMode.FreeForAll:
			case EGameMode.Juggernaut:
				ServiceProvider.GetService<CameraService>().SetCamera(Cameras.CUTSCENE, null, EHeroClass.NONE, null, -1);
				if (gameModeMetaData.GameMetaData.GameStateType == EGameState.PLAYING && gameModeMetaData.GameMetaData.TimeRemaining > 1000)
				{
					UIManager.Instance.ChangeState("RESPAWN");
				}
				break;
			case EGameMode.Rounds:
				ServiceProvider.GetService<CameraService>().SetCamera(Cameras.CUTSCENE, null, EHeroClass.NONE, null, -1);
				break;
			}
		}

		// Token: 0x04000864 RID: 2148
		private SceneService _sceneService;

		// Token: 0x04000865 RID: 2149
		private GameObject _killCamContainer;

		// Token: 0x04000866 RID: 2150
		private GameObject _cutsceneCameraInstance;

		// Token: 0x04000867 RID: 2151
		private KillCam _killCameraInstance;

		// Token: 0x04000868 RID: 2152
		private Cameras _currentCamera;
	}
}
