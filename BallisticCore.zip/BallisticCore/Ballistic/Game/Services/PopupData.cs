﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200016C RID: 364
	internal class PopupData
	{
		// Token: 0x04000A26 RID: 2598
		internal EPopupType Type;

		// Token: 0x04000A27 RID: 2599
		internal string Title;

		// Token: 0x04000A28 RID: 2600
		internal string Message;

		// Token: 0x04000A29 RID: 2601
		internal string[] ButtonTexts;

		// Token: 0x04000A2A RID: 2602
		internal Action<int> ButtonCallback;

		// Token: 0x04000A2B RID: 2603
		internal Action<int, string> PasswordCallback;

		// Token: 0x04000A2C RID: 2604
		internal float Progression;
	}
}
