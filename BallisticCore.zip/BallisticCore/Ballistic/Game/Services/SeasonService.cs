﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200017F RID: 383
	internal class SeasonService : IService
	{
		// Token: 0x060007B8 RID: 1976 RVA: 0x00007590 File Offset: 0x00005790
		internal override void Preprocess()
		{
			this._gameItemService = ServiceProvider.GetService<GameItemService>();
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x0000759D File Offset: 0x0000579D
		internal IEnumerable<MasterGenerator> GetAllGenerators()
		{
			return this._gameItemService.GetItemsOfType<MasterGenerator>();
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x00031804 File Offset: 0x0002FA04
		internal MasterGenerator GetGeneratorForSeason(ESeason season)
		{
			return this.GetAllGenerators().FirstOrDefault((MasterGenerator x) => x.Season == season);
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x000075AA File Offset: 0x000057AA
		internal SeasonInfo GetCurrentSeasonInfo()
		{
			return this._currentSeasonInfo;
		}

		// Token: 0x04000A89 RID: 2697
		private const string _seasonInfoDataUrl = "https://yptg3ccnw0.execute-api.us-east-1.amazonaws.com/prod/getCurrentSeason";

		// Token: 0x04000A8A RID: 2698
		private GameItemService _gameItemService;

		// Token: 0x04000A8B RID: 2699
		private SeasonInfo _currentSeasonInfo = new SeasonInfo
		{
			Season = ESeason.CORE
		};
	}
}
