﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A6 RID: 422
	public struct OnPlayerTakingFireData
	{
		// Token: 0x04000B66 RID: 2918
		public Vector3 BulletPoint;

		// Token: 0x04000B67 RID: 2919
		public Team ShooterTeam;
	}
}
