﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000159 RID: 345
	internal enum InventoryTypes
	{
		// Token: 0x0400094F RID: 2383
		LOCKBOX,
		// Token: 0x04000950 RID: 2384
		REWARD,
		// Token: 0x04000951 RID: 2385
		WEAPON,
		// Token: 0x04000952 RID: 2386
		GOLDSCRAP,
		// Token: 0x04000953 RID: 2387
		SCRAP
	}
}
