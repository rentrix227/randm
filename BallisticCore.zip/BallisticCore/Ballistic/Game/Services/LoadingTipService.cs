﻿using System;
using System.Collections.Generic;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200015B RID: 347
	public class LoadingTipService : IService
	{
		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060006A7 RID: 1703 RVA: 0x00006B09 File Offset: 0x00004D09
		internal uint Count
		{
			get
			{
				return 5U;
			}
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x00006B0C File Offset: 0x00004D0C
		internal override void Preprocess()
		{
			this.Reset();
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x0002CD34 File Offset: 0x0002AF34
		internal void Reset()
		{
			if (this.m_unseenTips == null)
			{
				this.m_unseenTips = new List<uint>();
			}
			else
			{
				this.m_unseenTips.Clear();
			}
			for (uint num = 1U; num < 6U; num += 1U)
			{
				this.m_unseenTips.Add(num);
			}
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x0002CD88 File Offset: 0x0002AF88
		internal string RetrieveLocalizationKey()
		{
			int num = Random.Range(0, this.m_unseenTips.Count * 100);
			num /= 100;
			string text = "loading_tip_" + this.m_unseenTips[num].ToString();
			this.m_unseenTips.Remove(this.m_unseenTips[num]);
			if (this.m_unseenTips.Count <= 0)
			{
				this.Reset();
			}
			return text;
		}

		// Token: 0x04000958 RID: 2392
		private const uint TIP_COUNT = 5U;

		// Token: 0x04000959 RID: 2393
		private List<uint> m_unseenTips;
	}
}
