﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Missions;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Lockbox;
using Aquiris.DataModel.ItemModel.GameItemModel.Reward;
using Aquiris.Services;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000145 RID: 325
	internal class InventoryService : IService
	{
		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x00006775 File Offset: 0x00004975
		// (set) Token: 0x0600061F RID: 1567 RVA: 0x0000677D File Offset: 0x0000497D
		internal NotificationsContainer Container { get; private set; }

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x06000620 RID: 1568 RVA: 0x0002A538 File Offset: 0x00028738
		// (remove) Token: 0x06000621 RID: 1569 RVA: 0x0002A570 File Offset: 0x00028770
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnNotificationChange;

		// Token: 0x06000622 RID: 1570 RVA: 0x0002A5A8 File Offset: 0x000287A8
		internal override void Preprocess()
		{
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._wait = new WaitForSeconds(0.1f);
			this._scraps = new List<SteamItem>();
			this._goldscraps = new List<SteamItem>();
			this._lockboxes = new List<SteamItem>();
			this._weaponSkins = new List<SteamItem>();
			this._vanityItems = new List<SteamItem>();
			this._rewards = new List<SteamItem>();
			this._isInventoryCachedUp = false;
			this.LoadNotifications();
			this.Validate(new Action<bool, byte[]>(this.ValidateAfterCacheUp));
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x00006786 File Offset: 0x00004986
		internal bool HasAccessory(List<SkinRequeriment> requeriments, List<int> identities)
		{
			return identities.All((int id) => this._weaponSkins.Exists((SteamItem t) => t.IdentityId == id)) && requeriments.All((SkinRequeriment req) => this._weaponSkins.Count((SteamItem t) => t.IdentityId % 1000 == (int)req.WeaponSkinName) >= req.Amount);
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x000067B4 File Offset: 0x000049B4
		internal override void Postprocess()
		{
			if (this._isInventoryCachedUp)
			{
				SteamInventory.DestroyResult(this._inventoryCache);
			}
			this.SaveNotifications();
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x0002A634 File Offset: 0x00028834
		internal void TriggerDropItem(Action<SteamItem> onTriggerDrop)
		{
			if (SteamApps.GetAppOwner().m_SteamID != SteamUser.GetSteamID().m_SteamID)
			{
				onTriggerDrop(null);
				return;
			}
			this._eventProxy.StartCoroutine(this.CoroutineTriggerDrop(onTriggerDrop));
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x000067D2 File Offset: 0x000049D2
		internal void ConsumeItem(SteamItem item)
		{
			this._eventProxy.StartCoroutine(this.CoroutineConsumeItem(item));
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0002A67C File Offset: 0x0002887C
		internal bool HasWeaponSkin(int steamSkinId)
		{
			return steamSkinId % 1000 == 0 || this._weaponSkins.Any((SteamItem m) => m.IdentityId == steamSkinId);
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x000067E7 File Offset: 0x000049E7
		internal bool HasPlayerSkin(HeroSkin data)
		{
			return data != null && (data.SteamAppId == 0 || SteamApps.BIsDlcInstalled(new AppId_t((uint)data.SteamAppId)));
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x0000680E File Offset: 0x00004A0E
		internal void CacheInventory()
		{
			this._eventProxy.StartCoroutine(this.CoroutineCacheItems());
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x00006822 File Offset: 0x00004A22
		internal List<SteamItem> GetCachedLockboxes()
		{
			return this._lockboxes;
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x0000682A File Offset: 0x00004A2A
		internal List<SteamItem> GetCachedWeaponSkins()
		{
			return this._weaponSkins;
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00006832 File Offset: 0x00004A32
		internal List<SteamItem> GetCachedVanities()
		{
			return this._vanityItems;
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x0000683A File Offset: 0x00004A3A
		internal List<SteamItem> GetCachedScraps()
		{
			return this._scraps;
		}

		// Token: 0x0600062E RID: 1582 RVA: 0x00006842 File Offset: 0x00004A42
		internal List<SteamItem> GetCachedGoldScraps()
		{
			return this._goldscraps;
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x0000684A File Offset: 0x00004A4A
		internal List<SteamItem> GetCachedRewards()
		{
			return this._rewards;
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x0002A6C4 File Offset: 0x000288C4
		internal void ExchangeLockbox(Lockbox lockbox, Action<bool, SteamItem[]> onExchangeResponse)
		{
			int lockboxId = lockbox.GetLockboxId();
			SteamItem steamItem = this._lockboxes.Find((SteamItem t) => t.IdentityId == lockboxId);
			if (steamItem == null)
			{
				onExchangeResponse(false, null);
				return;
			}
			SteamItem[] array = new SteamItem[] { steamItem };
			EnumBitMask<InventoryTypes> enumBitMask = new EnumBitMask<InventoryTypes>();
			enumBitMask.Set(InventoryTypes.WEAPON);
			this._eventProxy.StartCoroutine(this.CoroutineExchangeItems(array, lockbox.GetLockboxBundleId(), enumBitMask, onExchangeResponse));
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x0002A740 File Offset: 0x00028940
		internal void ExchangeRewards(SteamItem rewardItem, Reward reward, Action<bool, SteamItem[]> onExchangeResponse)
		{
			SteamItem[] array = new SteamItem[] { rewardItem };
			EnumBitMask<InventoryTypes> enumBitMask = new EnumBitMask<InventoryTypes>();
			enumBitMask.Set(InventoryTypes.SCRAP);
			enumBitMask.Set(InventoryTypes.GOLDSCRAP);
			this._eventProxy.StartCoroutine(this.CoroutineExchangeItems(array, reward.GetRewardBundleId(), enumBitMask, onExchangeResponse));
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x0002A788 File Offset: 0x00028988
		internal void ExchangeWeapons(WeaponSkinData weaponSkinData, Action<bool, SteamItem[]> onExchangeResponse)
		{
			int weaponSkinId = weaponSkinData.Weapon.GetSteamWeaponSkinId(weaponSkinData.WeaponSkin.WeaponSkinName);
			ERarity rarity = weaponSkinData.WeaponSkin.Rarity;
			int num;
			switch (rarity)
			{
			case ERarity.COMMON:
				num = InventoryHelper.ScrapGenerators[0];
				break;
			case ERarity.ADVANCED:
				num = InventoryHelper.ScrapGenerators[1];
				break;
			case ERarity.SPECIAL:
				num = InventoryHelper.ScrapGenerators[2];
				break;
			case ERarity.ELITE:
				num = InventoryHelper.ScrapGenerators[3];
				break;
			case ERarity.LEGENDARY:
				num = InventoryHelper.ScrapGenerators[4];
				break;
			default:
				if (rarity != ERarity.LEGACY)
				{
					if (rarity != ERarity.RANKED)
					{
						onExchangeResponse(false, null);
						return;
					}
					num = InventoryHelper.GoldenScrapGenerators[0];
				}
				else
				{
					num = InventoryHelper.ScrapGenerators[5];
				}
				break;
			}
			if (weaponSkinId < 0)
			{
				onExchangeResponse(false, null);
				return;
			}
			SteamItem steamItem = this._weaponSkins.Find((SteamItem t) => t.IdentityId == weaponSkinId);
			if (steamItem == null)
			{
				onExchangeResponse(false, null);
				return;
			}
			if (this._scraps.Count > 0 && this._scraps[0].Quantity + 10U > 60000U)
			{
				onExchangeResponse(false, null);
				return;
			}
			SteamItem[] array = new SteamItem[] { steamItem };
			EnumBitMask<InventoryTypes> enumBitMask = new EnumBitMask<InventoryTypes>();
			enumBitMask.Set(InventoryTypes.SCRAP);
			enumBitMask.Set(InventoryTypes.GOLDSCRAP);
			this._eventProxy.StartCoroutine(this.CoroutineExchangeItems(array, num, enumBitMask, onExchangeResponse));
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x0002A908 File Offset: 0x00028B08
		internal void ExchangeScraps(Action<bool, SteamItem[]> onExchangeResponse)
		{
			if (this._scraps.Count <= 0)
			{
				onExchangeResponse(false, null);
				return;
			}
			if (this._scraps[0].Quantity < 10U)
			{
				onExchangeResponse(false, null);
				return;
			}
			SteamItem[] array = this._scraps.GetRange(0, 1).ToArray();
			EnumBitMask<InventoryTypes> enumBitMask = new EnumBitMask<InventoryTypes>();
			enumBitMask.Set(InventoryTypes.LOCKBOX);
			this._eventProxy.StartCoroutine(this.CoroutineExchangeItems(array, 500, enumBitMask, onExchangeResponse));
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0002A98C File Offset: 0x00028B8C
		internal void ExchangeGoldScraps(Action<bool, SteamItem[]> onExchangeResponse)
		{
			if (this._goldscraps.Count < 10)
			{
				onExchangeResponse(false, null);
				return;
			}
			SteamItem[] array = this._goldscraps.GetRange(0, 10).ToArray();
			EnumBitMask<InventoryTypes> enumBitMask = new EnumBitMask<InventoryTypes>();
			enumBitMask.Set(InventoryTypes.LOCKBOX);
			this._eventProxy.StartCoroutine(this.CoroutineExchangeItems(array, 510, enumBitMask, onExchangeResponse));
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0002A9F0 File Offset: 0x00028BF0
		internal List<SteamItem> AddItemsFromServer(MissionsRewardEvent evt)
		{
			List<SteamItem> list = new List<SteamItem>();
			foreach (RewardData rewardData in evt.Reward)
			{
				SteamItem steamItem = this.ExtractItem(rewardData);
				this.AddItemIntoDatabase(steamItem);
				list.Add(steamItem);
			}
			return list;
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x00006852 File Offset: 0x00004A52
		private IEnumerator CoroutineCacheItems()
		{
			if (this._isInventoryCachedUp)
			{
				SteamInventory.DestroyResult(this._inventoryCache);
			}
			while (!SteamAPI.IsSteamRunning())
			{
				yield return null;
			}
			if (!SteamInventory.GetAllItems(ref this._inventoryCache))
			{
				Debug.Log("[CacheItems] failed to make the call.");
				SteamInventory.DestroyResult(this._inventoryCache);
				this._isInventoryCachedUp = false;
				yield break;
			}
			EResult eresult;
			for (eresult = SteamInventory.GetResultStatus(this._inventoryCache); eresult == 22; eresult = SteamInventory.GetResultStatus(this._inventoryCache))
			{
				yield return this._wait;
			}
			if (eresult == 1)
			{
				this._isInventoryCachedUp = true;
				SteamItemDetails_t[] array = new SteamItemDetails_t[10000];
				uint num = 10000U;
				if (SteamInventory.GetResultItems(this._inventoryCache, array, ref num))
				{
					this._lockboxes.Clear();
					this._weaponSkins.Clear();
					this._vanityItems.Clear();
					this._scraps.Clear();
					this._rewards.Clear();
					this._goldscraps.Clear();
					for (uint num2 = 0U; num2 < num; num2 += 1U)
					{
						SteamItem steamItem = this.ExtractItem(array[(int)(uint)((UIntPtr)num2)]);
						this.AddItemIntoDatabase(steamItem);
					}
					yield return this._eventProxy.StartCoroutine(this.CoroutineStack());
					Debug.Log("[Cache] Load Completed.");
				}
				else
				{
					Debug.Log("[CacheItems] failed to retrieve items.");
				}
			}
			else
			{
				Debug.Log("[CacheItems] failed:" + eresult.ToString());
				SteamInventory.DestroyResult(this._inventoryCache);
				this._isInventoryCachedUp = false;
			}
			ServiceProvider.GetService<LeaderboardService>().UpdateSkinScore();
			yield break;
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x0002AA64 File Offset: 0x00028C64
		private void AddItemIntoDatabase(SteamItem item)
		{
			if (item.IdentityId == 900)
			{
				this._scraps.Add(item);
			}
			if (item.IdentityId == 910)
			{
				this._goldscraps.Add(item);
			}
			if (item.IdentityId > 999 && item.IdentityId < 2000)
			{
				this._lockboxes.Add(item);
			}
			if (item.IdentityId > 2999 && item.IdentityId < 4000)
			{
				this._rewards.Add(item);
			}
			if (item.IdentityId > 4999 && item.IdentityId < 200000)
			{
				this._weaponSkins.Add(item);
			}
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x0002AB30 File Offset: 0x00028D30
		private IEnumerator CoroutineTriggerDrop(Action<SteamItem> onTriggerDrop)
		{
			SteamInventoryResult_t callback;
			if (!SteamInventory.TriggerItemDrop(ref callback, new SteamItemDef_t(0)))
			{
				Debug.Log("[TriggerDrop] failed to make the call.");
				onTriggerDrop(null);
				SteamInventory.DestroyResult(callback);
				yield break;
			}
			EResult result;
			for (result = SteamInventory.GetResultStatus(callback); result == 22; result = SteamInventory.GetResultStatus(callback))
			{
				yield return this._wait;
			}
			if (result == 1)
			{
				SteamItemDetails_t[] array = new SteamItemDetails_t[5];
				uint num = 5U;
				if (SteamInventory.GetResultItems(callback, array, ref num))
				{
					if (num > 0U)
					{
						uint num2 = 0U;
						while ((ulong)num2 < (ulong)((long)array.Length))
						{
							if (array[(int)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef > 999 && array[(int)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef < 2000)
							{
								SteamItem steamItem = this.ExtractItem(array[(int)((UIntPtr)num2)]);
								this._lockboxes.Add(steamItem);
								this.AddNotification(steamItem);
								onTriggerDrop(steamItem);
								if (this.OnItemDrop != null)
								{
									this.OnItemDrop(steamItem);
								}
								break;
							}
							num2 += 1U;
						}
					}
					else
					{
						Debug.Log("[TriggerDrop] Dropped 0 items.");
						onTriggerDrop(null);
					}
				}
			}
			else
			{
				Debug.Log("[TriggerDrop] cannot drop items yet.");
				onTriggerDrop(null);
			}
			SteamInventory.DestroyResult(callback);
			yield break;
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x00006861 File Offset: 0x00004A61
		private IEnumerator CoroutineExchangeItems(SteamItem[] items, int generator, EnumBitMask<InventoryTypes> types, Action<bool, SteamItem[]> exchangeResponseCallback)
		{
			SteamItemInstanceID_t[] array = items.Select((SteamItem t) => new SteamItemInstanceID_t(t.InstanceId)).ToArray<SteamItemInstanceID_t>();
			uint[] array2 = items.Select(delegate(SteamItem t)
			{
				if (t.IdentityId == 900)
				{
					return 10U;
				}
				return 1U;
			}).ToArray<uint>();
			SteamItemDef_t[] array3 = new SteamItemDef_t[]
			{
				new SteamItemDef_t(generator)
			};
			uint[] array4 = new uint[] { 1U };
			SteamInventoryResult_t callback;
			if (!SteamInventory.ExchangeItems(ref callback, array3, array4, 1U, array, array2, (uint)array.Length))
			{
				Debug.Log("[ExchangeLockbox] failed to make the call.");
				SteamInventory.DestroyResult(callback);
				exchangeResponseCallback(false, null);
				yield break;
			}
			EResult eresult;
			for (eresult = SteamInventory.GetResultStatus(callback); eresult == 22; eresult = SteamInventory.GetResultStatus(callback))
			{
				yield return this._wait;
			}
			if (eresult == 1)
			{
				SteamItemDetails_t[] array5 = new SteamItemDetails_t[20];
				uint num = 20U;
				if (SteamInventory.GetResultItems(callback, array5, ref num))
				{
					if (num > 0U)
					{
						List<SteamItem> generatedItems = new List<SteamItem>();
						for (uint num2 = 0U; num2 < num; num2 += 1U)
						{
							if (array5[(int)(uint)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef > 999 && array5[(int)(uint)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef < 2000 && types.IsSet(InventoryTypes.LOCKBOX))
							{
								SteamItem steamItem = this.ExtractItem(array5[(int)(uint)((UIntPtr)num2)]);
								this.AddNotification(steamItem);
								foreach (SteamItem steamItem2 in items)
								{
									if (steamItem2.IdentityId == 900)
									{
										if (items[0].Quantity > 10U)
										{
											items[0].Quantity -= 10U;
										}
										else
										{
											this._scraps.Clear();
										}
									}
									else
									{
										this._goldscraps.Remove(steamItem2);
									}
								}
								this._lockboxes.Add(steamItem);
								generatedItems.Add(steamItem);
							}
							if (array5[(int)(uint)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef > 4999 && array5[(int)(uint)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef < 200000 && types.IsSet(InventoryTypes.WEAPON))
							{
								SteamItem steamItem3 = this.ExtractItem(array5[(int)(uint)((UIntPtr)num2)]);
								this.AddNotification(steamItem3);
								if (this.OnWeaponSkinUnlocked != null)
								{
									this.OnWeaponSkinUnlocked(steamItem3);
								}
								foreach (SteamItem steamItem4 in items)
								{
									this._lockboxes.Remove(steamItem4);
								}
								this._weaponSkins.Add(steamItem3);
								generatedItems.Add(steamItem3);
							}
							if (array5[(int)(uint)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef == 900 && types.IsSet(InventoryTypes.SCRAP))
							{
								SteamItem steamItem5 = this.ExtractItem(array5[(int)(uint)((UIntPtr)num2)]);
								int num3 = 0;
								while ((long)num3 < (long)((ulong)steamItem5.Quantity))
								{
									this.AddNotification(steamItem5);
									num3++;
								}
								foreach (SteamItem steamItem6 in items)
								{
									this._weaponSkins.Remove(steamItem6);
									this._rewards.Remove(steamItem6);
								}
								this._scraps.Add(steamItem5);
								generatedItems.Add(steamItem5);
							}
							if (array5[(int)(uint)((UIntPtr)num2)].m_iDefinition.m_SteamItemDef == 910 && types.IsSet(InventoryTypes.GOLDSCRAP))
							{
								SteamItem steamItem7 = this.ExtractItem(array5[(int)(uint)((UIntPtr)num2)]);
								int num4 = 0;
								while ((long)num4 < (long)((ulong)steamItem7.Quantity))
								{
									this.AddNotification(steamItem7);
									num4++;
								}
								foreach (SteamItem steamItem8 in items)
								{
									this._weaponSkins.Remove(steamItem8);
									this._rewards.Remove(steamItem8);
								}
								this._goldscraps.Add(steamItem7);
								generatedItems.Add(steamItem7);
							}
						}
						yield return this._eventProxy.StartCoroutine(this.CoroutineStack());
						exchangeResponseCallback(generatedItems.Count > 0, generatedItems.ToArray());
						generatedItems = null;
					}
					else
					{
						Debug.Log("[ExchangeItems] failed: 0 generated.");
						exchangeResponseCallback(false, null);
					}
				}
				else
				{
					Debug.Log("[ExchangeItems] failed to retrieve items.");
					exchangeResponseCallback(false, null);
				}
			}
			else
			{
				Debug.Log("[ExchangeItems] failed:" + eresult.ToString());
				exchangeResponseCallback(false, null);
			}
			SteamInventory.DestroyResult(callback);
			ServiceProvider.GetService<LeaderboardService>().UpdateSkinScore();
			yield break;
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x0002AB54 File Offset: 0x00028D54
		private IEnumerator CoroutineStack()
		{
			List<SteamItem> toRemove = new List<SteamItem>();
			if (this._scraps.Count <= 1)
			{
				yield break;
			}
			List<SteamItem> extraStacks = this._scraps.Skip(1).ToList<SteamItem>();
			foreach (SteamItem stack in extraStacks)
			{
				SteamItemInstanceID_t stackSource = new SteamItemInstanceID_t(stack.InstanceId);
				SteamItemInstanceID_t stackDest = new SteamItemInstanceID_t(this._scraps[0].InstanceId);
				SteamInventoryResult_t callback;
				if (!SteamInventory.TransferItemQuantity(ref callback, stackSource, stack.Quantity, stackDest))
				{
					Debug.Log("[Stacking] failed to make the call.");
					SteamInventory.DestroyResult(callback);
					yield break;
				}
				EResult result;
				for (result = SteamInventory.GetResultStatus(callback); result == 22; result = SteamInventory.GetResultStatus(callback))
				{
					yield return this._wait;
				}
				if (result == 1)
				{
					SteamItemDetails_t[] array = new SteamItemDetails_t[20];
					uint num = 20U;
					if (SteamInventory.GetResultItems(callback, array, ref num))
					{
						int num2 = 0;
						while ((long)num2 < (long)((ulong)num))
						{
							foreach (SteamItem steamItem in this._scraps)
							{
								if (steamItem.InstanceId == array[num2].m_itemId.m_SteamItemInstanceID)
								{
									if (array[num2].m_unQuantity <= 0)
									{
										toRemove.Add(steamItem);
									}
									else
									{
										steamItem.Quantity = (uint)array[num2].m_unQuantity;
									}
								}
							}
							num2++;
						}
					}
					else
					{
						Debug.Log("[Stacking] failed to retrieve items.");
					}
				}
				else
				{
					Debug.Log("[Stacking] failed:" + result);
				}
				SteamInventory.DestroyResult(callback);
			}
			foreach (SteamItem steamItem2 in toRemove)
			{
				this._scraps.Remove(steamItem2);
			}
			yield break;
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x0000688D File Offset: 0x00004A8D
		private IEnumerator CoroutineConsumeItem(SteamItem item)
		{
			SteamInventoryResult_t callback;
			if (!SteamInventory.ConsumeItem(ref callback, new SteamItemInstanceID_t(item.InstanceId), item.Quantity))
			{
				Debug.Log("[ConsumeItem] failed to make the call.");
				SteamInventory.DestroyResult(callback);
				yield break;
			}
			EResult eresult;
			for (eresult = SteamInventory.GetResultStatus(callback); eresult == 22; eresult = SteamInventory.GetResultStatus(callback))
			{
				yield return this._wait;
			}
			if (eresult == 1)
			{
				this._lockboxes.Remove(item);
				this._vanityItems.Remove(item);
				this._weaponSkins.Remove(item);
				this._scraps.Remove(item);
			}
			else
			{
				Debug.Log("[ConsumeItem] failed:" + eresult.ToString());
			}
			SteamInventory.DestroyResult(callback);
			ServiceProvider.GetService<LeaderboardService>().UpdateSkinScore();
			yield break;
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0002AB70 File Offset: 0x00028D70
		private static IEnumerator HeartbeatRoutine()
		{
			for (;;)
			{
				SteamInventory.SendItemDropHeartbeat();
				yield return new WaitForSeconds(60f);
			}
			yield break;
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x0002AB84 File Offset: 0x00028D84
		private SteamItem ExtractItem(RewardData rewardData)
		{
			return new SteamItem
			{
				InstanceId = (ulong)rewardData.InstanceId,
				IdentityId = rewardData.ItemdefId,
				Quantity = (uint)rewardData.Quantity
			};
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0002ABBC File Offset: 0x00028DBC
		private SteamItem ExtractItem(SteamItemDetails_t definition)
		{
			return new SteamItem
			{
				InstanceId = definition.m_itemId.m_SteamItemInstanceID,
				IdentityId = definition.m_iDefinition.m_SteamItemDef,
				Quantity = (uint)definition.m_unQuantity
			};
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x000068A3 File Offset: 0x00004AA3
		internal void StartHeartbeat()
		{
			if (this._heartbeatRoutine == null)
			{
				this._heartbeatRoutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(InventoryService.HeartbeatRoutine());
			}
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x000068C5 File Offset: 0x00004AC5
		internal void StopHeartbeat()
		{
			if (this._heartbeatRoutine != null)
			{
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._heartbeatRoutine);
				this._heartbeatRoutine = null;
			}
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x0002AC04 File Offset: 0x00028E04
		internal void LoadNotifications()
		{
			try
			{
				string text = File.ReadAllText("BallisticConfiguration.notifications");
				this.Container = ConversionUtil.ReadUnityJson<NotificationsContainer>(text);
				Debug.Log("Loading notifications");
				if (this.Container.Version != 2U)
				{
					Debug.Log("Notifications outdated version. Resetting it");
					this.Reset();
				}
			}
			catch (Exception ex)
			{
				Debug.Log("Error reading notifications from file. Resetting it\n" + ex.StackTrace);
				this.Reset();
			}
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x0002AC90 File Offset: 0x00028E90
		internal void SaveNotifications()
		{
			try
			{
				File.WriteAllText("BallisticConfiguration.notifications", ConversionUtil.WriteUnityJson(this.Container), Encoding.UTF8);
				Debug.Log("Saved notifications");
			}
			catch
			{
				Debug.LogError("Error writing notifications file");
			}
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x0002ACE8 File Offset: 0x00028EE8
		private void AddNotification(SteamItem received)
		{
			if (received.IdentityId == 900 || received.IdentityId == 910)
			{
				this.Container.NewScraps.Add(received.InstanceId);
			}
			if (received.IdentityId > 999 && received.IdentityId < 2000)
			{
				this.Container.NewLockboxes.Add(received.InstanceId);
			}
			if (received.IdentityId > 4999)
			{
				this.Container.NewWeaponSkins.Add(received.InstanceId);
			}
			this.DispatchNotificationChange();
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x0002AD90 File Offset: 0x00028F90
		internal int GetNotificationsCount(ENotifications notification, bool exclude)
		{
			switch (notification)
			{
			case ENotifications.LOCKBOX:
				return this.Container.NewLockboxes.Count;
			case ENotifications.SCRAPS:
				return this.Container.NewScraps.Count;
			case ENotifications.ACCESSORY:
				return this.Container.NewAccessorys.Count;
			case ENotifications.WEAPONSKINS:
				return this.Container.NewWeaponSkins.Count;
			default:
				return 0;
			}
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x0002AE00 File Offset: 0x00029000
		internal void ClearNotifications(ENotifications notifications)
		{
			switch (notifications)
			{
			case ENotifications.LOCKBOX:
				this.Container.NewLockboxes = new List<ulong>();
				break;
			case ENotifications.SCRAPS:
				this.Container.NewScraps = new List<ulong>();
				break;
			case ENotifications.ACCESSORY:
				this.Container.NewAccessorys = new List<ulong>();
				break;
			case ENotifications.WEAPONSKINS:
				this.Container.NewWeaponSkins = new List<ulong>();
				break;
			}
			this.DispatchNotificationChange();
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x0002AE84 File Offset: 0x00029084
		internal void Reset()
		{
			Debug.Log("Resetting notifications");
			this.Container = new NotificationsContainer
			{
				Version = 2U
			};
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x000068E9 File Offset: 0x00004AE9
		protected virtual void DispatchNotificationChange()
		{
			if (this.OnNotificationChange != null)
			{
				this.OnNotificationChange();
			}
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x00006901 File Offset: 0x00004B01
		internal void Validate(Action<bool, byte[]> onValidationCompleted = null)
		{
			this._eventProxy.StartCoroutine(this.ValidationRestart(onValidationCompleted));
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x0002AEB0 File Offset: 0x000290B0
		private IEnumerator ValidationRestart(Action<bool, byte[]> onValidationCompleted)
		{
			yield return this._eventProxy.StartCoroutine(this.CoroutineCacheItems());
			uint binarySpace;
			if (!SteamInventory.SerializeResult(this._inventoryCache, null, ref binarySpace))
			{
				if (onValidationCompleted != null)
				{
					onValidationCompleted(false, null);
				}
				Debug.Log("Failed to Serialize");
			}
			this._inventoryCacheBytes = new byte[binarySpace];
			if (!SteamInventory.SerializeResult(this._inventoryCache, this._inventoryCacheBytes, ref binarySpace))
			{
				if (onValidationCompleted != null)
				{
					onValidationCompleted(false, null);
				}
				Debug.Log("Failed to Serialize");
			}
			if (onValidationCompleted != null)
			{
				onValidationCompleted(true, this._inventoryCacheBytes);
			}
			yield break;
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x00005457 File Offset: 0x00003657
		private void ValidateAfterCacheUp(bool success, byte[] serializedArray)
		{
			ServiceProvider.GetService<SoldiersService>().ValidateAll();
		}

		// Token: 0x040008D8 RID: 2264
		private const uint _version = 2U;

		// Token: 0x040008D9 RID: 2265
		private const string _fileName = "BallisticConfiguration.notifications";

		// Token: 0x040008DC RID: 2268
		internal Action<SteamItem> OnItemDrop;

		// Token: 0x040008DD RID: 2269
		internal Action<SteamItem> OnWeaponSkinUnlocked;

		// Token: 0x040008DE RID: 2270
		private EventProxy _eventProxy;

		// Token: 0x040008DF RID: 2271
		private WaitForSeconds _wait;

		// Token: 0x040008E0 RID: 2272
		private List<SteamItem> _rewards;

		// Token: 0x040008E1 RID: 2273
		private List<SteamItem> _scraps;

		// Token: 0x040008E2 RID: 2274
		private List<SteamItem> _goldscraps;

		// Token: 0x040008E3 RID: 2275
		private List<SteamItem> _lockboxes;

		// Token: 0x040008E4 RID: 2276
		private List<SteamItem> _weaponSkins;

		// Token: 0x040008E5 RID: 2277
		private List<SteamItem> _vanityItems;

		// Token: 0x040008E6 RID: 2278
		private Coroutine _heartbeatRoutine;

		// Token: 0x040008E7 RID: 2279
		private SteamInventoryResult_t _inventoryCache;

		// Token: 0x040008E8 RID: 2280
		private byte[] _inventoryCacheBytes;

		// Token: 0x040008E9 RID: 2281
		private bool _isInventoryCachedUp;
	}
}
