﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000144 RID: 324
	internal class InputControlService : IService
	{
		// Token: 0x06000613 RID: 1555 RVA: 0x00006654 File Offset: 0x00004854
		internal void ClearAll()
		{
			this._controllerInputMap.Clear();
			this._controllerMouseMap.Clear();
			this._controllerPartialMap.Clear();
			this.UpdateInput();
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x0000667D File Offset: 0x0000487D
		internal void SetInput(AbstractView view, bool isInputEnabled)
		{
			if (view != null)
			{
				this._controllerInputMap[view] = isInputEnabled;
				this.UpdateInput();
			}
			else
			{
				Debug.LogError("Controller param is null");
			}
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x000066AD File Offset: 0x000048AD
		internal void SetMouse(AbstractView view, bool isMouseEnabled)
		{
			if (view != null)
			{
				this._controllerMouseMap[view] = isMouseEnabled;
				this.UpdateInput();
			}
			else
			{
				Debug.LogError("Controller param is null");
			}
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x000066DD File Offset: 0x000048DD
		internal void RemoveMouse(AbstractView view)
		{
			if (view != null)
			{
				this._controllerMouseMap.Remove(view);
				this.UpdateInput();
			}
			else
			{
				Debug.LogError("Controller param is null");
			}
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x0000670D File Offset: 0x0000490D
		internal void SetPartialInput(AbstractView view, bool isPartialInputEnabled)
		{
			if (view != null)
			{
				this._controllerPartialMap[view] = isPartialInputEnabled;
				this.UpdateInput();
			}
			else
			{
				Debug.LogError("Controller param is null");
			}
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x0002A2D4 File Offset: 0x000284D4
		private void UpdateInput()
		{
			this._result = true;
			foreach (bool flag in this._controllerInputMap.Values)
			{
				this._result = this._result && flag;
			}
			this._isInputEnabled = this._result;
			this._result = true;
			foreach (bool flag2 in this._controllerPartialMap.Values)
			{
				this._result = this._result && flag2;
			}
			this._isPartialInputEnabled = this._result;
			this._result = this._controllerMouseMap.Count <= 0;
			foreach (bool flag3 in this._controllerMouseMap.Values)
			{
				this._result = this._result || flag3;
			}
			this._isMouseEnabled = this._result;
			this.SetMouseAndInput(this._isInputEnabled, this._isPartialInputEnabled, this._isMouseEnabled);
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x0002A450 File Offset: 0x00028650
		private void SetMouseAndInput(bool isInputEnabled, bool isInputPartiallyEnabled, bool isMouseEnabled)
		{
			Cursor.visible = isMouseEnabled;
			Cursor.lockState = ((!isMouseEnabled) ? 1 : 0);
			if (isInputEnabled)
			{
				this._optionControlService.EnableInput();
			}
			else
			{
				this._optionControlService.DisableInput();
			}
			if (isInputPartiallyEnabled)
			{
				this._optionControlService.EnablePartial();
			}
			else
			{
				this._optionControlService.DisablePartial();
			}
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x0002A4B8 File Offset: 0x000286B8
		internal override void Preprocess()
		{
			this._controllerInputMap = new Dictionary<AbstractView, bool>();
			this._controllerMouseMap = new Dictionary<AbstractView, bool>();
			this._controllerPartialMap = new Dictionary<AbstractView, bool>();
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._eventProxy.EUpdate.AddListener(new Action(this.OnUpdate));
			this.UpdateInput();
			this.SetMouseAndInput(this._isInputEnabled, this._isPartialInputEnabled, this._isMouseEnabled);
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x0000673D File Offset: 0x0000493D
		private void OnUpdate()
		{
			this.SetMouseAndInput(this._isInputEnabled, this._isPartialInputEnabled, this._isMouseEnabled);
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x00006757 File Offset: 0x00004957
		internal override void Postprocess()
		{
			this._eventProxy.EUpdate.RemoveListener(new Action(this.OnUpdate));
		}

		// Token: 0x040008CF RID: 2255
		private Dictionary<AbstractView, bool> _controllerInputMap;

		// Token: 0x040008D0 RID: 2256
		private Dictionary<AbstractView, bool> _controllerPartialMap;

		// Token: 0x040008D1 RID: 2257
		private Dictionary<AbstractView, bool> _controllerMouseMap;

		// Token: 0x040008D2 RID: 2258
		private OptionControlService _optionControlService;

		// Token: 0x040008D3 RID: 2259
		private EventProxy _eventProxy;

		// Token: 0x040008D4 RID: 2260
		private bool _isInputEnabled;

		// Token: 0x040008D5 RID: 2261
		private bool _isPartialInputEnabled;

		// Token: 0x040008D6 RID: 2262
		private bool _isMouseEnabled;

		// Token: 0x040008D7 RID: 2263
		private bool _result;
	}
}
