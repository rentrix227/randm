﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020004F3 RID: 1267
	internal enum LeaderboardPrize
	{
		// Token: 0x04001CE2 RID: 7394
		GOLD_LOCKBOX,
		// Token: 0x04001CE3 RID: 7395
		GOLD_SCRAP,
		// Token: 0x04001CE4 RID: 7396
		SCRAP,
		// Token: 0x04001CE5 RID: 7397
		NONE
	}
}
