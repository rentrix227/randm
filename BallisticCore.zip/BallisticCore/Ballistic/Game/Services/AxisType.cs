﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000165 RID: 357
	public enum AxisType
	{
		// Token: 0x040009AA RID: 2474
		MOUSE_X,
		// Token: 0x040009AB RID: 2475
		MOUSE_Y,
		// Token: 0x040009AC RID: 2476
		SCROLL_WHEEL,
		// Token: 0x040009AD RID: 2477
		HORIZONTAL,
		// Token: 0x040009AE RID: 2478
		VERTICAL
	}
}
