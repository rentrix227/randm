﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200019E RID: 414
	public struct OnProjectileExplodeData
	{
		// Token: 0x04000B53 RID: 2899
		public string WeaponName;

		// Token: 0x04000B54 RID: 2900
		public Vector3 ExplosionPoint;
	}
}
