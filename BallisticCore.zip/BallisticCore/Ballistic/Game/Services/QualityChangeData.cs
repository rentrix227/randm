﻿using System;
using Aquiris.Ballistic.Game.Helper;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000143 RID: 323
	public struct QualityChangeData
	{
		// Token: 0x040008CC RID: 2252
		public OptionPresetLevel Quality;

		// Token: 0x040008CD RID: 2253
		public AntialisingPresetLevel AntiAliasing;

		// Token: 0x040008CE RID: 2254
		public bool MotionBlur;
	}
}
