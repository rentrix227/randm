﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200019C RID: 412
	public struct OnShootData
	{
		// Token: 0x04000B4C RID: 2892
		public string WeaponName;

		// Token: 0x04000B4D RID: 2893
		public bool IsFirstPerson;

		// Token: 0x04000B4E RID: 2894
		public Transform ShooterOrigin;

		// Token: 0x04000B4F RID: 2895
		public bool IsAiming;
	}
}
