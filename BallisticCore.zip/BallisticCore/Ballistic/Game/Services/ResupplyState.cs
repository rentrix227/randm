﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200017D RID: 381
	internal struct ResupplyState
	{
		// Token: 0x04000A86 RID: 2694
		internal bool Active;

		// Token: 0x04000A87 RID: 2695
		internal double Cooldown;
	}
}
