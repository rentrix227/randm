﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000198 RID: 408
	internal class EngageEntry
	{
		// Token: 0x04000B20 RID: 2848
		internal long VictimId;

		// Token: 0x04000B21 RID: 2849
		internal float TimeStamp;

		// Token: 0x04000B22 RID: 2850
		internal float AccumulatedDamage;

		// Token: 0x04000B23 RID: 2851
		internal bool HasEngaged;
	}
}
