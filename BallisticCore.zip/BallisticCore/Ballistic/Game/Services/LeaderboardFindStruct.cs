﻿using System;
using Aquiris.Ballistic.Utils;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020004F7 RID: 1271
	internal class LeaderboardFindStruct
	{
		// Token: 0x06001B04 RID: 6916 RVA: 0x00013C99 File Offset: 0x00011E99
		public LeaderboardFindStruct(int currentMonth, int currentWeek)
		{
			this._currentMonth = currentMonth;
			this._currentWeek = currentWeek;
		}

		// Token: 0x06001B05 RID: 6917 RVA: 0x0008C0E0 File Offset: 0x0008A2E0
		internal void SetLeaderboard(Leaderboards leaderboard)
		{
			this._leaderboard = leaderboard;
			if (leaderboard >= Leaderboards.SHADOW_LADDER && leaderboard <= Leaderboards.BESERKER_LADDER)
			{
				int num = (int)(leaderboard - Leaderboards.SHADOW_LADDER);
				if (num <= 3 || num - 5 <= 1)
				{
					goto IL_005F;
				}
			}
			if (leaderboard == Leaderboards.PERFORMANCE_LADDER)
			{
				this._leaderboardName = StatisticsConstants.gperf_leaderboard_name(leaderboard, this._currentMonth);
				return;
			}
			if (leaderboard != Leaderboards.WRAITH_LADDER)
			{
				this._leaderboardName = StatisticsConstants.gperf_leaderboard_name(leaderboard);
				return;
			}
			IL_005F:
			this._leaderboardName = StatisticsConstants.gperf_leaderboard_name(leaderboard, this._currentWeek);
		}

		// Token: 0x06001B06 RID: 6918 RVA: 0x0008C160 File Offset: 0x0008A360
		internal void Dispatch()
		{
			SteamAPICall_t steamAPICall_t = SteamUserStats.FindLeaderboard(this._leaderboardName);
			SteamCallbacks.LeaderboardFindResult_t.RegisterCallResult(new Action<LeaderboardFindResult_t, bool>(this.OnFind), steamAPICall_t);
		}

		// Token: 0x06001B07 RID: 6919 RVA: 0x00013CAF File Offset: 0x00011EAF
		private void OnFind(LeaderboardFindResult_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				return;
			}
			if (evt.m_bLeaderboardFound == 1)
			{
				this.DisposeFind(evt);
				return;
			}
			this.DisposeFailure();
		}

		// Token: 0x06001B08 RID: 6920 RVA: 0x00013CCC File Offset: 0x00011ECC
		protected virtual void DisposeFailure()
		{
			Debug.LogWarning("Dispatch Failed:" + this._leaderboardName);
		}

		// Token: 0x06001B09 RID: 6921 RVA: 0x00013CE3 File Offset: 0x00011EE3
		protected virtual void DisposeFind(LeaderboardFindResult_t evt)
		{
			this._leaderboardPointer = evt.m_hSteamLeaderboard;
		}

		// Token: 0x04001CF5 RID: 7413
		private string _leaderboardName;

		// Token: 0x04001CF6 RID: 7414
		protected Leaderboards _leaderboard;

		// Token: 0x04001CF7 RID: 7415
		protected SteamLeaderboard_t _leaderboardPointer;

		// Token: 0x04001CF8 RID: 7416
		private readonly int _currentMonth;

		// Token: 0x04001CF9 RID: 7417
		private readonly int _currentWeek;
	}
}
