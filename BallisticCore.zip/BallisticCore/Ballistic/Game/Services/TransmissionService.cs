﻿using System;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200019A RID: 410
	public class TransmissionService : IService
	{
		// Token: 0x0600089E RID: 2206 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Preprocess()
		{
		}

		// Token: 0x0600089F RID: 2207 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x04000B3D RID: 2877
		public Signal<OnWeaponInitializedData> OnWeaponInitialized;

		// Token: 0x04000B3E RID: 2878
		public Signal<OnShootData> OnShoot;

		// Token: 0x04000B3F RID: 2879
		public Signal<OnProjectileHitData> OnProjectileHit;

		// Token: 0x04000B40 RID: 2880
		public Signal<OnProjectileExplodeData> OnProjectileExplode;

		// Token: 0x04000B41 RID: 2881
		public Signal<OnProjectileEnterPlayerRangeData> OnProjectileEnterPlayerRange;

		// Token: 0x04000B42 RID: 2882
		public Signal<OnDrawData> OnDraw;

		// Token: 0x04000B43 RID: 2883
		public Signal<OnAimData> OnAim;

		// Token: 0x04000B44 RID: 2884
		public Signal<OnReloadData> OnReload;

		// Token: 0x04000B45 RID: 2885
		public Signal<OnBulletHitData> OnBulletHit;

		// Token: 0x04000B46 RID: 2886
		public Signal<OnPlayerTakingFireData> OnPlayerTakingFire;

		// Token: 0x04000B47 RID: 2887
		public Signal<OnGlassShatter> OnGlassShatter;

		// Token: 0x04000B48 RID: 2888
		public Signal<OnGlassBreak> OnGlassBreak;
	}
}
