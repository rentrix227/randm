﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000181 RID: 385
	internal class ServerInfoService : IService
	{
		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060007C0 RID: 1984 RVA: 0x000075C2 File Offset: 0x000057C2
		// (set) Token: 0x060007C1 RID: 1985 RVA: 0x000075CA File Offset: 0x000057CA
		public string BannerUrl { get; private set; }

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060007C2 RID: 1986 RVA: 0x000075D3 File Offset: 0x000057D3
		// (set) Token: 0x060007C3 RID: 1987 RVA: 0x000075DB File Offset: 0x000057DB
		public string ClickUrl { get; private set; }

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060007C4 RID: 1988 RVA: 0x000075E4 File Offset: 0x000057E4
		// (set) Token: 0x060007C5 RID: 1989 RVA: 0x000075EC File Offset: 0x000057EC
		public Texture2D BannerTexture { get; private set; }

		// Token: 0x060007C6 RID: 1990 RVA: 0x000075F5 File Offset: 0x000057F5
		internal override void Preprocess()
		{
			this._coroutine = null;
			this.BannerTexture = null;
		}

		// Token: 0x060007C7 RID: 1991 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060007C8 RID: 1992 RVA: 0x00007605 File Offset: 0x00005805
		public void UpdateInfo(string bannerUrl, string clickUrl)
		{
			this.BannerUrl = bannerUrl;
			this.ClickUrl = clickUrl;
			this.BannerTexture = null;
			this.LoadBannerTexture();
		}

		// Token: 0x060007C9 RID: 1993 RVA: 0x00031838 File Offset: 0x0002FA38
		private void LoadBannerTexture()
		{
			if (string.IsNullOrEmpty(this.BannerUrl))
			{
				return;
			}
			if (this._coroutine != null)
			{
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._coroutine);
			}
			this._coroutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.LoadBannerRoutine());
		}

		// Token: 0x060007CA RID: 1994 RVA: 0x00031888 File Offset: 0x0002FA88
		private IEnumerator LoadBannerRoutine()
		{
			WWW request = new WWW(this.BannerUrl);
			yield return request;
			if (string.IsNullOrEmpty(request.error))
			{
				this.BannerTexture = new Texture2D(326, 82, 10, false);
				request.LoadImageIntoTexture(this.BannerTexture);
				if (this.OnBannerLoaded != null)
				{
					this.OnBannerLoaded();
				}
			}
			yield break;
		}

		// Token: 0x04000A90 RID: 2704
		public Action OnBannerLoaded;

		// Token: 0x04000A91 RID: 2705
		private const int _bannerWidth = 326;

		// Token: 0x04000A92 RID: 2706
		private const int _bannerHeight = 82;

		// Token: 0x04000A93 RID: 2707
		private Coroutine _coroutine;
	}
}
