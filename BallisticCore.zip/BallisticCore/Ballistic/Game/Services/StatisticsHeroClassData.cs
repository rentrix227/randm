﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000197 RID: 407
	internal class StatisticsHeroClassData
	{
		// Token: 0x06000874 RID: 2164 RVA: 0x00007E02 File Offset: 0x00006002
		internal int GetStatistic(EHeroStatistic stat)
		{
			if (!this._currentStatistics.ContainsKey(stat))
			{
				this._currentStatistics.Add(stat, 0);
			}
			return this._currentStatistics[stat];
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x00007E2E File Offset: 0x0000602E
		internal float GetLeaderboardStatistic(EGameMode mode)
		{
			if (!this._currentLeaderboardStatistic.ContainsKey(mode))
			{
				this._currentLeaderboardStatistic.Add(mode, 0f);
			}
			return this._currentLeaderboardStatistic[mode];
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x00007E5E File Offset: 0x0000605E
		internal int SetStatistic(EHeroStatistic stat, int value)
		{
			if (!this._currentStatistics.ContainsKey(stat))
			{
				this._currentStatistics.Add(stat, 0);
			}
			this._currentStatistics[stat] = value;
			return this._currentStatistics[stat];
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x00007E97 File Offset: 0x00006097
		internal void SetLeaderboardStatistic(EGameMode mode, float value)
		{
			if (!this._currentLeaderboardStatistic.ContainsKey(mode))
			{
				this._currentLeaderboardStatistic.Add(mode, 0f);
			}
			this._currentLeaderboardStatistic[mode] = value;
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000878 RID: 2168 RVA: 0x00007EC8 File Offset: 0x000060C8
		internal int Kills
		{
			get
			{
				return this.GetStatistic(EHeroStatistic.KILLS);
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000879 RID: 2169 RVA: 0x00007ED1 File Offset: 0x000060D1
		internal int Deaths
		{
			get
			{
				return this.GetStatistic(EHeroStatistic.DEATHS);
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600087A RID: 2170 RVA: 0x00007EDA File Offset: 0x000060DA
		internal int Engages
		{
			get
			{
				return this.GetStatistic(EHeroStatistic.ENGAGES);
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600087B RID: 2171 RVA: 0x00007EE3 File Offset: 0x000060E3
		internal int Headshots
		{
			get
			{
				return this.GetStatistic(EHeroStatistic.HEADSHOTS);
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x0600087C RID: 2172 RVA: 0x00007EEC File Offset: 0x000060EC
		internal int Assists
		{
			get
			{
				return this.GetStatistic(EHeroStatistic.ASSISTS);
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x0600087D RID: 2173 RVA: 0x00007EF5 File Offset: 0x000060F5
		internal int Xp
		{
			get
			{
				return this.GetStatistic(EHeroStatistic.XP);
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x0600087E RID: 2174 RVA: 0x00007EFE File Offset: 0x000060FE
		internal float KillDeathRatio
		{
			get
			{
				return StatisticsService.GetKillDeathRatio(this.Kills, this.Deaths);
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x0600087F RID: 2175 RVA: 0x00007F11 File Offset: 0x00006111
		internal float KillRatio
		{
			get
			{
				if (this.Engages > 0)
				{
					return (float)this.Kills / (float)this.Engages;
				}
				return 0f;
			}
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00007F34 File Offset: 0x00006134
		internal int IncrementStatistic(EHeroStatistic statistic, int amount)
		{
			return this.SetStatistic(statistic, this.GetStatistic(statistic) + amount);
		}

		// Token: 0x04000B1E RID: 2846
		private Dictionary<EHeroStatistic, int> _currentStatistics = new Dictionary<EHeroStatistic, int>();

		// Token: 0x04000B1F RID: 2847
		private Dictionary<EGameMode, float> _currentLeaderboardStatistic = new Dictionary<EGameMode, float>();
	}
}
