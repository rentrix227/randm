﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000195 RID: 405
	internal enum EGeneralStatistic
	{
		// Token: 0x04000B04 RID: 2820
		WINS,
		// Token: 0x04000B05 RID: 2821
		LOSES,
		// Token: 0x04000B06 RID: 2822
		SAVIOR_KILLS,
		// Token: 0x04000B07 RID: 2823
		KILL_ASSISTS,
		// Token: 0x04000B08 RID: 2824
		SHOTGUN_KILLS,
		// Token: 0x04000B09 RID: 2825
		SNIPER_KILLS,
		// Token: 0x04000B0A RID: 2826
		SMG_KILLS,
		// Token: 0x04000B0B RID: 2827
		ASSAULT_RIFLE_KILLS,
		// Token: 0x04000B0C RID: 2828
		MACHINE_PISTOL_KILLS,
		// Token: 0x04000B0D RID: 2829
		PISTOL_KILLS,
		// Token: 0x04000B0E RID: 2830
		GRENADE_KILLS,
		// Token: 0x04000B0F RID: 2831
		MELEE_KILLS,
		// Token: 0x04000B10 RID: 2832
		HEADSHOT_KILLS,
		// Token: 0x04000B11 RID: 2833
		LMG_KILLS,
		// Token: 0x04000B12 RID: 2834
		MATCHES_PLAYED,
		// Token: 0x04000B13 RID: 2835
		LASTMATCH
	}
}
