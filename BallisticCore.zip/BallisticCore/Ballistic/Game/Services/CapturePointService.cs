﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200013B RID: 315
	public class CapturePointService : IService
	{
		// Token: 0x060005E7 RID: 1511 RVA: 0x00006518 File Offset: 0x00004718
		internal override void Preprocess()
		{
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._eventProxy.EUpdate.AddListener(new Action(this.GameUpdate));
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x00006557 File Offset: 0x00004757
		internal override void Postprocess()
		{
			this._eventProxy.EUpdate.RemoveListener(new Action(this.GameUpdate));
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x00006575 File Offset: 0x00004775
		private void GameUpdate()
		{
			if (this._networkGameService.IsConnected())
			{
				this.UpdatePoints();
			}
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x000291AC File Offset: 0x000273AC
		public CapturePointService.PointData GetPointData(string pointName)
		{
			CapturePointService.PointData pointData = null;
			for (int i = 0; i < this.PointsData.Count; i++)
			{
				if (this.PointsData[i].PointName == pointName)
				{
					pointData = this.PointsData[i];
				}
			}
			return pointData;
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x00029204 File Offset: 0x00027404
		private void UpdatePoints()
		{
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			if (gameModeMetaData == null)
			{
				return;
			}
			if (gameModeMetaData.GameMetaData.PointInfo == null)
			{
				return;
			}
			if (gameModeMetaData.GameMetaData.PointInfo.Count != this.PointsData.Count)
			{
				this.PointsData.Clear();
			}
			for (int i = 0; i < gameModeMetaData.GameMetaData.PointInfo.Count; i++)
			{
				CapturePointService.PointData pointData = this.GetPointData(gameModeMetaData.GameMetaData.PointInfo[i].PointName);
				if (pointData == null)
				{
					pointData = new CapturePointService.PointData(gameModeMetaData.GameMetaData.PointInfo[i].PointName);
					this.PointsData.Add(pointData);
				}
				Team team = (Team)gameModeMetaData.GameMetaData.PointInfo[i].CurrentTeamOwner;
				Team team2 = Team.NONE;
				float num = (float)gameModeMetaData.GameMetaData.PointInfo[i].CurrentCaptureGaugeValues[1] / (float)gameModeMetaData.GameMetaData.PointInfo[i].CapCaptureGaugeValues[1];
				float num2 = (float)gameModeMetaData.GameMetaData.PointInfo[i].CurrentCaptureGaugeValues[2] / (float)gameModeMetaData.GameMetaData.PointInfo[i].CapCaptureGaugeValues[2];
				if (team == Team.NONE)
				{
					if (num > num2 && num > 0f)
					{
						team2 = Team.MFA;
						pointData.CaptureAmount = num;
					}
					else if (num2 > num && num2 > 0f)
					{
						team2 = Team.SMOKE;
						pointData.CaptureAmount = num2;
					}
				}
				else if (team == Team.MFA)
				{
					team2 = Team.SMOKE;
					pointData.CaptureAmount = 1f - num;
					pointData.IsProtected = (int)gameModeMetaData.GameMetaData.PointInfo[i].PlayersOnPoint[1] > 0;
				}
				else if (team == Team.SMOKE)
				{
					team2 = Team.MFA;
					pointData.CaptureAmount = 1f - num2;
					pointData.IsProtected = (int)gameModeMetaData.GameMetaData.PointInfo[i].PlayersOnPoint[2] > 0;
				}
				if (this._gameModeService.GameMode == EGameMode.KingOfTheHill)
				{
					pointData.CaptureAmount = 0f;
				}
				pointData.OwnerTeam = UIEnums.GetRelativeTeam(team);
				pointData.CapturingTeam = UIEnums.GetRelativeTeam(team2);
			}
		}

		// Token: 0x0400086D RID: 2157
		public List<CapturePointService.PointData> PointsData = new List<CapturePointService.PointData>();

		// Token: 0x0400086E RID: 2158
		private NetworkGameService _networkGameService;

		// Token: 0x0400086F RID: 2159
		private GameModeService _gameModeService;

		// Token: 0x04000870 RID: 2160
		private EventProxy _eventProxy;

		// Token: 0x0200013C RID: 316
		public class PointData
		{
			// Token: 0x060005EC RID: 1516 RVA: 0x0000658D File Offset: 0x0000478D
			public PointData(string pointName)
			{
				this.PointName = pointName;
			}

			// Token: 0x04000871 RID: 2161
			public string PointName;

			// Token: 0x04000872 RID: 2162
			public UITeam OwnerTeam;

			// Token: 0x04000873 RID: 2163
			public UITeam CapturingTeam;

			// Token: 0x04000874 RID: 2164
			public float CaptureAmount;

			// Token: 0x04000875 RID: 2165
			public bool IsProtected;
		}
	}
}
