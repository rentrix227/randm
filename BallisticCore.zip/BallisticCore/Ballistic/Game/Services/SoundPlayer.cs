﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200018D RID: 397
	public struct SoundPlayer
	{
		// Token: 0x0600082F RID: 2095 RVA: 0x00032B70 File Offset: 0x00030D70
		public void Play()
		{
			if (this.UseRandomVolume)
			{
				this.Sound.volume = this.Volume + Random.Range(this.RndVolumeMinMax.x, this.RndVolumeMinMax.y);
			}
			if (this.UseRandomPitch)
			{
				this.Sound.pitch = this.Pitch + Random.Range(this.RndPitchMinMax.x, this.RndPitchMinMax.y);
			}
			this.Sound.Play();
		}

		// Token: 0x04000ACC RID: 2764
		public AudioSource Sound;

		// Token: 0x04000ACD RID: 2765
		public float Volume;

		// Token: 0x04000ACE RID: 2766
		public float Pitch;

		// Token: 0x04000ACF RID: 2767
		public bool UseRandomVolume;

		// Token: 0x04000AD0 RID: 2768
		public Vector2 RndVolumeMinMax;

		// Token: 0x04000AD1 RID: 2769
		public bool UseRandomPitch;

		// Token: 0x04000AD2 RID: 2770
		public Vector2 RndPitchMinMax;
	}
}
