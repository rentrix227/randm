﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200017E RID: 382
	internal struct SeasonInfo
	{
		// Token: 0x04000A88 RID: 2696
		public ESeason Season;
	}
}
