﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A4 RID: 420
	public struct OnGlassBreak
	{
		// Token: 0x04000B60 RID: 2912
		public Vector3 Position;
	}
}
