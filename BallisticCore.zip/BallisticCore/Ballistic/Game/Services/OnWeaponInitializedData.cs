﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200019B RID: 411
	public struct OnWeaponInitializedData
	{
		// Token: 0x04000B49 RID: 2889
		public string WeaponName;

		// Token: 0x04000B4A RID: 2890
		public bool IsFirstPerson;

		// Token: 0x04000B4B RID: 2891
		public Transform WeaponRoot;
	}
}
