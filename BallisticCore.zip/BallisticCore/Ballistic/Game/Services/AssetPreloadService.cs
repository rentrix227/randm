﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Character.PlayerList;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Loadout;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameHeroModel;
using Aquiris.Services.ItemModel.GameItemModel.GameHeroSkinModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000134 RID: 308
	public class AssetPreloadService : IService
	{
		// Token: 0x060005BB RID: 1467 RVA: 0x00028398 File Offset: 0x00026598
		internal override void Preprocess()
		{
			HeroService service = ServiceProvider.GetService<HeroService>();
			HeroSkinService service2 = ServiceProvider.GetService<HeroSkinService>();
			this._preLoadedAssets = new Dictionary<string, GameObject>();
			foreach (HeroItemData heroItemData in service.PossibleHeroes())
			{
				string itemModel = service2.GetHeroSkinById(heroItemData.GameItem.StandardItemMap[ELoadoutNumber.LOADOUT1][EHeroItemSlot.Skin]).ItemModel;
				this._preLoadedAssets.Add(itemModel, Resources.Load<GameObject>(itemModel));
				this._preLoadedAssets.Add(itemModel + "_arms", Resources.Load<GameObject>(itemModel + "_arms"));
			}
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x0002846C File Offset: 0x0002666C
		private static IEnumerator AsyncResource<T>(string prefabName, Action<T> onLoadCompleted) where T : Object
		{
			ResourceRequest rqt = Resources.LoadAsync<T>(prefabName);
			while (!rqt.isDone)
			{
				yield return null;
			}
			onLoadCompleted(rqt.asset as T);
			yield break;
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x00006422 File Offset: 0x00004622
		public void LoadAsync<T>(string prefabName, Action<T> onLoadCompleted) where T : Object
		{
			this._eventProxy.StartCoroutine(AssetPreloadService.AsyncResource<T>(prefabName, onLoadCompleted));
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x00028490 File Offset: 0x00026690
		public GameObject Load(string prefabName)
		{
			GameObject gameObject;
			if (!this._preLoadedAssets.TryGetValue(prefabName, out gameObject))
			{
				GameObject gameObject2 = Resources.Load<GameObject>(prefabName);
				this._preLoadedAssets.Add(prefabName, gameObject2);
				return gameObject2;
			}
			if (gameObject != null)
			{
				return gameObject;
			}
			return Resources.Load<GameObject>(prefabName);
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x00006437 File Offset: 0x00004637
		private void OnSceneLoaded(EBaseScene scene)
		{
			if (scene == EBaseScene.InGame)
			{
				this._eventProxy.StartCoroutine(this.ForcePreloadCharacters());
			}
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x000284DC File Offset: 0x000266DC
		public IEnumerator ForcePreloadCharacters()
		{
			HeroService heroService = ServiceProvider.GetService<HeroService>();
			SoldiersService soldierService = ServiceProvider.GetService<SoldiersService>();
			int clientUserId = -100;
			foreach (HeroItemData possibleHero in heroService.PossibleHeroes())
			{
				foreach (PlayerLoadoutData loadout in soldierService.GetPlayerClassLoadout(possibleHero.GameItem.UniqueIdentifier))
				{
					LoadoutInfo info = new LoadoutInfo
					{
						Hero = possibleHero.GameItem.ItemId,
						HeroLevel = 1,
						LoadoutItemMap = new Dictionary<int, int>(),
						SkillList = new List<int>()
					};
					info.LoadoutItemMap[1] = loadout.PlayerItem.ItemMap[EHeroItemSlot.PrimaryWeapon];
					info.LoadoutItemMap[2] = loadout.PlayerItem.ItemMap[EHeroItemSlot.SecondaryWeapon];
					info.LoadoutItemMap[3] = loadout.PlayerItem.ItemMap[EHeroItemSlot.MeleeWeapon];
					info.LoadoutItemMap[4] = loadout.PlayerItem.ItemMap[EHeroItemSlot.Explosive];
					info.LoadoutItemMap[5] = loadout.PlayerItem.ItemMap[EHeroItemSlot.Skin];
					info.LoadoutItemMap[6] = 0;
					info.LoadoutItemMap[7] = 0;
					info.LoadoutItemMap[8] = 0;
					info.LoadoutItemMap[9] = 0;
					info.LoadoutItemMap[11] = 130;
					info.LoadoutItemMap[13] = 130;
					info.LoadoutItemMap[15] = 130;
					info.LoadoutItemMap[14] = 130;
					info.LoadoutItemMap[12] = 130;
					foreach (EHeroSkillV2 eheroSkillV in loadout.PlayerItem.Skills)
					{
						info.SkillList.Add((int)eheroSkillV);
					}
					int weaponInUse = info.LoadoutItemMap[1];
					sbyte team = 1;
					ServiceProvider.GetService<NetworkGameService>().CreateFakeClient((long)clientUserId, info, team, weaponInUse);
					SpawnEvent simulatedSpawnEvent = new SpawnEvent
					{
						User = (long)clientUserId,
						SpawnLocationId = "default",
						WeaponInUse = weaponInUse,
						Loadout = info
					};
					ServiceProvider.GetService<NetworkGameService>().SimulateSpawnEvent(simulatedSpawnEvent);
					while (!NetworkCharacterTable.ActivePlayers.ContainsKey((long)clientUserId))
					{
						yield return null;
					}
					ServiceProvider.GetService<NetworkGameService>().DestroyFakeClient((long)clientUserId);
					clientUserId--;
				}
			}
			yield break;
		}

		// Token: 0x0400084C RID: 2124
		private EventProxy _eventProxy;

		// Token: 0x0400084D RID: 2125
		private Dictionary<string, GameObject> _preLoadedAssets;
	}
}
