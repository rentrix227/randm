﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200016D RID: 365
	internal class UnlockItemPopupData
	{
		// Token: 0x04000A2D RID: 2605
		internal EHeroClass Class;

		// Token: 0x04000A2E RID: 2606
		internal EUnlockType Type;

		// Token: 0x04000A2F RID: 2607
		internal string ItemName;

		// Token: 0x04000A30 RID: 2608
		internal int LoadoutNumber;
	}
}
