﻿using System;
using System.Collections.Generic;
using Aquiris.Services;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000137 RID: 311
	internal class AvatarService : IService
	{
		// Token: 0x060005CF RID: 1487 RVA: 0x00006472 File Offset: 0x00004672
		internal override void Preprocess()
		{
			this._avatarRequests = new Dictionary<ulong, List<Action<ulong, Texture2D>>>();
			SteamCallbacks.PersonaStateChange_t.RegisterCallback(new Action<PersonaStateChange_t>(this.OnPersonaStateChanged));
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x00006490 File Offset: 0x00004690
		internal override void Postprocess()
		{
			SteamCallbacks.PersonaStateChange_t.UnregisterCallback(new Action<PersonaStateChange_t>(this.OnPersonaStateChanged));
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x00028AA4 File Offset: 0x00026CA4
		internal void LoadImageMedium(CSteamID steamId, Action<ulong, Texture2D> callback, bool invertY = false)
		{
			if (steamId.m_SteamID <= 0UL)
			{
				callback(steamId.m_SteamID, null);
				return;
			}
			int mediumFriendAvatar = SteamFriends.GetMediumFriendAvatar(steamId);
			if (mediumFriendAvatar > 0)
			{
				byte[] array = new byte[32768];
				if (SteamUtils.GetImageRGBA(mediumFriendAvatar, array, 32768))
				{
					if (invertY)
					{
						byte[] array2 = new byte[32768];
						Buffer.BlockCopy(array, 0, array2, 0, 32768);
						for (int i = 0; i < 64; i++)
						{
							Buffer.BlockCopy(array2, i * 64 * 4, array, (64 - i - 1) * 64 * 4, 256);
						}
					}
					Texture2D texture2D = new Texture2D(64, 64, 4, false);
					texture2D.LoadRawTextureData(array);
					texture2D.Apply();
					callback(steamId.m_SteamID, texture2D);
				}
				else
				{
					callback(steamId.m_SteamID, null);
				}
			}
			else
			{
				if (!this._avatarRequests.ContainsKey(steamId.m_SteamID))
				{
					this._avatarRequests.Add(steamId.m_SteamID, new List<Action<ulong, Texture2D>>());
				}
				this._avatarRequests[steamId.m_SteamID].Add(callback);
				SteamFriends.RequestUserInformation(steamId, false);
			}
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x00028BD8 File Offset: 0x00026DD8
		internal void LoadLargeImage(CSteamID steamId, Action<ulong, Texture2D> callback, bool invertY = false)
		{
			if (steamId.m_SteamID <= 0UL)
			{
				callback(steamId.m_SteamID, null);
				return;
			}
			int largeFriendAvatar = SteamFriends.GetLargeFriendAvatar(steamId);
			if (largeFriendAvatar > 0)
			{
				byte[] array = new byte[270848];
				if (SteamUtils.GetImageRGBA(largeFriendAvatar, array, 270848))
				{
					if (invertY)
					{
						byte[] array2 = new byte[270848];
						Buffer.BlockCopy(array, 0, array2, 0, 270848);
						for (int i = 0; i < 184; i++)
						{
							Buffer.BlockCopy(array2, i * 184 * 4, array, (184 - i - 1) * 184 * 4, 736);
						}
					}
					Texture2D texture2D = new Texture2D(184, 184, 4, false);
					texture2D.LoadRawTextureData(array);
					texture2D.Apply();
					callback(steamId.m_SteamID, texture2D);
				}
				else
				{
					callback(steamId.m_SteamID, null);
				}
			}
			else
			{
				callback(steamId.m_SteamID, null);
			}
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x00028CE0 File Offset: 0x00026EE0
		private void OnPersonaStateChanged(PersonaStateChange_t personaState)
		{
			if (this._avatarRequests.ContainsKey(personaState.m_ulSteamID))
			{
				Action<ulong, Texture2D>[] array = this._avatarRequests[personaState.m_ulSteamID].ToArray();
				this._avatarRequests.Remove(personaState.m_ulSteamID);
				foreach (Action<ulong, Texture2D> action in array)
				{
					this.LoadImageMedium(new CSteamID(personaState.m_ulSteamID), action, false);
				}
			}
		}

		// Token: 0x04000863 RID: 2147
		private Dictionary<ulong, List<Action<ulong, Texture2D>>> _avatarRequests;
	}
}
