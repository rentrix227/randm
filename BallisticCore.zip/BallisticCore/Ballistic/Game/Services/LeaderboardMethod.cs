﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020004F4 RID: 1268
	internal enum LeaderboardMethod
	{
		// Token: 0x04001CE7 RID: 7399
		GLOBAL,
		// Token: 0x04001CE8 RID: 7400
		FRIENDS,
		// Token: 0x04001CE9 RID: 7401
		NEIGHTBOURS
	}
}
