﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200017B RID: 379
	internal class RemoteCharacterInfo
	{
		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060007AF RID: 1967 RVA: 0x0000751E File Offset: 0x0000571E
		public string NicknamePlainText
		{
			get
			{
				return StringUtils.RemoveRichText(this.Nickname);
			}
		}

		// Token: 0x04000A79 RID: 2681
		internal long PlayerId;

		// Token: 0x04000A7A RID: 2682
		internal EHeroClass HeroClass;

		// Token: 0x04000A7B RID: 2683
		internal Team Team;

		// Token: 0x04000A7C RID: 2684
		internal Vector3 WorldPosition;

		// Token: 0x04000A7D RID: 2685
		internal Quaternion WorldRotation;

		// Token: 0x04000A7E RID: 2686
		internal bool IsVisibleOnRadar;

		// Token: 0x04000A7F RID: 2687
		internal bool IsTargetedByPlayer;

		// Token: 0x04000A80 RID: 2688
		internal bool IsCamouflaged;

		// Token: 0x04000A81 RID: 2689
		internal string Nickname;

		// Token: 0x04000A82 RID: 2690
		internal float Health;

		// Token: 0x04000A83 RID: 2691
		internal float MaxHealth;

		// Token: 0x04000A84 RID: 2692
		internal bool IsVisibleOnScreen;
	}
}
