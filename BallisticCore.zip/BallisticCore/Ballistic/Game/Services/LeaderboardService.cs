﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Reward;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000501 RID: 1281
	internal class LeaderboardService : IService
	{
		// Token: 0x06001B31 RID: 6961 RVA: 0x0008C7E8 File Offset: 0x0008A9E8
		internal override void Preprocess()
		{
			this._gameItemService = ServiceProvider.GetService<GameItemService>();
			this._inventoryService = ServiceProvider.GetService<InventoryService>();
			this._leaderboardEqualityComparer = new LeaderboardSteamItemEqualityComparer();
			this._lastLeaderboardEntry = new LeaderboardEntry
			{
				Name = SteamFriends.GetPersonaName(),
				SteamId = SteamUser.GetSteamID(),
				Position = 0,
				Score = 0,
				ScoreAdvanced = 0,
				ScoreCommon = 0,
				ScoreElite = 0,
				ScoreLegendary = 0,
				ScoreSpecial = 0,
				PrizeType = LeaderboardPrize.NONE,
				Prize = null
			};
			this._leaderboardSkinScoresHandler = new LeaderboardRequestSkinStruct();
			ServiceProvider.GetService<EventProxy>().HttpCoroutine(HttpServiceConstants.GetCurrentWeekMonth(new Action<bool, int, int>(this.LoadCurrentPlayerScore)));
		}

		// Token: 0x06001B32 RID: 6962 RVA: 0x0008C89C File Offset: 0x0008AA9C
		private void LoadCurrentPlayerScore(bool success, int week, int month)
		{
			if (success)
			{
				this._currentWeek = week;
				this._currentMonth = month;
				this._leaderboardGlobalScoresHandler = new LeaderboardRequestStruct(0, this._currentMonth, this._currentWeek, new Action<Leaderboards, LeaderboardScoresDownloaded_t, bool>(this.OnGlobalLeaderboardHandler));
				this._leaderboardFriendsScoresHandler = new LeaderboardRequestStruct(2, this._currentMonth, this._currentWeek, new Action<Leaderboards, LeaderboardScoresDownloaded_t, bool>(this.OnFriendsLeaderboardHandler));
				this._leaderboardNeightboursScoresHandler = new LeaderboardRequestStruct(1, this._currentMonth, this._currentWeek, new Action<Leaderboards, LeaderboardScoresDownloaded_t, bool>(this.OnNeightboursLeaderboardHandler));
				this.RequestNeightboursLeaderboardScore(Leaderboards.PERFORMANCE_LADDER, 0, 0);
				return;
			}
			Debug.LogWarning("Load currentWeek|Month failed");
		}

		// Token: 0x06001B33 RID: 6963 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x06001B34 RID: 6964 RVA: 0x00013E36 File Offset: 0x00012036
		internal LeaderboardEntry GetLastSelfLeaderboardEntry()
		{
			return this._lastLeaderboardEntry;
		}

		// Token: 0x06001B35 RID: 6965 RVA: 0x00013E3E File Offset: 0x0001203E
		internal bool GetCurrentMonth(out int month)
		{
			month = this._currentMonth % 12 + 1;
			return this._currentMonth > 0;
		}

		// Token: 0x06001B36 RID: 6966 RVA: 0x0008C944 File Offset: 0x0008AB44
		internal void RequestGlobalLeaderboardScores(Leaderboards leaderboard, int maxPlayerAmount)
		{
			if (leaderboard == Leaderboards.SKIN_LEGENDARY_LADDER)
			{
				this._leaderboardSkinScoresHandler.SetMethod(0);
				this._leaderboardSkinScoresHandler.SetRange(1, 100);
				this._leaderboardSkinScoresHandler.SetCallback(this.OnGlobalLeaderboardReceived);
				this._leaderboardSkinScoresHandler.Dispatch();
				return;
			}
			if (this._leaderboardGlobalScoresHandler == null)
			{
				return;
			}
			this._leaderboardGlobalScoresHandler.SetLeaderboard(leaderboard);
			this._leaderboardGlobalScoresHandler.SetRange(1, maxPlayerAmount);
			this._leaderboardGlobalScoresHandler.Dispatch();
		}

		// Token: 0x06001B37 RID: 6967 RVA: 0x0008C9C0 File Offset: 0x0008ABC0
		internal void RequestFriendsLeaderboardScore(Leaderboards leaderboard, int maxPlayerAmount)
		{
			if (leaderboard == Leaderboards.SKIN_LEGENDARY_LADDER)
			{
				this._leaderboardSkinScoresHandler.SetMethod(2);
				this._leaderboardSkinScoresHandler.SetRange(1, 50);
				this._leaderboardSkinScoresHandler.SetCallback(this.OnFriendsLeaderboardReceived);
				this._leaderboardSkinScoresHandler.Dispatch();
				return;
			}
			if (this._leaderboardFriendsScoresHandler == null)
			{
				return;
			}
			this._leaderboardFriendsScoresHandler.SetLeaderboard(leaderboard);
			this._leaderboardFriendsScoresHandler.SetRange(1, maxPlayerAmount);
			this._leaderboardFriendsScoresHandler.Dispatch();
		}

		// Token: 0x06001B38 RID: 6968 RVA: 0x0008CA3C File Offset: 0x0008AC3C
		internal void RequestNeightboursLeaderboardScore(Leaderboards leaderboard, int playerBefore, int playerAfter)
		{
			if (leaderboard == Leaderboards.SKIN_LEGENDARY_LADDER)
			{
				this._leaderboardSkinScoresHandler.SetMethod(1);
				this._leaderboardSkinScoresHandler.SetRange(playerBefore, playerAfter);
				this._leaderboardSkinScoresHandler.SetCallback(this.OnNeightboursLeaderboardReceived);
				this._leaderboardSkinScoresHandler.Dispatch();
				return;
			}
			if (this._leaderboardNeightboursScoresHandler == null)
			{
				return;
			}
			this._leaderboardNeightboursScoresHandler.SetLeaderboard(leaderboard);
			this._leaderboardNeightboursScoresHandler.SetRange(playerBefore, playerAfter);
			this._leaderboardNeightboursScoresHandler.Dispatch();
		}

		// Token: 0x06001B39 RID: 6969 RVA: 0x00013E56 File Offset: 0x00012056
		private void OnGlobalLeaderboardHandler(Leaderboards leaderboard, LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				return;
			}
			if (this.OnGlobalLeaderboardReceived != null)
			{
				this.OnGlobalLeaderboardReceived(leaderboard, LeaderboardService.QueryData(leaderboard, evt, false));
			}
		}

		// Token: 0x06001B3A RID: 6970 RVA: 0x0008CAB8 File Offset: 0x0008ACB8
		private void OnNeightboursLeaderboardHandler(Leaderboards leaderboard, LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				return;
			}
			LeaderboardEntry[] array = LeaderboardService.QueryData(leaderboard, evt, false);
			if (leaderboard == Leaderboards.PERFORMANCE_LADDER)
			{
				LeaderboardEntry leaderboardEntry = array.FirstOrDefault((LeaderboardEntry t) => UserProfile.IsMe(t.SteamId.m_SteamID));
				if (leaderboardEntry != null)
				{
					this._lastLeaderboardEntry = leaderboardEntry;
				}
			}
			if (this.OnNeightboursLeaderboardReceived != null)
			{
				this.OnNeightboursLeaderboardReceived(leaderboard, array);
			}
		}

		// Token: 0x06001B3B RID: 6971 RVA: 0x00013E78 File Offset: 0x00012078
		private void OnFriendsLeaderboardHandler(Leaderboards leaderboard, LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				return;
			}
			if (this.OnFriendsLeaderboardReceived != null)
			{
				this.OnFriendsLeaderboardReceived(leaderboard, LeaderboardService.QueryData(leaderboard, evt, false));
			}
		}

		// Token: 0x06001B3C RID: 6972 RVA: 0x0008CB20 File Offset: 0x0008AD20
		internal static LeaderboardEntry[] QueryData(Leaderboards leader, LeaderboardScoresDownloaded_t evt, bool includeUnranked)
		{
			LeaderboardEntry[] array = new LeaderboardEntry[evt.m_cEntryCount];
			IEnumerable<Reward> itemsOfType = ServiceProvider.GetService<GameItemService>().GetItemsOfType<Reward>();
			for (int i = 0; i < evt.m_cEntryCount; i++)
			{
				LeaderboardEntry_t leaderboardEntry_t;
				if (SteamUserStats.GetDownloadedLeaderboardEntry(evt.m_hSteamLeaderboardEntries, i, ref leaderboardEntry_t, null, 0))
				{
					array[i] = new LeaderboardEntry();
					array[i].SteamId = leaderboardEntry_t.m_steamIDUser;
					array[i].Name = SteamFriends.GetFriendPersonaName(leaderboardEntry_t.m_steamIDUser);
					array[i].Position = leaderboardEntry_t.m_nGlobalRank;
					array[i].Score = leaderboardEntry_t.m_nScore;
					array[i].ScoreLegendary = 0;
					array[i].ScoreElite = 0;
					array[i].ScoreSpecial = 0;
					array[i].ScoreAdvanced = 0;
					array[i].ScoreCommon = 0;
					array[i].Prize = null;
					array[i].PrizeType = LeaderboardService.GetPrizeType(leader, leaderboardEntry_t.m_nGlobalRank);
					if (array[i].PrizeType != LeaderboardPrize.NONE)
					{
						int prizeId = LeaderboardService.GetPrizeId(leader, leaderboardEntry_t.m_nGlobalRank);
						array[i].Prize = itemsOfType.FirstOrDefault((Reward t) => t.GetRewardId() == prizeId);
					}
				}
			}
			if (!includeUnranked)
			{
				array = array.Where(new Func<LeaderboardEntry, bool>(LeaderboardService.IsRanked)).ToArray<LeaderboardEntry>();
			}
			return array;
		}

		// Token: 0x06001B3D RID: 6973 RVA: 0x00013E9A File Offset: 0x0001209A
		private static bool IsRanked(LeaderboardEntry entry)
		{
			return entry.Score > 0;
		}

		// Token: 0x06001B3E RID: 6974 RVA: 0x0008CC5C File Offset: 0x0008AE5C
		internal static LeaderboardPrize GetPrizeType(Leaderboards leader, int position)
		{
			if (leader >= Leaderboards.SHADOW_LADDER && leader <= Leaderboards.BESERKER_LADDER)
			{
				int num = (int)(leader - Leaderboards.SHADOW_LADDER);
				if (num <= 3 || num - 5 <= 1)
				{
					goto IL_004A;
				}
			}
			if (leader != Leaderboards.PERFORMANCE_LADDER)
			{
				if (leader != Leaderboards.WRAITH_LADDER)
				{
					return LeaderboardPrize.NONE;
				}
			}
			else
			{
				if (position <= 10)
				{
					return LeaderboardPrize.GOLD_LOCKBOX;
				}
				if (position <= 100)
				{
					return LeaderboardPrize.GOLD_SCRAP;
				}
				return LeaderboardPrize.NONE;
			}
			IL_004A:
			if (position <= 30)
			{
				return LeaderboardPrize.SCRAP;
			}
			return LeaderboardPrize.NONE;
		}

		// Token: 0x06001B3F RID: 6975 RVA: 0x0008CCBC File Offset: 0x0008AEBC
		internal static int GetPrizeId(Leaderboards leader, int position)
		{
			if (leader >= Leaderboards.SHADOW_LADDER && leader <= Leaderboards.BESERKER_LADDER)
			{
				switch ((int)(leader - Leaderboards.SHADOW_LADDER))
				{
				case 0:
					if (position <= 30)
					{
						return 3190 + position;
					}
					return -1;
				case 1:
					if (position <= 30)
					{
						return 3280 + position;
					}
					return -1;
				case 2:
					if (position <= 30)
					{
						return 3250 + position;
					}
					return -1;
				case 3:
					if (position <= 30)
					{
						return 3220 + position;
					}
					return -1;
				case 5:
					if (position <= 30)
					{
						return 3130 + position;
					}
					return -1;
				case 6:
					if (position <= 30)
					{
						return 3100 + position;
					}
					return -1;
				}
			}
			if (leader != Leaderboards.PERFORMANCE_LADDER)
			{
				if (leader != Leaderboards.WRAITH_LADDER)
				{
					return -1;
				}
				if (position <= 30)
				{
					return 3160 + position;
				}
				return -1;
			}
			else
			{
				if (position <= 100)
				{
					return 3000 + position;
				}
				return -1;
			}
		}

		// Token: 0x06001B40 RID: 6976 RVA: 0x0008CD9C File Offset: 0x0008AF9C
		internal LeaderboardEntry OverrideByRankPrize(LeaderboardEntry leaderboardEntry)
		{
			int num = RatingUtil.GetSkillRatingTierNumber((float)leaderboardEntry.Score) + 1;
			if (num < 16)
			{
				if (num <= 3)
				{
					leaderboardEntry.PrizeType = LeaderboardPrize.GOLD_SCRAP;
				}
				else
				{
					leaderboardEntry.PrizeType = LeaderboardPrize.SCRAP;
				}
				leaderboardEntry.Prize = this._gameItemService.GetItemByName<Reward>("tier#" + num.ToString(), false);
			}
			else
			{
				leaderboardEntry.PrizeType = LeaderboardPrize.NONE;
				leaderboardEntry.Prize = null;
			}
			return leaderboardEntry;
		}

		// Token: 0x06001B41 RID: 6977 RVA: 0x0008CE08 File Offset: 0x0008B008
		internal void UpdateSkinScore()
		{
			foreach (Leaderboards leaderboards in new Leaderboards[]
			{
				Leaderboards.SKIN_LEGENDARY_LADDER,
				Leaderboards.SKIN_ELITE_LADDER,
				Leaderboards.SKIN_SPECIAL_LADDER,
				Leaderboards.SKIN_ADVANCED_LADDER,
				Leaderboards.SKIN_COMMON_LADDER
			})
			{
				SteamAPICall_t steamAPICall_t = SteamUserStats.FindLeaderboard(leaderboards.ToString().ToLowerInvariant());
				SteamCallbacks.LeaderboardFindResult_t.RegisterCallResult(new Action<LeaderboardFindResult_t, bool>(this.OnFindLeaderboard), steamAPICall_t);
			}
		}

		// Token: 0x06001B42 RID: 6978 RVA: 0x0008CE64 File Offset: 0x0008B064
		private void OnFindLeaderboard(LeaderboardFindResult_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				return;
			}
			Leaderboards steamLeaderboard = (Leaderboards)evt.m_hSteamLeaderboard.m_SteamLeaderboard;
			int num = 0;
			IEnumerable<SteamItem> enumerable = this._inventoryService.GetCachedWeaponSkins().Distinct(this._leaderboardEqualityComparer);
			if (steamLeaderboard >= Leaderboards.SKIN_SPECIAL_LADDER && steamLeaderboard <= Leaderboards.SKIN_COMMON_LADDER)
			{
				switch ((int)(steamLeaderboard - Leaderboards.SKIN_SPECIAL_LADDER))
				{
				case 0:
					num = enumerable.Count(new Func<SteamItem, bool>(this.IsSpecial));
					goto IL_00D4;
				case 1:
					num = enumerable.Count(new Func<SteamItem, bool>(this.IsAdvanced));
					goto IL_00D4;
				case 2:
					num = enumerable.Count(new Func<SteamItem, bool>(this.IsCommon));
					goto IL_00D4;
				}
			}
			if (steamLeaderboard != Leaderboards.SKIN_LEGENDARY_LADDER)
			{
				if (steamLeaderboard == Leaderboards.SKIN_ELITE_LADDER)
				{
					num = enumerable.Count(new Func<SteamItem, bool>(this.IsElite));
				}
			}
			else
			{
				num = enumerable.Count(new Func<SteamItem, bool>(this.IsLegendary));
			}
			IL_00D4:
			if (steamLeaderboard == Leaderboards.SKIN_LEGENDARY_LADDER && SteamUser.GetSteamID().m_SteamID == 76561198047682549UL && num > 5)
			{
				num = 5;
			}
			ELeaderboardUploadScoreMethod eleaderboardUploadScoreMethod = 2;
			SteamAPICall_t steamAPICall_t = SteamUserStats.UploadLeaderboardScore(evt.m_hSteamLeaderboard, eleaderboardUploadScoreMethod, num, null, 0);
			SteamCallbacks.LeaderboardScoreUploaded_t.RegisterCallResult(new Action<LeaderboardScoreUploaded_t, bool>(this.OnUploadScore), steamAPICall_t);
		}

		// Token: 0x06001B43 RID: 6979 RVA: 0x00013EA5 File Offset: 0x000120A5
		private void OnUploadScore(LeaderboardScoreUploaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				return;
			}
			Debug.Log("Leaderboard Changes Uploaded!");
		}

		// Token: 0x06001B44 RID: 6980 RVA: 0x00013EB5 File Offset: 0x000120B5
		private bool IsLegendary(SteamItem item)
		{
			return LeaderboardService.GetRarityByIdentity(item.IdentityId) == ERarity.LEGENDARY;
		}

		// Token: 0x06001B45 RID: 6981 RVA: 0x00013EC5 File Offset: 0x000120C5
		private bool IsElite(SteamItem item)
		{
			return LeaderboardService.GetRarityByIdentity(item.IdentityId) == ERarity.ELITE;
		}

		// Token: 0x06001B46 RID: 6982 RVA: 0x00013ED5 File Offset: 0x000120D5
		private bool IsSpecial(SteamItem item)
		{
			return LeaderboardService.GetRarityByIdentity(item.IdentityId) == ERarity.SPECIAL;
		}

		// Token: 0x06001B47 RID: 6983 RVA: 0x00013EE5 File Offset: 0x000120E5
		private bool IsAdvanced(SteamItem item)
		{
			return LeaderboardService.GetRarityByIdentity(item.IdentityId) == ERarity.ADVANCED;
		}

		// Token: 0x06001B48 RID: 6984 RVA: 0x00013EF5 File Offset: 0x000120F5
		private bool IsCommon(SteamItem item)
		{
			return LeaderboardService.GetRarityByIdentity(item.IdentityId) == ERarity.COMMON;
		}

		// Token: 0x06001B49 RID: 6985 RVA: 0x00013F05 File Offset: 0x00012105
		private static ERarity GetRarityByIdentity(int identityId)
		{
			return WeaponSkin.GetSkinRarity((EWeaponSkinName)(identityId % 1000));
		}

		// Token: 0x04001D16 RID: 7446
		private LeaderboardRequestStruct _leaderboardGlobalScoresHandler;

		// Token: 0x04001D17 RID: 7447
		private LeaderboardRequestStruct _leaderboardFriendsScoresHandler;

		// Token: 0x04001D18 RID: 7448
		private LeaderboardRequestStruct _leaderboardNeightboursScoresHandler;

		// Token: 0x04001D19 RID: 7449
		private LeaderboardRequestSkinStruct _leaderboardSkinScoresHandler;

		// Token: 0x04001D1A RID: 7450
		internal Action<Leaderboards, LeaderboardEntry[]> OnGlobalLeaderboardReceived;

		// Token: 0x04001D1B RID: 7451
		internal Action<Leaderboards, LeaderboardEntry[]> OnFriendsLeaderboardReceived;

		// Token: 0x04001D1C RID: 7452
		internal Action<Leaderboards, LeaderboardEntry[]> OnNeightboursLeaderboardReceived;

		// Token: 0x04001D1D RID: 7453
		private GameItemService _gameItemService;

		// Token: 0x04001D1E RID: 7454
		private InventoryService _inventoryService;

		// Token: 0x04001D1F RID: 7455
		private LeaderboardEntry _lastLeaderboardEntry;

		// Token: 0x04001D20 RID: 7456
		private LeaderboardSteamItemEqualityComparer _leaderboardEqualityComparer;

		// Token: 0x04001D21 RID: 7457
		private int _currentWeek;

		// Token: 0x04001D22 RID: 7458
		private int _currentMonth;
	}
}
