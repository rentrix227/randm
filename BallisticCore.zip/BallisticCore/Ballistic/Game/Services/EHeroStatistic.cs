﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000194 RID: 404
	internal enum EHeroStatistic
	{
		// Token: 0x04000AFD RID: 2813
		KILLS,
		// Token: 0x04000AFE RID: 2814
		DEATHS,
		// Token: 0x04000AFF RID: 2815
		ENGAGES,
		// Token: 0x04000B00 RID: 2816
		ASSISTS,
		// Token: 0x04000B01 RID: 2817
		HEADSHOTS,
		// Token: 0x04000B02 RID: 2818
		XP
	}
}
