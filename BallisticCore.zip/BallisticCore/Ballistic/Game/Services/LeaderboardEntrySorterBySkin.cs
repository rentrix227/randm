﻿using System;
using System.Collections.Generic;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020004F6 RID: 1270
	internal class LeaderboardEntrySorterBySkin : IComparer<LeaderboardEntry>
	{
		// Token: 0x06001B03 RID: 6915 RVA: 0x0008C040 File Offset: 0x0008A240
		public int Compare(LeaderboardEntry x, LeaderboardEntry y)
		{
			if (x.ScoreLegendary != y.ScoreLegendary)
			{
				return x.ScoreLegendary.CompareTo(y.ScoreLegendary);
			}
			if (x.ScoreElite != y.ScoreElite)
			{
				return x.ScoreElite.CompareTo(y.ScoreElite);
			}
			if (x.ScoreSpecial != y.ScoreSpecial)
			{
				return x.ScoreSpecial.CompareTo(y.ScoreSpecial);
			}
			if (x.ScoreAdvanced != y.ScoreAdvanced)
			{
				return x.ScoreAdvanced.CompareTo(y.ScoreAdvanced);
			}
			return x.ScoreCommon.CompareTo(y.ScoreCommon);
		}
	}
}
