﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200019F RID: 415
	public struct OnProjectileEnterPlayerRangeData
	{
		// Token: 0x04000B55 RID: 2901
		public Transform ProjectileTransform;

		// Token: 0x04000B56 RID: 2902
		public Team LauncherTeam;

		// Token: 0x04000B57 RID: 2903
		public bool LauncherIsLocalCharacter;
	}
}
