﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200018C RID: 396
	public struct SoundGroup
	{
		// Token: 0x04000ACA RID: 2762
		public int soundIndex;

		// Token: 0x04000ACB RID: 2763
		public SoundPlayer[] Sounds;
	}
}
