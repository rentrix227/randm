﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.DataModel.ItemModel.GameItemModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.DataModel.ItemModel.GameItemModel.LoadoutModel;
using Aquiris.DataModel.ItemModel.GameItemModel.ProgressionModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerHeroSkinModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerProgressionModel;
using Aquiris.DataModel.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.Services.ItemModel.GameItemModel.GameHeroModel;
using Aquiris.Services.ItemModel.GameItemModel.GameLoadoutModel;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using Aquiris.Services.ItemModel.PlayerItemModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200016F RID: 367
	internal class ProgressionService : IService
	{
		// Token: 0x0600073A RID: 1850 RVA: 0x0002F9E0 File Offset: 0x0002DBE0
		internal override void Preprocess()
		{
			if (Application.isPlaying)
			{
				this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
				this._networkGameService.OnClientConnectionStarted.AddListener(new Action(this.OnClientConnectionStarted));
				this._networkGameService.OnClientListReceived.AddListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
				this._networkGameService.OnUserListChanged.AddListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
				this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
				this._networkGameService.OnVoteEnd.AddListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
				this._storageService = ServiceProvider.GetService<PlayerItemStorageService>();
				this._statisticsService = ServiceProvider.GetService<StatisticsService>();
			}
			this._scoreForEachClass = new Dictionary<EHeroClass, int>();
		}

		// Token: 0x0600073B RID: 1851 RVA: 0x0002FAB0 File Offset: 0x0002DCB0
		internal override void Postprocess()
		{
			if (this._networkGameService != null)
			{
				this._networkGameService.OnClientConnectionStarted.RemoveListener(new Action(this.OnClientConnectionStarted));
				this._networkGameService.OnClientListReceived.RemoveListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
				this._networkGameService.OnUserListChanged.RemoveListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
				this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
				this._networkGameService.OnVoteEnd.RemoveListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			}
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x0000702F File Offset: 0x0000522F
		private void OnClientConnectionStarted()
		{
			this._lastPlayerScore = 0;
			this._scoreForEachClass.Clear();
			this._stayedForEntireMatch = false;
			this._matchCounter = 0;
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x00007051 File Offset: 0x00005251
		private void OnClientListReceived(ClientListReceivedEvent evt)
		{
			this.SetPlayerCount(true);
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x0000705A File Offset: 0x0000525A
		private void OnUserListChanged(UserListChangedEvent evt)
		{
			this.SetPlayerCount(false);
		}

		// Token: 0x0600073F RID: 1855 RVA: 0x0002FB54 File Offset: 0x0002DD54
		private void SetPlayerCount(bool forceUpdate)
		{
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			if (gameModeMetaData != null && gameModeMetaData.ClientMetaDataMap != null)
			{
				int num = 0;
				foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in gameModeMetaData.ClientMetaDataMap)
				{
					if (keyValuePair.Value.ClientMode == EClientMode.PLAYER)
					{
						num++;
					}
				}
				if (forceUpdate)
				{
					this._maximumPlayersThisMatch = num;
				}
				else if (num > this._maximumPlayersThisMatch)
				{
					this._maximumPlayersThisMatch = num;
				}
			}
		}

		// Token: 0x06000740 RID: 1856 RVA: 0x00007063 File Offset: 0x00005263
		private void OnDie(DieEvent evt)
		{
			if (evt.Sender.isMe)
			{
				this.CheckScoreIncrement();
			}
		}

		// Token: 0x06000741 RID: 1857 RVA: 0x0000707B File Offset: 0x0000527B
		private void OnVoteEnd(VoteMapEndEvent evt)
		{
			this._lastPlayerScore = 0;
			this.SetPlayerCount(true);
			this._scoreForEachClass.Clear();
			this._stayedForEntireMatch = true;
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x0002FC04 File Offset: 0x0002DE04
		internal float CalculatePerformanceFactor()
		{
			ClientCommonMetaData clientCommonMetaData = this._networkGameService.GetClientCommonMetaData(UserProfile.LocalGameClient.gameClientId);
			int score = (int)clientCommonMetaData.Score;
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			int num = 0;
			if (gameModeMetaData != null)
			{
				if (gameModeMetaData.ClientMetaDataMap.Count((KeyValuePair<long, ClientCommonMetaData> x) => x.Value.ClientMode == EClientMode.PLAYER) > 0)
				{
					num = (from x in gameModeMetaData.ClientMetaDataMap
						where x.Value.ClientMode == EClientMode.PLAYER
						select (int)x.Value.Score).Max();
				}
			}
			return this.CalculatePerformanceFactor(score, num);
		}

		// Token: 0x06000743 RID: 1859 RVA: 0x0002FCC8 File Offset: 0x0002DEC8
		internal float CalculatePerformanceFactor(int playerScore, int bestScore)
		{
			if (ProgressionData.Instance == null)
			{
				Debug.LogError("Could not operate performance due to missing ProgressionData. default = 0.25");
				return 0.25f;
			}
			int num = Mathf.Max(ProgressionData.Instance.MinXPScoreGoal, bestScore);
			num = Mathf.Min(num, ProgressionData.Instance.MaxXPScoreGoal);
			return Mathf.Clamp01((float)playerScore / (float)num);
		}

		// Token: 0x06000744 RID: 1860 RVA: 0x0000709D File Offset: 0x0000529D
		internal int CalculatePerformanceXp(int playerScore, IEnumerable<int> allScores)
		{
			return Mathf.RoundToInt((float)ProgressionData.Instance.BaseXPScoreBonus * this.CalculatePerformanceFactor(playerScore, allScores.Max()));
		}

		// Token: 0x06000745 RID: 1861 RVA: 0x000070BD File Offset: 0x000052BD
		internal int CalculatePerformanceXp()
		{
			return Mathf.RoundToInt((float)ProgressionData.Instance.BaseXPScoreBonus * this.CalculatePerformanceFactor());
		}

		// Token: 0x06000746 RID: 1862 RVA: 0x0002FD24 File Offset: 0x0002DF24
		internal List<ClassProgressionData> CalculateClassesXpGain(out Dictionary<EAwardedXpCategory, int> xpGainedByCategory)
		{
			xpGainedByCategory = new Dictionary<EAwardedXpCategory, int>();
			ClientCommonMetaData clientCommonMetaData = this._networkGameService.GetClientCommonMetaData(UserProfile.LocalGameClient.gameClientId);
			int score = (int)clientCommonMetaData.Score;
			GameConfig gameConfig = this._networkGameService.GetGameModeMetaData().GameConfig;
			float num = ProgressionData.GetMatchDurationXpFactor((float)gameConfig.MatchTime / 60f) * ProgressionData.GetNumberOfPlayersXpFactor(this._maximumPlayersThisMatch);
			int num2 = 0;
			this.AddXpCategory(EAwardedXpCategory.SCORE, this.CalculatePerformanceXp(), num, ref num2, ref xpGainedByCategory);
			if (score >= ProgressionData.Instance.MinScoreToGainBonus)
			{
				if (ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam == EWinningTeam.MINE)
				{
					this.AddXpCategory(EAwardedXpCategory.WINNING, ProgressionData.Instance.BonusForWinning, num, ref num2, ref xpGainedByCategory);
				}
				if (this._stayedForEntireMatch)
				{
					this.AddXpCategory(EAwardedXpCategory.CONSECUTIVEMATCH, ProgressionData.Instance.BonusForPlayingEntireMatch, num, ref num2, ref xpGainedByCategory);
				}
				if (this._statisticsService.GeneralUserData.LastMatchIndex < this.GetCurrentDayIndex())
				{
					this.AddXpCategory(EAwardedXpCategory.FIRSTMATCHOFTHEDAY, ProgressionData.Instance.BonusForFirstMatchOfTheDay, 1f, ref num2, ref xpGainedByCategory);
				}
			}
			int num3 = this._scoreForEachClass.Values.Sum();
			List<ClassProgressionData> list = new List<ClassProgressionData>();
			foreach (KeyValuePair<EHeroClass, int> keyValuePair in this._scoreForEachClass)
			{
				float num4 = ((num3 <= 0) ? (1f / (float)this._scoreForEachClass.Count) : ((float)keyValuePair.Value / (float)score));
				int num5 = Mathf.CeilToInt((float)num2 * num4);
				ClassProgressionData classProgressionData = new ClassProgressionData
				{
					HeroClass = keyValuePair.Key,
					XpGained = num5,
					XpAccumulatedToNextLevel = this.GetHeroClassFutureLevelXpRemaining(keyValuePair.Key, num5),
					OldXp = this.GetHeroClassLevelXp(keyValuePair.Key),
					OldLevel = this.GetHeroClassLevel(keyValuePair.Key),
					NewLevel = this.GetHeroClassFutureLevel(keyValuePair.Key, num5),
					UnlockTypes = new List<EUnlockType>(),
					UnlockedItems = new List<string>(),
					UnlockedItemIndexes = new List<int>()
				};
				for (int i = classProgressionData.OldLevel + 1; i <= classProgressionData.NewLevel; i++)
				{
					LevelUnlockData unlockForLevel = ProgressionData.GetUnlockForLevel(classProgressionData.HeroClass, i);
					classProgressionData.UnlockTypes.Add(unlockForLevel.UnlockType);
					classProgressionData.UnlockedItems.Add(unlockForLevel.UnlockedItemName);
					classProgressionData.UnlockedItemIndexes.Add(unlockForLevel.UnlockedItemIndex);
				}
				list.Add(classProgressionData);
			}
			return list;
		}

		// Token: 0x06000747 RID: 1863 RVA: 0x0002FFE8 File Offset: 0x0002E1E8
		private void AddXpCategory(EAwardedXpCategory category, int xp, float xpScaleFactor, ref int totalxp, ref Dictionary<EAwardedXpCategory, int> awardedCategories)
		{
			int num = ((category != EAwardedXpCategory.FIRSTMATCHOFTHEDAY) ? Mathf.RoundToInt((float)xp * xpScaleFactor) : xp);
			totalxp += num;
			if (awardedCategories.ContainsKey(category))
			{
				Dictionary<EAwardedXpCategory, int> dictionary;
				(dictionary = awardedCategories)[category] = dictionary[category] + num;
			}
			else
			{
				awardedCategories.Add(category, num);
			}
		}

		// Token: 0x06000748 RID: 1864 RVA: 0x00030048 File Offset: 0x0002E248
		internal int GetCurrentDayIndex()
		{
			DateTime utcNow = DateTime.UtcNow;
			return utcNow.Year * 1000 + utcNow.DayOfYear;
		}

		// Token: 0x06000749 RID: 1865 RVA: 0x000070D6 File Offset: 0x000052D6
		internal void SetMatchEnded()
		{
			this.CheckScoreIncrement();
			this._matchCounter++;
		}

		// Token: 0x0600074A RID: 1866 RVA: 0x00030070 File Offset: 0x0002E270
		internal void ApplyMatchProgression()
		{
			Dictionary<EAwardedXpCategory, int> dictionary;
			List<ClassProgressionData> list = this.CalculateClassesXpGain(out dictionary);
			this.ApplyProgression(list);
			if (dictionary.ContainsKey(EAwardedXpCategory.FIRSTMATCHOFTHEDAY))
			{
				this._statisticsService.SetGeneralUserStats(EGeneralStatistic.LASTMATCH, this.GetCurrentDayIndex());
			}
		}

		// Token: 0x0600074B RID: 1867 RVA: 0x000300AC File Offset: 0x0002E2AC
		private void ApplyProgression(List<ClassProgressionData> classesProgression)
		{
			foreach (ClassProgressionData classProgressionData in classesProgression)
			{
				this._statisticsService.IncrementGeneralHeroUserStats(classProgressionData.HeroClass, EHeroStatistic.XP, classProgressionData.XpGained);
				for (int i = 0; i < classProgressionData.UnlockTypes.Count; i++)
				{
					EUnlockType eunlockType = classProgressionData.UnlockTypes[i];
					if (eunlockType != EUnlockType.LOADOUT)
					{
						if (eunlockType != EUnlockType.SKILL)
						{
							if (eunlockType == EUnlockType.WEAPON)
							{
								this.UnlockWeapon(classProgressionData.UnlockedItems[i]);
							}
						}
						else
						{
							EHeroSkillV2 eheroSkillV = (EHeroSkillV2)Enum.Parse(typeof(EHeroSkillV2), classProgressionData.UnlockedItems[i].ToUpperInvariant());
							this.UnlockSkill(classProgressionData.HeroClass, eheroSkillV);
						}
					}
					else
					{
						this.UnlockLoadout(classProgressionData.HeroClass, classProgressionData.UnlockedItemIndexes[i]);
					}
				}
			}
			this._storageService.Save();
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x000070EC File Offset: 0x000052EC
		internal void GenerateStartingPlayerItems()
		{
			this.UnlockItem<Progression, PlayerProgression>("Progression");
			this.UnlockHero(EHeroClass.BERSERKER);
			this.UnlockHero(EHeroClass.GRENADIER);
			this.UnlockHero(EHeroClass.MARKSMAN);
			this.UnlockHero(EHeroClass.SHADOW);
			this.UnlockHero(EHeroClass.TANK);
			this.UnlockHero(EHeroClass.VANGUARD);
			this.UnlockHero(EHeroClass.WRAITH);
		}

		// Token: 0x0600074D RID: 1869 RVA: 0x000301D0 File Offset: 0x0002E3D0
		private void UnlockItem<TG, TP>(string itemName) where TG : GameItem where TP : PlayerItem
		{
			TG itemByName = ServiceProvider.GetService<GameItemService>().GetItemByName<TG>(itemName, false);
			if (itemByName != null)
			{
				TP tp = ServiceProvider.GetService<PlayerItemService>().FindPlayerItems<TP>(itemByName).FirstOrDefault<TP>();
				if (tp == null)
				{
					PlayerItem playerItem = this._storageService.CreatePlayerItem(itemByName);
					this._storageService.SavePlayerItem(playerItem);
				}
			}
		}

		// Token: 0x0600074E RID: 1870 RVA: 0x00030234 File Offset: 0x0002E434
		internal void UnlockHero(EHeroClass heroClass)
		{
			string text = heroClass.ToString().ToLowerInvariant();
			this.UnlockItem<HeroV3, PlayerHero>(text);
			this.UnlockHeroSkin(text + "_default");
			this.UnlockLoadout(heroClass, 0);
		}

		// Token: 0x0600074F RID: 1871 RVA: 0x0000712A File Offset: 0x0000532A
		internal void UnlockHeroSkin(string skinName)
		{
			this.UnlockItem<HeroSkin, PlayerHeroSkin>(skinName);
		}

		// Token: 0x06000750 RID: 1872 RVA: 0x00007133 File Offset: 0x00005333
		internal void UnlockWeapon(string weaponName)
		{
			this.UnlockItem<WeaponV4, PlayerWeapon>(weaponName);
		}

		// Token: 0x06000751 RID: 1873 RVA: 0x00030274 File Offset: 0x0002E474
		internal void UnlockSkill(EHeroClass heroClass, EHeroSkillV2 skill)
		{
			PlayerHero playerItem = ServiceProvider.GetService<PlayerHeroService>().GetPlayerHeroData(heroClass).PlayerItem;
			playerItem.UnlockSkill(skill);
			this._storageService.SavePlayerItem(playerItem);
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x000302A8 File Offset: 0x0002E4A8
		internal void UnlockLoadout(EHeroClass heroClass, int loadoutIndex)
		{
			Loadout gameItem = ServiceProvider.GetService<LoadoutService>().GetLoadout(heroClass).GameItem;
			IEnumerable<PlayerItem> enumerable = ServiceProvider.GetService<PlayerItemService>().FindPlayerItems<PlayerItem>(gameItem);
			HeroV3 gameItem2 = ServiceProvider.GetService<HeroService>().GetHero(heroClass).GameItem;
			ELoadoutNumber eloadoutNumber = loadoutIndex + ELoadoutNumber.LOADOUT1;
			int itemId = ServiceProvider.GetService<GameItemService>().GetItemByName<Accessory>("accessory_default", false).ItemId;
			SlotMapDictionary slotMapDictionary = new SlotMapDictionary();
			slotMapDictionary[EHeroItemSlot.PrimaryWeapon] = gameItem2.StandardItemMap[eloadoutNumber][EHeroItemSlot.PrimaryWeapon];
			slotMapDictionary[EHeroItemSlot.SecondaryWeapon] = gameItem2.StandardItemMap[eloadoutNumber][EHeroItemSlot.SecondaryWeapon];
			slotMapDictionary[EHeroItemSlot.MeleeWeapon] = gameItem2.StandardItemMap[eloadoutNumber][EHeroItemSlot.MeleeWeapon];
			slotMapDictionary[EHeroItemSlot.Explosive] = gameItem2.StandardItemMap[eloadoutNumber][EHeroItemSlot.Explosive];
			slotMapDictionary[EHeroItemSlot.Skin] = gameItem2.StandardItemMap[eloadoutNumber][EHeroItemSlot.Skin];
			slotMapDictionary[EHeroItemSlot.PrimaryWeaponSkin] = 0;
			slotMapDictionary[EHeroItemSlot.SecondaryWeaponSkin] = 0;
			slotMapDictionary[EHeroItemSlot.MeleeWeaponSkin] = 0;
			slotMapDictionary[EHeroItemSlot.ExplosiveSkin] = 0;
			slotMapDictionary[EHeroItemSlot.AccessoryChest] = itemId;
			slotMapDictionary[EHeroItemSlot.AccessoryBack] = itemId;
			slotMapDictionary[EHeroItemSlot.AccessoryHead] = itemId;
			slotMapDictionary[EHeroItemSlot.AccessoryFeet] = itemId;
			slotMapDictionary[EHeroItemSlot.AccessoryPelvis] = itemId;
			SlotMapDictionary slotMapDictionary2 = slotMapDictionary;
			List<EHeroSkillV2> list = new List<EHeroSkillV2>();
			foreach (HeroSkillNodeV3 heroSkillNodeV in gameItem2.HeroSkillTree.SkillNodes)
			{
				if (heroSkillNodeV.DefaultLoadout.IsSet(eloadoutNumber))
				{
					list.Add(heroSkillNodeV.HeroSkillId);
				}
			}
			List<int> list2 = new List<int>
			{
				slotMapDictionary2[EHeroItemSlot.PrimaryWeapon],
				slotMapDictionary2[EHeroItemSlot.SecondaryWeapon],
				slotMapDictionary2[EHeroItemSlot.MeleeWeapon],
				slotMapDictionary2[EHeroItemSlot.Explosive]
			};
			foreach (int num in list2)
			{
				WeaponV4 gameItem3 = ServiceProvider.GetService<WeaponService>().GetWeapon(num).GameItem;
				this.UnlockWeapon(gameItem3.ItemName);
			}
			foreach (EHeroSkillV2 eheroSkillV in list)
			{
				this.UnlockSkill(heroClass, eheroSkillV);
			}
			if (enumerable.Count<PlayerItem>() <= loadoutIndex)
			{
				PlayerItem playerItem = this._storageService.CreatePlayerItem(gameItem);
				if (playerItem is PlayerLoadoutV2)
				{
					PlayerLoadoutV2 playerLoadoutV = playerItem as PlayerLoadoutV2;
					playerLoadoutV.Number = loadoutIndex + 1;
					playerLoadoutV.LoadoutVersion = gameItem.LoadoutVersion;
					playerLoadoutV.ItemName = "LOADOUT " + playerLoadoutV.Number;
					playerLoadoutV.ItemMap = slotMapDictionary2;
					playerLoadoutV.Skills = list;
					this._storageService.SavePlayerItem(playerItem);
				}
			}
			ServiceProvider.GetService<SoldiersService>().LoadPlayerLoadouts(0);
			ServiceProvider.GetService<SoldiersService>().DispatchSoldierChanged(ServiceProvider.GetService<SoldiersService>().GetCurrentClass());
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x000305F4 File Offset: 0x0002E7F4
		private void CheckScoreIncrement()
		{
			int num = UserProfile.LocalGameClient.score - this._lastPlayerScore;
			this._lastPlayerScore = UserProfile.LocalGameClient.score;
			EHeroClass heroClass = LoadoutUtil.GetHeroClass(UserProfile.LocalGameClient.loadoutInfo);
			if (heroClass == EHeroClass.NONE)
			{
				return;
			}
			if (!this._scoreForEachClass.ContainsKey(heroClass))
			{
				this._scoreForEachClass.Add(heroClass, 0);
			}
			Dictionary<EHeroClass, int> scoreForEachClass;
			EHeroClass eheroClass;
			(scoreForEachClass = this._scoreForEachClass)[eheroClass = heroClass] = scoreForEachClass[eheroClass] + num;
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x0000713C File Offset: 0x0000533C
		internal bool CheckGoldClass(EHeroClass hero)
		{
			return ProgressionData.GetLevelForXp(this._statisticsService.GeneralUserData.HeroUserDatas[hero].Xp) >= ProgressionData.Instance.LevelForGoldClass;
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x0000716D File Offset: 0x0000536D
		internal bool CheckGoldClass(int level)
		{
			return level >= ProgressionData.Instance.LevelForGoldClass;
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x00030674 File Offset: 0x0002E874
		internal int GetAllHeroLevel()
		{
			int num = 0;
			foreach (KeyValuePair<EHeroClass, StatisticsHeroClassData> keyValuePair in this._statisticsService.GeneralUserData.HeroUserDatas)
			{
				num += ProgressionData.GetLevelForXp(keyValuePair.Value.Xp);
			}
			return num;
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x0000717F File Offset: 0x0000537F
		internal int GetHeroClassLevel(EHeroClass heroClass)
		{
			return ProgressionData.GetLevelForXp(this._statisticsService.GeneralUserData.HeroUserDatas[heroClass].Xp);
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x000071A1 File Offset: 0x000053A1
		internal int GetHeroClassFutureLevel(EHeroClass heroClass, int plusXp)
		{
			return ProgressionData.GetLevelForXp(this._statisticsService.GeneralUserData.HeroUserDatas[heroClass].Xp + plusXp);
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x000306EC File Offset: 0x0002E8EC
		private int GetHeroClassFutureLevelXpRemaining(EHeroClass heroClass, int plusXp)
		{
			int levelForXp = ProgressionData.GetLevelForXp(this._statisticsService.GeneralUserData.HeroUserDatas[heroClass].Xp + plusXp);
			int heroClassLevel = this.GetHeroClassLevel(heroClass);
			if (levelForXp > heroClassLevel)
			{
				return ProgressionData.GetTotalXpToReachLevel(heroClassLevel) + plusXp - ProgressionData.GetTotalXpToReachLevel(levelForXp);
			}
			return 0;
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x000071C5 File Offset: 0x000053C5
		internal int GetHeroClassLevelXp(EHeroClass heroClass)
		{
			return this._statisticsService.GeneralUserData.HeroUserDatas[heroClass].Xp - ProgressionData.GetTotalXpToReachLevel(this.GetHeroClassLevel(heroClass));
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x000071EF File Offset: 0x000053EF
		internal int GetHeroClassMaxLevelXp(EHeroClass heroClass)
		{
			return ProgressionData.GetTotalXpToReachLevel(this.GetHeroClassLevel(heroClass) + 1) - ProgressionData.GetTotalXpToReachLevel(this.GetHeroClassLevel(heroClass));
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x0003073C File Offset: 0x0002E93C
		internal void GetPlayerAccountLevel(out int level, out int frac)
		{
			PlayerHeroService service = ServiceProvider.GetService<PlayerHeroService>();
			IEnumerable<PlayerHeroData> availablePlayerHeroes = service.GetAvailablePlayerHeroes();
			int num = availablePlayerHeroes.Select((PlayerHeroData hero) => this.GetHeroClassLevel(hero.GameItemData.GameItem.UniqueIdentifier)).Sum();
			int num2 = availablePlayerHeroes.Count<PlayerHeroData>();
			level = num / num2;
			frac = num % num2;
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x0000720C File Offset: 0x0000540C
		internal EPlayerRank GetPlayerRank()
		{
			return ProgressionData.GetPlayerRankForLevel(this.GetPlayerAccountLevel());
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x00030780 File Offset: 0x0002E980
		internal int GetPlayerAccountLevel()
		{
			int num;
			int num2;
			this.GetPlayerAccountLevel(out num, out num2);
			return num;
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x00030798 File Offset: 0x0002E998
		internal void GetPlayerAccountLevelAcc(out int level)
		{
			int num = (from hero in ServiceProvider.GetService<PlayerHeroService>().GetAvailablePlayerHeroes()
				select this.GetHeroClassLevel(hero.GameItemData.GameItem.UniqueIdentifier)).Sum();
			level = num;
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x000307CC File Offset: 0x0002E9CC
		internal int GetPlayerAccountLevelAcc()
		{
			int num;
			this.GetPlayerAccountLevelAcc(out num);
			return num;
		}

		// Token: 0x04000A3A RID: 2618
		private NetworkGameService _networkGameService;

		// Token: 0x04000A3B RID: 2619
		private PlayerItemStorageService _storageService;

		// Token: 0x04000A3C RID: 2620
		private StatisticsService _statisticsService;

		// Token: 0x04000A3D RID: 2621
		private int _lastPlayerScore;

		// Token: 0x04000A3E RID: 2622
		private int _maximumPlayersThisMatch;

		// Token: 0x04000A3F RID: 2623
		private int _matchCounter;

		// Token: 0x04000A40 RID: 2624
		private bool _stayedForEntireMatch;

		// Token: 0x04000A41 RID: 2625
		private Dictionary<EHeroClass, int> _scoreForEachClass;

		// Token: 0x02000170 RID: 368
		private struct SkillUnlock
		{
			// Token: 0x04000A45 RID: 2629
			public EHeroClass HeroClass;

			// Token: 0x04000A46 RID: 2630
			public EHeroSkillV2 Skill;
		}

		// Token: 0x02000171 RID: 369
		private struct LoadoutUnlock
		{
			// Token: 0x04000A47 RID: 2631
			public EHeroClass HeroClass;

			// Token: 0x04000A48 RID: 2632
			public int LoadoutIndex;
		}
	}
}
