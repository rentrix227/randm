﻿using System;
using System.Collections.Generic;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200018A RID: 394
	public class SoundService : IService
	{
		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x06000823 RID: 2083 RVA: 0x000079D4 File Offset: 0x00005BD4
		// (set) Token: 0x06000824 RID: 2084 RVA: 0x000079DC File Offset: 0x00005BDC
		public float MasterSfxVolume { get; set; }

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000825 RID: 2085 RVA: 0x000079E5 File Offset: 0x00005BE5
		// (set) Token: 0x06000826 RID: 2086 RVA: 0x000079ED File Offset: 0x00005BED
		public float MasterMusicSound { get; set; }

		// Token: 0x06000827 RID: 2087 RVA: 0x000079F6 File Offset: 0x00005BF6
		internal override void Preprocess()
		{
			this._dictionary = new Dictionary<int, SoundGroup>();
			this._audioRoot = new GameObject("_MasterAudioManager").transform;
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00007A18 File Offset: 0x00005C18
		public void AddSound(string name, SoundConfig source)
		{
			this.AddSound(name, Animator.StringToHash(name), source);
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x000328C4 File Offset: 0x00030AC4
		public void AddSound(string name, int hashName, SoundConfig source)
		{
			if (this._dictionary.ContainsKey(hashName))
			{
				return;
			}
			SoundGroup soundGroup = new SoundGroup
			{
				Sounds = new SoundPlayer[source.InstanceLimit]
			};
			for (int i = 0; i < soundGroup.Sounds.Length; i++)
			{
				soundGroup.Sounds[i] = new SoundPlayer
				{
					Sound = Object.Instantiate<GameObject>(source.Config.gameObject).GetComponent<AudioSource>(),
					Volume = source.Config.volume,
					Pitch = source.Config.pitch,
					UseRandomVolume = source.UseRandomVolume,
					UseRandomPitch = source.UseRandomPitch,
					RndVolumeMinMax = source.RndVolumeMinMax,
					RndPitchMinMax = source.RndPitchMinMax
				};
				soundGroup.Sounds[i].Sound.name = name;
				soundGroup.Sounds[i].Sound.transform.parent = this._audioRoot;
			}
			this._dictionary.Add(hashName, soundGroup);
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x000329F8 File Offset: 0x00030BF8
		public void RemoveSound(int hashName)
		{
			if (!this._dictionary.ContainsKey(hashName))
			{
				return;
			}
			foreach (SoundPlayer soundPlayer in this._dictionary[hashName].Sounds)
			{
				Object.Destroy(soundPlayer.Sound.gameObject);
			}
			this._dictionary.Remove(hashName);
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x00032A6C File Offset: 0x00030C6C
		public void PlayGroup(int hashName)
		{
			if (!this._dictionary.TryGetValue(hashName, out this._internalSoundGroup))
			{
				return;
			}
			this._internalSoundGroup.soundIndex = (this._internalSoundGroup.soundIndex + 1) % this._internalSoundGroup.Sounds.Length;
			this._internalSoundGroup.Sounds[this._internalSoundGroup.soundIndex].Play();
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x00032AD8 File Offset: 0x00030CD8
		public void PlayGroupAtPosition(int hashName, Vector3 position)
		{
			if (!this._dictionary.TryGetValue(hashName, out this._internalSoundGroup))
			{
				return;
			}
			this._internalSoundGroup.soundIndex = (this._internalSoundGroup.soundIndex + 1) % this._internalSoundGroup.Sounds.Length;
			this._internalSoundGroup.Sounds[this._internalSoundGroup.soundIndex].Sound.transform.position = position;
			this._internalSoundGroup.Sounds[this._internalSoundGroup.soundIndex].Play();
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x00007A28 File Offset: 0x00005C28
		internal void DispatchToMasterAudio(string playSound)
		{
			if (this.OnPlaySoundRequest != null)
			{
				this.OnPlaySoundRequest(playSound);
			}
		}

		// Token: 0x04000AC0 RID: 2752
		public Action<string> OnPlaySoundRequest;

		// Token: 0x04000AC1 RID: 2753
		private Dictionary<int, SoundGroup> _dictionary;

		// Token: 0x04000AC2 RID: 2754
		private Transform _audioRoot;

		// Token: 0x04000AC3 RID: 2755
		private SoundGroup _internalSoundGroup;
	}
}
