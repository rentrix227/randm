﻿using System;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200013F RID: 319
	internal class CurrentMatchService : IService
	{
		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060005FA RID: 1530 RVA: 0x000065F3 File Offset: 0x000047F3
		// (set) Token: 0x060005FB RID: 1531 RVA: 0x000065FB File Offset: 0x000047FB
		internal CurrentMatchService.ConnectionState State { get; set; }

		// Token: 0x060005FC RID: 1532 RVA: 0x00029500 File Offset: 0x00027700
		internal MatchStandingsData GetMatchStandings()
		{
			if (this._networkGameService.GetGameModeMetaData() == null)
			{
				return this._lastMatchStandingsData;
			}
			GameMetaData gameMetaData = this._networkGameService.GetGameModeMetaData().GameMetaData;
			GameConfig gameConfig = this._networkGameService.GetGameModeMetaData().GameConfig;
			MatchStandingsData matchStandingsData = new MatchStandingsData
			{
				WinningTeam = EWinningTeam.UNDEFINED,
				MaxTeamScore = gameConfig.MaxScore,
				YourTeamScore = 0,
				EnemyTeamScore = 0,
				YourTeamWins = 0,
				EnemyTeamWins = 0,
				YourPlayerData = this._yourPlayerData,
				EnemyPlayerData = this._enemyPlayerData
			};
			EGameMode gameMode = this._gameModeService.GameMode;
			if (gameMode != EGameMode.FreeForAll && gameMode != EGameMode.Juggernaut)
			{
				matchStandingsData.YourTeam = UserProfile.LocalGameClient.team;
				matchStandingsData.EnemyTeam = ((matchStandingsData.YourTeam != Team.MFA) ? Team.MFA : Team.SMOKE);
				float num = (float)this._networkGameService.GetGameModeMetaData().TeamMetaDataMap[(sbyte)matchStandingsData.YourTeam].RemainingTickets;
				float num2 = (float)this._networkGameService.GetGameModeMetaData().TeamMetaDataMap[(sbyte)matchStandingsData.EnemyTeam].RemainingTickets;
				int points = this._networkGameService.GetGameModeMetaData().TeamMetaDataMap[(sbyte)matchStandingsData.YourTeam].Points;
				int points2 = this._networkGameService.GetGameModeMetaData().TeamMetaDataMap[(sbyte)matchStandingsData.EnemyTeam].Points;
				switch (this._gameModeService.GameMode)
				{
				case EGameMode.TeamDeathMatch:
				case EGameMode.Conquest:
				case EGameMode.KingOfTheHill:
					if ((int)gameMetaData.WinnerTeam > 0)
					{
						matchStandingsData.WinningTeam = ((matchStandingsData.YourTeam != (Team)gameMetaData.WinnerTeam) ? EWinningTeam.ENEMY : EWinningTeam.MINE);
					}
					else if ((int)gameMetaData.WinnerTeam == 0)
					{
						matchStandingsData.WinningTeam = EWinningTeam.NONE;
					}
					else if (num > num2 && num > 0f)
					{
						matchStandingsData.WinningTeam = EWinningTeam.MINE;
					}
					else if (num2 > num && num2 > 0f)
					{
						matchStandingsData.WinningTeam = EWinningTeam.ENEMY;
					}
					else
					{
						matchStandingsData.WinningTeam = EWinningTeam.NONE;
					}
					break;
				case EGameMode.Rounds:
					if ((int)gameMetaData.WinnerTeam > 0)
					{
						matchStandingsData.WinningTeam = ((matchStandingsData.YourTeam != (Team)gameMetaData.WinnerTeam) ? EWinningTeam.ENEMY : EWinningTeam.MINE);
					}
					else if ((int)gameMetaData.WinnerTeam == 0)
					{
						matchStandingsData.WinningTeam = EWinningTeam.NONE;
					}
					else if (points > points2 && points > 0)
					{
						matchStandingsData.WinningTeam = EWinningTeam.MINE;
					}
					else if (points2 > points && points2 > 0)
					{
						matchStandingsData.WinningTeam = EWinningTeam.ENEMY;
					}
					else
					{
						matchStandingsData.WinningTeam = EWinningTeam.NONE;
					}
					break;
				}
				this._yourPlayerData.Clear();
				foreach (ClientCommonMetaData clientCommonMetaData in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Values)
				{
					if (clientCommonMetaData != null)
					{
						if ((Team)clientCommonMetaData.Team == matchStandingsData.YourTeam && clientCommonMetaData.ClientMode == EClientMode.PLAYER)
						{
							this._yourPlayerData.Add(clientCommonMetaData);
						}
					}
				}
				this._yourPlayerData.Sort(this._playerDataSorter);
				this._enemyPlayerData.Clear();
				foreach (ClientCommonMetaData clientCommonMetaData2 in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Values)
				{
					if (clientCommonMetaData2 != null)
					{
						if ((Team)clientCommonMetaData2.Team != matchStandingsData.YourTeam && clientCommonMetaData2.ClientMode == EClientMode.PLAYER)
						{
							this._enemyPlayerData.Add(clientCommonMetaData2);
						}
					}
				}
				this._enemyPlayerData.Sort(this._playerDataSorter);
				switch (this._gameModeService.GameMode)
				{
				case EGameMode.TeamDeathMatch:
					matchStandingsData.YourTeamScore = (int)(num / this._gameModeService.PointsPerKill);
					matchStandingsData.EnemyTeamScore = (int)(num2 / this._gameModeService.PointsPerKill);
					break;
				case EGameMode.Conquest:
				case EGameMode.KingOfTheHill:
					matchStandingsData.YourTeamScore = Mathf.CeilToInt(num / 10f);
					matchStandingsData.EnemyTeamScore = Mathf.CeilToInt(num2 / 10f);
					matchStandingsData.MaxTeamScore = Mathf.CeilToInt((float)matchStandingsData.MaxTeamScore / 10f);
					break;
				case EGameMode.Rounds:
					matchStandingsData.YourTeamScore = (int)num;
					matchStandingsData.EnemyTeamScore = (int)num2;
					matchStandingsData.YourTeamWins = points;
					matchStandingsData.EnemyTeamWins = points2;
					break;
				}
			}
			else
			{
				matchStandingsData.YourPlayerData.Clear();
				foreach (ClientCommonMetaData clientCommonMetaData3 in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Values)
				{
					if (clientCommonMetaData3 != null)
					{
						if (clientCommonMetaData3.ClientMode == EClientMode.PLAYER)
						{
							matchStandingsData.YourPlayerData.Add(clientCommonMetaData3);
						}
					}
				}
				matchStandingsData.YourPlayerData.Sort(this._playerDataSorter);
				for (int i = 0; i < matchStandingsData.YourPlayerData.Length; i++)
				{
					if (UserProfile.IsMe(matchStandingsData.YourPlayerData[i].User))
					{
						matchStandingsData.PlayerRanking = i + 1;
						break;
					}
				}
				ClientCommonMetaData clientCommonMetaData4 = this._networkGameService.GetClientCommonMetaData(UserProfile.LocalGameClient.gameClientId);
				if (clientCommonMetaData4 != null)
				{
					if ((int)gameMetaData.WinnerTeam >= 0)
					{
						matchStandingsData.WinningTeam = ((!clientCommonMetaData4.HasWinnedMatch) ? EWinningTeam.ENEMY : EWinningTeam.MINE);
					}
					else
					{
						matchStandingsData.WinningTeam = ((matchStandingsData.PlayerRanking > Mathf.CeilToInt((float)matchStandingsData.YourPlayerData.Length / 2f)) ? EWinningTeam.ENEMY : EWinningTeam.MINE);
					}
				}
			}
			this._lastMatchStandingsData = matchStandingsData;
			return matchStandingsData;
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00029B78 File Offset: 0x00027D78
		internal override void Preprocess()
		{
			this.State = CurrentMatchService.ConnectionState.DISCONNECTED;
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._playerDataSorter = new ClientCommonMetaDataSortByScore();
			this._yourPlayerData = new HighSpeedArray<ClientCommonMetaData>(20);
			this._enemyPlayerData = new HighSpeedArray<ClientCommonMetaData>(20);
		}

		// Token: 0x04000881 RID: 2177
		private NetworkGameService _networkGameService;

		// Token: 0x04000882 RID: 2178
		private GameModeService _gameModeService;

		// Token: 0x04000883 RID: 2179
		private ClientCommonMetaDataSortByScore _playerDataSorter;

		// Token: 0x04000884 RID: 2180
		private HighSpeedArray<ClientCommonMetaData> _yourPlayerData;

		// Token: 0x04000885 RID: 2181
		private HighSpeedArray<ClientCommonMetaData> _enemyPlayerData;

		// Token: 0x04000886 RID: 2182
		private MatchStandingsData _lastMatchStandingsData;

		// Token: 0x02000140 RID: 320
		internal enum ConnectionState : byte
		{
			// Token: 0x04000889 RID: 2185
			DISCONNECTED,
			// Token: 0x0400088A RID: 2186
			IN_LOBBY,
			// Token: 0x0400088B RID: 2187
			CONNECTING,
			// Token: 0x0400088C RID: 2188
			CONNECTED,
			// Token: 0x0400088D RID: 2189
			FAILED_CONNECTION,
			// Token: 0x0400088E RID: 2190
			LOST_CONNECTION,
			// Token: 0x0400088F RID: 2191
			KICKED,
			// Token: 0x04000890 RID: 2192
			BADCONNECTION,
			// Token: 0x04000891 RID: 2193
			GRENADEHACK,
			// Token: 0x04000892 RID: 2194
			SPEEDHACK,
			// Token: 0x04000893 RID: 2195
			INACTIVITY,
			// Token: 0x04000894 RID: 2196
			MAXPING,
			// Token: 0x04000895 RID: 2197
			SERVERFULL,
			// Token: 0x04000896 RID: 2198
			SERVERTERMINATED,
			// Token: 0x04000897 RID: 2199
			VACBANNED,
			// Token: 0x04000898 RID: 2200
			HOST_KICKED,
			// Token: 0x04000899 RID: 2201
			HOST_BLACKLISTED
		}
	}
}
