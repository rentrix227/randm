﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000196 RID: 406
	internal class StatisticsGeneralData
	{
		// Token: 0x0600085B RID: 2139 RVA: 0x00007B0D File Offset: 0x00005D0D
		internal StatisticsGeneralData()
		{
			this.HeroUserDatas = new Dictionary<EHeroClass, StatisticsHeroClassData>();
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x00007B41 File Offset: 0x00005D41
		internal int GetStatistic(EGeneralStatistic stat)
		{
			if (!this._currentStatistics.ContainsKey(stat))
			{
				this._currentStatistics.Add(stat, 0);
			}
			return this._currentStatistics[stat];
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x00007B6D File Offset: 0x00005D6D
		internal float GetLeaderboardStatistic(EGameMode mode)
		{
			if (!this._currentLeaderboardRating.ContainsKey(mode))
			{
				this._currentLeaderboardRating.Add(mode, 0f);
			}
			return this._currentLeaderboardRating[mode];
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x000344B4 File Offset: 0x000326B4
		internal int GetLeaderboardMatchs(EGameMode mode)
		{
			if (mode == EGameMode.Any)
			{
				return this._currentLeaderboardMatchs.Sum((KeyValuePair<EGameMode, int> t) => t.Value);
			}
			if (!this._currentLeaderboardMatchs.ContainsKey(mode))
			{
				this._currentLeaderboardMatchs.Add(mode, 0);
			}
			return this._currentLeaderboardMatchs[mode];
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00007B9D File Offset: 0x00005D9D
		internal int SetStatistic(EGeneralStatistic stat, int value)
		{
			if (!this._currentStatistics.ContainsKey(stat))
			{
				this._currentStatistics.Add(stat, 0);
			}
			this._currentStatistics[stat] = value;
			return this._currentStatistics[stat];
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x00007BD6 File Offset: 0x00005DD6
		internal float SetLeaderboardStatistic(EGameMode mode, float value)
		{
			if (!this._currentLeaderboardRating.ContainsKey(mode))
			{
				this._currentLeaderboardRating.Add(mode, 0f);
			}
			this._currentLeaderboardRating[mode] = value;
			return this._currentLeaderboardRating[mode];
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x00007C13 File Offset: 0x00005E13
		internal int SetLeaderboardMatchs(EGameMode mode, int value)
		{
			if (!this._currentLeaderboardMatchs.ContainsKey(mode))
			{
				this._currentLeaderboardMatchs.Add(mode, 0);
			}
			this._currentLeaderboardMatchs[mode] = value;
			return this._currentLeaderboardMatchs[mode];
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x00007C4C File Offset: 0x00005E4C
		internal int IncrementStatistic(EGeneralStatistic statistic, int amount)
		{
			return this.SetStatistic(statistic, this.GetStatistic(statistic) + amount);
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x06000863 RID: 2147 RVA: 0x00007C5E File Offset: 0x00005E5E
		internal int Matchs
		{
			get
			{
				return this.GetStatistic(EGeneralStatistic.WINS) + this.GetStatistic(EGeneralStatistic.LOSES);
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000864 RID: 2148 RVA: 0x00007C6F File Offset: 0x00005E6F
		internal int Kills
		{
			get
			{
				return this.HeroUserDatas.Values.Select((StatisticsHeroClassData item) => item.Kills).Sum();
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000865 RID: 2149 RVA: 0x00007CA3 File Offset: 0x00005EA3
		internal int Deaths
		{
			get
			{
				return this.HeroUserDatas.Values.Select((StatisticsHeroClassData item) => item.Deaths).Sum();
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x06000866 RID: 2150 RVA: 0x00007CD7 File Offset: 0x00005ED7
		internal int Engages
		{
			get
			{
				return this.HeroUserDatas.Values.Select((StatisticsHeroClassData item) => item.Engages).Sum();
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x06000867 RID: 2151 RVA: 0x00007D0B File Offset: 0x00005F0B
		internal int Assists
		{
			get
			{
				return this.HeroUserDatas.Values.Select((StatisticsHeroClassData item) => item.Assists).Sum();
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x06000868 RID: 2152 RVA: 0x00007D3F File Offset: 0x00005F3F
		internal int Headshots
		{
			get
			{
				return this.HeroUserDatas.Values.Select((StatisticsHeroClassData item) => item.Headshots).Sum();
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000869 RID: 2153 RVA: 0x00007D73 File Offset: 0x00005F73
		internal float KillDeathRatio
		{
			get
			{
				return StatisticsService.GetKillDeathRatio(this.Kills, this.Deaths);
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x0600086A RID: 2154 RVA: 0x00007D86 File Offset: 0x00005F86
		internal int LastMatchIndex
		{
			get
			{
				return this.GetStatistic(EGeneralStatistic.LASTMATCH);
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x0600086B RID: 2155 RVA: 0x00007D90 File Offset: 0x00005F90
		internal float KillRatio
		{
			get
			{
				if (this.Engages > 0)
				{
					return (float)this.Kills / (float)this.Engages;
				}
				return 0f;
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x0600086C RID: 2156 RVA: 0x0003451C File Offset: 0x0003271C
		internal float WinLoseRatio
		{
			get
			{
				int statistic = this.GetStatistic(EGeneralStatistic.WINS);
				int statistic2 = this.GetStatistic(EGeneralStatistic.LOSES);
				if (statistic > 0)
				{
					return (float)statistic / (float)statistic2;
				}
				return (float)((statistic <= 0) ? 0 : statistic);
			}
		}

		// Token: 0x04000B14 RID: 2836
		private Dictionary<EGeneralStatistic, int> _currentStatistics = new Dictionary<EGeneralStatistic, int>();

		// Token: 0x04000B15 RID: 2837
		private Dictionary<EGameMode, float> _currentLeaderboardRating = new Dictionary<EGameMode, float>();

		// Token: 0x04000B16 RID: 2838
		private Dictionary<EGameMode, int> _currentLeaderboardMatchs = new Dictionary<EGameMode, int>();

		// Token: 0x04000B17 RID: 2839
		internal Dictionary<EHeroClass, StatisticsHeroClassData> HeroUserDatas;
	}
}
