﻿using System;
using Aquiris.Ballistic.Game.Weapon;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200015F RID: 351
	public struct AimingUpdateStruct
	{
		// Token: 0x04000983 RID: 2435
		public CrosshairType Crosshair;

		// Token: 0x04000984 RID: 2436
		public float CurrentPrecision;

		// Token: 0x04000985 RID: 2437
		public float PulsePrecisionLoss;

		// Token: 0x04000986 RID: 2438
		public float FireRate;

		// Token: 0x04000987 RID: 2439
		public WeaponTargeting Targeting;

		// Token: 0x04000988 RID: 2440
		public long TargetingEnemyId;
	}
}
