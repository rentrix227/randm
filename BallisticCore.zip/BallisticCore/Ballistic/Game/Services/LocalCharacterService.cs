﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Aquiris.Ballistic.Game.Character.Network;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Maps;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200015C RID: 348
	public class LocalCharacterService : IService
	{
		// Token: 0x060006AD RID: 1709 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Preprocess()
		{
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060006AF RID: 1711 RVA: 0x0002CE50 File Offset: 0x0002B050
		// (remove) Token: 0x060006B0 RID: 1712 RVA: 0x0002CE88 File Offset: 0x0002B088
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnWeaponShotFired;

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060006B1 RID: 1713 RVA: 0x0002CEC0 File Offset: 0x0002B0C0
		// (remove) Token: 0x060006B2 RID: 1714 RVA: 0x0002CEF8 File Offset: 0x0002B0F8
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<AimingUpdateStruct> OnAimingUpdate;

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x060006B3 RID: 1715 RVA: 0x0002CF30 File Offset: 0x0002B130
		// (remove) Token: 0x060006B4 RID: 1716 RVA: 0x0002CF68 File Offset: 0x0002B168
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<AmmoUpdateStruct> OnAmmoUpdate;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x060006B5 RID: 1717 RVA: 0x0002CFA0 File Offset: 0x0002B1A0
		// (remove) Token: 0x060006B6 RID: 1718 RVA: 0x0002CFD8 File Offset: 0x0002B1D8
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<EHeroSkillV2, SkillState> OnSkillStateUpdate;

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x060006B7 RID: 1719 RVA: 0x0002D010 File Offset: 0x0002B210
		// (remove) Token: 0x060006B8 RID: 1720 RVA: 0x0002D048 File Offset: 0x0002B248
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action<float> OnFallDamage;

		// Token: 0x060006B9 RID: 1721 RVA: 0x00003C49 File Offset: 0x00001E49
		private static bool _isPointVisibleStub(Vector3 point)
		{
			return false;
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060006BA RID: 1722 RVA: 0x00006B14 File Offset: 0x00004D14
		// (set) Token: 0x060006BB RID: 1723 RVA: 0x00006B1C File Offset: 0x00004D1C
		public Vector3 WorldPosition { get; private set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060006BC RID: 1724 RVA: 0x00006B25 File Offset: 0x00004D25
		// (set) Token: 0x060006BD RID: 1725 RVA: 0x00006B2D File Offset: 0x00004D2D
		public Quaternion WorldRotation { get; private set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060006BE RID: 1726 RVA: 0x00006B36 File Offset: 0x00004D36
		// (set) Token: 0x060006BF RID: 1727 RVA: 0x00006B3E File Offset: 0x00004D3E
		public Camera FXCamera { get; private set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060006C0 RID: 1728 RVA: 0x00006B47 File Offset: 0x00004D47
		// (set) Token: 0x060006C1 RID: 1729 RVA: 0x00006B4F File Offset: 0x00004D4F
		public Camera StageCamera { get; private set; }

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060006C2 RID: 1730 RVA: 0x00006B58 File Offset: 0x00004D58
		// (set) Token: 0x060006C3 RID: 1731 RVA: 0x00006B60 File Offset: 0x00004D60
		public float MinimapScaleFactor { get; private set; }

		// Token: 0x060006C4 RID: 1732 RVA: 0x00006B69 File Offset: 0x00004D69
		public void DispatchAimingUpdate(AimingUpdateStruct evt)
		{
			if (this.OnAimingUpdate != null)
			{
				this.OnAimingUpdate(evt);
			}
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x00006B82 File Offset: 0x00004D82
		public void DispatchAmmoUpdate(AmmoUpdateStruct evt)
		{
			if (this.OnAmmoUpdate != null)
			{
				this.OnAmmoUpdate(evt);
			}
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x00006B9B File Offset: 0x00004D9B
		public void DispatchFallDamage(float distance)
		{
			if (this.OnFallDamage != null)
			{
				this.OnFallDamage(distance);
			}
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x0002D080 File Offset: 0x0002B280
		public void DispatchUpdateSkillState(EHeroSkillV2 skill, SkillState state)
		{
			if (this._dictionarySkillState.ContainsKey(skill))
			{
				this._dictionarySkillState[skill] = state;
			}
			else
			{
				this._dictionarySkillState.Add(skill, state);
			}
			if (this.OnSkillStateUpdate != null)
			{
				this.OnSkillStateUpdate(skill, state);
			}
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x00006BB4 File Offset: 0x00004DB4
		public void UpdateTransform(Vector3 worldPosition, Quaternion worldRotation)
		{
			this.WorldPosition = worldPosition;
			this.WorldRotation = worldRotation;
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x00006BC4 File Offset: 0x00004DC4
		public void SetFXCamera(Camera camera)
		{
			this.FXCamera = camera;
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x00006BCD File Offset: 0x00004DCD
		public void SetStageCamera(Camera camera)
		{
			this.StageCamera = camera;
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00006BD6 File Offset: 0x00004DD6
		public void SetMinimapScaleFactor(float scaleFactor)
		{
			this.MinimapScaleFactor = scaleFactor;
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x00006BDF File Offset: 0x00004DDF
		public void SetMapVisibility(bool isVisible)
		{
			this.IsVisible = isVisible;
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x00006BE8 File Offset: 0x00004DE8
		public void DispatchWeaponShotFired()
		{
			if (this.OnWeaponShotFired != null)
			{
				this.OnWeaponShotFired();
			}
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x0002D0D8 File Offset: 0x0002B2D8
		internal SkillState GetSkillState(EHeroSkillV2 skill)
		{
			if (!this._dictionarySkillState.ContainsKey(skill))
			{
				this._dictionarySkillState.Add(skill, default(SkillState));
			}
			return this._dictionarySkillState[skill];
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x0002D118 File Offset: 0x0002B318
		public void SetBitState(int stateBitMask)
		{
			this._currentStateBitMask = stateBitMask;
			if (this._previousStateBitMask == this._currentStateBitMask)
			{
				return;
			}
			bool state = PlayerState.GetState(this._previousStateBitMask, PlayerState.State.IsSprinting);
			bool state2 = PlayerState.GetState(this._currentStateBitMask, PlayerState.State.IsSprinting);
			if (!state && state2)
			{
				this.DispatchEvent(LocalCharacterService.Events.OnSprintStart);
			}
			if (state && !state2)
			{
				this.DispatchEvent(LocalCharacterService.Events.OnSprintEnd);
			}
			bool state3 = PlayerState.GetState(this._previousStateBitMask, PlayerState.State.IsJumping);
			bool state4 = PlayerState.GetState(this._currentStateBitMask, PlayerState.State.IsJumping);
			if (!state3 && state4)
			{
				this.DispatchEvent(LocalCharacterService.Events.OnJumpStart);
			}
			this._previousStateBitMask = this._currentStateBitMask;
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x0002D1BC File Offset: 0x0002B3BC
		public void AddListener(LocalCharacterService.Events evt, LocalCharacterService.EventCallback callback)
		{
			if (!this._eventsMap.ContainsKey(evt))
			{
				this._eventsMap.Add(evt, new List<LocalCharacterService.EventCallback>());
			}
			List<LocalCharacterService.EventCallback> list = this._eventsMap[evt];
			list.Add(callback);
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x0002D200 File Offset: 0x0002B400
		public void RemoveListener(LocalCharacterService.Events evt, LocalCharacterService.EventCallback callback)
		{
			if (!this._eventsMap.ContainsKey(evt))
			{
				return;
			}
			List<LocalCharacterService.EventCallback> list = this._eventsMap[evt];
			if (list.Contains(callback))
			{
				list.Remove(callback);
			}
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x0002D240 File Offset: 0x0002B440
		public void DispatchEvent(LocalCharacterService.Events evt)
		{
			if (!this._eventsMap.ContainsKey(evt))
			{
				return;
			}
			List<LocalCharacterService.EventCallback> list = this._eventsMap[evt];
			for (int i = 0; i < list.Count; i++)
			{
				list[i]();
			}
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x0002D290 File Offset: 0x0002B490
		public static bool IsPositionOnEnemyArea(Vector3 position, Team playerTeam)
		{
			float num = float.PositiveInfinity;
			for (int i = 0; i < SpawnBlocker.AllBlockers.Count; i++)
			{
				SpawnBlocker spawnBlocker = SpawnBlocker.AllBlockers[i];
				if (spawnBlocker.Team == playerTeam)
				{
					float num2 = Vector3.SqrMagnitude(spawnBlocker.transform.position - position);
					num = Mathf.Min(num, num2);
				}
			}
			return num < 100f;
		}

		// Token: 0x0400095F RID: 2399
		public Predicate<Vector3> IsPointVisible = new Predicate<Vector3>(LocalCharacterService._isPointVisibleStub);

		// Token: 0x04000965 RID: 2405
		public bool IsDead;

		// Token: 0x04000966 RID: 2406
		public float IsDeadTimestamp;

		// Token: 0x04000967 RID: 2407
		public bool IsJumping;

		// Token: 0x04000968 RID: 2408
		public bool IsVisible;

		// Token: 0x04000969 RID: 2409
		private readonly Dictionary<LocalCharacterService.Events, List<LocalCharacterService.EventCallback>> _eventsMap = new Dictionary<LocalCharacterService.Events, List<LocalCharacterService.EventCallback>>();

		// Token: 0x0400096A RID: 2410
		private readonly Dictionary<EHeroSkillV2, SkillState> _dictionarySkillState = new Dictionary<EHeroSkillV2, SkillState>();

		// Token: 0x0400096B RID: 2411
		private int _previousStateBitMask;

		// Token: 0x0400096C RID: 2412
		private int _currentStateBitMask;

		// Token: 0x0400096D RID: 2413
		private const float _distanceToTriggerEnemyAreaWarning = 100f;

		// Token: 0x0200015D RID: 349
		public enum Events : byte
		{
			// Token: 0x04000970 RID: 2416
			OnSpawn,
			// Token: 0x04000971 RID: 2417
			OnKill,
			// Token: 0x04000972 RID: 2418
			OnDie,
			// Token: 0x04000973 RID: 2419
			OnWeaponSwitch,
			// Token: 0x04000974 RID: 2420
			OnBeingHit,
			// Token: 0x04000975 RID: 2421
			OnIronSightIn,
			// Token: 0x04000976 RID: 2422
			OnIronSightOut,
			// Token: 0x04000977 RID: 2423
			OnReload,
			// Token: 0x04000978 RID: 2424
			OnShotFired,
			// Token: 0x04000979 RID: 2425
			OnMeleeAttack,
			// Token: 0x0400097A RID: 2426
			OnGrenadeToss,
			// Token: 0x0400097B RID: 2427
			OnTakingFire,
			// Token: 0x0400097C RID: 2428
			OnSprintStart,
			// Token: 0x0400097D RID: 2429
			OnSprintEnd,
			// Token: 0x0400097E RID: 2430
			OnJumpStart,
			// Token: 0x0400097F RID: 2431
			OnJumpLandingNoDamage,
			// Token: 0x04000980 RID: 2432
			OnJumpLandingWithDamage,
			// Token: 0x04000981 RID: 2433
			OnBackstab,
			// Token: 0x04000982 RID: 2434
			OnAmmoRecoveredOnKill
		}

		// Token: 0x0200015E RID: 350
		// (Invoke) Token: 0x060006D5 RID: 1749
		public delegate void EventCallback();
	}
}
