﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A9 RID: 425
	[StructLayout(LayoutKind.Sequential, Size = 1)]
	public struct Signal
	{
		// Token: 0x14000024 RID: 36
		// (add) Token: 0x060008AA RID: 2218 RVA: 0x000350B4 File Offset: 0x000332B4
		// (remove) Token: 0x060008AB RID: 2219 RVA: 0x000350EC File Offset: 0x000332EC
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action OnExecute;

		// Token: 0x060008AC RID: 2220 RVA: 0x00007FD0 File Offset: 0x000061D0
		public void AddListener(Action onExecute)
		{
			this.OnExecute -= onExecute;
			this.OnExecute += onExecute;
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x00007FE0 File Offset: 0x000061E0
		public void RemoveListener(Action onExecute)
		{
			this.OnExecute -= onExecute;
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x00007FE9 File Offset: 0x000061E9
		public void Dispatch()
		{
			if (this.OnExecute != null)
			{
				this.OnExecute();
			}
		}
	}
}
