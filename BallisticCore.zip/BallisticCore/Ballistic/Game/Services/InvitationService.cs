﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200015A RID: 346
	internal class InvitationService : IService
	{
		// Token: 0x0600069C RID: 1692 RVA: 0x0002CA50 File Offset: 0x0002AC50
		internal override void Preprocess()
		{
			this._startupInviteLobbyId = 0L;
			string[] commandLineArgs = Environment.GetCommandLineArgs();
			if (commandLineArgs.Length == 3 && commandLineArgs[1] == "+connect_lobby")
			{
				try
				{
					this._startupInviteLobbyId = long.Parse(commandLineArgs[2]);
				}
				catch (Exception ex)
				{
					Debug.LogError("Error parsing lobby id: " + ex);
				}
			}
			SteamCallbacks.GameLobbyJoinRequested_t.RegisterCallback(new Action<GameLobbyJoinRequested_t>(this.OnInviteReceived));
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._serverBrowser = ServiceProvider.GetService<ServerBrowserService>();
			this._serverBrowser.ListenSearchEvents(new Action(this.OnSearchStated), new Action(this.OnSearchCancelled), new Action(this.OnSearchEnded), new Action<HostItem>(this.OnSearchUpdate), new Action<List<HostItem>>(this.OnUpdateListRequest));
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x00006AE4 File Offset: 0x00004CE4
		internal override void Postprocess()
		{
			SteamCallbacks.GameLobbyJoinRequested_t.UnregisterCallback(new Action<GameLobbyJoinRequested_t>(this.OnInviteReceived));
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x0002CB30 File Offset: 0x0002AD30
		internal void CheckStartupInvitation()
		{
			if (this._startupInviteLobbyId == 0L)
			{
				return;
			}
			Debug.Log("Startup invitation lobby id = " + this._startupInviteLobbyId);
			this._controller = UIManager.Instance.FindController<ServerBrowserController>();
			if (this._controller == null)
			{
				Debug.LogWarning("Error: ServerBrowserController not found!");
				this.CleanStartupInvitation();
				return;
			}
			this._controller.RefreshServerList();
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x0002CB9C File Offset: 0x0002AD9C
		internal void OnInviteReceived(GameLobbyJoinRequested_t data)
		{
			Debug.Log("Callback Invitation to LobbyId " + data.m_steamIDLobby.m_SteamID);
			this._startupInviteLobbyId = (long)data.m_steamIDLobby.m_SteamID;
			if (this._networkGameService.IsLobbyConnected())
			{
				Debug.Log(string.Concat(new object[]
				{
					"CurrentMatch = ",
					this._networkGameService.GetLobbyId().m_SteamID,
					", InvitationMatch = ",
					data.m_steamIDLobby.m_SteamID
				}));
				if (this._networkGameService.GetLobbyId().m_SteamID == data.m_steamIDLobby.m_SteamID)
				{
					Debug.Log("You are already on this lobby, ignoring it...");
					this.CleanStartupInvitation();
					return;
				}
				if (this._networkGameService.BallisticClient != null && this._networkGameService.BallisticClient.IsConnected)
				{
					ServiceProvider.GetService<SceneService>().LoadMain(string.Empty);
				}
				else
				{
					this._networkGameService.LeaveCurrentLobby();
					this.CheckStartupInvitation();
				}
			}
			else if (this._networkGameService.BallisticClient != null && this._networkGameService.BallisticClient.IsConnected)
			{
				ServiceProvider.GetService<SceneService>().LoadMain(string.Empty);
			}
			else
			{
				this.CheckStartupInvitation();
			}
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x00006AF7 File Offset: 0x00004CF7
		private void CleanStartupInvitation()
		{
			this._startupInviteLobbyId = 0L;
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x00002A31 File Offset: 0x00000C31
		private void OnSearchCancelled()
		{
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x00002A31 File Offset: 0x00000C31
		private void OnUpdateListRequest(List<HostItem> hostItems)
		{
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x0002CD00 File Offset: 0x0002AF00
		private void OnSearchUpdate(HostItem hostItem)
		{
			if (hostItem.SteamId.m_SteamID == (ulong)this._startupInviteLobbyId)
			{
				this._controller.Join(hostItem, EClientMode.SPECTATOR);
			}
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x00006B01 File Offset: 0x00004D01
		private void OnSearchEnded()
		{
			this.CleanStartupInvitation();
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x00002A31 File Offset: 0x00000C31
		private void OnSearchStated()
		{
		}

		// Token: 0x04000954 RID: 2388
		private NetworkGameService _networkGameService;

		// Token: 0x04000955 RID: 2389
		private ServerBrowserService _serverBrowser;

		// Token: 0x04000956 RID: 2390
		private ServerBrowserController _controller;

		// Token: 0x04000957 RID: 2391
		private long _startupInviteLobbyId;
	}
}
