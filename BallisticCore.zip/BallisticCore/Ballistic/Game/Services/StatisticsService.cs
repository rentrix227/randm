﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Achievement;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000190 RID: 400
	internal class StatisticsService : IService
	{
		// Token: 0x170000DB RID: 219
		// (get) Token: 0x06000840 RID: 2112 RVA: 0x00007A76 File Offset: 0x00005C76
		// (set) Token: 0x06000841 RID: 2113 RVA: 0x00007A7E File Offset: 0x00005C7E
		internal bool IsCacheReady { get; private set; }

		// Token: 0x06000842 RID: 2114 RVA: 0x0003342C File Offset: 0x0003162C
		internal override void Preprocess()
		{
			this.IsCacheReady = false;
			this._onCachingUserData = null;
			this.GeneralUserData = new StatisticsGeneralData();
			this.LocalMatchUserData = new StatisticsGeneralData();
			for (int i = 0; i < StatisticsService._heroes.Length; i++)
			{
				this.GeneralUserData.HeroUserDatas.Add(StatisticsService._heroes[i], new StatisticsHeroClassData());
				this.LocalMatchUserData.HeroUserDatas.Add(StatisticsService._heroes[i], new StatisticsHeroClassData());
			}
			this._engages = new HighSpeedArray<EngageEntry>(50);
			SteamCallbacks.UserStatsReceived_t.RegisterCallback(new Action<UserStatsReceived_t>(this.OnUserStatsReceived));
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._networkGameService.OnClientConnectionStarted.AddListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnVoteEnd.AddListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnEngage));
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x00033570 File Offset: 0x00031770
		internal override void Postprocess()
		{
			this._networkGameService.OnClientConnectionStarted.RemoveListener(new Action(this.OnClientConnectionStarted));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnVoteEnd.RemoveListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnEngage));
			SteamCallbacks.UserStatsReceived_t.UnregisterCallback(new Action<UserStatsReceived_t>(this.OnUserStatsReceived));
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x0003361C File Offset: 0x0003181C
		private void OnClientConnectionStarted()
		{
			foreach (EHeroClass eheroClass in StatisticsService._heroes)
			{
				IEnumerator enumerator = Enum.GetValues(typeof(EHeroStatistic)).GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						EHeroStatistic eheroStatistic = (EHeroStatistic)obj;
						this.LocalMatchUserData.HeroUserDatas[eheroClass].SetStatistic(eheroStatistic, 0);
					}
				}
				finally
				{
					IDisposable disposable;
					if ((disposable = enumerator as IDisposable) != null)
					{
						disposable.Dispose();
					}
				}
			}
			this._engages.Clear();
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x0003361C File Offset: 0x0003181C
		private void OnVoteEnd(VoteMapEndEvent evt)
		{
			foreach (EHeroClass eheroClass in StatisticsService._heroes)
			{
				IEnumerator enumerator = Enum.GetValues(typeof(EHeroStatistic)).GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						EHeroStatistic eheroStatistic = (EHeroStatistic)obj;
						this.LocalMatchUserData.HeroUserDatas[eheroClass].SetStatistic(eheroStatistic, 0);
					}
				}
				finally
				{
					IDisposable disposable;
					if ((disposable = enumerator as IDisposable) != null)
					{
						disposable.Dispose();
					}
				}
			}
			this._engages.Clear();
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x000336CC File Offset: 0x000318CC
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			EWinningTeam winningTeam = ServiceProvider.GetService<CurrentMatchService>().GetMatchStandings().WinningTeam;
			if (winningTeam != EWinningTeam.MINE)
			{
				if (winningTeam != EWinningTeam.ENEMY)
				{
					if (winningTeam != EWinningTeam.NONE)
					{
					}
				}
				else
				{
					this.IncrementGeneralUserStats(EGeneralStatistic.LOSES, 1);
				}
			}
			else
			{
				this.IncrementGeneralUserStats(EGeneralStatistic.WINS, 1);
			}
			this.IncrementGeneralUserStats(EGeneralStatistic.MATCHES_PLAYED, 1);
			this.CommitStats();
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x00033734 File Offset: 0x00031934
		private void OnEngage(HitEvent hit)
		{
			if (!hit.Sender.isMe)
			{
				return;
			}
			this._engages.RemoveAll((EngageEntry item) => Time.time - item.TimeStamp > 10f);
			EngageEntry engageEntry = this._engages.Find((EngageEntry item) => item.VictimId == hit.VictimGameClientId);
			if (engageEntry == null)
			{
				engageEntry = new EngageEntry
				{
					VictimId = hit.VictimGameClientId,
					TimeStamp = Time.time,
					AccumulatedDamage = hit.Damage,
					HasEngaged = false
				};
				if (hit.Damage >= 10f)
				{
					engageEntry.HasEngaged = true;
					this.IncrementLocalHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.ENGAGES, 1);
					this.IncrementGeneralHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.ENGAGES, 1);
				}
				if (hit.VictimRemainingLife > 0f)
				{
					this._engages.Add(engageEntry);
				}
			}
			else
			{
				engageEntry.AccumulatedDamage += hit.Damage;
				if (!engageEntry.HasEngaged && engageEntry.AccumulatedDamage >= 10f)
				{
					engageEntry.HasEngaged = true;
					this.IncrementLocalHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.ENGAGES, 1);
					this.IncrementGeneralHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.ENGAGES, 1);
				}
				if (hit.VictimRemainingLife <= 0f)
				{
					this._engages.Remove(engageEntry);
				}
			}
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x0003390C File Offset: 0x00031B0C
		private void OnDie(DieEvent evt)
		{
			if (evt.AdditionalPlayers != null)
			{
				for (int i = 0; i < evt.AdditionalPlayers.Count; i++)
				{
					AdditionalScorer additionalScorer = evt.AdditionalPlayers[i];
					if (additionalScorer.Sender.isMe && (additionalScorer.IsAssist || additionalScorer.IsCriticalAssist))
					{
						this.IncrementGeneralUserStats(EGeneralStatistic.KILL_ASSISTS, 1);
						break;
					}
				}
			}
			if (evt.Killer.isMe && !evt.Sender.isMe)
			{
				this.IncrementLocalHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.KILLS, 1);
				this.IncrementGeneralHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.KILLS, 1);
				if (evt.SaviorKill)
				{
					this.IncrementGeneralUserStats(EGeneralStatistic.SAVIOR_KILLS, 1);
				}
				switch (evt.WeaponCategory)
				{
				case EWeaponCategory.AssaultRifle:
					this.IncrementGeneralUserStats(EGeneralStatistic.ASSAULT_RIFLE_KILLS, 1);
					break;
				case EWeaponCategory.Explosive:
				case EWeaponCategory.GrenadeLauncher:
					this.IncrementGeneralUserStats(EGeneralStatistic.GRENADE_KILLS, 1);
					break;
				case EWeaponCategory.LightMachineGun:
					this.IncrementGeneralUserStats(EGeneralStatistic.LMG_KILLS, 1);
					break;
				case EWeaponCategory.MachinePistol:
					this.IncrementGeneralUserStats(EGeneralStatistic.MACHINE_PISTOL_KILLS, 1);
					break;
				case EWeaponCategory.Melee:
				case EWeaponCategory.MeleeSpecial:
				case EWeaponCategory.Concussion:
					this.IncrementGeneralUserStats(EGeneralStatistic.MELEE_KILLS, 1);
					break;
				case EWeaponCategory.Shotgun:
					this.IncrementGeneralUserStats(EGeneralStatistic.SHOTGUN_KILLS, 1);
					break;
				case EWeaponCategory.Sidearm:
					this.IncrementGeneralUserStats(EGeneralStatistic.PISTOL_KILLS, 1);
					break;
				case EWeaponCategory.SniperRifle:
					this.IncrementGeneralUserStats(EGeneralStatistic.SNIPER_KILLS, 1);
					break;
				case EWeaponCategory.SubMachineGun:
					this.IncrementGeneralUserStats(EGeneralStatistic.SMG_KILLS, 1);
					break;
				}
				if (evt.IsHeadshot)
				{
					this.IncrementGeneralUserStats(EGeneralStatistic.HEADSHOT_KILLS, 1);
					this.IncrementLocalHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.HEADSHOTS, 1);
					this.IncrementGeneralHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.HEADSHOTS, 1);
				}
			}
			if (!evt.Sender.isMe && evt.AdditionalPlayers != null)
			{
				foreach (AdditionalScorer additionalScorer2 in evt.AdditionalPlayers)
				{
					if (additionalScorer2.Sender.isMe && (additionalScorer2.IsAssist || additionalScorer2.IsCriticalAssist))
					{
						this.IncrementLocalHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.ASSISTS, 1);
						this.IncrementGeneralHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.ASSISTS, 1);
						break;
					}
				}
			}
			if (evt.Sender.isMe)
			{
				this.IncrementLocalHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.DEATHS, 1);
				this.IncrementGeneralHeroUserStats(this._gameModeService.SelectedLoadout.GameItemData.GameItem.UniqueIdentifier, EHeroStatistic.DEATHS, 1);
				this._engages.Clear();
			}
			if (!evt.Sender.isMe)
			{
				this._engages.RemoveAll((EngageEntry item) => item.VictimId == evt.SenderId);
			}
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00007A87 File Offset: 0x00005C87
		internal bool RequestCurrentStats(Action<StatisticsGeneralData> onRequestUserDataSucess)
		{
			if (onRequestUserDataSucess != null)
			{
				this._onCachingUserData = (Action<StatisticsGeneralData>)Delegate.Combine(this._onCachingUserData, onRequestUserDataSucess);
			}
			return SteamUserStats.RequestCurrentStats();
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x00033CB8 File Offset: 0x00031EB8
		internal void IncrementGeneralUserStats(EGeneralStatistic statistic, int amount)
		{
			string text = StatisticsConstants.game_generalstatistic(statistic);
			int statistic2 = this.GeneralUserData.GetStatistic(statistic);
			int num = this.GeneralUserData.IncrementStatistic(statistic, amount);
			if (!SteamUserStats.SetStat(text, num))
			{
				Debug.Log("Could not set value into userStatistic:" + text);
			}
			ServiceProvider.GetService<AchievementService>().NotifyStatProgress(statistic, num, statistic2);
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00007AAB File Offset: 0x00005CAB
		internal void IncrementLocalHeroUserStats(EHeroClass heroClass, EHeroStatistic heroStatistic, int amount)
		{
			this.LocalMatchUserData.HeroUserDatas[heroClass].IncrementStatistic(heroStatistic, amount);
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00033D10 File Offset: 0x00031F10
		internal void IncrementGeneralHeroUserStats(EHeroClass heroClass, EHeroStatistic heroStatistic, int amount)
		{
			string text = StatisticsConstants.game_hero_statistic(heroClass, heroStatistic);
			int num = this.GeneralUserData.HeroUserDatas[heroClass].IncrementStatistic(heroStatistic, amount);
			if (!SteamUserStats.SetStat(text, num))
			{
				Debug.Log("Could not set value into heroStatistic:" + text);
			}
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x00033D5C File Offset: 0x00031F5C
		internal void SetGeneralUserStats(EGeneralStatistic statistic, int value)
		{
			this.GeneralUserData.SetStatistic(statistic, value);
			string text = StatisticsConstants.game_generalstatistic(statistic);
			if (!SteamUserStats.SetStat(text, value))
			{
				Debug.Log("Could not set value into userStatistic:" + text);
			}
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x00033D9C File Offset: 0x00031F9C
		internal void SetHeroUserStats(EHeroClass hero, EHeroStatistic heroStatistic, int value)
		{
			this.GeneralUserData.HeroUserDatas[hero].SetStatistic(heroStatistic, value);
			string text = StatisticsConstants.game_hero_statistic(hero, heroStatistic);
			if (!SteamUserStats.SetStat(text, value))
			{
				Debug.Log("Could not set value into heroStatistic:" + text);
			}
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x00033DE8 File Offset: 0x00031FE8
		internal void EraseUserStats()
		{
			this.SetGeneralUserStats(EGeneralStatistic.WINS, 0);
			this.SetGeneralUserStats(EGeneralStatistic.LOSES, 0);
			foreach (EHeroClass eheroClass in StatisticsService._heroes)
			{
				foreach (EHeroStatistic eheroStatistic in StatisticsService._stats)
				{
					this.SetHeroUserStats(eheroClass, eheroStatistic, 0);
				}
			}
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00033E54 File Offset: 0x00032054
		internal static float GetKillDeathRatio(int kills, int deaths)
		{
			float num = ((kills <= 0) ? 1f : ((float)kills));
			float num2 = ((deaths <= 0) ? 1f : ((float)deaths));
			return num / num2;
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x00033E8C File Offset: 0x0003208C
		internal void Log()
		{
			string text = "[CurrentStats]\n";
			int num;
			foreach (EGameMode egameMode in StatisticsService._modes)
			{
				string text2 = text;
				text = string.Concat(new object[] { text2, "GPERF|", egameMode, ":" });
				string text3;
				for (int j = 0; j < 10; j++)
				{
					text3 = StatisticsConstants.gperf_mode(egameMode, j);
					if (SteamUserStats.GetStat(text3, ref num))
					{
						text = text + num.ToString() + "|";
					}
				}
				text3 = StatisticsConstants.gperf_mode_matchs(egameMode);
				if (SteamUserStats.GetStat(text3, ref num))
				{
					text = text + " matchs: " + num;
				}
				text += "\n";
			}
			foreach (EHeroClass eheroClass in StatisticsService._heroes)
			{
				foreach (EGameMode egameMode2 in StatisticsService._modes)
				{
					string text2 = text;
					text = string.Concat(new object[] { text2, "GPERFHERO|", eheroClass, egameMode2, ":" });
					for (int m = 0; m < 5; m++)
					{
						string text3 = StatisticsConstants.gperf_mode_hero(egameMode2, eheroClass, m);
						if (SteamUserStats.GetStat(text3, ref num))
						{
							text = text + num.ToString() + "|";
						}
					}
					text = text.Remove(text.Length - 1, 1) + "\n";
				}
			}
			Debug.Log(text);
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x00007AC6 File Offset: 0x00005CC6
		internal void CommitStats()
		{
			SteamUserStats.StoreStats();
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x00034058 File Offset: 0x00032258
		private void OnUserStatsReceived(UserStatsReceived_t callback)
		{
			if (callback.m_eResult != 1)
			{
				Debug.LogWarning("Error while trying to recover data of from Steam" + callback.m_eResult);
				return;
			}
			IEnumerator enumerator = Enum.GetValues(typeof(EGeneralStatistic)).GetEnumerator();
			int num;
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					EGeneralStatistic egeneralStatistic = (EGeneralStatistic)obj;
					string text = StatisticsConstants.game_generalstatistic(egeneralStatistic);
					if (SteamUserStats.GetStat(text, ref num))
					{
						this.GeneralUserData.SetStatistic(egeneralStatistic, num);
					}
					else
					{
						this.GeneralUserData.SetStatistic(egeneralStatistic, 0);
						Debug.LogWarning("Error while trying to recover data of " + text + " from Steam");
					}
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			foreach (EGameMode egameMode in StatisticsService._modes)
			{
				float num2;
				if (StatisticsConstants.GetRatingFinalClientForMode(egameMode, out num2))
				{
					this.GeneralUserData.SetLeaderboardStatistic(egameMode, num2);
				}
				else
				{
					Debug.LogWarning("Error while trying to recover GetRatingFinalClientForMode[" + egameMode + "] from Steam");
					this.GeneralUserData.SetLeaderboardStatistic(egameMode, 0f);
				}
				string text = StatisticsConstants.gperf_mode_matchs(egameMode);
				if (SteamUserStats.GetStat(text, ref num))
				{
					this.GeneralUserData.SetLeaderboardMatchs(egameMode, num);
				}
				else
				{
					Debug.LogWarning("Error while trying to recover data of " + text + " from Steam");
					this.GeneralUserData.SetLeaderboardMatchs(egameMode, 0);
				}
			}
			foreach (EHeroClass eheroClass in StatisticsService._heroes)
			{
				IEnumerator enumerator2 = Enum.GetValues(typeof(EHeroStatistic)).GetEnumerator();
				try
				{
					while (enumerator2.MoveNext())
					{
						object obj2 = enumerator2.Current;
						EHeroStatistic eheroStatistic = (EHeroStatistic)obj2;
						string text = StatisticsConstants.game_hero_statistic(eheroClass, eheroStatistic);
						if (SteamUserStats.GetStat(text, ref num))
						{
							this.GeneralUserData.HeroUserDatas[eheroClass].SetStatistic(eheroStatistic, num);
						}
						else
						{
							Debug.LogWarning("Error while trying to recover data of " + text + " from Steam");
							this.GeneralUserData.HeroUserDatas[eheroClass].SetStatistic(eheroStatistic, 0);
						}
					}
				}
				finally
				{
					IDisposable disposable2;
					if ((disposable2 = enumerator2 as IDisposable) != null)
					{
						disposable2.Dispose();
					}
				}
				foreach (EGameMode egameMode2 in StatisticsService._modes)
				{
					float num2;
					if (StatisticsConstants.GetRatingFinalClientForModeHero(egameMode2, eheroClass, out num2))
					{
						this.GeneralUserData.HeroUserDatas[eheroClass].SetLeaderboardStatistic(egameMode2, num2);
					}
					else
					{
						Debug.LogWarning(string.Concat(new object[] { "Error while trying to recover GetRatingFinalClientForModeHero[", egameMode2, "][", eheroClass, "] from Steam" }));
						this.GeneralUserData.HeroUserDatas[eheroClass].SetLeaderboardStatistic(egameMode2, 0f);
					}
				}
			}
			if (this._onCachingUserData != null)
			{
				this._onCachingUserData(this.GeneralUserData);
			}
			this._onCachingUserData = null;
			this.IsCacheReady = true;
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x000343C4 File Offset: 0x000325C4
		internal void ClearXp()
		{
			foreach (EHeroClass eheroClass in StatisticsService._heroes)
			{
				while (this.GeneralUserData.HeroUserDatas[eheroClass].Xp > 0)
				{
					if (this.GeneralUserData.HeroUserDatas[eheroClass].Xp > 3000)
					{
						this.IncrementGeneralHeroUserStats(eheroClass, EHeroStatistic.XP, -3000);
					}
					else
					{
						this.IncrementGeneralHeroUserStats(eheroClass, EHeroStatistic.XP, -this.GeneralUserData.HeroUserDatas[eheroClass].Xp);
					}
				}
			}
		}

		// Token: 0x04000AE8 RID: 2792
		internal StatisticsGeneralData LocalMatchUserData;

		// Token: 0x04000AE9 RID: 2793
		internal StatisticsGeneralData GeneralUserData;

		// Token: 0x04000AEA RID: 2794
		private Action<StatisticsGeneralData> _onCachingUserData;

		// Token: 0x04000AEB RID: 2795
		private NetworkGameService _networkGameService;

		// Token: 0x04000AEC RID: 2796
		private GameModeService _gameModeService;

		// Token: 0x04000AEE RID: 2798
		private static readonly EHeroClass[] _heroes = new EHeroClass[]
		{
			EHeroClass.BERSERKER,
			EHeroClass.VANGUARD,
			EHeroClass.WRAITH,
			EHeroClass.GRENADIER,
			EHeroClass.SHADOW,
			EHeroClass.TANK,
			EHeroClass.MARKSMAN
		};

		// Token: 0x04000AEF RID: 2799
		private static readonly EHeroStatistic[] _stats = new EHeroStatistic[]
		{
			EHeroStatistic.ASSISTS,
			EHeroStatistic.DEATHS,
			EHeroStatistic.ENGAGES,
			EHeroStatistic.KILLS,
			EHeroStatistic.HEADSHOTS
		};

		// Token: 0x04000AF0 RID: 2800
		private static readonly EGameMode[] _modes = new EGameMode[]
		{
			EGameMode.TeamDeathMatch,
			EGameMode.Conquest,
			EGameMode.KingOfTheHill,
			EGameMode.FreeForAll,
			EGameMode.Rounds
		};

		// Token: 0x04000AF1 RID: 2801
		private const float _engageTimeLimit = 10f;

		// Token: 0x04000AF2 RID: 2802
		private const float _engageDamageLimit = 10f;

		// Token: 0x04000AF3 RID: 2803
		private HighSpeedArray<EngageEntry> _engages;
	}
}
