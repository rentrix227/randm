﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.DataModel.Container;
using Aquiris.DataModel.ItemModel.ConfigItemModel.GameMapModel;
using Aquiris.DataModel.ItemModel.ConfigItemModel.GameMapModel.ResupplyModel;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200017C RID: 380
	internal class ResupplyService : IService
	{
		// Token: 0x060007B1 RID: 1969 RVA: 0x0000752B File Offset: 0x0000572B
		internal override void Preprocess()
		{
			this._resupplyState = new Dictionary<string, ResupplyState>();
			ServiceProvider.GetService<NetworkGameService>().OnResupplyResponse.AddListener(new Action<ResupplyEvent>(this.OnResupplyResponse));
		}

		// Token: 0x060007B2 RID: 1970 RVA: 0x00007553 File Offset: 0x00005753
		internal override void Postprocess()
		{
			ServiceProvider.GetService<NetworkGameService>().OnResupplyResponse.RemoveListener(new Action<ResupplyEvent>(this.OnResupplyResponse));
		}

		// Token: 0x060007B3 RID: 1971 RVA: 0x0003173C File Offset: 0x0002F93C
		public ResupplyState GetResupplyState(string resupplyLocationName)
		{
			if (!this._resupplyState.ContainsKey(resupplyLocationName))
			{
				this._resupplyState.Add(resupplyLocationName, new ResupplyState
				{
					Active = false,
					Cooldown = 0.0
				});
			}
			return this._resupplyState[resupplyLocationName];
		}

		// Token: 0x060007B4 RID: 1972 RVA: 0x00031794 File Offset: 0x0002F994
		private void OnResupplyResponse(ResupplyEvent evt)
		{
			this._resupplyState[evt.ResupplyLocationName] = new ResupplyState
			{
				Active = evt.IsActive,
				Cooldown = evt.Cooldown
			};
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x00007570 File Offset: 0x00005770
		internal ResupplyStationConfigV2 GetResupplyFromId(int resupplyStationConfig)
		{
			return ConfigItemContainer.Instance.GetItemById(resupplyStationConfig) as ResupplyStationConfigV2;
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x00007582 File Offset: 0x00005782
		internal ResupplyStationConfigV2 GetResupplyFromResupplyConfigEntry(ResupplyConfigEntry gameModeConfigEntry)
		{
			return this.GetResupplyFromId(gameModeConfigEntry.ResupplyConfigID);
		}

		// Token: 0x04000A85 RID: 2693
		private Dictionary<string, ResupplyState> _resupplyState;
	}
}
