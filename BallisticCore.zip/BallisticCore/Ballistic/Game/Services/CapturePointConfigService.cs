﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.DataModel.Container;
using Aquiris.DataModel.ItemModel.ConfigItemModel.GameMapModel;
using Aquiris.DataModel.ItemModel.ConfigItemModel.GameMapModel.CapturePointModel;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200013A RID: 314
	internal class CapturePointConfigService : IService
	{
		// Token: 0x060005DF RID: 1503 RVA: 0x000064D0 File Offset: 0x000046D0
		internal CapturePointConfigV2 GetCapturePointFromId(int itemId)
		{
			return ConfigItemContainer.Instance.GetItemById(itemId) as CapturePointConfigV2;
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x000064E2 File Offset: 0x000046E2
		internal CapturePointConfigV2 GetCapturePointFromEntry(CapturePointConfigEntry configEntry)
		{
			return this.GetCapturePointFromId(configEntry.CapturePointConfigID);
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x000064F0 File Offset: 0x000046F0
		internal PointInfo TransformIntoPointInfo(CapturePointConfigEntry configEntry)
		{
			return this.TransformIntoPointInfo(configEntry.CapturePointLocation, this.GetCapturePointFromEntry(configEntry));
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x00029088 File Offset: 0x00027288
		private PointInfo TransformIntoPointInfo(string name, CapturePointConfigV2 config)
		{
			if (config == null)
			{
				Debug.LogError("CapturePointConfigV2:" + name);
			}
			PointInfo pointInfo = new PointInfo();
			pointInfo.PointName = name;
			pointInfo.CurrentTeamOwner = (sbyte)config.InitialState;
			pointInfo.CapCaptureGaugeValues = CapturePointConfigService.ListToDictionary(config.CapCaptureGauge);
			pointInfo.CurrentCaptureGaugeValues = new Dictionary<sbyte, short>();
			sbyte b = 0;
			while ((int)b < pointInfo.CapCaptureGaugeValues.Count)
			{
				pointInfo.CurrentCaptureGaugeValues[b] = 0;
				b = (sbyte)((int)b + 1);
			}
			pointInfo.PlayersOnPoint = new Dictionary<sbyte, sbyte>();
			sbyte b2 = 0;
			while ((int)b2 < pointInfo.CapCaptureGaugeValues.Count)
			{
				pointInfo.PlayersOnPoint[b2] = 0;
				b2 = (sbyte)((int)b2 + 1);
			}
			return pointInfo;
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x00029148 File Offset: 0x00027348
		private static Dictionary<sbyte, short> ListToDictionary(IEnumerable<short> list)
		{
			Dictionary<sbyte, short> dictionary = new Dictionary<sbyte, short>();
			sbyte b = 0;
			foreach (short num in list)
			{
				dictionary[b] = num;
				b = (sbyte)((int)b + 1);
			}
			return dictionary;
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Preprocess()
		{
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}
	}
}
