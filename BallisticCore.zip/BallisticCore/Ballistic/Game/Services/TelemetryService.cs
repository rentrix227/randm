﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Dedicated;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Ballistic.Network.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Steamworks;
using UnityEngine;
using UnityEngine.Analytics;
using UnityEngine.Rendering;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000199 RID: 409
	internal class TelemetryService : IService
	{
		// Token: 0x170000EE RID: 238
		// (get) Token: 0x06000883 RID: 2179 RVA: 0x00007F46 File Offset: 0x00006146
		private bool IsDedicatedServer
		{
			get
			{
				return BallisticDedicatedServer.IsRunning;
			}
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x00034558 File Offset: 0x00032758
		internal override void Preprocess()
		{
			if (!this.IsDedicatedServer)
			{
				this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
				this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
				this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.OnSpawn));
				this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
				this._remoteCharacterService = ServiceProvider.GetService<RemoteCharactersService>();
				this._sessionMatchCounter = 0;
				this.ProcessGameStart();
			}
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x000345E8 File Offset: 0x000327E8
		internal override void Postprocess()
		{
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.OnSpawn));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x0003464C File Offset: 0x0003284C
		private void OnSpawn(SpawnEvent evt)
		{
			this.SubmitUserId();
			if (evt.User == (long)SteamUser.GetSteamID().m_SteamID)
			{
				TelemetryService.SubmitSpawn((ulong)this._networkGameService.GetGameModeMetaData().GameConfig.GameMap, this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, LoadoutUtil.GetHeroClass(evt.Loadout), LoadoutUtil.GetPrimaryWeapon(evt.Loadout).ItemModel, LoadoutUtil.GetSecondaryWeapon(evt.Loadout).ItemModel, LoadoutUtil.GetMeeleWeapon(evt.Loadout).ItemModel, LoadoutUtil.GetExplosive(evt.Loadout).ItemModel, LoadoutUtil.GetSkillsSelected(evt.Loadout));
				this._lifeTimeSpawnEnabled = true;
				this._lifeTimeKills = 0;
				this._lifeTimeUtc = TimeUtils.getUTCTime();
			}
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x00034718 File Offset: 0x00032918
		private void OnDie(DieEvent evt)
		{
			if (evt.Killer.isMe)
			{
				WeaponV4 itemById = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(evt.WeaponId);
				string text = ((itemById == null) ? "suicide" : itemById.ItemName);
				TelemetryService.SubmitKill((ulong)this._networkGameService.GetGameModeMetaData().GameConfig.GameMap, this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, LoadoutUtil.GetHeroClass(evt.Killer.loadoutInfo), LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo), text, evt.WeaponCategory, evt.Headshot == HeadshotType.HEADSHOT, evt.Sender.isMe);
				if (this._lifeTimeSpawnEnabled)
				{
					this._lifeTimeKills++;
				}
			}
			if (evt.Sender.isMe)
			{
				this._lifeTimeSpawnEnabled = false;
				this.SubmitLifespan((ulong)this._networkGameService.GetGameModeMetaData().GameConfig.GameMap, this._networkGameService.GetGameModeMetaData().GameConfig.GameMode, LoadoutUtil.GetHeroClass(evt.Sender.loadoutInfo), this._lifeTimeKills, (int)(TimeUtils.getUTCTime() - this._lifeTimeUtc) / 1000);
			}
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x00034850 File Offset: 0x00032A50
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			if (this.IsDedicatedServer)
			{
				return;
			}
			this._sessionMatchCounter++;
			int num = PlayerPrefs.GetInt("!telemetry@lastDayMatchesPlayed", 0);
			num++;
			PlayerPrefs.SetInt("!telemetry@lastDayMatchesPlayed", num);
			PlayerPrefs.Save();
			short matchTime = this._networkGameService.GetGameModeMetaData().GameConfig.MatchTime;
			ProgressionService service = ServiceProvider.GetService<ProgressionService>();
			Dictionary<EAwardedXpCategory, int> dictionary;
			int num2 = service.CalculateClassesXpGain(out dictionary).Sum((ClassProgressionData x) => x.XpGained);
			float num3 = service.CalculatePerformanceFactor();
			this.SubmitMatchEnded((int)matchTime, num2, num3);
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x00030048 File Offset: 0x0002E248
		private int GetCurrentDayIndex()
		{
			DateTime utcNow = DateTime.UtcNow;
			return utcNow.Year * 1000 + utcNow.DayOfYear;
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x000348F4 File Offset: 0x00032AF4
		private void ProcessGameStart()
		{
			bool flag = PlayerPrefs.GetInt("!telemetry@lastMatchDayIndex", -1) < this.GetCurrentDayIndex();
			if (flag)
			{
				int @int = PlayerPrefs.GetInt("!telemetry@lastDayMatchesPlayed", 0);
				if (@int > 0)
				{
					this.SubmitEventDayEnded(@int);
					this.SubmitEventPlatform(BallisticVersion.CLIENT_VERSION_INTEGER, ServiceProvider.GetService<GameSettingsService>().Container.Quality, SystemInfo.processorType, SystemInfo.graphicsDeviceName, SystemInfo.graphicsDeviceType, SystemInfo.operatingSystem, SystemInfo.systemMemorySize, SystemInfo.graphicsMemorySize);
				}
				PlayerPrefs.SetInt("!telemetry@lastDayMatchesPlayed", 0);
				PlayerPrefs.SetInt("!telemetry@lastMatchDayIndex", this.GetCurrentDayIndex());
				PlayerPrefs.Save();
			}
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x00007F4D File Offset: 0x0000614D
		internal void ProcessGameQuit()
		{
			this.SubmitEventSessionEnded(this._sessionMatchCounter);
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x00034990 File Offset: 0x00032B90
		private void SubmitUserId()
		{
			if (this._isUserInitialized)
			{
				return;
			}
			Analytics.SetUserId(SteamUser.GetSteamID().m_SteamID.ToString());
			this._isUserInitialized = true;
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x000349D0 File Offset: 0x00032BD0
		private static void SubmitKill(ulong map, EGameMode mode, EHeroClass heroClass, EHeroClass heroClassKilled, string weapon, EWeaponCategory category, bool headshot, bool suicide)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					"Mode|Map",
					mode + "|" + map
				},
				{ "Killed", heroClassKilled },
				{ "Weapon", weapon },
				{ "WeaponCategory", category },
				{ "Headshot", headshot },
				{ "Suicide", suicide }
			};
			TelemetryService.Event("[V2]:Kill " + heroClass, dictionary);
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x00034A70 File Offset: 0x00032C70
		private static void SubmitSpawn(ulong map, EGameMode mode, EHeroClass heroClass, string primary, string secondary, string melee, string grenade, List<EHeroSkillV2> skills)
		{
			skills.Sort(TelemetryService._comparer);
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					"Mode|Map",
					mode + "|" + map
				},
				{
					"Primary|Secondary",
					primary + "|" + secondary
				},
				{
					"Skills",
					skills[0] + "/" + skills[1]
				}
			};
			TelemetryService.Event("[V2]:Spawn " + heroClass, dictionary);
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x00034B10 File Offset: 0x00032D10
		private void SubmitLifespan(ulong map, EGameMode mode, EHeroClass heroClass, int kills, int lifespanInSeconds)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					"Mode|Map",
					mode + "|" + map
				},
				{
					"Hero",
					heroClass.ToString()
				},
				{ "Kills", kills },
				{ "Seconds", lifespanInSeconds }
			};
			TelemetryService.Event("[V2]:Lifetime " + heroClass, dictionary);
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x00034B98 File Offset: 0x00032D98
		internal void SubmitDrop(EHeroClass heroClassBox, ESeason season)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{ "Lockbox", heroClassBox },
				{ "Season", season }
			};
			TelemetryService.Event("[V2]:Drop", dictionary);
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x00034BDC File Offset: 0x00032DDC
		internal void SubmitLockboxOpen(EHeroClass heroClassBox, ESeason season, string itemskin, ERarity rarity)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{ "Season", season },
				{ "Received", itemskin },
				{ "Rarity", rarity }
			};
			TelemetryService.Event("[V2]:Lockbox " + heroClassBox, dictionary);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x00034C38 File Offset: 0x00032E38
		internal void SubmitDisassembly(string itemskin, ERarity rarity, int scrapsGenerated)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{ "Received", itemskin },
				{ "Rarity", rarity },
				{ "Scraps", scrapsGenerated }
			};
			TelemetryService.Event("[V2]:Disassembly", dictionary);
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x00034C88 File Offset: 0x00032E88
		internal void SubmitScrapsExchange(EHeroClass lockboxGenerated, ESeason season)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{ "Lockbox", lockboxGenerated },
				{ "Season", season }
			};
			TelemetryService.Event("[V2]:ExchangeScraps", dictionary);
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x00034CCC File Offset: 0x00032ECC
		internal void SubmitServerVoteResult(string gameMapSelected, EGameMode gameModeSelected)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					"Map",
					gameMapSelected.ToString()
				},
				{
					"Mode",
					gameModeSelected.ToString()
				}
			};
			TelemetryService.Event("[V2]:[BODS]:VoteResult", dictionary);
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x00034D18 File Offset: 0x00032F18
		internal void SubmitMatchEnded(int matchTimeInSeconds, int xpGained, float relativePerformance)
		{
			TelemetryService.Event("[V2]:MatchEnded", new Dictionary<string, object>
			{
				{ "MatchDuration", matchTimeInSeconds },
				{ "XPGained", xpGained },
				{ "RelativePerformance", xpGained }
			});
		}

		// Token: 0x06000896 RID: 2198 RVA: 0x00034D6C File Offset: 0x00032F6C
		internal void SubmitEventSessionEnded(int matchesPlayed)
		{
			TelemetryService.Event("[V2]:SessionEnded", new Dictionary<string, object> { { "MatchesPlayed", matchesPlayed } });
		}

		// Token: 0x06000897 RID: 2199 RVA: 0x00034D9C File Offset: 0x00032F9C
		internal void SubmitEventDayEnded(int matchesPlayed)
		{
			TelemetryService.Event("[V2]:DayEnded", new Dictionary<string, object> { { "MatchesPlayed", matchesPlayed } });
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x00034DCC File Offset: 0x00032FCC
		private void SubmitEventPlatform(int GameVersion, OptionPresetLevel qualityLevel, string processor, string graphics, GraphicsDeviceType graphicsApi, string os, int systemMemory, int graphicsMemory)
		{
			TelemetryService.Event("[V2]:System", new Dictionary<string, object>
			{
				{ "GameVersion", GameVersion },
				{ "Quality", qualityLevel },
				{ "Processor", processor },
				{ "GraphicsCard", graphics },
				{ "GraphicsAPI", graphicsApi },
				{ "OS", os },
				{ "SystemMemory", systemMemory },
				{ "GraphicsMemory", graphicsMemory }
			});
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x00007F5B File Offset: 0x0000615B
		private static void Event(string evt, IDictionary<string, object> parameters)
		{
			Analytics.CustomEvent(evt, parameters);
		}

		// Token: 0x0600089A RID: 2202 RVA: 0x00034E68 File Offset: 0x00033068
		internal void SubmitAvgPlayerToPlayerPing(string ServerName)
		{
			if (this._remoteCharacterService.ActivePlayers.Length > 0)
			{
				float num = 0f;
				float num2 = 0f;
				for (int i = 0; i < this._remoteCharacterService.ActivePlayers.Length; i++)
				{
					float pingForPlayer = this._remoteCharacterService.GetPingForPlayer(this._remoteCharacterService.ActivePlayers[i].PlayerId);
					if (pingForPlayer > 0f)
					{
						num += pingForPlayer;
						num2 += 1f;
					}
				}
				num /= num2;
				string text = "Undefined";
				if (ServerName.Contains("NA East"))
				{
					text = "NA East";
				}
				else if (ServerName.Contains("NA West"))
				{
					text = "NA East";
				}
				else if (ServerName.Contains("Europe"))
				{
					text = "NA East";
				}
				else if (ServerName.Contains("Asia"))
				{
					text = "NA East";
				}
				else if (ServerName.Contains("China"))
				{
					text = "NA East";
				}
				else if (ServerName.Contains("South"))
				{
					text = "NA East";
				}
				TelemetryService.Event("[V2]:Ping", new Dictionary<string, object>
				{
					{ "ServerName", text },
					{ "AveragePing", num }
				});
			}
		}

		// Token: 0x04000B24 RID: 2852
		private static readonly HeroSkillV2Comparer _comparer = new HeroSkillV2Comparer();

		// Token: 0x04000B25 RID: 2853
		private NetworkGameService _networkGameService;

		// Token: 0x04000B26 RID: 2854
		private RemoteCharactersService _remoteCharacterService;

		// Token: 0x04000B27 RID: 2855
		private bool _isUserInitialized;

		// Token: 0x04000B28 RID: 2856
		private const string EventPrefix = "[V2]:";

		// Token: 0x04000B29 RID: 2857
		private const string EventKill = "Kill ";

		// Token: 0x04000B2A RID: 2858
		private const string EventSpawn = "Spawn ";

		// Token: 0x04000B2B RID: 2859
		private const string EventLifetime = "Lifetime ";

		// Token: 0x04000B2C RID: 2860
		private const string EventDropItem = "Drop";

		// Token: 0x04000B2D RID: 2861
		private const string EventLockbox = "Lockbox ";

		// Token: 0x04000B2E RID: 2862
		private const string EventWeaponDisassembly = "Disassembly";

		// Token: 0x04000B2F RID: 2863
		private const string EventExchangeScraps = "ExchangeScraps";

		// Token: 0x04000B30 RID: 2864
		private const string EventMatchEnded = "MatchEnded";

		// Token: 0x04000B31 RID: 2865
		private const string EventSessionEnded = "SessionEnded";

		// Token: 0x04000B32 RID: 2866
		private const string EventDayEnded = "DayEnded";

		// Token: 0x04000B33 RID: 2867
		private const string EventSystem = "System";

		// Token: 0x04000B34 RID: 2868
		private const string EventPing = "Ping";

		// Token: 0x04000B35 RID: 2869
		private const string EventVoteResult = "[BODS]:VoteResult";

		// Token: 0x04000B36 RID: 2870
		private bool _lifeTimeSpawnEnabled;

		// Token: 0x04000B37 RID: 2871
		private int _lifeTimeKills;

		// Token: 0x04000B38 RID: 2872
		private long _lifeTimeUtc;

		// Token: 0x04000B39 RID: 2873
		private int _sessionMatchCounter;

		// Token: 0x04000B3A RID: 2874
		private const string LastMatchDayIndexKey = "!telemetry@lastMatchDayIndex";

		// Token: 0x04000B3B RID: 2875
		private const string LastDayMatchesPlayedKey = "!telemetry@lastDayMatchesPlayed";
	}
}
