﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A2 RID: 418
	public struct OnReloadData
	{
		// Token: 0x04000B5C RID: 2908
		public string WeaponName;

		// Token: 0x04000B5D RID: 2909
		public int ReloadStep;

		// Token: 0x04000B5E RID: 2910
		public float ReloadSpeed;
	}
}
