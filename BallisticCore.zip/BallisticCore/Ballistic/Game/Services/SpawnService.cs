﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Character.PlayerBehaviour;
using Aquiris.Ballistic.Game.Character.PlayerList;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200018E RID: 398
	public class SpawnService : IService
	{
		// Token: 0x06000831 RID: 2097 RVA: 0x00032BF8 File Offset: 0x00030DF8
		internal override void Preprocess()
		{
			this._clientCoroutineList = new Dictionary<long, Coroutine>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._networkGameService.OnSpawn.AddListener(new Action<SpawnEvent>(this.SpawnPlayer));
			this._networkGameService.OnClientListReceived.AddListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnVoteEnd.AddListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			this._networkGameService.OnClientConnectionClosed.AddListener(new Action(this.OnClientConnectionClosed));
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x00032CA4 File Offset: 0x00030EA4
		internal override void Postprocess()
		{
			this._networkGameService.OnSpawn.RemoveListener(new Action<SpawnEvent>(this.SpawnPlayer));
			this._networkGameService.OnClientListReceived.RemoveListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnVoteEnd.RemoveListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			this._networkGameService.OnClientConnectionClosed.RemoveListener(new Action(this.OnClientConnectionClosed));
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x00032D24 File Offset: 0x00030F24
		private void OnClientListReceived(ClientListReceivedEvent evt)
		{
			if (evt.GameClientList == null)
			{
				return;
			}
			for (int i = 0; i < evt.GameClientList.Count; i++)
			{
				GameClient gameClient = evt.GameClientList[i];
				if (gameClient.spawned && !gameClient.isMe && gameClient.loadoutInfo != null)
				{
					SpawnEvent spawnEvent = new SpawnEvent
					{
						User = gameClient.gameClientId,
						SpawnLocationId = "default",
						WeaponInUse = gameClient.weaponId,
						Loadout = gameClient.loadoutInfo
					};
					this.SpawnPlayer(spawnEvent);
				}
			}
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x00007A41 File Offset: 0x00005C41
		private void OnClientConnectionClosed()
		{
			this._clientCoroutineList.Clear();
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00007A41 File Offset: 0x00005C41
		private void OnVoteEnd(VoteMapEndEvent evt)
		{
			this._clientCoroutineList.Clear();
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x00007A4E File Offset: 0x00005C4E
		public void SetContainers(GameObject LocalCharacterContainer, GameObject EnemyCharacterContainer)
		{
			this.LocalCharacterContainer = LocalCharacterContainer;
			this.EnemyCharacterContainer = EnemyCharacterContainer;
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x00032DCC File Offset: 0x00030FCC
		public void SpawnPlayer(SpawnEvent spawnEvent)
		{
			GameClient client = this._networkGameService.GetClient(spawnEvent.User);
			if (this._clientCoroutineList.ContainsKey(spawnEvent.User) && this._clientCoroutineList[spawnEvent.User] != null)
			{
				this._eventProxy.StopCoroutine(this._clientCoroutineList[spawnEvent.User]);
			}
			this._clientCoroutineList[spawnEvent.User] = this._eventProxy.StartCoroutine(this.SpawnPlayerCoroutine(client, spawnEvent));
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x00032E58 File Offset: 0x00031058
		private IEnumerator SpawnPlayerCoroutine(GameClient gameClient, SpawnEvent spawnEvent)
		{
			GameObject characterContainer = ((!gameClient.isMe) ? this.EnemyCharacterContainer : this.LocalCharacterContainer);
			AssetPreloadService assetPreloadService = ServiceProvider.GetService<AssetPreloadService>();
			if (gameClient.isMe)
			{
				assetPreloadService.Load(LoadoutUtil.GetSkinBody(gameClient.loadoutInfo).ItemModel + "_arms");
			}
			else
			{
				assetPreloadService.Load(LoadoutUtil.GetSkinBody(gameClient.loadoutInfo).ItemModel);
			}
			WeaponV4 primary = LoadoutUtil.GetPrimaryWeapon(gameClient.loadoutInfo);
			WeaponV4 secondary = LoadoutUtil.GetSecondaryWeapon(gameClient.loadoutInfo);
			WeaponV4 meele = LoadoutUtil.GetMeeleWeapon(gameClient.loadoutInfo);
			WeaponV4 grenade = LoadoutUtil.GetExplosive(gameClient.loadoutInfo);
			if (gameClient.isMe)
			{
				assetPreloadService.Load("weapon/" + primary.ItemModel + "_prefab");
				assetPreloadService.Load("weapon/" + secondary.ItemModel + "_prefab");
				assetPreloadService.Load("weapon/" + meele.ItemModel + "_prefab");
				assetPreloadService.Load("weapon/" + grenade.ItemModel + "_prefab");
			}
			else
			{
				assetPreloadService.Load("weapon/" + primary.ItemModel + "_prefab_3rd");
				assetPreloadService.Load("weapon/" + secondary.ItemModel + "_prefab_3rd");
				assetPreloadService.Load("weapon/" + meele.ItemModel + "_prefab_3rd");
				assetPreloadService.Load("weapon/" + grenade.ItemModel + "_prefab_3rd");
				Accessory[] accessories = LoadoutUtil.GetAccessories(gameClient.loadoutInfo);
				foreach (Accessory accessory in accessories)
				{
					if (accessory.ItemId != 130)
					{
						foreach (string text in accessory.ItemModel.Split(new char[] { ';' }))
						{
							assetPreloadService.Load("accessories/" + text);
						}
					}
				}
			}
			while (this._gameModeService.State != GameModeState.Ready)
			{
				yield return null;
			}
			if (this._gameModeService.IsEnd())
			{
				yield break;
			}
			if (!this._networkGameService.IsConnected())
			{
				yield break;
			}
			Vector3 spawnTempPosition = new Vector3(1000f, -10000f, 0f);
			SpawnLocation spawnLocation = ServiceProvider.GetService<GameModeService>().GetSpawnLocationById(gameClient.team, spawnEvent.SpawnLocationId);
			if (spawnLocation == null)
			{
				Debug.LogError(string.Concat(new object[]
				{
					"SPAWNPOINT IS NULL:",
					ServiceProvider.GetService<GameModeService>().GameMap,
					" ",
					ServiceProvider.GetService<GameModeService>().GameMode,
					":",
					spawnEvent.SpawnLocationId
				}));
				yield break;
			}
			FPSCharacter fpsCharacter;
			if (!NetworkCharacterTable.ActivePlayers.ContainsKey(gameClient.gameClientId))
			{
				Vector3 vector = spawnLocation.SpawnPosition;
				if (!gameClient.isMe)
				{
					vector = spawnTempPosition;
				}
				fpsCharacter = Object.Instantiate<GameObject>(characterContainer, vector, spawnLocation.SpawnRotation).GetComponent<FPSCharacter>();
				fpsCharacter.gameClient = gameClient;
				fpsCharacter.ownerID = gameClient.gameClientId;
				NetworkCharacterTable.AddPlayer(fpsCharacter);
			}
			else
			{
				fpsCharacter = NetworkCharacterTable.ActivePlayers[gameClient.gameClientId];
				if (!gameClient.isMe)
				{
					fpsCharacter.transform.position = spawnTempPosition;
					fpsCharacter.state.position = spawnTempPosition;
				}
				else
				{
					fpsCharacter.transform.position = spawnLocation.SpawnPosition;
				}
				fpsCharacter.transform.rotation = spawnLocation.SpawnRotation;
				fpsCharacter.gameClient = gameClient;
				fpsCharacter.ownerID = gameClient.gameClientId;
			}
			fpsCharacter.gameObject.SetActive(false);
			fpsCharacter.Spawn(spawnEvent);
			this._clientCoroutineList[spawnEvent.User] = null;
			yield break;
		}

		// Token: 0x04000AD3 RID: 2771
		private NetworkGameService _networkGameService;

		// Token: 0x04000AD4 RID: 2772
		private GameModeService _gameModeService;

		// Token: 0x04000AD5 RID: 2773
		private EventProxy _eventProxy;

		// Token: 0x04000AD6 RID: 2774
		private GameObject LocalCharacterContainer;

		// Token: 0x04000AD7 RID: 2775
		private GameObject EnemyCharacterContainer;

		// Token: 0x04000AD8 RID: 2776
		private Dictionary<long, Coroutine> _clientCoroutineList;
	}
}
