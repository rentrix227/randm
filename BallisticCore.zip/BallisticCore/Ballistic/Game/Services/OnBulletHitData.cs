﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A5 RID: 421
	public struct OnBulletHitData
	{
		// Token: 0x04000B61 RID: 2913
		public Collider HitCollider;

		// Token: 0x04000B62 RID: 2914
		public Vector3 HitPoint;

		// Token: 0x04000B63 RID: 2915
		public Vector3 HitNormal;

		// Token: 0x04000B64 RID: 2916
		public bool IsFirstPerson;

		// Token: 0x04000B65 RID: 2917
		public float WeaponDecalSize;
	}
}
