﻿using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Text;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000167 RID: 359
	[Serializable]
	public class OptionControlService : IService
	{
		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060006F4 RID: 1780 RVA: 0x00006D51 File Offset: 0x00004F51
		// (set) Token: 0x060006F5 RID: 1781 RVA: 0x00006D59 File Offset: 0x00004F59
		public bool ControlEnabled { get; private set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060006F6 RID: 1782 RVA: 0x00006D62 File Offset: 0x00004F62
		// (set) Token: 0x060006F7 RID: 1783 RVA: 0x00006D6A File Offset: 0x00004F6A
		public bool PartialEnabled { get; private set; }

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x060006F8 RID: 1784 RVA: 0x0002D53C File Offset: 0x0002B73C
		// (remove) Token: 0x060006F9 RID: 1785 RVA: 0x0002D574 File Offset: 0x0002B774
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action OnKeyBindingChanged;

		// Token: 0x060006FA RID: 1786 RVA: 0x00006D73 File Offset: 0x00004F73
		internal override void Preprocess()
		{
			this.Container = new OptionControlContainer();
			this.ControlEnabled = true;
			this.PartialEnabled = true;
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x0002D5AC File Offset: 0x0002B7AC
		internal void Save()
		{
			try
			{
				File.WriteAllText("BallisticConfiguration.controls", ConversionUtil.WriteUnityJson(this.Container), Encoding.UTF8);
				Debug.Log("Saved control settings");
			}
			catch (Exception ex)
			{
				Debug.LogError("Error writing settings file:" + ex.Message);
			}
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x0002D610 File Offset: 0x0002B810
		public void Load()
		{
			try
			{
				string text = File.ReadAllText("BallisticConfiguration.controls");
				this.Container = ConversionUtil.ReadUnityJson<OptionControlContainer>(text);
				Debug.Log("Loading controls settings");
				if (this.Container.Version != 5U)
				{
					Debug.Log("Controls settings outdated version. Resetting it");
					this.Reset();
				}
			}
			catch (Exception ex)
			{
				Debug.Log("Error reading controls from file. Resetting it\n" + ex.Message);
				this.Reset();
			}
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x0002D69C File Offset: 0x0002B89C
		internal void Reset()
		{
			Debug.Log("Resetting option control settings");
			this.Container = new OptionControlContainer
			{
				Version = 5U,
				ToggleAim = true,
				InvertMouse = false,
				ToggleCrouch = false,
				ToggleSprint = false,
				MouseWheel = true,
				MouseSensitivityNormal = 0.39f,
				MouseSensitivityIronSight = 0.35f,
				MouseSensitivityTelescopic = 0.31f,
				NormalStageFov = 70
			};
			IEnumerator enumerator = Enum.GetValues(typeof(KeyType)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					KeyType keyType = (KeyType)obj;
					this.Container[keyType] = this.GetDefaultKeyCode(keyType);
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			this.DispatchKeyBindingChanged();
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x00006D8E File Offset: 0x00004F8E
		public void DisableInput()
		{
			this.ControlEnabled = false;
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x00006D97 File Offset: 0x00004F97
		public void EnableInput()
		{
			if (this.ControlEnabled)
			{
				return;
			}
			this.ControlEnabled = true;
			this._enableFrame = Time.frameCount + 15;
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x00006DBA File Offset: 0x00004FBA
		public void EnablePartial()
		{
			this.PartialEnabled = true;
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x00006DC3 File Offset: 0x00004FC3
		public void DisablePartial()
		{
			this.PartialEnabled = false;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x0002D788 File Offset: 0x0002B988
		public KeyCode GetCurrentKeyUp()
		{
			IEnumerator enumerator = Enum.GetValues(typeof(KeyCode)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					KeyCode keyCode = (KeyCode)obj;
					if (Input.GetKeyUp(keyCode))
					{
						return keyCode;
					}
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			return 0;
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x00006DCC File Offset: 0x00004FCC
		public KeyCode GetKeyCode(KeyType button)
		{
			return this.Container.GetKeyCode(button);
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x00006DDA File Offset: 0x00004FDA
		public bool GetKey(KeyType key)
		{
			return this.GetKey(key, true);
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x0002D804 File Offset: 0x0002BA04
		public bool GetKey(KeyType key, bool validate)
		{
			if (validate && !this.ValidateInput(key))
			{
				return false;
			}
			KeyCode keyCode = this.Container.GetKeyCode(key);
			return Input.GetKey(keyCode);
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x00006DE4 File Offset: 0x00004FE4
		public bool GetKeyDown(KeyType key)
		{
			return this.GetKeyDown(key, true);
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x0002D838 File Offset: 0x0002BA38
		public bool GetKeyDown(KeyType key, bool validate)
		{
			if (validate && !this.ValidateInput(key))
			{
				return false;
			}
			KeyCode keyCode = this.Container.GetKeyCode(key);
			return Input.GetKeyDown(keyCode);
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x00006DEE File Offset: 0x00004FEE
		public bool GetKeyUp(KeyType key)
		{
			return this.GetKeyUp(key, true);
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x0002D86C File Offset: 0x0002BA6C
		public bool GetKeyUp(KeyType key, bool validate)
		{
			if (validate && !this.ValidateInput(key))
			{
				return false;
			}
			KeyCode keyCode = this.Container.GetKeyCode(key);
			return Input.GetKeyUp(keyCode);
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x00006DF8 File Offset: 0x00004FF8
		public float GetAxisL(AxisType axis)
		{
			return this.GetAxisL(axis, true);
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x0002D8A0 File Offset: 0x0002BAA0
		public float GetAxisL(AxisType axis, bool validate)
		{
			if (!this.ControlEnabled && validate)
			{
				return 0f;
			}
			if ((axis == AxisType.MOUSE_X || axis == AxisType.MOUSE_Y) && !this.PartialEnabled && validate)
			{
				return 0f;
			}
			switch (axis)
			{
			case AxisType.MOUSE_X:
				return Input.GetAxis("Mouse X");
			case AxisType.MOUSE_Y:
				return ((!this.Container.InvertMouse) ? 1f : (-1f)) * Input.GetAxis("Mouse Y");
			case AxisType.SCROLL_WHEEL:
				return Input.GetAxis("Mouse ScrollWheel");
			case AxisType.HORIZONTAL:
				return OptionControlService.ComputeAxis(this.GetKey(KeyType.LEFT), this.GetKey(KeyType.RIGHT), ref this._horizontalAxis);
			case AxisType.VERTICAL:
				return OptionControlService.ComputeAxis(this.GetKey(KeyType.BACKWARD), this.GetKey(KeyType.FORWARD), ref this._verticalAxis);
			default:
				return 0f;
			}
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x0002D984 File Offset: 0x0002BB84
		public KeyCode GetDefaultKeyCode(KeyType type)
		{
			switch (type)
			{
			case KeyType.FORWARD:
				return 119;
			case KeyType.BACKWARD:
				return 115;
			case KeyType.LEFT:
				return 97;
			case KeyType.RIGHT:
				return 100;
			case KeyType.JUMP:
				return 32;
			case KeyType.CROUCH:
				return 306;
			case KeyType.SPRINT:
				return 304;
			case KeyType.GET_PRIMARY_WEAPON:
				return 49;
			case KeyType.GET_SECONDARY_WEAPON:
				return 50;
			case KeyType.GRENADE:
				return 103;
			case KeyType.MELEE:
				return 102;
			case KeyType.QUICK_CHANGE_WEAPON:
				return 113;
			case KeyType.SUICIDE:
				return 107;
			case KeyType.AIM:
				return 324;
			case KeyType.SHOOT:
				return 323;
			case KeyType.ACTION:
				return 114;
			case KeyType.SCORES:
				return 9;
			case KeyType.RELOAD:
				return 114;
			case KeyType.RETURN:
				return 13;
			case KeyType.CHAT_TEAM:
				return 277;
			case KeyType.CHAT_ALL:
				return 13;
			case KeyType.ESCAPE:
				return 27;
			case KeyType.WEAPON_SECOND_FUNCTION:
				return 101;
			case KeyType.MENU:
				return 27;
			case KeyType.SPACE_BAR:
				return 32;
			case KeyType.VOICE_WHEEL:
				return 118;
			case KeyType.VOICE_MOVE:
				return 51;
			case KeyType.VOICE_DEFEND:
				return 55;
			case KeyType.VOICE_FOLLOW:
				return 52;
			case KeyType.VOICE_LAUGH:
				return 53;
			case KeyType.VOICE_TAUNT:
				return 56;
			case KeyType.VOICE_HELP:
				return 54;
			case KeyType.VOTE_KICK_NO:
				return 48;
			case KeyType.NONE:
				return 0;
			default:
				Debug.LogWarning("[OptionControls] No default key assigment for " + type);
				return 0;
			}
		}

		// Token: 0x0600070E RID: 1806 RVA: 0x0002DAB0 File Offset: 0x0002BCB0
		private bool ValidateInput(KeyType key)
		{
			return (this.ControlEnabled && key == KeyType.RETURN) || (this.ControlEnabled && ((key != KeyType.GRENADE && key != KeyType.SUICIDE) || this._enableFrame < Time.frameCount));
		}

		// Token: 0x0600070F RID: 1807 RVA: 0x0002DB00 File Offset: 0x0002BD00
		private static float ComputeAxis(bool negative, bool positive, ref float current)
		{
			if (!negative && !positive)
			{
				current = 0f;
			}
			else if (Math.Abs(current) < Mathf.Epsilon || !negative || !positive)
			{
				current = ((!negative) ? ((!positive) ? current : 1f) : (-1f));
			}
			return current;
		}

		// Token: 0x06000710 RID: 1808 RVA: 0x00006E02 File Offset: 0x00005002
		internal void DispatchKeyBindingChanged()
		{
			if (this.OnKeyBindingChanged != null)
			{
				this.OnKeyBindingChanged();
			}
		}

		// Token: 0x040009D2 RID: 2514
		private const uint _version = 5U;

		// Token: 0x040009D3 RID: 2515
		private const string _fileName = "BallisticConfiguration.controls";

		// Token: 0x040009D4 RID: 2516
		private int _enableFrame;

		// Token: 0x040009D5 RID: 2517
		private float _horizontalAxis;

		// Token: 0x040009D6 RID: 2518
		private float _verticalAxis;

		// Token: 0x040009D9 RID: 2521
		public OptionControlContainer Container;
	}
}
