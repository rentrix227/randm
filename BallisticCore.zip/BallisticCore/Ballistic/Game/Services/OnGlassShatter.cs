﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A3 RID: 419
	public struct OnGlassShatter
	{
		// Token: 0x04000B5F RID: 2911
		public Vector3 Position;
	}
}
