﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000141 RID: 321
	public class GameSettingsService : IService
	{
		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000600 RID: 1536 RVA: 0x00029BC8 File Offset: 0x00027DC8
		// (remove) Token: 0x06000601 RID: 1537 RVA: 0x00029C00 File Offset: 0x00027E00
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action<QualityChangeData> OnQualityChange;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000602 RID: 1538 RVA: 0x00029C38 File Offset: 0x00027E38
		// (remove) Token: 0x06000603 RID: 1539 RVA: 0x00029C70 File Offset: 0x00027E70
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action<Resolution> OnResolutionChange;

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x00006604 File Offset: 0x00004804
		// (set) Token: 0x06000605 RID: 1541 RVA: 0x0000660C File Offset: 0x0000480C
		public GameSettingsContainer Container { get; private set; }

		// Token: 0x06000606 RID: 1542 RVA: 0x00006615 File Offset: 0x00004815
		internal override void Preprocess()
		{
			this.Container = new GameSettingsContainer();
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x00029CA8 File Offset: 0x00027EA8
		internal void Reset()
		{
			Debug.Log("Resetting game settings");
			this.Container = new GameSettingsContainer
			{
				Quality = OptionPresetLevel.Medium,
				FullScreen = true,
				VSync = false,
				AntiAliasing = AntialisingPresetLevel.OFF,
				Buffering = RenderBuffering.DEFAULT,
				TextureMipmap = TextureMipmapLevel.MAXIMUM,
				AnisotropicFiltering = 0,
				MotionBlur = false,
				InGameChat = true,
				Language = "en_US",
				Version = 8U,
				SoundVolume = 1f,
				MusicVolume = 1f,
				VoiceVolume = 1f,
				Width = ((Screen.resolutions.Length <= 0 || Screen.resolutions[Screen.resolutions.Length - 1].width <= 0) ? 1366 : Screen.resolutions[Screen.resolutions.Length - 1].width),
				Height = ((Screen.resolutions.Length <= 0 || Screen.resolutions[Screen.resolutions.Length - 1].height <= 0) ? 768 : Screen.resolutions[Screen.resolutions.Length - 1].height),
				RefreshRate = ((Screen.resolutions.Length <= 0 || Screen.resolutions[Screen.resolutions.Length - 1].refreshRate <= 0) ? 60 : Screen.resolutions[Screen.resolutions.Length - 1].refreshRate)
			};
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x00029E34 File Offset: 0x00028034
		internal void Save()
		{
			try
			{
				File.WriteAllText("BallisticConfiguration.settings", ConversionUtil.WriteUnityJson(this.Container), Encoding.UTF8);
				Debug.Log("Saved game settings");
			}
			catch (Exception ex)
			{
				Debug.LogError("Error writing settings file:" + ex.Message);
			}
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x00029E98 File Offset: 0x00028098
		public void Load()
		{
			try
			{
				this.Container = ConversionUtil.ReadUnityJson<GameSettingsContainer>(File.ReadAllText("BallisticConfiguration.settings"));
				Debug.Log("Loading game settings");
				if (this.Container.Version != 8U)
				{
					Debug.Log("Game settings outdated version. Resetting it");
					this.Reset();
				}
			}
			catch (Exception ex)
			{
				Debug.Log("Error reading settings from file. Resetting it\n" + ex.Message);
				this.Reset();
			}
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00029F20 File Offset: 0x00028120
		internal Resolution GetCurrentResolution()
		{
			Resolution resolution = default(Resolution);
			resolution.width = this.Container.Width;
			resolution.height = this.Container.Height;
			resolution.refreshRate = this.Container.RefreshRate;
			return resolution;
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x00029F6C File Offset: 0x0002816C
		internal void RebuildVideo()
		{
			Debug.Log(string.Concat(new object[]
			{
				"Setting resolution to ",
				this.Container.Width,
				"x",
				this.Container.Height,
				"@",
				this.Container.RefreshRate
			}));
			ServiceProvider.GetService<GameSettingsService>().DispatchResolutionChange(this.GetCurrentResolution());
			Screen.SetResolution(this.Container.Width, this.Container.Height, this.Container.FullScreen, this.Container.RefreshRate);
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x0002A01C File Offset: 0x0002821C
		internal void RebuildQuality()
		{
			QualitySettings.SetQualityLevel((int)this.Container.Quality);
			ServiceProvider.GetService<GameSettingsService>().DispatchQualityChangeEvent(new QualityChangeData
			{
				Quality = this.Container.Quality,
				AntiAliasing = this.Container.AntiAliasing,
				MotionBlur = this.Container.MotionBlur
			});
			QualitySettings.vSyncCount = ((!this.Container.VSync) ? 0 : 1);
			switch (this.Container.AntiAliasing)
			{
			case AntialisingPresetLevel.MSAAx2:
			case AntialisingPresetLevel.MSAAx2_FXAA:
				QualitySettings.antiAliasing = 2;
				break;
			case AntialisingPresetLevel.MSAAx4:
			case AntialisingPresetLevel.MSAAx4_FXAA:
				QualitySettings.antiAliasing = 4;
				break;
			case AntialisingPresetLevel.MSAAx8:
			case AntialisingPresetLevel.MSAAx8_FXAA:
				QualitySettings.antiAliasing = 8;
				break;
			default:
				QualitySettings.antiAliasing = 0;
				break;
			}
			QualitySettings.maxQueuedFrames = (int)this.Container.Buffering;
			QualitySettings.masterTextureLimit = (int)this.Container.TextureMipmap;
			if (this.Container.AnisotropicFiltering != null)
			{
				QualitySettings.anisotropicFiltering = this.Container.AnisotropicFiltering;
			}
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x0002A13C File Offset: 0x0002833C
		internal void RebuildAudio()
		{
			ServiceProvider.GetService<MusicService>().SetSfxVolume(this.Container.SoundVolume);
			ServiceProvider.GetService<MusicService>().SetMusicVolume(this.Container.MusicVolume);
			ServiceProvider.GetService<MusicService>().SetVoiceVolume(this.Container.VoiceVolume);
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x00006622 File Offset: 0x00004822
		internal void DispatchQualityChangeEvent(QualityChangeData evt)
		{
			if (this.OnQualityChange != null)
			{
				this.OnQualityChange(evt);
			}
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x0000663B File Offset: 0x0000483B
		internal void DispatchResolutionChange(Resolution evt)
		{
			if (this.OnResolutionChange != null)
			{
				this.OnResolutionChange(evt);
			}
		}

		// Token: 0x0400089A RID: 2202
		private const uint _version = 8U;

		// Token: 0x0400089B RID: 2203
		private const string _fileName = "BallisticConfiguration.settings";
	}
}
