﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A8 RID: 424
	[StructLayout(LayoutKind.Sequential, Size = 1)]
	public struct Signal<T>
	{
		// Token: 0x14000023 RID: 35
		// (add) Token: 0x060008A5 RID: 2213 RVA: 0x00035044 File Offset: 0x00033244
		// (remove) Token: 0x060008A6 RID: 2214 RVA: 0x0003507C File Offset: 0x0003327C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action<T> OnExecute;

		// Token: 0x060008A7 RID: 2215 RVA: 0x00007FA5 File Offset: 0x000061A5
		public void AddListener(Action<T> onExecute)
		{
			this.OnExecute += onExecute;
		}

		// Token: 0x060008A8 RID: 2216 RVA: 0x00007FAE File Offset: 0x000061AE
		public void RemoveListener(Action<T> onExecute)
		{
			this.OnExecute -= onExecute;
		}

		// Token: 0x060008A9 RID: 2217 RVA: 0x00007FB7 File Offset: 0x000061B7
		public void Dispatch(T data)
		{
			if (this.OnExecute != null)
			{
				this.OnExecute(data);
			}
		}
	}
}
