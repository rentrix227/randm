﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200018B RID: 395
	[Serializable]
	public struct SoundConfig
	{
		// Token: 0x04000AC4 RID: 2756
		public AudioSource Config;

		// Token: 0x04000AC5 RID: 2757
		public int InstanceLimit;

		// Token: 0x04000AC6 RID: 2758
		public bool UseRandomVolume;

		// Token: 0x04000AC7 RID: 2759
		public Vector2 RndVolumeMinMax;

		// Token: 0x04000AC8 RID: 2760
		public bool UseRandomPitch;

		// Token: 0x04000AC9 RID: 2761
		public Vector2 RndPitchMinMax;
	}
}
