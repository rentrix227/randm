﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A0 RID: 416
	public struct OnDrawData
	{
		// Token: 0x04000B58 RID: 2904
		public string WeaponName;

		// Token: 0x04000B59 RID: 2905
		public bool IsQuickDraw;
	}
}
