﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.Audio;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000162 RID: 354
	internal class MusicService : IService
	{
		// Token: 0x060006D9 RID: 1753 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x00006C00 File Offset: 0x00004E00
		internal override void Preprocess()
		{
			this._mixer = Resources.Load<AudioMixer>("BallisticMixer");
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x00006C1D File Offset: 0x00004E1D
		internal void FadeInMusic(float fadeTime)
		{
			if (this._fadeCoroutine != null)
			{
				this._eventProxy.StopCoroutine(this._fadeCoroutine);
			}
			this._fadeCoroutine = this._eventProxy.StartCoroutine(this.FadeInMusicCoroutine(fadeTime));
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x00006C53 File Offset: 0x00004E53
		internal void FadeOutMusic(float fadeTime)
		{
			if (this._fadeCoroutine != null)
			{
				this._eventProxy.StopCoroutine(this._fadeCoroutine);
			}
			this._fadeCoroutine = this._eventProxy.StartCoroutine(this.FadeOutMusicCoroutine(fadeTime));
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x00006C89 File Offset: 0x00004E89
		internal void MuteUi()
		{
			this.SetUiVolume(-80f);
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x00006C96 File Offset: 0x00004E96
		internal void UnmuteUi()
		{
			this.SetUiVolume(0f);
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x00006CA3 File Offset: 0x00004EA3
		internal void SetUiVolume(float value)
		{
			this._mixer.SetFloat("UiVol", value);
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x0002D304 File Offset: 0x0002B504
		internal AudioMixerGroup GetMixerGroup(string subPath)
		{
			AudioMixerGroup[] array = this._mixer.FindMatchingGroups(subPath);
			if (array.Length > 0)
			{
				return array[0];
			}
			return null;
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x0002D32C File Offset: 0x0002B52C
		private IEnumerator FadeInMusicCoroutine(float fadeTime)
		{
			float fadeInTotal = 0f;
			float currentVol;
			this._mixer.GetFloat("MusicVol", ref currentVol);
			while (fadeInTotal < fadeTime)
			{
				this._mixer.SetFloat("MusicVol", Mathf.Lerp(currentVol, 0f, fadeInTotal / fadeTime));
				fadeInTotal += Time.deltaTime;
				yield return null;
			}
			yield break;
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x0002D350 File Offset: 0x0002B550
		private IEnumerator FadeOutMusicCoroutine(float fadeTime)
		{
			float fadeOutTotal = 0f;
			float currentVol;
			this._mixer.GetFloat("MusicVol", ref currentVol);
			while (fadeOutTotal < fadeTime)
			{
				this._mixer.SetFloat("MusicVol", Mathf.Lerp(currentVol, -80f, fadeOutTotal / fadeTime));
				fadeOutTotal += Time.deltaTime;
				yield return null;
			}
			yield break;
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x00006CB7 File Offset: 0x00004EB7
		private float PercentToDb(float percent)
		{
			return Mathf.Lerp(-80f, 0f, Mathf.Pow(percent, 0.2f));
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x00006CD3 File Offset: 0x00004ED3
		internal void SetSfxVolume(float volume)
		{
			this._mixer.SetFloat("MasterSfxVol", this.PercentToDb(volume));
		}

		// Token: 0x060006E5 RID: 1765 RVA: 0x00006CED File Offset: 0x00004EED
		internal void SetMusicVolume(float volume)
		{
			this._mixer.SetFloat("MasterMusicVol", this.PercentToDb(volume));
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x00006D07 File Offset: 0x00004F07
		internal void SetVoiceVolume(float volume)
		{
			this._mixer.SetFloat("MasterVoiceVol", this.PercentToDb(volume));
		}

		// Token: 0x04000996 RID: 2454
		private EventProxy _eventProxy;

		// Token: 0x04000997 RID: 2455
		private AudioMixer _mixer;

		// Token: 0x04000998 RID: 2456
		private Coroutine _fadeCoroutine;
	}
}
