﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000193 RID: 403
	internal enum EWinningTeam
	{
		// Token: 0x04000AF8 RID: 2808
		NONE,
		// Token: 0x04000AF9 RID: 2809
		MINE,
		// Token: 0x04000AFA RID: 2810
		ENEMY,
		// Token: 0x04000AFB RID: 2811
		UNDEFINED
	}
}
