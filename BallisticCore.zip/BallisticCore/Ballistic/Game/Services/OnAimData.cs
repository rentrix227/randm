﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A1 RID: 417
	public struct OnAimData
	{
		// Token: 0x04000B5A RID: 2906
		public string WeaponName;

		// Token: 0x04000B5B RID: 2907
		public bool IsAimingIn;
	}
}
