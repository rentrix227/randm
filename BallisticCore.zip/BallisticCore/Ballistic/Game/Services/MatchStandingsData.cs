﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200013E RID: 318
	internal struct MatchStandingsData
	{
		// Token: 0x04000876 RID: 2166
		internal EWinningTeam WinningTeam;

		// Token: 0x04000877 RID: 2167
		internal int PlayerRanking;

		// Token: 0x04000878 RID: 2168
		internal int YourTeamWins;

		// Token: 0x04000879 RID: 2169
		internal int EnemyTeamWins;

		// Token: 0x0400087A RID: 2170
		internal int YourTeamScore;

		// Token: 0x0400087B RID: 2171
		internal int EnemyTeamScore;

		// Token: 0x0400087C RID: 2172
		internal int MaxTeamScore;

		// Token: 0x0400087D RID: 2173
		internal Team YourTeam;

		// Token: 0x0400087E RID: 2174
		internal Team EnemyTeam;

		// Token: 0x0400087F RID: 2175
		internal HighSpeedArray<ClientCommonMetaData> YourPlayerData;

		// Token: 0x04000880 RID: 2176
		internal HighSpeedArray<ClientCommonMetaData> EnemyPlayerData;
	}
}
