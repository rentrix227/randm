﻿using System;
using System.Collections.Generic;
using System.Text;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200016E RID: 366
	[Serializable]
	public class ClassProgressionData
	{
		// Token: 0x06000737 RID: 1847 RVA: 0x0002F85C File Offset: 0x0002DA5C
		private string ListToString<T>(List<T> list)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("{");
			foreach (T t in list)
			{
				stringBuilder.Append((t == null) ? "null" : t.ToString()).Append(", ");
			}
			stringBuilder.Append("}");
			return stringBuilder.ToString();
		}

		// Token: 0x06000738 RID: 1848 RVA: 0x0002F904 File Offset: 0x0002DB04
		public override string ToString()
		{
			return string.Concat(new object[]
			{
				"[ClassProgressionData]\nHeroClass:",
				this.HeroClass,
				"\nOldXP:",
				this.OldXp,
				"\nXPGained:",
				this.XpGained,
				"\nOldLevel:",
				this.OldLevel,
				"\nNewLevel:",
				this.NewLevel,
				"\nUnlockTypes:",
				this.ListToString<EUnlockType>(this.UnlockTypes),
				"\nUnlockedItems:",
				this.ListToString<string>(this.UnlockedItems),
				"\nUnlockedItemIndexes:",
				this.ListToString<int>(this.UnlockedItemIndexes),
				"\n"
			});
		}

		// Token: 0x04000A31 RID: 2609
		public EHeroClass HeroClass;

		// Token: 0x04000A32 RID: 2610
		public int OldXp;

		// Token: 0x04000A33 RID: 2611
		public int XpGained;

		// Token: 0x04000A34 RID: 2612
		public int XpAccumulatedToNextLevel;

		// Token: 0x04000A35 RID: 2613
		public int OldLevel;

		// Token: 0x04000A36 RID: 2614
		public int NewLevel;

		// Token: 0x04000A37 RID: 2615
		public List<EUnlockType> UnlockTypes;

		// Token: 0x04000A38 RID: 2616
		public List<string> UnlockedItems;

		// Token: 0x04000A39 RID: 2617
		public List<int> UnlockedItemIndexes;
	}
}
