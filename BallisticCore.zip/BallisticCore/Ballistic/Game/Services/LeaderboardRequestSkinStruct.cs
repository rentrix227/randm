﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Utils;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020004F9 RID: 1273
	internal class LeaderboardRequestSkinStruct
	{
		// Token: 0x06001B0D RID: 6925 RVA: 0x00013D0E File Offset: 0x00011F0E
		public LeaderboardRequestSkinStruct()
		{
			this._leaderboardEntrySkinComparer = new LeaderboardEntrySorterBySkin();
		}

		// Token: 0x06001B0E RID: 6926 RVA: 0x00013D21 File Offset: 0x00011F21
		internal void SetCallback(Action<Leaderboards, LeaderboardEntry[]> OnDownloadCompleted)
		{
			this._OnDownloadCompleted = OnDownloadCompleted;
		}

		// Token: 0x06001B0F RID: 6927 RVA: 0x00013D2A File Offset: 0x00011F2A
		internal void SetMethod(ELeaderboardDataRequest method)
		{
			this._method = method;
		}

		// Token: 0x06001B10 RID: 6928 RVA: 0x00013D33 File Offset: 0x00011F33
		internal void SetRange(int minPlayers, int maxPlayers)
		{
			this._minPlayers = minPlayers;
			this._maxPlayers = maxPlayers;
		}

		// Token: 0x06001B11 RID: 6929 RVA: 0x0008C18C File Offset: 0x0008A38C
		internal void Dispatch()
		{
			SteamAPICall_t steamAPICall_t = SteamUserStats.FindLeaderboard(StatisticsConstants.gperf_leaderboard_name(Leaderboards.SKIN_LEGENDARY_LADDER));
			SteamCallbacks.LeaderboardFindResult_t.RegisterCallResult(new Action<LeaderboardFindResult_t, bool>(this.OnFindLegendaries), steamAPICall_t);
		}

		// Token: 0x06001B12 RID: 6930 RVA: 0x0008C1BC File Offset: 0x0008A3BC
		private void OnFindLegendaries(LeaderboardFindResult_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("IO failure at legendaries");
				return;
			}
			if (evt.m_bLeaderboardFound == 1)
			{
				this._legendaryPointer = evt.m_hSteamLeaderboard;
				SteamAPICall_t steamAPICall_t = SteamUserStats.FindLeaderboard(StatisticsConstants.gperf_leaderboard_name(Leaderboards.SKIN_ELITE_LADDER));
				SteamCallbacks.LeaderboardFindResult_t.RegisterCallResult(new Action<LeaderboardFindResult_t, bool>(this.OnFindElites), steamAPICall_t);
				return;
			}
			this.DisposeFailure("Not found at legendaries");
		}

		// Token: 0x06001B13 RID: 6931 RVA: 0x0008C21C File Offset: 0x0008A41C
		private void OnFindElites(LeaderboardFindResult_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("IO failure at elites");
				return;
			}
			if (evt.m_bLeaderboardFound == 1)
			{
				this._elitePointer = evt.m_hSteamLeaderboard;
				SteamAPICall_t steamAPICall_t = SteamUserStats.FindLeaderboard(StatisticsConstants.gperf_leaderboard_name(Leaderboards.SKIN_SPECIAL_LADDER));
				SteamCallbacks.LeaderboardFindResult_t.RegisterCallResult(new Action<LeaderboardFindResult_t, bool>(this.OnFindSpecials), steamAPICall_t);
				return;
			}
			this.DisposeFailure("Not found at elites");
		}

		// Token: 0x06001B14 RID: 6932 RVA: 0x0008C27C File Offset: 0x0008A47C
		private void OnFindSpecials(LeaderboardFindResult_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("IO failure at specials");
				return;
			}
			if (evt.m_bLeaderboardFound == 1)
			{
				this._specialPointer = evt.m_hSteamLeaderboard;
				SteamAPICall_t steamAPICall_t = SteamUserStats.FindLeaderboard(StatisticsConstants.gperf_leaderboard_name(Leaderboards.SKIN_ADVANCED_LADDER));
				SteamCallbacks.LeaderboardFindResult_t.RegisterCallResult(new Action<LeaderboardFindResult_t, bool>(this.OnFindAdvanceds), steamAPICall_t);
				return;
			}
			this.DisposeFailure("Not found at specials");
		}

		// Token: 0x06001B15 RID: 6933 RVA: 0x0008C2DC File Offset: 0x0008A4DC
		private void OnFindAdvanceds(LeaderboardFindResult_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("IO failure at advanceds");
				return;
			}
			if (evt.m_bLeaderboardFound == 1)
			{
				this._advancedPointer = evt.m_hSteamLeaderboard;
				SteamAPICall_t steamAPICall_t = SteamUserStats.FindLeaderboard(StatisticsConstants.gperf_leaderboard_name(Leaderboards.SKIN_COMMON_LADDER));
				SteamCallbacks.LeaderboardFindResult_t.RegisterCallResult(new Action<LeaderboardFindResult_t, bool>(this.OnFindCommons), steamAPICall_t);
				return;
			}
			this.DisposeFailure("Not found at advanceds");
		}

		// Token: 0x06001B16 RID: 6934 RVA: 0x0008C33C File Offset: 0x0008A53C
		private void OnFindCommons(LeaderboardFindResult_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("IO failure at commons");
				return;
			}
			if (evt.m_bLeaderboardFound == 1)
			{
				this._commonPointer = evt.m_hSteamLeaderboard;
				SteamAPICall_t steamAPICall_t = SteamUserStats.DownloadLeaderboardEntries(this._legendaryPointer, this._method, this._minPlayers, this._maxPlayers);
				SteamCallbacks.LeaderboardScoresDownloaded_t.RegisterCallResult(new Action<LeaderboardScoresDownloaded_t, bool>(this.OnDownloadLegendariesHandler), steamAPICall_t);
				return;
			}
			this.DisposeFailure("Not found at commons");
		}

		// Token: 0x06001B17 RID: 6935 RVA: 0x0008C3AC File Offset: 0x0008A5AC
		private void OnDownloadLegendariesHandler(LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("Download failure at legendaries");
				return;
			}
			this._entries = LeaderboardService.QueryData(Leaderboards.SKIN_LEGENDARY_LADDER, evt, true);
			this._users = this._entries.Select((LeaderboardEntry t) => t.SteamId).ToArray<CSteamID>();
			for (int i = 0; i < this._entries.Length; i++)
			{
				this._entries[i].ScoreLegendary = this._entries[i].Score;
				this._entries[i].Score = 0;
			}
			SteamAPICall_t steamAPICall_t = SteamUserStats.DownloadLeaderboardEntriesForUsers(this._elitePointer, this._users, this._users.Length);
			SteamCallbacks.LeaderboardScoresDownloaded_t.RegisterCallResult(new Action<LeaderboardScoresDownloaded_t, bool>(this.OnDownloadEliteHandler), steamAPICall_t);
		}

		// Token: 0x06001B18 RID: 6936 RVA: 0x0008C478 File Offset: 0x0008A678
		private void OnDownloadEliteHandler(LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("Download failure at elites");
				return;
			}
			LeaderboardEntry_t entry;
			Func<LeaderboardEntry, bool> <>9__0;
			for (int i = 0; i < evt.m_cEntryCount; i++)
			{
				if (SteamUserStats.GetDownloadedLeaderboardEntry(evt.m_hSteamLeaderboardEntries, i, ref entry, null, 0))
				{
					IEnumerable<LeaderboardEntry> entries = this._entries;
					Func<LeaderboardEntry, bool> func;
					if ((func = <>9__0) == null)
					{
						func = (<>9__0 = (LeaderboardEntry t) => t.SteamId.m_SteamID == entry.m_steamIDUser.m_SteamID);
					}
					entries.First(func).ScoreElite = entry.m_nScore;
				}
			}
			SteamAPICall_t steamAPICall_t = SteamUserStats.DownloadLeaderboardEntriesForUsers(this._specialPointer, this._users, this._users.Length);
			SteamCallbacks.LeaderboardScoresDownloaded_t.RegisterCallResult(new Action<LeaderboardScoresDownloaded_t, bool>(this.OnDownloadSpecialHandler), steamAPICall_t);
		}

		// Token: 0x06001B19 RID: 6937 RVA: 0x0008C528 File Offset: 0x0008A728
		private void OnDownloadSpecialHandler(LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("Download failure at specials");
				return;
			}
			LeaderboardEntry_t entry;
			Func<LeaderboardEntry, bool> <>9__0;
			for (int i = 0; i < evt.m_cEntryCount; i++)
			{
				if (SteamUserStats.GetDownloadedLeaderboardEntry(evt.m_hSteamLeaderboardEntries, i, ref entry, null, 0))
				{
					IEnumerable<LeaderboardEntry> entries = this._entries;
					Func<LeaderboardEntry, bool> func;
					if ((func = <>9__0) == null)
					{
						func = (<>9__0 = (LeaderboardEntry t) => t.SteamId.m_SteamID == entry.m_steamIDUser.m_SteamID);
					}
					entries.First(func).ScoreSpecial = entry.m_nScore;
				}
			}
			SteamAPICall_t steamAPICall_t = SteamUserStats.DownloadLeaderboardEntriesForUsers(this._advancedPointer, this._users, this._users.Length);
			SteamCallbacks.LeaderboardScoresDownloaded_t.RegisterCallResult(new Action<LeaderboardScoresDownloaded_t, bool>(this.OnDownloadAdvancedHandler), steamAPICall_t);
		}

		// Token: 0x06001B1A RID: 6938 RVA: 0x0008C5D8 File Offset: 0x0008A7D8
		private void OnDownloadAdvancedHandler(LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("Download failure at advanced");
				return;
			}
			LeaderboardEntry_t entry;
			Func<LeaderboardEntry, bool> <>9__0;
			for (int i = 0; i < evt.m_cEntryCount; i++)
			{
				if (SteamUserStats.GetDownloadedLeaderboardEntry(evt.m_hSteamLeaderboardEntries, i, ref entry, null, 0))
				{
					IEnumerable<LeaderboardEntry> entries = this._entries;
					Func<LeaderboardEntry, bool> func;
					if ((func = <>9__0) == null)
					{
						func = (<>9__0 = (LeaderboardEntry t) => t.SteamId.m_SteamID == entry.m_steamIDUser.m_SteamID);
					}
					entries.First(func).ScoreAdvanced = entry.m_nScore;
				}
			}
			SteamAPICall_t steamAPICall_t = SteamUserStats.DownloadLeaderboardEntriesForUsers(this._commonPointer, this._users, this._users.Length);
			SteamCallbacks.LeaderboardScoresDownloaded_t.RegisterCallResult(new Action<LeaderboardScoresDownloaded_t, bool>(this.OnDownloadCommonHandler), steamAPICall_t);
		}

		// Token: 0x06001B1B RID: 6939 RVA: 0x0008C688 File Offset: 0x0008A888
		private void OnDownloadCommonHandler(LeaderboardScoresDownloaded_t evt, bool bIOFailure)
		{
			if (bIOFailure)
			{
				this.DisposeFailure("Download failure at common");
				return;
			}
			LeaderboardEntry_t entry;
			Func<LeaderboardEntry, bool> <>9__0;
			for (int i = 0; i < evt.m_cEntryCount; i++)
			{
				if (SteamUserStats.GetDownloadedLeaderboardEntry(evt.m_hSteamLeaderboardEntries, i, ref entry, null, 0))
				{
					IEnumerable<LeaderboardEntry> entries = this._entries;
					Func<LeaderboardEntry, bool> func;
					if ((func = <>9__0) == null)
					{
						func = (<>9__0 = (LeaderboardEntry t) => t.SteamId.m_SteamID == entry.m_steamIDUser.m_SteamID);
					}
					entries.First(func).ScoreCommon = entry.m_nScore;
				}
			}
			Array.Sort<LeaderboardEntry>(this._entries, this._leaderboardEntrySkinComparer);
			Array.Reverse<LeaderboardEntry>(this._entries);
			for (int j = 0; j < this._entries.Length; j++)
			{
				this._entries[j].Position = j + 1;
			}
			if (this._OnDownloadCompleted != null)
			{
				this._OnDownloadCompleted(Leaderboards.SKIN_LEGENDARY_LADDER, this._entries);
			}
		}

		// Token: 0x06001B1C RID: 6940 RVA: 0x00013D43 File Offset: 0x00011F43
		protected virtual void DisposeFailure(string failured)
		{
			Debug.LogWarning("Dispatch Skins Leaderboard: failure at " + failured);
		}

		// Token: 0x04001CFA RID: 7418
		private int _minPlayers;

		// Token: 0x04001CFB RID: 7419
		private int _maxPlayers;

		// Token: 0x04001CFC RID: 7420
		private ELeaderboardDataRequest _method;

		// Token: 0x04001CFD RID: 7421
		private LeaderboardEntry[] _entries;

		// Token: 0x04001CFE RID: 7422
		private CSteamID[] _users;

		// Token: 0x04001CFF RID: 7423
		private SteamLeaderboard_t _legendaryPointer;

		// Token: 0x04001D00 RID: 7424
		private SteamLeaderboard_t _elitePointer;

		// Token: 0x04001D01 RID: 7425
		private SteamLeaderboard_t _specialPointer;

		// Token: 0x04001D02 RID: 7426
		private SteamLeaderboard_t _advancedPointer;

		// Token: 0x04001D03 RID: 7427
		private SteamLeaderboard_t _commonPointer;

		// Token: 0x04001D04 RID: 7428
		private LeaderboardEntrySorterBySkin _leaderboardEntrySkinComparer;

		// Token: 0x04001D05 RID: 7429
		private Action<Leaderboards, LeaderboardEntry[]> _OnDownloadCompleted;
	}
}
