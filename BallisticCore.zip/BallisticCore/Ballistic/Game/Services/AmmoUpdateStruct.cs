﻿using System;
using Aquiris.Ballistic.Game.Weapon;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000160 RID: 352
	public struct AmmoUpdateStruct
	{
		// Token: 0x04000989 RID: 2441
		public string Weapon;

		// Token: 0x0400098A RID: 2442
		public int Ammo;

		// Token: 0x0400098B RID: 2443
		public int TotalAmmo;

		// Token: 0x0400098C RID: 2444
		public bool IsMelee;

		// Token: 0x0400098D RID: 2445
		public SecondaryFunctionType SecondaryFunctionType;

		// Token: 0x0400098E RID: 2446
		public float GrenadeCooldownPercent;

		// Token: 0x0400098F RID: 2447
		public float SecondaryFunctionCooldownPercent;
	}
}
