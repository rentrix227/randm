﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.Reward;
using Steamworks;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020004F5 RID: 1269
	internal class LeaderboardEntry
	{
		// Token: 0x04001CEA RID: 7402
		internal CSteamID SteamId;

		// Token: 0x04001CEB RID: 7403
		internal string Name;

		// Token: 0x04001CEC RID: 7404
		internal int Position;

		// Token: 0x04001CED RID: 7405
		internal int Score;

		// Token: 0x04001CEE RID: 7406
		internal LeaderboardPrize PrizeType;

		// Token: 0x04001CEF RID: 7407
		internal Reward Prize;

		// Token: 0x04001CF0 RID: 7408
		internal int ScoreLegendary;

		// Token: 0x04001CF1 RID: 7409
		internal int ScoreElite;

		// Token: 0x04001CF2 RID: 7410
		internal int ScoreSpecial;

		// Token: 0x04001CF3 RID: 7411
		internal int ScoreAdvanced;

		// Token: 0x04001CF4 RID: 7412
		internal int ScoreCommon;
	}
}
