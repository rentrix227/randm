﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200019D RID: 413
	public struct OnProjectileHitData
	{
		// Token: 0x04000B50 RID: 2896
		public string WeaponName;

		// Token: 0x04000B51 RID: 2897
		public Vector3 HitPoint;

		// Token: 0x04000B52 RID: 2898
		public string HitTag;
	}
}
