﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001A7 RID: 423
	[StructLayout(LayoutKind.Sequential, Size = 1)]
	public struct Signal<T, U>
	{
		// Token: 0x14000022 RID: 34
		// (add) Token: 0x060008A0 RID: 2208 RVA: 0x00034FD4 File Offset: 0x000331D4
		// (remove) Token: 0x060008A1 RID: 2209 RVA: 0x0003500C File Offset: 0x0003320C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action<T, U> OnExecute;

		// Token: 0x060008A2 RID: 2210 RVA: 0x00007F79 File Offset: 0x00006179
		public void AddListener(Action<T, U> onExecute)
		{
			this.OnExecute += onExecute;
		}

		// Token: 0x060008A3 RID: 2211 RVA: 0x00007F82 File Offset: 0x00006182
		public void RemoveListener(Action<T, U> onExecute)
		{
			this.OnExecute -= onExecute;
		}

		// Token: 0x060008A4 RID: 2212 RVA: 0x00007F8B File Offset: 0x0000618B
		public void Dispatch(T data, U data2)
		{
			if (this.OnExecute != null)
			{
				this.OnExecute(data, data2);
			}
		}
	}
}
