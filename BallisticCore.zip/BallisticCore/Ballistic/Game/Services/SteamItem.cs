﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000156 RID: 342
	internal class SteamItem
	{
		// Token: 0x04000941 RID: 2369
		internal ulong InstanceId;

		// Token: 0x04000942 RID: 2370
		internal int IdentityId;

		// Token: 0x04000943 RID: 2371
		internal uint Quantity = 1U;
	}
}
