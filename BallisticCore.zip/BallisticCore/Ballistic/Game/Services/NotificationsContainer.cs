﻿using System;
using System.Collections.Generic;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000157 RID: 343
	[Serializable]
	public class NotificationsContainer
	{
		// Token: 0x04000944 RID: 2372
		public uint Version;

		// Token: 0x04000945 RID: 2373
		public List<ulong> NewLockboxes = new List<ulong>();

		// Token: 0x04000946 RID: 2374
		public List<ulong> NewScraps = new List<ulong>();

		// Token: 0x04000947 RID: 2375
		public List<ulong> NewWeaponSkins = new List<ulong>();

		// Token: 0x04000948 RID: 2376
		public List<ulong> NewAccessorys = new List<ulong>();
	}
}
