﻿using System;
using Aquiris.Ballistic.Game.Helper;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000142 RID: 322
	[Serializable]
	public class GameSettingsContainer
	{
		// Token: 0x0400089F RID: 2207
		public string CommentResolution = "Resolution type: Width = integer, Height = integer, RefreshRate = integer";

		// Token: 0x040008A0 RID: 2208
		public int Width = 800;

		// Token: 0x040008A1 RID: 2209
		public int Height = 600;

		// Token: 0x040008A2 RID: 2210
		public int RefreshRate = 60;

		// Token: 0x040008A3 RID: 2211
		public string CommentQuality = "Quality types: 0(LOW), 1(MEDIUM), 2(HIGH)";

		// Token: 0x040008A4 RID: 2212
		public OptionPresetLevel Quality;

		// Token: 0x040008A5 RID: 2213
		public string CommentAntiAliasing = "AntiAliasing types: 0(OFF), 1(FXAA), 2(MSAAx2), 3(MSAAx4), 4(MSAAx8), 5(MSAAx2+FXAA), 6(MSAAx4+FXAA), 7(MSAAx8+FXAA)";

		// Token: 0x040008A6 RID: 2214
		public AntialisingPresetLevel AntiAliasing;

		// Token: 0x040008A7 RID: 2215
		public string CommentBuffering = "Buffering types: 1(OFF), 2(DEFAULT), 3(TRIPLE_BUFFER), 4(QUADRA_BUFFER), 5(PENTA_BUFFER)";

		// Token: 0x040008A8 RID: 2216
		public RenderBuffering Buffering;

		// Token: 0x040008A9 RID: 2217
		public string CommentTextureMipmap = "TextureMipmap types: 0(MAXIMUM), 1(HALF), 2(QUARTER), 3(EIGHTH)";

		// Token: 0x040008AA RID: 2218
		public TextureMipmapLevel TextureMipmap;

		// Token: 0x040008AB RID: 2219
		public string CommentAnisotropicFiltering = "AnisotropicFiltering types: 0(FROM_QUALITY), 1(PER_TEXTURE), 2(FORCED)";

		// Token: 0x040008AC RID: 2220
		public AnisotropicFiltering AnisotropicFiltering;

		// Token: 0x040008AD RID: 2221
		public string CommentMotionBlur = "MotionBlur types: false(DISABLED), true(ENABLED)";

		// Token: 0x040008AE RID: 2222
		public bool MotionBlur;

		// Token: 0x040008AF RID: 2223
		public string CommentFullScreen = "FullScreen types: false(DISABLED), true(ENABLED)";

		// Token: 0x040008B0 RID: 2224
		public bool FullScreen;

		// Token: 0x040008B1 RID: 2225
		public string CommentVSync = "VSync types: false(DISABLED), true(ENABLED)";

		// Token: 0x040008B2 RID: 2226
		public bool VSync;

		// Token: 0x040008B3 RID: 2227
		public string CommentInGameChat = "InGameChat types: false(DISABLED), true(ENABLED)";

		// Token: 0x040008B4 RID: 2228
		public bool InGameChat;

		// Token: 0x040008B5 RID: 2229
		public string Language;

		// Token: 0x040008B6 RID: 2230
		public string CommentVersion = "Change Version cause GameSettings to Reset the file.";

		// Token: 0x040008B7 RID: 2231
		public uint Version;

		// Token: 0x040008B8 RID: 2232
		public string CommentVoiceVolume = "VoiceVolume types: range from 0.0 to 1.0";

		// Token: 0x040008B9 RID: 2233
		public float VoiceVolume;

		// Token: 0x040008BA RID: 2234
		public string CommentSoundVolume = "SoundVolume types: range from 0.0 to 1.0";

		// Token: 0x040008BB RID: 2235
		public float SoundVolume;

		// Token: 0x040008BC RID: 2236
		public string CommentMusicVolume = "MusicVolume types: range from 0.0 to 1.0";

		// Token: 0x040008BD RID: 2237
		public float MusicVolume;

		// Token: 0x040008BE RID: 2238
		public string CommentNetworkNorthAmericaEast = "QuickMatch 'North America East': false(DISABLED), true(ENABLED)";

		// Token: 0x040008BF RID: 2239
		public bool QNetworkNorthAmericaEast = true;

		// Token: 0x040008C0 RID: 2240
		public string CommentNetworkNorthAmericaWest = "QuickMatch 'North America West': false(DISABLED), true(ENABLED)";

		// Token: 0x040008C1 RID: 2241
		public bool QNetworkNorthAmericaWest = true;

		// Token: 0x040008C2 RID: 2242
		public string CommentNetworkSouthAmerica = "QuickMatch 'South America': false(DISABLED), true(ENABLED)";

		// Token: 0x040008C3 RID: 2243
		public bool QNetworkSouthAmerica = true;

		// Token: 0x040008C4 RID: 2244
		public string CommentNetworkEurope = "QuickMatch 'Europe': false(DISABLED), true(ENABLED)";

		// Token: 0x040008C5 RID: 2245
		public bool QNetworkEurope = true;

		// Token: 0x040008C6 RID: 2246
		public string CommentNetworkAsia = "QuickMatch 'Asia': false(DISABLED), true(ENABLED)";

		// Token: 0x040008C7 RID: 2247
		public bool QNetworkAsia = true;

		// Token: 0x040008C8 RID: 2248
		public string CommentNetworkChina = "QuickMatch 'Asia': false(DISABLED), true(ENABLED)";

		// Token: 0x040008C9 RID: 2249
		public bool QNetworkChina = true;

		// Token: 0x040008CA RID: 2250
		public string CommentNetworkDedicated = "QuickMatch 'Custom Dedicated Servers': false(DISABLED), true(ENABLED)";

		// Token: 0x040008CB RID: 2251
		public bool QNetworkDedicated = true;
	}
}
