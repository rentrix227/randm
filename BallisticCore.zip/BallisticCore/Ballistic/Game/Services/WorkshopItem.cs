﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001AD RID: 429
	internal struct WorkshopItem
	{
		// Token: 0x04000B8D RID: 2957
		internal string Title;

		// Token: 0x04000B8E RID: 2958
		internal string Type;

		// Token: 0x04000B8F RID: 2959
		internal ulong PublishedFileId;

		// Token: 0x04000B90 RID: 2960
		internal string Metadata;

		// Token: 0x04000B91 RID: 2961
		internal string Description;

		// Token: 0x04000B92 RID: 2962
		internal string FolderPath;
	}
}
