﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Connection;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000176 RID: 374
	internal class QuickMatchService : IService
	{
		// Token: 0x1400000F RID: 15
		// (add) Token: 0x06000771 RID: 1905 RVA: 0x000308C4 File Offset: 0x0002EAC4
		// (remove) Token: 0x06000772 RID: 1906 RVA: 0x000308FC File Offset: 0x0002EAFC
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnStart;

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000773 RID: 1907 RVA: 0x00030934 File Offset: 0x0002EB34
		// (remove) Token: 0x06000774 RID: 1908 RVA: 0x0003096C File Offset: 0x0002EB6C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnFailed;

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000775 RID: 1909 RVA: 0x000309A4 File Offset: 0x0002EBA4
		// (remove) Token: 0x06000776 RID: 1910 RVA: 0x000309DC File Offset: 0x0002EBDC
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnJoining;

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000777 RID: 1911 RVA: 0x00030A14 File Offset: 0x0002EC14
		// (remove) Token: 0x06000778 RID: 1912 RVA: 0x00030A4C File Offset: 0x0002EC4C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnConnected;

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000779 RID: 1913 RVA: 0x00030A84 File Offset: 0x0002EC84
		// (remove) Token: 0x0600077A RID: 1914 RVA: 0x00030ABC File Offset: 0x0002ECBC
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnMatchIsTakingTooMuchTime;

		// Token: 0x14000014 RID: 20
		// (add) Token: 0x0600077B RID: 1915 RVA: 0x00030AF4 File Offset: 0x0002ECF4
		// (remove) Token: 0x0600077C RID: 1916 RVA: 0x00030B2C File Offset: 0x0002ED2C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnMatchIsAboutToStart;

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x0600077D RID: 1917 RVA: 0x00030B64 File Offset: 0x0002ED64
		// (remove) Token: 0x0600077E RID: 1918 RVA: 0x00030B9C File Offset: 0x0002ED9C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnFinish;

		// Token: 0x14000016 RID: 22
		// (add) Token: 0x0600077F RID: 1919 RVA: 0x00030BD4 File Offset: 0x0002EDD4
		// (remove) Token: 0x06000780 RID: 1920 RVA: 0x00030C0C File Offset: 0x0002EE0C
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal event Action OnCancel;

		// Token: 0x06000781 RID: 1921 RVA: 0x000072E1 File Offset: 0x000054E1
		internal override void Preprocess()
		{
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._gameSettingsService = ServiceProvider.GetService<GameSettingsService>();
			this._networkGameService.OnClientConnectionEstablished.AddListener(new Action(this.OnQuickMatchClientConnectionEstablished));
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x00007320 File Offset: 0x00005520
		internal override void Postprocess()
		{
			this._networkGameService.OnClientConnectionEstablished.RemoveListener(new Action(this.OnQuickMatchClientConnectionEstablished));
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x0000733E File Offset: 0x0000553E
		internal void Search()
		{
			this._highPriority = false;
			this._currentStartSearch = this._eventProxy.StartCoroutine(this.SearchDelayed(3f));
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x00007363 File Offset: 0x00005563
		private void SearchHighPriority()
		{
			this.CleanUp();
			this._highPriority = true;
			this._currentStartSearch = this._eventProxy.StartCoroutine(this.SearchDelayed(1f));
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x00030C44 File Offset: 0x0002EE44
		private IEnumerator SearchDelayed(float delay)
		{
			if (this.OnStart != null)
			{
				this.OnStart();
			}
			yield return new WaitForSeconds(delay);
			this._discovery = new HostDiscovery();
			this._discovery.OnDiscoveryEnded += this.OnDiscoveryEnd;
			this._discovery.OnDiscoveryCanceled += this.OnDiscoveryCanceled;
			this._discovery.Go();
			this._currentStartSearch = null;
			yield break;
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x0000738E File Offset: 0x0000558E
		internal void Cancel()
		{
			if (this.OnCancel != null)
			{
				this.OnCancel();
			}
			this.CleanUp();
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x00030C68 File Offset: 0x0002EE68
		private void DestroyDiscovery()
		{
			if (this._discovery == null)
			{
				return;
			}
			this._discovery.OnDiscoveryEnded -= this.OnDiscoveryEnd;
			this._discovery.OnDiscoveryCanceled -= this.OnDiscoveryCanceled;
			this._discovery = null;
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00030CB8 File Offset: 0x0002EEB8
		private void OnDiscoveryEnd()
		{
			HostItem hostItem = this.FindBestMatch(this._discovery.HostList);
			if (hostItem == null)
			{
				if (this.OnFailed != null)
				{
					this.OnFailed();
				}
				if (this.OnFinish != null)
				{
					this.OnFinish();
				}
			}
			else
			{
				this._lastServerSelected = hostItem.SteamId.m_SteamID;
				if (this.OnJoining != null)
				{
					this.OnJoining();
				}
				this.RegisterEvents();
				if (hostItem.Type == EHostType.Lobby)
				{
					this._networkGameService.JoinLobby(hostItem.SteamId, null, EClientMode.PLAYER);
				}
				else
				{
					this._networkGameService.ConnectToServer(hostItem.SteamId, EClientMode.PLAYER, null, false);
				}
			}
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x000073AC File Offset: 0x000055AC
		private void OnDiscoveryCanceled()
		{
			this.DestroyDiscovery();
			if (this.OnCancel != null)
			{
				this.OnCancel();
			}
			this.CleanUp();
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x00030D78 File Offset: 0x0002EF78
		private void RegisterEvents()
		{
			this._networkGameService.OnClientConnectionFail.AddListener(new Action<LeaveGameMotivation>(this.OnQuickMatchClientConnectionFail));
			this._networkGameService.OnClientConnectionClosed.AddListener(new Action(this.OnClientConnectionClosed));
			this._networkGameService.OnMapLoad.AddListener(new Action<MapLoadEvent>(this.OnMapLoad));
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x00030DDC File Offset: 0x0002EFDC
		private void UnregisterEvents()
		{
			this._networkGameService.OnClientConnectionFail.RemoveListener(new Action<LeaveGameMotivation>(this.OnQuickMatchClientConnectionFail));
			this._networkGameService.OnClientConnectionClosed.RemoveListener(new Action(this.OnClientConnectionClosed));
			this._networkGameService.OnMapLoad.RemoveListener(new Action<MapLoadEvent>(this.OnMapLoad));
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x000073D0 File Offset: 0x000055D0
		private void OnClientConnectionClosed()
		{
			ServiceProvider.GetService<PopupService>().ShowConnectionFail(LeaveGameMotivation.DISCONNECTED);
			Debug.LogWarningFormat("[Quick Match] Connection Closed with Server: {0}", new object[] { LeaveGameMotivation.DISCONNECTED });
			this._connectionFailedServers.Add(this._lastServerSelected);
			this.CleanUp();
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x0000740D File Offset: 0x0000560D
		private void OnQuickMatchClientConnectionFail(LeaveGameMotivation motivation)
		{
			Debug.LogWarningFormat("[Quick Match] Failed to join room. Reason: {0}", new object[] { motivation });
			this._connectionFailedServers.Add(this._lastServerSelected);
			this.CleanUp();
			ServiceProvider.GetService<PopupService>().ShowConnectionFail(motivation);
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x0000744A File Offset: 0x0000564A
		private void OnQuickMatchClientConnectionEstablished()
		{
			this._connectionFailedServers.Clear();
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x00007457 File Offset: 0x00005657
		private void OnMapLoad(MapLoadEvent evt)
		{
			if (this.OnConnected != null)
			{
				this.OnConnected();
			}
			this._currentConnectionRoutine = this._eventProxy.StartCoroutine(this.ConnectionRoutine());
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x00030E40 File Offset: 0x0002F040
		private IEnumerator ConnectionRoutine()
		{
			float timer = 0f;
			while (this._networkGameService.GameClients.Count <= 1 && timer < 30f)
			{
				timer += Time.deltaTime;
				yield return null;
			}
			if (this.OnMatchIsTakingTooMuchTime != null)
			{
				this.OnMatchIsTakingTooMuchTime();
			}
			while (this._networkGameService.GameClients.Count <= 1 && timer < 180f)
			{
				timer += Time.deltaTime;
				yield return null;
			}
			if (this._networkGameService.GameClients.Count <= 1 && !this._highPriority)
			{
				this.SearchHighPriority();
				yield break;
			}
			if (this.OnMatchIsAboutToStart != null)
			{
				this.OnMatchIsAboutToStart();
			}
			yield return new WaitForSeconds(5f);
			this.UnregisterEvents();
			this._networkGameService.LoadMapNow();
			this._currentConnectionRoutine = null;
			if (this.OnFinish != null)
			{
				this.OnFinish();
			}
			yield break;
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x00030E5C File Offset: 0x0002F05C
		private void CleanUp()
		{
			if (this._discovery != null)
			{
				this._discovery.Cancel();
			}
			this.DestroyDiscovery();
			if (this._currentStartSearch != null)
			{
				this._eventProxy.StopCoroutine(this._currentStartSearch);
				this._currentStartSearch = null;
			}
			if (this._currentConnectionRoutine != null)
			{
				this._eventProxy.StopCoroutine(this._currentConnectionRoutine);
				this._currentConnectionRoutine = null;
			}
			this.UnregisterEvents();
			this._networkGameService.DisconnectFromServer();
			if (this.OnFinish != null)
			{
				this.OnFinish();
			}
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x00030EF4 File Offset: 0x0002F0F4
		private HostItem FindBestMatch(IList<HostItem> items)
		{
			HostItem hostItem = null;
			float num = -10000f;
			for (int i = 0; i < items.Count; i++)
			{
				HostItem hostItem2 = items[i];
				if (hostItem2.Status == EServerStatus.OFFICIAL || hostItem2.Status == EServerStatus.DEDICATED)
				{
					if (hostItem2.MaxPing <= 0 || (ulong)hostItem2.Ping <= (ulong)((long)hostItem2.MaxPing))
					{
						if (!hostItem2.Password)
						{
							if (hostItem2.Status == EServerStatus.OFFICIAL)
							{
								if (hostItem2.Name.ToLowerInvariant().Contains("asia") && !this._gameSettingsService.Container.QNetworkAsia)
								{
									goto IL_02B1;
								}
								if (hostItem2.Name.ToLowerInvariant().Contains("china") && !this._gameSettingsService.Container.QNetworkChina)
								{
									goto IL_02B1;
								}
								if (hostItem2.Name.ToLowerInvariant().Contains("europe") && !this._gameSettingsService.Container.QNetworkEurope)
								{
									goto IL_02B1;
								}
								if (hostItem2.Name.ToLowerInvariant().Contains("south") && !this._gameSettingsService.Container.QNetworkSouthAmerica)
								{
									goto IL_02B1;
								}
								if (hostItem2.Name.ToLowerInvariant().Contains("na west") && !this._gameSettingsService.Container.QNetworkNorthAmericaWest)
								{
									goto IL_02B1;
								}
								if (hostItem2.Name.ToLowerInvariant().Contains("na east") && !this._gameSettingsService.Container.QNetworkNorthAmericaEast)
								{
									goto IL_02B1;
								}
							}
							else if (hostItem2.Status == EServerStatus.DEDICATED && !this._gameSettingsService.Container.QNetworkDedicated)
							{
								goto IL_02B1;
							}
							if (this._connectionFailedServers.Contains(hostItem2.SteamId.m_SteamID))
							{
								Debug.LogFormat("Server will be filtered: {0}", new object[] { hostItem2.Name });
							}
							else if (hostItem2.SteamId.m_SteamID != this._lastServerSelected)
							{
								if (hostItem2.NumPlayers > 0U || !this._highPriority)
								{
									float num2 = QuickMatchService.CalculateScoreForServer(hostItem2);
									Debug.LogFormat("[Quick Match] Score for room {0}: {1} (players: {2}/{3}) (ping: {4})", new object[] { hostItem2.Name, num2, hostItem2.NumPlayers, hostItem2.MaxPlayers, hostItem2.Ping });
									if (num2 > num)
									{
										num = num2;
										hostItem = hostItem2;
									}
								}
							}
						}
					}
				}
				IL_02B1:;
			}
			return hostItem;
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x000311C4 File Offset: 0x0002F3C4
		private static float CalculateScoreForServer(HostItem item)
		{
			int num = (int)(item.NumPlayers + item.NumSpectators);
			int ping = (int)item.Ping;
			if (num >= 12)
			{
				return 100f - (float)ping * 2f - 200f - 50f * (float)(num - 12);
			}
			return 100f - (float)ping * 2f + (float)(7 - Mathf.Abs(num - 7)) * 50f;
		}

		// Token: 0x04000A54 RID: 2644
		private NetworkGameService _networkGameService;

		// Token: 0x04000A55 RID: 2645
		private EventProxy _eventProxy;

		// Token: 0x04000A56 RID: 2646
		private GameSettingsService _gameSettingsService;

		// Token: 0x04000A57 RID: 2647
		private ulong _lastServerSelected;

		// Token: 0x04000A58 RID: 2648
		private List<ulong> _connectionFailedServers = new List<ulong>();

		// Token: 0x04000A61 RID: 2657
		private HostDiscovery _discovery;

		// Token: 0x04000A62 RID: 2658
		private Coroutine _currentConnectionRoutine;

		// Token: 0x04000A63 RID: 2659
		private Coroutine _currentStartSearch;

		// Token: 0x04000A64 RID: 2660
		private bool _highPriority;

		// Token: 0x02000177 RID: 375
		internal class QuickMatchDefinitionData
		{
			// Token: 0x04000A65 RID: 2661
			internal const int MaxPlayers = 12;

			// Token: 0x04000A66 RID: 2662
			internal const float PingBaseScore = 100f;

			// Token: 0x04000A67 RID: 2663
			internal const float PingPenaltyMultiplier = 2f;

			// Token: 0x04000A68 RID: 2664
			internal const float FullPenaltyBaseScore = 200f;

			// Token: 0x04000A69 RID: 2665
			internal const float FullPenaltyPerPlayerScore = 50f;

			// Token: 0x04000A6A RID: 2666
			internal const int IdealPlayersCount = 7;

			// Token: 0x04000A6B RID: 2667
			internal const float PerPlayerScore = 50f;
		}
	}
}
