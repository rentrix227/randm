﻿using System;
using System.Collections;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000168 RID: 360
	[Serializable]
	public class OptionControlContainer
	{
		// Token: 0x06000711 RID: 1809 RVA: 0x0002DB68 File Offset: 0x0002BD68
		public OptionControlContainer()
		{
			int num = 0;
			IEnumerator enumerator = Enum.GetValues(typeof(KeyType)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					KeyType keyType = (KeyType)obj;
					if (keyType > (KeyType)num)
					{
						num = (int)keyType;
					}
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			this.KeyCodes = new KeyCode[num + 1];
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x00006E1A File Offset: 0x0000501A
		public KeyCode GetKeyCode(KeyType button)
		{
			if (button == KeyType.RETURN)
			{
				return 13;
			}
			if (button != KeyType.SPACE_BAR)
			{
				return this.KeyCodes[(int)button];
			}
			return 32;
		}

		// Token: 0x170000C4 RID: 196
		public KeyCode this[KeyType type]
		{
			get
			{
				return this.KeyCodes[(int)type];
			}
			set
			{
				this.KeyCodes[(int)type] = value;
				ServiceProvider.GetService<OptionControlService>().DispatchKeyBindingChanged();
			}
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x0002DBF0 File Offset: 0x0002BDF0
		public void RemoveKeys(KeyCode key)
		{
			if (key == null)
			{
				return;
			}
			IEnumerator enumerator = Enum.GetValues(typeof(KeyType)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					KeyType keyType = (KeyType)obj;
					if (!OptionControlContainer.IsSpecialKey(keyType))
					{
						if (this[keyType] == key)
						{
							this[keyType] = 0;
						}
					}
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			ServiceProvider.GetService<OptionControlService>().DispatchKeyBindingChanged();
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x0002DC90 File Offset: 0x0002BE90
		private static bool IsSpecialKey(KeyType type)
		{
			return type == KeyType.SPACE_BAR || type == KeyType.RETURN || type == KeyType.ESCAPE || type == KeyType.VOICE_WHEEL || type == KeyType.VOTE_KICK_NO || type == KeyType.VOICE_TAUNT || type == KeyType.VOICE_MOVE || type == KeyType.VOICE_LAUGH || type == KeyType.VOICE_HELP || type == KeyType.VOICE_DEFEND || type == KeyType.VOICE_FOLLOW;
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x0002DCF8 File Offset: 0x0002BEF8
		public bool CheckExistingInInstance(KeyCode code)
		{
			IEnumerator enumerator = Enum.GetValues(typeof(KeyType)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					KeyType keyType = (KeyType)obj;
					if (!OptionControlContainer.IsSpecialKey(keyType))
					{
						if (this[keyType] == code)
						{
							return true;
						}
					}
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
			return false;
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000718 RID: 1816 RVA: 0x00006E5E File Offset: 0x0000505E
		// (set) Token: 0x06000719 RID: 1817 RVA: 0x00006E66 File Offset: 0x00005066
		public float MouseSensitivityNormal
		{
			get
			{
				return this.mouseSensitivity;
			}
			set
			{
				this.mouseSensitivity = Mathf.Clamp(value, 0.01f, 1f);
				this.rawMouseSensivity = Mathf.Lerp(0.1f, 20f, Mathf.Pow(this.mouseSensitivity, 2f));
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x0600071A RID: 1818 RVA: 0x00006EA3 File Offset: 0x000050A3
		// (set) Token: 0x0600071B RID: 1819 RVA: 0x00006EAB File Offset: 0x000050AB
		public float MouseSensitivityIronSight
		{
			get
			{
				return this.mouseSensitivityIronSight;
			}
			set
			{
				this.mouseSensitivityIronSight = Mathf.Clamp(value, 0.01f, 1f);
				this.rawMouseSensivityIronSight = Mathf.Lerp(0.1f, 20f, Mathf.Pow(this.mouseSensitivityIronSight, 2f));
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x0600071C RID: 1820 RVA: 0x00006EE8 File Offset: 0x000050E8
		// (set) Token: 0x0600071D RID: 1821 RVA: 0x00006EF0 File Offset: 0x000050F0
		public float MouseSensitivityTelescopic
		{
			get
			{
				return this.mouseSensitivityTelescopic;
			}
			set
			{
				this.mouseSensitivityTelescopic = Mathf.Clamp(value, 0.01f, 1f);
				this.rawMouseSensitivityTelescopic = Mathf.Lerp(0.1f, 20f, Mathf.Pow(this.mouseSensitivityTelescopic, 2f));
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x0600071E RID: 1822 RVA: 0x00006F2D File Offset: 0x0000512D
		public float RawSensitivity
		{
			get
			{
				return this.rawMouseSensivity;
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x0600071F RID: 1823 RVA: 0x00006F35 File Offset: 0x00005135
		public float RawSensitivityIronSight
		{
			get
			{
				return this.rawMouseSensivityIronSight;
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000720 RID: 1824 RVA: 0x00006F3D File Offset: 0x0000513D
		public float RawSensitivityTelescopic
		{
			get
			{
				return this.rawMouseSensitivityTelescopic;
			}
		}

		// Token: 0x040009DB RID: 2523
		public uint Version;

		// Token: 0x040009DC RID: 2524
		public bool InvertMouse;

		// Token: 0x040009DD RID: 2525
		public bool ToggleAim;

		// Token: 0x040009DE RID: 2526
		public bool ToggleCrouch;

		// Token: 0x040009DF RID: 2527
		public bool ToggleSprint;

		// Token: 0x040009E0 RID: 2528
		public bool MouseWheel;

		// Token: 0x040009E1 RID: 2529
		public int NormalStageFov;

		// Token: 0x040009E2 RID: 2530
		public float mouseSensitivity;

		// Token: 0x040009E3 RID: 2531
		public float rawMouseSensivity;

		// Token: 0x040009E4 RID: 2532
		public float mouseSensitivityIronSight;

		// Token: 0x040009E5 RID: 2533
		public float rawMouseSensivityIronSight;

		// Token: 0x040009E6 RID: 2534
		public float mouseSensitivityTelescopic;

		// Token: 0x040009E7 RID: 2535
		public float rawMouseSensitivityTelescopic;

		// Token: 0x040009E8 RID: 2536
		public KeyCode[] KeyCodes;

		// Token: 0x040009E9 RID: 2537
		public const float MaxMouseSensitivity = 20f;

		// Token: 0x040009EA RID: 2538
		public const float MinMouseSensitivity = 0.1f;

		// Token: 0x040009EB RID: 2539
		public const float MouseSensitivityExp = 2f;
	}
}
