﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200017A RID: 378
	public class RemoteCharactersService : IService
	{
		// Token: 0x060007A2 RID: 1954 RVA: 0x00031508 File Offset: 0x0002F708
		internal override void Preprocess()
		{
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnUserListChanged.AddListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnClientConnectionEstablished.AddListener(new Action(this.OnClientListRestart));
			this._networkGameService.OnClientListReceived.AddListener(new Action<ClientListReceivedEvent>(this.OnClientListRestart));
			this._networkGameService.OnVoteEnd.AddListener(new Action<VoteMapEndEvent>(this.OnClientListRestart));
			this.ActivePlayers = new HighSpeedArray<RemoteCharacterInfo>(40);
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x000315A0 File Offset: 0x0002F7A0
		internal override void Postprocess()
		{
			this._networkGameService.OnUserListChanged.RemoveListener(new Action<UserListChangedEvent>(this.OnUserListChanged));
			this._networkGameService.OnClientConnectionEstablished.RemoveListener(new Action(this.OnClientListRestart));
			this._networkGameService.OnClientListReceived.RemoveListener(new Action<ClientListReceivedEvent>(this.OnClientListRestart));
			this._networkGameService.OnVoteEnd.RemoveListener(new Action<VoteMapEndEvent>(this.OnClientListRestart));
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x000074C9 File Offset: 0x000056C9
		private void OnClientListRestart(VoteMapEndEvent evt)
		{
			this.ActivePlayers.Clear();
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x000074C9 File Offset: 0x000056C9
		private void OnClientListRestart(ClientListReceivedEvent evt)
		{
			this.ActivePlayers.Clear();
		}

		// Token: 0x060007A6 RID: 1958 RVA: 0x000074C9 File Offset: 0x000056C9
		private void OnClientListRestart()
		{
			this.ActivePlayers.Clear();
		}

		// Token: 0x060007A7 RID: 1959 RVA: 0x000074D6 File Offset: 0x000056D6
		private void OnUserListChanged(UserListChangedEvent evt)
		{
			if (evt.UpdateType == UserUpdateType.UserLeftRoom)
			{
				this.RemovePlayer(evt.SenderId);
			}
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x000074F0 File Offset: 0x000056F0
		private void RemovePlayer(long playerId)
		{
			this.ActivePlayers.Remove<long>(new Func<RemoteCharacterInfo, long, bool>(this.CheckForPlayerId), playerId);
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x0000750A File Offset: 0x0000570A
		private bool CheckForPlayerId(RemoteCharacterInfo info, long playerId)
		{
			return info.PlayerId == playerId;
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x00031620 File Offset: 0x0002F820
		internal RemoteCharacterInfo GetCharacterInfo(long playerId)
		{
			for (int i = 0; i < this.ActivePlayers.Length; i++)
			{
				if (this.ActivePlayers[i].PlayerId == playerId)
				{
					return this.ActivePlayers[i];
				}
			}
			return null;
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x00031670 File Offset: 0x0002F870
		internal float GetPingForPlayer(long playerId)
		{
			float num = -1f;
			this._pingCache.TryGetValue(playerId, out num);
			return num;
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x00007515 File Offset: 0x00005715
		public void MarkPlayerDead(long playerId)
		{
			this.RemovePlayer(playerId);
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x00031694 File Offset: 0x0002F894
		public void UpdatePlayerInfo(long playerId, EHeroClass heroClass, Team team, Vector3 worldPosition, Quaternion worldRotation, bool isVisibleOnRadar, bool isTargetedByPlayer, bool isCamouflaged, string nickname, float health, float maxHealth, bool isVisibleOnScreen, float averagePing)
		{
			RemoteCharacterInfo remoteCharacterInfo = this.GetCharacterInfo(playerId);
			if (remoteCharacterInfo == null)
			{
				remoteCharacterInfo = new RemoteCharacterInfo
				{
					PlayerId = playerId
				};
				this.ActivePlayers.Add(remoteCharacterInfo);
			}
			remoteCharacterInfo.Team = team;
			remoteCharacterInfo.HeroClass = heroClass;
			remoteCharacterInfo.WorldPosition = worldPosition;
			remoteCharacterInfo.WorldRotation = worldRotation;
			remoteCharacterInfo.IsVisibleOnRadar = isVisibleOnRadar;
			remoteCharacterInfo.IsTargetedByPlayer = isTargetedByPlayer;
			remoteCharacterInfo.IsCamouflaged = isCamouflaged;
			remoteCharacterInfo.Nickname = nickname;
			remoteCharacterInfo.Health = health;
			remoteCharacterInfo.MaxHealth = maxHealth;
			remoteCharacterInfo.IsVisibleOnScreen = isVisibleOnScreen;
			if (averagePing > 0.1f)
			{
				this._pingCache[playerId] = averagePing;
			}
		}

		// Token: 0x04000A76 RID: 2678
		private NetworkGameService _networkGameService;

		// Token: 0x04000A77 RID: 2679
		internal HighSpeedArray<RemoteCharacterInfo> ActivePlayers;

		// Token: 0x04000A78 RID: 2680
		private readonly Dictionary<long, float> _pingCache = new Dictionary<long, float>();
	}
}
