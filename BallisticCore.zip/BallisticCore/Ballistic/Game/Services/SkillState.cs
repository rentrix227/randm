﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000161 RID: 353
	public struct SkillState
	{
		// Token: 0x04000990 RID: 2448
		public bool isPermanent;

		// Token: 0x04000991 RID: 2449
		public bool isActive;

		// Token: 0x04000992 RID: 2450
		public int stackCounter;

		// Token: 0x04000993 RID: 2451
		public int timerCounter;

		// Token: 0x04000994 RID: 2452
		public bool isTriggered;

		// Token: 0x04000995 RID: 2453
		public float Timestamp;
	}
}
