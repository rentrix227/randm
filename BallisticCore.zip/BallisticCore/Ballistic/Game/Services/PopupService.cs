﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Connection;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000169 RID: 361
	internal class PopupService : IService
	{
		// Token: 0x06000722 RID: 1826 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x0002DD88 File Offset: 0x0002BF88
		internal override void Preprocess()
		{
			this._layerMap = new Dictionary<EPopupType, int>
			{
				{
					EPopupType.SEARCH_MATCH,
					2
				},
				{
					EPopupType.FAILED_JOINING_MATCH,
					2
				},
				{
					EPopupType.CREATING_MATCH,
					2
				},
				{
					EPopupType.GAME_STARTING,
					2
				},
				{
					EPopupType.QUIT_GAME,
					2
				},
				{
					EPopupType.RESOLUTION_CONFIRMATION,
					2
				},
				{
					EPopupType.NO_MATCH_FOUND,
					2
				},
				{
					EPopupType.CONNECTION_LOST,
					2
				},
				{
					EPopupType.BACK_TO_MENU,
					2
				},
				{
					EPopupType.HOST_LEFT,
					2
				},
				{
					EPopupType.STEAM_ACTION_FAILED,
					2
				},
				{
					EPopupType.KICKED,
					2
				},
				{
					EPopupType.ERROR_CREATING_MATCH,
					2
				},
				{
					EPopupType.JOINING_MATCH,
					2
				},
				{
					EPopupType.KEY_DEFINE,
					2
				},
				{
					EPopupType.DEFAULT_LOADOUTS,
					2
				},
				{
					EPopupType.RESET_STATISTICS,
					2
				},
				{
					EPopupType.QUIT_TO_DESKTOP,
					2
				},
				{
					EPopupType.SCRAPS_MESSAGE,
					2
				},
				{
					EPopupType.STEAM_CONFIRMATION,
					2
				},
				{
					EPopupType.BACK_TO_SOLDIERS,
					2
				},
				{
					EPopupType.BACK_TO_INVENTORY,
					2
				},
				{
					EPopupType.BACK_TO_LEADERBOARD,
					2
				},
				{
					EPopupType.BADCONNECTION,
					2
				},
				{
					EPopupType.GRENADEHACK,
					2
				},
				{
					EPopupType.SPEEDHACK,
					2
				},
				{
					EPopupType.INACTIVITY,
					2
				},
				{
					EPopupType.MAXPING,
					2
				},
				{
					EPopupType.SERVERFULL,
					2
				},
				{
					EPopupType.VACBANNED,
					2
				},
				{
					EPopupType.PASSWORD_REQUIRED,
					2
				},
				{
					EPopupType.PASSWORD_ERROR,
					2
				},
				{
					EPopupType.HOST_KICKED,
					2
				},
				{
					EPopupType.HOST_BLACKLISTED,
					2
				},
				{
					EPopupType.WAITING_PLAYERS,
					2
				},
				{
					EPopupType.MAPS_IS_MISSING,
					2
				},
				{
					EPopupType.MAPS_DOWNLOADING,
					2
				},
				{
					EPopupType.MAPS_UPLOAD_ERROR,
					2
				},
				{
					EPopupType.MAPS_UPLOADING,
					2
				}
			};
			this._localization = ServiceProvider.GetService<LocalizationService>();
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x0002DF04 File Offset: 0x0002C104
		internal void ShowConnectionFail(LeaveGameMotivation motivation)
		{
			switch (motivation)
			{
			case LeaveGameMotivation.MAXPING:
				this.Show(EPopupType.MAXPING, null, null, null, 0f);
				break;
			case LeaveGameMotivation.SERVERFULL:
				this.Show(EPopupType.SERVERFULL, null, null, null, 0f);
				break;
			case LeaveGameMotivation.VACBANNED:
				this.Show(EPopupType.VACBANNED, null, null, null, 0f);
				break;
			case LeaveGameMotivation.WRONGPASSWORD:
				this.Show(EPopupType.PASSWORD_ERROR, null, null, null, 0f);
				break;
			case LeaveGameMotivation.HOST_KICKED:
				this.Show(EPopupType.HOST_KICKED, null, null, null, 0f);
				break;
			case LeaveGameMotivation.HOST_BLACKLISTED:
				this.Show(EPopupType.HOST_BLACKLISTED, null, null, null, 0f);
				break;
			default:
				this.Show(EPopupType.FAILED_JOINING_MATCH, null, null, null, 0f);
				break;
			}
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x0002DFC8 File Offset: 0x0002C1C8
		internal void Show(EPopupType type, string param = null, Action<int> callback = null, Action<int, string> password = null, float progress = 0f)
		{
			switch (type)
			{
			case EPopupType.KEY_DEFINE:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get(param, ELocalizedTextCase.UPPER_CASE)
				};
				UIManager.Instance.ChangeState("KEY_BINDING");
				break;
			case EPopupType.JOINING_MATCH:
				this._popupData = new PopupData
				{
					Type = type,
					Message = this._localization.Get("popup_join_match", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_cancel", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("SEARCHING_CONNECTION");
				break;
			case EPopupType.SEARCH_MATCH:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_searching_match_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_searching_match_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_cancel", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("SEARCHING_CONNECTION");
				break;
			case EPopupType.SCRAPS_MESSAGE:
				if (param != null)
				{
					this._popupData = new PopupData
					{
						Type = type,
						Title = this._localization.Get("popup_scraps_received_title", ELocalizedTextCase.UPPER_CASE),
						Message = string.Format(this._localization.Get("popup_scraps_received_message", ELocalizedTextCase.NONE), param),
						ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
						ButtonCallback = callback
					};
					UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				}
				break;
			case EPopupType.GAME_STARTING:
				this._popupData = new PopupData
				{
					Type = type
				};
				UIManager.Instance.ChangeState("GAME_ABOUT_TO_START");
				break;
			case EPopupType.FAILED_JOINING_MATCH:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_error_joining_match", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_error_joining_match", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.NO_MATCH_FOUND:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_no_match_found_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_no_match_found_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.ERROR_CREATING_MATCH:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_error_creating_match", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_error_creating_match", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.CREATING_MATCH:
				this._popupData = new PopupData
				{
					Type = type,
					Message = this._localization.Get("popup_create_match", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_cancel", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("SEARCHING_CONNECTION");
				break;
			case EPopupType.QUIT_GAME:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_exit_to_desktop_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_exit_match", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.RESOLUTION_CONFIRMATION:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_confirm_resolution_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_confirm_resolution_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.CONNECTION_LOST:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_host_left_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_host_left_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.DEFAULT_LOADOUTS:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_default_loadouts_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_default_loadouts_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.RESET_STATISTICS:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_reset_statistics_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_reset_statistics_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.HOST_LEFT:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_host_left_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_host_left_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.QUIT_TO_DESKTOP:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_exit_to_desktop_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_exit_to_desktop_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.BACK_TO_MENU:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_back_to_menu_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_back_to_menu_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.STEAM_ACTION_FAILED:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_steam_action_failed_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_steam_action_failed_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.KICKED:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_kicked_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_kicked_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.STEAM_CONFIRMATION:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_action_confirmation_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_action_confirmation_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.BACK_TO_SOLDIERS:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_back_to_soldiers_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_back_to_soldiers_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.BACK_TO_INVENTORY:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_back_to_inventory_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_back_to_inventory_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.BACK_TO_LEADERBOARD:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_back_to_leaderboard_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_back_to_leaderboard_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.BADCONNECTION:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_badconnection_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_badconnection_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.GRENADEHACK:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_grenadehack_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_grenadehack_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.SPEEDHACK:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_speedhack_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_speedhack_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.INACTIVITY:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_inactivity_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_inactivity_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.MAXPING:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_maxping_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_maxping_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.SERVERFULL:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_serverfull_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_serverfull_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.VACBANNED:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_vacbanned_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_vacbanned_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.PASSWORD_REQUIRED:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_password_protected_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_password_protected_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_cancel", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = null,
					PasswordCallback = password
				};
				UIManager.Instance.ChangeState("PASSWORD_MESSAGE");
				break;
			case EPopupType.PASSWORD_ERROR:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_password_error_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_password_error_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.HOST_KICKED:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_hostkicked_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_hostkicked_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.HOST_BLACKLISTED:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_hostblacklisted_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_hostblacklisted_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.WAITING_PLAYERS:
				this._popupData = new PopupData
				{
					Type = type,
					Message = this._localization.Get("popup_waiting_players", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_cancel", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("SEARCHING_CONNECTION");
				break;
			case EPopupType.MAPS_IS_MISSING:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_maps_is_missing_title", ELocalizedTextCase.UPPER_CASE),
					Message = string.Format(this._localization.Get("popup_maps_is_missing_message", ELocalizedTextCase.NONE), param),
					ButtonTexts = new string[]
					{
						this._localization.Get("popup_no", ELocalizedTextCase.UPPER_CASE),
						null,
						this._localization.Get("popup_yes", ELocalizedTextCase.UPPER_CASE)
					},
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.MAPS_DOWNLOADING:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_maps_downloading_title", ELocalizedTextCase.UPPER_CASE),
					Message = string.Format(this._localization.Get("popup_maps_downloading_message", ELocalizedTextCase.UPPER_CASE), param, (int)(progress * 100f)),
					ButtonTexts = new string[] { this._localization.Get("popup_cancel", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback,
					Progression = progress
				};
				UIManager.Instance.ChangeState("PROGRESSION_MESSAGE");
				break;
			case EPopupType.MAPS_UPLOAD_ERROR:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_maps_upload_error_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_maps_upload_error_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			case EPopupType.MAPS_UPLOADING:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_maps_uploading_title", ELocalizedTextCase.UPPER_CASE),
					Message = string.Format(this._localization.Get("popup_maps_uploading_message", ELocalizedTextCase.UPPER_CASE), (int)(progress * 100f)),
					ButtonTexts = new string[] { this._localization.Get("popup_cancel", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback,
					Progression = progress
				};
				UIManager.Instance.ChangeState("PROGRESSION_MESSAGE");
				break;
			case EPopupType.MAPS_UPLOAD_SUCCESS:
				this._popupData = new PopupData
				{
					Type = type,
					Title = this._localization.Get("popup_maps_upload_success_title", ELocalizedTextCase.UPPER_CASE),
					Message = this._localization.Get("popup_maps_upload_success_message", ELocalizedTextCase.NONE),
					ButtonTexts = new string[] { this._localization.Get("popup_ok", ELocalizedTextCase.UPPER_CASE) },
					ButtonCallback = callback
				};
				UIManager.Instance.ChangeState("DEFAULT_MESSAGE");
				break;
			}
			if (this.OnPopupDataUpdate != null)
			{
				this.OnPopupDataUpdate(this._popupData);
			}
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x00006F73 File Offset: 0x00005173
		internal void ShowUnlockScraps(ScrapData scrapData)
		{
			this._unlockScrapQueue.Enqueue(scrapData);
			if (this._unlocksRoutine == null)
			{
				this._unlocksRoutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.RunUnlockRoutine());
			}
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x00006FA2 File Offset: 0x000051A2
		internal void ShowUnlockLockbox(LockboxData lockboxData)
		{
			this._unlockItemsQueue.Enqueue(lockboxData);
			if (this._unlocksRoutine == null)
			{
				this._unlocksRoutine = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.RunUnlockRoutine());
			}
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x0002F470 File Offset: 0x0002D670
		private IEnumerator RunUnlockRoutine()
		{
			bool canShowPopup = false;
			while (!canShowPopup)
			{
				canShowPopup = UIManager.Instance.CurrentStates.Contains("FINAL_SCOREBOARD") || UIManager.Instance.CurrentStates.Contains("PROGRESSION") || UIManager.Instance.CurrentStates.Contains("RANKING") || UIManager.Instance.CurrentStates.Contains("HOME") || UIManager.Instance.CurrentStates.Contains("SERVER_BROWSER") || UIManager.Instance.CurrentStates.Contains("INVENTORY") || UIManager.Instance.CurrentStates.Contains("SOLDIER") || UIManager.Instance.CurrentStates.Contains("LEADERBOARDS");
				yield return this._wait;
			}
			while (this._unlockItemsQueue.Count > 0 || this._unlockScrapQueue.Count > 0)
			{
				if (this._unlockItemsQueue.Count > 0)
				{
					LockboxData lockboxData = this._unlockItemsQueue.Dequeue();
					if (this.OnUnlockLockboxDataUpdate != null)
					{
						this.OnUnlockLockboxDataUpdate(lockboxData);
					}
					UIManager.Instance.ChangeState("UNLOCKED_LOCKBOX");
				}
				else if (this._unlockScrapQueue.Count > 0)
				{
					ScrapData scrapData = this._unlockScrapQueue.Dequeue();
					if (this.OnUnlockScrapDataUpdate != null)
					{
						this.OnUnlockScrapDataUpdate(scrapData);
					}
					UIManager.Instance.ChangeState("UNLOCKED_SCRAP");
				}
				yield return this._wait;
				while (UIManager.Instance.CurrentStates.Contains("UNLOCKED_LOCKBOX") || UIManager.Instance.CurrentStates.Contains("UNLOCKED_SCRAP"))
				{
					yield return this._wait;
				}
			}
			this._unlocksRoutine = null;
			yield break;
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x0002F48C File Offset: 0x0002D68C
		internal void ShowItemUnlock(EHeroClass heroClass, EUnlockType unlockType, string unlockItemName, int unlockedItemIndex)
		{
			if (!UIManager.Instance.CurrentStates.Contains("UNLOCKED_ITEM"))
			{
				UIManager.Instance.ChangeState("UNLOCKED_ITEM");
			}
			if (this.OnUnlockItemPopupDataUpdate != null)
			{
				this.OnUnlockItemPopupDataUpdate(new UnlockItemPopupData
				{
					Class = heroClass,
					ItemName = unlockItemName,
					LoadoutNumber = unlockedItemIndex + 1,
					Type = unlockType
				});
			}
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x00006FD1 File Offset: 0x000051D1
		internal void HiddenItemUnlock()
		{
			if (UIManager.Instance.CurrentStates.Contains("UNLOCKED_ITEM"))
			{
				UIManager.Instance.DisableLayer(1);
			}
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0002F500 File Offset: 0x0002D700
		internal void UpdateData(string title = null, string message = null, string[] buttonTexts = null, Action<int> callback = null, float progression = 0f)
		{
			if (!string.IsNullOrEmpty(title))
			{
				this._popupData.Title = title;
			}
			if (!string.IsNullOrEmpty(message))
			{
				this._popupData.Message = message;
			}
			if (buttonTexts != null)
			{
				this._popupData.ButtonTexts = buttonTexts;
			}
			if (callback != null)
			{
				this._popupData.ButtonCallback = callback;
			}
			if (!Mathf.Approximately(progression, 0f))
			{
				this._popupData.Progression = progression;
			}
			if (this.OnPopupDataUpdate != null)
			{
				this.OnPopupDataUpdate(this._popupData);
			}
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x00006FF7 File Offset: 0x000051F7
		internal void Hide(EPopupType type)
		{
			UIManager.Instance.DisableLayer(this._layerMap[type]);
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x0000700F File Offset: 0x0000520F
		internal PopupData GetData()
		{
			return this._popupData;
		}

		// Token: 0x040009EC RID: 2540
		private Dictionary<EPopupType, int> _layerMap;

		// Token: 0x040009ED RID: 2541
		private PopupData _popupData;

		// Token: 0x040009EE RID: 2542
		private LocalizationService _localization;

		// Token: 0x040009EF RID: 2543
		internal Action<PopupData> OnPopupDataUpdate;

		// Token: 0x040009F0 RID: 2544
		internal Action<UnlockItemPopupData> OnUnlockItemPopupDataUpdate;

		// Token: 0x040009F1 RID: 2545
		internal Action<LockboxData> OnUnlockLockboxDataUpdate;

		// Token: 0x040009F2 RID: 2546
		internal Action<ScrapData> OnUnlockScrapDataUpdate;

		// Token: 0x040009F3 RID: 2547
		internal Queue<LockboxData> _unlockItemsQueue = new Queue<LockboxData>();

		// Token: 0x040009F4 RID: 2548
		internal Queue<ScrapData> _unlockScrapQueue = new Queue<ScrapData>();

		// Token: 0x040009F5 RID: 2549
		internal Coroutine _unlocksRoutine;

		// Token: 0x040009F6 RID: 2550
		private WaitForSeconds _wait = new WaitForSeconds(0.5f);
	}
}
