﻿using System;
using Aquiris.Services;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x0200013D RID: 317
	internal class CloudService : IService
	{
		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060005EE RID: 1518 RVA: 0x00029468 File Offset: 0x00027668
		internal ulong AvailableBytes
		{
			get
			{
				ulong num;
				ulong num2;
				if (SteamRemoteStorage.GetQuota(ref num, ref num2))
				{
					return num2;
				}
				return 0UL;
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060005EF RID: 1519 RVA: 0x00029488 File Offset: 0x00027688
		internal ulong TotalBytes
		{
			get
			{
				ulong num;
				ulong num2;
				if (SteamRemoteStorage.GetQuota(ref num, ref num2))
				{
					return num;
				}
				return 0UL;
			}
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x0000659C File Offset: 0x0000479C
		internal bool Exists(string p_name)
		{
			return SteamRemoteStorage.FileExists(p_name);
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x000065A4 File Offset: 0x000047A4
		internal int GetSize(string p_name)
		{
			if (!this.Exists(p_name))
			{
				return 0;
			}
			return SteamRemoteStorage.GetFileSize(p_name);
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x000065BA File Offset: 0x000047BA
		internal bool Write(string p_name, byte[] p_data)
		{
			return SteamRemoteStorage.FileWrite(p_name, p_data, p_data.Length);
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x000294A8 File Offset: 0x000276A8
		internal byte[] Read(string p_name)
		{
			if (!this.Exists(p_name))
			{
				return null;
			}
			int size = this.GetSize(p_name);
			byte[] array = new byte[size];
			int num = SteamRemoteStorage.FileRead(p_name, array, array.Length);
			if (size == num)
			{
				return array;
			}
			return null;
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x000065C6 File Offset: 0x000047C6
		internal bool Delete(string p_name)
		{
			Debug.Log("CloudService::Delete " + p_name);
			return !this.Exists(p_name) || SteamRemoteStorage.FileDelete(p_name);
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x000065EC File Offset: 0x000047EC
		internal int GetCount()
		{
			return SteamRemoteStorage.GetFileCount();
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x000294E8 File Offset: 0x000276E8
		internal string GetNameAt(int p_index)
		{
			int num;
			return SteamRemoteStorage.GetFileNameAndSize(p_index, ref num);
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Preprocess()
		{
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}
	}
}
