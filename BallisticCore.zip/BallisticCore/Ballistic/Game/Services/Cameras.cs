﻿using System;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000139 RID: 313
	public enum Cameras
	{
		// Token: 0x0400086A RID: 2154
		CUTSCENE,
		// Token: 0x0400086B RID: 2155
		KILLCAM,
		// Token: 0x0400086C RID: 2156
		NONE
	}
}
