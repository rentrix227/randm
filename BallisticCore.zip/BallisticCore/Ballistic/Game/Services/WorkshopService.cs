﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020001AA RID: 426
	internal class WorkshopService : IService
	{
		// Token: 0x060008B0 RID: 2224 RVA: 0x00008024 File Offset: 0x00006224
		internal override void Preprocess()
		{
			SteamCallbacks.RemoteStorageUnsubscribePublishedFileResult_t.RegisterCallback(new Action<RemoteStorageUnsubscribePublishedFileResult_t>(this.OnUnsubscribePublishedFile));
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x00008037 File Offset: 0x00006237
		private void OnUnsubscribePublishedFile(RemoteStorageUnsubscribePublishedFileResult_t param)
		{
			ServiceProvider.GetService<GameMapModeConfigService>().ReloadMapConfigs();
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x00008043 File Offset: 0x00006243
		internal override void Postprocess()
		{
			SteamCallbacks.RemoteStorageUnsubscribePublishedFileResult_t.UnregisterCallback(new Action<RemoteStorageUnsubscribePublishedFileResult_t>(this.OnUnsubscribePublishedFile));
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x00035124 File Offset: 0x00033324
		internal void RequestWorkshopItemList()
		{
			UGCQueryHandle_t ugcqueryHandle_t = SteamUGC.CreateQueryUserUGCRequest(SteamUser.GetSteamID().GetAccountID(), 0, 0, 2, SteamUtils.GetAppID(), SteamUtils.GetAppID(), 1U);
			SteamUGC.SetReturnMetadata(ugcqueryHandle_t, true);
			SteamAPICall_t steamAPICall_t = SteamUGC.SendQueryUGCRequest(ugcqueryHandle_t);
			SteamCallbacks.SteamUGCQueryCompleted_t.RegisterCallResult(new Action<SteamUGCQueryCompleted_t, bool>(this.OnUGCQueryPersonalContentCompleted), steamAPICall_t);
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x00035174 File Offset: 0x00033374
		private void OnSubmitItemUpdateCompleted(SubmitItemUpdateResult_t param, bool bIOFailure)
		{
			if (bIOFailure)
			{
				Debug.Log("Failed to submit update.");
				return;
			}
			if (param.m_eResult != 1)
			{
				Debug.Log("Failed to submit update:" + param.m_eResult);
				ServiceProvider.GetService<PopupService>().Show(EPopupType.MAPS_UPLOAD_ERROR, null, null, null, 0f);
			}
			else
			{
				ServiceProvider.GetService<PopupService>().Show(EPopupType.MAPS_UPLOAD_SUCCESS, null, null, null, 0f);
			}
			if (param.m_bUserNeedsToAcceptWorkshopLegalAgreement)
			{
				SteamFriends.ActivateGameOverlayToWebPage("steam://url/CommunityFilePage/" + this._currentUpdatingItem.PublishedFileId.ToString());
			}
			Debug.Log("Submit Item Sucess");
			this.RequestWorkshopItemList();
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00035228 File Offset: 0x00033428
		private void OnUGCQueryPersonalContentCompleted(SteamUGCQueryCompleted_t param, bool bIOFailure)
		{
			if (param.m_eResult == 1)
			{
				WorkshopItem[] array = new WorkshopItem[param.m_unNumResultsReturned];
				for (uint num = 0U; num < param.m_unNumResultsReturned; num += 1U)
				{
					SteamUGCDetails_t steamUGCDetails_t;
					if (SteamUGC.GetQueryUGCResult(param.m_handle, num, ref steamUGCDetails_t))
					{
						array[(int)((UIntPtr)num)].Title = steamUGCDetails_t.m_rgchTitle;
						array[(int)((UIntPtr)num)].PublishedFileId = steamUGCDetails_t.m_nPublishedFileId.m_PublishedFileId;
						array[(int)((UIntPtr)num)].Type = steamUGCDetails_t.m_rgchTags;
						array[(int)((UIntPtr)num)].Description = steamUGCDetails_t.m_rgchDescription;
						array[(int)((UIntPtr)num)].FolderPath = this.GetPathLocally(steamUGCDetails_t.m_nPublishedFileId.m_PublishedFileId);
					}
					string empty = string.Empty;
					if (SteamUGC.GetQueryUGCMetadata(param.m_handle, num, ref empty, 200U))
					{
						array[(int)((UIntPtr)num)].Metadata = empty;
					}
				}
				if (this.OnWorkshopItemListReceived != null)
				{
					this.OnWorkshopItemListReceived(array);
				}
			}
			SteamUGC.ReleaseQueryUGCRequest(param.m_handle);
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x00035344 File Offset: 0x00033544
		private void OnCreateItemReceived(CreateItemResult_t param, bool bIOFailure)
		{
			if (bIOFailure)
			{
				Debug.Log("failed to create item.");
				return;
			}
			if (param.m_eResult != 1)
			{
				Debug.Log("failed to create item:" + param.m_eResult);
				return;
			}
			if (param.m_bUserNeedsToAcceptWorkshopLegalAgreement)
			{
				SteamFriends.ActivateGameOverlayToWebPage("steam://url/CommunityFilePage/" + param.m_nPublishedFileId.m_PublishedFileId.ToString());
			}
			this.RequestWorkshopItemList();
			Debug.Log("Item created with sucess!:" + param.m_nPublishedFileId.m_PublishedFileId);
		}

		// Token: 0x060008B7 RID: 2231 RVA: 0x00008056 File Offset: 0x00006256
		private void OnSubscribePublishedFile(RemoteStorageSubscribePublishedFileResult_t param, bool bIOFailure)
		{
			if (bIOFailure)
			{
				Debug.Log("failed to create item.");
				return;
			}
			if (param.m_eResult != 1)
			{
				Debug.Log("failed to create item:" + param.m_eResult);
				return;
			}
		}

		// Token: 0x060008B8 RID: 2232 RVA: 0x000353E4 File Offset: 0x000335E4
		internal void RequestCreateItem()
		{
			SteamAPICall_t steamAPICall_t = SteamUGC.CreateItem(SteamUtils.GetAppID(), 0);
			SteamCallbacks.CreateItemResult_t.RegisterCallResult(new Action<CreateItemResult_t, bool>(this.OnCreateItemReceived), steamAPICall_t);
		}

		// Token: 0x060008B9 RID: 2233 RVA: 0x00035410 File Offset: 0x00033610
		internal void RequestUpdateItem(WorkshopItem workshopItem)
		{
			string[] files = Directory.GetFiles(workshopItem.FolderPath, "*.mapsettings");
			if (files.Length <= 0)
			{
				return;
			}
			GameMapConfig gameMapConfig = ConversionUtil.ReadUnityJson<GameMapConfig>(File.ReadAllText(files.FirstOrDefault<string>()));
			if (gameMapConfig == null)
			{
				return;
			}
			UIManager.Instance.ChangeState("SETTINGS_WORKSHOP_UPLOAD");
			this.SetPathLocally(workshopItem.PublishedFileId, workshopItem.FolderPath);
			UGCUpdateHandle_t ugcupdateHandle_t = SteamUGC.StartItemUpdate(SteamUtils.GetAppID(), new PublishedFileId_t(workshopItem.PublishedFileId));
			SteamUGC.SetItemTitle(ugcupdateHandle_t, workshopItem.Title);
			SteamUGC.SetItemDescription(ugcupdateHandle_t, workshopItem.Description);
			SteamUGC.SetItemMetadata(ugcupdateHandle_t, workshopItem.Metadata);
			SteamUGC.SetItemVisibility(ugcupdateHandle_t, 0);
			SteamUGC.SetItemTags(ugcupdateHandle_t, new List<string> { workshopItem.Type });
			SteamUGC.SetItemPreview(ugcupdateHandle_t, workshopItem.FolderPath + gameMapConfig.MapName + "_512.jpg");
			SteamUGC.SetItemContent(ugcupdateHandle_t, workshopItem.FolderPath);
			SteamAPICall_t steamAPICall_t = SteamUGC.SubmitItemUpdate(ugcupdateHandle_t, "Ballistic Ovekill Client - Map Update");
			SteamCallbacks.SubmitItemUpdateResult_t.RegisterCallResult(new Action<SubmitItemUpdateResult_t, bool>(this.OnSubmitItemUpdateCompleted), steamAPICall_t);
			this._coroutinePendingMaps = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.UploadMapProgress(ugcupdateHandle_t));
			this._currentUpdatingItem = workshopItem;
		}

		// Token: 0x060008BA RID: 2234 RVA: 0x00008092 File Offset: 0x00006292
		private void OnPopupUploadingCallback(int result)
		{
			if (result == 1 && this._coroutinePendingMaps != null)
			{
				ServiceProvider.GetService<PopupService>().Hide(EPopupType.MAPS_UPLOADING);
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._coroutinePendingMaps);
				this._coroutinePendingMaps = null;
			}
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x00035544 File Offset: 0x00033744
		private IEnumerator UploadMapProgress(UGCUpdateHandle_t update)
		{
			ulong punBytesProcessed;
			ulong punBytesTotal;
			EItemUpdateStatus status = SteamUGC.GetItemUpdateProgress(update, ref punBytesProcessed, ref punBytesTotal);
			do
			{
				status = SteamUGC.GetItemUpdateProgress(update, ref punBytesProcessed, ref punBytesTotal);
				float progression = (float)(punBytesProcessed / punBytesTotal);
				if (punBytesTotal > 0UL)
				{
					ServiceProvider.GetService<PopupService>().Show(EPopupType.MAPS_UPLOADING, null, new Action<int>(this.OnPopupUploadingCallback), null, progression);
				}
				yield return this._wait;
			}
			while (status != null);
			this._coroutinePendingMaps = null;
			yield break;
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x00035568 File Offset: 0x00033768
		internal bool ValidateMap(WorkshopItem _currentItem, RawImage mapIcon128 = null, RawImage mapIcon512 = null, RawImage mapIconHigh = null)
		{
			if (string.IsNullOrEmpty(_currentItem.Title))
			{
				Debug.LogWarning("Title is Empty! Add  any title to workshop item.");
				return false;
			}
			if (!_currentItem.FolderPath.EndsWith(Path.DirectorySeparatorChar.ToString()))
			{
				Debug.LogWarning("Path incomplete! Add '" + Path.DirectorySeparatorChar + "' to the end.");
				return false;
			}
			if (!Directory.Exists(_currentItem.FolderPath))
			{
				Debug.LogWarning("Folder doesn't exist!");
				return false;
			}
			string[] files = Directory.GetFiles(_currentItem.FolderPath, "*.mapsettings");
			if (files.Length <= 0)
			{
				Debug.LogWarning("Settings file doesn't exist!");
				return false;
			}
			GameMapConfig gameMapConfig = ConversionUtil.ReadUnityJson<GameMapConfig>(File.ReadAllText(files.FirstOrDefault<string>()));
			if (gameMapConfig == null)
			{
				Debug.LogWarning("Config could not be converted to GameMapConfig. Please check your settings file:" + files.FirstOrDefault<string>());
				return false;
			}
			if (string.IsNullOrEmpty(gameMapConfig.MapName))
			{
				Debug.LogWarning("Config MapName is null or empty. Please check your settings file:" + files.FirstOrDefault<string>());
				return false;
			}
			if (string.IsNullOrEmpty(gameMapConfig.MapNameLocalizationDefault))
			{
				Debug.Log("Config MapNameLocalizationDefault is null or empty. Please check your settings file:" + files.FirstOrDefault<string>());
				return false;
			}
			if (!gameMapConfig.GameModes.Contains("basic_tdm"))
			{
				Debug.LogWarning("Config Doesn't support basic_tdm gamemode configuration. Please check your settings file:" + files.FirstOrDefault<string>());
				return false;
			}
			if (!gameMapConfig.GameModes.Contains("basic_ffa"))
			{
				Debug.LogWarning("Config Doesn't support basic_tdm gamemode configuration. Please check your settings file:" + files.FirstOrDefault<string>());
				return false;
			}
			string text = _currentItem.FolderPath + "Win/" + gameMapConfig.MapName + ".mapbundle";
			string text2 = _currentItem.FolderPath + "Linux/" + gameMapConfig.MapName + ".mapbundle";
			string text3 = _currentItem.FolderPath + "OSX/" + gameMapConfig.MapName + ".mapbundle";
			if (!File.Exists(text))
			{
				Debug.LogWarning("Mapbundle of Windows is Empty. Please check your folder files:" + text);
				return false;
			}
			if (!File.Exists(text2))
			{
				Debug.LogWarning("Mapbundle of Linux is Empty. Please check your folder files:" + text2);
				return false;
			}
			if (!File.Exists(text3))
			{
				Debug.LogWarning("Mapbundle of MacOSX is Empty. Please check your folder files:" + text3);
				return false;
			}
			string text4 = _currentItem.FolderPath + gameMapConfig.MapName + "_128.jpg";
			string text5 = _currentItem.FolderPath + gameMapConfig.MapName + "_512.jpg";
			string text6 = _currentItem.FolderPath + gameMapConfig.MapName + "_high.jpg";
			if (!this.TryToGetImage(text4, 128, 64, ref this.img_128))
			{
				Debug.LogWarning(text4 + " doesnt exist. Please check your folder files.");
				return false;
			}
			if (!this.TryToGetImage(text5, 512, 256, ref this.img_512))
			{
				Debug.LogWarning(text5 + " doesnt exist. Please check your folder files.");
				return false;
			}
			if (!this.TryToGetImage(text6, 2048, 1024, ref this.img_2048))
			{
				Debug.LogWarning(text6 + " doesnt exist. Please check your folder files.");
				return false;
			}
			if (mapIcon128 && mapIcon512 && mapIconHigh)
			{
				mapIcon128.texture = this.img_128;
				mapIcon512.texture = this.img_512;
				mapIconHigh.texture = this.img_2048;
			}
			return true;
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x000358C4 File Offset: 0x00033AC4
		private bool TryToGetImage(string path_to_image, int width, int height, ref Texture2D image)
		{
			if (image == null)
			{
				image = new Texture2D(1, 1, 12, false);
			}
			if (!File.Exists(path_to_image))
			{
				Debug.LogWarning(string.Concat(new object[] { path_to_image, " has[", image.width, "x", image.height, "] and this doenst match required size[", width, "x", height, "]" }));
				return false;
			}
			byte[] array = File.ReadAllBytes(path_to_image);
			ImageConversion.LoadImage(image, array, false);
			if (image.width != width || image.height != height)
			{
				Debug.LogWarning(string.Concat(new object[] { path_to_image, " has[", image.width, "x", image.height, "] and this doenst match required size[", width, "x", height, "]" }));
				return false;
			}
			return true;
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x00035228 File Offset: 0x00033428
		private void OnUGCQueryDownloadContentCompleted(SteamUGCQueryCompleted_t param, bool bIOFailure)
		{
			if (param.m_eResult == 1)
			{
				WorkshopItem[] array = new WorkshopItem[param.m_unNumResultsReturned];
				for (uint num = 0U; num < param.m_unNumResultsReturned; num += 1U)
				{
					SteamUGCDetails_t steamUGCDetails_t;
					if (SteamUGC.GetQueryUGCResult(param.m_handle, num, ref steamUGCDetails_t))
					{
						array[(int)((UIntPtr)num)].Title = steamUGCDetails_t.m_rgchTitle;
						array[(int)((UIntPtr)num)].PublishedFileId = steamUGCDetails_t.m_nPublishedFileId.m_PublishedFileId;
						array[(int)((UIntPtr)num)].Type = steamUGCDetails_t.m_rgchTags;
						array[(int)((UIntPtr)num)].Description = steamUGCDetails_t.m_rgchDescription;
						array[(int)((UIntPtr)num)].FolderPath = this.GetPathLocally(steamUGCDetails_t.m_nPublishedFileId.m_PublishedFileId);
					}
					string empty = string.Empty;
					if (SteamUGC.GetQueryUGCMetadata(param.m_handle, num, ref empty, 200U))
					{
						array[(int)((UIntPtr)num)].Metadata = empty;
					}
				}
				if (this.OnWorkshopItemListReceived != null)
				{
					this.OnWorkshopItemListReceived(array);
				}
			}
			SteamUGC.ReleaseQueryUGCRequest(param.m_handle);
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x000080C9 File Offset: 0x000062C9
		private string GetPathLocally(ulong publisherId)
		{
			return PlayerPrefs.GetString("w" + publisherId, Application.streamingAssetsPath + "/MAP_FOLDER_HERE/");
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x000080EF File Offset: 0x000062EF
		private void SetPathLocally(ulong publisherId, string path)
		{
			PlayerPrefs.SetString("w" + publisherId, path);
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x00035A0C File Offset: 0x00033C0C
		internal void VerifyHost(HostItem host, EClientMode clientMode, Action<HostItem, EClientMode> JoinVerified)
		{
			this._host = host;
			this._clientMode = clientMode;
			this._pendingMaps.Clear();
			this._joinVerified = JoinVerified;
			foreach (ulong num in host.GameMaps)
			{
				if (!ServiceProvider.GetService<GameMapModeConfigService>().HasGameMapConfig(num))
				{
					if (this.IsDefaultMap(num))
					{
						Debug.LogError("Default Map[" + num + "] is missing on game folder. Please verify your installation.");
						return;
					}
					this._pendingMaps.Add(num);
				}
				else if (!this.IsDefaultMap(num) && this.IsSet(SteamUGC.GetItemState(new PublishedFileId_t(num)), 8))
				{
					this._pendingMaps.Add(num);
				}
			}
			if (this._pendingMaps.Count <= 0)
			{
				JoinVerified(host, clientMode);
				return;
			}
			ServiceProvider.GetService<PopupService>().Show(EPopupType.MAPS_IS_MISSING, this._pendingMaps.Count.ToString(), new Action<int>(this.OnPopupDownloadCallback), null, 0f);
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x00008107 File Offset: 0x00006307
		private void OnPopupDownloadCallback(int result)
		{
			if (result == 2)
			{
				this._coroutinePendingMaps = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.DownloadPendingMaps(this._host, this._clientMode, this._pendingMaps, this._joinVerified));
			}
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x00035B20 File Offset: 0x00033D20
		private IEnumerator DownloadPendingMaps(HostItem host, EClientMode clientMode, List<ulong> pendingMaps, Action<HostItem, EClientMode> JoinVerified)
		{
			while (pendingMaps.Count > 0)
			{
				PublishedFileId_t pendingMap = new PublishedFileId_t(pendingMaps.Last<ulong>());
				uint state = SteamUGC.GetItemState(pendingMap);
				if (this.IsSet(state, 16))
				{
					ulong num = 0UL;
					ulong num2 = 0UL;
					if (SteamUGC.GetItemDownloadInfo(pendingMap, ref num, ref num2))
					{
						float num3 = (float)(num / num2);
						ServiceProvider.GetService<PopupService>().Show(EPopupType.MAPS_DOWNLOADING, pendingMaps.Count.ToString(), new Action<int>(this.OnPopupDownloadingCallback), null, num3);
					}
				}
				else if (this.IsSet(state, 32))
				{
					if (!SteamUGC.DownloadItem(pendingMap, true))
					{
						Debug.Log("Map[" + pendingMaps + "] failed to start download it with High Priority.");
						ServiceProvider.GetService<PopupService>().Hide(EPopupType.MAPS_DOWNLOADING);
						yield break;
					}
				}
				else if (!this.IsSet(state, 1))
				{
					SteamAPICall_t steamAPICall_t = SteamUGC.SubscribeItem(pendingMap);
					SteamCallbacks.RemoteStorageSubscribePublishedFileResult_t.RegisterCallResult(new Action<RemoteStorageSubscribePublishedFileResult_t, bool>(this.OnSubscribePublishedFile), steamAPICall_t);
				}
				else if (this.IsSet(state, 8))
				{
					Debug.Log("Map[" + pendingMaps + "] is need to be updated.");
					if (!SteamUGC.DownloadItem(pendingMap, true))
					{
						Debug.Log("Map[" + pendingMaps + "] failed to start download it with High Priority.");
						ServiceProvider.GetService<PopupService>().Hide(EPopupType.MAPS_DOWNLOADING);
						yield break;
					}
					ServiceProvider.GetService<PopupService>().Show(EPopupType.MAPS_DOWNLOADING, pendingMaps.Count.ToString(), new Action<int>(this.OnPopupDownloadingCallback), null, 0f);
				}
				else if (!this.IsSet(state, 4))
				{
					Debug.Log("Map[" + pendingMaps + "] must be downloaded.");
					if (!SteamUGC.DownloadItem(pendingMap, true))
					{
						Debug.Log("Map[" + pendingMaps + "] failed to start download it with High Priority.");
						ServiceProvider.GetService<PopupService>().Hide(EPopupType.MAPS_DOWNLOADING);
						yield break;
					}
					ServiceProvider.GetService<PopupService>().Show(EPopupType.MAPS_DOWNLOADING, pendingMaps.Count.ToString(), new Action<int>(this.OnPopupDownloadingCallback), null, 0f);
				}
				else
				{
					pendingMaps.Remove(pendingMaps.Last<ulong>());
				}
				yield return this._wait;
			}
			ServiceProvider.GetService<PopupService>().Hide(EPopupType.MAPS_DOWNLOADING);
			ServiceProvider.GetService<GameMapModeConfigService>().ReloadMapConfigs();
			this.VerifyHost(host, clientMode, JoinVerified);
			this._coroutinePendingMaps = null;
			yield break;
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x0000813E File Offset: 0x0000633E
		private void OnPopupDownloadingCallback(int result)
		{
			if (result == 1 && this._coroutinePendingMaps != null)
			{
				ServiceProvider.GetService<PopupService>().Hide(EPopupType.MAPS_DOWNLOADING);
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._coroutinePendingMaps);
				this._coroutinePendingMaps = null;
			}
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x00008175 File Offset: 0x00006375
		private bool IsDefaultMap(ulong mapId)
		{
			return mapId <= 20UL;
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x00008180 File Offset: 0x00006380
		private bool IsSet(uint value, EItemState state)
		{
			return (value & state) != 0;
		}

		// Token: 0x04000B6B RID: 2923
		private const int _defaultMapMaxRange = 20;

		// Token: 0x04000B6C RID: 2924
		private const string ImageExtension128 = "_128.jpg";

		// Token: 0x04000B6D RID: 2925
		private const string ImageExtension512 = "_512.jpg";

		// Token: 0x04000B6E RID: 2926
		private const string ImageExtensionHigh = "_high.jpg";

		// Token: 0x04000B6F RID: 2927
		internal Action<WorkshopItem[]> OnWorkshopItemListReceived;

		// Token: 0x04000B70 RID: 2928
		private WaitForSecondsRealtime _wait = new WaitForSecondsRealtime(0.75f);

		// Token: 0x04000B71 RID: 2929
		private List<ulong> _pendingMaps = new List<ulong>();

		// Token: 0x04000B72 RID: 2930
		private HostItem _host;

		// Token: 0x04000B73 RID: 2931
		private EClientMode _clientMode;

		// Token: 0x04000B74 RID: 2932
		private Action<HostItem, EClientMode> _joinVerified;

		// Token: 0x04000B75 RID: 2933
		private Coroutine _coroutinePendingMaps;

		// Token: 0x04000B76 RID: 2934
		private Texture2D img_128;

		// Token: 0x04000B77 RID: 2935
		private Texture2D img_512;

		// Token: 0x04000B78 RID: 2936
		private Texture2D img_2048;

		// Token: 0x04000B79 RID: 2937
		private WorkshopItem _currentUpdatingItem;
	}
}
