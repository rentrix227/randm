﻿using System;
using Aquiris.Ballistic.Utils;
using Steamworks;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x02000500 RID: 1280
	internal class LeaderboardRequestStruct : LeaderboardFindStruct
	{
		// Token: 0x06001B2B RID: 6955 RVA: 0x00013DF1 File Offset: 0x00011FF1
		internal LeaderboardRequestStruct(ELeaderboardDataRequest method, int currentMonth, int currentWeek, Action<Leaderboards, LeaderboardScoresDownloaded_t, bool> OnDownloadCompleted)
			: base(currentMonth, currentWeek)
		{
			this._method = method;
			this._OnDownloadCompleted = OnDownloadCompleted;
			this._minPlayers = 1;
		}

		// Token: 0x06001B2C RID: 6956 RVA: 0x00013E11 File Offset: 0x00012011
		private void OnDownloadHandler(LeaderboardScoresDownloaded_t param, bool bIOFailure)
		{
			this._OnDownloadCompleted(this._leaderboard, param, bIOFailure);
		}

		// Token: 0x06001B2D RID: 6957 RVA: 0x00013E26 File Offset: 0x00012026
		internal void SetRange(int minPlayers, int maxPlayers)
		{
			this._minPlayers = minPlayers;
			this._maxPlayers = maxPlayers;
		}

		// Token: 0x06001B2E RID: 6958 RVA: 0x0008C76C File Offset: 0x0008A96C
		protected override void DisposeFind(LeaderboardFindResult_t evt)
		{
			base.DisposeFind(evt);
			SteamAPICall_t steamAPICall_t = SteamUserStats.DownloadLeaderboardEntries(evt.m_hSteamLeaderboard, this._method, this._minPlayers, this._maxPlayers);
			SteamCallbacks.LeaderboardScoresDownloaded_t.RegisterCallResult(new Action<LeaderboardScoresDownloaded_t, bool>(this.OnDownloadHandler), steamAPICall_t);
		}

		// Token: 0x06001B2F RID: 6959 RVA: 0x0008C7B0 File Offset: 0x0008A9B0
		protected override void DisposeFailure()
		{
			base.DisposeFailure();
			Action<Leaderboards, LeaderboardScoresDownloaded_t, bool> onDownloadCompleted = this._OnDownloadCompleted;
			Leaderboards leaderboard = this._leaderboard;
			LeaderboardScoresDownloaded_t leaderboardScoresDownloaded_t = default(LeaderboardScoresDownloaded_t);
			leaderboardScoresDownloaded_t.m_cEntryCount = 0;
			onDownloadCompleted(leaderboard, leaderboardScoresDownloaded_t, false);
		}

		// Token: 0x04001D12 RID: 7442
		protected int _minPlayers;

		// Token: 0x04001D13 RID: 7443
		protected int _maxPlayers;

		// Token: 0x04001D14 RID: 7444
		private ELeaderboardDataRequest _method;

		// Token: 0x04001D15 RID: 7445
		protected Action<Leaderboards, LeaderboardScoresDownloaded_t, bool> _OnDownloadCompleted;
	}
}
