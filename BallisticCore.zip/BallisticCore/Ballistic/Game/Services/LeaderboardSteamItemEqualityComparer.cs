﻿using System;
using System.Collections.Generic;

namespace Aquiris.Ballistic.Game.Services
{
	// Token: 0x020004F8 RID: 1272
	internal class LeaderboardSteamItemEqualityComparer : IEqualityComparer<SteamItem>
	{
		// Token: 0x06001B0B RID: 6923 RVA: 0x00013CF1 File Offset: 0x00011EF1
		public bool Equals(SteamItem x, SteamItem y)
		{
			return x.IdentityId == y.IdentityId;
		}

		// Token: 0x06001B0C RID: 6924 RVA: 0x00013D01 File Offset: 0x00011F01
		public int GetHashCode(SteamItem item)
		{
			return item.IdentityId.GetHashCode();
		}
	}
}
