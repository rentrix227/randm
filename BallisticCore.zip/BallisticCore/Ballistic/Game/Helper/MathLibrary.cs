﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000AD RID: 173
	internal static class MathLibrary
	{
		// Token: 0x060002CE RID: 718 RVA: 0x00004317 File Offset: 0x00002517
		internal static float IncrementTowards(float current, float target, float delta)
		{
			if (current < target)
			{
				current += delta;
				if (current > target)
				{
					current = target;
				}
			}
			else
			{
				current -= delta;
				if (current < target)
				{
					current = target;
				}
			}
			return current;
		}
	}
}
