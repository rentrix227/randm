﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A2 RID: 162
	public static class InventoryHelper
	{
		// Token: 0x0400052D RID: 1325
		public const int ScrapBaseGenerator = 500;

		// Token: 0x0400052E RID: 1326
		public const int ScrapsId = 900;

		// Token: 0x0400052F RID: 1327
		public static ERarity[] Rarities = new ERarity[]
		{
			ERarity.COMMON,
			ERarity.ADVANCED,
			ERarity.SPECIAL,
			ERarity.ELITE,
			ERarity.LEGENDARY,
			ERarity.LEGACY,
			ERarity.RANKED
		};

		// Token: 0x04000530 RID: 1328
		public static int[] ScrapBundleIds = new int[]
		{
			941, 942, 943, 944, 945, 946, 947, 948, 949, 950,
			951, 952, 953, 954, 955, 956, 957, 958, 959, 960,
			961, 962, 963, 964, 965, 966, 967, 968, 969, 970,
			971, 972, 973, 974, 975, 976, 977, 978, 979, 980
		};

		// Token: 0x04000531 RID: 1329
		public static int[] ScrapGenerators = new int[] { 901, 902, 903, 904, 905, 906 };

		// Token: 0x04000532 RID: 1330
		public static int[] ScrapBaseDrop = new int[] { 1, 3, 5, 10, 15, 1, 5 };

		// Token: 0x04000533 RID: 1331
		public static int[] ScrapVarDrop = new int[] { 0, 0, 1, 5, 15, 0, 0 };

		// Token: 0x04000534 RID: 1332
		public const int GoldScrapBaseGenerator = 510;

		// Token: 0x04000535 RID: 1333
		public const int GoldenScrapsId = 910;

		// Token: 0x04000536 RID: 1334
		public static int[] GoldenScrapGenerators = new int[] { 911 };
	}
}
