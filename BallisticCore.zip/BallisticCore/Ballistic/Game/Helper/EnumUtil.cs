﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x0200009F RID: 159
	public static class EnumUtil
	{
		// Token: 0x06000291 RID: 657 RVA: 0x00004049 File Offset: 0x00002249
		public static IEnumerable<T> GetValues<T>()
		{
			return Enum.GetValues(typeof(T)).Cast<T>();
		}

		// Token: 0x06000292 RID: 658 RVA: 0x0000405F File Offset: 0x0000225F
		public static T ParseEnum<T>(string value)
		{
			return (T)((object)Enum.Parse(typeof(T), value, true));
		}
	}
}
