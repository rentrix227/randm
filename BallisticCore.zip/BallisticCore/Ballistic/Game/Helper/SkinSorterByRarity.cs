﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.UI;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000AA RID: 170
	internal class SkinSorterByRarity : IComparer<WeaponSkinData>
	{
		// Token: 0x060002B9 RID: 697 RVA: 0x0001BEF4 File Offset: 0x0001A0F4
		public int Compare(WeaponSkinData x, WeaponSkinData y)
		{
			ERarity rarity = x.WeaponSkin.Rarity;
			int num;
			switch (rarity)
			{
			case ERarity.COMMON:
				num = 0;
				break;
			case ERarity.ADVANCED:
				num = 1;
				break;
			case ERarity.SPECIAL:
				num = 2;
				break;
			case ERarity.ELITE:
				num = 3;
				break;
			case ERarity.LEGENDARY:
				num = 4;
				break;
			default:
				if (rarity != ERarity.LEGACY)
				{
					if (rarity != ERarity.NONE)
					{
						num = 7;
					}
					else
					{
						num = 6;
					}
				}
				else
				{
					num = 5;
				}
				break;
			}
			ERarity rarity2 = y.WeaponSkin.Rarity;
			int num2;
			switch (rarity2)
			{
			case ERarity.COMMON:
				num2 = 0;
				break;
			case ERarity.ADVANCED:
				num2 = 1;
				break;
			case ERarity.SPECIAL:
				num2 = 2;
				break;
			case ERarity.ELITE:
				num2 = 3;
				break;
			case ERarity.LEGENDARY:
				num2 = 4;
				break;
			default:
				if (rarity2 != ERarity.LEGACY)
				{
					if (rarity2 != ERarity.NONE)
					{
						num2 = 7;
					}
					else
					{
						num2 = 6;
					}
				}
				else
				{
					num2 = 5;
				}
				break;
			}
			return num.CompareTo(num2);
		}
	}
}
