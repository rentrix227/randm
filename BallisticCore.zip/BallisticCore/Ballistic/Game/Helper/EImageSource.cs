﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000B5 RID: 181
	public enum EImageSource
	{
		// Token: 0x04000567 RID: 1383
		RESOURCES,
		// Token: 0x04000568 RID: 1384
		METADATA,
		// Token: 0x04000569 RID: 1385
		STREAMINGASSETS
	}
}
