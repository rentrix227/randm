﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000C1 RID: 193
	public enum UserUpdateType
	{
		// Token: 0x040005B1 RID: 1457
		UserJoinedRoom,
		// Token: 0x040005B2 RID: 1458
		UserLeftRoom,
		// Token: 0x040005B3 RID: 1459
		JoinedMfaTeam,
		// Token: 0x040005B4 RID: 1460
		JoinedSmokeTeam,
		// Token: 0x040005B5 RID: 1461
		BecomesJuggernaut
	}
}
