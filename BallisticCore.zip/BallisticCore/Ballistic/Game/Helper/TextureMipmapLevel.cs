﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000B1 RID: 177
	public enum TextureMipmapLevel
	{
		// Token: 0x0400055C RID: 1372
		MAXIMUM,
		// Token: 0x0400055D RID: 1373
		HALF,
		// Token: 0x0400055E RID: 1374
		QUARTER,
		// Token: 0x0400055F RID: 1375
		EIGHTH
	}
}
