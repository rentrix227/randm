﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.UI;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A7 RID: 167
	internal class LockboxSorterBySeason : IComparer<LockboxData>
	{
		// Token: 0x060002B3 RID: 691 RVA: 0x00004103 File Offset: 0x00002303
		public int Compare(LockboxData x, LockboxData y)
		{
			return x.Lockbox.Season.CompareTo(y.Lockbox.Season);
		}
	}
}
