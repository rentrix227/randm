﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.UI;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A6 RID: 166
	internal class LockboxSorterByClass : IComparer<LockboxData>
	{
		// Token: 0x060002B1 RID: 689 RVA: 0x000040DB File Offset: 0x000022DB
		public int Compare(LockboxData x, LockboxData y)
		{
			return x.Lockbox.HeroClass.CompareTo(y.Lockbox.HeroClass);
		}
	}
}
