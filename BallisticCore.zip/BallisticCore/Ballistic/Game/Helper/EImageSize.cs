﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000B4 RID: 180
	public enum EImageSize
	{
		// Token: 0x04000563 RID: 1379
		SMALL,
		// Token: 0x04000564 RID: 1380
		MEDIUM,
		// Token: 0x04000565 RID: 1381
		LARGE
	}
}
