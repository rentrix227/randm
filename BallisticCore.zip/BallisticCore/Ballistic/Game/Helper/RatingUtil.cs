﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000B3 RID: 179
	internal static class RatingUtil
	{
		// Token: 0x060002D1 RID: 721 RVA: 0x0001C2FC File Offset: 0x0001A4FC
		internal static EPlayerRank GetSkillRatingTier(int currentRating)
		{
			for (int i = 0; i < RatingUtil._skillRatingLimit.Length; i++)
			{
				if (currentRating >= RatingUtil._skillRatingLimit[i])
				{
					return RatingUtil._skillRatingEnum[i];
				}
			}
			return EPlayerRank.ASPIRANT;
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x0001C338 File Offset: 0x0001A538
		internal static int GetSkillRatingTierNumber(float currentRating)
		{
			for (int i = 0; i < RatingUtil._skillRatingLimit.Length; i++)
			{
				if (currentRating >= (float)RatingUtil._skillRatingLimit[i])
				{
					return i;
				}
			}
			return 15;
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x0001C370 File Offset: 0x0001A570
		internal static int GetSkillRatingLimiarNext(float currentRating)
		{
			int i = 0;
			while (i < RatingUtil._skillRatingLimit.Length)
			{
				if (currentRating >= (float)RatingUtil._skillRatingLimit[i])
				{
					if (i - 1 >= 0)
					{
						return RatingUtil._skillRatingLimit[i - 1];
					}
					return -1;
				}
				else
				{
					i++;
				}
			}
			return -1;
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x0001C3BC File Offset: 0x0001A5BC
		internal static int GetSkillRatingLimiarDrop(int currentRating)
		{
			for (int i = 0; i < RatingUtil._skillRatingLimit.Length; i++)
			{
				if (currentRating >= RatingUtil._skillRatingLimit[i])
				{
					return RatingUtil._skillRatingLimit[i];
				}
			}
			return -1;
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00004344 File Offset: 0x00002544
		internal static EPlayerRank GetSkillRatingTierByPosition(int position)
		{
			if (position >= 0 && position < RatingUtil._skillRatingEnum.Length)
			{
				return RatingUtil._skillRatingEnum[position];
			}
			return EPlayerRank.ASPIRANT;
		}

		// Token: 0x04000560 RID: 1376
		internal static int[] _skillRatingLimit = new int[]
		{
			700, 500, 300, 200, 100, 90, 80, 70, 60, 50,
			40, 30, 20, 10, 5, 0
		};

		// Token: 0x04000561 RID: 1377
		internal static EPlayerRank[] _skillRatingEnum = new EPlayerRank[]
		{
			EPlayerRank.LEGEND,
			EPlayerRank.OVERLORD,
			EPlayerRank.REAPER,
			EPlayerRank.DESTROYER,
			EPlayerRank.PUNISHER,
			EPlayerRank.DEMON,
			EPlayerRank.GHOST,
			EPlayerRank.ASSASSIN,
			EPlayerRank.HUNTER,
			EPlayerRank.MERCENARY,
			EPlayerRank.VETERAN,
			EPlayerRank.SURVIVOR,
			EPlayerRank.NOTEWORTHY,
			EPlayerRank.WANDERER,
			EPlayerRank.FUGITIVE,
			EPlayerRank.ASPIRANT
		};
	}
}
