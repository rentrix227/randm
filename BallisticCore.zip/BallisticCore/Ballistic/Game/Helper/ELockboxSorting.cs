﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A3 RID: 163
	internal enum ELockboxSorting
	{
		// Token: 0x04000538 RID: 1336
		NONE,
		// Token: 0x04000539 RID: 1337
		CLASS,
		// Token: 0x0400053A RID: 1338
		SEASON
	}
}
