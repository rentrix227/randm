﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000C0 RID: 192
	public static class TransformTools
	{
		// Token: 0x06000319 RID: 793 RVA: 0x0001D0F4 File Offset: 0x0001B2F4
		public static string GetPath(Component p_node, Component p_root = null)
		{
			string name = p_node.transform.name;
			if (p_node.transform.parent == p_root)
			{
				return name;
			}
			return TransformTools.GetPath(p_node.transform.parent, p_root) + "/" + name;
		}

		// Token: 0x0600031A RID: 794 RVA: 0x0000465A File Offset: 0x0000285A
		public static T GetSame<T>(Component p_root, Component p_originalRoot, T p_original) where T : Component
		{
			return p_root.transform.Find(TransformTools.GetPath(p_original, p_originalRoot)).GetComponent<T>();
		}

		// Token: 0x0600031B RID: 795 RVA: 0x00004678 File Offset: 0x00002878
		public static T GetSame<T>(GameObject p_root, GameObject p_originalRoot, T p_original) where T : Component
		{
			return p_root.transform.Find(TransformTools.GetPath(p_original, p_originalRoot.transform)).GetComponent<T>();
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0000469B File Offset: 0x0000289B
		public static GameObject GetSame(GameObject p_root, GameObject p_originalRoot, GameObject p_original)
		{
			return p_root.transform.Find(TransformTools.GetPath(p_original.transform, p_originalRoot.transform)).gameObject;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0001D144 File Offset: 0x0001B344
		public static T FindInParents<T>(Transform p_object) where T : Component
		{
			if (p_object == null)
			{
				return (T)((object)null);
			}
			T component = p_object.GetComponent<T>();
			if (component != null)
			{
				return component;
			}
			if (p_object.parent == null)
			{
				return (T)((object)null);
			}
			return TransformTools.FindInParents<T>(p_object.parent);
		}
	}
}
