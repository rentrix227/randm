﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A9 RID: 169
	internal class SkinSorterBySkinName : IComparer<WeaponSkinData>
	{
		// Token: 0x060002B6 RID: 694 RVA: 0x00004174 File Offset: 0x00002374
		public SkinSorterBySkinName()
		{
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x00004187 File Offset: 0x00002387
		public int Compare(WeaponSkinData x, WeaponSkinData y)
		{
			return string.Compare(this._localizationService.GetWeaponSkinName(x.WeaponSkin.WeaponSkinName, ELocalizedTextCase.NONE), this._localizationService.GetWeaponSkinName(y.WeaponSkin.WeaponSkinName, ELocalizedTextCase.NONE), StringComparison.Ordinal);
		}

		// Token: 0x04000544 RID: 1348
		private readonly LocalizationService _localizationService;
	}
}
