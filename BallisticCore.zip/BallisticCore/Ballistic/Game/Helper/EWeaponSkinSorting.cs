﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A4 RID: 164
	internal enum EWeaponSkinSorting
	{
		// Token: 0x0400053C RID: 1340
		NONE,
		// Token: 0x0400053D RID: 1341
		NAME,
		// Token: 0x0400053E RID: 1342
		SKIN,
		// Token: 0x0400053F RID: 1343
		RARITY
	}
}
