﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Network.Transport.Gameplay.Loadout;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.HeroSkinModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.Services.ItemModel.GameItemModel.GameSkillModel;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000AC RID: 172
	public static class LoadoutUtil
	{
		// Token: 0x060002BC RID: 700 RVA: 0x000041FA File Offset: 0x000023FA
		public static HeroSkin GetSkinBody(LoadoutInfo info)
		{
			return ServiceProvider.GetService<GameItemService>().GetItemById<HeroSkin>(info.LoadoutItemMap[5]);
		}

		// Token: 0x060002BD RID: 701 RVA: 0x0001BFF0 File Offset: 0x0001A1F0
		public static Accessory[] GetAccessories(LoadoutInfo info)
		{
			return new Accessory[]
			{
				ServiceProvider.GetService<GameItemService>().GetItemById<Accessory>(info.LoadoutItemMap[11]),
				ServiceProvider.GetService<GameItemService>().GetItemById<Accessory>(info.LoadoutItemMap[13]),
				ServiceProvider.GetService<GameItemService>().GetItemById<Accessory>(info.LoadoutItemMap[14]),
				ServiceProvider.GetService<GameItemService>().GetItemById<Accessory>(info.LoadoutItemMap[15]),
				ServiceProvider.GetService<GameItemService>().GetItemById<Accessory>(info.LoadoutItemMap[12])
			};
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00004212 File Offset: 0x00002412
		public static string GetSkinArms(LoadoutInfo info)
		{
			return LoadoutUtil.GetSkinBody(info).ItemModel + "_arms";
		}

		// Token: 0x060002BF RID: 703 RVA: 0x00004229 File Offset: 0x00002429
		public static WeaponV4 GetPrimaryWeapon(LoadoutInfo info)
		{
			return ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(info.LoadoutItemMap[1]);
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x00004241 File Offset: 0x00002441
		public static WeaponV4 GetSecondaryWeapon(LoadoutInfo info)
		{
			return ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(info.LoadoutItemMap[2]);
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00004259 File Offset: 0x00002459
		public static WeaponV4 GetMeeleWeapon(LoadoutInfo info)
		{
			return ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(info.LoadoutItemMap[3]);
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x00004271 File Offset: 0x00002471
		public static WeaponV4 GetExplosive(LoadoutInfo info)
		{
			return ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(info.LoadoutItemMap[4]);
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x00004289 File Offset: 0x00002489
		public static WeaponSkin GetPrimaryWeaponSkin(LoadoutInfo info)
		{
			return new WeaponSkin((EWeaponSkinName)info.LoadoutItemMap[6]);
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x0000429C File Offset: 0x0000249C
		public static WeaponSkin GetSecondaryWeaponSkin(LoadoutInfo info)
		{
			return new WeaponSkin((EWeaponSkinName)info.LoadoutItemMap[7]);
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x000042AF File Offset: 0x000024AF
		public static WeaponSkin GetMeeleWeaponSkin(LoadoutInfo info)
		{
			return new WeaponSkin((EWeaponSkinName)info.LoadoutItemMap[8]);
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x000042C2 File Offset: 0x000024C2
		public static WeaponSkin GetExplosiveSkin(LoadoutInfo info)
		{
			return new WeaponSkin((EWeaponSkinName)info.LoadoutItemMap[9]);
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x000042D6 File Offset: 0x000024D6
		public static bool HasSkill(LoadoutInfo info, EHeroSkillV2 skill)
		{
			return info.SkillList.Contains((int)skill);
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x0001C088 File Offset: 0x0001A288
		public static HashSet<EHeroSkillV2> Skills(LoadoutInfo info)
		{
			HashSet<EHeroSkillV2> hashSet = new HashSet<EHeroSkillV2>();
			foreach (int num in info.SkillList)
			{
				hashSet.Add((EHeroSkillV2)num);
			}
			return hashSet;
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x0001C0EC File Offset: 0x0001A2EC
		public static List<EHeroSkillV2> GetSkillsSelected(LoadoutInfo info)
		{
			HeroV3 itemById = ServiceProvider.GetService<GameItemService>().GetItemById<HeroV3>(info.Hero);
			return (from skillData in ServiceProvider.GetService<SkillService>().GetSelectedSkillDataList(itemById.HeroSkillTree.SkillNodes, info.SkillList.ConvertAll<EHeroSkillV2>(new Converter<int, EHeroSkillV2>(LoadoutUtil.ConvertSkill)), HeroSkillNodeV3.SkillNature.Selectable)
				select skillData.Skill).ToList<EHeroSkillV2>();
		}

		// Token: 0x060002CA RID: 714 RVA: 0x00003DD8 File Offset: 0x00001FD8
		private static EHeroSkillV2 ConvertSkill(int skill)
		{
			return (EHeroSkillV2)skill;
		}

		// Token: 0x060002CB RID: 715 RVA: 0x000042E4 File Offset: 0x000024E4
		public static EHeroClass GetHeroClass(LoadoutInfo info)
		{
			if (info != null && info.Hero > 0)
			{
				return ServiceProvider.GetService<GameItemService>().GetItemById<HeroV3>(info.Hero).UniqueIdentifier;
			}
			return EHeroClass.NONE;
		}

		// Token: 0x060002CC RID: 716 RVA: 0x0001C170 File Offset: 0x0001A370
		public static EWeaponSkinName GetSkinForWeapon(LoadoutInfo info, int weaponId)
		{
			if (weaponId == info.LoadoutItemMap[1])
			{
				return (EWeaponSkinName)info.LoadoutItemMap[6];
			}
			if (weaponId == info.LoadoutItemMap[2])
			{
				return (EWeaponSkinName)info.LoadoutItemMap[7];
			}
			if (weaponId == info.LoadoutItemMap[3])
			{
				return (EWeaponSkinName)info.LoadoutItemMap[8];
			}
			if (weaponId == info.LoadoutItemMap[4])
			{
				return (EWeaponSkinName)info.LoadoutItemMap[9];
			}
			return EWeaponSkinName.DEFAULT;
		}
	}
}
