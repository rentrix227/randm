﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000AE RID: 174
	public enum OptionPresetLevel
	{
		// Token: 0x04000549 RID: 1353
		Low,
		// Token: 0x0400054A RID: 1354
		Medium,
		// Token: 0x0400054B RID: 1355
		High
	}
}
