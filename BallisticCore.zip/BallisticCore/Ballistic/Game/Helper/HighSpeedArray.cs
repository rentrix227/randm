﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A1 RID: 161
	internal class HighSpeedArray<T>
	{
		// Token: 0x06000293 RID: 659 RVA: 0x00004077 File Offset: 0x00002277
		internal HighSpeedArray(int capacity)
		{
			this.SetCapacity(capacity);
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000294 RID: 660 RVA: 0x00004086 File Offset: 0x00002286
		internal T[] Array
		{
			get
			{
				return this._array;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000295 RID: 661 RVA: 0x0000408E File Offset: 0x0000228E
		internal int Length
		{
			get
			{
				return this._currentIndex;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000296 RID: 662 RVA: 0x00004096 File Offset: 0x00002296
		internal int Capacity
		{
			get
			{
				return this._array.Length;
			}
		}

		// Token: 0x1700004C RID: 76
		internal T this[int key]
		{
			get
			{
				return this._array[key];
			}
			set
			{
				this._array[key] = value;
			}
		}

		// Token: 0x06000299 RID: 665 RVA: 0x000040BD File Offset: 0x000022BD
		internal void SetCapacity(int capacity)
		{
			this._array = new T[capacity];
			this._currentIndex = 0;
		}

		// Token: 0x0600029A RID: 666 RVA: 0x0001B8CC File Offset: 0x00019ACC
		internal void Add(T obj)
		{
			if (this._currentIndex >= this.Capacity)
			{
				Debug.LogWarning("Error: HighSpeedArray reached limit for " + typeof(T).ToString());
				return;
			}
			this._array[this._currentIndex] = obj;
			this._currentIndex++;
		}

		// Token: 0x0600029B RID: 667 RVA: 0x0001B92C File Offset: 0x00019B2C
		internal void AddRange(HighSpeedArray<T> range)
		{
			for (int i = 0; i < range.Length; i++)
			{
				this.Add(range[i]);
			}
		}

		// Token: 0x0600029C RID: 668 RVA: 0x0001B960 File Offset: 0x00019B60
		internal void AddRange(IEnumerable<T> list)
		{
			foreach (T t in list)
			{
				this.Add(t);
			}
		}

		// Token: 0x0600029D RID: 669 RVA: 0x0001B9B4 File Offset: 0x00019BB4
		internal int IndexOf(T entry)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (object.Equals(this._array[i], entry))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x0600029E RID: 670 RVA: 0x0001B9FC File Offset: 0x00019BFC
		internal int IndexOf(Predicate<T> predicate)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (predicate(this._array[i]))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x0600029F RID: 671 RVA: 0x0001BA3C File Offset: 0x00019C3C
		internal int IndexOf<T1>(Func<T, T1, bool> predicate, T1 param)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (predicate(this._array[i], param))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x0001BA7C File Offset: 0x00019C7C
		internal T Find(Predicate<T> predicate)
		{
			int num = this.IndexOf(predicate);
			if (num < 0)
			{
				return default(T);
			}
			return this[num];
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x0001BAAC File Offset: 0x00019CAC
		internal T Find<T1>(Func<T, T1, bool> predicate, T1 param)
		{
			int num = this.IndexOf<T1>(predicate, param);
			if (num < 0)
			{
				return default(T);
			}
			return this[num];
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x0001BADC File Offset: 0x00019CDC
		internal bool Exists(Predicate<T> predicate)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (predicate(this._array[i]))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x0001BB1C File Offset: 0x00019D1C
		internal bool Contains(T data)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (this._array[i].Equals(data))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x0001BB68 File Offset: 0x00019D68
		internal void RemoveAll(Func<T, bool> predicate)
		{
			int i = 0;
			while (i < this._currentIndex)
			{
				if (predicate(this._array[i]))
				{
					this.RemoveAt(i);
				}
				else
				{
					i++;
				}
			}
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x0001BBB0 File Offset: 0x00019DB0
		internal void Remove(Predicate<T> predicate)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (predicate(this._array[i]))
				{
					this.RemoveAt(i);
					return;
				}
			}
		}

		// Token: 0x060002A6 RID: 678 RVA: 0x0001BBF4 File Offset: 0x00019DF4
		internal void Remove<T1>(Func<T, T1, bool> predicate, T1 param)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (predicate(this._array[i], param))
				{
					this.RemoveAt(i);
					return;
				}
			}
		}

		// Token: 0x060002A7 RID: 679 RVA: 0x0001BC38 File Offset: 0x00019E38
		internal void Sort(IComparer<T> comparer)
		{
			for (int i = 0; i < this.Length; i++)
			{
				for (int j = i + 1; j < this.Length; j++)
				{
					if (comparer.Compare(this._array[i], this._array[j]) < 0)
					{
						T t = this._array[i];
						this._array[i] = this._array[j];
						this._array[j] = t;
					}
				}
			}
		}

		// Token: 0x060002A8 RID: 680 RVA: 0x000040D2 File Offset: 0x000022D2
		internal void Clear()
		{
			this._currentIndex = 0;
		}

		// Token: 0x060002A9 RID: 681 RVA: 0x0001BCD0 File Offset: 0x00019ED0
		internal void RemoveAt(int index)
		{
			if (index >= this._currentIndex)
			{
				return;
			}
			int num = index;
			while (num + 1 < this._currentIndex)
			{
				this._array[num] = this._array[num + 1];
				num++;
			}
			this._currentIndex--;
		}

		// Token: 0x060002AA RID: 682 RVA: 0x0001BD2C File Offset: 0x00019F2C
		internal void Remove(T entry)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (object.Equals(this._array[i], entry))
				{
					this.RemoveAt(i);
				}
			}
		}

		// Token: 0x060002AB RID: 683 RVA: 0x0001BADC File Offset: 0x00019CDC
		internal bool Any(Predicate<T> predicate)
		{
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (predicate(this._array[i]))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060002AC RID: 684 RVA: 0x0001BD78 File Offset: 0x00019F78
		internal void Revert()
		{
			for (int i = 0; i < this._currentIndex / 2; i++)
			{
				T t = this._array[i];
				this._array[i] = this._array[this._currentIndex - i - 1];
				this._array[this._currentIndex - i - 1] = t;
			}
		}

		// Token: 0x060002AD RID: 685 RVA: 0x0001BDE4 File Offset: 0x00019FE4
		internal int Sum(Func<T, int> function)
		{
			int num = 0;
			for (int i = 0; i < this._currentIndex; i++)
			{
				num += function(this._array[i]);
			}
			return num;
		}

		// Token: 0x060002AE RID: 686 RVA: 0x0001BE20 File Offset: 0x0001A020
		internal int Count(Predicate<T> predicate)
		{
			int num = 0;
			for (int i = 0; i < this._currentIndex; i++)
			{
				if (predicate(this._array[i]))
				{
					num++;
				}
			}
			return num;
		}

		// Token: 0x0400052B RID: 1323
		private int _currentIndex;

		// Token: 0x0400052C RID: 1324
		private T[] _array;
	}
}
