﻿using System;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000B2 RID: 178
	internal class RarityHelper
	{
		// Token: 0x060002D0 RID: 720 RVA: 0x0001C1FC File Offset: 0x0001A3FC
		internal static Color GetRarityColor(ERarity rarity)
		{
			switch (rarity)
			{
			case ERarity.COMMON:
				return new Color(0.654902f, 0.6509804f, 0.6431373f);
			case ERarity.ADVANCED:
				return new Color(0.435294122f, 0.65882355f, 0.8627451f);
			case ERarity.SPECIAL:
				return new Color(0.5764706f, 0.768627465f, 0.490196079f);
			case ERarity.ELITE:
				return new Color(0.5568628f, 0.4862745f, 0.7647059f);
			case ERarity.LEGENDARY:
				return new Color(0.9019608f, 0.5686275f, 0.219607845f);
			default:
				if (rarity == ERarity.LEGACY)
				{
					return new Color(0.243137255f, 0.2901961f, 0.498039216f);
				}
				if (rarity == ERarity.RANKED)
				{
					return new Color(0.7058824f, 0.6156863f, 0f);
				}
				if (rarity != ERarity.NONE)
				{
					return new Color(0.5019608f, 0.5019608f, 0.5019608f);
				}
				return new Color(0.5019608f, 0.5019608f, 0.5019608f);
			}
		}
	}
}
