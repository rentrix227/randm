﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000AB RID: 171
	internal class AccessorySorterByName : IComparer<Accessory>
	{
		// Token: 0x060002BA RID: 698 RVA: 0x000041BD File Offset: 0x000023BD
		public AccessorySorterByName()
		{
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
		}

		// Token: 0x060002BB RID: 699 RVA: 0x000041D0 File Offset: 0x000023D0
		public int Compare(Accessory x, Accessory y)
		{
			return string.Compare(this._localizationService.GetAccessoryName(x.ItemName), this._localizationService.GetAccessoryName(y.ItemName), StringComparison.Ordinal);
		}

		// Token: 0x04000545 RID: 1349
		private readonly LocalizationService _localizationService;
	}
}
