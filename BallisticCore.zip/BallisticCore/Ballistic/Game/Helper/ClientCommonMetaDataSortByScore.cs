﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x0200009B RID: 155
	internal class ClientCommonMetaDataSortByScore : IComparer<ClientCommonMetaData>
	{
		// Token: 0x0600024D RID: 589 RVA: 0x0001B088 File Offset: 0x00019288
		public int Compare(ClientCommonMetaData x, ClientCommonMetaData y)
		{
			return x.Score.CompareTo(y.Score);
		}
	}
}
