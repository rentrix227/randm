﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A0 RID: 160
	public enum FXEffectType
	{
		// Token: 0x04000526 RID: 1318
		None,
		// Token: 0x04000527 RID: 1319
		BulletMarks,
		// Token: 0x04000528 RID: 1320
		BulletHitParticles,
		// Token: 0x04000529 RID: 1321
		ExplosionDecals,
		// Token: 0x0400052A RID: 1322
		BloodDecals
	}
}
