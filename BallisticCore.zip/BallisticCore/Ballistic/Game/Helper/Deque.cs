﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x0200009C RID: 156
	[DebuggerDisplay("Count = {Count}, Capacity = {Capacity}")]
	[DebuggerTypeProxy(typeof(Deque<>.DebugView))]
	internal sealed class Deque<T> : IList<T>, IList, ICollection<T>, IEnumerable<T>, IEnumerable, ICollection
	{
		// Token: 0x0600024E RID: 590 RVA: 0x00003C15 File Offset: 0x00001E15
		public Deque(int capacity)
		{
			if (capacity < 1)
			{
				throw new ArgumentOutOfRangeException("capacity", "Capacity must be greater than 0.");
			}
			this.buffer = new T[capacity];
		}

		// Token: 0x0600024F RID: 591 RVA: 0x0001B0AC File Offset: 0x000192AC
		public Deque(IEnumerable<T> collection)
		{
			int num = collection.Count<T>();
			if (num > 0)
			{
				this.buffer = new T[num];
				this.DoInsertRange(0, collection, num);
			}
			else
			{
				this.buffer = new T[8];
			}
		}

		// Token: 0x06000250 RID: 592 RVA: 0x00003C40 File Offset: 0x00001E40
		public Deque()
			: this(8)
		{
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000251 RID: 593 RVA: 0x00003C49 File Offset: 0x00001E49
		bool ICollection<T>.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000040 RID: 64
		public T this[int index]
		{
			get
			{
				Deque<T>.CheckExistingIndexArgument(this.Count, index);
				return this.DoGetItem(index);
			}
			set
			{
				Deque<T>.CheckExistingIndexArgument(this.Count, index);
				this.DoSetItem(index, value);
			}
		}

		// Token: 0x06000254 RID: 596 RVA: 0x00003C77 File Offset: 0x00001E77
		public void Insert(int index, T item)
		{
			Deque<T>.CheckNewIndexArgument(this.Count, index);
			this.DoInsert(index, item);
		}

		// Token: 0x06000255 RID: 597 RVA: 0x00003C8D File Offset: 0x00001E8D
		public void RemoveAt(int index)
		{
			Deque<T>.CheckExistingIndexArgument(this.Count, index);
			this.DoRemoveAt(index);
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0001B0F4 File Offset: 0x000192F4
		public int IndexOf(T item)
		{
			EqualityComparer<T> @default = EqualityComparer<T>.Default;
			int num = 0;
			foreach (T t in this)
			{
				if (@default.Equals(item, t))
				{
					return num;
				}
				num++;
			}
			return -1;
		}

		// Token: 0x06000257 RID: 599 RVA: 0x00003CA2 File Offset: 0x00001EA2
		void ICollection<T>.Add(T item)
		{
			this.DoInsert(this.Count, item);
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00003CB1 File Offset: 0x00001EB1
		bool ICollection<T>.Contains(T item)
		{
			return this.Contains(item, null);
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0001B168 File Offset: 0x00019368
		void ICollection<T>.CopyTo(T[] array, int arrayIndex)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array", "Array is null");
			}
			int count = this.Count;
			Deque<T>.CheckRangeArguments(array.Length, arrayIndex, count);
			for (int num = 0; num != count; num++)
			{
				array[arrayIndex + num] = this[num];
			}
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0001B1C0 File Offset: 0x000193C0
		public bool Remove(T item)
		{
			int num = this.IndexOf(item);
			if (num == -1)
			{
				return false;
			}
			this.DoRemoveAt(num);
			return true;
		}

		// Token: 0x0600025B RID: 603 RVA: 0x0001B1E8 File Offset: 0x000193E8
		public IEnumerator<T> GetEnumerator()
		{
			int count = this.Count;
			for (int i = 0; i != count; i++)
			{
				yield return this.DoGetItem(i);
			}
			yield break;
		}

		// Token: 0x0600025C RID: 604 RVA: 0x00003CBB File Offset: 0x00001EBB
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x0600025D RID: 605 RVA: 0x0001B204 File Offset: 0x00019404
		private bool ObjectIsT(object item)
		{
			if (item is T)
			{
				return true;
			}
			if (item == null)
			{
				Type typeFromHandle = typeof(T);
				if (typeFromHandle.IsClass && !typeFromHandle.IsPointer)
				{
					return true;
				}
				if (typeFromHandle.IsInterface)
				{
					return true;
				}
				if (typeFromHandle.IsGenericType && typeFromHandle.GetGenericTypeDefinition() == typeof(Nullable<>))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600025E RID: 606 RVA: 0x00003CC3 File Offset: 0x00001EC3
		int IList.Add(object value)
		{
			if (!this.ObjectIsT(value))
			{
				throw new ArgumentException("Item is not of the correct type.", "value");
			}
			this.AddToBack((T)((object)value));
			return this.Count - 1;
		}

		// Token: 0x0600025F RID: 607 RVA: 0x00003CF5 File Offset: 0x00001EF5
		bool IList.Contains(object value)
		{
			if (!this.ObjectIsT(value))
			{
				throw new ArgumentException("Item is not of the correct type.", "value");
			}
			return this.Contains((T)((object)value));
		}

		// Token: 0x06000260 RID: 608 RVA: 0x00003D1F File Offset: 0x00001F1F
		int IList.IndexOf(object value)
		{
			if (!this.ObjectIsT(value))
			{
				throw new ArgumentException("Item is not of the correct type.", "value");
			}
			return this.IndexOf((T)((object)value));
		}

		// Token: 0x06000261 RID: 609 RVA: 0x00003D49 File Offset: 0x00001F49
		void IList.Insert(int index, object value)
		{
			if (!this.ObjectIsT(value))
			{
				throw new ArgumentException("Item is not of the correct type.", "value");
			}
			this.Insert(index, (T)((object)value));
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000262 RID: 610 RVA: 0x00003C49 File Offset: 0x00001E49
		bool IList.IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000263 RID: 611 RVA: 0x00003C49 File Offset: 0x00001E49
		bool IList.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06000264 RID: 612 RVA: 0x00003D74 File Offset: 0x00001F74
		void IList.Remove(object value)
		{
			if (!this.ObjectIsT(value))
			{
				throw new ArgumentException("Item is not of the correct type.", "value");
			}
			this.Remove((T)((object)value));
		}

		// Token: 0x1700003D RID: 61
		object IList.this[int index]
		{
			get
			{
				return this[index];
			}
			set
			{
				if (!this.ObjectIsT(value))
				{
					throw new ArgumentException("Item is not of the correct type.", "value");
				}
				this[index] = (T)((object)value);
			}
		}

		// Token: 0x06000267 RID: 615 RVA: 0x0001B27C File Offset: 0x0001947C
		void ICollection.CopyTo(Array array, int index)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array", "Destination array cannot be null.");
			}
			Deque<T>.CheckRangeArguments(array.Length, index, this.Count);
			for (int num = 0; num != this.Count; num++)
			{
				try
				{
					array.SetValue(this[num], index + num);
				}
				catch (InvalidCastException ex)
				{
					throw new ArgumentException("Destination array is of incorrect type.", ex);
				}
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000268 RID: 616 RVA: 0x00003C49 File Offset: 0x00001E49
		bool ICollection.IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000269 RID: 617 RVA: 0x00003DD8 File Offset: 0x00001FD8
		object ICollection.SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x0600026A RID: 618 RVA: 0x0001B300 File Offset: 0x00019500
		private static void CheckNewIndexArgument(int sourceLength, int index)
		{
			if (index < 0 || index > sourceLength)
			{
				throw new ArgumentOutOfRangeException("index", string.Concat(new object[] { "Invalid new index ", index, " for source length ", sourceLength }));
			}
		}

		// Token: 0x0600026B RID: 619 RVA: 0x0001B354 File Offset: 0x00019554
		private static void CheckExistingIndexArgument(int sourceLength, int index)
		{
			if (index < 0 || index >= sourceLength)
			{
				throw new ArgumentOutOfRangeException("index", string.Concat(new object[] { "Invalid existing index ", index, " for source length ", sourceLength }));
			}
		}

		// Token: 0x0600026C RID: 620 RVA: 0x0001B3A8 File Offset: 0x000195A8
		private static void CheckRangeArguments(int sourceLength, int offset, int count)
		{
			if (offset < 0)
			{
				throw new ArgumentOutOfRangeException("offset", "Invalid offset " + offset);
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", "Invalid count " + count);
			}
			if (sourceLength - offset < count)
			{
				throw new ArgumentException(string.Concat(new object[] { "Invalid offset (", offset, ") or count + (", count, ") for source length ", sourceLength }));
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600026D RID: 621 RVA: 0x00003DDB File Offset: 0x00001FDB
		private bool IsEmpty
		{
			get
			{
				return this.Count == 0;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600026E RID: 622 RVA: 0x00003DE6 File Offset: 0x00001FE6
		private bool IsFull
		{
			get
			{
				return this.Count == this.Capacity;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600026F RID: 623 RVA: 0x00003DF6 File Offset: 0x00001FF6
		private bool IsSplit
		{
			get
			{
				return this.offset > this.Capacity - this.Count;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000270 RID: 624 RVA: 0x00003E0D File Offset: 0x0000200D
		// (set) Token: 0x06000271 RID: 625 RVA: 0x0001B448 File Offset: 0x00019648
		public int Capacity
		{
			get
			{
				return this.buffer.Length;
			}
			set
			{
				if (value < 1)
				{
					throw new ArgumentOutOfRangeException("value", "Capacity must be greater than 0.");
				}
				if (value < this.Count)
				{
					throw new InvalidOperationException("Capacity cannot be set to a value less than Count");
				}
				if (value == this.buffer.Length)
				{
					return;
				}
				T[] array = new T[value];
				if (this.IsSplit)
				{
					int num = this.Capacity - this.offset;
					Array.Copy(this.buffer, this.offset, array, 0, num);
					Array.Copy(this.buffer, 0, array, num, this.Count - num);
				}
				else
				{
					Array.Copy(this.buffer, this.offset, array, 0, this.Count);
				}
				this.buffer = array;
				this.offset = 0;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000272 RID: 626 RVA: 0x00003E17 File Offset: 0x00002017
		// (set) Token: 0x06000273 RID: 627 RVA: 0x00003E1F File Offset: 0x0000201F
		public int Count { get; private set; }

		// Token: 0x06000274 RID: 628 RVA: 0x00003E28 File Offset: 0x00002028
		private int DequeIndexToBufferIndex(int index)
		{
			return (index + this.offset) % this.Capacity;
		}

		// Token: 0x06000275 RID: 629 RVA: 0x00003E39 File Offset: 0x00002039
		private T DoGetItem(int index)
		{
			return this.buffer[this.DequeIndexToBufferIndex(index)];
		}

		// Token: 0x06000276 RID: 630 RVA: 0x00003E4D File Offset: 0x0000204D
		private void DoSetItem(int index, T item)
		{
			this.buffer[this.DequeIndexToBufferIndex(index)] = item;
		}

		// Token: 0x06000277 RID: 631 RVA: 0x00003E62 File Offset: 0x00002062
		private void DoInsert(int index, T item)
		{
			this.EnsureCapacityForOneElement();
			if (index == 0)
			{
				this.DoAddToFront(item);
				return;
			}
			if (index == this.Count)
			{
				this.DoAddToBack(item);
				return;
			}
			this.DoInsertRange(index, new T[] { item }, 1);
		}

		// Token: 0x06000278 RID: 632 RVA: 0x00003EA2 File Offset: 0x000020A2
		private void DoRemoveAt(int index)
		{
			if (index == 0)
			{
				this.DoRemoveFromFront();
				return;
			}
			if (index == this.Count - 1)
			{
				this.DoRemoveFromBack();
				return;
			}
			this.DoRemoveRange(index, 1);
		}

		// Token: 0x06000279 RID: 633 RVA: 0x0001B508 File Offset: 0x00019708
		private int PostIncrement(int value)
		{
			int num = this.offset;
			this.offset += value;
			this.offset %= this.Capacity;
			return num;
		}

		// Token: 0x0600027A RID: 634 RVA: 0x00003ED0 File Offset: 0x000020D0
		private int PreDecrement(int value)
		{
			this.offset -= value;
			if (this.offset < 0)
			{
				this.offset += this.Capacity;
			}
			return this.offset;
		}

		// Token: 0x0600027B RID: 635 RVA: 0x00003F05 File Offset: 0x00002105
		private void DoAddToBack(T value)
		{
			this.buffer[this.DequeIndexToBufferIndex(this.Count)] = value;
			this.Count++;
		}

		// Token: 0x0600027C RID: 636 RVA: 0x00003F2D File Offset: 0x0000212D
		private void DoAddToFront(T value)
		{
			this.buffer[this.PreDecrement(1)] = value;
			this.Count++;
		}

		// Token: 0x0600027D RID: 637 RVA: 0x0001B540 File Offset: 0x00019740
		private T DoRemoveFromBack()
		{
			T t = this.buffer[this.DequeIndexToBufferIndex(this.Count - 1)];
			this.Count--;
			return t;
		}

		// Token: 0x0600027E RID: 638 RVA: 0x00003F50 File Offset: 0x00002150
		private T DoRemoveFromFront()
		{
			this.Count--;
			return this.buffer[this.PostIncrement(1)];
		}

		// Token: 0x0600027F RID: 639 RVA: 0x0001B578 File Offset: 0x00019778
		private void DoInsertRange(int index, IEnumerable<T> collection, int collectionCount)
		{
			if (index < this.Count / 2)
			{
				int num = this.Capacity - collectionCount;
				for (int num2 = 0; num2 != index; num2++)
				{
					this.buffer[this.DequeIndexToBufferIndex(num + num2)] = this.buffer[this.DequeIndexToBufferIndex(num2)];
				}
				this.PreDecrement(collectionCount);
			}
			else
			{
				int num3 = this.Count - index;
				int num4 = index + collectionCount;
				for (int num5 = num3 - 1; num5 != -1; num5--)
				{
					this.buffer[this.DequeIndexToBufferIndex(num4 + num5)] = this.buffer[this.DequeIndexToBufferIndex(index + num5)];
				}
			}
			int num6 = index;
			foreach (T t in collection)
			{
				this.buffer[this.DequeIndexToBufferIndex(num6)] = t;
				num6++;
			}
			this.Count += collectionCount;
		}

		// Token: 0x06000280 RID: 640 RVA: 0x0001B6A8 File Offset: 0x000198A8
		private void DoRemoveRange(int index, int collectionCount)
		{
			if (index == 0)
			{
				this.PostIncrement(collectionCount);
				this.Count -= collectionCount;
				return;
			}
			if (index == this.Count - collectionCount)
			{
				this.Count -= collectionCount;
				return;
			}
			if (index + collectionCount / 2 < this.Count / 2)
			{
				for (int num = index - 1; num != -1; num--)
				{
					this.buffer[this.DequeIndexToBufferIndex(collectionCount + num)] = this.buffer[this.DequeIndexToBufferIndex(num)];
				}
				this.PostIncrement(collectionCount);
			}
			else
			{
				int num2 = this.Count - collectionCount - index;
				int num3 = index + collectionCount;
				for (int num4 = 0; num4 != num2; num4++)
				{
					this.buffer[this.DequeIndexToBufferIndex(index + num4)] = this.buffer[this.DequeIndexToBufferIndex(num3 + num4)];
				}
			}
			this.Count -= collectionCount;
		}

		// Token: 0x06000281 RID: 641 RVA: 0x00003F72 File Offset: 0x00002172
		private void EnsureCapacityForOneElement()
		{
			if (this.IsFull)
			{
				this.Capacity *= 2;
			}
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00003F8D File Offset: 0x0000218D
		public void AddToBack(T value)
		{
			this.EnsureCapacityForOneElement();
			this.DoAddToBack(value);
		}

		// Token: 0x06000283 RID: 643 RVA: 0x00003F9C File Offset: 0x0000219C
		public void AddToFront(T value)
		{
			this.EnsureCapacityForOneElement();
			this.DoAddToFront(value);
		}

		// Token: 0x06000284 RID: 644 RVA: 0x0001B7AC File Offset: 0x000199AC
		public void InsertRange(int index, IEnumerable<T> collection)
		{
			int num = collection.Count<T>();
			Deque<T>.CheckNewIndexArgument(this.Count, index);
			if (num > this.Capacity - this.Count)
			{
				this.Capacity = checked(this.Count + num);
			}
			if (num == 0)
			{
				return;
			}
			this.DoInsertRange(index, collection, num);
		}

		// Token: 0x06000285 RID: 645 RVA: 0x00003FAB File Offset: 0x000021AB
		public void RemoveRange(int offset, int count)
		{
			Deque<T>.CheckRangeArguments(this.Count, offset, count);
			if (count == 0)
			{
				return;
			}
			this.DoRemoveRange(offset, count);
		}

		// Token: 0x06000286 RID: 646 RVA: 0x00003FC9 File Offset: 0x000021C9
		public T RemoveFromBack()
		{
			if (this.IsEmpty)
			{
				throw new InvalidOperationException("The deque is empty.");
			}
			return this.DoRemoveFromBack();
		}

		// Token: 0x06000287 RID: 647 RVA: 0x00003FE7 File Offset: 0x000021E7
		public T RemoveFromFront()
		{
			if (this.IsEmpty)
			{
				throw new InvalidOperationException("The deque is empty.");
			}
			return this.DoRemoveFromFront();
		}

		// Token: 0x06000288 RID: 648 RVA: 0x00004005 File Offset: 0x00002205
		public void Clear()
		{
			this.offset = 0;
			this.Count = 0;
		}

		// Token: 0x0400051A RID: 1306
		private const int DefaultCapacity = 8;

		// Token: 0x0400051B RID: 1307
		private T[] buffer;

		// Token: 0x0400051C RID: 1308
		private int offset;

		// Token: 0x0200009D RID: 157
		[DebuggerNonUserCode]
		private sealed class DebugView
		{
			// Token: 0x06000289 RID: 649 RVA: 0x00004015 File Offset: 0x00002215
			public DebugView(Deque<T> deque)
			{
				this.deque = deque;
			}

			// Token: 0x17000046 RID: 70
			// (get) Token: 0x0600028A RID: 650 RVA: 0x0001B800 File Offset: 0x00019A00
			[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
			public T[] Items
			{
				get
				{
					T[] array = new T[this.deque.Count];
					((ICollection<T>)this.deque).CopyTo(array, 0);
					return array;
				}
			}

			// Token: 0x0400051E RID: 1310
			private readonly Deque<T> deque;
		}
	}
}
