﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000B0 RID: 176
	public enum RenderBuffering
	{
		// Token: 0x04000556 RID: 1366
		OFF = 1,
		// Token: 0x04000557 RID: 1367
		DEFAULT,
		// Token: 0x04000558 RID: 1368
		TRIPLE_BUFFER,
		// Token: 0x04000559 RID: 1369
		QUADRA_BUFFER,
		// Token: 0x0400055A RID: 1370
		PENTA_BUFFER
	}
}
