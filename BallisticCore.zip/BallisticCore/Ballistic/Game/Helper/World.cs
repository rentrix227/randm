﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000C2 RID: 194
	public class World
	{
		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600031F RID: 799 RVA: 0x000046BE File Offset: 0x000028BE
		public static LayerMask AllPlayerCollisionLayers
		{
			get
			{
				return World.playerCollisionLayer | World.shootableAndPlayerCollisionLayer | World.projectileAndPlayerCollision;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000320 RID: 800 RVA: 0x000046E5 File Offset: 0x000028E5
		public static LayerMask AllShootableLayers
		{
			get
			{
				return World.shootableLayer | World.shootableAndPlayerCollisionLayer | World.shootableIgnoreFlares;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000321 RID: 801 RVA: 0x0000470C File Offset: 0x0000290C
		public static LayerMask ShootableLayersExceptIgnoreFlares
		{
			get
			{
				return World.shootableLayer | World.shootableAndPlayerCollisionLayer;
			}
		}

		// Token: 0x040005B6 RID: 1462
		public static LayerMask playerCollisionLayer = 1 << LayerMask.NameToLayer("PlayerCollision");

		// Token: 0x040005B7 RID: 1463
		public static LayerMask lightMapShadow = 1 << LayerMask.NameToLayer("LightmapShadow");

		// Token: 0x040005B8 RID: 1464
		public static LayerMask shootableLayer = 1 << LayerMask.NameToLayer("Shootable");

		// Token: 0x040005B9 RID: 1465
		public static LayerMask shootableAndPlayerCollisionLayer = 1 << LayerMask.NameToLayer("ShootableAndPlayerCollision");

		// Token: 0x040005BA RID: 1466
		public static LayerMask projectileAndPlayerCollision = 1 << LayerMask.NameToLayer("ProjectileAndPlayerCollision");

		// Token: 0x040005BB RID: 1467
		public static LayerMask bodyPartLayer = 1 << LayerMask.NameToLayer("BodyPart");

		// Token: 0x040005BC RID: 1468
		public static LayerMask weaponsLayer = 1 << LayerMask.NameToLayer("Weapons");

		// Token: 0x040005BD RID: 1469
		public static LayerMask enemyLayer = 1 << LayerMask.NameToLayer("Enemy");

		// Token: 0x040005BE RID: 1470
		public static LayerMask shootableBy3rd = 1 << LayerMask.NameToLayer("ShootableBy3rd");

		// Token: 0x040005BF RID: 1471
		public static LayerMask shootableIgnoreFlares = 1 << LayerMask.NameToLayer("ShootableIgnoreFlares");

		// Token: 0x040005C0 RID: 1472
		public const string FPSPlayerTag = "fpsPlayer";

		// Token: 0x040005C1 RID: 1473
		public const string EnemyCharacterTag = "enemyCharacter";

		// Token: 0x040005C2 RID: 1474
		public static Vector3 DEAD_POSITION = new Vector3(1000f, 1000f, 1000f);

		// Token: 0x040005C3 RID: 1475
		public static float INVINCIBLE_TIME = 4f;

		// Token: 0x040005C4 RID: 1476
		public const float SAFE_FALL_LIMIT = 4.5f;

		// Token: 0x040005C5 RID: 1477
		public const float MAX_FALL_DISTANCE = 10f;

		// Token: 0x040005C6 RID: 1478
		public static Vector2 BloodParticleRange = new Vector2(50f, 90f);

		// Token: 0x020000C3 RID: 195
		public static class MaterialTags
		{
			// Token: 0x040005C7 RID: 1479
			public static string Concrete = "concrete";

			// Token: 0x040005C8 RID: 1480
			public static string Dirt = "dirt";

			// Token: 0x040005C9 RID: 1481
			public static string Glass = "glass";

			// Token: 0x040005CA RID: 1482
			public static string Grate = "grate";

			// Token: 0x040005CB RID: 1483
			public static string MetalArmor = "metalarmor";

			// Token: 0x040005CC RID: 1484
			public static string HollowMetal = "hollowmetal";

			// Token: 0x040005CD RID: 1485
			public static string Water = "water";

			// Token: 0x040005CE RID: 1486
			public static string Wood = "wood";

			// Token: 0x040005CF RID: 1487
			public static string Untagged = "untagged";

			// Token: 0x040005D0 RID: 1488
			public static string[] All = new string[]
			{
				World.MaterialTags.Untagged,
				World.MaterialTags.Concrete,
				World.MaterialTags.Dirt,
				World.MaterialTags.Glass,
				World.MaterialTags.Grate,
				World.MaterialTags.MetalArmor,
				World.MaterialTags.HollowMetal,
				World.MaterialTags.Water,
				World.MaterialTags.Wood
			};
		}
	}
}
