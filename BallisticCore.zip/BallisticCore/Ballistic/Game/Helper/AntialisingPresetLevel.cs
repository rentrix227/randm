﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000AF RID: 175
	public enum AntialisingPresetLevel
	{
		// Token: 0x0400054D RID: 1357
		OFF,
		// Token: 0x0400054E RID: 1358
		FXAA,
		// Token: 0x0400054F RID: 1359
		MSAAx2,
		// Token: 0x04000550 RID: 1360
		MSAAx4,
		// Token: 0x04000551 RID: 1361
		MSAAx8,
		// Token: 0x04000552 RID: 1362
		MSAAx2_FXAA,
		// Token: 0x04000553 RID: 1363
		MSAAx4_FXAA,
		// Token: 0x04000554 RID: 1364
		MSAAx8_FXAA
	}
}
