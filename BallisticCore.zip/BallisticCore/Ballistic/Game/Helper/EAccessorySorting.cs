﻿using System;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A5 RID: 165
	internal enum EAccessorySorting
	{
		// Token: 0x04000541 RID: 1345
		NONE,
		// Token: 0x04000542 RID: 1346
		NAME
	}
}
