﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000B6 RID: 182
	public static class TextureHelper
	{
		// Token: 0x060002D7 RID: 727 RVA: 0x0001C3F8 File Offset: 0x0001A5F8
		internal static string GetMapIconPath(GameMapConfig config, EImageSize size)
		{
			if (config == null)
			{
				return null;
			}
			if (size == EImageSize.SMALL)
			{
				return config.FolderPath + "/" + config.MapName + "_128.jpg";
			}
			if (size == EImageSize.MEDIUM)
			{
				return config.FolderPath + "/" + config.MapName + "_512.jpg";
			}
			if (size != EImageSize.LARGE)
			{
				return config.FolderPath + "/" + config.MapName + "_128.jpg";
			}
			return config.FolderPath + "/" + config.MapName + "_high.jpg";
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x00004393 File Offset: 0x00002593
		internal static string GetModeIconPath(string mode, EImageSize eImageSize)
		{
			return "GameModes/" + mode;
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x000043A0 File Offset: 0x000025A0
		internal static string GetWeaponIconPath(string itemModel, EImageSize size, EWeaponSkinName skinName)
		{
			return TextureHelper.GetWeaponIconPath(itemModel, size, skinName.ToString().ToLowerInvariant());
		}

		// Token: 0x060002DA RID: 730 RVA: 0x000043BB File Offset: 0x000025BB
		internal static string GetWeaponIconPath(string itemModel, EImageSize size, string skinName = "default")
		{
			return string.Concat(new string[]
			{
				"WeaponIcons/",
				itemModel,
				"/",
				skinName,
				(size != EImageSize.LARGE) ? string.Empty : "_large"
			});
		}

		// Token: 0x060002DB RID: 731 RVA: 0x0001C498 File Offset: 0x0001A698
		internal static string GetLockboxIconPath(ESeason season, EHeroClass heroClass, EImageSize size)
		{
			switch (season)
			{
			case ESeason.EARLYACCESS:
			case ESeason.FIRSTBLOOD:
			case ESeason.SECONDWAVE:
			case ESeason.THIRDSTRIKE:
			case ESeason.CORE:
				return "LockboxIcons/" + heroClass + ((size != EImageSize.LARGE) ? string.Empty : "_large");
			default:
				return "LockboxIcons/" + season.ToString() + ((size != EImageSize.LARGE) ? string.Empty : "_large");
			}
		}

		// Token: 0x060002DC RID: 732 RVA: 0x000043F9 File Offset: 0x000025F9
		internal static string GetSkillIconPath(EHeroSkillV2 skill)
		{
			return TextureHelper.GetSkillIconPath(skill.ToString().ToLowerInvariant());
		}

		// Token: 0x060002DD RID: 733 RVA: 0x00004412 File Offset: 0x00002612
		internal static string GetSkillIconPath(string skillName)
		{
			return "Skills/" + skillName;
		}

		// Token: 0x060002DE RID: 734 RVA: 0x0000441F File Offset: 0x0000261F
		internal static string GetGoldClassIconPath(EHeroClass heroClass)
		{
			return "Classes/IconsGold/" + heroClass.ToString().ToLowerInvariant();
		}

		// Token: 0x060002DF RID: 735 RVA: 0x0000443D File Offset: 0x0000263D
		internal static string GetClassIconPath(EHeroClass heroClass)
		{
			return "Classes/Icons/" + heroClass.ToString().ToLowerInvariant();
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x0000445B File Offset: 0x0000265B
		internal static string GetClassSkinIconPath(string skinName)
		{
			return "Classes/Skins/" + skinName;
		}

		// Token: 0x060002E1 RID: 737 RVA: 0x00004468 File Offset: 0x00002668
		internal static string GetClassHudIconPath(string skinName)
		{
			return "Classes/HUD/" + skinName;
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x00004475 File Offset: 0x00002675
		internal static string GetAccessoryIconPath(string accessoryName, EImageSize size)
		{
			return "AccessoriesIcons/" + accessoryName + ((size != EImageSize.LARGE) ? string.Empty : "_large");
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x00004498 File Offset: 0x00002698
		internal static string GetClassSkinLoadoutImagePath(string skinName)
		{
			return "Classes/Loadouts/" + skinName;
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x000044A5 File Offset: 0x000026A5
		internal static string GetClassProgressionBackgroundPath(EHeroClass heroClass)
		{
			return "Classes/Progressions/" + heroClass.ToString().ToLowerInvariant();
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x0001C51C File Offset: 0x0001A71C
		internal static string GetSeasonIconPath(ESeason season, EImageSize size)
		{
			string text = string.Empty;
			if (size != EImageSize.SMALL)
			{
				if (size != EImageSize.MEDIUM)
				{
					if (size == EImageSize.LARGE)
					{
						text = "_large";
					}
				}
				else
				{
					text = "_medium";
				}
			}
			else
			{
				text = "_small";
			}
			return "SeasonsIcons/" + season.ToString().ToLowerInvariant() + text;
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x0001C588 File Offset: 0x0001A788
		internal static string GetRewardsIconPath(EHeroClass hero, EImageSize size)
		{
			string text = string.Empty;
			if (size != EImageSize.SMALL)
			{
				if (size != EImageSize.MEDIUM)
				{
					if (size == EImageSize.LARGE)
					{
						text = "_large";
					}
				}
				else
				{
					text = "_medium";
				}
			}
			else
			{
				text = "_small";
			}
			return "RewardClassIcons/" + hero.ToString().ToLowerInvariant() + text;
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x000044C3 File Offset: 0x000026C3
		private static Coroutine StartCoroutine(IEnumerator routine)
		{
			return ServiceProvider.GetService<EventProxy>().StartCoroutine(routine);
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x000044D0 File Offset: 0x000026D0
		internal static void LoadImageAsync(string imagePath, Image target, bool setNativeSize = false, EImageSource imageSource = EImageSource.RESOURCES)
		{
			TextureHelper.StartCoroutine(TextureHelper.LoadSpriteAsyncRoutine(imagePath, target, setNativeSize, imageSource));
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x000044E1 File Offset: 0x000026E1
		internal static void LoadImageAsync(string imagePath, RawImage target, bool setNativeSize = false, EImageSource imageSource = EImageSource.RESOURCES)
		{
			TextureHelper.StartCoroutine(TextureHelper.LoadTextureAsyncRoutine(imagePath, target, setNativeSize, imageSource));
		}

		// Token: 0x060002EA RID: 746 RVA: 0x000044F2 File Offset: 0x000026F2
		internal static void LoadImageAsync(string imagePath, Renderer target, EImageSource imageSource = EImageSource.RESOURCES)
		{
			TextureHelper.StartCoroutine(TextureHelper.LoadTextureAsyncRoutine(imagePath, target, imageSource));
		}

		// Token: 0x060002EB RID: 747 RVA: 0x0001C5F4 File Offset: 0x0001A7F4
		internal static void CacheImage(string imagePath, EImageSource imageSource = EImageSource.RESOURCES)
		{
			TextureHelper.ImageLoadResult imageLoadResult = new TextureHelper.ImageLoadResult();
			TextureHelper.StartCoroutine(TextureHelper.LoadImageRoutine(imagePath, imageSource, imageLoadResult));
		}

		// Token: 0x060002EC RID: 748 RVA: 0x0001C618 File Offset: 0x0001A818
		public static string ImagePathToStreamingAssetsPathForBuild(string imagePath)
		{
			string text = Crypto.ComputeMd5Hash(imagePath.Replace("\\", "/"));
			string text2 = text.Substring(0, 2) + "/" + text;
			return Application.streamingAssetsPath + "/metadata/_data/" + text2;
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0001C618 File Offset: 0x0001A818
		public static string ImagePathToStreamingAssetsPath(string imagePath)
		{
			string text = Crypto.ComputeMd5Hash(imagePath.Replace("\\", "/"));
			string text2 = text.Substring(0, 2) + "/" + text;
			return Application.streamingAssetsPath + "/metadata/_data/" + text2;
		}

		// Token: 0x060002EE RID: 750 RVA: 0x0001C660 File Offset: 0x0001A860
		public static void ClearCache()
		{
			foreach (TextureHelper.ImageLoadResult imageLoadResult in TextureHelper._textureCache.Values)
			{
				if (imageLoadResult.ImageSource == EImageSource.METADATA)
				{
					Object.Destroy(imageLoadResult.Texture);
				}
			}
			TextureHelper._textureCache.Clear();
			Resources.UnloadUnusedAssets();
			GC.Collect();
		}

		// Token: 0x060002EF RID: 751 RVA: 0x00004502 File Offset: 0x00002702
		public static void Encode(byte[] src, byte[] dst, int offset = 0)
		{
			Crypto.Spoof(src, dst, 0, offset, src.Length);
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x0001C6E8 File Offset: 0x0001A8E8
		private static void WorkerThreadProc()
		{
			for (;;)
			{
				while (TextureHelper._workerThreadQueue.Count == 0)
				{
					Thread.Sleep(50);
				}
				Action action = TextureHelper._workerThreadQueue.Dequeue();
				action();
			}
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x0001C728 File Offset: 0x0001A928
		private static IEnumerator LoadImageRoutine(string imagePath, EImageSource imageSource, TextureHelper.ImageLoadResult result)
		{
			TextureHelper.ImageLoadResult cachedResult;
			if (TextureHelper._textureCache.TryGetValue(imagePath, out cachedResult))
			{
				while (cachedResult.Texture == null)
				{
					yield return null;
				}
				result.Texture = cachedResult.Texture;
				result.Sprite = cachedResult.Sprite;
				yield break;
			}
			TextureHelper.ImageLoadResult cacheEntry = new TextureHelper.ImageLoadResult();
			TextureHelper._textureCache.Add(imagePath, cacheEntry);
			if (TextureHelper._workerThread == null)
			{
				TextureHelper._workerThread = new Thread(new ThreadStart(TextureHelper.WorkerThreadProc))
				{
					Priority = ThreadPriority.BelowNormal
				};
				TextureHelper._workerThread.Start();
			}
			if (imageSource == EImageSource.RESOURCES)
			{
				ResourceRequest rqt = Resources.LoadAsync<Texture2D>(imagePath);
				yield return rqt;
				result.Texture = rqt.asset as Texture2D;
				if (result.Texture != null)
				{
					result.Sprite = Sprite.Create(result.Texture, new Rect(0f, 0f, (float)result.Texture.width, (float)result.Texture.height), new Vector2(0.5f, 0.5f), 100f, 0U, 0);
				}
				else
				{
					result.Sprite = null;
				}
			}
			else if (imageSource == EImageSource.METADATA || imageSource == EImageSource.STREAMINGASSETS)
			{
				bool doneLoading = false;
				byte[] imageBytes = null;
				Texture2D texture = null;
				string fullPath = string.Empty;
				if (imageSource != EImageSource.METADATA)
				{
					if (imageSource == EImageSource.STREAMINGASSETS)
					{
						fullPath = imagePath;
					}
				}
				else
				{
					fullPath = TextureHelper.ImagePathToStreamingAssetsPath(imagePath);
				}
				TextureHelper._workerThreadQueue.Enqueue(delegate
				{
					if (File.Exists(fullPath))
					{
						if (imageSource != EImageSource.METADATA)
						{
							if (imageSource == EImageSource.STREAMINGASSETS)
							{
								imageBytes = File.ReadAllBytes(fullPath);
							}
						}
						else
						{
							byte[] array = File.ReadAllBytes(fullPath);
							Rect rect;
							int num = BytePacker.UnpackIntRect(array, 0, out rect);
							imageBytes = new byte[array.Length - num];
							Crypto.Spoof(array, imageBytes, num, 0, imageBytes.Length);
						}
					}
					doneLoading = true;
				});
				while (!doneLoading)
				{
					yield return null;
				}
				while (Time.frameCount <= TextureHelper._lastLoadedTextureFrame && TextureHelper._texturesLoadedThisFrame >= 1)
				{
					yield return null;
				}
				if (Time.frameCount > TextureHelper._lastLoadedTextureFrame)
				{
					TextureHelper._texturesLoadedThisFrame = 0;
				}
				else
				{
					TextureHelper._texturesLoadedThisFrame++;
				}
				TextureHelper._lastLoadedTextureFrame = Time.frameCount;
				if (imageBytes != null)
				{
					texture = new Texture2D(1, 1, 12, false);
					ImageConversion.LoadImage(texture, imageBytes, false);
					result.Texture = texture;
					result.Sprite = Sprite.Create(result.Texture, new Rect(0f, 0f, (float)texture.width, (float)texture.height), new Vector2(0.5f, 0.5f), 100f, 0U, 1);
					texture.Apply(false, true);
				}
				else
				{
					texture = new Texture2D(512, 128, 5, false);
					Color32[] pixels = texture.GetPixels32();
					for (int i = 0; i < pixels.Length; i++)
					{
						pixels[i] = new Color32(byte.MaxValue, 0, byte.MaxValue, byte.MaxValue);
					}
					texture.SetPixels32(pixels);
					result.Texture = texture;
					result.Sprite = Sprite.Create(result.Texture, new Rect(0f, 0f, (float)texture.width, (float)texture.height), new Vector2(0.5f, 0.5f), 100f, 0U, 1);
					texture.Apply(false, true);
				}
			}
			cacheEntry.Texture = result.Texture;
			cacheEntry.ImageSource = imageSource;
			cacheEntry.Sprite = result.Sprite;
			yield break;
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x0001C754 File Offset: 0x0001A954
		private static IEnumerator LoadSpriteAsyncRoutine(string imagePath, Image target, bool setNativeSize, EImageSource imageSource)
		{
			if (target == null)
			{
				Debug.LogError("Error at AsyncLoading: [" + imagePath + "] could not be on a null target");
				yield break;
			}
			TextureHelper.ImageLoadResult textureLoadResult = new TextureHelper.ImageLoadResult();
			yield return TextureHelper.StartCoroutine(TextureHelper.LoadImageRoutine(imagePath, imageSource, textureLoadResult));
			if (textureLoadResult.Texture == null)
			{
				Debug.LogError("Error at AsyncLoading: [" + imagePath + "] is null");
				yield break;
			}
			target.sprite = textureLoadResult.Sprite;
			if (setNativeSize)
			{
				target.SetNativeSize();
			}
			yield break;
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x0001C784 File Offset: 0x0001A984
		private static IEnumerator LoadTextureAsyncRoutine(string imagePath, RawImage target, bool setNativeSize, EImageSource imageSource)
		{
			TextureHelper.ImageLoadResult textureLoadResult = new TextureHelper.ImageLoadResult();
			yield return TextureHelper.StartCoroutine(TextureHelper.LoadImageRoutine(imagePath, imageSource, textureLoadResult));
			target.texture = textureLoadResult.Texture;
			if (setNativeSize)
			{
				target.SetNativeSize();
			}
			yield break;
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x0001C7B4 File Offset: 0x0001A9B4
		private static IEnumerator LoadTextureAsyncRoutine(string imagePath, Renderer target, EImageSource imageSource)
		{
			TextureHelper.ImageLoadResult textureLoadResult = new TextureHelper.ImageLoadResult();
			yield return TextureHelper.StartCoroutine(TextureHelper.LoadImageRoutine(imagePath, imageSource, textureLoadResult));
			target.material.mainTexture = textureLoadResult.Texture;
			yield break;
		}

		// Token: 0x0400056A RID: 1386
		public const string ClassIconsPath = "Classes/Icons/";

		// Token: 0x0400056B RID: 1387
		public const string ClassIconsGoldPath = "Classes/IconsGold/";

		// Token: 0x0400056C RID: 1388
		public const string SkillIconsPath = "Skills/";

		// Token: 0x0400056D RID: 1389
		public const string WeaponIconsPath = "WeaponIcons/";

		// Token: 0x0400056E RID: 1390
		public const string ClassSkinLoadoutsIconsPath = "Classes/Loadouts/";

		// Token: 0x0400056F RID: 1391
		public const string ClassSkinIconsPath = "Classes/Skins/";

		// Token: 0x04000570 RID: 1392
		public const string ClassProgressionBackgroundPath = "Classes/Progressions/";

		// Token: 0x04000571 RID: 1393
		public const string ClassHudIconsPath = "Classes/HUD/";

		// Token: 0x04000572 RID: 1394
		public const string LockboxIconsPath = "LockboxIcons/";

		// Token: 0x04000573 RID: 1395
		public const string SeasonIconsPath = "SeasonsIcons/";

		// Token: 0x04000574 RID: 1396
		public const string RewardClassIconsPath = "RewardClassIcons/";

		// Token: 0x04000575 RID: 1397
		public const string AccessoryIconsPath = "AccessoriesIcons/";

		// Token: 0x04000576 RID: 1398
		private const int TexturesLoadedPerFrame = 1;

		// Token: 0x04000577 RID: 1399
		private static int _lastLoadedTextureFrame = -1;

		// Token: 0x04000578 RID: 1400
		private static int _texturesLoadedThisFrame = 0;

		// Token: 0x04000579 RID: 1401
		private static Thread _workerThread = null;

		// Token: 0x0400057A RID: 1402
		private static readonly Queue<Action> _workerThreadQueue = new Queue<Action>();

		// Token: 0x0400057B RID: 1403
		private static readonly Dictionary<string, TextureHelper.ImageLoadResult> _textureCache = new Dictionary<string, TextureHelper.ImageLoadResult>();

		// Token: 0x020000B7 RID: 183
		private class ImageLoadResult
		{
			// Token: 0x0400057D RID: 1405
			public Texture2D Texture;

			// Token: 0x0400057E RID: 1406
			public EImageSource ImageSource;

			// Token: 0x0400057F RID: 1407
			public Sprite Sprite;
		}
	}
}
