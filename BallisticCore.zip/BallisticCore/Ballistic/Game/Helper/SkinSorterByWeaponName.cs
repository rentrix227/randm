﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Localization;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000A8 RID: 168
	internal class SkinSorterByWeaponName : IComparer<WeaponSkinData>
	{
		// Token: 0x060002B4 RID: 692 RVA: 0x0000412B File Offset: 0x0000232B
		public SkinSorterByWeaponName()
		{
			this._localizationService = ServiceProvider.GetService<LocalizationService>();
		}

		// Token: 0x060002B5 RID: 693 RVA: 0x0000413E File Offset: 0x0000233E
		public int Compare(WeaponSkinData x, WeaponSkinData y)
		{
			return string.Compare(this._localizationService.GetWeaponName(x.Weapon.ItemName, ELocalizedTextCase.NONE), this._localizationService.GetWeaponName(y.Weapon.ItemName, ELocalizedTextCase.NONE), StringComparison.Ordinal);
		}

		// Token: 0x04000543 RID: 1347
		private readonly LocalizationService _localizationService;
	}
}
