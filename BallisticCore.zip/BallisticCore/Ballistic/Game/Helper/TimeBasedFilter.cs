﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Helper
{
	// Token: 0x020000BE RID: 190
	public class TimeBasedFilter
	{
		// Token: 0x06000312 RID: 786 RVA: 0x00004598 File Offset: 0x00002798
		public TimeBasedFilter(float p_timeWindow, bool p_ignoreTimeScale = false)
		{
			this.m_timeWindow = Mathf.Max(p_timeWindow, 0.0001f);
			this.m_ignoreTimeScale = p_ignoreTimeScale;
			this.m_buffer = new Deque<TimeBasedFilter.FilterEntry>();
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000313 RID: 787 RVA: 0x000045C3 File Offset: 0x000027C3
		public bool IsEmpty
		{
			get
			{
				return this.m_buffer.Count == 0;
			}
		}

		// Token: 0x06000314 RID: 788 RVA: 0x000045D3 File Offset: 0x000027D3
		public void Add(float p_value, float p_time)
		{
			this.m_buffer.AddToBack(new TimeBasedFilter.FilterEntry(p_value, p_time));
			this.m_currentSum += p_value;
		}

		// Token: 0x06000315 RID: 789 RVA: 0x000045F5 File Offset: 0x000027F5
		public void Add(float p_value)
		{
			if (this.m_ignoreTimeScale)
			{
				this.Add(p_value, Time.realtimeSinceStartup);
			}
			else
			{
				this.Add(p_value, Time.time);
			}
		}

		// Token: 0x06000316 RID: 790 RVA: 0x0001D064 File Offset: 0x0001B264
		public float Get(float p_currentTime)
		{
			if (this.m_buffer.Count == 0)
			{
				return 0f;
			}
			TimeBasedFilter.FilterEntry filterEntry;
			for (;;)
			{
				filterEntry = this.m_buffer.RemoveFromFront();
				if (filterEntry.time >= p_currentTime - this.m_timeWindow || this.m_buffer.Count == 0)
				{
					break;
				}
				this.m_currentSum -= filterEntry.value;
			}
			this.m_buffer.AddToFront(filterEntry);
			return this.m_currentSum / (float)this.m_buffer.Count;
		}

		// Token: 0x06000317 RID: 791 RVA: 0x0000461F File Offset: 0x0000281F
		public float Get()
		{
			if (this.m_ignoreTimeScale)
			{
				return this.Get(Time.realtimeSinceStartup);
			}
			return this.Get(Time.time);
		}

		// Token: 0x040005AA RID: 1450
		private float m_timeWindow;

		// Token: 0x040005AB RID: 1451
		private bool m_ignoreTimeScale;

		// Token: 0x040005AC RID: 1452
		private Deque<TimeBasedFilter.FilterEntry> m_buffer;

		// Token: 0x040005AD RID: 1453
		private float m_currentSum;

		// Token: 0x020000BF RID: 191
		private struct FilterEntry
		{
			// Token: 0x06000318 RID: 792 RVA: 0x00004643 File Offset: 0x00002843
			public FilterEntry(float p_value, float p_time)
			{
				this = default(TimeBasedFilter.FilterEntry);
				this.value = p_value;
				this.time = p_time;
			}

			// Token: 0x040005AE RID: 1454
			public float value;

			// Token: 0x040005AF RID: 1455
			public float time;
		}
	}
}
