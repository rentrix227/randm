﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing
{
	// Token: 0x020000F4 RID: 244
	[RequireComponent(typeof(BoxCollider))]
	[AddComponentMenu("Image Effects/Amplify Color Volume")]
	public class AmplifyColorVolume : AmplifyColorVolumeBase
	{
		// Token: 0x060004CB RID: 1227 RVA: 0x000242B4 File Offset: 0x000224B4
		public void OnTriggerEnter(Collider other)
		{
			AmplifyColorTriggerProxy component = other.GetComponent<AmplifyColorTriggerProxy>();
			if (component != null && component.OwnerEffect.UseVolumes && (component.OwnerEffect.VolumeCollisionMask & (1 << base.gameObject.layer)) != 0)
			{
				component.OwnerEffect.EnterVolume(this);
			}
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x00024318 File Offset: 0x00022518
		public void OnTriggerExit(Collider other)
		{
			AmplifyColorTriggerProxy component = other.GetComponent<AmplifyColorTriggerProxy>();
			if (component != null && component.OwnerEffect.UseVolumes && (component.OwnerEffect.VolumeCollisionMask & (1 << base.gameObject.layer)) != 0)
			{
				component.OwnerEffect.ExitVolume(this);
			}
		}
	}
}
