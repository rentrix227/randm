﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.PostProcessing.AmplifyColor;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing
{
	// Token: 0x020000F1 RID: 241
	[AddComponentMenu("")]
	public class AmplifyColorBase : MonoBehaviour
	{
		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060004A7 RID: 1191 RVA: 0x00005888 File Offset: 0x00003A88
		public Texture2D DefaultLut
		{
			get
			{
				return (!(this.defaultLut == null)) ? this.defaultLut : this.CreateDefaultLut();
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060004A8 RID: 1192 RVA: 0x000058AC File Offset: 0x00003AAC
		public bool IsBlending
		{
			get
			{
				return this.blending;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060004A9 RID: 1193 RVA: 0x000058B4 File Offset: 0x00003AB4
		private float effectVolumesBlendAdjusted
		{
			get
			{
				return Mathf.Clamp01((this.effectVolumesBlendAdjust >= 0.99f) ? 1f : ((this.volumesBlendAmount - this.effectVolumesBlendAdjust) / (1f - this.effectVolumesBlendAdjust)));
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060004AA RID: 1194 RVA: 0x000058EF File Offset: 0x00003AEF
		public string SharedInstanceID
		{
			get
			{
				return this.sharedInstanceID;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060004AB RID: 1195 RVA: 0x000058F7 File Offset: 0x00003AF7
		public bool WillItBlend
		{
			get
			{
				return this.LutTexture != null && this.LutBlendTexture != null && !this.blending;
			}
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x0002317C File Offset: 0x0002137C
		public void NewSharedInstanceID()
		{
			this.sharedInstanceID = Guid.NewGuid().ToString();
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x00005927 File Offset: 0x00003B27
		private void ReportMissingShaders()
		{
			Debug.LogError("[AmplifyColor] Failed to initialize shaders. Please attempt to re-enable the Amplify Color Effect component. If that fails, please reinstall Amplify Color.");
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x00005933 File Offset: 0x00003B33
		private void ReportNotSupported()
		{
			Debug.LogError("[AmplifyColor] This image effect is not supported on this platform. Please make sure your Unity license supports Full-Screen Post-Processing Effects which is usually reserved forn Pro licenses.");
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x0000593F File Offset: 0x00003B3F
		private bool CheckShader(Shader s)
		{
			if (s == null)
			{
				this.ReportMissingShaders();
				return false;
			}
			if (!s.isSupported)
			{
				this.ReportNotSupported();
				return false;
			}
			return true;
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x000231A4 File Offset: 0x000213A4
		private bool CheckShaders()
		{
			return this.CheckShader(this.shaderBase) && this.CheckShader(this.shaderBlend) && this.CheckShader(this.shaderBlendCache) && this.CheckShader(this.shaderMask) && this.CheckShader(this.shaderBlendMask);
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x00005969 File Offset: 0x00003B69
		private bool CheckSupport()
		{
			if (!SystemInfo.supportsImageEffects)
			{
				this.ReportNotSupported();
				return false;
			}
			return true;
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x00023204 File Offset: 0x00021404
		private void OnEnable()
		{
			if (!this.CheckSupport())
			{
				return;
			}
			if (!this.CreateMaterials())
			{
				return;
			}
			Texture2D texture2D = this.LutTexture as Texture2D;
			Texture2D texture2D2 = this.LutBlendTexture as Texture2D;
			if ((texture2D != null && texture2D.mipmapCount > 1) || (texture2D2 != null && texture2D2.mipmapCount > 1))
			{
				Debug.LogError("[AmplifyColor] Please disable \"Generate Mip Maps\" import settings on all LUT textures to avoid visual glitches. Change Texture Type to \"Advanced\" to access Mip settings.");
			}
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x0000597E File Offset: 0x00003B7E
		private void OnDisable()
		{
			if (this.actualTriggerProxy != null)
			{
				Object.DestroyImmediate(this.actualTriggerProxy.gameObject);
				this.actualTriggerProxy = null;
			}
			this.ReleaseMaterials();
			this.ReleaseTextures();
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x000059B4 File Offset: 0x00003BB4
		private void VolumesBlendTo(Texture blendTargetLUT, float blendTimeInSec)
		{
			this.volumesLutBlendTexture = blendTargetLUT;
			this.volumesBlendAmount = 0f;
			this.volumesBlendingTime = blendTimeInSec;
			this.volumesBlendingTimeCountdown = blendTimeInSec;
			this.volumesBlending = true;
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x000059DD File Offset: 0x00003BDD
		public void BlendTo(Texture blendTargetLUT, float blendTimeInSec, Action onFinishBlend)
		{
			this.LutBlendTexture = blendTargetLUT;
			this.BlendAmount = 0f;
			this.onFinishBlend = onFinishBlend;
			this.blendingTime = blendTimeInSec;
			this.blendingTimeCountdown = blendTimeInSec;
			this.blending = true;
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0002327C File Offset: 0x0002147C
		public void Start()
		{
			this.worldLUT = this.LutTexture;
			this.worldVolumeEffects = this.EffectFlags.GenerateEffectData(this);
			this.blendVolumeEffects = (this.currentVolumeEffects = this.worldVolumeEffects);
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x000232BC File Offset: 0x000214BC
		public void Update()
		{
			if (this.volumesBlending)
			{
				this.volumesBlendAmount = (this.volumesBlendingTime - this.volumesBlendingTimeCountdown) / this.volumesBlendingTime;
				this.volumesBlendingTimeCountdown -= Time.smoothDeltaTime;
				if (this.volumesBlendAmount >= 1f)
				{
					this.LutTexture = this.volumesLutBlendTexture;
					this.volumesBlendAmount = 0f;
					this.volumesBlending = false;
					this.volumesLutBlendTexture = null;
					this.effectVolumesBlendAdjust = 0f;
					this.currentVolumeEffects = this.blendVolumeEffects;
					this.currentVolumeEffects.SetValues(this);
					if (this.blendingFromMidBlend && this.midBlendLUT != null)
					{
						this.midBlendLUT.DiscardContents();
					}
					this.blendingFromMidBlend = false;
				}
			}
			else
			{
				this.volumesBlendAmount = Mathf.Clamp01(this.volumesBlendAmount);
			}
			if (this.blending)
			{
				this.BlendAmount = (this.blendingTime - this.blendingTimeCountdown) / this.blendingTime;
				this.blendingTimeCountdown -= Time.smoothDeltaTime;
				if (this.BlendAmount >= 1f)
				{
					this.LutTexture = this.LutBlendTexture;
					this.BlendAmount = 0f;
					this.blending = false;
					this.LutBlendTexture = null;
					if (this.onFinishBlend != null)
					{
						this.onFinishBlend();
					}
				}
			}
			else
			{
				this.BlendAmount = Mathf.Clamp01(this.BlendAmount);
			}
			if (this.UseVolumes)
			{
				if (this.actualTriggerProxy == null)
				{
					GameObject gameObject = new GameObject(base.name + "+ACVolumeProxy")
					{
						hideFlags = 61
					};
					this.actualTriggerProxy = gameObject.AddComponent<AmplifyColorTriggerProxy>();
					this.actualTriggerProxy.OwnerEffect = this;
				}
				this.UpdateVolumes();
			}
			else if (this.actualTriggerProxy != null)
			{
				Object.DestroyImmediate(this.actualTriggerProxy.gameObject);
				this.actualTriggerProxy = null;
			}
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x00005A0D File Offset: 0x00003C0D
		public void EnterVolume(AmplifyColorVolumeBase volume)
		{
			if (!this.enteredVolumes.Contains(volume))
			{
				this.enteredVolumes.Insert(0, volume);
			}
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x00005A2D File Offset: 0x00003C2D
		public void ExitVolume(AmplifyColorVolumeBase volume)
		{
			if (this.enteredVolumes.Contains(volume))
			{
				this.enteredVolumes.Remove(volume);
			}
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x000234BC File Offset: 0x000216BC
		private void UpdateVolumes()
		{
			if (this.volumesBlending)
			{
				this.currentVolumeEffects.BlendValues(this, this.blendVolumeEffects, this.effectVolumesBlendAdjusted);
			}
			Transform transform = ((!(this.TriggerVolumeProxy == null)) ? this.TriggerVolumeProxy : base.transform);
			if (this.actualTriggerProxy.transform.parent != transform)
			{
				this.actualTriggerProxy.Reference = transform;
				this.actualTriggerProxy.gameObject.layer = transform.gameObject.layer;
			}
			AmplifyColorVolumeBase amplifyColorVolumeBase = null;
			int num = int.MinValue;
			foreach (AmplifyColorVolumeBase amplifyColorVolumeBase2 in this.enteredVolumes)
			{
				if (amplifyColorVolumeBase2.Priority > num)
				{
					amplifyColorVolumeBase = amplifyColorVolumeBase2;
					num = amplifyColorVolumeBase2.Priority;
				}
			}
			if (amplifyColorVolumeBase != this.currentVolumeLut)
			{
				this.currentVolumeLut = amplifyColorVolumeBase;
				Texture texture = ((!(amplifyColorVolumeBase == null)) ? amplifyColorVolumeBase.LutTexture : this.worldLUT);
				float num2 = ((!(amplifyColorVolumeBase == null)) ? amplifyColorVolumeBase.EnterBlendTime : this.ExitVolumeBlendTime);
				if (this.volumesBlending && !this.blendingFromMidBlend && texture == this.LutTexture)
				{
					this.LutTexture = this.volumesLutBlendTexture;
					this.volumesLutBlendTexture = texture;
					this.volumesBlendingTimeCountdown = num2 * ((this.volumesBlendingTime - this.volumesBlendingTimeCountdown) / this.volumesBlendingTime);
					this.volumesBlendingTime = num2;
					this.currentVolumeEffects = VolumeEffect.BlendValuesToVolumeEffect(this.EffectFlags, this.currentVolumeEffects, this.blendVolumeEffects, this.effectVolumesBlendAdjusted);
					this.effectVolumesBlendAdjust = 1f - this.volumesBlendAmount;
					this.volumesBlendAmount = 1f - this.volumesBlendAmount;
				}
				else
				{
					if (this.volumesBlending)
					{
						this.materialBlendCache.SetFloat("_lerpAmount", this.volumesBlendAmount);
						if (this.blendingFromMidBlend)
						{
							Graphics.Blit(this.midBlendLUT, this.blendCacheLut);
							this.materialBlendCache.SetTexture("_RgbTex", this.blendCacheLut);
						}
						else
						{
							this.materialBlendCache.SetTexture("_RgbTex", this.LutTexture);
						}
						this.materialBlendCache.SetTexture("_LerpRgbTex", (!(this.volumesLutBlendTexture != null)) ? this.defaultLut : this.volumesLutBlendTexture);
						Graphics.Blit(this.midBlendLUT, this.midBlendLUT, this.materialBlendCache);
						this.blendCacheLut.DiscardContents();
						this.currentVolumeEffects = VolumeEffect.BlendValuesToVolumeEffect(this.EffectFlags, this.currentVolumeEffects, this.blendVolumeEffects, this.effectVolumesBlendAdjusted);
						this.effectVolumesBlendAdjust = 0f;
						this.blendingFromMidBlend = true;
					}
					this.VolumesBlendTo(texture, num2);
				}
				this.blendVolumeEffects = ((!(amplifyColorVolumeBase == null)) ? amplifyColorVolumeBase.EffectContainer.GetVolumeEffect(this) : this.worldVolumeEffects);
				if (this.blendVolumeEffects == null)
				{
					this.blendVolumeEffects = this.worldVolumeEffects;
				}
			}
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x000237FC File Offset: 0x000219FC
		private void SetupShader()
		{
			this.colorSpace = QualitySettings.activeColorSpace;
			this.qualityLevel = this.QualityLevel;
			string text = ((this.colorSpace != 1) ? string.Empty : "Linear");
			this.shaderBase = Shader.Find("Hidden/Amplify Color/Base" + text);
			this.shaderBlend = Shader.Find("Hidden/Amplify Color/Blend" + text);
			this.shaderBlendCache = Shader.Find("Hidden/Amplify Color/BlendCache");
			this.shaderMask = Shader.Find("Hidden/Amplify Color/Mask" + text);
			this.shaderBlendMask = Shader.Find("Hidden/Amplify Color/BlendMask" + text);
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x000238A4 File Offset: 0x00021AA4
		private void ReleaseMaterials()
		{
			if (this.materialBase != null)
			{
				Object.DestroyImmediate(this.materialBase);
				this.materialBase = null;
			}
			if (this.materialBlend != null)
			{
				Object.DestroyImmediate(this.materialBlend);
				this.materialBlend = null;
			}
			if (this.materialBlendCache != null)
			{
				Object.DestroyImmediate(this.materialBlendCache);
				this.materialBlendCache = null;
			}
			if (this.materialMask != null)
			{
				Object.DestroyImmediate(this.materialMask);
				this.materialMask = null;
			}
			if (this.materialBlendMask != null)
			{
				Object.DestroyImmediate(this.materialBlendMask);
				this.materialBlendMask = null;
			}
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x00023960 File Offset: 0x00021B60
		private Texture2D CreateDefaultLut()
		{
			this.defaultLut = new Texture2D(1024, 32, 3, false, true)
			{
				hideFlags = 61
			};
			this.defaultLut.name = "DefaultLut";
			this.defaultLut.hideFlags = 52;
			this.defaultLut.anisoLevel = 1;
			this.defaultLut.filterMode = 1;
			Color32[] array = new Color32[32768];
			for (int i = 0; i < 32; i++)
			{
				int num = i * 32;
				for (int j = 0; j < 32; j++)
				{
					int num2 = num + j * 1024;
					for (int k = 0; k < 32; k++)
					{
						float num3 = (float)k / 31f;
						float num4 = (float)j / 31f;
						float num5 = (float)i / 31f;
						byte b = (byte)(num3 * 255f);
						byte b2 = (byte)(num4 * 255f);
						byte b3 = (byte)(num5 * 255f);
						array[num2 + k] = new Color32(b, b2, b3, byte.MaxValue);
					}
				}
			}
			this.defaultLut.SetPixels32(array);
			this.defaultLut.Apply();
			return this.defaultLut;
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x00023A9C File Offset: 0x00021C9C
		private void CreateHelperTextures()
		{
			this.ReleaseTextures();
			this.blendCacheLut = new RenderTexture(1024, 32, 0, 0, 1)
			{
				hideFlags = 61
			};
			this.blendCacheLut.name = "BlendCacheLut";
			this.blendCacheLut.wrapMode = 1;
			this.blendCacheLut.useMipMap = false;
			this.blendCacheLut.anisoLevel = 0;
			this.blendCacheLut.Create();
			this.midBlendLUT = new RenderTexture(1024, 32, 0, 0, 1)
			{
				hideFlags = 61
			};
			this.midBlendLUT.name = "MidBlendLut";
			this.midBlendLUT.wrapMode = 1;
			this.midBlendLUT.useMipMap = false;
			this.midBlendLUT.anisoLevel = 0;
			this.midBlendLUT.Create();
			this.CreateDefaultLut();
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x00023B74 File Offset: 0x00021D74
		private bool CheckMaterialAndShader(Material material, string name)
		{
			if (material == null || material.shader == null)
			{
				Debug.LogError("[AmplifyColor] Error creating " + name + " material. Effect disabled.");
			}
			else if (!material.shader.isSupported)
			{
				Debug.LogError("[AmplifyColor] " + name + " shader not supported on this platform. Effect disabled.");
			}
			else
			{
				material.hideFlags = 61;
			}
			return base.enabled;
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x00005A4D File Offset: 0x00003C4D
		private void SwitchToMobile(Material mat)
		{
			mat.EnableKeyword("AC_QUALITY_MOBILE");
			mat.DisableKeyword("AC_QUALITY_STANDARD");
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x00005A65 File Offset: 0x00003C65
		private void SwitchToStandard(Material mat)
		{
			mat.EnableKeyword("AC_QUALITY_STANDARD");
			mat.DisableKeyword("AC_QUALITY_MOBILE");
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x00023BF0 File Offset: 0x00021DF0
		private bool CreateMaterials()
		{
			this.SetupShader();
			if (!this.CheckShaders())
			{
				return false;
			}
			this.ReleaseMaterials();
			this.materialBase = new Material(this.shaderBase);
			this.materialBlend = new Material(this.shaderBlend);
			this.materialBlendCache = new Material(this.shaderBlendCache);
			this.materialMask = new Material(this.shaderMask);
			this.materialBlendMask = new Material(this.shaderBlendMask);
			bool flag = true;
			flag = flag && this.CheckMaterialAndShader(this.materialBase, "BaseMaterial");
			flag = flag && this.CheckMaterialAndShader(this.materialBlend, "BlendMaterial");
			flag = flag && this.CheckMaterialAndShader(this.materialBlendCache, "BlendCacheMaterial");
			flag = flag && this.CheckMaterialAndShader(this.materialMask, "MaskMaterial");
			if (!flag || !this.CheckMaterialAndShader(this.materialBlendMask, "BlendMaskMaterial"))
			{
				return false;
			}
			if (this.QualityLevel == Quality.Mobile)
			{
				this.SwitchToMobile(this.materialBase);
				this.SwitchToMobile(this.materialBlend);
				this.SwitchToMobile(this.materialBlendCache);
				this.SwitchToMobile(this.materialMask);
				this.SwitchToMobile(this.materialBlendMask);
			}
			else
			{
				this.SwitchToStandard(this.materialBase);
				this.SwitchToStandard(this.materialBlend);
				this.SwitchToStandard(this.materialBlendCache);
				this.SwitchToStandard(this.materialMask);
				this.SwitchToStandard(this.materialBlendMask);
			}
			this.CreateHelperTextures();
			return true;
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x00023D8C File Offset: 0x00021F8C
		private void ReleaseTextures()
		{
			if (this.blendCacheLut != null)
			{
				Object.DestroyImmediate(this.blendCacheLut);
				this.blendCacheLut = null;
			}
			if (this.midBlendLUT != null)
			{
				Object.DestroyImmediate(this.midBlendLUT);
				this.midBlendLUT = null;
			}
			if (this.defaultLut != null)
			{
				Object.DestroyImmediate(this.defaultLut);
				this.defaultLut = null;
			}
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x00023E04 File Offset: 0x00022004
		public static bool ValidateLutDimensions(Texture lut)
		{
			bool flag = true;
			if (lut != null)
			{
				if (lut.width / lut.height != lut.height)
				{
					Debug.LogWarning("[AmplifyColor] Lut " + lut.name + " has invalid dimensions.");
					flag = false;
				}
				else if (lut.anisoLevel != 0)
				{
					lut.anisoLevel = 0;
				}
			}
			return flag;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x00023E6C File Offset: 0x0002206C
		public void OnRenderImage(RenderTexture source, RenderTexture destination)
		{
			this.BlendAmount = Mathf.Clamp01(this.BlendAmount);
			if (this.colorSpace != QualitySettings.activeColorSpace || this.qualityLevel != this.QualityLevel)
			{
				this.CreateMaterials();
			}
			bool flag = AmplifyColorBase.ValidateLutDimensions(this.LutTexture);
			bool flag2 = AmplifyColorBase.ValidateLutDimensions(this.LutBlendTexture);
			bool flag3 = this.LutTexture == null && this.LutBlendTexture == null && this.volumesLutBlendTexture == null;
			if (!flag || !flag2 || flag3)
			{
				Graphics.Blit(source, destination);
				return;
			}
			Texture texture = ((!(this.LutTexture == null)) ? this.LutTexture : this.defaultLut);
			Texture lutBlendTexture = this.LutBlendTexture;
			int num = (base.GetComponent<Camera>().allowHDR ? 1 : 0);
			bool flag4 = this.BlendAmount != 0f || this.blending;
			bool flag5 = flag4 || (flag4 && lutBlendTexture != null);
			bool flag6 = flag5;
			Material material;
			if (flag5 || this.volumesBlending)
			{
				if (this.MaskTexture != null)
				{
					material = this.materialBlendMask;
				}
				else
				{
					material = this.materialBlend;
				}
			}
			else if (this.MaskTexture != null)
			{
				material = this.materialMask;
			}
			else
			{
				material = this.materialBase;
			}
			material.SetFloat("_lerpAmount", this.BlendAmount);
			if (this.MaskTexture != null)
			{
				material.SetTexture("_MaskTex", this.MaskTexture);
			}
			if (this.volumesBlending)
			{
				this.volumesBlendAmount = Mathf.Clamp01(this.volumesBlendAmount);
				this.materialBlendCache.SetFloat("_lerpAmount", this.volumesBlendAmount);
				if (this.blendingFromMidBlend)
				{
					this.materialBlendCache.SetTexture("_RgbTex", this.midBlendLUT);
				}
				else
				{
					this.materialBlendCache.SetTexture("_RgbTex", texture);
				}
				this.materialBlendCache.SetTexture("_LerpRgbTex", (!(this.volumesLutBlendTexture != null)) ? this.defaultLut : this.volumesLutBlendTexture);
				Graphics.Blit(texture, this.blendCacheLut, this.materialBlendCache);
			}
			if (flag6)
			{
				this.materialBlendCache.SetFloat("_lerpAmount", this.BlendAmount);
				RenderTexture renderTexture = null;
				if (this.volumesBlending)
				{
					renderTexture = RenderTexture.GetTemporary(this.blendCacheLut.width, this.blendCacheLut.height, this.blendCacheLut.depth, this.blendCacheLut.format, 1);
					Graphics.Blit(this.blendCacheLut, renderTexture);
					this.materialBlendCache.SetTexture("_RgbTex", renderTexture);
				}
				else
				{
					this.materialBlendCache.SetTexture("_RgbTex", texture);
				}
				this.materialBlendCache.SetTexture("_LerpRgbTex", (!(lutBlendTexture != null)) ? this.defaultLut : lutBlendTexture);
				Graphics.Blit(texture, this.blendCacheLut, this.materialBlendCache);
				if (renderTexture != null)
				{
					RenderTexture.ReleaseTemporary(renderTexture);
				}
				material.SetTexture("_RgbBlendCacheTex", this.blendCacheLut);
			}
			else if (this.volumesBlending)
			{
				material.SetTexture("_RgbBlendCacheTex", this.blendCacheLut);
			}
			else
			{
				if (texture != null)
				{
					material.SetTexture("_RgbTex", texture);
				}
				if (lutBlendTexture != null)
				{
					material.SetTexture("_LerpRgbTex", lutBlendTexture);
				}
			}
			Graphics.Blit(source, destination, material, num);
			if (flag6 || this.volumesBlending)
			{
				this.blendCacheLut.DiscardContents();
			}
		}

		// Token: 0x04000736 RID: 1846
		public const int LutSize = 32;

		// Token: 0x04000737 RID: 1847
		public const int LutWidth = 1024;

		// Token: 0x04000738 RID: 1848
		public const int LutHeight = 32;

		// Token: 0x04000739 RID: 1849
		public Quality QualityLevel = Quality.Standard;

		// Token: 0x0400073A RID: 1850
		public float BlendAmount;

		// Token: 0x0400073B RID: 1851
		public Texture LutTexture;

		// Token: 0x0400073C RID: 1852
		public Texture LutBlendTexture;

		// Token: 0x0400073D RID: 1853
		public Texture MaskTexture;

		// Token: 0x0400073E RID: 1854
		public bool UseVolumes;

		// Token: 0x0400073F RID: 1855
		public float ExitVolumeBlendTime = 1f;

		// Token: 0x04000740 RID: 1856
		public Transform TriggerVolumeProxy;

		// Token: 0x04000741 RID: 1857
		public LayerMask VolumeCollisionMask = -1;

		// Token: 0x04000742 RID: 1858
		private Shader shaderBase;

		// Token: 0x04000743 RID: 1859
		private Shader shaderBlend;

		// Token: 0x04000744 RID: 1860
		private Shader shaderBlendCache;

		// Token: 0x04000745 RID: 1861
		private Shader shaderMask;

		// Token: 0x04000746 RID: 1862
		private Shader shaderBlendMask;

		// Token: 0x04000747 RID: 1863
		private RenderTexture blendCacheLut;

		// Token: 0x04000748 RID: 1864
		private Texture2D defaultLut;

		// Token: 0x04000749 RID: 1865
		private ColorSpace colorSpace = -1;

		// Token: 0x0400074A RID: 1866
		private Quality qualityLevel = Quality.Standard;

		// Token: 0x0400074B RID: 1867
		private Material materialBase;

		// Token: 0x0400074C RID: 1868
		private Material materialBlend;

		// Token: 0x0400074D RID: 1869
		private Material materialBlendCache;

		// Token: 0x0400074E RID: 1870
		private Material materialMask;

		// Token: 0x0400074F RID: 1871
		private Material materialBlendMask;

		// Token: 0x04000750 RID: 1872
		private bool blending;

		// Token: 0x04000751 RID: 1873
		private float blendingTime;

		// Token: 0x04000752 RID: 1874
		private float blendingTimeCountdown;

		// Token: 0x04000753 RID: 1875
		private Action onFinishBlend;

		// Token: 0x04000754 RID: 1876
		private bool volumesBlending;

		// Token: 0x04000755 RID: 1877
		private float volumesBlendingTime;

		// Token: 0x04000756 RID: 1878
		private float volumesBlendingTimeCountdown;

		// Token: 0x04000757 RID: 1879
		private Texture volumesLutBlendTexture;

		// Token: 0x04000758 RID: 1880
		private float volumesBlendAmount;

		// Token: 0x04000759 RID: 1881
		private Texture worldLUT;

		// Token: 0x0400075A RID: 1882
		private AmplifyColorVolumeBase currentVolumeLut;

		// Token: 0x0400075B RID: 1883
		private RenderTexture midBlendLUT;

		// Token: 0x0400075C RID: 1884
		private bool blendingFromMidBlend;

		// Token: 0x0400075D RID: 1885
		private VolumeEffect worldVolumeEffects;

		// Token: 0x0400075E RID: 1886
		private VolumeEffect currentVolumeEffects;

		// Token: 0x0400075F RID: 1887
		private VolumeEffect blendVolumeEffects;

		// Token: 0x04000760 RID: 1888
		private float effectVolumesBlendAdjust;

		// Token: 0x04000761 RID: 1889
		private List<AmplifyColorVolumeBase> enteredVolumes = new List<AmplifyColorVolumeBase>();

		// Token: 0x04000762 RID: 1890
		private AmplifyColorTriggerProxy actualTriggerProxy;

		// Token: 0x04000763 RID: 1891
		[HideInInspector]
		public VolumeEffectFlags EffectFlags = new VolumeEffectFlags();

		// Token: 0x04000764 RID: 1892
		[SerializeField]
		[HideInInspector]
		private string sharedInstanceID = string.Empty;
	}
}
