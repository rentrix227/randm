﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing
{
	// Token: 0x020000F2 RID: 242
	[ImageEffectTransformsToLDR]
	[ExecuteInEditMode]
	[AddComponentMenu("Image Effects/Amplify Color")]
	public sealed class AmplifyColorEffect : AmplifyColorBase
	{
	}
}
