﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing
{
	// Token: 0x020000F3 RID: 243
	[RequireComponent(typeof(Rigidbody))]
	[RequireComponent(typeof(SphereCollider))]
	[AddComponentMenu("")]
	public class AmplifyColorTriggerProxy : MonoBehaviour
	{
		// Token: 0x060004C8 RID: 1224 RVA: 0x00024258 File Offset: 0x00022458
		public void Start()
		{
			this.sphereCollider = base.GetComponent<SphereCollider>();
			this.sphereCollider.radius = 0.01f;
			this.sphereCollider.isTrigger = true;
			this.rigidBody = base.GetComponent<Rigidbody>();
			this.rigidBody.useGravity = false;
			this.rigidBody.isKinematic = true;
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x00005A85 File Offset: 0x00003C85
		public void LateUpdate()
		{
			base.transform.position = this.Reference.position;
			base.transform.rotation = this.Reference.rotation;
		}

		// Token: 0x04000765 RID: 1893
		public Transform Reference;

		// Token: 0x04000766 RID: 1894
		public AmplifyColorBase OwnerEffect;

		// Token: 0x04000767 RID: 1895
		private SphereCollider sphereCollider;

		// Token: 0x04000768 RID: 1896
		private Rigidbody rigidBody;
	}
}
