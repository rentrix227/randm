﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Aquiris.Ballistic.Game.PostProcessing.AmplifyColor
{
	// Token: 0x02000103 RID: 259
	[Serializable]
	public class VolumeEffectContainer
	{
		// Token: 0x06000503 RID: 1283 RVA: 0x00005CC3 File Offset: 0x00003EC3
		public VolumeEffectContainer()
		{
			this.volumes = new List<VolumeEffect>();
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x0002537C File Offset: 0x0002357C
		public void AddColorEffect(AmplifyColorBase colorEffect)
		{
			VolumeEffect volumeEffect;
			if ((volumeEffect = this.volumes.Find((VolumeEffect s) => s.gameObject == colorEffect)) != null)
			{
				volumeEffect.UpdateVolume();
			}
			else
			{
				volumeEffect = new VolumeEffect(colorEffect);
				this.volumes.Add(volumeEffect);
				volumeEffect.UpdateVolume();
			}
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x000253E0 File Offset: 0x000235E0
		public VolumeEffect AddJustColorEffect(AmplifyColorBase colorEffect)
		{
			VolumeEffect volumeEffect = new VolumeEffect(colorEffect);
			this.volumes.Add(volumeEffect);
			return volumeEffect;
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00025404 File Offset: 0x00023604
		public VolumeEffect GetVolumeEffect(AmplifyColorBase colorEffect)
		{
			VolumeEffect volumeEffect = this.volumes.Find((VolumeEffect s) => s.gameObject == colorEffect);
			if (volumeEffect == null)
			{
				volumeEffect = this.volumes.Find((VolumeEffect s) => s.gameObject != null && s.gameObject.SharedInstanceID == colorEffect.SharedInstanceID);
			}
			return volumeEffect;
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00005CD6 File Offset: 0x00003ED6
		public void RemoveVolumeEffect(VolumeEffect volume)
		{
			this.volumes.Remove(volume);
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x00005CE5 File Offset: 0x00003EE5
		public AmplifyColorBase[] GetStoredEffects()
		{
			return this.volumes.Select((VolumeEffect r) => r.gameObject).ToArray<AmplifyColorBase>();
		}

		// Token: 0x04000788 RID: 1928
		public List<VolumeEffect> volumes;
	}
}
