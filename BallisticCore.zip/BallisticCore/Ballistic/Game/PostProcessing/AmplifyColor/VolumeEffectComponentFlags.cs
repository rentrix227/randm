﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing.AmplifyColor
{
	// Token: 0x02000107 RID: 263
	[Serializable]
	public class VolumeEffectComponentFlags
	{
		// Token: 0x06000511 RID: 1297 RVA: 0x00005DBF File Offset: 0x00003FBF
		public VolumeEffectComponentFlags(string name)
		{
			this.componentName = name;
			this.componentFields = new List<VolumeEffectFieldFlags>();
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x00025458 File Offset: 0x00023658
		public VolumeEffectComponentFlags(VolumeEffectComponent comp)
			: this(comp.componentName)
		{
			this.blendFlag = true;
			foreach (VolumeEffectField volumeEffectField in comp.fields)
			{
				if (VolumeEffectField.IsValidType(volumeEffectField.fieldType))
				{
					this.componentFields.Add(new VolumeEffectFieldFlags(volumeEffectField));
				}
			}
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x000254E4 File Offset: 0x000236E4
		public VolumeEffectComponentFlags(Component c)
			: this(c.GetType() + string.Empty)
		{
			FieldInfo[] fields = c.GetType().GetFields();
			foreach (FieldInfo fieldInfo in fields)
			{
				if (VolumeEffectField.IsValidType(fieldInfo.FieldType.FullName))
				{
					this.componentFields.Add(new VolumeEffectFieldFlags(fieldInfo));
				}
			}
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x00025554 File Offset: 0x00023754
		public void UpdateComponentFlags(VolumeEffectComponent comp)
		{
			using (List<VolumeEffectField>.Enumerator enumerator = comp.fields.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					VolumeEffectField field = enumerator.Current;
					if (this.componentFields.Find((VolumeEffectFieldFlags s) => s.fieldName == field.fieldName) == null && VolumeEffectField.IsValidType(field.fieldType))
					{
						this.componentFields.Add(new VolumeEffectFieldFlags(field));
					}
				}
			}
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x000255FC File Offset: 0x000237FC
		public void UpdateComponentFlags(Component c)
		{
			FieldInfo[] fields = c.GetType().GetFields();
			FieldInfo[] array = fields;
			for (int i = 0; i < array.Length; i++)
			{
				FieldInfo pi = array[i];
				if (!this.componentFields.Exists((VolumeEffectFieldFlags s) => s.fieldName == pi.Name) && VolumeEffectField.IsValidType(pi.FieldType.FullName))
				{
					this.componentFields.Add(new VolumeEffectFieldFlags(pi));
				}
			}
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00025688 File Offset: 0x00023888
		public string[] GetFieldNames()
		{
			return (from r in this.componentFields
				where r.blendFlag
				select r.fieldName).ToArray<string>();
		}

		// Token: 0x0400078F RID: 1935
		public string componentName;

		// Token: 0x04000790 RID: 1936
		public List<VolumeEffectFieldFlags> componentFields;

		// Token: 0x04000791 RID: 1937
		public bool blendFlag;
	}
}
