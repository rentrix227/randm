﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing.AmplifyColor
{
	// Token: 0x020000F7 RID: 247
	[Serializable]
	public class VolumeEffectComponent
	{
		// Token: 0x060004D4 RID: 1236 RVA: 0x00005AF6 File Offset: 0x00003CF6
		public VolumeEffectComponent(string name)
		{
			this.componentName = name;
			this.fields = new List<VolumeEffectField>();
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x000245DC File Offset: 0x000227DC
		public VolumeEffectComponent(Component c, VolumeEffectComponentFlags compFlags)
			: this(compFlags.componentName)
		{
			foreach (VolumeEffectFieldFlags volumeEffectFieldFlags in compFlags.componentFields)
			{
				if (volumeEffectFieldFlags.blendFlag)
				{
					FieldInfo field = c.GetType().GetField(volumeEffectFieldFlags.fieldName);
					VolumeEffectField volumeEffectField = ((!VolumeEffectField.IsValidType(field.FieldType.FullName)) ? null : new VolumeEffectField(field, c));
					if (volumeEffectField != null)
					{
						this.fields.Add(volumeEffectField);
					}
				}
			}
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x00005B10 File Offset: 0x00003D10
		public VolumeEffectField AddField(FieldInfo pi, Component c)
		{
			return this.AddField(pi, c, -1);
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x00024694 File Offset: 0x00022894
		public VolumeEffectField AddField(FieldInfo pi, Component c, int position)
		{
			VolumeEffectField volumeEffectField = ((!VolumeEffectField.IsValidType(pi.FieldType.FullName)) ? null : new VolumeEffectField(pi, c));
			if (volumeEffectField != null)
			{
				if (position < 0 || position >= this.fields.Count)
				{
					this.fields.Add(volumeEffectField);
				}
				else
				{
					this.fields.Insert(position, volumeEffectField);
				}
			}
			return volumeEffectField;
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x00005B1B File Offset: 0x00003D1B
		public void RemoveEffectField(VolumeEffectField field)
		{
			this.fields.Remove(field);
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x00024704 File Offset: 0x00022904
		public void UpdateComponent(Component c, VolumeEffectComponentFlags compFlags)
		{
			using (List<VolumeEffectFieldFlags>.Enumerator enumerator = compFlags.componentFields.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					VolumeEffectFieldFlags fieldFlags = enumerator.Current;
					if (fieldFlags.blendFlag)
					{
						if (!this.fields.Exists((VolumeEffectField s) => s.fieldName == fieldFlags.fieldName))
						{
							FieldInfo field = c.GetType().GetField(fieldFlags.fieldName);
							VolumeEffectField volumeEffectField = ((!VolumeEffectField.IsValidType(field.FieldType.FullName)) ? null : new VolumeEffectField(field, c));
							if (volumeEffectField != null)
							{
								this.fields.Add(volumeEffectField);
							}
						}
					}
				}
			}
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x000247E4 File Offset: 0x000229E4
		public VolumeEffectField GetEffectField(string fieldName)
		{
			return this.fields.Find((VolumeEffectField s) => s.fieldName == fieldName);
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x00024818 File Offset: 0x00022A18
		public static FieldInfo[] ListAcceptableFields(Component c)
		{
			if (c == null)
			{
				return new FieldInfo[0];
			}
			FieldInfo[] array = c.GetType().GetFields();
			return array.Where((FieldInfo f) => VolumeEffectField.IsValidType(f.FieldType.FullName)).ToArray<FieldInfo>();
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x00005B2A File Offset: 0x00003D2A
		public string[] GetFieldNames()
		{
			return this.fields.Select((VolumeEffectField r) => r.fieldName).ToArray<string>();
		}

		// Token: 0x04000776 RID: 1910
		public string componentName;

		// Token: 0x04000777 RID: 1911
		public List<VolumeEffectField> fields;
	}
}
