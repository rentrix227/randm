﻿using System;
using System.Reflection;

namespace Aquiris.Ballistic.Game.PostProcessing.AmplifyColor
{
	// Token: 0x02000106 RID: 262
	[Serializable]
	public class VolumeEffectFieldFlags
	{
		// Token: 0x0600050F RID: 1295 RVA: 0x00005D73 File Offset: 0x00003F73
		public VolumeEffectFieldFlags(FieldInfo pi)
		{
			this.fieldName = pi.Name;
			this.fieldType = pi.FieldType.FullName;
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x00005D98 File Offset: 0x00003F98
		public VolumeEffectFieldFlags(VolumeEffectField field)
		{
			this.fieldName = field.fieldName;
			this.fieldType = field.fieldType;
			this.blendFlag = true;
		}

		// Token: 0x0400078C RID: 1932
		public string fieldName;

		// Token: 0x0400078D RID: 1933
		public string fieldType;

		// Token: 0x0400078E RID: 1934
		public bool blendFlag;
	}
}
