﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing.AmplifyColor
{
	// Token: 0x0200010A RID: 266
	[Serializable]
	public class VolumeEffectFlags
	{
		// Token: 0x0600051D RID: 1309 RVA: 0x00005E19 File Offset: 0x00004019
		public VolumeEffectFlags()
		{
			this.components = new List<VolumeEffectComponentFlags>();
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x000256E4 File Offset: 0x000238E4
		public void AddComponent(Component c)
		{
			VolumeEffectComponentFlags volumeEffectComponentFlags;
			if ((volumeEffectComponentFlags = this.components.Find((VolumeEffectComponentFlags s) => s.componentName == c.GetType() + string.Empty)) != null)
			{
				volumeEffectComponentFlags.UpdateComponentFlags(c);
			}
			else
			{
				this.components.Add(new VolumeEffectComponentFlags(c));
			}
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x00025744 File Offset: 0x00023944
		public void UpdateFlags(VolumeEffect effectVol)
		{
			using (List<VolumeEffectComponent>.Enumerator enumerator = effectVol.components.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					VolumeEffectComponent comp = enumerator.Current;
					VolumeEffectComponentFlags volumeEffectComponentFlags;
					if ((volumeEffectComponentFlags = this.components.Find((VolumeEffectComponentFlags s) => s.componentName == comp.componentName)) == null)
					{
						this.components.Add(new VolumeEffectComponentFlags(comp));
					}
					else
					{
						volumeEffectComponentFlags.UpdateComponentFlags(comp);
					}
				}
			}
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x000257EC File Offset: 0x000239EC
		public static void UpdateCamFlags(AmplifyColorBase[] effects, AmplifyColorVolumeBase[] volumes)
		{
			foreach (AmplifyColorBase amplifyColorBase in effects)
			{
				amplifyColorBase.EffectFlags = new VolumeEffectFlags();
				foreach (AmplifyColorVolumeBase amplifyColorVolumeBase in volumes)
				{
					VolumeEffect volumeEffect = amplifyColorVolumeBase.EffectContainer.GetVolumeEffect(amplifyColorBase);
					if (volumeEffect != null)
					{
						amplifyColorBase.EffectFlags.UpdateFlags(volumeEffect);
					}
				}
			}
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x00025864 File Offset: 0x00023A64
		public VolumeEffect GenerateEffectData(AmplifyColorBase go)
		{
			VolumeEffect volumeEffect = new VolumeEffect(go);
			foreach (VolumeEffectComponentFlags volumeEffectComponentFlags in this.components)
			{
				if (volumeEffectComponentFlags.blendFlag)
				{
					Component component = go.GetComponent(volumeEffectComponentFlags.componentName);
					if (component != null)
					{
						volumeEffect.AddComponent(component, volumeEffectComponentFlags);
					}
				}
			}
			return volumeEffect;
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x000258F4 File Offset: 0x00023AF4
		public VolumeEffectComponentFlags GetComponentFlags(string compName)
		{
			return this.components.Find((VolumeEffectComponentFlags s) => s.componentName == compName);
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x00025928 File Offset: 0x00023B28
		public string[] GetComponentNames()
		{
			return (from r in this.components
				where r.blendFlag
				select r.componentName).ToArray<string>();
		}

		// Token: 0x04000796 RID: 1942
		public List<VolumeEffectComponentFlags> components;
	}
}
