﻿using System;
using System.Reflection;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing.AmplifyColor
{
	// Token: 0x020000F6 RID: 246
	[Serializable]
	public class VolumeEffectField
	{
		// Token: 0x060004D0 RID: 1232 RVA: 0x00005AE0 File Offset: 0x00003CE0
		public VolumeEffectField(string fieldName, string fieldType)
		{
			this.fieldName = fieldName;
			this.fieldType = fieldType;
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00024444 File Offset: 0x00022644
		public VolumeEffectField(FieldInfo pi, Component c)
			: this(pi.Name, pi.FieldType.FullName)
		{
			object value = pi.GetValue(c);
			this.UpdateValue(value);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00024478 File Offset: 0x00022678
		public static bool IsValidType(string type)
		{
			if (type != null)
			{
				if (type == "System.Single" || type == "System.Boolean" || type == "UnityEngine.Color" || type == "UnityEngine.Vector2" || type == "UnityEngine.Vector3" || type == "UnityEngine.Vector4")
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x000244F4 File Offset: 0x000226F4
		public void UpdateValue(object val)
		{
			string text = this.fieldType;
			if (text != null)
			{
				if (!(text == "System.Single"))
				{
					if (!(text == "System.Boolean"))
					{
						if (!(text == "UnityEngine.Color"))
						{
							if (!(text == "UnityEngine.Vector2"))
							{
								if (!(text == "UnityEngine.Vector3"))
								{
									if (text == "UnityEngine.Vector4")
									{
										this.valueVector4 = (Vector4)val;
									}
								}
								else
								{
									this.valueVector3 = (Vector3)val;
								}
							}
							else
							{
								this.valueVector2 = (Vector2)val;
							}
						}
						else
						{
							this.valueColor = (Color)val;
						}
					}
					else
					{
						this.valueBoolean = (bool)val;
					}
				}
				else
				{
					this.valueSingle = (float)val;
				}
			}
		}

		// Token: 0x0400076E RID: 1902
		public string fieldName;

		// Token: 0x0400076F RID: 1903
		public string fieldType;

		// Token: 0x04000770 RID: 1904
		public float valueSingle;

		// Token: 0x04000771 RID: 1905
		public Color valueColor;

		// Token: 0x04000772 RID: 1906
		public bool valueBoolean;

		// Token: 0x04000773 RID: 1907
		public Vector2 valueVector2;

		// Token: 0x04000774 RID: 1908
		public Vector3 valueVector3;

		// Token: 0x04000775 RID: 1909
		public Vector4 valueVector4;
	}
}
