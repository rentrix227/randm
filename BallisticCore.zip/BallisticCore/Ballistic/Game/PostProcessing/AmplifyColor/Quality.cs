﻿using System;

namespace Aquiris.Ballistic.Game.PostProcessing.AmplifyColor
{
	// Token: 0x020000F0 RID: 240
	public enum Quality
	{
		// Token: 0x04000734 RID: 1844
		Mobile,
		// Token: 0x04000735 RID: 1845
		Standard
	}
}
