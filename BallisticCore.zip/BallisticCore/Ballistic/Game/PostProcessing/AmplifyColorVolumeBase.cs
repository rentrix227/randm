﻿using System;
using Aquiris.Ballistic.Game.PostProcessing.AmplifyColor;
using UnityEngine;

namespace Aquiris.Ballistic.Game.PostProcessing
{
	// Token: 0x020000F5 RID: 245
	[AddComponentMenu("")]
	public class AmplifyColorVolumeBase : MonoBehaviour
	{
		// Token: 0x060004CE RID: 1230 RVA: 0x0002437C File Offset: 0x0002257C
		private void OnDrawGizmos()
		{
			if (this.ShowInSceneView)
			{
				BoxCollider component = base.GetComponent<BoxCollider>();
				if (component != null)
				{
					Gizmos.color = Color.green;
					Gizmos.DrawIcon(base.transform.position, "lut-volume.png", true);
					Gizmos.matrix = base.transform.localToWorldMatrix;
					Gizmos.DrawWireCube(component.center, component.size);
				}
			}
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x000243E8 File Offset: 0x000225E8
		private void OnDrawGizmosSelected()
		{
			BoxCollider component = base.GetComponent<BoxCollider>();
			if (component != null)
			{
				Color green = Color.green;
				green.a = 0.2f;
				Gizmos.color = green;
				Gizmos.matrix = base.transform.localToWorldMatrix;
				Gizmos.DrawCube(component.center, component.size);
			}
		}

		// Token: 0x04000769 RID: 1897
		public Texture2D LutTexture;

		// Token: 0x0400076A RID: 1898
		public float EnterBlendTime = 1f;

		// Token: 0x0400076B RID: 1899
		public int Priority;

		// Token: 0x0400076C RID: 1900
		public bool ShowInSceneView = true;

		// Token: 0x0400076D RID: 1901
		[HideInInspector]
		public VolumeEffectContainer EffectContainer = new VolumeEffectContainer();
	}
}
