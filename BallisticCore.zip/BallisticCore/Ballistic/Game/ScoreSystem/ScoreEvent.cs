﻿using System;

namespace Aquiris.Ballistic.Game.ScoreSystem
{
	// Token: 0x0200011A RID: 282
	public enum ScoreEvent
	{
		// Token: 0x0400080A RID: 2058
		None = -1,
		// Token: 0x0400080B RID: 2059
		Kill,
		// Token: 0x0400080C RID: 2060
		KillAssist,
		// Token: 0x0400080D RID: 2061
		CriticalKillAssist,
		// Token: 0x0400080E RID: 2062
		KillStreak5,
		// Token: 0x0400080F RID: 2063
		KillStreak10,
		// Token: 0x04000810 RID: 2064
		KillStreak25,
		// Token: 0x04000811 RID: 2065
		ExpertKill,
		// Token: 0x04000812 RID: 2066
		HeadShot,
		// Token: 0x04000813 RID: 2067
		Backstab,
		// Token: 0x04000814 RID: 2068
		LongHeadshot,
		// Token: 0x04000815 RID: 2069
		CapturePoint,
		// Token: 0x04000816 RID: 2070
		DefenseKill,
		// Token: 0x04000817 RID: 2071
		DoubleKill,
		// Token: 0x04000818 RID: 2072
		TripleKill,
		// Token: 0x04000819 RID: 2073
		MultiKill,
		// Token: 0x0400081A RID: 2074
		AvengerKill,
		// Token: 0x0400081B RID: 2075
		SaviorKill
	}
}
