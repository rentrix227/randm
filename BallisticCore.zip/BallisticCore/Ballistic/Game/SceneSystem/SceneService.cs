﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerWeaponModel;
using Aquiris.UI.Base;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Aquiris.Ballistic.Game.SceneSystem
{
	// Token: 0x02000115 RID: 277
	public class SceneService : IService
	{
		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600054D RID: 1357 RVA: 0x000268B0 File Offset: 0x00024AB0
		// (remove) Token: 0x0600054E RID: 1358 RVA: 0x000268E8 File Offset: 0x00024AE8
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action<MapLoadProgress> OnMapLoading;

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x0600054F RID: 1359 RVA: 0x00026920 File Offset: 0x00024B20
		// (remove) Token: 0x06000550 RID: 1360 RVA: 0x00026958 File Offset: 0x00024B58
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action<EBaseScene> OnSceneLoaded;

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x06000551 RID: 1361 RVA: 0x00026990 File Offset: 0x00024B90
		// (remove) Token: 0x06000552 RID: 1362 RVA: 0x000269C8 File Offset: 0x00024BC8
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action OnLeaveGameScene;

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000553 RID: 1363 RVA: 0x00005FFC File Offset: 0x000041FC
		internal bool IsLoadingScene
		{
			get
			{
				return this._loadingCoroutine.Count > 0 || this._loadingCurrent != null;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000554 RID: 1364 RVA: 0x0000601E File Offset: 0x0000421E
		// (set) Token: 0x06000555 RID: 1365 RVA: 0x00006026 File Offset: 0x00004226
		internal EBaseScene CurrentScene { get; private set; }

		// Token: 0x06000556 RID: 1366 RVA: 0x00026A00 File Offset: 0x00024C00
		internal override void Preprocess()
		{
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnMapLoad.AddListener(new Action<MapLoadEvent>(this.OnMapLoad));
			this._networkGameService.OnVoteEnd.AddListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			this._eventProxy.StartCoroutine(this.Update());
			this._currentAssetBundle = null;
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x00026A74 File Offset: 0x00024C74
		internal override void Postprocess()
		{
			this._networkGameService.OnMapLoad.RemoveListener(new Action<MapLoadEvent>(this.OnMapLoad));
			this._networkGameService.OnVoteEnd.RemoveListener(new Action<VoteMapEndEvent>(this.OnVoteEnd));
			if (this._currentAssetBundle != null)
			{
				this._currentAssetBundle.Unload(true);
			}
			this._currentAssetBundle = null;
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x00026AE0 File Offset: 0x00024CE0
		private void OnMapLoad(MapLoadEvent evt)
		{
			Debug.Log("Loading map checking...");
			if (this._networkGameService.IsConnected() && this._networkGameService.LoadMapAutomatically)
			{
				Debug.Log("Loading map...");
				this.LoadMap(evt.GameMapId, evt.GameMode);
			}
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x00026B34 File Offset: 0x00024D34
		private IEnumerator Update()
		{
			for (;;)
			{
				while (this._loadingCoroutine.Count > 0)
				{
					this._loadingCurrent = this._eventProxy.StartCoroutine(this._loadingCoroutine.Dequeue());
					yield return this._loadingCurrent;
					this._loadingCurrent = null;
					yield return new WaitForSeconds(1f);
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x0000602F File Offset: 0x0000422F
		private void OnVoteEnd(VoteMapEndEvent evt)
		{
			if (this._networkGameService.IsConnected() && this._networkGameService.LoadMapAutomatically)
			{
				this.LoadMap((ulong)evt.MapModeEntry.GameMap, evt.MapModeEntry.GameMode);
			}
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x0000606D File Offset: 0x0000426D
		private void NotifySceneLoaded(EBaseScene scene)
		{
			if (this.OnSceneLoaded != null)
			{
				this.OnSceneLoaded(scene);
				this.CurrentScene = scene;
			}
		}

		// Token: 0x0600055C RID: 1372 RVA: 0x0000608D File Offset: 0x0000428D
		internal void LoadSceneEntry()
		{
			SceneManager.LoadScene("EntryUI", 0);
			this.OnSceneLoaded(EBaseScene.Entry);
		}

		// Token: 0x0600055D RID: 1373 RVA: 0x000060A6 File Offset: 0x000042A6
		internal void LoadSceneTitle()
		{
			SceneManager.LoadScene("TitleUI", 0);
			this.NotifySceneLoaded(EBaseScene.Title);
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x000060BA File Offset: 0x000042BA
		internal void LoadMain(string defaultState = "")
		{
			this._loadingCoroutine.Enqueue(this.LoadScreenCoroutine(defaultState));
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x000060CE File Offset: 0x000042CE
		internal void LoadMap(ulong gameMapId, EGameMode gameMode)
		{
			this._loadingCoroutine.Enqueue(this.LoadMapCoroutine(gameMapId, gameMode));
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x00026B50 File Offset: 0x00024D50
		private void CachePlayerWeaponIcons()
		{
			SoldiersService service = ServiceProvider.GetService<SoldiersService>();
			Dictionary<EHeroClass, List<PlayerLoadoutData>> playerLoadouts = service.GetPlayerLoadouts();
			EHeroItemSlot[] array = new EHeroItemSlot[]
			{
				EHeroItemSlot.PrimaryWeapon,
				EHeroItemSlot.SecondaryWeapon,
				EHeroItemSlot.MeleeWeapon,
				EHeroItemSlot.Explosive
			};
			Dictionary<string, List<EWeaponSkinName>> dictionary = new Dictionary<string, List<EWeaponSkinName>>();
			foreach (List<PlayerLoadoutData> list in playerLoadouts.Values)
			{
				foreach (PlayerLoadoutData playerLoadoutData in list)
				{
					Dictionary<EHeroItemSlot, PlayerWeaponData> loadoutInfo = service.GetLoadoutInfo(playerLoadoutData);
					foreach (EHeroItemSlot eheroItemSlot in array)
					{
						if (loadoutInfo.ContainsKey(eheroItemSlot))
						{
							PlayerWeaponData playerWeaponData = loadoutInfo[eheroItemSlot];
							if (playerWeaponData != null)
							{
								string itemModel = playerWeaponData.GameItemData.GameItem.ItemModel;
								WeaponSkin skinForLoadout = playerWeaponData.PlayerItem.GetSkinForLoadout(playerLoadoutData.PlayerItem);
								if (!dictionary.ContainsKey(itemModel))
								{
									dictionary.Add(itemModel, new List<EWeaponSkinName>(new EWeaponSkinName[] { skinForLoadout.WeaponSkinName }));
								}
								else if (!dictionary[itemModel].Contains(skinForLoadout.WeaponSkinName))
								{
									dictionary[itemModel].Add(skinForLoadout.WeaponSkinName);
								}
							}
						}
					}
				}
			}
			IEnumerable<WeaponV4> enumerable = from w in ServiceProvider.GetService<WeaponService>().GetWeapons()
				where w.Available
				select w;
			foreach (WeaponV4 weaponV in enumerable)
			{
				string itemModel2 = weaponV.ItemModel;
				if (dictionary.ContainsKey(itemModel2))
				{
					foreach (EWeaponSkinName eweaponSkinName in dictionary[itemModel2])
					{
						string weaponIconPath = TextureHelper.GetWeaponIconPath(itemModel2, EImageSize.SMALL, eweaponSkinName);
						TextureHelper.CacheImage(weaponIconPath, EImageSource.METADATA);
					}
				}
				else
				{
					string weaponIconPath2 = TextureHelper.GetWeaponIconPath(itemModel2, EImageSize.SMALL, EWeaponSkinName.DEFAULT);
					TextureHelper.CacheImage(weaponIconPath2, EImageSource.METADATA);
				}
			}
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x00026E0C File Offset: 0x0002500C
		private IEnumerator LoadScreenCoroutine(string defaultState)
		{
			if (this.CurrentScene == EBaseScene.InGame && this.OnLeaveGameScene != null)
			{
				this.OnLeaveGameScene();
			}
			ServiceProvider.GetService<MusicService>().FadeOutMusic(2f);
			UIManager.Instance.ChangeState("GENERIC_LOADING");
			yield return new WaitForSeconds(1f);
			TextureHelper.ClearCache();
			AsyncOperation asyncOperation = SceneManager.LoadSceneAsync("MainUI");
			while (!asyncOperation.isDone)
			{
				yield return null;
			}
			this.CachePlayerWeaponIcons();
			yield return new WaitForSeconds(1f);
			ServiceProvider.GetService<MusicService>().FadeInMusic(2f);
			ServiceProvider.GetService<InputControlService>().ClearAll();
			UIManager.Instance.DisableLayer(1);
			UIManager.Instance.DisableLayer(2);
			yield return null;
			if (string.IsNullOrEmpty(defaultState))
			{
				UIManager.Instance.ChangeState("HOME");
			}
			else
			{
				UIManager.Instance.ChangeState(defaultState);
			}
			if (this._currentAssetBundle != null)
			{
				this._currentAssetBundle.Unload(true);
			}
			this.NotifySceneLoaded(EBaseScene.Main);
			switch (ServiceProvider.GetService<CurrentMatchService>().State)
			{
			case CurrentMatchService.ConnectionState.LOST_CONNECTION:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.CONNECTION_LOST, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.KICKED:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.KICKED, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.BADCONNECTION:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.BADCONNECTION, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.GRENADEHACK:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.GRENADEHACK, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.SPEEDHACK:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.SPEEDHACK, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.INACTIVITY:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.INACTIVITY, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.MAXPING:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.MAXPING, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.HOST_KICKED:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.HOST_KICKED, null, null, null, 0f);
				break;
			case CurrentMatchService.ConnectionState.HOST_BLACKLISTED:
				ServiceProvider.GetService<PopupService>().Show(EPopupType.HOST_BLACKLISTED, null, null, null, 0f);
				break;
			}
			ServiceProvider.GetService<StatisticsService>().CommitStats();
			yield return new WaitForSeconds(0.5f);
			ServiceProvider.GetService<InvitationService>().CheckStartupInvitation();
			yield break;
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x00026E30 File Offset: 0x00025030
		private IEnumerator LoadMapCoroutine(ulong gameMapId, EGameMode gameMode)
		{
			GameMapConfig config = ServiceProvider.GetService<GameMapModeConfigService>().GetGameMapConfig(gameMapId);
			string sceneBundlePath = this.GetPlatformMapPath(config);
			if (!File.Exists(sceneBundlePath))
			{
				Debug.LogError("Could not find map bundle at " + sceneBundlePath);
				yield break;
			}
			MapLoadProgress mapLoadProgress;
			mapLoadProgress.Map = config;
			mapLoadProgress.Mode = gameMode;
			mapLoadProgress.Progress = 0f;
			mapLoadProgress.Tip = ServiceProvider.GetService<LoadingTipService>().RetrieveLocalizationKey();
			UIManager.Instance.DisableLayer(1);
			UIManager.Instance.DisableLayer(2);
			UIManager.Instance.DisableLayer(3);
			UIManager.Instance.DisableLayer(4);
			this.HandleOnMapLoading(mapLoadProgress);
			yield return new WaitForSeconds(2f);
			SceneManager.LoadScene("TransitionUI", 0);
			TextureHelper.ClearCache();
			if (this._currentAssetBundle != null)
			{
				this._currentAssetBundle.Unload(true);
			}
			float tipTime = 0f;
			AssetBundleCreateRequest asyncLoad = AssetBundle.LoadFromFileAsync(sceneBundlePath);
			while (!asyncLoad.isDone)
			{
				if (tipTime >= 6f)
				{
					tipTime %= 6f;
					mapLoadProgress.Tip = ServiceProvider.GetService<LoadingTipService>().RetrieveLocalizationKey();
				}
				tipTime += Time.deltaTime;
				mapLoadProgress.Progress = asyncLoad.progress * 0.2f;
				this.HandleOnMapLoading(mapLoadProgress);
				yield return null;
			}
			this._currentAssetBundle = asyncLoad.assetBundle;
			Debug.Log(this._currentAssetBundle.GetAllScenePaths().FirstOrDefault<string>());
			AsyncOperation mapLoadOp = SceneManager.LoadSceneAsync(this._currentAssetBundle.GetAllScenePaths().FirstOrDefault<string>(), 0);
			while (!mapLoadOp.isDone)
			{
				if (tipTime >= 6f)
				{
					tipTime %= 6f;
					mapLoadProgress.Tip = ServiceProvider.GetService<LoadingTipService>().RetrieveLocalizationKey();
				}
				tipTime += Time.deltaTime;
				mapLoadProgress.Progress = 0.2f + mapLoadOp.progress * 0.4f;
				this.HandleOnMapLoading(mapLoadProgress);
				yield return null;
			}
			if (config.MapId > 100UL)
			{
				if (RenderSettings.skybox != null)
				{
					RenderSettings.skybox.shader = Shader.Find(RenderSettings.skybox.shader.name);
				}
				foreach (MeshRenderer meshRenderer in SceneManager.GetActiveScene().GetRootGameObjects().SelectMany((GameObject t) => t.GetComponentsInChildren<MeshRenderer>()))
				{
					foreach (Material material in meshRenderer.sharedMaterials)
					{
						if (material != null && material.shader.name.Contains("Standard"))
						{
							material.shader = Shader.Find(material.shader.name);
						}
					}
				}
				foreach (AudioListener audioListener in SceneManager.GetActiveScene().GetRootGameObjects().SelectMany((GameObject t) => t.GetComponentsInChildren<AudioListener>()))
				{
					Object.Destroy(audioListener);
				}
			}
			AsyncOperation uiLoadOp = SceneManager.LoadSceneAsync("InGameUI", 1);
			while (!uiLoadOp.isDone)
			{
				if (tipTime >= 6f)
				{
					tipTime %= 6f;
					mapLoadProgress.Tip = ServiceProvider.GetService<LoadingTipService>().RetrieveLocalizationKey();
				}
				tipTime += Time.deltaTime;
				mapLoadProgress.Progress = 0.6f + 0.4f * uiLoadOp.progress;
				this.HandleOnMapLoading(mapLoadProgress);
				yield return null;
			}
			mapLoadProgress.Progress = 1f;
			this.HandleOnMapLoading(mapLoadProgress);
			UIManager.Instance.ChangeState("CUTSCENE");
			ServiceProvider.GetService<InputControlService>().ClearAll();
			yield return new WaitForSeconds(0.5f);
			this.NotifySceneLoaded(EBaseScene.InGame);
			yield break;
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x00026E5C File Offset: 0x0002505C
		private string GetPlatformMapPath(GameMapConfig config)
		{
			RuntimePlatform platform = Application.platform;
			switch (platform)
			{
			case 0:
			case 1:
				return config.FolderPath + "OSX/" + config.MapName + ".mapbundle";
			case 2:
			case 7:
				return config.FolderPath + "Win/" + config.MapName + ".mapbundle";
			default:
				switch (platform)
				{
				case 13:
				case 16:
					return config.FolderPath + "Linux/" + config.MapName + ".mapbundle";
				}
				Debug.LogError("Platform not supported:" + Application.platform);
				return string.Empty;
			}
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x000060E3 File Offset: 0x000042E3
		private void HandleOnMapLoading(MapLoadProgress progress)
		{
			if (this.OnMapLoading != null)
			{
				this.OnMapLoading(progress);
			}
		}

		// Token: 0x040007DC RID: 2012
		private EventProxy _eventProxy;

		// Token: 0x040007DD RID: 2013
		private NetworkGameService _networkGameService;

		// Token: 0x040007DE RID: 2014
		private const string SceneUiEntry = "EntryUI";

		// Token: 0x040007DF RID: 2015
		private const string SceneUiTitle = "TitleUI";

		// Token: 0x040007E0 RID: 2016
		private const string SceneUiMain = "MainUI";

		// Token: 0x040007E1 RID: 2017
		private const string SceneUiGame = "InGameUI";

		// Token: 0x040007E2 RID: 2018
		private const string SceneTransitionUI = "TransitionUI";

		// Token: 0x040007E3 RID: 2019
		private const float TipIntervalSec = 6f;

		// Token: 0x040007E8 RID: 2024
		private Coroutine _loadingCurrent;

		// Token: 0x040007E9 RID: 2025
		private Queue<IEnumerator> _loadingCoroutine = new Queue<IEnumerator>();

		// Token: 0x040007EA RID: 2026
		private AssetBundle _currentAssetBundle;
	}
}
