﻿using System;

namespace Aquiris.Ballistic.Game.SceneSystem
{
	// Token: 0x02000114 RID: 276
	public enum EBaseScene
	{
		// Token: 0x040007D8 RID: 2008
		Entry,
		// Token: 0x040007D9 RID: 2009
		Title,
		// Token: 0x040007DA RID: 2010
		Main,
		// Token: 0x040007DB RID: 2011
		InGame
	}
}
