﻿using System;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;

namespace Aquiris.Ballistic.Game.SceneSystem
{
	// Token: 0x02000119 RID: 281
	public struct MapLoadProgress
	{
		// Token: 0x04000805 RID: 2053
		public GameMapConfig Map;

		// Token: 0x04000806 RID: 2054
		public EGameMode Mode;

		// Token: 0x04000807 RID: 2055
		public float Progress;

		// Token: 0x04000808 RID: 2056
		public string Tip;
	}
}
