﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Spectator
{
	// Token: 0x020001AE RID: 430
	public class KillCam : MonoBehaviour
	{
		// Token: 0x060008D4 RID: 2260 RVA: 0x00036014 File Offset: 0x00034214
		public void Awake()
		{
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnRoundUp.AddListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			base.transform.parent = null;
			this._currentHeight = this.DefaultLookAtHeight;
			this._camera = base.GetComponent<Camera>();
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x000081BB File Offset: 0x000063BB
		private void OnRoundUp(ChangeRoundEvent evt)
		{
			if (this._killCamTimer > 0f)
			{
				this._killCamTimer = 0f;
			}
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x000081D8 File Offset: 0x000063D8
		public void OnDestroy()
		{
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x00036078 File Offset: 0x00034278
		public void OnDrawGizmos()
		{
			Gizmos.color = Color.blue;
			for (int i = 0; i < this._nearPlaneCorners.Count; i++)
			{
				Vector3 vector = this._nearPlaneCorners[i];
				Gizmos.DrawSphere(vector, 0.03f);
			}
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x000360C4 File Offset: 0x000342C4
		public void LateUpdate()
		{
			if (this.EnemyToFollow == null || !this.EnemyToFollow.gameObject.activeInHierarchy)
			{
				this.EnemyToFollow = null;
			}
			else
			{
				Vector3 position = this.EnemyToFollow.position;
				Quaternion rotation = this.EnemyToFollow.rotation;
				Vector3 vector = this.EnemyToFollow.position + this._currentHeight * Vector3.up;
				if (this._refresh)
				{
					this._refresh = false;
					this._currentRotation = rotation;
				}
				else
				{
					this._currentRotation = Quaternion.Slerp(this._currentRotation, rotation, 10f * Time.deltaTime);
				}
				base.transform.position = position + this._currentRotation * this.Offset;
				base.transform.LookAt(vector);
				float num = Vector3.Distance(base.transform.position, vector);
				float num2 = num;
				if (num2 > 0f)
				{
					float num3 = this._camera.nearClipPlane * Mathf.Tan(0.5f * this._camera.fieldOfView * 0.0174532924f);
					float num4 = this._camera.aspect * num3;
					Vector3 position2 = base.transform.position;
					Vector3 vector2 = position2 + this._camera.nearClipPlane * base.transform.forward;
					Vector3 up = base.transform.up;
					Vector3 right = base.transform.right;
					this._nearPlaneCorners.Clear();
					this._nearPlaneCorners.Add(vector2);
					this._nearPlaneCorners.Add(vector2 + num3 * up + num4 * right);
					this._nearPlaneCorners.Add(vector2 + num3 * up - num4 * right);
					this._nearPlaneCorners.Add(vector2 - num3 * up + num4 * right);
					this._nearPlaneCorners.Add(vector2 - num3 * up - num4 * right);
					Vector3 vector3 = vector - position2;
					vector3.y = 0f;
					vector3.Normalize();
					Vector3 vector4 = base.transform.position + vector3 * (num - this.MinDistance);
					float num5 = num2;
					for (int i = 0; i < this._nearPlaneCorners.Count; i++)
					{
						Vector3 vector5 = this._nearPlaneCorners[i];
						Vector3 vector6 = vector5 - position2;
						Vector3 vector7 = vector4 + vector6;
						Vector3 vector8 = vector5;
						Vector3 vector9 = vector8 - vector7;
						RaycastHit[] array = Physics.RaycastAll(vector7, vector9.normalized, vector9.magnitude, this.CollisionLayers);
						for (int j = 0; j < array.Length; j++)
						{
							if (!array[j].collider.isTrigger)
							{
								num5 = Mathf.Min(num5, array[j].distance);
								break;
							}
						}
					}
					if (num5 < num2)
					{
						float num6 = Mathf.Max(num5, this.MinDistance);
						float num7 = 1f - num6 / (num - this.MinDistance);
						vector += num7 * this.CollisionLookAtOffset * Vector3.up;
						base.transform.position = vector4 - num6 * vector3;
						base.transform.LookAt(vector);
					}
				}
			}
			if (this._killCamTimer > 0f)
			{
				this._killCamTimer -= Time.deltaTime;
				if (this._killCamTimer <= 0f)
				{
					if (this._gameModeService.GameMode == EGameMode.Rounds)
					{
						InGameEndmatchController.EnforcePlayerSpectate();
					}
					else
					{
						CameraService.ReturnToRespawn();
					}
				}
			}
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x000364CC File Offset: 0x000346CC
		public void SetTarget(Transform target, EHeroClass classHero)
		{
			this.EnemyToFollow = target;
			if (classHero != EHeroClass.TANK)
			{
				this._currentHeight = this.DefaultLookAtHeight;
			}
			else
			{
				this._currentHeight = this.TankLookAtHeight;
			}
			this._killCamTimer = this.KillCamTime;
		}

		// Token: 0x04000B93 RID: 2963
		public Transform EnemyToFollow;

		// Token: 0x04000B94 RID: 2964
		public Vector3 Offset;

		// Token: 0x04000B95 RID: 2965
		public float KillCamTime;

		// Token: 0x04000B96 RID: 2966
		public float KillCamTimeToChangeTarget;

		// Token: 0x04000B97 RID: 2967
		public float DefaultLookAtHeight = 1f;

		// Token: 0x04000B98 RID: 2968
		public float TankLookAtHeight = 1.2f;

		// Token: 0x04000B99 RID: 2969
		public float CollisionLookAtOffset = 0.4f;

		// Token: 0x04000B9A RID: 2970
		public float MaxCompensationAngle = 130f;

		// Token: 0x04000B9B RID: 2971
		public float CollisionDistance = 1f;

		// Token: 0x04000B9C RID: 2972
		public float CameraRadius = 0.3f;

		// Token: 0x04000B9D RID: 2973
		public LayerMask CollisionLayers;

		// Token: 0x04000B9E RID: 2974
		public float MinDistance;

		// Token: 0x04000B9F RID: 2975
		private float _killCamTimer;

		// Token: 0x04000BA0 RID: 2976
		private Quaternion _currentRotation;

		// Token: 0x04000BA1 RID: 2977
		private bool _refresh;

		// Token: 0x04000BA2 RID: 2978
		private float _currentHeight;

		// Token: 0x04000BA3 RID: 2979
		private Camera _camera;

		// Token: 0x04000BA4 RID: 2980
		private GameModeService _gameModeService;

		// Token: 0x04000BA5 RID: 2981
		private NetworkGameService _networkGameService;

		// Token: 0x04000BA6 RID: 2982
		private readonly List<Vector3> _nearPlaneCorners = new List<Vector3>();
	}
}
