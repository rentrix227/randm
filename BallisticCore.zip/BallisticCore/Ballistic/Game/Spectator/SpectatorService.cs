﻿using System;
using System.Collections;
using System.Linq;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using Aquiris.UI.Base;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Spectator
{
	// Token: 0x020001B2 RID: 434
	public class SpectatorService : IService
	{
		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x060008F3 RID: 2291 RVA: 0x000082E5 File Offset: 0x000064E5
		public bool IsSpectating
		{
			get
			{
				return UserProfile.LocalGameClient != null && UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR;
			}
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x000374C0 File Offset: 0x000356C0
		internal override void Preprocess()
		{
			this._cameraService = ServiceProvider.GetService<CameraService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnClientListReceived.AddListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnRoundUp.AddListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._orbitUserList = new HighSpeedArray<long>(40);
			this._userListSorter = new UserListSorter();
			this._orbitCurrentTargetUser = -1L;
			this._autoCycleEnabled = false;
			this._showInfoEnabled = true;
			this._freeCameraEnabled = false;
			this._currentCycleNext = null;
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x0003759C File Offset: 0x0003579C
		internal override void Postprocess()
		{
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnClientListReceived.RemoveListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x00008300 File Offset: 0x00006500
		private void OnClientListReceived(ClientListReceivedEvent evt)
		{
			this.FreeSpectator(true);
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x00008309 File Offset: 0x00006509
		private void OnDie(DieEvent dieEvent)
		{
			if (dieEvent.SenderId == this._orbitCurrentTargetUser)
			{
				this._currentCycleNext = ServiceProvider.GetService<EventProxy>().StartCoroutine(this.CycleToNext(dieEvent.SenderId, dieEvent.KillerId));
			}
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x0003761C File Offset: 0x0003581C
		private IEnumerator CycleToNext(long dieId, long killerId)
		{
			yield return new WaitForSeconds(2f);
			if (this._orbitCurrentTargetUser == dieId)
			{
				EGameMode gameMode = this._gameModeService.GameMode;
				if (gameMode != EGameMode.Rounds)
				{
					while (!this.SpawnOrbitSpectator((!this._autoCycleEnabled) ? this._orbitCurrentTargetUser : killerId))
					{
						yield return new WaitForSeconds(1f);
					}
				}
				else
				{
					while (!this.SpawnOrbitSpectator())
					{
						yield return new WaitForSeconds(1f);
					}
				}
			}
			this._currentCycleNext = null;
			yield break;
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x0000833E File Offset: 0x0000653E
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			if (this._currentCycleNext != null)
			{
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._currentCycleNext);
			}
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x0000835B File Offset: 0x0000655B
		private void OnRoundUp(ChangeRoundEvent evt)
		{
			if (this._currentCycleNext != null)
			{
				ServiceProvider.GetService<EventProxy>().StopCoroutine(this._currentCycleNext);
			}
			this.FreeSpectator(false);
		}

		// Token: 0x060008FB RID: 2299 RVA: 0x0000837F File Offset: 0x0000657F
		public void SetSpectatorPrefabs(GameObject freeCamContainer, GameObject orbitCamContainer)
		{
			this._freeCamContainer = freeCamContainer;
			this._orbitCamContainer = orbitCamContainer;
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x00037648 File Offset: 0x00035848
		internal void SpawnFreeCamFromCutCamera()
		{
			Transform transform = this._cameraService.GetCurrentCamera().transform;
			this.SpawnFreeCam(transform.position, transform.eulerAngles.y);
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x00037680 File Offset: 0x00035880
		internal void SpawnFreeCamFromOrbit()
		{
			if (this._internal == null)
			{
				return;
			}
			SpectatorOrbitCam component = this._internal.GetComponent<SpectatorOrbitCam>();
			if (component == null)
			{
				return;
			}
			this.SpawnFreeCam(component.GetPosition(), component.GetRotationY());
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x000376CC File Offset: 0x000358CC
		internal void SpawnFreeCam(Vector3 position, float rotationY)
		{
			if (!this.CanSpawnSpectators())
			{
				return;
			}
			if (this._internal == null)
			{
				this._internal = Object.Instantiate<GameObject>(this._freeCamContainer, position, Quaternion.Euler(0f, rotationY, 0f));
			}
			else if (this._internal.GetComponent<SpectatorFreeCam>() == null)
			{
				this.FreeSpectator(true);
				this._internal = Object.Instantiate<GameObject>(this._freeCamContainer, position, Quaternion.Euler(0f, rotationY, 0f));
			}
			this._freeCameraEnabled = true;
			if (UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE && UserProfile.LocalGameClient.requestMode != ETeamMode.UNDEFINED)
			{
				UIManager.Instance.ChangeState("FREE_CAMERA_QUEUE");
			}
			else
			{
				UIManager.Instance.ChangeState("FREE_CAMERA");
			}
			this._cameraService.SetCamera(Cameras.NONE, null, EHeroClass.NONE, null, -1);
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x000377B8 File Offset: 0x000359B8
		internal bool SpawnOrbitSpectator()
		{
			EGameMode gameMode = this._networkGameService.GetGameModeMetaData().GameConfig.GameMode;
			ClientCommonMetaData clientCommonMetaData;
			if (gameMode != EGameMode.Rounds)
			{
				clientCommonMetaData = this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Values.FirstOrDefault((ClientCommonMetaData t) => t.CurrentState == EPlayerState.ALIVE && t.ClientMode == EClientMode.PLAYER && ServiceProvider.GetService<RemoteCharactersService>().ActivePlayers.Find((RemoteCharacterInfo j) => j.PlayerId == t.User) != null);
			}
			else
			{
				clientCommonMetaData = this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Values.FirstOrDefault((ClientCommonMetaData t) => t.CurrentState == EPlayerState.ALIVE && t.ClientMode == EClientMode.PLAYER && (int)t.Team == (int)UserProfile.LocalGameClient.ClientCommonMetaData.Team && ServiceProvider.GetService<RemoteCharactersService>().ActivePlayers.Find((RemoteCharacterInfo j) => j.PlayerId == t.User) != null);
			}
			return clientCommonMetaData != null && this.SpawnOrbitSpectator(clientCommonMetaData.User);
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x00037878 File Offset: 0x00035A78
		internal bool SpawnOrbitSpectator(long targetUser)
		{
			if (!this.CanSpawnSpectators())
			{
				return false;
			}
			ClientCommonMetaData clientCommonMetaData = this._networkGameService.GetClientCommonMetaData(targetUser);
			if (clientCommonMetaData == null)
			{
				return false;
			}
			if (clientCommonMetaData.CurrentState != EPlayerState.ALIVE)
			{
				return false;
			}
			RemoteCharacterInfo remoteCharacterInfo = ServiceProvider.GetService<RemoteCharactersService>().ActivePlayers.Find((RemoteCharacterInfo t) => t.PlayerId == targetUser);
			if (remoteCharacterInfo == null)
			{
				return false;
			}
			if (this._internal == null)
			{
				this._internal = Object.Instantiate<GameObject>(this._orbitCamContainer, remoteCharacterInfo.WorldPosition, Quaternion.identity);
			}
			else if (this._internal.GetComponent<SpectatorOrbitCam>() == null)
			{
				this.FreeSpectator(true);
				this._internal = Object.Instantiate<GameObject>(this._orbitCamContainer, remoteCharacterInfo.WorldPosition, Quaternion.identity);
			}
			if (this._internal == null)
			{
				return false;
			}
			if (UserProfile.LocalGameClient.requestMode != ETeamMode.SPECTATE && UserProfile.LocalGameClient.requestMode != ETeamMode.UNDEFINED && this._gameModeService.GameMode != EGameMode.Rounds)
			{
				UIManager.Instance.ChangeState("KILL_CAM_QUEUE");
			}
			else
			{
				UIManager.Instance.ChangeState("KILL_CAM");
			}
			this._orbitCurrentTargetUser = targetUser;
			this._internal.GetComponent<SpectatorOrbitCam>().SetTarget(remoteCharacterInfo);
			UIManager.Instance.FindController<InGameKillcamController>().SetTarget(targetUser, -1);
			this._cameraService.SetCamera(Cameras.NONE, null, EHeroClass.NONE, null, -1);
			return true;
		}

		// Token: 0x06000901 RID: 2305 RVA: 0x00037A04 File Offset: 0x00035C04
		internal void FreeSpectator(bool changingMode)
		{
			if (this._internal == null)
			{
				return;
			}
			if (!changingMode && !UIManager.Instance.CurrentStates.Contains("RESPAWN"))
			{
				UIManager.Instance.ChangeState("RESPAWN");
			}
			this._freeCameraEnabled = false;
			this._orbitCurrentTargetUser = -1L;
			this._cameraService.SetCamera(Cameras.CUTSCENE, null, EHeroClass.NONE, null, -1);
			Object.Destroy(this._internal);
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x00037A7C File Offset: 0x00035C7C
		internal bool CanSpawnSpectators()
		{
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			return gameModeMetaData != null && (gameModeMetaData.GameMetaData.GameStateType == EGameState.PLAYING || gameModeMetaData.GameMetaData.GameStateType == EGameState.ROUNDUP) && UserProfile.LocalGameClient != null && UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR;
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0000838F File Offset: 0x0000658F
		internal long GetCurrentUser()
		{
			return this._orbitCurrentTargetUser;
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x00008397 File Offset: 0x00006597
		internal bool HasOrbitSpawned()
		{
			return this._orbitCurrentTargetUser > 0L;
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x000083A3 File Offset: 0x000065A3
		internal bool GetAutoCycle()
		{
			return this._autoCycleEnabled;
		}

		// Token: 0x06000906 RID: 2310 RVA: 0x000083AB File Offset: 0x000065AB
		internal bool GetShowInfo()
		{
			return UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER || this._showInfoEnabled;
		}

		// Token: 0x06000907 RID: 2311 RVA: 0x000083C5 File Offset: 0x000065C5
		internal bool HasFreeSpawned()
		{
			return this._freeCameraEnabled;
		}

		// Token: 0x06000908 RID: 2312 RVA: 0x000083CD File Offset: 0x000065CD
		internal void SetAutoCycle(bool enabled)
		{
			this._autoCycleEnabled = enabled;
		}

		// Token: 0x06000909 RID: 2313 RVA: 0x000083D6 File Offset: 0x000065D6
		internal void SetShowInfo(bool enabled)
		{
			this._showInfoEnabled = enabled;
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x00037AD8 File Offset: 0x00035CD8
		internal void CycleNext()
		{
			if (this._orbitCurrentTargetUser <= 0L)
			{
				return;
			}
			this._orbitUserList.Clear();
			foreach (long num in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Keys)
			{
				if (this._networkGameService.GetClientCommonMetaData(num).CurrentState == EPlayerState.ALIVE || num == this._orbitCurrentTargetUser)
				{
					this._orbitUserList.Add(num);
				}
			}
			this._orbitUserList.Sort(this._userListSorter);
			int num2 = this._orbitUserList.IndexOf(this._orbitCurrentTargetUser);
			if (num2 >= 0)
			{
				this.SpawnOrbitSpectator(this._orbitUserList[(num2 + 1) % this._orbitUserList.Length]);
			}
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x00037BD0 File Offset: 0x00035DD0
		internal void CyclePrevious()
		{
			if (this._orbitCurrentTargetUser <= 0L)
			{
				return;
			}
			this._orbitUserList.Clear();
			foreach (long num in this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Keys)
			{
				if (this._networkGameService.GetClientCommonMetaData(num).CurrentState == EPlayerState.ALIVE || num == this._orbitCurrentTargetUser)
				{
					this._orbitUserList.Add(num);
				}
			}
			this._orbitUserList.Sort(this._userListSorter);
			int num2 = this._orbitUserList.IndexOf(this._orbitCurrentTargetUser);
			if (num2 >= 0)
			{
				this.SpawnOrbitSpectator(this._orbitUserList[(this._orbitUserList.Length + num2 - 1) % this._orbitUserList.Length]);
			}
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x000083DF File Offset: 0x000065DF
		public Camera GetCurrentCamera()
		{
			if (this._internal == null)
			{
				return null;
			}
			return this._internal.GetComponentInChildren<Camera>();
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x000083FF File Offset: 0x000065FF
		public Transform GetCurrentCameraTransform()
		{
			if (this._internal == null)
			{
				return null;
			}
			return this._internal.transform;
		}

		// Token: 0x04000BD8 RID: 3032
		private GameObject _freeCamContainer;

		// Token: 0x04000BD9 RID: 3033
		private GameObject _orbitCamContainer;

		// Token: 0x04000BDA RID: 3034
		private GameObject _internal;

		// Token: 0x04000BDB RID: 3035
		private GameModeService _gameModeService;

		// Token: 0x04000BDC RID: 3036
		private NetworkGameService _networkGameService;

		// Token: 0x04000BDD RID: 3037
		private CameraService _cameraService;

		// Token: 0x04000BDE RID: 3038
		private HighSpeedArray<long> _orbitUserList;

		// Token: 0x04000BDF RID: 3039
		private UserListSorter _userListSorter;

		// Token: 0x04000BE0 RID: 3040
		private long _orbitCurrentTargetUser;

		// Token: 0x04000BE1 RID: 3041
		private bool _autoCycleEnabled;

		// Token: 0x04000BE2 RID: 3042
		private bool _showInfoEnabled;

		// Token: 0x04000BE3 RID: 3043
		private bool _freeCameraEnabled;

		// Token: 0x04000BE4 RID: 3044
		private Coroutine _currentCycleNext;
	}
}
