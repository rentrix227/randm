﻿using System;
using System.Collections.Generic;

namespace Aquiris.Ballistic.Game.Spectator
{
	// Token: 0x020001B7 RID: 439
	public class UserListSorter : IComparer<long>
	{
		// Token: 0x0600091D RID: 2333 RVA: 0x00008471 File Offset: 0x00006671
		public int Compare(long x, long y)
		{
			return x.CompareTo(y);
		}
	}
}
