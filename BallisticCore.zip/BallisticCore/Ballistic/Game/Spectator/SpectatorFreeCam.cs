﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Spectator
{
	// Token: 0x020001AF RID: 431
	[RequireComponent(typeof(CharacterController))]
	public class SpectatorFreeCam : MonoBehaviour
	{
		// Token: 0x060008DB RID: 2267 RVA: 0x00036570 File Offset: 0x00034770
		public void Awake()
		{
			this._mouseInputQueue = new Queue<Vector2>();
			this._controller = base.GetComponent<CharacterController>();
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnRoundUp.AddListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x000365E4 File Offset: 0x000347E4
		public void LateUpdate()
		{
			this._inputRotation.x = this._optionControlService.GetAxisL(AxisType.MOUSE_X) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedX * this._optionControlService.Container.MouseSensitivityNormal;
			if (this._optionControlService.Container.InvertMouse)
			{
				this._inputRotation.y = -this._optionControlService.GetAxisL(AxisType.MOUSE_Y) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedY * this._optionControlService.Container.MouseSensitivityNormal;
			}
			else
			{
				this._inputRotation.y = this._optionControlService.GetAxisL(AxisType.MOUSE_Y) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedY * this._optionControlService.Container.MouseSensitivityNormal;
			}
			this._mouseInputQueue.Enqueue(this._inputRotation);
			while (this._mouseInputQueue.Count > this.MouseFilteringBufferSize)
			{
				this._mouseInputQueue.Dequeue();
			}
			Vector2 vector = default(Vector2);
			float num = 1f;
			float num2 = 0f;
			foreach (Vector2 vector2 in this._mouseInputQueue)
			{
				vector.x += vector2.x * num;
				vector.y += vector2.y * num;
				num2 += num;
				num *= this.MouseFilterWeightFactor;
			}
			this._inputRotation.x = vector.x / num2;
			this._inputRotation.y = vector.y / num2;
			this._currentYMotor -= this._inputRotation.y;
			if (this._currentYMotor > SpectatorFreeCam._maxAngle.y)
			{
				this._currentYMotor = SpectatorFreeCam._maxAngle.y;
			}
			if (this._currentYMotor < SpectatorFreeCam._maxAngle.x)
			{
				this._currentYMotor = SpectatorFreeCam._maxAngle.x;
			}
			this.CamMotor.localRotation = Quaternion.Euler(this._currentYMotor, 0f, 0f);
			base.transform.Rotate(0f, this._inputRotation.x, 0f);
			if (this._optionControlService.GetKey(KeyType.SPRINT))
			{
				this._inputMoviment.x = this._optionControlService.GetAxisL(AxisType.HORIZONTAL) * this.CameraSprintSpeed * Time.deltaTime;
				this._inputMoviment.z = this._optionControlService.GetAxisL(AxisType.VERTICAL) * this.CameraSprintSpeed * Time.deltaTime;
			}
			else
			{
				this._inputMoviment.x = this._optionControlService.GetAxisL(AxisType.HORIZONTAL) * this.CameraWalkSpeed * Time.deltaTime;
				this._inputMoviment.z = this._optionControlService.GetAxisL(AxisType.VERTICAL) * this.CameraWalkSpeed * Time.deltaTime;
			}
			this._inputMoviment.y = 0f;
			if (this._optionControlService.GetKey(KeyType.SPACE_BAR))
			{
				this._inputMoviment.y = this._inputMoviment.y + this.CameraWalkSpeed * Time.deltaTime;
			}
			if (this._optionControlService.GetKey(KeyType.CROUCH))
			{
				this._inputMoviment.y = this._inputMoviment.y - this.CameraWalkSpeed * Time.deltaTime;
			}
			this._controller.Move(this.CamMotor.forward * this._inputMoviment.z + base.transform.right * this._inputMoviment.x + base.transform.up * this._inputMoviment.y);
			if (Input.GetKeyDown(45))
			{
				this.CameraWalkSpeed -= 0.1f;
				if (this.CameraWalkSpeed < 0f)
				{
					this.CameraWalkSpeed = 0f;
				}
			}
			if (Input.GetKeyDown(61))
			{
				this.CameraWalkSpeed += 0.1f;
			}
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x000081F6 File Offset: 0x000063F6
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			this.Suicide(true);
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x000081FF File Offset: 0x000063FF
		public void OnDestroy()
		{
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x000081F6 File Offset: 0x000063F6
		private void OnRoundUp(ChangeRoundEvent evt)
		{
			this.Suicide(true);
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x00036A4C File Offset: 0x00034C4C
		private void Suicide(bool changingMode)
		{
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			ServiceProvider.GetService<SpectatorService>().FreeSpectator(changingMode);
		}

		// Token: 0x04000BA7 RID: 2983
		private NetworkGameService _networkGameService;

		// Token: 0x04000BA8 RID: 2984
		private OptionControlService _optionControlService;

		// Token: 0x04000BA9 RID: 2985
		public Transform CamMotor;

		// Token: 0x04000BAA RID: 2986
		public float CameraWalkSpeed = 6f;

		// Token: 0x04000BAB RID: 2987
		public float CameraSprintSpeed = 10f;

		// Token: 0x04000BAC RID: 2988
		public int MouseFilteringBufferSize = 2;

		// Token: 0x04000BAD RID: 2989
		public float MouseFilterWeightFactor = 1f;

		// Token: 0x04000BAE RID: 2990
		public float RotationSpeedX = 2f;

		// Token: 0x04000BAF RID: 2991
		public float RotationSpeedY = 2f;

		// Token: 0x04000BB0 RID: 2992
		private static readonly Vector2 _maxAngle = new Vector2(-50f, 80f);

		// Token: 0x04000BB1 RID: 2993
		private CharacterController _controller;

		// Token: 0x04000BB2 RID: 2994
		private Queue<Vector2> _mouseInputQueue;

		// Token: 0x04000BB3 RID: 2995
		private float _currentYMotor;

		// Token: 0x04000BB4 RID: 2996
		private Vector2 _inputRotation;

		// Token: 0x04000BB5 RID: 2997
		private Vector3 _inputMoviment;
	}
}
