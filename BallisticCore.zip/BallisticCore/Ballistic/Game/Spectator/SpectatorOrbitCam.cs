﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Spectator
{
	// Token: 0x020001B1 RID: 433
	public class SpectatorOrbitCam : MonoBehaviour
	{
		// Token: 0x060008E7 RID: 2279 RVA: 0x00036F60 File Offset: 0x00035160
		public void Awake()
		{
			this._mouseInputQueue = new Queue<Vector2>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnRoundUp.AddListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
		}

		// Token: 0x060008E8 RID: 2280 RVA: 0x0000829F File Offset: 0x0000649F
		private void OnDie(DieEvent evt)
		{
			if (evt.SenderId == this._targetGameClientId)
			{
				this._target = null;
			}
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x00036FE4 File Offset: 0x000351E4
		internal void SetTarget(RemoteCharacterInfo target)
		{
			this._targetGameClientId = target.PlayerId;
			this._target = target;
			this.CamHeight.localPosition = new Vector3(0f, (target.HeroClass != EHeroClass.TANK) ? 1f : 1.2f, 0f);
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x000082B9 File Offset: 0x000064B9
		internal Vector3 GetPosition()
		{
			return this.CamMotor.position;
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x0003703C File Offset: 0x0003523C
		internal float GetRotationY()
		{
			return this.CamMotor.rotation.eulerAngles.y;
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x00037064 File Offset: 0x00035264
		public void LateUpdate()
		{
			if (this._target == null)
			{
				return;
			}
			base.transform.position = this._target.WorldPosition;
			this._inputRotation.x = this._optionControlService.GetAxisL(AxisType.MOUSE_X) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedX * this._optionControlService.Container.MouseSensitivityNormal;
			if (this._optionControlService.Container.InvertMouse)
			{
				this._inputRotation.y = this._optionControlService.GetAxisL(AxisType.MOUSE_Y) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedY * this._optionControlService.Container.MouseSensitivityNormal;
			}
			else
			{
				this._inputRotation.y = -this._optionControlService.GetAxisL(AxisType.MOUSE_Y) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedY * this._optionControlService.Container.MouseSensitivityNormal;
			}
			this._mouseInputQueue.Enqueue(this._inputRotation);
			while (this._mouseInputQueue.Count > this.MouseFilteringBufferSize)
			{
				this._mouseInputQueue.Dequeue();
			}
			Vector2 vector = default(Vector2);
			float num = 1f;
			float num2 = 0f;
			foreach (Vector2 vector2 in this._mouseInputQueue)
			{
				vector.x += vector2.x * num;
				vector.y += vector2.y * num;
				num2 += num;
				num *= this.MouseFilterWeightFactor;
			}
			this._inputRotation.x = vector.x / num2;
			this._inputRotation.y = vector.y / num2;
			this._currentYMotor += this._inputRotation.y;
			if (this._currentYMotor > SpectatorOrbitCam._maxAngle.y)
			{
				this._currentYMotor = SpectatorOrbitCam._maxAngle.y;
			}
			if (this._currentYMotor < SpectatorOrbitCam._maxAngle.x)
			{
				this._currentYMotor = SpectatorOrbitCam._maxAngle.x;
			}
			this.CamHeight.localRotation = Quaternion.Euler(this._currentYMotor, 0f, 0f);
			base.transform.Rotate(0f, this._inputRotation.x, 0f);
			this._ray.origin = this.CamHeight.position;
			Vector3 vector3 = this.CamHeight.TransformPoint(new Vector3(0f, 0f, -this.OffsetDistance - this.OffsetRadius));
			Vector3 vector4 = vector3 - this.CamHeight.position;
			this._ray.direction = vector4.normalized;
			this.CamMotor.localPosition = ((!Physics.Raycast(this._ray, ref this._hit, vector4.magnitude, World.AllShootableLayers)) ? new Vector3(0f, 0f, -this.OffsetDistance) : new Vector3(0f, 0f, -this._hit.distance + this.OffsetRadius));
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x000082C6 File Offset: 0x000064C6
		private void OnRoundUp(ChangeRoundEvent evt)
		{
			this.Suicide(true);
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x000082C6 File Offset: 0x000064C6
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			this.Suicide(true);
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x000373F0 File Offset: 0x000355F0
		private void Suicide(bool changingMode)
		{
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
			ServiceProvider.GetService<SpectatorService>().FreeSpectator(changingMode);
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x0003745C File Offset: 0x0003565C
		public void OnDestroy()
		{
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnRoundUp.RemoveListener(new Action<ChangeRoundEvent>(this.OnRoundUp));
		}

		// Token: 0x04000BC4 RID: 3012
		private NetworkGameService _networkGameService;

		// Token: 0x04000BC5 RID: 3013
		private OptionControlService _optionControlService;

		// Token: 0x04000BC6 RID: 3014
		public Transform CamHeight;

		// Token: 0x04000BC7 RID: 3015
		public Transform CamMotor;

		// Token: 0x04000BC8 RID: 3016
		public float OffsetDistance = 3f;

		// Token: 0x04000BC9 RID: 3017
		public float OffsetRadius = 1.5f;

		// Token: 0x04000BCA RID: 3018
		public float RotationSpeedX = 2f;

		// Token: 0x04000BCB RID: 3019
		public float RotationSpeedY = 2f;

		// Token: 0x04000BCC RID: 3020
		public int MouseFilteringBufferSize = 2;

		// Token: 0x04000BCD RID: 3021
		public float MouseFilterWeightFactor = 1f;

		// Token: 0x04000BCE RID: 3022
		private RemoteCharacterInfo _target;

		// Token: 0x04000BCF RID: 3023
		private const float _defaultLookAtHeight = 1f;

		// Token: 0x04000BD0 RID: 3024
		private const float _tankLookAtHeight = 1.2f;

		// Token: 0x04000BD1 RID: 3025
		private static readonly Vector2 _maxAngle = new Vector2(10f, 80f);

		// Token: 0x04000BD2 RID: 3026
		private long _targetGameClientId;

		// Token: 0x04000BD3 RID: 3027
		private Queue<Vector2> _mouseInputQueue;

		// Token: 0x04000BD4 RID: 3028
		private float _currentYMotor;

		// Token: 0x04000BD5 RID: 3029
		private Vector2 _inputRotation;

		// Token: 0x04000BD6 RID: 3030
		private Ray _ray = default(Ray);

		// Token: 0x04000BD7 RID: 3031
		private RaycastHit _hit;
	}
}
