﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Spectator
{
	// Token: 0x020001B0 RID: 432
	[RequireComponent(typeof(CharacterController))]
	public class SpectatorFreeCamOffline : MonoBehaviour
	{
		// Token: 0x060008E3 RID: 2275 RVA: 0x0000824F File Offset: 0x0000644F
		public void Awake()
		{
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			this._optionControlService.Load();
			this._optionControlService.EnableInput();
			this._mouseInputQueue = new Queue<Vector2>();
			this._controller = base.GetComponent<CharacterController>();
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x00036AF0 File Offset: 0x00034CF0
		public void LateUpdate()
		{
			this._inputRotation.x = this._optionControlService.GetAxisL(AxisType.MOUSE_X) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedX * this._optionControlService.Container.MouseSensitivityNormal;
			if (this._optionControlService.Container.InvertMouse)
			{
				this._inputRotation.y = -this._optionControlService.GetAxisL(AxisType.MOUSE_Y) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedY * this._optionControlService.Container.MouseSensitivityNormal;
			}
			else
			{
				this._inputRotation.y = this._optionControlService.GetAxisL(AxisType.MOUSE_Y) * this._optionControlService.Container.RawSensitivity * this.RotationSpeedY * this._optionControlService.Container.MouseSensitivityNormal;
			}
			this._mouseInputQueue.Enqueue(this._inputRotation);
			while (this._mouseInputQueue.Count > this.MouseFilteringBufferSize)
			{
				this._mouseInputQueue.Dequeue();
			}
			Vector2 vector = default(Vector2);
			float num = 1f;
			float num2 = 0f;
			foreach (Vector2 vector2 in this._mouseInputQueue)
			{
				vector.x += vector2.x * num;
				vector.y += vector2.y * num;
				num2 += num;
				num *= this.MouseFilterWeightFactor;
			}
			this._inputRotation.x = vector.x / num2;
			this._inputRotation.y = vector.y / num2;
			this._currentYMotor -= this._inputRotation.y;
			if (this._currentYMotor > SpectatorFreeCamOffline._maxAngle.y)
			{
				this._currentYMotor = SpectatorFreeCamOffline._maxAngle.y;
			}
			if (this._currentYMotor < SpectatorFreeCamOffline._maxAngle.x)
			{
				this._currentYMotor = SpectatorFreeCamOffline._maxAngle.x;
			}
			this.CamMotor.localRotation = Quaternion.Euler(this._currentYMotor, 0f, 0f);
			base.transform.Rotate(0f, this._inputRotation.x, 0f);
			if (this._optionControlService.GetKey(KeyType.SPRINT))
			{
				this._inputMoviment.x = this._optionControlService.GetAxisL(AxisType.HORIZONTAL) * this.CameraSprintSpeed * Time.deltaTime;
				this._inputMoviment.z = this._optionControlService.GetAxisL(AxisType.VERTICAL) * this.CameraSprintSpeed * Time.deltaTime;
			}
			else
			{
				this._inputMoviment.x = this._optionControlService.GetAxisL(AxisType.HORIZONTAL) * this.CameraWalkSpeed * Time.deltaTime;
				this._inputMoviment.z = this._optionControlService.GetAxisL(AxisType.VERTICAL) * this.CameraWalkSpeed * Time.deltaTime;
			}
			this._inputMoviment.y = 0f;
			if (this._optionControlService.GetKey(KeyType.SPACE_BAR))
			{
				this._inputMoviment.y = this._inputMoviment.y + this.CameraWalkSpeed * Time.deltaTime;
			}
			if (this._optionControlService.GetKey(KeyType.CROUCH))
			{
				this._inputMoviment.y = this._inputMoviment.y - this.CameraWalkSpeed * Time.deltaTime;
			}
			this._controller.Move(this.CamMotor.forward * this._inputMoviment.z + base.transform.right * this._inputMoviment.x + base.transform.up * this._inputMoviment.y);
		}

		// Token: 0x04000BB6 RID: 2998
		private OptionControlService _optionControlService;

		// Token: 0x04000BB7 RID: 2999
		public Transform CamMotor;

		// Token: 0x04000BB8 RID: 3000
		public float CameraWalkSpeed = 6f;

		// Token: 0x04000BB9 RID: 3001
		public float CameraSprintSpeed = 10f;

		// Token: 0x04000BBA RID: 3002
		public int MouseFilteringBufferSize = 2;

		// Token: 0x04000BBB RID: 3003
		public float MouseFilterWeightFactor = 1f;

		// Token: 0x04000BBC RID: 3004
		public float RotationSpeedX = 2f;

		// Token: 0x04000BBD RID: 3005
		public float RotationSpeedY = 2f;

		// Token: 0x04000BBE RID: 3006
		private static readonly Vector2 _maxAngle = new Vector2(-50f, 80f);

		// Token: 0x04000BBF RID: 3007
		private CharacterController _controller;

		// Token: 0x04000BC0 RID: 3008
		private Queue<Vector2> _mouseInputQueue;

		// Token: 0x04000BC1 RID: 3009
		private float _currentYMotor;

		// Token: 0x04000BC2 RID: 3010
		private Vector2 _inputRotation;

		// Token: 0x04000BC3 RID: 3011
		private Vector3 _inputMoviment;
	}
}
