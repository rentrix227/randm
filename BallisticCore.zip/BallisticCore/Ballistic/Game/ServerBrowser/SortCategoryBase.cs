﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200012D RID: 301
	internal abstract class SortCategoryBase : ISortCategory
	{
		// Token: 0x060005AB RID: 1451
		protected abstract int CompareHosts(HostItem a, HostItem b);

		// Token: 0x060005AC RID: 1452 RVA: 0x000063E0 File Offset: 0x000045E0
		public void SortAscending(ref List<HostItem> serverList)
		{
			serverList.Sort(new Comparison<HostItem>(this.CompareHosts));
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x000063F6 File Offset: 0x000045F6
		public void SortDescending(ref List<HostItem> serverList)
		{
			this.SortAscending(ref serverList);
			serverList.Reverse();
		}
	}
}
