﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Discovery;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000128 RID: 296
	public static class LatencyDefinitionData
	{
		// Token: 0x0600059E RID: 1438 RVA: 0x0000636F File Offset: 0x0000456F
		internal static LatencyDefinitionData.LatencyDefinition GetLatency(HostItem hostItem)
		{
			if (hostItem.Ping == 0U)
			{
				return LatencyDefinitionData.GetLatency(LatencyDefinitionData.GetDistanceBasedLatency(hostItem.Country));
			}
			return LatencyDefinitionData.GetLatency(hostItem.Ping);
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00027FD4 File Offset: 0x000261D4
		internal static LatencyDefinitionData.LatencyDefinition GetLatency(uint value)
		{
			for (int i = 0; i < LatencyDefinitionData._latencies.Length; i++)
			{
				if (LatencyDefinitionData._latencies[i].Value >= value)
				{
					return LatencyDefinitionData._latencies[i];
				}
			}
			return LatencyDefinitionData._latencies[LatencyDefinitionData._latencies.Length - 1];
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x00028024 File Offset: 0x00026224
		internal static LatencyDefinitionData.LatencyDefinition GetLatency(ELatency value)
		{
			return Array.Find<LatencyDefinitionData.LatencyDefinition>(LatencyDefinitionData._latencies, (LatencyDefinitionData.LatencyDefinition x) => x.Latency == value);
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00028054 File Offset: 0x00026254
		internal static LatencyDefinitionData.LatencyDefinition GetDefinition(HostItem host)
		{
			LatencyDefinitionData.LatencyDefinition latency = LatencyDefinitionData.GetLatency(host);
			return new LatencyDefinitionData.LatencyDefinition
			{
				Latency = latency.Latency,
				UiColor = latency.UiColor,
				Value = host.Ping,
				Country = host.Country,
				Continent = RegionUtils.GetRegionCodeForCountry(host.Country)
			};
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x000280B0 File Offset: 0x000262B0
		internal static ELatency GetDistanceBasedLatency(string hostCountry)
		{
			RegionUtils.ContinentDistance distance = RegionUtils.GetDistance(SteamUtils.GetIPCountry(), hostCountry);
			if (distance == RegionUtils.ContinentDistance.FAR)
			{
				return ELatency.BAD;
			}
			if (distance == RegionUtils.ContinentDistance.MEDIUM)
			{
				return ELatency.POOR;
			}
			if (distance != RegionUtils.ContinentDistance.NEAR)
			{
				return ELatency.BAD;
			}
			return ELatency.GOOD;
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x00006398 File Offset: 0x00004598
		internal static ELatency GetPingBasedLatency(uint ping)
		{
			return LatencyDefinitionData.GetLatency(ping).Latency;
		}

		// Token: 0x0400083A RID: 2106
		private static readonly LatencyDefinitionData.LatencyDefinition[] _latencies = new LatencyDefinitionData.LatencyDefinition[]
		{
			new LatencyDefinitionData.LatencyDefinition
			{
				Latency = ELatency.ALL,
				Value = 0U,
				UiColor = new Color(0.223529413f, 0.223529413f, 0.223529413f, 1f)
			},
			new LatencyDefinitionData.LatencyDefinition
			{
				Latency = ELatency.EXCELLENT,
				Value = 50U,
				UiColor = new Color(0.196078435f, 0.627451f, 0.5019608f, 1f)
			},
			new LatencyDefinitionData.LatencyDefinition
			{
				Latency = ELatency.GOOD,
				Value = 120U,
				UiColor = new Color(0.282352954f, 0.5019608f, 0.321568638f, 1f)
			},
			new LatencyDefinitionData.LatencyDefinition
			{
				Latency = ELatency.AVERAGE,
				Value = 200U,
				UiColor = new Color(0.784313738f, 0.6f, 0f, 1f)
			},
			new LatencyDefinitionData.LatencyDefinition
			{
				Latency = ELatency.POOR,
				Value = 300U,
				UiColor = new Color(0.784313738f, 0.435294122f, 0.121568628f, 1f)
			},
			new LatencyDefinitionData.LatencyDefinition
			{
				Latency = ELatency.BAD,
				Value = 5000U,
				UiColor = new Color(0.8666667f, 0.105882354f, 0.08235294f, 1f)
			}
		};

		// Token: 0x02000129 RID: 297
		internal class LatencyDefinition
		{
			// Token: 0x1700009A RID: 154
			// (get) Token: 0x060005A6 RID: 1446 RVA: 0x000063A5 File Offset: 0x000045A5
			public string Region
			{
				get
				{
					return this.Continent + "/" + this.Country;
				}
			}

			// Token: 0x0400083B RID: 2107
			public ELatency Latency;

			// Token: 0x0400083C RID: 2108
			public string Continent;

			// Token: 0x0400083D RID: 2109
			public string Country;

			// Token: 0x0400083E RID: 2110
			public uint Value;

			// Token: 0x0400083F RID: 2111
			public Color UiColor;
		}
	}
}
