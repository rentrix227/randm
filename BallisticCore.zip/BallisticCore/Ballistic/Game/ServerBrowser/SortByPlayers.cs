﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000131 RID: 305
	internal class SortByPlayers : SortCategoryBase
	{
		// Token: 0x060005B5 RID: 1461 RVA: 0x000282D4 File Offset: 0x000264D4
		protected override int CompareHosts(HostItem a, HostItem b)
		{
			return a.NumPlayers.CompareTo(b.NumPlayers);
		}
	}
}
