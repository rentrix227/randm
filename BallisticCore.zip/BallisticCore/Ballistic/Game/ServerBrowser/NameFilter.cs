﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200011D RID: 285
	internal class NameFilter : IFilterRule
	{
		// Token: 0x0600057A RID: 1402 RVA: 0x0000615C File Offset: 0x0000435C
		public NameFilter(string nameFilter)
		{
			this._nameFilter = nameFilter;
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x0000616B File Offset: 0x0000436B
		public bool IsServerValid(HostItem hostItem)
		{
			return hostItem.Name.ToLower().Contains(this._nameFilter.ToLower());
		}

		// Token: 0x0400082D RID: 2093
		private readonly string _nameFilter;
	}
}
