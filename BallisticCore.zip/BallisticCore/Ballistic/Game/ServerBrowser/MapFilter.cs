﻿using System;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Utils;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200011E RID: 286
	internal class MapFilter : IFilterRule
	{
		// Token: 0x0600057C RID: 1404 RVA: 0x00006188 File Offset: 0x00004388
		public MapFilter(GameMapConfig map)
		{
			this._map = map;
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x00006197 File Offset: 0x00004397
		public bool IsServerValid(HostItem hostItem)
		{
			return this._map.MapId == hostItem.GameMap;
		}

		// Token: 0x0400082E RID: 2094
		private readonly GameMapConfig _map;
	}
}
