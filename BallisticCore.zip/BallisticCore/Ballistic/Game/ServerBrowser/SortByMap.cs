﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200012F RID: 303
	internal class SortByMap : SortCategoryBase
	{
		// Token: 0x060005B1 RID: 1457 RVA: 0x0002825C File Offset: 0x0002645C
		protected override int CompareHosts(HostItem a, HostItem b)
		{
			return string.Compare(a.GameMap.ToString(), b.GameMap.ToString(), StringComparison.Ordinal);
		}
	}
}
