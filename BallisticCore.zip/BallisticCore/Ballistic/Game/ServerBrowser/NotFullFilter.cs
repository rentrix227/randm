﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000124 RID: 292
	internal class NotFullFilter : IFilterRule
	{
		// Token: 0x06000589 RID: 1417 RVA: 0x000061FB File Offset: 0x000043FB
		public bool IsServerValid(HostItem hostItem)
		{
			return hostItem.NumPlayers < hostItem.MaxPlayers;
		}
	}
}
