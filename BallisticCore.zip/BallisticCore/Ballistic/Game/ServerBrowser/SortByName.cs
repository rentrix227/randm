﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200012E RID: 302
	internal class SortByName : SortCategoryBase
	{
		// Token: 0x060005AF RID: 1455 RVA: 0x0000640E File Offset: 0x0000460E
		protected override int CompareHosts(HostItem a, HostItem b)
		{
			return string.Compare(a.Name, b.Name, StringComparison.Ordinal);
		}
	}
}
