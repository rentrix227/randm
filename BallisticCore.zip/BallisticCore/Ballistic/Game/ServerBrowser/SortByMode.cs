﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000130 RID: 304
	internal class SortByMode : SortCategoryBase
	{
		// Token: 0x060005B3 RID: 1459 RVA: 0x00028298 File Offset: 0x00026498
		protected override int CompareHosts(HostItem a, HostItem b)
		{
			return string.Compare(a.GameMode.ToString(), b.GameMode.ToString(), StringComparison.Ordinal);
		}
	}
}
