﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000122 RID: 290
	internal class VacSecureFilter : IFilterRule
	{
		// Token: 0x06000585 RID: 1413 RVA: 0x000061E8 File Offset: 0x000043E8
		public bool IsServerValid(HostItem hostItem)
		{
			return hostItem.VacSecure;
		}
	}
}
