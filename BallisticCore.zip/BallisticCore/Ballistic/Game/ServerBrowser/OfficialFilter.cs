﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000121 RID: 289
	internal class OfficialFilter : IFilterRule
	{
		// Token: 0x06000583 RID: 1411 RVA: 0x000061DA File Offset: 0x000043DA
		public bool IsServerValid(HostItem hostItem)
		{
			return hostItem.Status != EServerStatus.OFFICIAL;
		}
	}
}
