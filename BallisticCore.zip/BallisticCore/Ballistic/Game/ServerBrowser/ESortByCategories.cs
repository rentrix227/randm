﻿using System;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200011C RID: 284
	public enum ESortByCategories
	{
		// Token: 0x04000825 RID: 2085
		LOCK,
		// Token: 0x04000826 RID: 2086
		SHIELD,
		// Token: 0x04000827 RID: 2087
		NAME,
		// Token: 0x04000828 RID: 2088
		MAP,
		// Token: 0x04000829 RID: 2089
		GAMEMODE,
		// Token: 0x0400082A RID: 2090
		PLAYERS,
		// Token: 0x0400082B RID: 2091
		LATENCY,
		// Token: 0x0400082C RID: 2092
		STATUS
	}
}
