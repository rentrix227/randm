﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000120 RID: 288
	internal class LatencyFilter : IFilterRule
	{
		// Token: 0x06000580 RID: 1408 RVA: 0x000061CB File Offset: 0x000043CB
		public LatencyFilter(ELatency latency)
		{
			this._latency = latency;
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x0002795C File Offset: 0x00025B5C
		public bool IsServerValid(HostItem hostItem)
		{
			if (hostItem.Ping > 0U)
			{
				return hostItem.Ping <= LatencyDefinitionData.GetLatency(this._latency).Value;
			}
			ELatency distanceBasedLatency = LatencyDefinitionData.GetDistanceBasedLatency(hostItem.Country);
			return distanceBasedLatency <= this._latency;
		}

		// Token: 0x04000830 RID: 2096
		private readonly ELatency _latency;
	}
}
