﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000125 RID: 293
	internal interface IFilterRule
	{
		// Token: 0x0600058A RID: 1418
		bool IsServerValid(HostItem hostItem);
	}
}
