﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000126 RID: 294
	internal interface ISortCategory
	{
		// Token: 0x0600058B RID: 1419
		void SortAscending(ref List<HostItem> serverList);

		// Token: 0x0600058C RID: 1420
		void SortDescending(ref List<HostItem> serverList);
	}
}
