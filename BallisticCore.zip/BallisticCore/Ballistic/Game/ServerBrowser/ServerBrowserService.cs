﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Steamworks;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000127 RID: 295
	internal class ServerBrowserService : IService
	{
		// Token: 0x14000005 RID: 5
		// (add) Token: 0x0600058E RID: 1422 RVA: 0x000279AC File Offset: 0x00025BAC
		// (remove) Token: 0x0600058F RID: 1423 RVA: 0x000279E4 File Offset: 0x00025BE4
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private event Action<List<HostItem>> UpdateListEvent;

		// Token: 0x06000590 RID: 1424 RVA: 0x0000621E File Offset: 0x0000441E
		internal override void Preprocess()
		{
			this._hostDiscovery = new HostDiscovery();
			this._filterRules = new List<IFilterRule>();
			this._sortCategory = new SortByPlayers();
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x00027A1C File Offset: 0x00025C1C
		internal bool IsServerValid(HostItem hostItem)
		{
			if (hostItem.Status == EServerStatus.OFFICIAL && this._serverFilterMode == EServerFilterMode.ONLY_COMMUNITY)
			{
				return false;
			}
			for (int i = 0; i < this._filterRules.Count; i++)
			{
				if (!this._filterRules[i].IsServerValid(hostItem))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x00027A7C File Offset: 0x00025C7C
		internal void SetFilterRules(ServerBrowserSearchFilters filters)
		{
			this._filterRules.Clear();
			this._serverFilterMode = filters.OfficialsSearchFilterMode;
			if (!string.IsNullOrEmpty(filters.Name))
			{
				this._filterRules.Add(new NameFilter(filters.Name));
			}
			if (filters.Map.MapId != GameMapModeConfigService.DefaultAnyMap.MapId)
			{
				this._filterRules.Add(new MapFilter(filters.Map));
			}
			if (filters.Mode != EGameMode.Any)
			{
				this._filterRules.Add(new ModeFilter(filters.Mode));
			}
			if (filters.Latency != ELatency.ALL)
			{
				this._filterRules.Add(new LatencyFilter(filters.Latency));
			}
			if (!filters.Officials)
			{
				this._filterRules.Add(new OfficialFilter());
			}
			if (this.UpdateListEvent != null)
			{
				this.UpdateListEvent(this.GetServersFound());
			}
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x00006241 File Offset: 0x00004441
		internal void SearchServers(ServerBrowserSearchFilters filters)
		{
			if (this.IsSearching())
			{
				this.StopSearch();
			}
			this.SetFilterRules(filters);
			this._hostDiscovery.Go(filters.FriendsOnly);
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x0000626C File Offset: 0x0000446C
		internal bool IsSearching()
		{
			return this._hostDiscovery.Running;
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x00006279 File Offset: 0x00004479
		internal void StopSearch()
		{
			this._hostDiscovery.Cancel();
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00027B70 File Offset: 0x00025D70
		internal List<HostItem> GetServersFound()
		{
			List<HostItem> list = new List<HostItem>(this._hostDiscovery.HostList);
			foreach (HostItem hostItem in this._hostDiscovery.HostList)
			{
				if (!this.IsServerValid(hostItem))
				{
					list.Remove(hostItem);
				}
			}
			EServerFilterMode serverFilterMode = this._serverFilterMode;
			if (serverFilterMode == EServerFilterMode.AVALIABLE)
			{
				this.lp = list.FindAll((HostItem t) => t.Status == EServerStatus.OFFICIAL && t.NumPlayers <= 0U);
				this.sortName.SortAscending(ref this.lp);
				bool flag = true;
				bool flag2 = true;
				bool flag3 = true;
				bool flag4 = true;
				bool flag5 = true;
				bool flag6 = true;
				bool flag7 = true;
				bool flag8 = true;
				bool flag9 = true;
				bool flag10 = true;
				bool flag11 = true;
				bool flag12 = true;
				foreach (HostItem hostItem2 in this.lp)
				{
					if (flag && hostItem2.Name.Contains("NA East") && hostItem2.MaxPing <= 0)
					{
						flag = false;
					}
					else if (flag2 && hostItem2.Name.Contains("NA West") && hostItem2.MaxPing <= 0)
					{
						flag2 = false;
					}
					else if (flag3 && hostItem2.Name.Contains("Europe") && hostItem2.MaxPing <= 0)
					{
						flag3 = false;
					}
					else if (flag4 && hostItem2.Name.Contains("Asia") && hostItem2.MaxPing <= 0)
					{
						flag4 = false;
					}
					else if (flag5 && hostItem2.Name.Contains("China") && hostItem2.MaxPing <= 0)
					{
						flag5 = false;
					}
					else if (flag6 && hostItem2.Name.Contains("South") && hostItem2.MaxPing <= 0)
					{
						flag6 = false;
					}
					else if (flag7 && hostItem2.Name.Contains("NA East") && hostItem2.MaxPing <= 0)
					{
						flag7 = false;
					}
					else if (flag8 && hostItem2.Name.Contains("NA West") && hostItem2.MaxPing <= 0)
					{
						flag8 = false;
					}
					else if (flag9 && hostItem2.Name.Contains("Europe") && hostItem2.MaxPing <= 0)
					{
						flag9 = false;
					}
					else if (flag10 && hostItem2.Name.Contains("Asia") && hostItem2.MaxPing <= 0)
					{
						flag10 = false;
					}
					else if (flag11 && hostItem2.Name.Contains("China") && hostItem2.MaxPing <= 0)
					{
						flag11 = false;
					}
					else if (flag12 && hostItem2.Name.Contains("South") && hostItem2.MaxPing <= 0)
					{
						flag12 = false;
					}
					else
					{
						list.Remove(hostItem2);
					}
				}
			}
			if (this._sortCategory == null)
			{
				return list;
			}
			if (this._sortAscending)
			{
				this._sortCategory.SortAscending(ref list);
			}
			else
			{
				this._sortCategory.SortDescending(ref list);
			}
			return list;
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x00027F5C File Offset: 0x0002615C
		internal HostItem GetServerById(CSteamID id)
		{
			foreach (HostItem hostItem in this._hostDiscovery.HostList)
			{
				if (hostItem.SteamId == id)
				{
					return hostItem;
				}
			}
			return null;
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00006286 File Offset: 0x00004486
		internal void ListenSearchEvents(Action onSearchStarted, Action onSearchCancelled, Action onSearchEnded, Action<HostItem> onSearchUpdate, Action<List<HostItem>> onUpdateListRequest)
		{
			this._hostDiscovery.OnDiscoveryStarted += onSearchStarted;
			this._hostDiscovery.OnDiscoveryCanceled += onSearchCancelled;
			this._hostDiscovery.OnDiscoveryEnded += onSearchEnded;
			this._hostDiscovery.OnDiscoveryUpdated += onSearchUpdate;
			this.UpdateListEvent += onUpdateListRequest;
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x000062C1 File Offset: 0x000044C1
		internal void ClearSearchEvents(Action onSearchStarted, Action onSearchCancelled, Action onSearchEnded, Action<HostItem> onSearchUpdate, Action<List<HostItem>> onUpdateListRequest)
		{
			this._hostDiscovery.OnDiscoveryStarted -= onSearchStarted;
			this._hostDiscovery.OnDiscoveryCanceled -= onSearchCancelled;
			this._hostDiscovery.OnDiscoveryEnded -= onSearchEnded;
			this._hostDiscovery.OnDiscoveryUpdated -= onSearchUpdate;
			this.UpdateListEvent -= onUpdateListRequest;
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x000062FC File Offset: 0x000044FC
		internal void SetSortCategory(ISortCategory sortCategory, bool ascOrDesc)
		{
			this._sortCategory = sortCategory;
			this._sortAscending = ascOrDesc;
			if (this.UpdateListEvent != null)
			{
				this.UpdateListEvent(this.GetServersFound());
			}
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00006328 File Offset: 0x00004528
		internal void SortServers()
		{
			if (this._sortCategory == null)
			{
				return;
			}
			if (this.UpdateListEvent != null)
			{
				this.UpdateListEvent(this.GetServersFound());
			}
		}

		// Token: 0x04000831 RID: 2097
		private List<IFilterRule> _filterRules;

		// Token: 0x04000832 RID: 2098
		private EServerFilterMode _serverFilterMode;

		// Token: 0x04000833 RID: 2099
		private bool _sortAscending;

		// Token: 0x04000834 RID: 2100
		private ISortCategory _sortCategory;

		// Token: 0x04000835 RID: 2101
		private HostDiscovery _hostDiscovery;

		// Token: 0x04000837 RID: 2103
		private List<HostItem> lp;

		// Token: 0x04000838 RID: 2104
		private SortByName sortName = new SortByName();
	}
}
