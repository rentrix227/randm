﻿using System;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.Services.ItemModel.ConfigItemModel;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200012B RID: 299
	internal class ServerBrowserSearchFilters
	{
		// Token: 0x04000841 RID: 2113
		public string Name;

		// Token: 0x04000842 RID: 2114
		public GameMapConfig Map = GameMapModeConfigService.DefaultAnyMap;

		// Token: 0x04000843 RID: 2115
		public EGameMode Mode;

		// Token: 0x04000844 RID: 2116
		public ELatency Latency;

		// Token: 0x04000845 RID: 2117
		public bool FriendsOnly;

		// Token: 0x04000846 RID: 2118
		public bool Officials;

		// Token: 0x04000847 RID: 2119
		public EServerFilterMode OfficialsSearchFilterMode;
	}
}
