﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000132 RID: 306
	internal class SortByLatency : SortCategoryBase
	{
		// Token: 0x060005B7 RID: 1463 RVA: 0x000282F8 File Offset: 0x000264F8
		protected override int CompareHosts(HostItem a, HostItem b)
		{
			ELatency elatency = ((a.Status != EServerStatus.DEDICATED && a.Status != EServerStatus.OFFICIAL) ? ELatency.UNDEFINED : LatencyDefinitionData.GetPingBasedLatency(a.Ping));
			ELatency elatency2 = ((b.Status != EServerStatus.DEDICATED && b.Status != EServerStatus.OFFICIAL) ? ELatency.UNDEFINED : LatencyDefinitionData.GetPingBasedLatency(b.Ping));
			return elatency.CompareTo(elatency2);
		}
	}
}
