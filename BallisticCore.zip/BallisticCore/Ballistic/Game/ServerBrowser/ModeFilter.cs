﻿using System;
using Aquiris.Ballistic.Network.Discovery;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200011F RID: 287
	internal class ModeFilter : IFilterRule
	{
		// Token: 0x0600057E RID: 1406 RVA: 0x000061AC File Offset: 0x000043AC
		public ModeFilter(EGameMode mode)
		{
			this._mode = mode;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x000061BB File Offset: 0x000043BB
		public bool IsServerValid(HostItem hostItem)
		{
			return this._mode == hostItem.GameMode;
		}

		// Token: 0x0400082F RID: 2095
		private readonly EGameMode _mode;
	}
}
