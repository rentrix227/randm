﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000123 RID: 291
	internal class HasPlayersFilter : IFilterRule
	{
		// Token: 0x06000587 RID: 1415 RVA: 0x000061F0 File Offset: 0x000043F0
		public bool IsServerValid(HostItem hostItem)
		{
			return hostItem.NumPlayers > 0U;
		}
	}
}
