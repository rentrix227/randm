﻿using System;
using Aquiris.Ballistic.Network.Discovery;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x02000133 RID: 307
	internal class SortByStatus : SortCategoryBase
	{
		// Token: 0x060005B9 RID: 1465 RVA: 0x0002836C File Offset: 0x0002656C
		protected override int CompareHosts(HostItem a, HostItem b)
		{
			return a.Status.CompareTo(b.Status);
		}
	}
}
