﻿using System;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200012C RID: 300
	internal enum EServerFilterMode
	{
		// Token: 0x04000849 RID: 2121
		ALL,
		// Token: 0x0400084A RID: 2122
		AVALIABLE,
		// Token: 0x0400084B RID: 2123
		ONLY_COMMUNITY
	}
}
