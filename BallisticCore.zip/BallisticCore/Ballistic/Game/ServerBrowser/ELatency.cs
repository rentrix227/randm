﻿using System;

namespace Aquiris.Ballistic.Game.ServerBrowser
{
	// Token: 0x0200011B RID: 283
	internal enum ELatency
	{
		// Token: 0x0400081D RID: 2077
		ALL,
		// Token: 0x0400081E RID: 2078
		EXCELLENT,
		// Token: 0x0400081F RID: 2079
		GOOD,
		// Token: 0x04000820 RID: 2080
		AVERAGE,
		// Token: 0x04000821 RID: 2081
		POOR,
		// Token: 0x04000822 RID: 2082
		BAD,
		// Token: 0x04000823 RID: 2083
		UNDEFINED
	}
}
