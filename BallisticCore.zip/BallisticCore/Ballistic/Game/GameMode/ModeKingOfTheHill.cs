﻿using System;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x0200008E RID: 142
	public class ModeKingOfTheHill : ModeCapturePoint
	{
	}
}
