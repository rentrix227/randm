﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x02000090 RID: 144
	public class ModeTeamDeathMatch : CustomGameMode
	{
		// Token: 0x060001F1 RID: 497 RVA: 0x000037B3 File Offset: 0x000019B3
		public ModeTeamDeathMatch(bool beta)
		{
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._beta = beta;
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void FinishGameMode()
		{
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x00019E28 File Offset: 0x00018028
		public override SpawnLocation GetSpawnLocationById(Team team, string locationId)
		{
			if (this._beta)
			{
				return this._gameModeService.MfaData.GetSpawnLocationById(locationId);
			}
			switch (team)
			{
			case Team.NONE:
				Debug.Log("Team data not implemented for passed in team: " + team);
				break;
			case Team.MFA:
				return this._gameModeService.MfaData.GetSpawnLocationById(locationId);
			case Team.SMOKE:
				return this._gameModeService.SmokesData.GetSpawnLocationById(locationId);
			default:
				Debug.Log("Team data not implemented for passed in team: " + team);
				break;
			}
			return null;
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x00019EC4 File Offset: 0x000180C4
		public override List<SpawnLocation> GetSpawnLocationPriorityList()
		{
			if (this._beta)
			{
				return this._gameModeService.MfaData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
			}
			if (UserProfile.LocalGameClient.team == Team.MFA)
			{
				return this._gameModeService.MfaData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
			}
			if (UserProfile.LocalGameClient.team == Team.SMOKE)
			{
				return this._gameModeService.SmokesData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
			}
			return null;
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x000036D0 File Offset: 0x000018D0
		public override bool IsEnemy(GameClient a, GameClient b)
		{
			return a.gameClientId != b.gameClientId && a.team != b.team;
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void OnMapLoaded(Transform gameModeRoot)
		{
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void UpdateGameMode()
		{
		}

		// Token: 0x040004BE RID: 1214
		private readonly GameModeService _gameModeService;

		// Token: 0x040004BF RID: 1215
		private readonly bool _beta;
	}
}
