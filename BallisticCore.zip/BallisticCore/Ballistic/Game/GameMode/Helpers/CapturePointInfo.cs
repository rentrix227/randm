﻿using System;
using System.Text;

namespace Aquiris.Ballistic.Game.GameMode.Helpers
{
	// Token: 0x02000094 RID: 148
	[Serializable]
	public class CapturePointInfo
	{
		// Token: 0x0600022E RID: 558 RVA: 0x00003A71 File Offset: 0x00001C71
		public CapturePointInfo()
		{
			this.m_owner = PointOwner.NEUTRAL;
			this.m_mfaPlayersOnPoint = 0;
			this.m_smokesPlayersOnPoint = 0;
			this.m_mfaCaptureValue = 0;
			this.m_smokesCaptureValue = 0;
			this.m_mfaConquerGauge = 0;
			this.m_smokesConquerGauge = 0;
			this.m_blocked = false;
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x0600022F RID: 559 RVA: 0x00003AB1 File Offset: 0x00001CB1
		public string pointName
		{
			get
			{
				return this.m_pointName;
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000230 RID: 560 RVA: 0x00003AB9 File Offset: 0x00001CB9
		public PointOwner owner
		{
			get
			{
				return this.m_owner;
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000231 RID: 561 RVA: 0x00003AC1 File Offset: 0x00001CC1
		public int mfaCaptureValue
		{
			get
			{
				return this.m_mfaCaptureValue;
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000232 RID: 562 RVA: 0x00003AC9 File Offset: 0x00001CC9
		public int smokesCaptureValue
		{
			get
			{
				return this.m_smokesCaptureValue;
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000233 RID: 563 RVA: 0x00003AD1 File Offset: 0x00001CD1
		public int mfaConquerGauge
		{
			get
			{
				return this.m_mfaConquerGauge;
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000234 RID: 564 RVA: 0x00003AD9 File Offset: 0x00001CD9
		public int smokesConquerGauge
		{
			get
			{
				return this.m_smokesConquerGauge;
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06000235 RID: 565 RVA: 0x00003AE1 File Offset: 0x00001CE1
		public int mfaPlayersOnPoint
		{
			get
			{
				return this.m_mfaPlayersOnPoint;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000236 RID: 566 RVA: 0x00003AE9 File Offset: 0x00001CE9
		public int smokesPlayersOnPoint
		{
			get
			{
				return this.m_smokesPlayersOnPoint;
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000237 RID: 567 RVA: 0x00003AF1 File Offset: 0x00001CF1
		public bool blocked
		{
			get
			{
				return this.m_blocked;
			}
		}

		// Token: 0x06000238 RID: 568 RVA: 0x0001AC90 File Offset: 0x00018E90
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("Point Name: " + this.m_pointName);
			stringBuilder.AppendLine("Owner: " + this.m_owner.ToString());
			stringBuilder.AppendLine("mfaCaputreValue: " + this.m_mfaCaptureValue);
			stringBuilder.AppendLine("smokesCaputreValue: " + this.m_smokesCaptureValue);
			stringBuilder.AppendLine("mfaConquerGauge: " + this.m_mfaConquerGauge);
			stringBuilder.AppendLine("smokesConquerGauge: " + this.m_smokesConquerGauge);
			return stringBuilder.ToString();
		}

		// Token: 0x040004D6 RID: 1238
		public const string POINT_NAME = "n";

		// Token: 0x040004D7 RID: 1239
		private const string POINT_MFA_CAPTURE_VALUE = "mv";

		// Token: 0x040004D8 RID: 1240
		private const string POINT_MFA_CONQUER_GAUGE = "mg";

		// Token: 0x040004D9 RID: 1241
		private const string POINT_SMOKES_CAPTURE_VALUE = "sv";

		// Token: 0x040004DA RID: 1242
		private const string POINT_SMOKES_CONQUER_GAUGE = "sg";

		// Token: 0x040004DB RID: 1243
		private const string POINT_OWNER = "o";

		// Token: 0x040004DC RID: 1244
		private const string POINT_BLOCKED = "b";

		// Token: 0x040004DD RID: 1245
		private const string POINT_MFA_PLAYERS = "m";

		// Token: 0x040004DE RID: 1246
		private const string POINT_SMOKES_PLAYERS = "s";

		// Token: 0x040004DF RID: 1247
		private string m_pointName;

		// Token: 0x040004E0 RID: 1248
		private PointOwner m_owner;

		// Token: 0x040004E1 RID: 1249
		private int m_mfaCaptureValue;

		// Token: 0x040004E2 RID: 1250
		private int m_smokesCaptureValue;

		// Token: 0x040004E3 RID: 1251
		private int m_mfaConquerGauge;

		// Token: 0x040004E4 RID: 1252
		private int m_smokesConquerGauge;

		// Token: 0x040004E5 RID: 1253
		private int m_mfaPlayersOnPoint;

		// Token: 0x040004E6 RID: 1254
		private int m_smokesPlayersOnPoint;

		// Token: 0x040004E7 RID: 1255
		private bool m_blocked;
	}
}
