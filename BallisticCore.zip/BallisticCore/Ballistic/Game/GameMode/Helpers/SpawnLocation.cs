﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode.Helpers
{
	// Token: 0x02000097 RID: 151
	public class SpawnLocation
	{
		// Token: 0x06000239 RID: 569 RVA: 0x0001AD54 File Offset: 0x00018F54
		public SpawnLocation(Team team, Transform transform)
		{
			this.LocationId = (((team != Team.MFA) ? "s" : "m") + "-" + transform.name).ToLower();
			this.SpawnPosition = transform.position;
			this.SpawnRotation = transform.rotation;
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00003AF9 File Offset: 0x00001CF9
		public SpawnLocation(string spawnId, Vector3 spawnPosition, Quaternion spawnRotation)
		{
			this.LocationId = spawnId;
			this.SpawnPosition = spawnPosition;
			this.SpawnRotation = spawnRotation;
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x0600023B RID: 571 RVA: 0x00003B16 File Offset: 0x00001D16
		// (set) Token: 0x0600023C RID: 572 RVA: 0x00003B1E File Offset: 0x00001D1E
		public string LocationId { get; private set; }

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x0600023D RID: 573 RVA: 0x00003B27 File Offset: 0x00001D27
		// (set) Token: 0x0600023E RID: 574 RVA: 0x00003B2F File Offset: 0x00001D2F
		public Vector3 SpawnPosition { get; private set; }

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600023F RID: 575 RVA: 0x00003B38 File Offset: 0x00001D38
		// (set) Token: 0x06000240 RID: 576 RVA: 0x00003B40 File Offset: 0x00001D40
		public Quaternion SpawnRotation { get; private set; }
	}
}
