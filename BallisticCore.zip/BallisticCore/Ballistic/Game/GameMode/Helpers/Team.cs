﻿using System;

namespace Aquiris.Ballistic.Game.GameMode.Helpers
{
	// Token: 0x02000098 RID: 152
	public enum Team : byte
	{
		// Token: 0x040004F3 RID: 1267
		NONE,
		// Token: 0x040004F4 RID: 1268
		MFA,
		// Token: 0x040004F5 RID: 1269
		SMOKE,
		// Token: 0x040004F6 RID: 1270
		FFA3,
		// Token: 0x040004F7 RID: 1271
		FFA4,
		// Token: 0x040004F8 RID: 1272
		FFA5,
		// Token: 0x040004F9 RID: 1273
		FFA6,
		// Token: 0x040004FA RID: 1274
		FFA7,
		// Token: 0x040004FB RID: 1275
		FFA8,
		// Token: 0x040004FC RID: 1276
		FFA9,
		// Token: 0x040004FD RID: 1277
		FFA10,
		// Token: 0x040004FE RID: 1278
		FFA11,
		// Token: 0x040004FF RID: 1279
		FFA12,
		// Token: 0x04000500 RID: 1280
		FFA13,
		// Token: 0x04000501 RID: 1281
		FFA14,
		// Token: 0x04000502 RID: 1282
		FFA15,
		// Token: 0x04000503 RID: 1283
		FFA16,
		// Token: 0x04000504 RID: 1284
		FFA17,
		// Token: 0x04000505 RID: 1285
		FFA18,
		// Token: 0x04000506 RID: 1286
		FFA19,
		// Token: 0x04000507 RID: 1287
		FFA20,
		// Token: 0x04000508 RID: 1288
		FFA21,
		// Token: 0x04000509 RID: 1289
		FFA22,
		// Token: 0x0400050A RID: 1290
		FFA23,
		// Token: 0x0400050B RID: 1291
		FFA24,
		// Token: 0x0400050C RID: 1292
		FFA25,
		// Token: 0x0400050D RID: 1293
		FFA26,
		// Token: 0x0400050E RID: 1294
		FFA27,
		// Token: 0x0400050F RID: 1295
		FFA28,
		// Token: 0x04000510 RID: 1296
		FFA29,
		// Token: 0x04000511 RID: 1297
		FFA30,
		// Token: 0x04000512 RID: 1298
		FFA31,
		// Token: 0x04000513 RID: 1299
		FFA32
	}
}
