﻿using System;

namespace Aquiris.Ballistic.Game.GameMode.Helpers
{
	// Token: 0x02000095 RID: 149
	public enum GameModeState
	{
		// Token: 0x040004E9 RID: 1257
		Waiting,
		// Token: 0x040004EA RID: 1258
		Ready
	}
}
