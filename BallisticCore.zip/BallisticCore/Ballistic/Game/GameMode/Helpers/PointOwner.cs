﻿using System;

namespace Aquiris.Ballistic.Game.GameMode.Helpers
{
	// Token: 0x02000096 RID: 150
	public enum PointOwner : byte
	{
		// Token: 0x040004EC RID: 1260
		NEUTRAL,
		// Token: 0x040004ED RID: 1261
		MFA,
		// Token: 0x040004EE RID: 1262
		SMOKES
	}
}
