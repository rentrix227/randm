﻿using System;

namespace Aquiris.Ballistic.Game.GameMode.Helpers
{
	// Token: 0x02000099 RID: 153
	public class TeamUtils
	{
		// Token: 0x06000242 RID: 578 RVA: 0x00003B49 File Offset: 0x00001D49
		public static Team Opposite(Team team)
		{
			if (team == Team.MFA)
			{
				return Team.SMOKE;
			}
			if (team != Team.SMOKE)
			{
				return Team.NONE;
			}
			return Team.MFA;
		}
	}
}
