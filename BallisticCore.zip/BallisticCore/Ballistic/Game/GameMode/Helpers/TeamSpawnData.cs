﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode.Helpers
{
	// Token: 0x0200009A RID: 154
	[Serializable]
	internal class TeamSpawnData
	{
		// Token: 0x06000243 RID: 579 RVA: 0x00003B63 File Offset: 0x00001D63
		internal TeamSpawnData(Team team)
		{
			this._remoteCharacterService = ServiceProvider.GetService<RemoteCharactersService>();
			this._team = team;
			this._positions = new List<Vector3>();
			this._spawnLocations = new Dictionary<string, SpawnLocation>();
			this.Clear();
		}

		// Token: 0x06000244 RID: 580 RVA: 0x0001ADB0 File Offset: 0x00018FB0
		internal void Clear()
		{
			this._spawnLocations.Clear();
			SpawnLocation spawnLocation = new SpawnLocation("default", World.DEAD_POSITION, Quaternion.identity);
			this._spawnLocations.Add(spawnLocation.LocationId, spawnLocation);
		}

		// Token: 0x06000245 RID: 581 RVA: 0x0001ADF0 File Offset: 0x00018FF0
		internal void AddSpawnPoint(Transform spawnPoint)
		{
			if (spawnPoint == null)
			{
				return;
			}
			SpawnLocation spawnLocation = new SpawnLocation(this._team, spawnPoint);
			if (!this._spawnLocations.ContainsKey(spawnLocation.LocationId))
			{
				this._spawnLocations.Add(spawnLocation.LocationId, spawnLocation);
			}
		}

		// Token: 0x06000246 RID: 582 RVA: 0x00003B99 File Offset: 0x00001D99
		internal SpawnLocation GetSpawnLocationById(string locationId)
		{
			if (this._spawnLocations == null)
			{
				return null;
			}
			if (this._spawnLocations.ContainsKey(locationId))
			{
				return this._spawnLocations[locationId];
			}
			return this._spawnLocations.Values.FirstOrDefault<SpawnLocation>();
		}

		// Token: 0x06000247 RID: 583 RVA: 0x0001AE40 File Offset: 0x00019040
		private static void ShuffleList<T>(IList<T> list)
		{
			int i = list.Count;
			while (i > 1)
			{
				i--;
				int num = Random.Range(0, i + 1);
				T t = list[num];
				list[num] = list[i];
				list[i] = t;
			}
		}

		// Token: 0x06000248 RID: 584 RVA: 0x0001AE8C File Offset: 0x0001908C
		internal List<SpawnLocation> GetSpawnLocationPriorityList(GameClient localPlayer)
		{
			this._positions.Clear();
			for (int i = 0; i < this._remoteCharacterService.ActivePlayers.Length; i++)
			{
				if (!UserProfile.IsMe(this._remoteCharacterService.ActivePlayers[i].PlayerId))
				{
					if (this._remoteCharacterService.ActivePlayers[i].Team != UserProfile.LocalGameClient.team)
					{
						this._positions.Add(this._remoteCharacterService.ActivePlayers[i].WorldPosition);
					}
				}
			}
			Dictionary<SpawnLocation, float> dictionary = new Dictionary<SpawnLocation, float>();
			List<KeyValuePair<string, SpawnLocation>> list = this._spawnLocations.ToList<KeyValuePair<string, SpawnLocation>>();
			TeamSpawnData.ShuffleList<KeyValuePair<string, SpawnLocation>>(list);
			foreach (KeyValuePair<string, SpawnLocation> keyValuePair in list)
			{
				if (!keyValuePair.Key.Equals("default"))
				{
					float num = float.PositiveInfinity;
					if (this._positions.Count > 0)
					{
						foreach (Vector3 vector in this._positions)
						{
							float num2 = TeamSpawnData.PlanarDistance(vector, keyValuePair.Value.SpawnPosition);
							if (num2 < num)
							{
								num = num2;
							}
						}
					}
					dictionary.Add(keyValuePair.Value, num);
				}
			}
			return (from entry in dictionary
				orderby entry.Value descending
				select entry.Key).ToList<SpawnLocation>();
		}

		// Token: 0x06000249 RID: 585 RVA: 0x00003BD6 File Offset: 0x00001DD6
		private static float PlanarDistance(Vector3 from, Vector3 to)
		{
			return Vector2.Distance(new Vector2(from.x, from.z), new Vector2(to.x, to.z));
		}

		// Token: 0x04000514 RID: 1300
		private RemoteCharactersService _remoteCharacterService;

		// Token: 0x04000515 RID: 1301
		private Dictionary<string, SpawnLocation> _spawnLocations;

		// Token: 0x04000516 RID: 1302
		protected List<Vector3> _positions;

		// Token: 0x04000517 RID: 1303
		protected Team _team;
	}
}
