﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x0200008D RID: 141
	public class ModeJuggernaut : CustomGameMode
	{
		// Token: 0x060001E2 RID: 482 RVA: 0x00003763 File Offset: 0x00001963
		public ModeJuggernaut()
		{
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x00003776 File Offset: 0x00001976
		public override SpawnLocation GetSpawnLocationById(Team team, string locationId)
		{
			return this._gameModeService.MfaData.GetSpawnLocationById(locationId);
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void OnMapLoaded(Transform gameModeRoot)
		{
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x00003789 File Offset: 0x00001989
		public override List<SpawnLocation> GetSpawnLocationPriorityList()
		{
			return this._gameModeService.MfaData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x000036D0 File Offset: 0x000018D0
		public override bool IsEnemy(GameClient a, GameClient b)
		{
			return a.gameClientId != b.gameClientId && a.team != b.team;
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void FinishGameMode()
		{
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void UpdateGameMode()
		{
		}

		// Token: 0x040004BC RID: 1212
		private readonly GameModeService _gameModeService;
	}
}
