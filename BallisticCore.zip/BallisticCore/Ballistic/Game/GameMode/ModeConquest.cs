﻿using System;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x0200008B RID: 139
	public class ModeConquest : ModeCapturePoint
	{
	}
}
