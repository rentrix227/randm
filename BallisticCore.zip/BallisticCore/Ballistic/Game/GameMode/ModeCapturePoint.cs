﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Maps;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Capture.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x0200008A RID: 138
	public class ModeCapturePoint : CustomGameMode
	{
		// Token: 0x060001CF RID: 463 RVA: 0x0000369C File Offset: 0x0000189C
		public ModeCapturePoint()
		{
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._availableZones = new Dictionary<string, CaptureZone>();
			this._playerIsCapturingPoint = new Dictionary<string, bool>();
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void FinishGameMode()
		{
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x00019B0C File Offset: 0x00017D0C
		public override SpawnLocation GetSpawnLocationById(Team team, string locationId)
		{
			switch (team)
			{
			case Team.NONE:
				Debug.Log("Team data not implemented for passed in team: " + team);
				break;
			case Team.MFA:
				return this._gameModeService.MfaData.GetSpawnLocationById(locationId);
			case Team.SMOKE:
				return this._gameModeService.SmokesData.GetSpawnLocationById(locationId);
			default:
				Debug.Log("Team data not implemented for passed in team: " + team);
				break;
			}
			return null;
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x00019B8C File Offset: 0x00017D8C
		public override List<SpawnLocation> GetSpawnLocationPriorityList()
		{
			Team team = UserProfile.LocalGameClient.team;
			if (team == Team.MFA)
			{
				return this._gameModeService.MfaData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
			}
			if (team != Team.SMOKE)
			{
				return null;
			}
			return this._gameModeService.SmokesData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x000036D0 File Offset: 0x000018D0
		public override bool IsEnemy(GameClient a, GameClient b)
		{
			return a.gameClientId != b.gameClientId && a.team != b.team;
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void OnMapLoaded(Transform gameModeRoot)
		{
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x00019BE4 File Offset: 0x00017DE4
		public bool IsPlayerCapturingPoint(string pointName)
		{
			bool flag;
			this._playerIsCapturingPoint.TryGetValue(pointName, out flag);
			return flag;
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x00019C04 File Offset: 0x00017E04
		public void StartZoneCapture(string zoneName)
		{
			CapturePointInteractionRequest capturePointInteractionRequest = new CapturePointInteractionRequest
			{
				CapturePointName = zoneName,
				CapturePointInteractionType = ECapturePointInteraction.ENTER
			};
			ServiceProvider.GetService<NetworkGameService>().RaiseNetworkEvent(capturePointInteractionRequest);
			this._playerIsCapturingPoint[zoneName] = true;
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x00019C40 File Offset: 0x00017E40
		public void StopZoneCapture(string zoneName)
		{
			CapturePointInteractionRequest capturePointInteractionRequest = new CapturePointInteractionRequest
			{
				CapturePointName = zoneName,
				CapturePointInteractionType = ECapturePointInteraction.EXIT
			};
			ServiceProvider.GetService<NetworkGameService>().RaiseNetworkEvent(capturePointInteractionRequest);
			this._playerIsCapturingPoint[zoneName] = false;
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x00019C7C File Offset: 0x00017E7C
		public override void UpdateGameMode()
		{
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			if (gameModeMetaData == null)
			{
				return;
			}
			if (gameModeMetaData.GameMetaData.PointInfo == null)
			{
				return;
			}
			foreach (PointInfo pointInfo in gameModeMetaData.GameMetaData.PointInfo)
			{
				if (pointInfo != null)
				{
					if (!string.IsNullOrEmpty(pointInfo.PointName))
					{
						if (this._availableZones.ContainsKey(pointInfo.PointName))
						{
							this._availableZones[pointInfo.PointName].UpdateZone(pointInfo);
						}
					}
				}
			}
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x000036F7 File Offset: 0x000018F7
		public void AddCaptureZone(CaptureZone zone)
		{
			this._availableZones.Add(zone.LocationId, zone);
		}

		// Token: 0x040004B7 RID: 1207
		private readonly NetworkGameService _networkGameService;

		// Token: 0x040004B8 RID: 1208
		private readonly GameModeService _gameModeService;

		// Token: 0x040004B9 RID: 1209
		private readonly Dictionary<string, CaptureZone> _availableZones;

		// Token: 0x040004BA RID: 1210
		private readonly Dictionary<string, bool> _playerIsCapturingPoint;
	}
}
