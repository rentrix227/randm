﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x0200008C RID: 140
	public class ModeFreeForAll : CustomGameMode
	{
		// Token: 0x060001DB RID: 475 RVA: 0x00003713 File Offset: 0x00001913
		public ModeFreeForAll()
		{
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
		}

		// Token: 0x060001DC RID: 476 RVA: 0x00003726 File Offset: 0x00001926
		public override SpawnLocation GetSpawnLocationById(Team team, string locationId)
		{
			return this._gameModeService.MfaData.GetSpawnLocationById(locationId);
		}

		// Token: 0x060001DD RID: 477 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void OnMapLoaded(Transform gameModeRoot)
		{
		}

		// Token: 0x060001DE RID: 478 RVA: 0x00003739 File Offset: 0x00001939
		public override List<SpawnLocation> GetSpawnLocationPriorityList()
		{
			return this._gameModeService.MfaData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
		}

		// Token: 0x060001DF RID: 479 RVA: 0x00003750 File Offset: 0x00001950
		public override bool IsEnemy(GameClient a, GameClient b)
		{
			return a.gameClientId != b.gameClientId;
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void FinishGameMode()
		{
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void UpdateGameMode()
		{
		}

		// Token: 0x040004BB RID: 1211
		private readonly GameModeService _gameModeService;
	}
}
