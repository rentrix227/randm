﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x0200008F RID: 143
	public class ModeRounds : CustomGameMode
	{
		// Token: 0x060001EA RID: 490 RVA: 0x000037A0 File Offset: 0x000019A0
		public ModeRounds()
		{
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
		}

		// Token: 0x060001EB RID: 491 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void FinishGameMode()
		{
		}

		// Token: 0x060001EC RID: 492 RVA: 0x00019D4C File Offset: 0x00017F4C
		public override SpawnLocation GetSpawnLocationById(Team team, string locationId)
		{
			switch (team)
			{
			case Team.NONE:
				Debug.Log("Team data not implemented for passed in team: " + team);
				break;
			case Team.MFA:
				return this._gameModeService.MfaData.GetSpawnLocationById(locationId);
			case Team.SMOKE:
				return this._gameModeService.SmokesData.GetSpawnLocationById(locationId);
			default:
				Debug.Log("Team data not implemented for passed in team: " + team);
				break;
			}
			return null;
		}

		// Token: 0x060001ED RID: 493 RVA: 0x00019DCC File Offset: 0x00017FCC
		public override List<SpawnLocation> GetSpawnLocationPriorityList()
		{
			if (UserProfile.LocalGameClient.team == Team.MFA)
			{
				return this._gameModeService.MfaData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
			}
			if (UserProfile.LocalGameClient.team == Team.SMOKE)
			{
				return this._gameModeService.SmokesData.GetSpawnLocationPriorityList(UserProfile.LocalGameClient);
			}
			return null;
		}

		// Token: 0x060001EE RID: 494 RVA: 0x000036D0 File Offset: 0x000018D0
		public override bool IsEnemy(GameClient a, GameClient b)
		{
			return a.gameClientId != b.gameClientId && a.team != b.team;
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void OnMapLoaded(Transform gameModeRoot)
		{
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x00002A31 File Offset: 0x00000C31
		public override void UpdateGameMode()
		{
		}

		// Token: 0x040004BD RID: 1213
		private readonly GameModeService _gameModeService;
	}
}
