﻿using System;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x02000093 RID: 147
	internal enum QueueState
	{
		// Token: 0x040004D3 RID: 1235
		FULL,
		// Token: 0x040004D4 RID: 1236
		REBALANCE,
		// Token: 0x040004D5 RID: 1237
		OPEN
	}
}
