﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Loadout;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Ballistic.Network.Transport.Player;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel.SkillModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerLoadoutModel;
using Thrift.Collections;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x02000091 RID: 145
	public class GameModeService : IService
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060001F9 RID: 505 RVA: 0x000037D5 File Offset: 0x000019D5
		// (set) Token: 0x060001FA RID: 506 RVA: 0x000037DD File Offset: 0x000019DD
		public CustomGameMode CustomGameMode { get; private set; }

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060001FB RID: 507 RVA: 0x000037E6 File Offset: 0x000019E6
		// (set) Token: 0x060001FC RID: 508 RVA: 0x000037EE File Offset: 0x000019EE
		public bool GameEnd { get; private set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060001FD RID: 509 RVA: 0x000037F7 File Offset: 0x000019F7
		// (set) Token: 0x060001FE RID: 510 RVA: 0x000037FF File Offset: 0x000019FF
		public EGameMode GameMode { get; private set; }

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060001FF RID: 511 RVA: 0x00003808 File Offset: 0x00001A08
		// (set) Token: 0x06000200 RID: 512 RVA: 0x00003810 File Offset: 0x00001A10
		public ulong GameMap { get; private set; }

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000201 RID: 513 RVA: 0x00003819 File Offset: 0x00001A19
		// (set) Token: 0x06000202 RID: 514 RVA: 0x00003821 File Offset: 0x00001A21
		public bool Beta { get; set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000203 RID: 515 RVA: 0x0000382A File Offset: 0x00001A2A
		// (set) Token: 0x06000204 RID: 516 RVA: 0x00003832 File Offset: 0x00001A32
		internal TeamSpawnData MfaData { get; private set; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000205 RID: 517 RVA: 0x0000383B File Offset: 0x00001A3B
		// (set) Token: 0x06000206 RID: 518 RVA: 0x00003843 File Offset: 0x00001A43
		internal TeamSpawnData SmokesData { get; private set; }

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000207 RID: 519 RVA: 0x0000384C File Offset: 0x00001A4C
		// (set) Token: 0x06000208 RID: 520 RVA: 0x00003854 File Offset: 0x00001A54
		public bool FriendlyFire { get; private set; }

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000209 RID: 521 RVA: 0x0000385D File Offset: 0x00001A5D
		// (set) Token: 0x0600020A RID: 522 RVA: 0x00003865 File Offset: 0x00001A65
		public bool AutoBalance { get; private set; }

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x0600020B RID: 523 RVA: 0x0000386E File Offset: 0x00001A6E
		// (set) Token: 0x0600020C RID: 524 RVA: 0x00003876 File Offset: 0x00001A76
		public GameModeState State { get; private set; }

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600020D RID: 525 RVA: 0x0000387F File Offset: 0x00001A7F
		// (set) Token: 0x0600020E RID: 526 RVA: 0x00003887 File Offset: 0x00001A87
		public PlayerLoadoutData SelectedLoadout { get; private set; }

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x0600020F RID: 527 RVA: 0x00003890 File Offset: 0x00001A90
		// (set) Token: 0x06000210 RID: 528 RVA: 0x00003898 File Offset: 0x00001A98
		public float PointsPerKill { get; private set; }

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000211 RID: 529 RVA: 0x000038A1 File Offset: 0x00001AA1
		// (set) Token: 0x06000212 RID: 530 RVA: 0x000038A9 File Offset: 0x00001AA9
		public float WaveTimeLeft { get; private set; }

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000213 RID: 531 RVA: 0x000038B2 File Offset: 0x00001AB2
		// (set) Token: 0x06000214 RID: 532 RVA: 0x000038BA File Offset: 0x00001ABA
		public float TimeLeft { get; private set; }

		// Token: 0x06000215 RID: 533 RVA: 0x00019F40 File Offset: 0x00018140
		internal override void Preprocess()
		{
			this.PointsPerKill = 1f;
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnClientConnectionEstablished.AddListener(new Action(this.HandleClientConnectionEstablished));
			this._networkGameService.OnClientConnectionClosed.AddListener(new Action(this.HandleClientConnectionClosed));
			this._networkGameService.OnTimeRemaining.AddListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnReadyToSpawn.AddListener(new Action<ReadyToSpawnResponse>(this.HandleUserReadyToSpawn));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.HandleVoteStart));
			this._networkGameService.OnVoteEnd.AddListener(new Action<VoteMapEndEvent>(this.HandleVoteEnd));
			this._networkGameService.OnMapLoad.AddListener(new Action<MapLoadEvent>(this.HandleMapLoad));
			this.MfaData = new TeamSpawnData(Team.MFA);
			this.SmokesData = new TeamSpawnData(Team.SMOKE);
			this._eventProxy = ServiceProvider.GetService<EventProxy>();
			ServiceProvider.GetService<SceneService>().OnSceneLoaded += this.OnMapLoaded;
		}

		// Token: 0x06000216 RID: 534 RVA: 0x000038C3 File Offset: 0x00001AC3
		private void HandleClientConnectionEstablished()
		{
			this.State = GameModeState.Waiting;
		}

		// Token: 0x06000217 RID: 535 RVA: 0x000038CC File Offset: 0x00001ACC
		private void OnTimeRemaining(TimeRemainingEvent evt)
		{
			this.TimeLeft = (float)evt.RemainingTime;
			if (this.TimeLeft < 0f)
			{
				this.TimeLeft = 0f;
			}
		}

		// Token: 0x06000218 RID: 536 RVA: 0x0001A060 File Offset: 0x00018260
		internal override void Postprocess()
		{
			this._networkGameService.OnClientConnectionEstablished.RemoveListener(new Action(this.HandleClientConnectionEstablished));
			this._networkGameService.OnClientConnectionClosed.RemoveListener(new Action(this.HandleClientConnectionClosed));
			this._networkGameService.OnTimeRemaining.RemoveListener(new Action<TimeRemainingEvent>(this.OnTimeRemaining));
			this._networkGameService.OnReadyToSpawn.RemoveListener(new Action<ReadyToSpawnResponse>(this.HandleUserReadyToSpawn));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.HandleVoteStart));
			this._networkGameService.OnVoteEnd.RemoveListener(new Action<VoteMapEndEvent>(this.HandleVoteEnd));
			this._networkGameService.OnMapLoad.RemoveListener(new Action<MapLoadEvent>(this.HandleMapLoad));
			ServiceProvider.GetService<SceneService>().OnSceneLoaded += this.OnMapLoaded;
		}

		// Token: 0x06000219 RID: 537 RVA: 0x000038F6 File Offset: 0x00001AF6
		public bool IsEnd()
		{
			return this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType != EGameState.PLAYING && this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType != EGameState.ROUNDUP;
		}

		// Token: 0x0600021A RID: 538 RVA: 0x00003931 File Offset: 0x00001B31
		public void RequestSpawn(PlayerLoadoutData selectedLoadout)
		{
			if (this.TimeLeft <= 1f)
			{
				return;
			}
			this.SelectedLoadout = selectedLoadout;
			this.WaveTimeLeft = 0f;
			this._isRequestingSpawn = true;
			this.CheckSpawn();
		}

		// Token: 0x0600021B RID: 539 RVA: 0x00003963 File Offset: 0x00001B63
		public bool IsEnemy(GameClient a, GameClient b)
		{
			return a == null || b == null || this.CustomGameMode.IsEnemy(a, b);
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0001A148 File Offset: 0x00018348
		public void SetGameModeAndRestart(EGameMode gameMode, ulong map, bool beta)
		{
			this.FinishService();
			this._isRequestingSpawn = false;
			this.PointsPerKill = (float)ServiceProvider.GetService<GameMapModeConfigService>().GetGameModeConfig(map, gameMode).PointsPerKill;
			this.GameMode = gameMode;
			this.GameMap = map;
			this.Beta = beta;
			this.State = GameModeState.Waiting;
			switch (gameMode)
			{
			case EGameMode.TeamDeathMatch:
				this.CustomGameMode = new ModeTeamDeathMatch(this.Beta);
				break;
			case EGameMode.Conquest:
				this.CustomGameMode = new ModeConquest();
				break;
			case EGameMode.KingOfTheHill:
				this.CustomGameMode = new ModeKingOfTheHill();
				break;
			case EGameMode.Rounds:
				this.CustomGameMode = new ModeRounds();
				break;
			case EGameMode.FreeForAll:
				this.CustomGameMode = new ModeFreeForAll();
				break;
			case EGameMode.Juggernaut:
				this.CustomGameMode = new ModeJuggernaut();
				break;
			}
			this.AutoBalance = this._networkGameService.GetGameModeMetaData().GameConfig.AutoBalance;
			this.FriendlyFire = false;
			this.WaveTimeLeft = 0f;
			this.GameEnd = false;
			this._eventProxy.EUpdate.AddListener(new Action(this.UpdateGameMode));
		}

		// Token: 0x0600021D RID: 541 RVA: 0x0001A274 File Offset: 0x00018474
		private void UpdateGameMode()
		{
			if (this.GameEnd)
			{
				return;
			}
			this.CustomGameMode.UpdateGameMode();
			this.TimeLeft -= Time.deltaTime;
			if (this.TimeLeft < 0f)
			{
				this.TimeLeft = 0f;
			}
			this.WaveTimeLeft -= Time.deltaTime;
			if (this.WaveTimeLeft < 0f)
			{
				this.WaveTimeLeft = 0f;
			}
			if (this.State != GameModeState.Ready)
			{
				return;
			}
			if (UserProfile.LocalGameClient == null)
			{
				return;
			}
			if (UserProfile.LocalGameClient.spawned)
			{
				if (this._isRequestingSpawn)
				{
					this._isRequestingSpawn = false;
				}
				return;
			}
			this.CheckSpawn();
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0001A334 File Offset: 0x00018534
		private void CheckSpawn()
		{
			if (!this._isRequestingSpawn)
			{
				return;
			}
			List<SpawnLocation> spawnLocationPriorityList = this.GetSpawnLocationPriorityList();
			ReadyToSpawnRequest readyToSpawnRequest = new ReadyToSpawnRequest
			{
				PreferedSpawnPoints = new THashSet<string>()
			};
			if (spawnLocationPriorityList != null)
			{
				for (int i = 0; i < spawnLocationPriorityList.Count; i++)
				{
					readyToSpawnRequest.PreferedSpawnPoints.Add(spawnLocationPriorityList[i].LocationId);
				}
			}
			LoadoutInfo loadoutInfo = new LoadoutInfo
			{
				LoadoutItemMap = new Dictionary<int, int>
				{
					{
						1,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.PrimaryWeapon]
					},
					{
						2,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.SecondaryWeapon]
					},
					{
						3,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.MeleeWeapon]
					},
					{
						4,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.Explosive]
					},
					{
						5,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.Skin]
					},
					{
						6,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.PrimaryWeaponSkin]
					},
					{
						7,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.SecondaryWeaponSkin]
					},
					{
						8,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.MeleeWeaponSkin]
					},
					{
						9,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.ExplosiveSkin]
					},
					{
						11,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryHead]
					},
					{
						13,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryChest]
					},
					{
						15,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryBack]
					},
					{
						14,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryPelvis]
					},
					{
						12,
						this.SelectedLoadout.PlayerItem.ItemMap[EHeroItemSlot.AccessoryFeet]
					}
				}
			};
			PlayerHeroData playerHeroData = ServiceProvider.GetService<PlayerHeroService>().GetPlayerHeroData(this.SelectedLoadout);
			loadoutInfo.Hero = playerHeroData.PlayerItem.GameItemID;
			loadoutInfo.HeroLevel = ServiceProvider.GetService<ProgressionService>().GetHeroClassLevel(playerHeroData.GameItemData.GameItem.UniqueIdentifier);
			loadoutInfo.SkillList = new List<int>();
			foreach (EHeroSkillV2 eheroSkillV in this.SelectedLoadout.PlayerItem.Skills)
			{
				loadoutInfo.SkillList.Add((int)eheroSkillV);
			}
			readyToSpawnRequest.LoadoutInfo = loadoutInfo;
			readyToSpawnRequest.ReadyToSpawn = true;
			this._networkGameService.RaiseNetworkEvent(readyToSpawnRequest);
		}

		// Token: 0x0600021F RID: 543 RVA: 0x00003980 File Offset: 0x00001B80
		public void FinishService()
		{
			this._eventProxy.EUpdate.RemoveListener(new Action(this.UpdateGameMode));
			if (this.CustomGameMode != null)
			{
				this.CustomGameMode.FinishGameMode();
				this.CustomGameMode = null;
			}
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0001A638 File Offset: 0x00018838
		private void OnMapLoaded(EBaseScene scene)
		{
			if (scene != EBaseScene.InGame)
			{
				return;
			}
			GameObject gameObject = GameObject.Find("GameModes");
			if (gameObject == null)
			{
				Debug.LogError("GameMode: failed to locate GameMode root in this map");
				return;
			}
			Transform transform;
			if (this.Beta && this.GameMode == EGameMode.TeamDeathMatch)
			{
				transform = gameObject.transform.Find(EGameMode.FreeForAll.ToString());
				transform.name = this.GameMode.ToString();
			}
			else
			{
				transform = gameObject.transform.Find(this.GameMode.ToString());
			}
			if (transform == null)
			{
				Debug.LogError("GameMode: failed to locate GameMode[" + this.GameMode.ToString() + "] in this map");
				return;
			}
			transform.parent = gameObject.transform.parent;
			Object.Destroy(gameObject);
			this.MfaData.Clear();
			this.SmokesData.Clear();
			Transform transform2 = transform.Find("SpawnPoints").Find(Team.MFA.ToString());
			if (transform2 != null)
			{
				for (int i = 0; i < transform2.childCount; i++)
				{
					this.MfaData.AddSpawnPoint(transform2.GetChild(i));
				}
			}
			Transform transform3 = transform.Find("SpawnPoints").Find(Team.SMOKE.ToString());
			if (transform3 != null)
			{
				for (int j = 0; j < transform3.childCount; j++)
				{
					this.SmokesData.AddSpawnPoint(transform3.GetChild(j));
				}
			}
			ProgressionService service = ServiceProvider.GetService<ProgressionService>();
			Dictionary<short, short> dictionary = new Dictionary<short, short>
			{
				{
					0,
					(short)service.GetAllHeroLevel()
				},
				{
					1,
					(short)service.GetHeroClassLevel(EHeroClass.BERSERKER)
				},
				{
					6,
					(short)service.GetHeroClassLevel(EHeroClass.VANGUARD)
				},
				{
					4,
					(short)service.GetHeroClassLevel(EHeroClass.SHADOW)
				},
				{
					7,
					(short)service.GetHeroClassLevel(EHeroClass.WRAITH)
				},
				{
					5,
					(short)service.GetHeroClassLevel(EHeroClass.TANK)
				},
				{
					2,
					(short)service.GetHeroClassLevel(EHeroClass.GRENADIER)
				},
				{
					3,
					(short)service.GetHeroClassLevel(EHeroClass.MARKSMAN)
				}
			};
			this._networkGameService.GetClientCommonMetaData((long)UserProfile.MyId()).Levels = dictionary;
			PlayerInfoEvent playerInfoEvent = new PlayerInfoEvent
			{
				User = (long)UserProfile.MyId(),
				PlayerLevels = dictionary
			};
			ServiceProvider.GetService<NetworkGameService>().RaiseNetworkEvent(playerInfoEvent);
			this.State = GameModeState.Ready;
			this.CustomGameMode.OnMapLoaded(transform);
		}

		// Token: 0x06000221 RID: 545 RVA: 0x000039BB File Offset: 0x00001BBB
		private List<SpawnLocation> GetSpawnLocationPriorityList()
		{
			if (this.CustomGameMode == null)
			{
				return null;
			}
			return this.CustomGameMode.GetSpawnLocationPriorityList();
		}

		// Token: 0x06000222 RID: 546 RVA: 0x000039D5 File Offset: 0x00001BD5
		public SpawnLocation GetSpawnLocationById(Team team, string locationId)
		{
			if (this.CustomGameMode == null)
			{
				return null;
			}
			return this.CustomGameMode.GetSpawnLocationById(team, locationId);
		}

		// Token: 0x06000223 RID: 547 RVA: 0x000039F1 File Offset: 0x00001BF1
		private void HandleUserReadyToSpawn(ReadyToSpawnResponse evt)
		{
			this.WaveTimeLeft = (float)((!evt.ReadyToSpawn) ? 0 : ((int)evt.TimeToSpawnInSeconds));
		}

		// Token: 0x06000224 RID: 548 RVA: 0x00003A12 File Offset: 0x00001C12
		private void HandleMapLoad(MapLoadEvent evt)
		{
			this.SetGameModeAndRestart(evt.GameMode, evt.GameMapId, evt.Beta);
		}

		// Token: 0x06000225 RID: 549 RVA: 0x00003A2C File Offset: 0x00001C2C
		private void HandleVoteStart(VoteMapStartEvent evt)
		{
			this.GameEnd = true;
		}

		// Token: 0x06000226 RID: 550 RVA: 0x00003A35 File Offset: 0x00001C35
		private void HandleVoteEnd(VoteMapEndEvent evt)
		{
			this.SetGameModeAndRestart(evt.MapModeEntry.GameMode, (ulong)evt.MapModeEntry.GameMap, evt.MapModeEntry.Beta);
		}

		// Token: 0x06000227 RID: 551 RVA: 0x00003A5E File Offset: 0x00001C5E
		private void HandleClientConnectionClosed()
		{
			this.FinishService();
		}

		// Token: 0x06000228 RID: 552 RVA: 0x00003A66 File Offset: 0x00001C66
		internal bool BlockedByRebalance(int teamPretendedCount, int teamOppositeCount)
		{
			return teamPretendedCount <= teamOppositeCount + 1;
		}

		// Token: 0x06000229 RID: 553 RVA: 0x0001A8F4 File Offset: 0x00018AF4
		public ClientCommonMetaData GetTeammateTarget(sbyte team)
		{
			return this._networkGameService.GetGameModeMetaData().ClientMetaDataMap.Values.FirstOrDefault((ClientCommonMetaData t) => t.ClientMode == EClientMode.PLAYER && t.CurrentState == EPlayerState.ALIVE && (int)t.Team == (int)team && UserProfile.LocalGameClient.gameClientId != t.User);
		}

		// Token: 0x0600022A RID: 554 RVA: 0x0001A934 File Offset: 0x00018B34
		internal QueueState MatchIsFull(ETeamMode teamMode)
		{
			GameModeMetaData gameModeMetaData = this._networkGameService.GetGameModeMetaData();
			EGameMode gameMode = this.GameMode;
			if (gameMode == EGameMode.FreeForAll || gameMode == EGameMode.Juggernaut)
			{
				int num = 0;
				foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in gameModeMetaData.ClientMetaDataMap)
				{
					if (keyValuePair.Value.ClientMode == EClientMode.PLAYER || gameModeMetaData.QueueMetaDataList.Contains(keyValuePair.Key))
					{
						num++;
					}
				}
				return ((int)gameModeMetaData.GameConfig.MaxPlayers > num) ? QueueState.OPEN : QueueState.FULL;
			}
			int num2 = 0;
			int num3 = 0;
			foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair2 in gameModeMetaData.ClientMetaDataMap)
			{
				if (keyValuePair2.Value.ClientMode == EClientMode.PLAYER && (int)keyValuePair2.Value.Team == 1)
				{
					num2++;
				}
				else if ((keyValuePair2.Value.RequestMode == ETeamMode.MFA || keyValuePair2.Value.RequestMode == ETeamMode.ANY) && gameModeMetaData.QueueMetaDataList.Contains(keyValuePair2.Key))
				{
					num2++;
				}
				if (keyValuePair2.Value.ClientMode == EClientMode.PLAYER && (int)keyValuePair2.Value.Team == 2)
				{
					num3++;
				}
				else if ((keyValuePair2.Value.RequestMode == ETeamMode.SMOKE || keyValuePair2.Value.RequestMode == ETeamMode.ANY) && gameModeMetaData.QueueMetaDataList.Contains(keyValuePair2.Key))
				{
					num3++;
				}
			}
			if (teamMode != ETeamMode.MFA)
			{
				if (teamMode != ETeamMode.SMOKE)
				{
					return QueueState.OPEN;
				}
				if ((int)(gameModeMetaData.GameConfig.MaxPlayers / 2) <= num3)
				{
					return QueueState.FULL;
				}
				if (num3 > num2 + 1)
				{
					return QueueState.REBALANCE;
				}
				return QueueState.OPEN;
			}
			else
			{
				if ((int)(gameModeMetaData.GameConfig.MaxPlayers / 2) <= num2)
				{
					return QueueState.FULL;
				}
				if (num2 > num3 + 1)
				{
					return QueueState.REBALANCE;
				}
				return QueueState.OPEN;
			}
		}

		// Token: 0x0600022B RID: 555 RVA: 0x0001AB84 File Offset: 0x00018D84
		internal int GetWaitingForTeam(ETeamMode teamMode, bool excludeSelf)
		{
			int num = 0;
			foreach (long num2 in this._networkGameService.GetGameModeMetaData().QueueMetaDataList)
			{
				ClientCommonMetaData clientCommonMetaData = this._networkGameService.GetClientCommonMetaData(num2);
				if (clientCommonMetaData != null)
				{
					if (!UserProfile.IsMe(clientCommonMetaData.User) || !excludeSelf)
					{
						if (clientCommonMetaData.ClientMode == EClientMode.SPECTATOR && (clientCommonMetaData.RequestMode == teamMode || clientCommonMetaData.RequestMode == ETeamMode.ANY))
						{
							num++;
						}
					}
				}
			}
			return num;
		}

		// Token: 0x040004C0 RID: 1216
		private NetworkGameService _networkGameService;

		// Token: 0x040004CF RID: 1231
		private EventProxy _eventProxy;

		// Token: 0x040004D0 RID: 1232
		private bool _isRequestingSpawn;
	}
}
