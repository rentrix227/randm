﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine;

namespace Aquiris.Ballistic.Game.GameMode
{
	// Token: 0x02000089 RID: 137
	public abstract class CustomGameMode
	{
		// Token: 0x060001C9 RID: 457
		public abstract bool IsEnemy(GameClient a, GameClient b);

		// Token: 0x060001CA RID: 458
		public abstract List<SpawnLocation> GetSpawnLocationPriorityList();

		// Token: 0x060001CB RID: 459
		public abstract SpawnLocation GetSpawnLocationById(Team team, string locationId);

		// Token: 0x060001CC RID: 460
		public abstract void OnMapLoaded(Transform gameModeRoot);

		// Token: 0x060001CD RID: 461
		public abstract void UpdateGameMode();

		// Token: 0x060001CE RID: 462
		public abstract void FinishGameMode();
	}
}
