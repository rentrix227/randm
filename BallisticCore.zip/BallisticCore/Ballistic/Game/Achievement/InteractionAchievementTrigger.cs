﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x0200005F RID: 95
	[RequireComponent(typeof(BoxCollider))]
	public class InteractionAchievementTrigger : VisibilityAchievementTrigger
	{
		// Token: 0x060000B7 RID: 183 RVA: 0x00002B97 File Offset: 0x00000D97
		public virtual void Awake()
		{
			this._optionControlService = ServiceProvider.GetService<OptionControlService>();
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x060000B8 RID: 184 RVA: 0x00016E48 File Offset: 0x00015048
		protected override bool UnlockRequirementsAreSatisfied
		{
			get
			{
				bool flag = false;
				for (int i = 0; i < this.KeysToTrigger.Count; i++)
				{
					if (Input.GetKeyDown(this.KeysToTrigger[i]))
					{
						flag = true;
						break;
					}
				}
				for (int j = 0; j < this.ActionsToTrigger.Count; j++)
				{
					if (this._optionControlService.GetKeyDown(this.ActionsToTrigger[j]))
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					return false;
				}
				Vector3 vector = this._localCharacterService.WorldPosition - base.transform.position;
				Vector3 vector2 = vector;
				vector2.y = 0f;
				float num = Mathf.Abs(vector.y);
				return vector2.magnitude <= this.HorizontalDistance && num <= this.VerticalDistance && base.UnlockRequirementsAreSatisfied;
			}
		}

		// Token: 0x04000308 RID: 776
		public float HorizontalDistance = 0.7f;

		// Token: 0x04000309 RID: 777
		public float VerticalDistance = 1.8f;

		// Token: 0x0400030A RID: 778
		public List<KeyCode> KeysToTrigger = new List<KeyCode>();

		// Token: 0x0400030B RID: 779
		public List<KeyType> ActionsToTrigger = new List<KeyType>();

		// Token: 0x0400030C RID: 780
		private OptionControlService _optionControlService;

		// Token: 0x0400030D RID: 781
		private LocalCharacterService _localCharacterService;
	}
}
