﻿using System;
using System.Collections.Generic;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x02000063 RID: 99
	public abstract class SceneBasedAchievementTrigger : MonoBehaviour
	{
		// Token: 0x060000C7 RID: 199 RVA: 0x00016F64 File Offset: 0x00015164
		private int GetAmount(Dictionary<EAchievementType, int> dict)
		{
			int num = 0;
			dict.TryGetValue(this.AchievementToUnlock, out num);
			return num;
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x00002CA7 File Offset: 0x00000EA7
		private void Increment(Dictionary<EAchievementType, int> dict, int amount)
		{
			dict[this.AchievementToUnlock] = this.GetAmount(dict) + amount;
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x00002CBE File Offset: 0x00000EBE
		public virtual void OnEnable()
		{
			this.Increment(SceneBasedAchievementTrigger._activeTriggers, 1);
		}

		// Token: 0x060000CA RID: 202 RVA: 0x00002CCC File Offset: 0x00000ECC
		public virtual void OnDisable()
		{
			this.Increment(SceneBasedAchievementTrigger._activeTriggers, -1);
			if (this._hasTriggeredAchievement)
			{
				this.Increment(SceneBasedAchievementTrigger._unlockedTriggers, -1);
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x060000CB RID: 203
		protected abstract bool UnlockRequirementsAreSatisfied { get; }

		// Token: 0x060000CC RID: 204 RVA: 0x00016F84 File Offset: 0x00015184
		public virtual void LateUpdate()
		{
			if (this.UnlockRequirementsAreSatisfied && !this._hasTriggeredAchievement)
			{
				this._hasTriggeredAchievement = true;
				this.Increment(SceneBasedAchievementTrigger._unlockedTriggers, 1);
				bool flag = false;
				if (!this.RequireAllInLevel)
				{
					flag = true;
				}
				else if (this.GetAmount(SceneBasedAchievementTrigger._unlockedTriggers) >= this.GetAmount(SceneBasedAchievementTrigger._activeTriggers))
				{
					flag = true;
				}
				if (flag)
				{
					ServiceProvider.GetService<AchievementService>().UnlockAchievement(this.AchievementToUnlock);
				}
			}
		}

		// Token: 0x04000311 RID: 785
		public EAchievementType AchievementToUnlock;

		// Token: 0x04000312 RID: 786
		public bool RequireAllInLevel;

		// Token: 0x04000313 RID: 787
		protected bool _hasTriggeredAchievement;

		// Token: 0x04000314 RID: 788
		private static readonly Dictionary<EAchievementType, int> _activeTriggers = new Dictionary<EAchievementType, int>();

		// Token: 0x04000315 RID: 789
		private static readonly Dictionary<EAchievementType, int> _unlockedTriggers = new Dictionary<EAchievementType, int>();
	}
}
