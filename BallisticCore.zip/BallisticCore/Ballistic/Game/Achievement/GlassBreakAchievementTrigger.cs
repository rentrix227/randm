﻿using System;
using Aquiris.Ballistic.Game.Maps;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x0200005E RID: 94
	[RequireComponent(typeof(GlassBehaviour))]
	public class GlassBreakAchievementTrigger : SceneBasedAchievementTrigger
	{
		// Token: 0x060000B3 RID: 179 RVA: 0x00002B29 File Offset: 0x00000D29
		public void Awake()
		{
			GlassBehaviour component = base.GetComponent<GlassBehaviour>();
			component.OnBreak = (Action<bool>)Delegate.Combine(component.OnBreak, new Action<bool>(this.OnBreak));
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00002B52 File Offset: 0x00000D52
		private void OnBreak(bool isFirstPerson)
		{
			this._isBroken = true;
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x060000B5 RID: 181 RVA: 0x00002B5B File Offset: 0x00000D5B
		protected override bool UnlockRequirementsAreSatisfied
		{
			get
			{
				return this._isBroken;
			}
		}

		// Token: 0x04000307 RID: 775
		private bool _isBroken;
	}
}
