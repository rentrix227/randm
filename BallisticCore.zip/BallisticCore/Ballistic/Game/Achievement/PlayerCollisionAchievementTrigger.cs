﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x02000061 RID: 97
	[RequireComponent(typeof(Collider))]
	public class PlayerCollisionAchievementTrigger : SceneBasedAchievementTrigger
	{
		// Token: 0x060000BF RID: 191 RVA: 0x00002C26 File Offset: 0x00000E26
		public void OnTriggerEnter(Collider other)
		{
			if (other.CompareTag("fpsPlayer"))
			{
				this._playerIsInsideTrigger = true;
			}
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00002C3F File Offset: 0x00000E3F
		public void OnTriggerExit(Collider other)
		{
			if (other.CompareTag("fpsPlayer"))
			{
				this._playerIsInsideTrigger = false;
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060000C1 RID: 193 RVA: 0x00002C58 File Offset: 0x00000E58
		protected override bool UnlockRequirementsAreSatisfied
		{
			get
			{
				return this._playerIsInsideTrigger;
			}
		}

		// Token: 0x0400030F RID: 783
		protected bool _playerIsInsideTrigger;
	}
}
