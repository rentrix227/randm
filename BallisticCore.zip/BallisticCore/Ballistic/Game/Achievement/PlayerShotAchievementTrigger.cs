﻿using System;
using Aquiris.Ballistic.Game.Maps;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x02000062 RID: 98
	public class PlayerShotAchievementTrigger : SceneBasedAchievementTrigger
	{
		// Token: 0x060000C3 RID: 195 RVA: 0x00002C60 File Offset: 0x00000E60
		public void Awake()
		{
			ShootableTrigger shootableTrigger = base.gameObject.AddComponent<ShootableTrigger>();
			shootableTrigger.OnShot = (Action)Delegate.Combine(shootableTrigger.OnShot, new Action(this.OnShot));
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x00002C8E File Offset: 0x00000E8E
		private void OnShot()
		{
			this._playerHasShotMe = true;
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060000C5 RID: 197 RVA: 0x00002C97 File Offset: 0x00000E97
		protected override bool UnlockRequirementsAreSatisfied
		{
			get
			{
				return this._playerHasShotMe;
			}
		}

		// Token: 0x04000310 RID: 784
		protected bool _playerHasShotMe;
	}
}
