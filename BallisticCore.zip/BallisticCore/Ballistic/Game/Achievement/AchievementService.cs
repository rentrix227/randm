﻿using System;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Capture.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Ballistic.Network.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.AccessoryModel;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Lockbox;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using Aquiris.Services.ItemModel.PlayerItemModel.PlayerHeroSkinModel;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x0200005B RID: 91
	internal class AchievementService : IService
	{
		// Token: 0x06000099 RID: 153 RVA: 0x00016494 File Offset: 0x00014694
		internal override void Preprocess()
		{
			InventoryService service = ServiceProvider.GetService<InventoryService>();
			service.OnItemDrop = (Action<SteamItem>)Delegate.Combine(service.OnItemDrop, new Action<SteamItem>(this.OnItemDrop));
			InventoryService service2 = ServiceProvider.GetService<InventoryService>();
			service2.OnWeaponSkinUnlocked = (Action<SteamItem>)Delegate.Combine(service2.OnWeaponSkinUnlocked, new Action<SteamItem>(this.OnWeaponSkinUnlocked));
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnClientListReceived.AddListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnVoteStart.AddListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnDie.AddListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnUserHit.AddListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnCapturedPoint.AddListener(new Action<CapturedPointEvent>(this.OnCapturedPoint));
			this._transmissionService = ServiceProvider.GetService<TransmissionService>();
			this._transmissionService.OnShoot.AddListener(new Action<OnShootData>(this.OnShoot));
			this._transmissionService.OnReload.AddListener(new Action<OnReloadData>(this.OnReload));
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			this._statisticsService = ServiceProvider.GetService<StatisticsService>();
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._localCharacterService.OnFallDamage += this.OnFallDamage;
			ServiceProvider.GetService<EventProxy>().EUpdate.AddListener(new Action(this.Update));
			InGameHeaderController.OnChatMessageSent = (Action<string>)Delegate.Combine(InGameHeaderController.OnChatMessageSent, new Action<string>(this.OnChatMessageSent));
			this._hasWrittenCrossWord = new bool[this._crossWords.Length];
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00016650 File Offset: 0x00014850
		private void OnChatMessageSent(string s)
		{
			bool flag = false;
			for (int i = 0; i < this._crossWords.Length; i++)
			{
				if (!this._hasWrittenCrossWord[i])
				{
					if (s.IndexOf(this._crossWords[i], StringComparison.InvariantCultureIgnoreCase) >= 0)
					{
						this._hasWrittenCrossWord[i] = true;
						flag = true;
					}
				}
			}
			if (flag)
			{
				int num = 0;
				for (int j = 0; j < this._crossWords.Length; j++)
				{
					if (this._hasWrittenCrossWord[j])
					{
						num++;
					}
				}
				if (num >= this._crossWords.Length)
				{
					this.UnlockAchievement(EAchievementType.INFINITE_LEARNING);
				}
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00002A33 File Offset: 0x00000C33
		private void OnFallDamage(float distance)
		{
			this._lastFallDamageDistance = distance;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x000166F4 File Offset: 0x000148F4
		private void CheckForAchievementsToUnlock()
		{
			if (this._achievementsToUnlock.Count > 0)
			{
				for (int i = 0; i < this._achievementsToUnlock.Count; i++)
				{
					string text = this._achievementsToUnlock[i].ToString();
					bool flag;
					SteamUserStats.GetAchievement(text, ref flag);
					if (!flag)
					{
						SteamUserStats.StoreStats();
						SteamUserStats.SetAchievement(text);
					}
				}
				this._achievementsToUnlock.Clear();
			}
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00016778 File Offset: 0x00014978
		private void Update()
		{
			if (this._statisticsService.IsCacheReady)
			{
				if (!this._hasCheckedForSwag)
				{
					this.CheckForSwag();
					this._hasCheckedForSwag = true;
				}
				this.CheckForAchievementsToUnlock();
			}
			if (this._gameModeService.GameMode == EGameMode.KingOfTheHill)
			{
				this._playerIsInsideKingOfTheHillPoint = (this._gameModeService.CustomGameMode as ModeKingOfTheHill).IsPlayerCapturingPoint("A");
				if (!this._playerIsInsideKingOfTheHillPoint)
				{
					this._enemiesKilledWhileInsideKingOfTheHill = 0;
				}
			}
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00002A3C File Offset: 0x00000C3C
		private void OnCapturedPoint(CapturedPointEvent capturedPointEvent)
		{
			this._pointsCapturedThisLife++;
			if (this._pointsCapturedThisLife >= 3)
			{
				this.UnlockAchievement(EAchievementType.ON_POINT);
			}
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00002A60 File Offset: 0x00000C60
		private void OnReload(OnReloadData onReloadData)
		{
			if (onReloadData.WeaponName == this._currentWeapon)
			{
				this._enemiesKilledWithoutReloading = 0;
			}
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00002A80 File Offset: 0x00000C80
		private void OnShoot(OnShootData onShootData)
		{
			if (!onShootData.IsFirstPerson)
			{
				return;
			}
			if (onShootData.WeaponName != this._currentWeapon)
			{
				this._currentWeapon = onShootData.WeaponName;
				this._enemiesKilledWithoutReloading = 0;
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00002ABA File Offset: 0x00000CBA
		private void OnClientListReceived(ClientListReceivedEvent clientListReceivedEvent)
		{
			this.ClearLifeTracking();
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00002AC2 File Offset: 0x00000CC2
		private void ClearLifeTracking()
		{
			this._totalDamageInflictedThisLife = 0;
			this._grenadeKills.Clear();
			this._pointsCapturedThisLife = 0;
			this._enemiesKilledWhileInsideKingOfTheHill = 0;
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x000167F8 File Offset: 0x000149F8
		private void OnUserHit(HitEvent hitEvent)
		{
			if (hitEvent.Sender.isMe && !hitEvent.VictimGameClient.isMe)
			{
				int totalDamageInflictedThisLife = this._totalDamageInflictedThisLife;
				this._totalDamageInflictedThisLife += Mathf.RoundToInt(hitEvent.Damage);
				if (totalDamageInflictedThisLife < 2000 && this._totalDamageInflictedThisLife >= 2000)
				{
					this.UnlockAchievement(EAchievementType.FORCE_OF_NATURE);
				}
			}
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00016868 File Offset: 0x00014A68
		private void OnDie(DieEvent dieEvent)
		{
			if (dieEvent.Killer.isMe && !dieEvent.Sender.isMe)
			{
				if (dieEvent.KillerMultiKill > 3)
				{
					this.UnlockAchievement(EAchievementType.GO_BALLISTIC);
				}
				if (dieEvent.WeaponCategory != EWeaponCategory.Explosive && dieEvent.WeaponCategory != EWeaponCategory.GrenadeLauncher && dieEvent.WeaponCategory != EWeaponCategory.Melee && dieEvent.WeaponCategory != EWeaponCategory.MeleeSpecial && dieEvent.WeaponCategory != EWeaponCategory.Concussion && dieEvent.WeaponCategory != EWeaponCategory.None)
				{
					this._enemiesKilledWithoutReloading++;
					if (this._enemiesKilledWithoutReloading >= 3)
					{
						this.UnlockAchievement(EAchievementType.UNSTOPPABLE);
					}
				}
				if (dieEvent.WeaponCategory == EWeaponCategory.Explosive || dieEvent.WeaponCategory == EWeaponCategory.GrenadeLauncher)
				{
					int num;
					this._grenadeKills.TryGetValue(dieEvent.GrenadeId, out num);
					num++;
					if (num >= 2)
					{
						this.UnlockAchievement(EAchievementType.BIG_BOOM);
					}
					this._grenadeKills[dieEvent.GrenadeId] = num;
				}
				if (dieEvent.IsBackstab)
				{
					double utctimeAsDouble = TimeUtils.getUTCTimeAsDouble();
					while (this._lastBackstabTimestamps.Count > 0 && this._lastBackstabTimestamps[0] < utctimeAsDouble - 5000.0)
					{
						this._lastBackstabTimestamps.RemoveAt(0);
					}
					this._lastBackstabTimestamps.Add(utctimeAsDouble);
					if (this._lastBackstabTimestamps.Count >= 2)
					{
						this.UnlockAchievement(EAchievementType.BACK_SCRATCHER);
					}
				}
				if (this._playerIsInsideKingOfTheHillPoint)
				{
					this._enemiesKilledWhileInsideKingOfTheHill++;
					if (this._enemiesKilledWhileInsideKingOfTheHill >= 5)
					{
						this.UnlockAchievement(EAchievementType.TRUE_KING);
					}
				}
			}
			if (dieEvent.Killer.isMe && dieEvent.Sender.isMe)
			{
				if (dieEvent.WeaponCategory == EWeaponCategory.GrenadeLauncher && this._localCharacterService.IsJumping)
				{
					this.UnlockAchievement(EAchievementType.THIS_ISNT_QUAKE);
				}
				if (dieEvent.IsFall && this._lastFallDamageDistance >= 11.5f)
				{
					this.UnlockAchievement(EAchievementType.THIS_ISNT_PORTAL);
				}
				ulong gameMap = this._gameModeService.GameMap;
				if (dieEvent.DamageType == EDamageType.LAVA)
				{
					this.UnlockAchievement(EAchievementType.FLOOR_IS_LAVA);
				}
				if (gameMap == 5UL && dieEvent.DamageType == EDamageType.SMASHED)
				{
					this.UnlockAchievement(EAchievementType.HEAVY_MACHINERY);
				}
			}
			if (dieEvent.Sender.isMe)
			{
				this.ClearLifeTracking();
			}
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00016AC8 File Offset: 0x00014CC8
		private void OnVoteStart(VoteMapStartEvent evt)
		{
			int score = UserProfile.LocalGameClient.score;
			if (score >= 1500)
			{
				this.UnlockAchievement(EAchievementType.MVP);
			}
			this.ClearLifeTracking();
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x00016AFC File Offset: 0x00014CFC
		private void CheckForSwag()
		{
			IEnumerable<Accessory> availableAccessories = ServiceProvider.GetService<PlayerHeroSkinService>().GetAvailableAccessories(true);
			if (availableAccessories.Any<Accessory>())
			{
				this.UnlockAchievement(EAchievementType.SWAG);
			}
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00002AE4 File Offset: 0x00000CE4
		private void OnWeaponSkinUnlocked(SteamItem steamItem)
		{
			this.CheckForSwag();
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x00016B28 File Offset: 0x00014D28
		private void OnItemDrop(SteamItem droppedItem)
		{
			if (droppedItem != null)
			{
				IEnumerable<Lockbox> itemsOfType = ServiceProvider.GetService<GameItemService>().GetItemsOfType<Lockbox>();
				Lockbox lockbox = itemsOfType.FirstOrDefault((Lockbox x) => x.GetLockboxId() == droppedItem.IdentityId);
				if (lockbox != null)
				{
					this.UnlockAchievement(EAchievementType.NO_MICROTRANSACTIONS);
				}
			}
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x00016B78 File Offset: 0x00014D78
		internal override void Postprocess()
		{
			InGameHeaderController.OnChatMessageSent = (Action<string>)Delegate.Remove(InGameHeaderController.OnChatMessageSent, new Action<string>(this.OnChatMessageSent));
			this._networkGameService.OnClientListReceived.RemoveListener(new Action<ClientListReceivedEvent>(this.OnClientListReceived));
			this._networkGameService.OnVoteStart.RemoveListener(new Action<VoteMapStartEvent>(this.OnVoteStart));
			this._networkGameService.OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
			this._networkGameService.OnUserHit.RemoveListener(new Action<HitEvent>(this.OnUserHit));
			this._networkGameService.OnCapturedPoint.RemoveListener(new Action<CapturedPointEvent>(this.OnCapturedPoint));
		}

		// Token: 0x060000AA RID: 170 RVA: 0x00002AEC File Offset: 0x00000CEC
		internal void UnlockAchievement(EAchievementType achievementToUnlock)
		{
			if (this._achievementsToUnlock.Contains(achievementToUnlock))
			{
				return;
			}
			this._achievementsToUnlock.Add(achievementToUnlock);
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00016C34 File Offset: 0x00014E34
		internal void NotifyStatProgress(EGeneralStatistic stat, int value, int previosuValue)
		{
			EAchievementType eachievementType = this.StatisticToAchievement(stat);
			if (eachievementType == EAchievementType.NONE)
			{
				return;
			}
			int totalStatForAchievement = this.GetTotalStatForAchievement(eachievementType);
			int progressModForAchievement = this.GetProgressModForAchievement(eachievementType);
			if (value > 0 && value < totalStatForAchievement && value % progressModForAchievement == 0)
			{
				SteamUserStats.IndicateAchievementProgress(eachievementType.ToString(), (uint)value, (uint)totalStatForAchievement);
			}
			if (previosuValue < totalStatForAchievement && value >= totalStatForAchievement)
			{
				SteamUserStats.StoreStats();
			}
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00016CA0 File Offset: 0x00014EA0
		private EAchievementType StatisticToAchievement(EGeneralStatistic stat)
		{
			switch (stat)
			{
			case EGeneralStatistic.SAVIOR_KILLS:
				return EAchievementType.HERO;
			case EGeneralStatistic.KILL_ASSISTS:
				return EAchievementType.TEAMPLAY;
			case EGeneralStatistic.SHOTGUN_KILLS:
				return EAchievementType.SHOTGUN_MASTER;
			case EGeneralStatistic.SNIPER_KILLS:
				return EAchievementType.SNIPER_RIFLE_MASTER;
			case EGeneralStatistic.SMG_KILLS:
				return EAchievementType.SMG_MASTER;
			case EGeneralStatistic.ASSAULT_RIFLE_KILLS:
				return EAchievementType.ASSAULT_RIFLE_MASTER;
			case EGeneralStatistic.MACHINE_PISTOL_KILLS:
				return EAchievementType.MACHINE_PISTOL_MASTER;
			case EGeneralStatistic.PISTOL_KILLS:
				return EAchievementType.PISTOL_MASTER;
			case EGeneralStatistic.GRENADE_KILLS:
				return EAchievementType.GRENADE_MASTER;
			case EGeneralStatistic.MELEE_KILLS:
				return EAchievementType.MELEE_MASTER;
			case EGeneralStatistic.HEADSHOT_KILLS:
				return EAchievementType.HEADHUNTER;
			case EGeneralStatistic.LMG_KILLS:
				return EAchievementType.LMG_MASTER;
			case EGeneralStatistic.MATCHES_PLAYED:
				return EAchievementType.THE_STUFF_IVE_SEEN;
			default:
				return EAchievementType.NONE;
			}
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00016D10 File Offset: 0x00014F10
		internal int GetDebugMultiplierForStat(EGeneralStatistic stat)
		{
			switch (stat)
			{
			case EGeneralStatistic.SAVIOR_KILLS:
				return 10;
			case EGeneralStatistic.KILL_ASSISTS:
				return 10;
			case EGeneralStatistic.SHOTGUN_KILLS:
			case EGeneralStatistic.SNIPER_KILLS:
			case EGeneralStatistic.SMG_KILLS:
			case EGeneralStatistic.ASSAULT_RIFLE_KILLS:
			case EGeneralStatistic.MACHINE_PISTOL_KILLS:
			case EGeneralStatistic.PISTOL_KILLS:
				return 200;
			case EGeneralStatistic.GRENADE_KILLS:
			case EGeneralStatistic.MELEE_KILLS:
				return 40;
			case EGeneralStatistic.HEADSHOT_KILLS:
				return 200;
			case EGeneralStatistic.MATCHES_PLAYED:
				return 400;
			}
			return 1;
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00016D7C File Offset: 0x00014F7C
		private int GetProgressModForAchievement(EAchievementType stat)
		{
			switch (stat)
			{
			case EAchievementType.HERO:
			case EAchievementType.TEAMPLAY:
				return 5;
			case EAchievementType.SHOTGUN_MASTER:
			case EAchievementType.SNIPER_RIFLE_MASTER:
			case EAchievementType.SMG_MASTER:
			case EAchievementType.ASSAULT_RIFLE_MASTER:
			case EAchievementType.MACHINE_PISTOL_MASTER:
			case EAchievementType.PISTOL_MASTER:
				return 50;
			case EAchievementType.GRENADE_MASTER:
			case EAchievementType.MELEE_MASTER:
				return 20;
			case EAchievementType.HEADHUNTER:
				return 100;
			case EAchievementType.THE_STUFF_IVE_SEEN:
				return 100;
			}
			return 0;
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00016DDC File Offset: 0x00014FDC
		private int GetTotalStatForAchievement(EAchievementType stat)
		{
			switch (stat)
			{
			case EAchievementType.HERO:
				return 20;
			case EAchievementType.TEAMPLAY:
				return 30;
			case EAchievementType.SHOTGUN_MASTER:
			case EAchievementType.SNIPER_RIFLE_MASTER:
			case EAchievementType.SMG_MASTER:
			case EAchievementType.ASSAULT_RIFLE_MASTER:
			case EAchievementType.MACHINE_PISTOL_MASTER:
			case EAchievementType.PISTOL_MASTER:
				return 500;
			case EAchievementType.GRENADE_MASTER:
			case EAchievementType.MELEE_MASTER:
				return 100;
			case EAchievementType.HEADHUNTER:
				return 1000;
			case EAchievementType.THE_STUFF_IVE_SEEN:
				return 1000;
			}
			return 0;
		}

		// Token: 0x040002CD RID: 717
		private readonly string[] _crossWords = new string[] { "aquiris", "steam", "horizon" };

		// Token: 0x040002CE RID: 718
		private bool[] _hasWrittenCrossWord;

		// Token: 0x040002CF RID: 719
		private NetworkGameService _networkGameService;

		// Token: 0x040002D0 RID: 720
		private TransmissionService _transmissionService;

		// Token: 0x040002D1 RID: 721
		private GameModeService _gameModeService;

		// Token: 0x040002D2 RID: 722
		private LocalCharacterService _localCharacterService;

		// Token: 0x040002D3 RID: 723
		private StatisticsService _statisticsService;

		// Token: 0x040002D4 RID: 724
		private int _totalDamageInflictedThisLife;

		// Token: 0x040002D5 RID: 725
		private int _pointsCapturedThisLife;

		// Token: 0x040002D6 RID: 726
		private string _currentWeapon;

		// Token: 0x040002D7 RID: 727
		private int _enemiesKilledWithoutReloading;

		// Token: 0x040002D8 RID: 728
		private bool _playerIsInsideKingOfTheHillPoint;

		// Token: 0x040002D9 RID: 729
		private int _enemiesKilledWhileInsideKingOfTheHill;

		// Token: 0x040002DA RID: 730
		private float _lastFallDamageDistance;

		// Token: 0x040002DB RID: 731
		private bool _hasCheckedForSwag;

		// Token: 0x040002DC RID: 732
		private readonly Dictionary<int, int> _grenadeKills = new Dictionary<int, int>();

		// Token: 0x040002DD RID: 733
		private readonly List<double> _lastBackstabTimestamps = new List<double>();

		// Token: 0x040002DE RID: 734
		private readonly List<EAchievementType> _achievementsToUnlock = new List<EAchievementType>();
	}
}
