﻿using System;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x02000060 RID: 96
	public class KilledSomeoneWhileInsideAchievementTrigger : PlayerCollisionAchievementTrigger
	{
		// Token: 0x060000BA RID: 186 RVA: 0x00002BB7 File Offset: 0x00000DB7
		public override void OnEnable()
		{
			base.OnEnable();
			ServiceProvider.GetService<NetworkGameService>().OnDie.AddListener(new Action<DieEvent>(this.OnDie));
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00002BDA File Offset: 0x00000DDA
		private void OnDie(DieEvent dieEvent)
		{
			if (dieEvent.Killer.isMe && !dieEvent.Sender.isMe)
			{
				this._playerJustKilledSomeone = true;
			}
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00002C03 File Offset: 0x00000E03
		public override void OnDisable()
		{
			base.OnDisable();
			ServiceProvider.GetService<NetworkGameService>().OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060000BD RID: 189 RVA: 0x00016F38 File Offset: 0x00015138
		protected override bool UnlockRequirementsAreSatisfied
		{
			get
			{
				bool flag = base.UnlockRequirementsAreSatisfied && this._playerJustKilledSomeone;
				this._playerJustKilledSomeone = false;
				return flag;
			}
		}

		// Token: 0x0400030E RID: 782
		private bool _playerJustKilledSomeone;
	}
}
