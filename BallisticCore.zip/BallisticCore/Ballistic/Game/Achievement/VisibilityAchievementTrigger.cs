﻿using System;
using System.Collections;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Achievement
{
	// Token: 0x02000064 RID: 100
	[RequireComponent(typeof(BoxCollider))]
	public class VisibilityAchievementTrigger : SceneBasedAchievementTrigger
	{
		// Token: 0x060000CF RID: 207 RVA: 0x00017004 File Offset: 0x00015204
		private IEnumerator VisibilityCheckRoutine()
		{
			yield return new WaitForSeconds(Random.value * this.UpdatePeriod);
			for (;;)
			{
				yield return new WaitForSeconds(this.UpdatePeriod);
				bool foundVisible = false;
				bool allPointsOnScreen = true;
				float minX = float.PositiveInfinity;
				float maxX = 0f;
				float minY = float.PositiveInfinity;
				float maxY = 0f;
				if (this.VisibilityDetail.x < 0.01f)
				{
					this.VisibilityDetail.x = 1.01f;
				}
				if (this.VisibilityDetail.y < 0.01f)
				{
					this.VisibilityDetail.y = 1.01f;
				}
				if (this.VisibilityDetail.z < 0.01f)
				{
					this.VisibilityDetail.z = 1.01f;
				}
				this._camera = ServiceProvider.GetService<LocalCharacterService>().StageCamera ?? Camera.main;
				if (!(this._camera == null))
				{
					for (float num = 0f; num <= 1f; num += this.VisibilityDetail.x)
					{
						for (float num2 = 0f; num2 <= 1f; num2 += this.VisibilityDetail.y)
						{
							for (float num3 = 0f; num3 <= 1f; num3 += this.VisibilityDetail.z)
							{
								Vector3 vector;
								vector..ctor(num, num2, num3);
								vector -= 0.5f * Vector3.one;
								vector.Scale(this._collider.size);
								Vector3 vector2 = this._collider.center + vector;
								Vector3 vector3 = base.transform.TransformPoint(vector2);
								if (!foundVisible)
								{
									bool flag = CameraUtils.IsPointVisible(this._camera, vector3, World.ShootableLayersExceptIgnoreFlares);
									if (flag)
									{
										foundVisible = true;
									}
								}
								if (allPointsOnScreen)
								{
									Vector3 vector4 = CameraUtils.SafeWorldToScreenPoint(this._camera, vector3);
									vector4.x /= (float)this._camera.pixelWidth;
									vector4.y /= (float)this._camera.pixelHeight;
									if (vector4.x < 0f || vector4.x > 1f || vector4.y < 0f || vector4.y > 1f)
									{
										allPointsOnScreen = false;
									}
									minX = Mathf.Min(minX, vector4.x);
									maxX = Mathf.Max(maxX, vector4.x);
									minY = Mathf.Min(minY, vector4.y);
									maxY = Mathf.Max(maxY, vector4.y);
								}
							}
						}
					}
					this._isVisible = foundVisible;
					this._allPointsAreOnScreen = foundVisible && allPointsOnScreen;
					this._pointsRadiusOnScreen = Mathf.Max(maxX - minX, maxY - minY);
				}
			}
			yield break;
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00002D37 File Offset: 0x00000F37
		public override void OnEnable()
		{
			base.OnEnable();
			this._collider = base.GetComponent<BoxCollider>();
			base.StartCoroutine(this.VisibilityCheckRoutine());
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000D1 RID: 209 RVA: 0x00017020 File Offset: 0x00015220
		protected override bool UnlockRequirementsAreSatisfied
		{
			get
			{
				if (this._camera == null)
				{
					return false;
				}
				if (this._hasTriggeredAchievement)
				{
					return false;
				}
				bool flag = this._isVisible && this._visibleTime > this.RequiredTime;
				bool flag2 = true;
				if (this.AllPointsMustBeOnScreen)
				{
					flag2 &= this._allPointsAreOnScreen;
				}
				flag2 &= this._pointsRadiusOnScreen > this.MinimumRadiusOnScreen;
				bool flag3 = Vector3.Angle(-this._camera.transform.forward, base.transform.forward) < this.MaximumViewAngle;
				return flag && flag2 && flag3;
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00002D58 File Offset: 0x00000F58
		public virtual void Update()
		{
			if (this._isVisible)
			{
				this._visibleTime += Time.deltaTime;
			}
			else
			{
				this._visibleTime = 0f;
			}
		}

		// Token: 0x04000316 RID: 790
		public Vector3 VisibilityDetail;

		// Token: 0x04000317 RID: 791
		public float UpdatePeriod = 0.2f;

		// Token: 0x04000318 RID: 792
		public float RequiredTime;

		// Token: 0x04000319 RID: 793
		public bool AllPointsMustBeOnScreen = true;

		// Token: 0x0400031A RID: 794
		public float MinimumRadiusOnScreen = 0.1f;

		// Token: 0x0400031B RID: 795
		public float MaximumViewAngle = 180f;

		// Token: 0x0400031C RID: 796
		private BoxCollider _collider;

		// Token: 0x0400031D RID: 797
		private bool _isVisible;

		// Token: 0x0400031E RID: 798
		private float _visibleTime;

		// Token: 0x0400031F RID: 799
		private bool _allPointsAreOnScreen;

		// Token: 0x04000320 RID: 800
		private float _pointsRadiusOnScreen;

		// Token: 0x04000321 RID: 801
		private Camera _camera;
	}
}
