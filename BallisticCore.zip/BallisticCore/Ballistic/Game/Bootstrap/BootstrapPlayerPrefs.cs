﻿using System;

namespace Aquiris.Ballistic.Game.Bootstrap
{
	// Token: 0x02000067 RID: 103
	public class BootstrapPlayerPrefs
	{
		// Token: 0x04000331 RID: 817
		public string Version;
	}
}
