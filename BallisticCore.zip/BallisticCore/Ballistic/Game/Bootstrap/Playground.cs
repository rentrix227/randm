﻿using System;
using System.Collections.Generic;
using System.Text;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Configuration.Steam;
using Aquiris.Ballistic.Network.Connection;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Bootstrap
{
	// Token: 0x02000068 RID: 104
	public class Playground : MonoBehaviour
	{
		// Token: 0x060000E6 RID: 230 RVA: 0x0001776C File Offset: 0x0001596C
		private void DefineOfflineWeapons()
		{
			this.offline_weapons = new List<GameObject>();
			if (this.extraWeapons)
			{
				this.offline_weapons.AddRange(this.ExtraWeapons);
			}
			if (this.extraWeapons2)
			{
				this.offline_weapons.AddRange(this.ExtraWeapons2);
			}
			if (this.berserker)
			{
				this.offline_weapons.AddRange(this.Berserker);
			}
			if (this.vanguard)
			{
				this.offline_weapons.AddRange(this.Vanguard);
			}
			if (this.wraith)
			{
				this.offline_weapons.AddRange(this.Wraith);
			}
			if (this.shadow)
			{
				this.offline_weapons.AddRange(this.Shadow);
			}
			if (this.grenadier)
			{
				this.offline_weapons.AddRange(this.Grenadier);
			}
			if (this.tank)
			{
				this.offline_weapons.AddRange(this.Tank);
			}
			if (this.marksman)
			{
				this.offline_weapons.AddRange(this.Marksman);
			}
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x00017880 File Offset: 0x00015A80
		public void Awake()
		{
			if (this._steamApiInitialized)
			{
				Debug.LogError("SteamAPI was initialized!. This is almost always an error. The most common case where this happens is the SteamManager getting desstroyed via Application.Quit() and having some code in some OnDestroy which gets called afterwards, creating a new SteamManager.");
				return;
			}
			if (!Packsize.Test())
			{
				Debug.LogError("[Steamworks.NET] Packsize Test returned false, the wrong version of Steamworks.NET is being run in this platform.", this);
			}
			if (!DllCheck.Test())
			{
				Debug.LogError("[Steamworks.NET] DllCheck Test returned false, One or more of the Steamworks binaries seems to be the wrong version.", this);
			}
			try
			{
				if (SteamAPI.RestartAppIfNecessary(new AppId_t(296300U)))
				{
					Debug.LogError("[Steamworks.NET] Application was reinitialized!", this);
					Application.Quit();
					return;
				}
			}
			catch (DllNotFoundException ex)
			{
				Debug.LogError("[Steamworks.NET] Could not load [lib]steam_api.dll/so/dylib. It's likely not in the correct location. Refer to the README for more details.\n" + ex, this);
				Application.Quit();
				return;
			}
			this._steamApiInitialized = SteamAPI.Init();
			if (!this._steamApiInitialized)
			{
				Debug.LogError("[Steamworks.NET] SteamAPI_Init() failed. Refer to Valve's documentation or the comment above this line for more information.", this);
				return;
			}
			Debug.Log("Steam API Initialized!");
			this.DefineOfflineWeapons();
			OfflineInformation.OfflineUi = false;
			OfflineInformation.OfflineMode = true;
			OfflineInformation.IncludeWeaponsSkins = this.WeaponSkins;
			OfflineInformation.OfflineWeapons = this.offline_weapons.ToArray();
			OfflineInformation.OfflineGrenade = this.Grenades;
			OfflineInformation.OfflineMelee = this.Melees;
			OfflineInformation.OfflineModeArmsModel = this.ArmsModel;
			OfflineInformation.OfflineLevelStuffToInstantiate = this.StuffToInstantiate;
			Object.DontDestroyOnLoad(base.gameObject);
			ServiceProvider.GetService<GameSettingsService>().Load();
			ServiceProvider.GetService<OptionControlService>().Load();
			ServiceProvider.GetService<NetworkGameService>().OnLobbyReady.AddListener(new Action(this.OnLobbyReady));
			ServiceProvider.GetService<NetworkGameService>().CreateLobby(new SteamConfig
			{
				ServerName = "Playground Server",
				GameMap = this.Map,
				GameMode = this.Mode,
				MaxPlayers = 16U,
				MaxSpectators = 2U,
				MaxPing = 0,
				MatchTime = 600U,
				TeamDeathMatch = 7U,
				RoundTime = 90U,
				WarmUpTime = 34f,
				DedicatedServer = false,
				DedicatedOnDemand = false,
				OfficialServer = false,
				SteamPort = 8766,
				GamePort = 27015,
				QueryPort = 27016,
				BannerUrl = string.Empty,
				ClickUrl = string.Empty
			});
			Application.runInBackground = true;
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x00002E23 File Offset: 0x00001023
		private static void SteamApiDebugTextHook(int nSeverity, StringBuilder pchDebugText)
		{
			Debug.LogWarning(pchDebugText);
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x00017AA8 File Offset: 0x00015CA8
		public void OnEnable()
		{
			if (!this._steamApiInitialized)
			{
				return;
			}
			if (this._steamApiWarningMessageHook != null)
			{
				return;
			}
			this._steamApiWarningMessageHook = new SteamAPIWarningMessageHook_t(Playground.SteamApiDebugTextHook);
			SteamClient.SetWarningMessageHook(this._steamApiWarningMessageHook);
		}

		// Token: 0x060000EA RID: 234 RVA: 0x00002E2B File Offset: 0x0000102B
		private void OnLobbyReady()
		{
			ServiceProvider.GetService<NetworkGameService>().OnLobbyReady.RemoveListener(new Action(this.OnLobbyReady));
			this.StartHost();
		}

		// Token: 0x060000EB RID: 235 RVA: 0x00017AFC File Offset: 0x00015CFC
		private void StartHost()
		{
			ServiceProvider.GetService<NetworkGameService>().OnHostRunning.AddListener(new Action(this.OnHostRunning));
			ServiceProvider.GetService<NetworkGameService>().OnHostInitError.AddListener(new Action(this.OnHostInitError));
			ServiceProvider.GetService<NetworkGameService>().OnClientConnectionEstablished.AddListener(new Action(this.OnClientConnectionEstablished));
			ServiceProvider.GetService<NetworkGameService>().OnClientConnectionFail.AddListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
			ServiceProvider.GetService<NetworkGameService>().CreateServer(ServiceProvider.GetService<NetworkGameService>().GetLobbyConfig());
		}

		// Token: 0x060000EC RID: 236 RVA: 0x00017B8C File Offset: 0x00015D8C
		private void OnHostRunning()
		{
			Debug.Log("Host created!");
			ServiceProvider.GetService<NetworkGameService>().OnHostRunning.RemoveListener(new Action(this.OnHostRunning));
			ServiceProvider.GetService<NetworkGameService>().OnHostInitError.RemoveListener(new Action(this.OnHostInitError));
			ServiceProvider.GetService<NetworkGameService>().StartServer(ServiceProvider.GetService<GameMapModeConfigService>().FindGameMapConfig(this.Map), this.Mode);
		}

		// Token: 0x060000ED RID: 237 RVA: 0x00017BFC File Offset: 0x00015DFC
		private void OnHostInitError()
		{
			Debug.Log("Error starting host!");
			ServiceProvider.GetService<NetworkGameService>().OnHostRunning.RemoveListener(new Action(this.OnHostRunning));
			ServiceProvider.GetService<NetworkGameService>().OnHostInitError.RemoveListener(new Action(this.OnHostInitError));
		}

		// Token: 0x060000EE RID: 238 RVA: 0x00002E4E File Offset: 0x0000104E
		private void OnClientConnectionEstablished()
		{
			ServiceProvider.GetService<NetworkGameService>().OnClientConnectionEstablished.RemoveListener(new Action(this.OnClientConnectionEstablished));
			ServiceProvider.GetService<NetworkGameService>().OnClientConnectionFail.RemoveListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
		}

		// Token: 0x060000EF RID: 239 RVA: 0x00002E4E File Offset: 0x0000104E
		private void OnClientConnectionFail(LeaveGameMotivation motivation)
		{
			ServiceProvider.GetService<NetworkGameService>().OnClientConnectionEstablished.RemoveListener(new Action(this.OnClientConnectionEstablished));
			ServiceProvider.GetService<NetworkGameService>().OnClientConnectionFail.RemoveListener(new Action<LeaveGameMotivation>(this.OnClientConnectionFail));
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x00002E86 File Offset: 0x00001086
		public void OnDestroy()
		{
			if (!this._steamApiInitialized)
			{
				return;
			}
			SteamAPI.Shutdown();
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x00002E99 File Offset: 0x00001099
		public void Update()
		{
			if (!this._steamApiInitialized)
			{
				return;
			}
			SteamAPI.RunCallbacks();
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x00002EAC File Offset: 0x000010AC
		public void OnApplicationQuit()
		{
			ServiceProvider.ShutdownServices();
		}

		// Token: 0x04000332 RID: 818
		public ulong Map = 1UL;

		// Token: 0x04000333 RID: 819
		public EGameMode Mode = EGameMode.TeamDeathMatch;

		// Token: 0x04000334 RID: 820
		public bool WeaponSkins;

		// Token: 0x04000335 RID: 821
		private List<GameObject> offline_weapons;

		// Token: 0x04000336 RID: 822
		public bool extraWeapons = true;

		// Token: 0x04000337 RID: 823
		public bool extraWeapons2 = true;

		// Token: 0x04000338 RID: 824
		public bool berserker;

		// Token: 0x04000339 RID: 825
		public bool vanguard;

		// Token: 0x0400033A RID: 826
		public bool wraith;

		// Token: 0x0400033B RID: 827
		public bool shadow;

		// Token: 0x0400033C RID: 828
		public bool grenadier;

		// Token: 0x0400033D RID: 829
		public bool tank;

		// Token: 0x0400033E RID: 830
		public bool marksman;

		// Token: 0x0400033F RID: 831
		public GameObject[] ExtraWeapons;

		// Token: 0x04000340 RID: 832
		public GameObject[] ExtraWeapons2;

		// Token: 0x04000341 RID: 833
		public GameObject[] Berserker;

		// Token: 0x04000342 RID: 834
		public GameObject[] Vanguard;

		// Token: 0x04000343 RID: 835
		public GameObject[] Wraith;

		// Token: 0x04000344 RID: 836
		public GameObject[] Shadow;

		// Token: 0x04000345 RID: 837
		public GameObject[] Grenadier;

		// Token: 0x04000346 RID: 838
		public GameObject[] Tank;

		// Token: 0x04000347 RID: 839
		public GameObject[] Marksman;

		// Token: 0x04000348 RID: 840
		public GameObject[] Grenades;

		// Token: 0x04000349 RID: 841
		public GameObject[] Melees;

		// Token: 0x0400034A RID: 842
		public GameObject ArmsModel;

		// Token: 0x0400034B RID: 843
		public GameObject[] StuffToInstantiate;

		// Token: 0x0400034C RID: 844
		private bool _steamApiInitialized;

		// Token: 0x0400034D RID: 845
		private SteamAPIWarningMessageHook_t _steamApiWarningMessageHook;
	}
}
