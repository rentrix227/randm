﻿using System;
using System.IO;
using System.Text;
using Aquiris.Ballistic.Game.Achievement;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.ServerBrowser;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.PlayerItemModel;
using Aquiris.UI.Base;
using Steamworks;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Bootstrap
{
	// Token: 0x02000066 RID: 102
	public class Bootstrap : MonoBehaviour
	{
		// Token: 0x17000012 RID: 18
		// (get) Token: 0x060000DA RID: 218 RVA: 0x00002DB5 File Offset: 0x00000FB5
		// (set) Token: 0x060000DB RID: 219 RVA: 0x00002DBC File Offset: 0x00000FBC
		public static Bootstrap Instance { get; private set; }

		// Token: 0x060000DC RID: 220 RVA: 0x000174E4 File Offset: 0x000156E4
		public void Awake()
		{
			Bootstrap.Instance = this;
			if (this.SteamApiInitialized)
			{
				Debug.LogError("SteamAPI was initialized!. This is almost always an error. The most common case where this happens is the SteamManager getting desstroyed via Application.Quit() and having some code in some OnDestroy which gets called afterwards, creating a new SteamManager.");
				return;
			}
			if (!Packsize.Test())
			{
				Debug.LogError("[Steamworks.NET] Packsize Test returned false, the wrong version of Steamworks.NET is being run in this platform.", this);
			}
			if (!DllCheck.Test())
			{
				Debug.LogError("[Steamworks.NET] DllCheck Test returned false, One or more of the Steamworks binaries seems to be the wrong version.", this);
			}
			this.SteamApiInitialized = SteamAPI.Init();
			if (!this.SteamApiInitialized)
			{
				Debug.LogError("[Steamworks.NET] SteamAPI_Init() failed. Refer to Valve's documentation or the comment above this line for more information.", this);
				return;
			}
			Debug.Log("Steam API Initialized!");
			OfflineInformation.OfflineUi = false;
			OfflineInformation.OfflineMode = false;
			Application.runInBackground = true;
			Object.DontDestroyOnLoad(base.gameObject);
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00017574 File Offset: 0x00015774
		public void Start()
		{
			if (!this.SteamApiInitialized)
			{
				return;
			}
			ServiceProvider.GetService<GameSettingsService>().Load();
			ServiceProvider.GetService<GameSettingsService>().Save();
			ServiceProvider.GetService<GameSettingsService>().RebuildVideo();
			ServiceProvider.GetService<GameSettingsService>().RebuildQuality();
			ServiceProvider.GetService<GameSettingsService>().RebuildAudio();
			ServiceProvider.GetService<OptionControlService>().Load();
			ServiceProvider.GetService<OptionControlService>().Save();
			ServiceProvider.GetService<TelemetryService>();
			ServiceProvider.GetService<AchievementService>();
			ServiceProvider.GetService<StatisticsService>().RequestCurrentStats(new Action<StatisticsGeneralData>(this.OnRequestUserDataSucess));
		}

		// Token: 0x060000DE RID: 222 RVA: 0x000175F8 File Offset: 0x000157F8
		private void OnRequestUserDataSucess(StatisticsGeneralData evt)
		{
			Debug.Log("Stats Completed!");
			ServiceProvider.GetService<PlayerItemStorageService>();
			ServiceProvider.GetService<SoldiersService>().LoadPlayerLoadouts(0);
			try
			{
				string client_VERSION = BallisticVersion.CLIENT_VERSION;
				BootstrapPlayerPrefs bootstrapPlayerPrefs = new BootstrapPlayerPrefs();
				if (File.Exists("BallisticConfiguration.version"))
				{
					bootstrapPlayerPrefs = ConversionUtil.ReadUnityJson<BootstrapPlayerPrefs>(File.ReadAllText("BallisticConfiguration.version", Encoding.UTF8));
					if (bootstrapPlayerPrefs.Version != client_VERSION)
					{
						this.Reset();
					}
				}
				else
				{
					this.Reset();
				}
				bootstrapPlayerPrefs.Version = client_VERSION;
				File.WriteAllText("BallisticConfiguration.version", ConversionUtil.WriteUnityJson(bootstrapPlayerPrefs), Encoding.UTF8);
			}
			catch (Exception ex)
			{
				Debug.LogError("Error loading version file:" + ex.Message);
			}
			ServiceProvider.GetService<InventoryService>();
			ServiceProvider.GetService<LeaderboardService>();
			Debug.Log("All load completed!");
			ServiceProvider.GetService<SceneService>().LoadSceneEntry();
		}

		// Token: 0x060000DF RID: 223 RVA: 0x00002A31 File Offset: 0x00000C31
		private void Reset()
		{
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x00002DC4 File Offset: 0x00000FC4
		private void OnRequestUserDataDebug(StatisticsGeneralData evt)
		{
			ServiceProvider.GetService<StatisticsService>().Log();
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x000176D0 File Offset: 0x000158D0
		public void Update()
		{
			if (!this.SteamApiInitialized)
			{
				return;
			}
			SteamAPI.RunCallbacks();
			if (Input.GetKey(306) && Input.GetKey(304) && Input.GetKey(303) && Input.GetKeyDown(61) && UIManager.Instance.FindController<ServerBrowserController>() != null)
			{
				UIManager.Instance.FindController<ServerBrowserController>().SetOfficials(EServerFilterMode.ALL);
			}
			if (Input.GetKeyDown(283))
			{
				ServiceProvider.GetService<StatisticsService>().RequestCurrentStats(new Action<StatisticsGeneralData>(this.OnRequestUserDataDebug));
			}
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x00002DD0 File Offset: 0x00000FD0
		public void OnApplicationQuit()
		{
			ServiceProvider.GetService<TelemetryService>().ProcessGameQuit();
			ServiceProvider.ShutdownServices();
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x00002DE1 File Offset: 0x00000FE1
		public void OnDestroy()
		{
			if (!this.SteamApiInitialized)
			{
				return;
			}
			Debug.Log("SteamAPI Shutdown!");
			SteamAPI.Shutdown();
		}

		// Token: 0x0400032C RID: 812
		private const string _fileName = "BallisticConfiguration.version";

		// Token: 0x0400032D RID: 813
		public bool DisablePlayerKicking = true;

		// Token: 0x0400032F RID: 815
		public bool SteamApiInitialized;

		// Token: 0x04000330 RID: 816
		public bool CheatEnabled;
	}
}
