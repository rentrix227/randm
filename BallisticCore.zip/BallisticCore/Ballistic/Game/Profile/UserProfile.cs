﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Steamworks;

namespace Aquiris.Ballistic.Game.Profile
{
	// Token: 0x02000323 RID: 803
	public class UserProfile
	{
		// Token: 0x060010F8 RID: 4344 RVA: 0x00061AE8 File Offset: 0x0005FCE8
		internal static bool IsMe(long userId)
		{
			return userId == (long)SteamUser.GetSteamID().m_SteamID;
		}

		// Token: 0x060010F9 RID: 4345 RVA: 0x00061AE8 File Offset: 0x0005FCE8
		internal static bool IsMe(ulong userId)
		{
			return userId == SteamUser.GetSteamID().m_SteamID;
		}

		// Token: 0x060010FA RID: 4346 RVA: 0x00061B08 File Offset: 0x0005FD08
		internal static ulong MyId()
		{
			return SteamUser.GetSteamID().m_SteamID;
		}

		// Token: 0x04001632 RID: 5682
		public static GameClient LocalGameClient;
	}
}
