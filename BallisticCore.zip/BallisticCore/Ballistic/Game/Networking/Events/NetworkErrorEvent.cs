﻿using System;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000EB RID: 235
	public class NetworkErrorEvent
	{
		// Token: 0x040006E2 RID: 1762
		public string Message;
	}
}
