﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000E9 RID: 233
	public class DieEvent
	{
		// Token: 0x060003FE RID: 1022 RVA: 0x000024A7 File Offset: 0x000006A7
		public DieEvent()
		{
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x00020C00 File Offset: 0x0001EE00
		public DieEvent(PlayerDieEvent evt)
		{
			this.Sender = ServiceProvider.GetService<NetworkGameService>().GetClient(evt.User);
			this.SenderId = evt.User;
			this.Killer = ServiceProvider.GetService<NetworkGameService>().GetClient(evt.KillerId);
			this.KillerId = evt.KillerId;
			this.WeaponId = evt.WeaponId;
			this.ChangingTeam = evt.ChagingTeam;
			this.BodyPart = evt.BodyPart;
			this.DamageType = evt.DamageType;
			this.IsBackstab = evt.DamageType == EDamageType.BACKSTAB;
			this.IsFall = evt.DamageType == EDamageType.FALL;
			this.Team = (Team)evt.Team;
			this.FinalScore = evt.KillerScoreChange;
			if (evt.ShooterPosition != null && evt.ShooterPosition.Count >= 3)
			{
				this.ShooterPosition = new Vector3((float)evt.ShooterPosition[0], (float)evt.ShooterPosition[1], (float)evt.ShooterPosition[2]);
			}
			if (evt.VictimPosition != null && evt.VictimPosition.Count >= 3)
			{
				this.VictimPosition = new Vector3((float)evt.VictimPosition[0], (float)evt.VictimPosition[1], (float)evt.VictimPosition[2]);
			}
			this.GetKillType((ushort)evt.KillType);
			this._effect = (int)evt.HitEffect;
			this.GetAdditionalAssists(evt.AdditionalPlayerIds, evt.AdditionalPlayerScore, evt.AdditionalPlayerInteractionType);
			this.KillerKillStreak = (int)evt.KillerKillStreak;
			this.KillerMultiKill = (int)evt.KillerMultiKill;
			this.GrenadeId = evt.GrenadeId;
			if (this.WeaponId <= 0)
			{
				return;
			}
			WeaponV4 itemById = ServiceProvider.GetService<GameItemService>().GetItemById<WeaponV4>(this.WeaponId);
			if (itemById == null)
			{
				return;
			}
			this.WeaponModel = itemById.ItemModel;
			this.WeaponCategory = itemById.Category;
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000400 RID: 1024 RVA: 0x000050E0 File Offset: 0x000032E0
		// (set) Token: 0x06000401 RID: 1025 RVA: 0x000050E8 File Offset: 0x000032E8
		public bool ComputeKill { get; private set; }

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000402 RID: 1026 RVA: 0x000050F1 File Offset: 0x000032F1
		// (set) Token: 0x06000403 RID: 1027 RVA: 0x000050F9 File Offset: 0x000032F9
		public HeadshotType Headshot { get; private set; }

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000404 RID: 1028 RVA: 0x00005102 File Offset: 0x00003302
		public bool IsHeadshot
		{
			get
			{
				return this.WeaponCategory != EWeaponCategory.Melee && (this.Headshot == HeadshotType.HEADSHOT || this.Headshot == HeadshotType.MARKSMAN_HEADSHOT);
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000405 RID: 1029 RVA: 0x0000512B File Offset: 0x0000332B
		// (set) Token: 0x06000406 RID: 1030 RVA: 0x00005133 File Offset: 0x00003333
		public bool IsBackstab { get; private set; }

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x06000407 RID: 1031 RVA: 0x0000513C File Offset: 0x0000333C
		// (set) Token: 0x06000408 RID: 1032 RVA: 0x00005144 File Offset: 0x00003344
		public bool IsFall { get; private set; }

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000409 RID: 1033 RVA: 0x0000514D File Offset: 0x0000334D
		// (set) Token: 0x0600040A RID: 1034 RVA: 0x00005155 File Offset: 0x00003355
		public Team Team { get; private set; }

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x0600040B RID: 1035 RVA: 0x0000515E File Offset: 0x0000335E
		// (set) Token: 0x0600040C RID: 1036 RVA: 0x00005166 File Offset: 0x00003366
		public short FinalScore { get; private set; }

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x0600040D RID: 1037 RVA: 0x0000516F File Offset: 0x0000336F
		// (set) Token: 0x0600040E RID: 1038 RVA: 0x00005177 File Offset: 0x00003377
		public bool AvengerKill { get; private set; }

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x0600040F RID: 1039 RVA: 0x00005180 File Offset: 0x00003380
		// (set) Token: 0x06000410 RID: 1040 RVA: 0x00005188 File Offset: 0x00003388
		public bool SaviorKill { get; private set; }

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000411 RID: 1041 RVA: 0x00005191 File Offset: 0x00003391
		// (set) Token: 0x06000412 RID: 1042 RVA: 0x00005199 File Offset: 0x00003399
		public bool DefenseKill { get; private set; }

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000413 RID: 1043 RVA: 0x000051A2 File Offset: 0x000033A2
		// (set) Token: 0x06000414 RID: 1044 RVA: 0x000051AA File Offset: 0x000033AA
		public bool OffensiveKill { get; private set; }

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000415 RID: 1045 RVA: 0x000051B3 File Offset: 0x000033B3
		// (set) Token: 0x06000416 RID: 1046 RVA: 0x000051BB File Offset: 0x000033BB
		public bool ChangingTeam { get; set; }

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06000417 RID: 1047 RVA: 0x000051C4 File Offset: 0x000033C4
		// (set) Token: 0x06000418 RID: 1048 RVA: 0x000051CC File Offset: 0x000033CC
		public int KillerKillStreak { get; private set; }

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06000419 RID: 1049 RVA: 0x000051D5 File Offset: 0x000033D5
		// (set) Token: 0x0600041A RID: 1050 RVA: 0x000051DD File Offset: 0x000033DD
		public int KillerMultiKill { get; private set; }

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600041B RID: 1051 RVA: 0x000051E6 File Offset: 0x000033E6
		// (set) Token: 0x0600041C RID: 1052 RVA: 0x000051EE File Offset: 0x000033EE
		public bool JuggernautKill { get; private set; }

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x0600041D RID: 1053 RVA: 0x000051F7 File Offset: 0x000033F7
		// (set) Token: 0x0600041E RID: 1054 RVA: 0x000051FF File Offset: 0x000033FF
		public bool KillOfJuggernaut { get; private set; }

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x0600041F RID: 1055 RVA: 0x00005208 File Offset: 0x00003408
		// (set) Token: 0x06000420 RID: 1056 RVA: 0x00005210 File Offset: 0x00003410
		public int BodyPart { get; private set; }

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000421 RID: 1057 RVA: 0x00005219 File Offset: 0x00003419
		// (set) Token: 0x06000422 RID: 1058 RVA: 0x00005221 File Offset: 0x00003421
		public int GrenadeId { get; private set; }

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000423 RID: 1059 RVA: 0x0000522A File Offset: 0x0000342A
		public List<AdditionalScorer> AdditionalPlayers
		{
			get
			{
				if (this._additionalPlayers == null || this._additionalPlayers.Count <= 0)
				{
					return null;
				}
				return this._additionalPlayers;
			}
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x00005250 File Offset: 0x00003450
		public bool IsEffectActing(HitEffect effect)
		{
			return (effect & (HitEffect)this._effect) != HitEffect.None;
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00020DF0 File Offset: 0x0001EFF0
		protected void GetKillType(ushort data)
		{
			this.ComputeKill = (data & 1) != 0;
			bool flag = (data & 2) != 0;
			bool flag2 = (data & 4) != 0;
			this.Headshot = ((!flag2) ? ((!flag) ? HeadshotType.NONE : HeadshotType.HEADSHOT) : HeadshotType.MARKSMAN_HEADSHOT);
			this.AvengerKill = (data & 8) != 0;
			this.SaviorKill = (data & 16) != 0;
			this.DefenseKill = (data & 32) != 0;
			this.OffensiveKill = (data & 64) != 0;
			this.KillOfJuggernaut = (data & 128) != 0;
			this.JuggernautKill = (data & 256) != 0;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x00020EA4 File Offset: 0x0001F0A4
		protected void GetAdditionalAssists(List<long> ids, List<short> scores, List<sbyte> assistType)
		{
			if (ids == null || scores == null || assistType == null)
			{
				return;
			}
			int count = ids.Count;
			int count2 = scores.Count;
			int count3 = assistType.Count;
			if (count != count3 && count != count2 && count2 != count3)
			{
				return;
			}
			this._additionalPlayers = new List<AdditionalScorer>();
			for (int i = 0; i < count; i++)
			{
				this._additionalPlayers.Add(new AdditionalScorer(ids[i], (int)scores[i], (int)assistType[i]));
			}
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x00005260 File Offset: 0x00003460
		public bool IsValid()
		{
			return this.Killer != null;
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x00020F34 File Offset: 0x0001F134
		public override string ToString()
		{
			return string.Format("[DieEvent: killerId={0}, computeKill={1}, headshot={2}, isHeadshot={3}, defenseKill={4}, avengerKill={5}, saviorKill={6}, changingTeam={7}, killerKillStreak={8}, killerMultiKill={9}, WillShooterRecoverFromLastStand={10}, BodyPart={11}, AdditionalPlayers={12}, Base={13}]", new object[]
			{
				this.KillerId,
				this.ComputeKill,
				this.Headshot,
				this.IsHeadshot,
				this.DefenseKill,
				this.AvengerKill,
				this.SaviorKill,
				this.ChangingTeam,
				this.KillerKillStreak,
				this.KillerMultiKill,
				false,
				this.BodyPart,
				this.AdditionalPlayers,
				base.ToString()
			});
		}

		// Token: 0x040006C2 RID: 1730
		public long SenderId;

		// Token: 0x040006C3 RID: 1731
		public long KillerId;

		// Token: 0x040006C4 RID: 1732
		public GameClient Sender;

		// Token: 0x040006C5 RID: 1733
		public GameClient Killer;

		// Token: 0x040006C6 RID: 1734
		public Vector3 ShooterPosition;

		// Token: 0x040006C7 RID: 1735
		public Vector3 VictimPosition;

		// Token: 0x040006C8 RID: 1736
		public EWeaponCategory WeaponCategory;

		// Token: 0x040006C9 RID: 1737
		public int WeaponId;

		// Token: 0x040006CA RID: 1738
		public string WeaponModel;

		// Token: 0x040006CB RID: 1739
		public EDamageType DamageType;

		// Token: 0x040006DD RID: 1757
		private readonly int _effect;

		// Token: 0x040006DE RID: 1758
		private List<AdditionalScorer> _additionalPlayers;
	}
}
