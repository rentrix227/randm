﻿using System;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Services;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000E8 RID: 232
	public class AdditionalScorer
	{
		// Token: 0x060003EF RID: 1007 RVA: 0x00020B48 File Offset: 0x0001ED48
		public AdditionalScorer(long gameClientId, int gameClientScore, int assistType)
		{
			this.SenderId = gameClientId;
			this.Sender = ServiceProvider.GetService<NetworkGameService>().GetClient(this.SenderId);
			this.Score = gameClientScore;
			this.IsAssist = assistType == 0;
			this.IsCriticalAssist = assistType == 1;
			this.IsJuggernautAssist = assistType == 2;
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060003F0 RID: 1008 RVA: 0x0000506C File Offset: 0x0000326C
		// (set) Token: 0x060003F1 RID: 1009 RVA: 0x00005074 File Offset: 0x00003274
		public GameClient Sender { get; private set; }

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060003F2 RID: 1010 RVA: 0x0000507D File Offset: 0x0000327D
		// (set) Token: 0x060003F3 RID: 1011 RVA: 0x00005085 File Offset: 0x00003285
		public long SenderId { get; private set; }

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x0000508E File Offset: 0x0000328E
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x00005096 File Offset: 0x00003296
		public int Score { get; private set; }

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x060003F6 RID: 1014 RVA: 0x0000509F File Offset: 0x0000329F
		// (set) Token: 0x060003F7 RID: 1015 RVA: 0x000050A7 File Offset: 0x000032A7
		public bool IsAssist { get; private set; }

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x060003F8 RID: 1016 RVA: 0x000050B0 File Offset: 0x000032B0
		// (set) Token: 0x060003F9 RID: 1017 RVA: 0x000050B8 File Offset: 0x000032B8
		public bool IsCriticalAssist { get; private set; }

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x060003FA RID: 1018 RVA: 0x000050C1 File Offset: 0x000032C1
		// (set) Token: 0x060003FB RID: 1019 RVA: 0x000050C9 File Offset: 0x000032C9
		public bool IsJuggernautAssist { get; private set; }

		// Token: 0x060003FC RID: 1020 RVA: 0x000050D2 File Offset: 0x000032D2
		public bool IsValid()
		{
			return this.Sender != null;
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x00020BA0 File Offset: 0x0001EDA0
		public override string ToString()
		{
			return string.Format("[AdditionalScorer: Sender={0}, SenderId={1}, Score={2}, isAssist={3}, IsCriticalAssist={4}]", new object[] { this.Sender, this.SenderId, this.Score, this.IsAssist, this.IsCriticalAssist });
		}
	}
}
