﻿using System;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000E7 RID: 231
	public enum HeadshotType
	{
		// Token: 0x040006B9 RID: 1721
		NONE,
		// Token: 0x040006BA RID: 1722
		HEADSHOT,
		// Token: 0x040006BB RID: 1723
		MARKSMAN_HEADSHOT
	}
}
