﻿using System;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000EA RID: 234
	public class MapLoadEvent
	{
		// Token: 0x06000429 RID: 1065 RVA: 0x0002100C File Offset: 0x0001F20C
		public MapLoadEvent(GameModeMetaData p_gameModeMetaData)
		{
			if (p_gameModeMetaData != null)
			{
				this.GameMode = p_gameModeMetaData.GameConfig.GameMode;
				this.GameMapId = (ulong)p_gameModeMetaData.GameConfig.GameMap;
				this.Beta = p_gameModeMetaData.GameConfig.Beta;
			}
		}

		// Token: 0x040006DF RID: 1759
		public EGameMode GameMode;

		// Token: 0x040006E0 RID: 1760
		public ulong GameMapId;

		// Token: 0x040006E1 RID: 1761
		public bool Beta;
	}
}
