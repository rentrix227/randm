﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.GameItemModel.GameWeaponModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000E4 RID: 228
	public class HitEvent
	{
		// Token: 0x060003E1 RID: 993 RVA: 0x000208C4 File Offset: 0x0001EAC4
		public HitEvent(PlayerHitEvent hit)
		{
			this.SenderId = hit.User;
			this.Sender = ServiceProvider.GetService<NetworkGameService>().GetClient(hit.User);
			this.VictimGameClientId = hit.UserBeingHitId;
			this.VictimGameClient = ServiceProvider.GetService<NetworkGameService>().GetClient(this.VictimGameClientId);
			this.BodyPartHit = hit.BodyPartHit;
			this.Damage = (float)hit.Damage;
			this.DamageType = hit.DamageType;
			List<double> list = hit.ShooterPosition;
			if (list != null && list.Count >= 3)
			{
				this.ShooterPosition = new Vector3((float)list[0], (float)list[1], (float)list[2]);
			}
			list = hit.VictimPosition;
			if (list != null && list.Count >= 3)
			{
				this.VictimPosition = new Vector3((float)list[0], (float)list[1], (float)list[2]);
			}
			this.WeaponId = hit.WeaponId;
			if (this.WeaponId > 0)
			{
				WeaponData weapon = ServiceProvider.GetService<WeaponService>().GetWeapon(this.WeaponId);
				if (weapon != null)
				{
					this.WeaponModel = weapon.GameItem.ItemModel;
					this.WeaponCategory = weapon.GameItem.WeaponData.WeaponCategory;
				}
				else
				{
					this.WeaponModel = null;
					this.WeaponCategory = EWeaponCategory.None;
				}
			}
			this._effect = (int)hit.HitEffect;
			this.VictimRemainingLife = (float)hit.VictimRemaingLife;
			this.PetHit = 0;
			this.IsSecondFunction = false;
			this.DeltaLife = (float)hit.DeltaLife;
			if (hit.SecondWindRecoveryTime > 0.0 && hit.SecondWindRecoveryLife > 0.0)
			{
				this.VictimSecondWindRecoverDuration = (float)hit.SecondWindRecoveryTime;
				this.VictimSecondWindRecoverLife = (float)hit.SecondWindRecoveryLife;
			}
			else
			{
				this.VictimSecondWindRecoverDuration = -1f;
				this.VictimSecondWindRecoverLife = -1f;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060003E2 RID: 994 RVA: 0x00004FE2 File Offset: 0x000031E2
		// (set) Token: 0x060003E3 RID: 995 RVA: 0x00004FEA File Offset: 0x000031EA
		public float DeltaLife { get; private set; }

		// Token: 0x060003E4 RID: 996 RVA: 0x00004FF3 File Offset: 0x000031F3
		public bool IsEffectActing(HitEffect effect)
		{
			return (effect & (HitEffect)this._effect) != HitEffect.None;
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x00005003 File Offset: 0x00003203
		public void AddEffect(HitEffect effect)
		{
			this._effect |= (int)effect;
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x00005013 File Offset: 0x00003213
		public void RemoveEffect(HitEffect effect)
		{
			this._effect &= (int)(~(int)effect);
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x00005024 File Offset: 0x00003224
		public void ResetEffects()
		{
			this._effect = 0;
		}

		// Token: 0x0400069F RID: 1695
		public long SenderId;

		// Token: 0x040006A0 RID: 1696
		public long VictimGameClientId;

		// Token: 0x040006A1 RID: 1697
		public GameClient Sender;

		// Token: 0x040006A2 RID: 1698
		public GameClient VictimGameClient;

		// Token: 0x040006A3 RID: 1699
		public int BodyPartHit;

		// Token: 0x040006A4 RID: 1700
		public float Damage;

		// Token: 0x040006A5 RID: 1701
		public Vector3 VictimPosition;

		// Token: 0x040006A6 RID: 1702
		public Vector3 ShooterPosition;

		// Token: 0x040006A7 RID: 1703
		public EDamageType DamageType;

		// Token: 0x040006A8 RID: 1704
		public EWeaponCategory WeaponCategory;

		// Token: 0x040006A9 RID: 1705
		public string WeaponModel;

		// Token: 0x040006AA RID: 1706
		public int WeaponId;

		// Token: 0x040006AB RID: 1707
		private int _effect;

		// Token: 0x040006AC RID: 1708
		public float VictimRemainingLife;

		// Token: 0x040006AD RID: 1709
		public int ShotsFired;

		// Token: 0x040006AE RID: 1710
		public float VictimRemainingArmor;

		// Token: 0x040006AF RID: 1711
		public float VictimSecondWindRecoverDuration;

		// Token: 0x040006B0 RID: 1712
		public float VictimSecondWindRecoverLife;

		// Token: 0x040006B2 RID: 1714
		public byte PetHit;

		// Token: 0x040006B3 RID: 1715
		public bool IsSecondFunction;
	}
}
