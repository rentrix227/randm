﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000E5 RID: 229
	public class CapturePointEvent
	{
		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060003E9 RID: 1001 RVA: 0x0000502D File Offset: 0x0000322D
		// (set) Token: 0x060003EA RID: 1002 RVA: 0x00005035 File Offset: 0x00003235
		public PointOwner Owner { get; set; }

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060003EB RID: 1003 RVA: 0x0000503E File Offset: 0x0000323E
		// (set) Token: 0x060003EC RID: 1004 RVA: 0x00005046 File Offset: 0x00003246
		public string PointName { get; set; }

		// Token: 0x060003ED RID: 1005 RVA: 0x0000504F File Offset: 0x0000324F
		public override string ToString()
		{
			return string.Format("[CapturePointEvent: Owner={0}, PointName={1}}]", this.Owner, this.PointName);
		}
	}
}
