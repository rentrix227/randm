﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Helper;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000EC RID: 236
	public class UserListChangedEvent
	{
		// Token: 0x040006E3 RID: 1763
		public long SenderId;

		// Token: 0x040006E4 RID: 1764
		public string SenderNickname;

		// Token: 0x040006E5 RID: 1765
		public Team SenderTeam;

		// Token: 0x040006E6 RID: 1766
		public UserUpdateType UpdateType;
	}
}
