﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;

namespace Aquiris.Ballistic.Game.Networking.Events
{
	// Token: 0x020000E6 RID: 230
	public class ClientListReceivedEvent
	{
		// Token: 0x060003EE RID: 1006 RVA: 0x00020AB8 File Offset: 0x0001ECB8
		public ClientListReceivedEvent(GameModeMetaData gameModeMetaData)
		{
			List<GameClient> list = new List<GameClient>();
			foreach (KeyValuePair<long, ClientCommonMetaData> keyValuePair in gameModeMetaData.ClientMetaDataMap)
			{
				GameClient gameClient = new GameClient(keyValuePair.Key);
				if (gameClient.isMe)
				{
					this.GameClient = gameClient;
				}
				list.Add(gameClient);
			}
			this.GameClientList = list;
		}

		// Token: 0x040006B6 RID: 1718
		public List<GameClient> GameClientList;

		// Token: 0x040006B7 RID: 1719
		public GameClient GameClient;
	}
}
