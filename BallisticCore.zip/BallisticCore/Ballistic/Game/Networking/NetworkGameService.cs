﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Aquiris.Ballistic.Game.Character.Network;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.SceneSystem;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network;
using Aquiris.Ballistic.Network.Address;
using Aquiris.Ballistic.Network.Configuration.Steam;
using Aquiris.Ballistic.Network.Connection;
using Aquiris.Ballistic.Network.Gameplay.GameMode;
using Aquiris.Ballistic.Network.Transmission.Events;
using Aquiris.Ballistic.Network.Transmission.Packet.Thrift;
using Aquiris.Ballistic.Network.Transport.Connection.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Capture.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Capture.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.Chat;
using Aquiris.Ballistic.Network.Transport.Gameplay.Command.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Inventory.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Inventory.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Leaderboards.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Loadout;
using Aquiris.Ballistic.Network.Transport.Gameplay.Missions;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Spawn.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Userlist.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.Vote.Events;
using Aquiris.Ballistic.Network.Transport.Player;
using Aquiris.Ballistic.Network.Transport.User.Events;
using Aquiris.Ballistic.Network.Transport.User.Requests;
using Aquiris.Ballistic.Utils;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using Steamworks;
using Thrift.Protocol;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Networking
{
	// Token: 0x020000ED RID: 237
	public class NetworkGameService : IService
	{
		// Token: 0x17000083 RID: 131
		// (get) Token: 0x0600042D RID: 1069 RVA: 0x0000526E File Offset: 0x0000346E
		private float _udpDelay
		{
			get
			{
				return 0.0333333351f;
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x0600042E RID: 1070 RVA: 0x00005275 File Offset: 0x00003475
		// (set) Token: 0x0600042F RID: 1071 RVA: 0x0000527D File Offset: 0x0000347D
		internal BallisticClient BallisticClient { get; private set; }

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06000430 RID: 1072 RVA: 0x00005286 File Offset: 0x00003486
		// (set) Token: 0x06000431 RID: 1073 RVA: 0x0000528E File Offset: 0x0000348E
		internal BallisticHost BallisticHost { get; private set; }

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x06000432 RID: 1074 RVA: 0x00005297 File Offset: 0x00003497
		// (set) Token: 0x06000433 RID: 1075 RVA: 0x0000529F File Offset: 0x0000349F
		internal bool ServerIsTerminating { get; private set; }

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06000434 RID: 1076 RVA: 0x000052A8 File Offset: 0x000034A8
		// (set) Token: 0x06000435 RID: 1077 RVA: 0x000052B0 File Offset: 0x000034B0
		internal bool LoadMapAutomatically { get; private set; }

		// Token: 0x06000436 RID: 1078 RVA: 0x000212F0 File Offset: 0x0001F4F0
		internal override void Preprocess()
		{
			SteamCallbacks.LobbyCreated_t.RegisterCallback(new Action<LobbyCreated_t>(this.OnLobbyCreatedCallback));
			SteamCallbacks.LobbyGameCreated_t.RegisterCallback(new Action<LobbyGameCreated_t>(this.OnLobbyGameCreatedCallback));
			SteamCallbacks.LobbyEnter_t.RegisterCallback(new Action<LobbyEnter_t>(this.OnLobbyEnterCallback));
			SteamCallbacks.LobbyDataUpdate_t.RegisterCallback(new Action<LobbyDataUpdate_t>(this.OnLobbyDataUpdate));
			SteamCallbacks.LobbyChatUpdate_t.RegisterCallback(new Action<LobbyChatUpdate_t>(this.OnLobbyChatUpdate));
			ServiceProvider.GetService<EventProxy>().EUpdate.AddListener(new Action(this.Update));
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x00021370 File Offset: 0x0001F570
		internal override void Postprocess()
		{
			SteamCallbacks.LobbyCreated_t.UnregisterCallback(new Action<LobbyCreated_t>(this.OnLobbyCreatedCallback));
			SteamCallbacks.LobbyGameCreated_t.UnregisterCallback(new Action<LobbyGameCreated_t>(this.OnLobbyGameCreatedCallback));
			SteamCallbacks.LobbyEnter_t.UnregisterCallback(new Action<LobbyEnter_t>(this.OnLobbyEnterCallback));
			SteamCallbacks.LobbyDataUpdate_t.UnregisterCallback(new Action<LobbyDataUpdate_t>(this.OnLobbyDataUpdate));
			SteamCallbacks.LobbyChatUpdate_t.UnregisterCallback(new Action<LobbyChatUpdate_t>(this.OnLobbyChatUpdate));
			if (this.BallisticClient != null && this.BallisticClient.IsConnected)
			{
				this.DisconnectFromServer();
			}
			if (this.HasServer)
			{
				this.DestroyServer();
			}
			if (this._lobbyConnected)
			{
				this.LeaveCurrentLobby();
			}
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x00021418 File Offset: 0x0001F618
		internal void Update()
		{
			if (!this._registeredSceneCallback)
			{
				ServiceProvider.GetService<SceneService>().OnLeaveGameScene += this.OnLeaveGameScene;
				this._registeredSceneCallback = true;
			}
			if (this._timer != null)
			{
				this._timer.Update();
			}
			if (this.BallisticHost != null)
			{
				this.BallisticHost.UpdateGameMode(Time.deltaTime);
				this._timeInterval -= Time.deltaTime;
				if (this._timeInterval < 0f)
				{
					this._timeInterval += 5f;
					if (this._lobbyConnected)
					{
						this.UpdateLobbyConfig(this.BallisticHost.ConnectionHostManager.CurrentConfig.GameMap, this.BallisticHost.ConnectionHostManager.CurrentConfig.GameMode);
						this.UpdateLobbyData((uint)this.BallisticHost.ConnectionHostManager.ClientCount(EClientMode.PLAYER), (uint)this.BallisticHost.ConnectionHostManager.ClientCount(EClientMode.SPECTATOR));
						GameModeHost gameModeHost = this.BallisticHost.GetGameModeHost();
						this.UpdateSteamUsers((gameModeHost != null) ? gameModeHost.ListClientCommonMetaData() : null);
					}
				}
				this._setHostInterval -= Time.deltaTime;
				if (this._setHostInterval < 0f)
				{
					this._setHostInterval += 45f;
					if (this._lobbyConnected)
					{
						this.SetLobbyHostInfo();
					}
				}
			}
			if (this.BallisticClient != null)
			{
				this.BallisticClient.Update();
				if (this.BallisticClient.GetGameModeMetaData() != null && this.BallisticClient.GetGameModeMetaData().GameConfig.ServerType == EServerType.OFFICIAL)
				{
					this._telemetryInterval -= Time.deltaTime;
					if (this._telemetryInterval < 0f)
					{
						this._telemetryInterval += 60f;
						ServiceProvider.GetService<TelemetryService>().SubmitAvgPlayerToPlayerPing(this.BallisticClient.GetGameModeMetaData().GameConfig.ServerName);
					}
				}
			}
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x000052B9 File Offset: 0x000034B9
		private void EverySecondUpdateEvent()
		{
			if (this.IsConnected())
			{
				this.BallisticClient.Ping();
			}
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x000052D1 File Offset: 0x000034D1
		public bool IsConnected()
		{
			return this.BallisticClient != null && this.BallisticClient.IsConnected;
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x000052EC File Offset: 0x000034EC
		public bool IsConnecting()
		{
			return this.BallisticClient != null && this.BallisticClient.IsConnecting;
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x00005307 File Offset: 0x00003507
		public CSteamID GetHostId()
		{
			if (this.BallisticClient != null)
			{
				return this.BallisticClient.GetHostID();
			}
			return CSteamID.Nil;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x00005325 File Offset: 0x00003525
		public double GetServerTimeStamp()
		{
			return this.BallisticClient.GetServerTimeStamp();
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x0600043E RID: 1086 RVA: 0x00005332 File Offset: 0x00003532
		internal List<GameClient> GameClients
		{
			get
			{
				return this._players.Values.ToList<GameClient>();
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x0600043F RID: 1087 RVA: 0x00021610 File Offset: 0x0001F810
		public double MatchTimestampAsDouble
		{
			get
			{
				if (this.BallisticClient != null && this.BallisticClient.GetGameModeMetaData() != null && this.BallisticClient.GetGameModeMetaData().GameMetaData != null)
				{
					return this.BallisticClient.GetServerTimeStamp() - (double)this.BallisticClient.GetGameModeMetaData().GameMetaData.ServerStartTime;
				}
				return 0.0;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000440 RID: 1088 RVA: 0x00005344 File Offset: 0x00003544
		public bool MatchTimestampIsValid
		{
			get
			{
				return this.BallisticClient != null && this.BallisticClient.MatchTimestampIsValid;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x0000535F File Offset: 0x0000355F
		public uint MatchTimestamp
		{
			get
			{
				return (uint)Math.Round(this.MatchTimestampAsDouble);
			}
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0002167C File Offset: 0x0001F87C
		public void ConnectToServer(CSteamID serverId, EClientMode clientMode, string password, bool loadMapImeadiate)
		{
			if (this.BallisticClient != null && (this.BallisticClient.IsConnecting || this.BallisticClient.IsConnected))
			{
				Debug.LogWarning("Tried to connect with a server without completely reset network.");
				return;
			}
			this.LoadMapAutomatically = loadMapImeadiate;
			ServiceProvider.GetService<CurrentMatchService>().State = CurrentMatchService.ConnectionState.CONNECTING;
			ServiceProvider.GetService<SpawnService>();
			ServiceProvider.GetService<ResupplyService>();
			ServiceProvider.GetService<GameModeService>();
			ServiceProvider.GetService<TelemetryService>();
			ServiceProvider.GetService<ProgressionService>();
			if (this.BallisticClient == null)
			{
				this.BallisticClient = new BallisticClient();
			}
			Debug.Log("Connecting as " + clientMode);
			this.BallisticClient.CreateConnection(serverId, clientMode, password);
			this._udpTime = 0f;
			this.BallisticClient.OnNetworkPacketReceived += this.OnNetworkPacketReceived;
			this.BallisticClient.OnConnectionEstablished += this.OnConnectionEstablished;
			this.BallisticClient.OnConnectionFailed += this.OnConnectionFailed;
			this.BallisticClient.OnConnectionLost += this.OnConnectionLost;
			this.BallisticClient.OnUserJoin += this.UserJoin;
			this.BallisticClient.OnUserLeft += this.UserLeft;
			this.OnClientConnectionStarted.Invoke();
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x000217CC File Offset: 0x0001F9CC
		internal void DisconnectFromServer()
		{
			Debug.Log("Disconnected");
			this.LeaveCurrentLobby();
			if (this._timer != null)
			{
				this._timer.ClearInterval(1f, new Action(this.EverySecondUpdateEvent));
			}
			ServiceProvider.GetService<ServerInfoService>().UpdateInfo(null, null);
			ServiceProvider.GetService<InventoryService>().StopHeartbeat();
			ServiceProvider.GetService<InventoryService>().CacheInventory();
			if (this.BallisticClient != null)
			{
				this.BallisticClient.OnNetworkPacketReceived -= this.OnNetworkPacketReceived;
				this.BallisticClient.OnConnectionEstablished -= this.OnConnectionEstablished;
				this.BallisticClient.OnConnectionFailed -= this.OnConnectionFailed;
				this.BallisticClient.OnConnectionLost -= this.OnConnectionLost;
				this.BallisticClient.OnUserJoin -= this.UserJoin;
				this.BallisticClient.OnUserLeft -= this.UserLeft;
				this.BallisticClient.DestroyConnection();
				this.BallisticClient = null;
			}
			this.OnConnectionClosed();
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x0000536D File Offset: 0x0000356D
		internal void LoadMapNow()
		{
			this.LoadMapAutomatically = true;
			ServiceProvider.GetService<SceneService>().LoadMap((ulong)this.GetGameModeMetaData().GameConfig.GameMap, this.GetGameModeMetaData().GameConfig.GameMode);
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x000053A0 File Offset: 0x000035A0
		private void OnConnectionClosed()
		{
			this.OnClientConnectionClosed.Invoke();
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x000218E0 File Offset: 0x0001FAE0
		private void OnConnectionEstablished()
		{
			this._timer = new WrapperTimer();
			this._timer.SetInterval(1f, new Action(this.EverySecondUpdateEvent));
			ServiceProvider.GetService<CurrentMatchService>().State = CurrentMatchService.ConnectionState.CONNECTED;
			UserReadyRequest userReadyRequest = new UserReadyRequest
			{
				IsReady = true
			};
			this.RaiseNetworkEvent(userReadyRequest);
			this.OnClientConnectionEstablished.Invoke();
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x000053AD File Offset: 0x000035AD
		private void OnConnectionFailed(LeaveGameMotivation motivation)
		{
			this.DisconnectFromServer();
			if (this.OnClientConnectionFail != null)
			{
				this.OnClientConnectionFail.Invoke(motivation);
			}
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x000053CE File Offset: 0x000035CE
		private void OnConnectionLost()
		{
			this.DisconnectFromServer();
			if (this.OnClientConnectionLost != null)
			{
				this.OnClientConnectionLost.Invoke();
			}
			if (ServiceProvider.GetService<CurrentMatchService>().State != CurrentMatchService.ConnectionState.SERVERTERMINATED)
			{
				ServiceProvider.GetService<SceneService>().LoadMain(string.Empty);
			}
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0000540E File Offset: 0x0000360E
		public GameModeMetaData GetGameModeMetaData()
		{
			BallisticClient ballisticClient = this.BallisticClient;
			return (ballisticClient != null) ? ballisticClient.GetGameModeMetaData() : null;
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x00021940 File Offset: 0x0001FB40
		internal HighSpeedArray<ClientCommonMetaData> GetQueueClientCommonMetadataList(ETeamMode teamMode)
		{
			this._queueClientCommonMetadataList.Clear();
			GameModeMetaData gameModeMetaData = this.GetGameModeMetaData();
			if (gameModeMetaData == null)
			{
				return this._queueClientCommonMetadataList;
			}
			foreach (long num in gameModeMetaData.QueueMetaDataList)
			{
				ClientCommonMetaData clientCommonMetaData = this.GetClientCommonMetaData(num);
				if (clientCommonMetaData != null)
				{
					if (clientCommonMetaData.RequestMode == teamMode || clientCommonMetaData.RequestMode == ETeamMode.ANY)
					{
						this._queueClientCommonMetadataList.Add(clientCommonMetaData);
					}
				}
			}
			return this._queueClientCommonMetadataList;
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x000219F0 File Offset: 0x0001FBF0
		public ClientCommonMetaData GetClientCommonMetaData(long steamId)
		{
			GameModeMetaData gameModeMetaData = this.GetGameModeMetaData();
			if (gameModeMetaData == null)
			{
				return null;
			}
			if (gameModeMetaData.ClientMetaDataMap == null || !gameModeMetaData.ClientMetaDataMap.ContainsKey(steamId))
			{
				return null;
			}
			return gameModeMetaData.ClientMetaDataMap[steamId];
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x00005425 File Offset: 0x00003625
		public GameClient GetClient(long clientId)
		{
			if (this._players == null)
			{
				return null;
			}
			return this._players.ContainsKey(clientId) ? this._players[clientId] : null;
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x00021A38 File Offset: 0x0001FC38
		private void OnLeaveGameScene()
		{
			if (ServiceProvider.GetService<CurrentMatchService>().State == CurrentMatchService.ConnectionState.CONNECTED)
			{
				ServiceProvider.GetService<CurrentMatchService>().State = CurrentMatchService.ConnectionState.DISCONNECTED;
			}
			if (this.BallisticClient != null && this.BallisticClient.IsConnected)
			{
				this.DisconnectFromServer();
			}
			if (this.HasServer)
			{
				this.DestroyServer();
			}
			if (this._lobbyConnected)
			{
				this.LeaveCurrentLobby();
			}
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x00005457 File Offset: 0x00003657
		private static void OnValidadeAfterDisconnection(bool value, byte[] binaryData)
		{
			ServiceProvider.GetService<SoldiersService>().ValidateAll();
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x00021A94 File Offset: 0x0001FC94
		private void OnValidadeAfterRequest(bool value, byte[] binaryData)
		{
			ServiceProvider.GetService<SoldiersService>().ValidateAll();
			byte[] array = CompressionHelper.CompressBytes(binaryData);
			InventoryResponse inventoryResponse = new InventoryResponse
			{
				Data = array
			};
			this.RaiseNetworkEvent(inventoryResponse);
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x00021AC8 File Offset: 0x0001FCC8
		internal void CreateFakeClient(long id, LoadoutInfo info, sbyte team, int weaponInUser)
		{
			ClientCommonMetaData clientCommonMetaData = new ClientCommonMetaData
			{
				User = id,
				Nickname = "Preload",
				CurrentState = EPlayerState.ALIVE,
				Health = 0.0,
				Deaths = 0,
				Score = 0,
				Kills = 0,
				Assists = 0,
				Criticalassists = 0,
				Ready = true,
				Team = team,
				WeaponInUse = weaponInUser,
				LoadoutInfo = info
			};
			this.BallisticClient.GetGameModeMetaData().ClientMetaDataMap.Add(id, clientCommonMetaData);
			this._players.Add(id, new GameClient(id));
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00005463 File Offset: 0x00003663
		internal void DestroyFakeClient(long id)
		{
			this._players.Remove(id);
			this.BallisticClient.GetGameModeMetaData().ClientMetaDataMap.Remove(id);
			this.UserLeft(id);
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x00021B70 File Offset: 0x0001FD70
		private void UserLeft(long userId)
		{
			UserListChangedEvent userListChangedEvent = new UserListChangedEvent
			{
				SenderId = userId,
				UpdateType = UserUpdateType.UserLeftRoom
			};
			this.ListChanged(userListChangedEvent);
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x00021B9C File Offset: 0x0001FD9C
		private void UserJoin(long userId)
		{
			UserListChangedEvent userListChangedEvent = new UserListChangedEvent
			{
				SenderId = userId,
				UpdateType = UserUpdateType.UserJoinedRoom
			};
			this.ListChanged(userListChangedEvent);
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00021BC8 File Offset: 0x0001FDC8
		private void ListChanged(UserListChangedEvent evt)
		{
			if (this._players == null)
			{
				this._players = new Dictionary<long, GameClient>();
			}
			UserUpdateType updateType = evt.UpdateType;
			if (updateType != UserUpdateType.UserJoinedRoom)
			{
				if (updateType == UserUpdateType.UserLeftRoom)
				{
					if (this._players.ContainsKey(evt.SenderId))
					{
						GameClient gameClient = this._players[evt.SenderId];
						evt.SenderNickname = gameClient.nickname;
						evt.SenderTeam = gameClient.team;
						this._players.Remove(evt.SenderId);
					}
				}
			}
			else if (!this._players.ContainsKey(evt.SenderId))
			{
				GameClient gameClient2 = new GameClient(evt.SenderId);
				evt.SenderNickname = gameClient2.nickname;
				evt.SenderTeam = gameClient2.team;
				this._players.Add(evt.SenderId, gameClient2);
			}
			this.OnUserListChanged.Invoke(evt);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x00005490 File Offset: 0x00003690
		internal void BroadcastNetworkEvent(TBase evt, bool teamOnly = false)
		{
			if (this.BallisticClient == null)
			{
				return;
			}
			this.BallisticClient.Broadcast(evt, teamOnly);
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x00021CB8 File Offset: 0x0001FEB8
		public void RaiseNetworkEvent(TBase evt)
		{
			if (this.BallisticClient == null)
			{
				return;
			}
			if (evt is UserListRequest)
			{
				this.HandleClientListReceivedEvent(new ClientListReceivedEvent(this.BallisticClient.GetGameModeMetaData()));
				return;
			}
			if (evt is VoiceRequest)
			{
				this.HandleVoiceRequest((VoiceRequest)evt);
			}
			this.BallisticClient.Send(evt);
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x00021D18 File Offset: 0x0001FF18
		public void UpdateState(PlayerState state, MapBounds mapBounds, bool calculateTimestamp = false)
		{
			if (this.BallisticClient == null || mapBounds == null)
			{
				return;
			}
			if (!this.BallisticClient.IsConnected)
			{
				return;
			}
			this._udpTime += Time.deltaTime;
			if (this._udpTime < this._udpDelay)
			{
				return;
			}
			this._udpTime = Mathf.Repeat(this._udpTime, this._udpDelay);
			if (calculateTimestamp)
			{
				state.timeStamp = this.MatchTimestamp;
			}
			try
			{
				this.BallisticClient.SendUdpMessage(state.Pack(mapBounds));
			}
			catch (Exception ex)
			{
				this.OnNetworkError.Invoke(new NetworkErrorEvent
				{
					Message = ex.StackTrace
				});
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000458 RID: 1112 RVA: 0x000054AB File Offset: 0x000036AB
		internal bool HasServer
		{
			get
			{
				return this.BallisticHost != null;
			}
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00021DE4 File Offset: 0x0001FFE4
		internal void CreateServer(SteamConfig config = null)
		{
			if (this.BallisticHost != null)
			{
				return;
			}
			Debug.Log("Running server");
			if (config == null)
			{
				config = new SteamConfig
				{
					MaxPlayers = 12U,
					MaxSpectators = 2U,
					MaxPing = 0,
					ServerName = "NetworkManager",
					SteamPort = 8766,
					GamePort = 27015,
					QueryPort = 27016,
					PrivateMatch = false,
					DedicatedServer = false,
					MatchTime = 600U,
					TeamDeathMatch = 7U,
					RoundTime = 90U,
					WarmUpTime = 34f,
					GameMode = EGameMode.Any,
					GameMap = GameMapModeConfigService.DefaultAnyMap.MapId,
					BroadcastQuality = EConnectionQuality.DedicatedBroadcastAlways,
					BannerUrl = null,
					ClickUrl = null,
					Password = null
				};
			}
			this._setHostInterval = 45f;
			this.BallisticHost = new BallisticHost(config);
			BallisticHost ballisticHost = this.BallisticHost;
			ballisticHost.OnHostReady = (Action)Delegate.Combine(ballisticHost.OnHostReady, new Action(this.OnHostReady));
			BallisticHost ballisticHost2 = this.BallisticHost;
			ballisticHost2.OnHostFail = (Action)Delegate.Combine(ballisticHost2.OnHostFail, new Action(this.OnHostFail));
			this.BallisticHost.StartHost();
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x000054B9 File Offset: 0x000036B9
		internal void StartServer()
		{
			if (this.BallisticHost == null)
			{
				Debug.LogWarning("[NetworkGameService] Invalid Call: Server not created!");
				return;
			}
			Debug.Log("[NetworkGameService] Starting server");
			this.BallisticHost.StartGameMode();
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x000054E6 File Offset: 0x000036E6
		internal void StartServer(GameMapConfig gameMap, EGameMode gameMode)
		{
			if (this.BallisticHost == null)
			{
				Debug.LogWarning("Invalid Call: Server not created!");
				return;
			}
			Debug.Log("[NetworkGameService] Starting server");
			this.BallisticHost.StartGameMode(gameMap, gameMode);
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x00005515 File Offset: 0x00003715
		private void OnHostReady()
		{
			if (this._lobbyConnected)
			{
				this.SetLobbyHostInfo();
			}
			this.OnHostRunning.Invoke();
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00005533 File Offset: 0x00003733
		private void OnHostFail()
		{
			this.OnHostInitError.Invoke();
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00005540 File Offset: 0x00003740
		internal void DestroyServer()
		{
			if (this.BallisticHost == null)
			{
				return;
			}
			Debug.Log("[NetworkGameService] Destroying server");
			this.BallisticHost.Close();
			this.BallisticHost = null;
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0000556A File Offset: 0x0000376A
		internal void CreateLobby(SteamConfig config)
		{
			this.LeaveCurrentLobby();
			this._lobbyConnected = true;
			this._lobbyId = CSteamID.Nil;
			this._lobbyConfig = config;
			this._lobbyPassword = config.Password;
			SteamMatchmaking.CreateLobby(2, (int)this._lobbyConfig.MaxPlayers);
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x00021F30 File Offset: 0x00020130
		internal void JoinLobby(CSteamID lobbyId, string password, EClientMode clientMode = EClientMode.PLAYER)
		{
			this.LeaveCurrentLobby();
			this._lobbyConnected = true;
			this._lobbyId = CSteamID.Nil;
			this._lobbyConfig = new SteamConfig();
			this._lobbyPassword = password;
			this._lobbyClientMode = clientMode;
			this._lobbyPassword = password;
			SteamMatchmaking.JoinLobby(lobbyId);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00021F7C File Offset: 0x0002017C
		private void OnLobbyCreatedCallback(LobbyCreated_t pCallback)
		{
			Debug.Log(string.Concat(new object[] { "[NetworkGameService] LobbyCreated: ", pCallback.m_eResult, " ", pCallback.m_ulSteamIDLobby }));
			this._lobbyId = new CSteamID(pCallback.m_ulSteamIDLobby);
			ServiceProvider.GetService<CurrentMatchService>().State = CurrentMatchService.ConnectionState.IN_LOBBY;
			this.UpdateAllLobbyData();
			this.OnLobbyReady.Invoke();
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x00021FF8 File Offset: 0x000201F8
		private void OnLobbyGameCreatedCallback(LobbyGameCreated_t pCallback)
		{
			if (this.BallisticClient != null && (this.BallisticClient.IsConnecting || this.BallisticClient.IsConnected))
			{
				return;
			}
			Debug.Log(string.Concat(new object[] { "[NetworkGameService] LobbyGameCreated: ", pCallback.m_ulSteamIDLobby, " ", pCallback.m_ulSteamIDGameServer, " ", pCallback.m_unIP, " ", pCallback.m_usPort }));
			string text = ((!string.IsNullOrEmpty(this._lobbyPassword)) ? Crypto.ComputeMd5Hash(this._lobbyPassword) : null);
			this.ConnectToServer(new CSteamID(pCallback.m_ulSteamIDGameServer), EClientMode.SPECTATOR, text, true);
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x000220D4 File Offset: 0x000202D4
		private void OnLobbyEnterCallback(LobbyEnter_t pCallback)
		{
			Debug.Log("[NetworkGameService] LobbyEnter: " + pCallback.m_ulSteamIDLobby);
			if (this.GetLobbyOwnerIsMe())
			{
				return;
			}
			if (this._lobbyId == CSteamID.Nil)
			{
				this._lobbyId = new CSteamID(pCallback.m_ulSteamIDLobby);
			}
			CSteamID lobbyOwner = this.GetLobbyOwner();
			Dictionary<ulong, string> lobbyMembers = this.GetLobbyMembers();
			if (lobbyMembers.Count > 1 && !lobbyOwner.Equals(SteamUser.GetSteamID()) && lobbyOwner.m_SteamID != 0UL && lobbyMembers.ContainsKey(lobbyOwner.m_SteamID))
			{
				this.GetUpdateAllLobbyData();
				ServiceProvider.GetService<CurrentMatchService>().State = CurrentMatchService.ConnectionState.IN_LOBBY;
				if (this.BallisticClient != null && (this.BallisticClient.IsConnecting || this.BallisticClient.IsConnected))
				{
					return;
				}
				uint num;
				ushort num2;
				CSteamID csteamID;
				if (SteamMatchmaking.GetLobbyGameServer(this._lobbyId, ref num, ref num2, ref csteamID))
				{
					Debug.Log("Connecting with Server..LobbyID:" + this._lobbyId);
					this.ConnectToServer(csteamID, this._lobbyClientMode, this._lobbyPassword, true);
				}
				else
				{
					this.OnLobbyEnter.Invoke();
				}
			}
			else
			{
				this.LeaveCurrentLobby();
			}
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x000055A9 File Offset: 0x000037A9
		private void OnLobbyDataUpdate(LobbyDataUpdate_t pCallback)
		{
			if (!this.GetLobbyOwnerIsMe())
			{
				this.UpdateAllLobbyData();
			}
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00022218 File Offset: 0x00020418
		private void OnLobbyChatUpdate(LobbyChatUpdate_t callback)
		{
			if (callback.m_rgfChatMemberStateChange != 1U && this.GetLobbyOwner().m_SteamID == callback.m_ulSteamIDUserChanged)
			{
				this.LeaveCurrentLobby();
			}
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x000055BC File Offset: 0x000037BC
		private void SetLobbyHostInfo()
		{
			SteamMatchmaking.SetLobbyGameServer(this._lobbyId, 0U, 0, this.BallisticHost.GetHostId());
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00022254 File Offset: 0x00020454
		private void UpdateAllLobbyData()
		{
			SteamMatchmaking.SetLobbyData(this._lobbyId, "sn", this._lobbyConfig.ServerName);
			SteamMatchmaking.SetLobbyData(this._lobbyId, "ma", this._lobbyConfig.GameMap.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "gm", this._lobbyConfig.GameMode.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "np", this._lobbyConfig.NumPlayers.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "mp", this._lobbyConfig.MaxPlayers.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "ns", this._lobbyConfig.NumSpectators.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "ms", this._lobbyConfig.MaxSpectators.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "pi", this._lobbyConfig.MaxPing.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "v", BallisticVersion.VERSION);
			SteamMatchmaking.SetLobbyData(this._lobbyId, "r", SteamUtils.GetIPCountry());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "gs", true.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "pw", (!string.IsNullOrEmpty(this._lobbyConfig.Password)) ? Crypto.ComputeMd5Hash(this._lobbyConfig.Password) : "null");
			SteamMatchmaking.SetLobbyData(this._lobbyId, "md", BytePacker.PackString(from t in ServiceProvider.GetService<GameMapModeConfigService>().GetAvaliableGameMapConfigList()
				select t.MapId));
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00022464 File Offset: 0x00020664
		internal void UpdateLobbyConfig(ulong gameMap, EGameMode gameMode)
		{
			this._lobbyConfig.GameMap = gameMap;
			this._lobbyConfig.GameMode = gameMode;
			SteamMatchmaking.SetLobbyData(this._lobbyId, "ma", this._lobbyConfig.GameMap.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "gm", this._lobbyConfig.GameMode.ToString());
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x000224E0 File Offset: 0x000206E0
		internal void UpdateLobbyData(uint numPlayers, uint numSpectators)
		{
			this._lobbyConfig.NumPlayers = numPlayers;
			this._lobbyConfig.NumSpectators = numSpectators;
			SteamMatchmaking.SetLobbyData(this._lobbyId, "np", this._lobbyConfig.NumPlayers.ToString());
			SteamMatchmaking.SetLobbyData(this._lobbyId, "ns", this._lobbyConfig.NumSpectators.ToString());
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00022554 File Offset: 0x00020754
		internal void UpdateSteamUsers(IEnumerable<ClientCommonMetaData> players)
		{
			if (players != null)
			{
				SteamMatchmaking.SetLobbyData(this._lobbyId, "su", BytePacker.PackString(players.Select((ClientCommonMetaData t) => t.User)));
			}
			else
			{
				SteamMatchmaking.SetLobbyData(this._lobbyId, "su", string.Empty);
			}
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x000225BC File Offset: 0x000207BC
		private void GetUpdateAllLobbyData()
		{
			this._lobbyConfig.ServerName = SteamMatchmaking.GetLobbyData(this._lobbyId, "sn");
			this._lobbyConfig.MaxPlayers = uint.Parse(SteamMatchmaking.GetLobbyData(this._lobbyId, "mp"));
			this._lobbyConfig.MaxSpectators = uint.Parse(SteamMatchmaking.GetLobbyData(this._lobbyId, "ms"));
			this._lobbyConfig.MaxPing = int.Parse(SteamMatchmaking.GetLobbyData(this._lobbyId, "pi"));
			this._lobbyConfig.Password = ((!(SteamMatchmaking.GetLobbyData(this._lobbyId, "pw") != "null")) ? string.Empty : SteamMatchmaking.GetLobbyData(this._lobbyId, "pw"));
			this._lobbyConfig.GameMap = ulong.Parse(SteamMatchmaking.GetLobbyData(this._lobbyId, "ma"));
			string lobbyData = SteamMatchmaking.GetLobbyData(this._lobbyId, "gm");
			IEnumerator enumerator = Enum.GetValues(typeof(EGameMode)).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					EGameMode egameMode = (EGameMode)obj;
					if (egameMode.ToString() == lobbyData)
					{
						this._lobbyConfig.GameMode = egameMode;
						break;
					}
				}
			}
			finally
			{
				IDisposable disposable;
				if ((disposable = enumerator as IDisposable) != null)
				{
					disposable.Dispose();
				}
			}
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0002273C File Offset: 0x0002093C
		private Dictionary<ulong, string> GetLobbyMembers()
		{
			Dictionary<ulong, string> dictionary = new Dictionary<ulong, string>();
			int numLobbyMembers = SteamMatchmaking.GetNumLobbyMembers(this._lobbyId);
			for (int i = 0; i < numLobbyMembers; i++)
			{
				CSteamID lobbyMemberByIndex = SteamMatchmaking.GetLobbyMemberByIndex(this._lobbyId, i);
				if (!dictionary.ContainsKey(lobbyMemberByIndex.m_SteamID))
				{
					string friendPersonaName = SteamFriends.GetFriendPersonaName(lobbyMemberByIndex);
					dictionary.Add(lobbyMemberByIndex.m_SteamID, friendPersonaName);
				}
			}
			return dictionary;
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x000055D6 File Offset: 0x000037D6
		internal CSteamID GetLobbyId()
		{
			return this._lobbyId;
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x000055DE File Offset: 0x000037DE
		internal SteamConfig GetLobbyConfig()
		{
			return this._lobbyConfig;
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x000055E6 File Offset: 0x000037E6
		private CSteamID GetLobbyOwner()
		{
			return SteamMatchmaking.GetLobbyOwner(this._lobbyId);
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x000055F3 File Offset: 0x000037F3
		internal bool IsLobbyConnected()
		{
			return this._lobbyConnected;
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x000227AC File Offset: 0x000209AC
		private bool GetLobbyOwnerIsMe()
		{
			return SteamMatchmaking.GetLobbyOwner(this._lobbyId).m_SteamID == SteamUser.GetSteamID().m_SteamID;
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x000227DC File Offset: 0x000209DC
		internal void LeaveCurrentLobby()
		{
			if (ServiceProvider.GetService<CurrentMatchService>().State == CurrentMatchService.ConnectionState.CONNECTED)
			{
				ServiceProvider.GetService<CurrentMatchService>().State = CurrentMatchService.ConnectionState.DISCONNECTED;
			}
			if (this._lobbyConnected)
			{
				SteamMatchmaking.LeaveLobby(this._lobbyId);
				this._lobbyId = CSteamID.Nil;
				this._lobbyConnected = false;
			}
			this.DestroyServer();
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x000055FB File Offset: 0x000037FB
		internal void SimulateSpawnEvent(SpawnEvent evt)
		{
			this.HandleSpawnEvent(evt);
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x00005604 File Offset: 0x00003804
		internal void SimulateDieEvent(DieEvent evt)
		{
			this.HandleDieEvent(evt);
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x0000560D File Offset: 0x0000380D
		private void HandleSpawnEvent(SpawnEvent evt)
		{
			this.OnSpawn.Invoke(evt);
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x0000561B File Offset: 0x0000381B
		private void HandleReadyToSpawnResponseEvent(ReadyToSpawnResponse evt)
		{
			this.OnReadyToSpawn.Invoke(evt);
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x00022834 File Offset: 0x00020A34
		private void HandleUserReadyEvent(UserReadyEvent evt)
		{
			if (evt.User != (long)SteamUser.GetSteamID().m_SteamID)
			{
				return;
			}
			this.OnMapLoad.Invoke(new MapLoadEvent(this.GetGameModeMetaData()));
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x00005629 File Offset: 0x00003829
		private void HandleChangeGameStateEvent(ChangeGameStateEvent evt)
		{
			if (this.OnChangeState != null)
			{
				this.OnChangeState.Invoke(evt);
			}
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x00005642 File Offset: 0x00003842
		private void HandleChangeRoundEvent(ChangeRoundEvent evt)
		{
			if (this.OnRoundUp != null)
			{
				this.OnRoundUp.Invoke(evt);
			}
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x0000565B File Offset: 0x0000385B
		private void HandleGrenadeLaunchEvent(GrenadeLaunchEvent evt)
		{
			this.OnGrenadeLaunch.Invoke(evt);
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x00022870 File Offset: 0x00020A70
		private void HandleClientListReceivedEvent(ClientListReceivedEvent evt)
		{
			Debug.Log("Clientlist received");
			if (evt.GameClientList != null)
			{
				if (evt.GameClient != null)
				{
					UserProfile.LocalGameClient = evt.GameClient;
				}
				if (this._players == null)
				{
					this._players = new Dictionary<long, GameClient>();
				}
				else
				{
					this._players.Clear();
				}
				foreach (GameClient gameClient in evt.GameClientList.Where((GameClient c) => !this._players.ContainsKey(c.gameClientId)))
				{
					this._players.Add(gameClient.gameClientId, gameClient);
				}
			}
			else
			{
				if (this._players != null)
				{
					this._players.Clear();
				}
				this._players = null;
			}
			ServiceProvider.GetService<ServerInfoService>().UpdateInfo(this.GetGameModeMetaData().GameConfig.BannerUrl, this.GetGameModeMetaData().GameConfig.ClickUrl);
			this.OnClientListReceived.Invoke(evt);
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x00005669 File Offset: 0x00003869
		private void HandleChatReceived(ChatEvent evt)
		{
			this.OnChatReceived.Invoke(evt);
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00005677 File Offset: 0x00003877
		private void HandlePlayerInfoReceived(PlayerInfoEvent evt)
		{
			this.OnPlayerInfoUpdated.Invoke(evt);
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x00005685 File Offset: 0x00003885
		private void HandleServerTerminationEvent(ServerTerminationEvent evt)
		{
			this.ServerIsTerminating = true;
			this.OnServerTermination.Invoke(evt);
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x0000569A File Offset: 0x0000389A
		private void HandleServerMessege(ServerCommandEvent evt)
		{
			this.OnServerCommandEvent.Invoke(evt);
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x000056A8 File Offset: 0x000038A8
		private void HandleCapturePointUpdateEvent(CapturePointUpdateStateEvent evt)
		{
			this.OnCapturePointUpdate.Invoke(evt);
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x000056B6 File Offset: 0x000038B6
		private void HandleCapturePointInteractionResponse(CapturePointInteractionResponse evt)
		{
			this.OnCapturePointInteractionResponse.Invoke(evt);
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x000056C4 File Offset: 0x000038C4
		private void HandleCapturedPointEvent(CapturedPointEvent evt)
		{
			this.OnCapturedPoint.Invoke(evt);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x000056D2 File Offset: 0x000038D2
		private void HandleUserStateUpdate(PlayerStateEvent evt)
		{
			this.OnUserStateUpdate.Invoke(evt);
			ArrayPool<byte>.FreeBuffer(evt.PlayerState);
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x000056EB File Offset: 0x000038EB
		private void HandleTeamQueueChangedEvent(TeamQueueChangedEvent evt)
		{
			this.OnTeamQueueChanged.Invoke(evt);
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x000056F9 File Offset: 0x000038F9
		private void HandleSelectTeam(SelectTeamResponse evt)
		{
			this.OnSelectTeam.Invoke(evt);
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x00005707 File Offset: 0x00003907
		private void HandleSelectTeamCompleted(SelectTeamCompletedResponse evt)
		{
			this.OnSelectTeamCompleted.Invoke(evt);
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x00005715 File Offset: 0x00003915
		private void HandleResupplyEvent(ResupplyEvent evt)
		{
			this.OnResupplyResponse.Invoke(evt);
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x00022990 File Offset: 0x00020B90
		private void HandleUserConnectedEvent(UserConnectedEvent evt)
		{
			this.ListChanged(new UserListChangedEvent
			{
				SenderId = evt.User,
				UpdateType = UserUpdateType.UserJoinedRoom
			});
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x00005723 File Offset: 0x00003923
		private void HandleHitEvent(HitEvent evt)
		{
			this.OnUserHit.Invoke(evt);
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x00005731 File Offset: 0x00003931
		private void HandleDieEvent(DieEvent evt)
		{
			this.OnDie.Invoke(evt);
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x0000573F File Offset: 0x0000393F
		private void HandleWeaponChangeEvent(ChangeWeaponEvent evt)
		{
			this.OnWeaponChange.Invoke(evt);
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0000574D File Offset: 0x0000394D
		private void HandleVoteStartEvent(VoteMapStartEvent evt)
		{
			this.OnVoteStart.Invoke(evt);
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x0000575B File Offset: 0x0000395B
		private void HandleTimeRemainingEvent(TimeRemainingEvent evt)
		{
			this.OnTimeRemaining.Invoke(evt);
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x00005769 File Offset: 0x00003969
		private void HandleVoteUpdateEvent(VoteMapEvent evt)
		{
			this.OnVoteUpdate.Invoke(evt);
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x00005777 File Offset: 0x00003977
		private void HandleVoteEndEvent(VoteMapEndEvent evt)
		{
			this.OnVoteEnd.Invoke(evt);
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x00005785 File Offset: 0x00003985
		private void HandleRecoveryHealth(RecoverHealthEvent evt)
		{
			this.OnRecoveryHealth.Invoke(evt);
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x00005793 File Offset: 0x00003993
		private void HandleTeamScoreEvent(TeamScoreEvent evt)
		{
			this.OnTeamScoreEvent.Invoke(evt);
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x000057A1 File Offset: 0x000039A1
		private void HandleTeamCallRequest(TeamCallRequest evt)
		{
			this.OnTeamCall.Invoke(evt);
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x000057AF File Offset: 0x000039AF
		private void HandleRebalanceCallRequest(RebalanceCallRequest evt)
		{
			this.OnRebalanceCall.Invoke(evt);
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x000057BD File Offset: 0x000039BD
		private void HandleVoiceRequest(VoiceRequest evt)
		{
			this.OnVoiceRequest.Invoke(evt);
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x000057CB File Offset: 0x000039CB
		private void HandleInventoryRequest()
		{
			ServiceProvider.GetService<InventoryService>().Validate(new Action<bool, byte[]>(this.OnValidadeAfterRequest));
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x000057E3 File Offset: 0x000039E3
		private void HandleServerInfo(ServerInfoEvent evt)
		{
			ServiceProvider.GetService<ServerInfoService>().UpdateInfo(evt.Banner, evt.Click);
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x000057FB File Offset: 0x000039FB
		private void HandleLeaderboardUpload(LeaderboardUploadEvent evt)
		{
			this.OnLeaderboardUpload.Invoke(evt);
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x00005809 File Offset: 0x00003A09
		private void HandleMissionsLoaded(MissionsLoadedEvent evt)
		{
			this.OnMissionsLoaded.Invoke(evt);
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x00005817 File Offset: 0x00003A17
		private void HandleMissionsChange(MissionsChangeEvent evt)
		{
			this.OnMissionsChange.Invoke(evt);
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x00005825 File Offset: 0x00003A25
		private void HandleMissionsRewarded(MissionsRewardEvent evt)
		{
			this.OnMissionsRewarded.Invoke(evt);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x00005833 File Offset: 0x00003A33
		private void HandleWeaponStationEvent(WeaponStationEvent evt)
		{
			this.OnWeaponStationEvent.Invoke(evt);
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00005841 File Offset: 0x00003A41
		private void HandleScoreUpdateEvent(ScoreUpdateEvent evt)
		{
			this.OnScoreUpdateEvent.Invoke(evt);
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x000229C0 File Offset: 0x00020BC0
		private void OnNetworkPacketReceived(PacketReceivedEventArgs<ThriftPacket, CSteamID, TBase, ETransportChannel, NetworkAddress<CSteamID>> packet)
		{
			ThriftPacket packet2 = packet.Packet;
			if (packet2.TransportObject is SpawnEvent)
			{
				this.HandleSpawnEvent((SpawnEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ReadyToSpawnResponse)
			{
				this.HandleReadyToSpawnResponseEvent((ReadyToSpawnResponse)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ChangeGameStateEvent)
			{
				this.HandleChangeGameStateEvent((ChangeGameStateEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ChangeRoundEvent)
			{
				this.HandleChangeRoundEvent((ChangeRoundEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is UpdateStateEvent)
			{
				this.HandleClientListReceivedEvent(new ClientListReceivedEvent(this.BallisticClient.GetGameModeMetaData()));
			}
			else if (packet2.TransportObject is ChangeWeaponEvent)
			{
				this.HandleWeaponChangeEvent((ChangeWeaponEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is PlayerStateEvent)
			{
				this.HandleUserStateUpdate((PlayerStateEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is PlayerDieEvent)
			{
				this.HandleDieEvent(new DieEvent((PlayerDieEvent)packet2.TransportObject));
			}
			else if (packet2.TransportObject is UserReadyEvent)
			{
				this.HandleUserReadyEvent((UserReadyEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is GrenadeLaunchEvent)
			{
				this.HandleGrenadeLaunchEvent((GrenadeLaunchEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is UserConnectedEvent)
			{
				this.HandleUserConnectedEvent((UserConnectedEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is CapturePointInteractionResponse)
			{
				this.HandleCapturePointInteractionResponse((CapturePointInteractionResponse)packet2.TransportObject);
			}
			else if (packet2.TransportObject is CapturePointUpdateStateEvent)
			{
				this.HandleCapturePointUpdateEvent((CapturePointUpdateStateEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is CapturedPointEvent)
			{
				this.HandleCapturedPointEvent((CapturedPointEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is PlayerHitEvent)
			{
				this.HandleHitEvent(new HitEvent((PlayerHitEvent)packet2.TransportObject));
			}
			else if (packet2.TransportObject is ResupplyEvent)
			{
				this.HandleResupplyEvent((ResupplyEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is VoteMapStartEvent)
			{
				this.HandleVoteStartEvent((VoteMapStartEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is VoteMapEvent)
			{
				this.HandleVoteUpdateEvent((VoteMapEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is VoteMapEndEvent)
			{
				this.HandleVoteEndEvent((VoteMapEndEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is RecoverHealthEvent)
			{
				this.HandleRecoveryHealth((RecoverHealthEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ChatEvent)
			{
				this.HandleChatReceived((ChatEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is TimeRemainingEvent)
			{
				this.HandleTimeRemainingEvent((TimeRemainingEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is TeamScoreEvent)
			{
				this.HandleTeamScoreEvent((TeamScoreEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is TeamCallRequest)
			{
				this.HandleTeamCallRequest((TeamCallRequest)packet2.TransportObject);
			}
			else if (packet2.TransportObject is RebalanceCallRequest)
			{
				this.HandleRebalanceCallRequest((RebalanceCallRequest)packet2.TransportObject);
			}
			else if (packet2.TransportObject is SelectTeamResponse)
			{
				this.HandleSelectTeam((SelectTeamResponse)packet2.TransportObject);
			}
			else if (packet2.TransportObject is SelectTeamCompletedResponse)
			{
				this.HandleSelectTeamCompleted((SelectTeamCompletedResponse)packet2.TransportObject);
			}
			else if (packet2.TransportObject is TeamQueueChangedEvent)
			{
				this.HandleTeamQueueChangedEvent((TeamQueueChangedEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is InventoryRequest)
			{
				this.HandleInventoryRequest();
			}
			else if (packet2.TransportObject is PlayerInfoEvent)
			{
				this.HandlePlayerInfoReceived((PlayerInfoEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ServerInfoEvent)
			{
				this.HandleServerInfo((ServerInfoEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ServerTerminationEvent)
			{
				this.HandleServerTerminationEvent((ServerTerminationEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is VoiceRequest)
			{
				this.HandleVoiceRequest((VoiceRequest)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ServerCommandEvent)
			{
				this.HandleServerMessege((ServerCommandEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is LeaderboardUploadEvent)
			{
				this.HandleLeaderboardUpload((LeaderboardUploadEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is MissionsChangeEvent)
			{
				this.HandleMissionsChange((MissionsChangeEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is MissionsLoadedEvent)
			{
				this.HandleMissionsLoaded((MissionsLoadedEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is MissionsRewardEvent)
			{
				this.HandleMissionsRewarded((MissionsRewardEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is WeaponStationEvent)
			{
				this.HandleWeaponStationEvent((WeaponStationEvent)packet2.TransportObject);
			}
			else if (packet2.TransportObject is ScoreUpdateEvent)
			{
				this.HandleScoreUpdateEvent((ScoreUpdateEvent)packet2.TransportObject);
			}
		}

		// Token: 0x040006E7 RID: 1767
		public const uint DefaultRounds = 7U;

		// Token: 0x040006E8 RID: 1768
		public const uint DefaultRoundTime = 90U;

		// Token: 0x040006E9 RID: 1769
		public const float DefaultWarmUp = 34f;

		// Token: 0x040006EA RID: 1770
		private const float _gameModeUpdateInterval = 1f;

		// Token: 0x040006EB RID: 1771
		private HighSpeedArray<ClientCommonMetaData> _queueClientCommonMetadataList = new HighSpeedArray<ClientCommonMetaData>(40);

		// Token: 0x040006F0 RID: 1776
		private WrapperTimer _timer;

		// Token: 0x040006F1 RID: 1777
		private bool _registeredSceneCallback;

		// Token: 0x040006F2 RID: 1778
		private float _timeInterval;

		// Token: 0x040006F3 RID: 1779
		private float _setHostInterval;

		// Token: 0x040006F4 RID: 1780
		private float _telemetryInterval;

		// Token: 0x040006F5 RID: 1781
		private float _udpTime;

		// Token: 0x040006F6 RID: 1782
		private Dictionary<long, GameClient> _players;

		// Token: 0x040006F7 RID: 1783
		private bool _lobbyConnected;

		// Token: 0x040006F8 RID: 1784
		private SteamConfig _lobbyConfig;

		// Token: 0x040006F9 RID: 1785
		private CSteamID _lobbyId;

		// Token: 0x040006FA RID: 1786
		private string _lobbyPassword;

		// Token: 0x040006FB RID: 1787
		private EClientMode _lobbyClientMode;

		// Token: 0x040006FC RID: 1788
		public DelegateData<ClientListReceivedEvent> OnClientListReceived = new DelegateData<ClientListReceivedEvent>(20);

		// Token: 0x040006FD RID: 1789
		public DelegateData<SpawnEvent> OnSpawn = new DelegateData<SpawnEvent>(80);

		// Token: 0x040006FE RID: 1790
		public DelegateData<ChangeRoundEvent> OnRoundUp = new DelegateData<ChangeRoundEvent>(100);

		// Token: 0x040006FF RID: 1791
		public DelegateData<UserListChangedEvent> OnUserListChanged = new DelegateData<UserListChangedEvent>(20);

		// Token: 0x04000700 RID: 1792
		public DelegateData<DieEvent> OnDie = new DelegateData<DieEvent>(100);

		// Token: 0x04000701 RID: 1793
		public DelegateData<HitEvent> OnUserHit = new DelegateData<HitEvent>(100);

		// Token: 0x04000702 RID: 1794
		public DelegateData<RecoverHealthEvent> OnRecoveryHealth = new DelegateData<RecoverHealthEvent>(30);

		// Token: 0x04000703 RID: 1795
		public DelegateData<ChangeWeaponEvent> OnWeaponChange = new DelegateData<ChangeWeaponEvent>(60);

		// Token: 0x04000704 RID: 1796
		public DelegateData<GrenadeLaunchEvent> OnGrenadeLaunch = new DelegateData<GrenadeLaunchEvent>(60);

		// Token: 0x04000705 RID: 1797
		public DelegateData<VoiceRequest> OnVoiceRequest = new DelegateData<VoiceRequest>(40);

		// Token: 0x04000706 RID: 1798
		public DelegateData<LeaderboardUploadEvent> OnLeaderboardUpload = new DelegateData<LeaderboardUploadEvent>(20);

		// Token: 0x04000707 RID: 1799
		public DelegateData<MissionsChangeEvent> OnMissionsChange = new DelegateData<MissionsChangeEvent>(20);

		// Token: 0x04000708 RID: 1800
		public DelegateData<MissionsLoadedEvent> OnMissionsLoaded = new DelegateData<MissionsLoadedEvent>(20);

		// Token: 0x04000709 RID: 1801
		public DelegateData<MissionsRewardEvent> OnMissionsRewarded = new DelegateData<MissionsRewardEvent>(20);

		// Token: 0x0400070A RID: 1802
		public DelegateData<WeaponStationEvent> OnWeaponStationEvent = new DelegateData<WeaponStationEvent>(20);

		// Token: 0x0400070B RID: 1803
		public DelegateData<ScoreUpdateEvent> OnScoreUpdateEvent = new DelegateData<ScoreUpdateEvent>(20);

		// Token: 0x0400070C RID: 1804
		public DelegateData<PlayerStateEvent> OnUserStateUpdate = new DelegateData<PlayerStateEvent>(50);

		// Token: 0x0400070D RID: 1805
		public DelegateData<TimeRemainingEvent> OnTimeRemaining = new DelegateData<TimeRemainingEvent>(40);

		// Token: 0x0400070E RID: 1806
		public DelegateData<ChangeGameStateEvent> OnChangeState = new DelegateData<ChangeGameStateEvent>(100);

		// Token: 0x0400070F RID: 1807
		internal DelegateData<TeamScoreEvent> OnTeamScoreEvent = new DelegateData<TeamScoreEvent>(25);

		// Token: 0x04000710 RID: 1808
		internal DelegateData<CapturePointInteractionResponse> OnCapturePointInteractionResponse = new DelegateData<CapturePointInteractionResponse>(40);

		// Token: 0x04000711 RID: 1809
		internal DelegateData<CapturePointUpdateStateEvent> OnCapturePointUpdate = new DelegateData<CapturePointUpdateStateEvent>(40);

		// Token: 0x04000712 RID: 1810
		internal DelegateData<CapturedPointEvent> OnCapturedPoint = new DelegateData<CapturedPointEvent>(40);

		// Token: 0x04000713 RID: 1811
		internal DelegateData<ChatEvent> OnChatReceived = new DelegateData<ChatEvent>(20);

		// Token: 0x04000714 RID: 1812
		internal DelegateData<SelectTeamResponse> OnSelectTeam = new DelegateData<SelectTeamResponse>(30);

		// Token: 0x04000715 RID: 1813
		internal DelegateData<SelectTeamCompletedResponse> OnSelectTeamCompleted = new DelegateData<SelectTeamCompletedResponse>(30);

		// Token: 0x04000716 RID: 1814
		internal DelegateData<TeamQueueChangedEvent> OnTeamQueueChanged = new DelegateData<TeamQueueChangedEvent>(30);

		// Token: 0x04000717 RID: 1815
		internal DelegateData<TeamCallRequest> OnTeamCall = new DelegateData<TeamCallRequest>(30);

		// Token: 0x04000718 RID: 1816
		internal DelegateData<RebalanceCallRequest> OnRebalanceCall = new DelegateData<RebalanceCallRequest>(30);

		// Token: 0x04000719 RID: 1817
		internal DelegateData<PlayerInfoEvent> OnPlayerInfoUpdated = new DelegateData<PlayerInfoEvent>(30);

		// Token: 0x0400071A RID: 1818
		internal DelegateData<ServerTerminationEvent> OnServerTermination = new DelegateData<ServerTerminationEvent>(30);

		// Token: 0x0400071B RID: 1819
		internal DelegateData<ServerCommandEvent> OnServerCommandEvent = new DelegateData<ServerCommandEvent>(30);

		// Token: 0x0400071C RID: 1820
		internal DelegateData<ReadyToSpawnResponse> OnReadyToSpawn = new DelegateData<ReadyToSpawnResponse>(30);

		// Token: 0x0400071D RID: 1821
		internal DelegateData<MapLoadEvent> OnMapLoad = new DelegateData<MapLoadEvent>(30);

		// Token: 0x0400071E RID: 1822
		internal DelegateData<ResupplyEvent> OnResupplyResponse = new DelegateData<ResupplyEvent>(200);

		// Token: 0x0400071F RID: 1823
		internal DelegateData<VoteMapStartEvent> OnVoteStart = new DelegateData<VoteMapStartEvent>(300);

		// Token: 0x04000720 RID: 1824
		internal DelegateData<VoteMapEvent> OnVoteUpdate = new DelegateData<VoteMapEvent>(20);

		// Token: 0x04000721 RID: 1825
		public DelegateData<VoteMapEndEvent> OnVoteEnd = new DelegateData<VoteMapEndEvent>(50);

		// Token: 0x04000722 RID: 1826
		internal DelegateData OnHostRunning = new DelegateData(20);

		// Token: 0x04000723 RID: 1827
		internal DelegateData OnHostInitError = new DelegateData(20);

		// Token: 0x04000724 RID: 1828
		internal DelegateData OnClientConnectionStarted = new DelegateData(20);

		// Token: 0x04000725 RID: 1829
		internal DelegateData OnClientConnectionLost = new DelegateData(20);

		// Token: 0x04000726 RID: 1830
		internal DelegateData OnClientConnectionEstablished = new DelegateData(20);

		// Token: 0x04000727 RID: 1831
		internal DelegateData<LeaveGameMotivation> OnClientConnectionFail = new DelegateData<LeaveGameMotivation>(10);

		// Token: 0x04000728 RID: 1832
		public DelegateData OnClientConnectionClosed = new DelegateData(30);

		// Token: 0x04000729 RID: 1833
		internal DelegateData<NetworkErrorEvent> OnNetworkError = new DelegateData<NetworkErrorEvent>(20);

		// Token: 0x0400072A RID: 1834
		internal DelegateData OnLobbyReady = new DelegateData(20);

		// Token: 0x0400072B RID: 1835
		internal DelegateData OnLobbyEnter = new DelegateData(20);
	}
}
