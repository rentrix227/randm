﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Networking
{
	// Token: 0x020000EE RID: 238
	public class WrapperTimer
	{
		// Token: 0x060004A1 RID: 1185 RVA: 0x00005875 File Offset: 0x00003A75
		public WrapperTimer()
		{
			this._items = new List<WrapperTimer.TimerItem>();
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x00022FC4 File Offset: 0x000211C4
		public void SetInterval(float updateInterval, Action callback)
		{
			WrapperTimer.TimerItem timerItem = new WrapperTimer.TimerItem
			{
				LastUpdate = Time.time,
				UpdateInterval = updateInterval,
				Callback = callback
			};
			this._items.Add(timerItem);
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x00023000 File Offset: 0x00021200
		public void ClearInterval(float updateInterval, Action callback)
		{
			WrapperTimer.TimerItem timerItem = null;
			for (int i = 0; i < this._items.Count; i++)
			{
				if (Math.Abs(this._items[i].UpdateInterval - updateInterval) < Mathf.Epsilon && this._items[i].Callback == callback)
				{
					timerItem = this._items[i];
					break;
				}
			}
			if (timerItem != null)
			{
				this._items.Remove(timerItem);
			}
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00023090 File Offset: 0x00021290
		public void Update()
		{
			if (this._items.Count == 0)
			{
				return;
			}
			for (int i = 0; i < this._items.Count; i++)
			{
				WrapperTimer.TimerItem timerItem = this._items[i];
				float num = Time.time - timerItem.LastUpdate;
				if (num >= timerItem.UpdateInterval)
				{
					timerItem.LastUpdate += timerItem.UpdateInterval;
					if (timerItem.Callback != null)
					{
						timerItem.Callback();
					}
				}
			}
		}

		// Token: 0x0400072F RID: 1839
		private readonly List<WrapperTimer.TimerItem> _items;

		// Token: 0x020000EF RID: 239
		private class TimerItem
		{
			// Token: 0x04000730 RID: 1840
			public float LastUpdate;

			// Token: 0x04000731 RID: 1841
			public float UpdateInterval;

			// Token: 0x04000732 RID: 1842
			public Action Callback;
		}
	}
}
