﻿using System;

namespace Aquiris.Ballistic.Game.Localization
{
	// Token: 0x020000C4 RID: 196
	public enum ELocalizedTextCase : byte
	{
		// Token: 0x040005D2 RID: 1490
		NONE,
		// Token: 0x040005D3 RID: 1491
		UPPER_CASE,
		// Token: 0x040005D4 RID: 1492
		LOWER_CASE,
		// Token: 0x040005D5 RID: 1493
		CAPITALIZE
	}
}
