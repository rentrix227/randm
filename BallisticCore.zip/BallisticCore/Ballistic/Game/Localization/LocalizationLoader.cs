﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Utils;
using Aquiris.Ballistic.Utils.Loader;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Localization
{
	// Token: 0x020000C6 RID: 198
	public class LocalizationLoader
	{
		// Token: 0x06000326 RID: 806 RVA: 0x00004728 File Offset: 0x00002928
		private LocalizationLoader()
		{
			this.LoadAllLanguagesFromWww();
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000327 RID: 807 RVA: 0x0000474C File Offset: 0x0000294C
		public static bool IsActive
		{
			get
			{
				return LocalizationLoader._instance != null;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000328 RID: 808 RVA: 0x00004759 File Offset: 0x00002959
		public static LocalizationLoader Instance
		{
			get
			{
				if (LocalizationLoader._instance == null)
				{
					LocalizationLoader._instance = new LocalizationLoader();
				}
				return LocalizationLoader._instance;
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000329 RID: 809 RVA: 0x00004774 File Offset: 0x00002974
		public Dictionary<string, Dictionary<string, string>> LanguageDictionaries
		{
			get
			{
				return LocalizationLoader._dictionaries;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600032A RID: 810 RVA: 0x0000477B File Offset: 0x0000297B
		public static string LocalizationFilesBasePath
		{
			get
			{
				return "file://" + Application.streamingAssetsPath + "/metadata/_localization/";
			}
		}

		// Token: 0x0600032B RID: 811 RVA: 0x00004791 File Offset: 0x00002991
		private string GetRemotePathToLanguageAsset(string language)
		{
			return LocalizationLoader.LocalizationFilesBasePath + language + ".gz";
		}

		// Token: 0x0600032C RID: 812 RVA: 0x000047A3 File Offset: 0x000029A3
		public bool IsLanguageLoadedFromWww(string language)
		{
			return this._languagesLoadedFromWww.Contains(language);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x000047B1 File Offset: 0x000029B1
		public void LoadLanguageFromWww(string language)
		{
			if (!this._languagesLoadedFromWww.Contains(language) && !this._languagesLoadingFromWww.Contains(language))
			{
				this.TryLoadLanguageFromWww(language);
			}
		}

		// Token: 0x0600032E RID: 814 RVA: 0x0001D434 File Offset: 0x0001B634
		public void LoadAllLanguagesFromWww()
		{
			foreach (string text in LanguageName.All)
			{
				this.LoadLanguageFromWww(text);
			}
		}

		// Token: 0x0600032F RID: 815 RVA: 0x000047DC File Offset: 0x000029DC
		public float GetAllLanguagesWwwLoadingProgress()
		{
			return (float)this._languagesLoadedFromWww.Count / (float)LanguageName.All.Length;
		}

		// Token: 0x06000330 RID: 816 RVA: 0x0001D468 File Offset: 0x0001B668
		private void LoadComplete(CommonLoader commonLoader)
		{
			commonLoader.onComplete = (Action<CommonLoader>)Delegate.Remove(commonLoader.onComplete, new Action<CommonLoader>(this.LoadComplete));
			LocalizationLoader._dictionaries[commonLoader.LoadingReference] = new ByteReader(commonLoader.bytes).ReadDictionary();
			this._languagesLoadedFromWww.Add(commonLoader.LoadingReference);
		}

		// Token: 0x06000331 RID: 817 RVA: 0x0001D4CC File Offset: 0x0001B6CC
		private void TryLoadLanguageFromWww(string language)
		{
			this._languagesLoadingFromWww.Add(language);
			string remotePathToLanguageAsset = this.GetRemotePathToLanguageAsset(language);
			if (remotePathToLanguageAsset.EndsWith(".gz"))
			{
				TextLoader textLoader = new TextLoader(remotePathToLanguageAsset, language);
				textLoader.onComplete = (Action<CommonLoader>)Delegate.Combine(textLoader.onComplete, new Action<CommonLoader>(this.LoadComplete));
				textLoader.Load();
			}
		}

		// Token: 0x040005E5 RID: 1509
		private static LocalizationLoader _instance;

		// Token: 0x040005E6 RID: 1510
		public List<TextAsset> Languages;

		// Token: 0x040005E7 RID: 1511
		private static readonly Dictionary<string, Dictionary<string, string>> _dictionaries = new Dictionary<string, Dictionary<string, string>>();

		// Token: 0x040005E8 RID: 1512
		private readonly HashSet<string> _languagesLoadingFromWww = new HashSet<string>();

		// Token: 0x040005E9 RID: 1513
		private readonly HashSet<string> _languagesLoadedFromWww = new HashSet<string>();
	}
}
