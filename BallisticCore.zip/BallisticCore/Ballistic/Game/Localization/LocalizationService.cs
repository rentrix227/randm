﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Network.Transport.Connection.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Utils;
using Aquiris.DataModel.ItemModel.GameItemModel.EquipableModel.WeaponModel;
using Aquiris.DataModel.ItemModel.GameItemModel.Generator;
using Aquiris.DataModel.ItemModel.GameItemModel.HeroModel;
using Aquiris.DataModel.ProgressionModel;
using Aquiris.Services;
using Aquiris.Services.ItemModel.ConfigItemModel;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Localization
{
	// Token: 0x020000C7 RID: 199
	public class LocalizationService : IService
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000334 RID: 820 RVA: 0x0001D52C File Offset: 0x0001B72C
		// (remove) Token: 0x06000335 RID: 821 RVA: 0x0001D564 File Offset: 0x0001B764
		[field: DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action OnLanguageChange;

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06000336 RID: 822 RVA: 0x000047FF File Offset: 0x000029FF
		private Dictionary<string, string> LanguageDictionary
		{
			get
			{
				return this.GetDictionaryForLanguage(this._language);
			}
		}

		// Token: 0x06000337 RID: 823 RVA: 0x0000480D File Offset: 0x00002A0D
		private Dictionary<string, string> GetDictionaryForLanguage(string language)
		{
			if (LocalizationLoader.Instance.LanguageDictionaries == null)
			{
				return null;
			}
			return (!LocalizationLoader.Instance.LanguageDictionaries.ContainsKey(language)) ? null : LocalizationLoader.Instance.LanguageDictionaries[language];
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000338 RID: 824 RVA: 0x0000484B File Offset: 0x00002A4B
		// (set) Token: 0x06000339 RID: 825 RVA: 0x0001D59C File Offset: 0x0001B79C
		public string CurrentLanguage
		{
			get
			{
				return this._language;
			}
			set
			{
				if (this._language != value)
				{
					string language = this._language;
					this._language = value;
					if (!string.IsNullOrEmpty(value))
					{
						bool flag = LocalizationLoader.Instance.LanguageDictionaries.ContainsKey(this._language);
						if (flag)
						{
							if (this.OnLanguageChange != null)
							{
								this.OnLanguageChange();
							}
							PlayerPrefs.SetString("current_language", value);
							PlayerPrefs.Save();
							return;
						}
						Debug.LogError("Fail to load language");
					}
					this._language = language;
				}
			}
		}

		// Token: 0x0600033A RID: 826 RVA: 0x00004853 File Offset: 0x00002A53
		public bool ContainsKey(string textKey)
		{
			return !string.IsNullOrEmpty(textKey) && this.LanguageDictionary != null && this.LanguageDictionary.ContainsKey(textKey);
		}

		// Token: 0x0600033B RID: 827 RVA: 0x00003043 File Offset: 0x00001243
		public bool IsInitialized()
		{
			return true;
		}

		// Token: 0x0600033C RID: 828 RVA: 0x00004879 File Offset: 0x00002A79
		public List<string> GetLanguages()
		{
			return new List<string>(LocalizationLoader.Instance.LanguageDictionaries.Keys);
		}

		// Token: 0x0600033D RID: 829 RVA: 0x0001D628 File Offset: 0x0001B828
		public List<string> GetValues(string textKey, ELocalizedTextCase localizeTextCase)
		{
			List<string> list = new List<string>();
			foreach (string text in this.GetLanguages())
			{
				list.Add(this.GetTextInCase(LocalizationLoader.Instance.LanguageDictionaries[text][textKey], localizeTextCase));
			}
			return list;
		}

		// Token: 0x0600033E RID: 830 RVA: 0x0001D6A8 File Offset: 0x0001B8A8
		public string Get(string textKey, ELocalizedTextCase localizeTextCase = ELocalizedTextCase.NONE)
		{
			if (!this._initialized)
			{
				this.Preprocess();
			}
			string text = textKey.ToLower();
			if (this.LanguageDictionary != null && this.LanguageDictionary.ContainsKey(text))
			{
				return this.GetTextInCase(this.LanguageDictionary[text], localizeTextCase);
			}
			return this.GetTextInCase(text, localizeTextCase);
		}

		// Token: 0x0600033F RID: 831 RVA: 0x0001D708 File Offset: 0x0001B908
		public string Get(string textKey, ELocalizedTextCase localizeTextCase, string language)
		{
			if (!this._initialized)
			{
				this.Preprocess();
			}
			string text = textKey.ToLower();
			Dictionary<string, string> dictionaryForLanguage = this.GetDictionaryForLanguage(language);
			if (dictionaryForLanguage == null)
			{
				return this.GetTextInCase(text, localizeTextCase);
			}
			if (dictionaryForLanguage.ContainsKey(text))
			{
				return this.GetTextInCase(dictionaryForLanguage[text], localizeTextCase);
			}
			return this.GetTextInCase(text, localizeTextCase);
		}

		// Token: 0x06000340 RID: 832 RVA: 0x0000488F File Offset: 0x00002A8F
		public List<string> GetKeys()
		{
			if (this.LanguageDictionary != null)
			{
				return new List<string>(this.LanguageDictionary.Keys);
			}
			return new List<string>();
		}

		// Token: 0x06000341 RID: 833 RVA: 0x0001D768 File Offset: 0x0001B968
		public string GetTextInCase(string textValue, ELocalizedTextCase localizeTextCase)
		{
			if (localizeTextCase == ELocalizedTextCase.CAPITALIZE)
			{
				return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(textValue.ToLower());
			}
			if (localizeTextCase == ELocalizedTextCase.UPPER_CASE)
			{
				return textValue.ToUpper();
			}
			if (localizeTextCase != ELocalizedTextCase.LOWER_CASE)
			{
				return textValue;
			}
			return textValue.ToLower();
		}

		// Token: 0x06000342 RID: 834 RVA: 0x0001D7B4 File Offset: 0x0001B9B4
		internal override void Preprocess()
		{
			string text = PlayerPrefs.GetString("current_language");
			if (string.IsNullOrEmpty(text))
			{
				text = "en_US";
			}
			this.CurrentLanguage = text;
			this._initialized = true;
		}

		// Token: 0x06000343 RID: 835 RVA: 0x00002A31 File Offset: 0x00000C31
		internal override void Postprocess()
		{
		}

		// Token: 0x06000344 RID: 836 RVA: 0x000048B2 File Offset: 0x00002AB2
		internal string GetMissionDescription(string mission, ELocalizedTextCase localizedTextCase)
		{
			return this.Get("mss_" + mission, localizedTextCase);
		}

		// Token: 0x06000345 RID: 837 RVA: 0x000048C6 File Offset: 0x00002AC6
		internal string GetMapName(ulong gameMap, ELocalizedTextCase localizeTextCase)
		{
			return this.GetMapName(gameMap, localizeTextCase, this.CurrentLanguage);
		}

		// Token: 0x06000346 RID: 838 RVA: 0x000048D6 File Offset: 0x00002AD6
		internal string GetModeName(EGameMode mode, ELocalizedTextCase localizeTextCase)
		{
			return this.GetModeName(mode, localizeTextCase, this.CurrentLanguage);
		}

		// Token: 0x06000347 RID: 839 RVA: 0x0001D7EC File Offset: 0x0001B9EC
		public string GetMapName(ulong gameMap, ELocalizedTextCase localizeTextCase, string Language)
		{
			if (gameMap == GameMapModeConfigService.DefaultAnyMap.MapId)
			{
				return this.Get("map_none", localizeTextCase, Language);
			}
			GameMapConfig gameMapConfig = ServiceProvider.GetService<GameMapModeConfigService>().GetGameMapConfig(gameMap);
			if (gameMapConfig == null)
			{
				return "WorkshopMapID[" + gameMap + "]";
			}
			if (gameMapConfig.MapNameLocalization.ContainsKey(Language))
			{
				return this.GetTextInCase(gameMapConfig.MapNameLocalization[Language], localizeTextCase);
			}
			return this.GetTextInCase(gameMapConfig.MapNameLocalizationDefault, localizeTextCase);
		}

		// Token: 0x06000348 RID: 840 RVA: 0x000048E6 File Offset: 0x00002AE6
		public string GetModeName(EGameMode mode, ELocalizedTextCase localizeTextCase, string Language)
		{
			return this.Get("mode_" + mode.ToString().ToLowerInvariant(), localizeTextCase, Language);
		}

		// Token: 0x06000349 RID: 841 RVA: 0x0000490C File Offset: 0x00002B0C
		internal string GetModeDescription(EGameMode mode, ELocalizedTextCase localizeTextCase)
		{
			return this.Get("mode_" + mode.ToString().ToLowerInvariant() + "_description", localizeTextCase);
		}

		// Token: 0x0600034A RID: 842 RVA: 0x00004936 File Offset: 0x00002B36
		internal string GetWeaponName(string itemName, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			return this.Get("item_name_weapon_" + itemName, textCase);
		}

		// Token: 0x0600034B RID: 843 RVA: 0x0000494A File Offset: 0x00002B4A
		internal string GetWeaponSkinFormat(EWeaponSkinName skinName, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			return this.Get("weaponskin_" + skinName.ToString().ToLowerInvariant(), textCase);
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0000496F File Offset: 0x00002B6F
		internal string GetWeaponSkinName(EWeaponSkinName skinName, ELocalizedTextCase textCase = ELocalizedTextCase.NONE)
		{
			return string.Format(this.GetWeaponSkinFormat(skinName, textCase), string.Empty);
		}

		// Token: 0x0600034D RID: 845 RVA: 0x00004983 File Offset: 0x00002B83
		internal string GetWeaponName(string itemName, EWeaponSkinName skinName, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			if (skinName == EWeaponSkinName.DEFAULT)
			{
				return this.GetWeaponName(itemName, textCase);
			}
			return string.Format(this.GetWeaponSkinFormat(skinName, textCase), this.GetWeaponName(itemName, textCase));
		}

		// Token: 0x0600034E RID: 846 RVA: 0x0001D874 File Offset: 0x0001BA74
		public string GetWeaponName(string itemName, EWeaponSkinName skinName, string language, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			if (skinName == EWeaponSkinName.DEFAULT)
			{
				return this.Get("item_name_weapon_" + itemName, textCase, language);
			}
			return string.Format(this.Get("weaponskin_" + skinName, textCase, language), this.Get("item_name_weapon_" + itemName, textCase, language));
		}

		// Token: 0x0600034F RID: 847 RVA: 0x000049A9 File Offset: 0x00002BA9
		internal string GetWeaponCategory(EWeaponCategory category, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			return this.Get(category.ToString(), textCase);
		}

		// Token: 0x06000350 RID: 848 RVA: 0x000049BF File Offset: 0x00002BBF
		internal string GetClassName(EHeroClass heroClass, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			return this.Get("item_name_hero_" + heroClass, textCase);
		}

		// Token: 0x06000351 RID: 849 RVA: 0x000049D8 File Offset: 0x00002BD8
		internal string GetSkillName(string skill, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			return this.Get(skill, textCase);
		}

		// Token: 0x06000352 RID: 850 RVA: 0x000049E2 File Offset: 0x00002BE2
		internal string GetSkillDescription(string skill, ELocalizedTextCase textCase = ELocalizedTextCase.UPPER_CASE)
		{
			return this.Get(skill + "_description", textCase);
		}

		// Token: 0x06000353 RID: 851 RVA: 0x000049F6 File Offset: 0x00002BF6
		internal string GetPlayerRankName(EPlayerRank rank, ELocalizedTextCase textCase = ELocalizedTextCase.NONE)
		{
			return this.Get("playerrank_" + rank, textCase);
		}

		// Token: 0x06000354 RID: 852 RVA: 0x00004A0F File Offset: 0x00002C0F
		internal string GetTeamName(Team team, ELocalizedTextCase textCase = ELocalizedTextCase.NONE)
		{
			return this.Get("team_" + team.ToString().ToLowerInvariant(), textCase);
		}

		// Token: 0x06000355 RID: 853 RVA: 0x00004A34 File Offset: 0x00002C34
		internal string GetSeasonName(ESeason season, ELocalizedTextCase textCase = ELocalizedTextCase.NONE)
		{
			return this.Get("season_" + season, textCase);
		}

		// Token: 0x06000356 RID: 854 RVA: 0x00004A4D File Offset: 0x00002C4D
		public string GetSeasonName(ESeason season, ELocalizedTextCase textCase, string language)
		{
			return this.Get("season_" + season, textCase, language);
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00004A67 File Offset: 0x00002C67
		internal string GetSeasonIndexName(int seasonIndex)
		{
			return string.Format(this.Get("season_index", ELocalizedTextCase.NONE), seasonIndex);
		}

		// Token: 0x06000358 RID: 856 RVA: 0x00004A80 File Offset: 0x00002C80
		internal string GetSeasonIndexNameAndStartDate(int seasonIndex, int daysElapsed)
		{
			return string.Format(this.Get("season_index_and_date", ELocalizedTextCase.NONE), seasonIndex, daysElapsed);
		}

		// Token: 0x06000359 RID: 857 RVA: 0x0001D8D0 File Offset: 0x0001BAD0
		public string GetLockboxName(EHeroClass heroClass, ESeason season, ELocalizedTextCase textCase, string language)
		{
			switch (season)
			{
			case ESeason.EARLYACCESS:
			case ESeason.FIRSTBLOOD:
			case ESeason.SECONDWAVE:
			case ESeason.THIRDSTRIKE:
			case ESeason.CORE:
				return this.Get("lockbox_" + heroClass.ToString().ToLowerInvariant(), textCase, language);
			case ESeason.LADDER:
				return this.Get("lockbox_golden_" + heroClass.ToString().ToLowerInvariant(), textCase, language);
			}
			return this.Get("lockbox_" + season.ToString().ToLowerInvariant(), textCase, language);
		}

		// Token: 0x0600035A RID: 858 RVA: 0x00004A9F File Offset: 0x00002C9F
		internal string GetLockboxName(EHeroClass heroClass, ESeason season, ELocalizedTextCase textCase = ELocalizedTextCase.NONE)
		{
			return this.GetLockboxName(heroClass, season, textCase, this.CurrentLanguage);
		}

		// Token: 0x0600035B RID: 859 RVA: 0x0001D97C File Offset: 0x0001BB7C
		public string GetLockboxDescription(ESeason season, string content, ELocalizedTextCase textCase, string language)
		{
			if (season != ESeason.LADDER)
			{
				return string.Format(this.Get("lockbox_description", textCase, language), this.GetSeasonName(season, textCase, language), content);
			}
			return string.Format(this.Get("lockbox_gold_description", textCase, language), this.GetSeasonName(season, textCase, language), content);
		}

		// Token: 0x0600035C RID: 860 RVA: 0x00004AB0 File Offset: 0x00002CB0
		internal string GetRarityName(ERarity rarity)
		{
			return this.Get("rarity_" + rarity.ToString().ToLowerInvariant(), ELocalizedTextCase.NONE);
		}

		// Token: 0x0600035D RID: 861 RVA: 0x00004AD5 File Offset: 0x00002CD5
		internal string GetAccessoryName(string accessory)
		{
			return this.Get("acc_" + accessory, ELocalizedTextCase.UPPER_CASE);
		}

		// Token: 0x0600035E RID: 862 RVA: 0x00004AE9 File Offset: 0x00002CE9
		internal string GetAcessoryDescription(string accessory)
		{
			return this.Get("acc_" + accessory + "_description", ELocalizedTextCase.NONE);
		}

		// Token: 0x0600035F RID: 863 RVA: 0x00004B02 File Offset: 0x00002D02
		internal string GetAwardedXpCategoryName(EAwardedXpCategory category)
		{
			return this.Get("xp_type_" + category, ELocalizedTextCase.NONE);
		}

		// Token: 0x06000360 RID: 864 RVA: 0x00004B1B File Offset: 0x00002D1B
		internal string GetAwardedXpWithSuffix(int amount)
		{
			return string.Format(this.Get("amount_and_xp", ELocalizedTextCase.NONE), amount);
		}

		// Token: 0x06000361 RID: 865 RVA: 0x0001D9D4 File Offset: 0x0001BBD4
		internal string GetServerTerminationMessage(ServerTerminationReason reason)
		{
			string text = "server_message_termination_" + reason.ToString().ToLowerInvariant();
			if (!this.ContainsKey(text))
			{
				text = "server_message_termination_none";
			}
			return this.Get(text, ELocalizedTextCase.NONE);
		}

		// Token: 0x040005EA RID: 1514
		private const string PrefsLanguageKey = "current_language";

		// Token: 0x040005EC RID: 1516
		private string _language;

		// Token: 0x040005ED RID: 1517
		private bool _initialized;
	}
}
