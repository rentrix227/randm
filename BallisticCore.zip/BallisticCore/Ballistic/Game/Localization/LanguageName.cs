﻿using System;

namespace Aquiris.Ballistic.Game.Localization
{
	// Token: 0x020000C5 RID: 197
	public class LanguageName
	{
		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000325 RID: 805 RVA: 0x0001D3A0 File Offset: 0x0001B5A0
		public static string[] All
		{
			get
			{
				return new string[]
				{
					"en_US", "pt_BR", "es_MX", "fr_FR", "de_DE", "hr_HR", "tr_TR", "sv_SE", "zn_CH", "it_IT",
					"zh_HK", "ru_RU", "pl_PL", "hu_HU", "fi_FI"
				};
			}
		}

		// Token: 0x040005D6 RID: 1494
		public const string English = "en_US";

		// Token: 0x040005D7 RID: 1495
		public const string PortugueseBrazilian = "pt_BR";

		// Token: 0x040005D8 RID: 1496
		public const string Spanish = "es_MX";

		// Token: 0x040005D9 RID: 1497
		public const string French = "fr_FR";

		// Token: 0x040005DA RID: 1498
		public const string German = "de_DE";

		// Token: 0x040005DB RID: 1499
		public const string Russian = "ru_RU";

		// Token: 0x040005DC RID: 1500
		public const string Croatia = "hr_HR";

		// Token: 0x040005DD RID: 1501
		public const string Turkish = "tr_TR";

		// Token: 0x040005DE RID: 1502
		public const string Swedish = "sv_SE";

		// Token: 0x040005DF RID: 1503
		public const string Italian = "it_IT";

		// Token: 0x040005E0 RID: 1504
		public const string Polish = "pl_PL";

		// Token: 0x040005E1 RID: 1505
		public const string Chinese = "zn_CH";

		// Token: 0x040005E2 RID: 1506
		public const string ChineseTraditional = "zh_HK";

		// Token: 0x040005E3 RID: 1507
		public const string Hungarian = "hu_HU";

		// Token: 0x040005E4 RID: 1508
		public const string Finnish = "fi_FI";
	}
}
