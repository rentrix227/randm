﻿using System;
using Aquiris.Ballistic.Dedicated;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D3 RID: 211
	public class MapScriptMaterialUVOverTime : MonoBehaviour
	{
		// Token: 0x060003A3 RID: 931 RVA: 0x00004DFF File Offset: 0x00002FFF
		public void Awake()
		{
			if (BallisticDedicatedServer.IsRunning)
			{
				Object.Destroy(this);
			}
			this.m_material = base.GetComponent<MeshRenderer>().material;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x0001F180 File Offset: 0x0001D380
		public void Update()
		{
			if (this.MainTex)
			{
				this.m_material.SetTextureOffset("_MainTex", this.UVSpeedMainTex / 100f * Time.time);
			}
			if (this.BumpMap)
			{
				this.m_material.SetTextureOffset("_BumpMap", this.UVSpeedBumpMap / 100f * Time.time);
			}
		}

		// Token: 0x0400065E RID: 1630
		[Tooltip("Percent per Second (1,1) means 1% per second")]
		public bool MainTex;

		// Token: 0x0400065F RID: 1631
		public Vector2 UVSpeedMainTex;

		// Token: 0x04000660 RID: 1632
		public bool BumpMap;

		// Token: 0x04000661 RID: 1633
		public Vector2 UVSpeedBumpMap;

		// Token: 0x04000662 RID: 1634
		private Material m_material;
	}
}
