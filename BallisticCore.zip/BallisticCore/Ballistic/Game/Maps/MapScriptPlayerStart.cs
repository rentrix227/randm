﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D7 RID: 215
	public class MapScriptPlayerStart : MonoBehaviour
	{
		// Token: 0x060003B3 RID: 947 RVA: 0x0001F51C File Offset: 0x0001D71C
		public void OnDrawGizmos()
		{
			Color cyan = Color.cyan;
			cyan.a = 0.4f;
			Gizmos.color = cyan;
			Gizmos.DrawSphere(base.transform.position + 0.4f * Vector3.up, 0.4f);
			Gizmos.DrawLine(base.transform.position, base.transform.position + 1.8f * Vector3.up);
			Gizmos.DrawLine(base.transform.position, base.transform.position + 0.6f * base.transform.forward);
			Gizmos.DrawSphere(base.transform.position + 1.75f * Vector3.up, 0.05f);
			Vector3 vector = base.transform.position + 1.62f * Vector3.up;
			Vector3 vector2 = vector + 0.28f * base.transform.forward;
			Gizmos.DrawSphere(vector2, 0.07f);
			Gizmos.DrawLine(vector, vector2);
		}

		// Token: 0x04000671 RID: 1649
		public const float TotalHeight = 1.8f;

		// Token: 0x04000672 RID: 1650
		public const float EyeHeight = 1.62f;

		// Token: 0x04000673 RID: 1651
		public const float Radius = 0.4f;
	}
}
