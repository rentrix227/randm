﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D8 RID: 216
	public class MapScriptPlaySoundRandomInterval : MonoBehaviour
	{
		// Token: 0x060003B5 RID: 949 RVA: 0x00004E7C File Offset: 0x0000307C
		public void Start()
		{
			this.m_randomInterval = Random.Range(this.Delay + this.MinInterval, this.Delay + this.MaxInterval);
			base.Invoke("PlaySound", this.m_randomInterval);
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x0001F648 File Offset: 0x0001D848
		public void PlaySound()
		{
			if (this.audioSource.isActiveAndEnabled)
			{
				this.audioSource.PlayOneShot(this.audioClip, this.audioSource.volume);
			}
			this.m_randomInterval = Random.Range(this.MinInterval, this.MaxInterval);
			base.Invoke("PlaySound", this.m_randomInterval);
		}

		// Token: 0x04000674 RID: 1652
		public float Delay;

		// Token: 0x04000675 RID: 1653
		public float MinInterval;

		// Token: 0x04000676 RID: 1654
		public float MaxInterval;

		// Token: 0x04000677 RID: 1655
		public AudioSource audioSource;

		// Token: 0x04000678 RID: 1656
		public AudioClip audioClip;

		// Token: 0x04000679 RID: 1657
		private float m_randomInterval;
	}
}
