﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000C9 RID: 201
	public class DestroyTheseWithMe : MonoBehaviour
	{
		// Token: 0x0600036D RID: 877 RVA: 0x00004BA7 File Offset: 0x00002DA7
		public void AddDependency(GameObject p_obj)
		{
			if (this.Dependencies == null)
			{
				this.Dependencies = new List<GameObject>();
			}
			this.Dependencies.Add(p_obj);
		}

		// Token: 0x0600036E RID: 878 RVA: 0x0001DE50 File Offset: 0x0001C050
		public void OnDestroy()
		{
			foreach (GameObject gameObject in this.Dependencies)
			{
				if (gameObject)
				{
					Object.Destroy(gameObject);
				}
			}
		}

		// Token: 0x04000601 RID: 1537
		private List<GameObject> Dependencies;
	}
}
