﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000DA RID: 218
	public class MapScriptSimpleRotation : MonoBehaviour
	{
		// Token: 0x060003BD RID: 957 RVA: 0x00004F0B File Offset: 0x0000310B
		public void Update()
		{
			base.transform.Rotate(this.rotateSpeed * Time.deltaTime);
		}

		// Token: 0x0400067E RID: 1662
		public Vector3 rotateSpeed;
	}
}
