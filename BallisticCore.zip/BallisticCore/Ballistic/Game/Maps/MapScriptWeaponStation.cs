﻿using System;
using Aquiris.Ballistic.Game.ResupplySystem;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000DF RID: 223
	public class MapScriptWeaponStation : MonoBehaviour
	{
		// Token: 0x060003CB RID: 971 RVA: 0x0001F9AC File Offset: 0x0001DBAC
		public void Start()
		{
			if (OfflineInformation.OfflineMode)
			{
				return;
			}
			GameObject gameObject = Object.Instantiate<GameObject>(Resources.Load<GameObject>(this.WeaponConfigName), base.transform, false);
			gameObject.GetComponent<WeaponStation>().Initialize(this.WeaponConfigName);
		}

		// Token: 0x060003CC RID: 972 RVA: 0x0001F9F0 File Offset: 0x0001DBF0
		public void OnDrawGizmos()
		{
			Gizmos.matrix = base.transform.localToWorldMatrix;
			Gizmos.color = new Color(Color.yellow.r * 2f, Color.yellow.g * 2f, Color.yellow.b * 2f, 0.2f);
			Gizmos.DrawCube(base.transform.up * 1f, new Vector3(1f, 2f, 1f));
		}

		// Token: 0x0400068A RID: 1674
		public string WeaponConfigName;
	}
}
