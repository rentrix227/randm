﻿using System;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000DB RID: 219
	public class MapScriptSpawnBlocker : MonoBehaviour
	{
		// Token: 0x060003BF RID: 959 RVA: 0x0001F728 File Offset: 0x0001D928
		public void Start()
		{
			if (OfflineInformation.OfflineMode)
			{
				return;
			}
			GameObject gameObject = Object.Instantiate<GameObject>(Resources.Load<GameObject>("spawn_blocker"), base.transform, false);
			gameObject.transform.localScale = Vector3.one;
			gameObject.transform.localPosition = Vector3.zero;
			gameObject.transform.localRotation = Quaternion.identity;
			gameObject.GetComponent<SpawnBlocker>().Initialize(this.team);
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x0001F798 File Offset: 0x0001D998
		public void OnDrawGizmos()
		{
			Gizmos.color = Color.blue;
			Gizmos.matrix = base.transform.localToWorldMatrix;
			Gizmos.DrawCube(new Vector3(0f, 1.25f, 0f), new Vector3(2.2f, 2.5f, 0.25f));
		}

		// Token: 0x0400067F RID: 1663
		public Team team;
	}
}
