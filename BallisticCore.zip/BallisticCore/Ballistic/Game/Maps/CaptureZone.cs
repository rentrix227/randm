﻿using System;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.UI;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000C8 RID: 200
	[RequireComponent(typeof(Rigidbody))]
	public class CaptureZone : TriangulatedArea
	{
		// Token: 0x06000363 RID: 867 RVA: 0x0001DA18 File Offset: 0x0001BC18
		public void Awake()
		{
			if (!Application.isPlaying)
			{
				return;
			}
			if (string.IsNullOrEmpty(this.LocationId))
			{
				base.enabled = false;
				Object.Destroy(base.gameObject);
				return;
			}
			CaptureZone._playerLayer = LayerMask.NameToLayer("FPSPlayer");
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			if (this._gameModeService.GameMode != this.GameMode)
			{
				Object.Destroy(base.gameObject);
				return;
			}
			this._capturePointMode = this._gameModeService.CustomGameMode as ModeCapturePoint;
			if (this._capturePointMode == null)
			{
				Object.Destroy(base.gameObject);
				return;
			}
			MeshRenderer component = base.GetComponent<MeshRenderer>();
			if (component)
			{
				this._renderer = new Renderer[] { component };
			}
			else
			{
				this._renderer = this.EnvironmentIndication.GetComponentsInChildren<Renderer>(true);
			}
			this._capturing = false;
			this._lastCaptureUpdate = 0f;
			this._capturePointMode.AddCaptureZone(this);
			this._propertyBlue = Shader.PropertyToID("_Blue");
			this._propertyRed = Shader.PropertyToID("_Red");
			this._targetToBlue = 0f;
			this._targetToRed = 0f;
			this._isEnabled = true;
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0001DB50 File Offset: 0x0001BD50
		public void Update()
		{
			if (!Application.isPlaying)
			{
				return;
			}
			if (this._renderer.Length > 0)
			{
				this._slidingToBlue = Mathf.MoveTowards(this._slidingToBlue, this._targetToBlue, 2f * Time.deltaTime);
				this._slidingToRed = Mathf.MoveTowards(this._slidingToRed, this._targetToRed, 2f * Time.deltaTime);
				this.UpdateCaptureZoneColors();
			}
			if (!this._capturing)
			{
				return;
			}
			if (Time.time - this._lastCaptureUpdate <= 0.5f)
			{
				return;
			}
			this._capturePointMode.StopZoneCapture(this.LocationId);
			this._capturing = false;
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0001DBFC File Offset: 0x0001BDFC
		public void OnTriggerStay(Collider collider)
		{
			if (!Application.isPlaying)
			{
				return;
			}
			if (!this._isEnabled)
			{
				return;
			}
			if (collider.gameObject.layer != CaptureZone._playerLayer)
			{
				return;
			}
			if (this._gameModeService.State != GameModeState.Ready)
			{
				return;
			}
			if (!UserProfile.LocalGameClient.spawned)
			{
				return;
			}
			if (this._capturePointMode == null)
			{
				return;
			}
			if (this._gameModeService.State != GameModeState.Ready)
			{
				return;
			}
			this._lastCaptureUpdate = Time.time;
			if (this._capturing)
			{
				return;
			}
			this._capturePointMode.StartZoneCapture(this.LocationId);
			this._capturing = true;
		}

		// Token: 0x06000366 RID: 870 RVA: 0x00004B43 File Offset: 0x00002D43
		public void OnDestroy()
		{
			if (!Application.isPlaying)
			{
				return;
			}
			if (this.EnvironmentIndication != null)
			{
				Object.Destroy(this.EnvironmentIndication);
			}
		}

		// Token: 0x06000367 RID: 871 RVA: 0x0001DCA8 File Offset: 0x0001BEA8
		public void OnValidate()
		{
			if (Application.isPlaying)
			{
				return;
			}
			int num = LayerMask.NameToLayer("CapturePoint");
			base.GetComponent<Rigidbody>().isKinematic = true;
			base.GetComponent<Rigidbody>().useGravity = false;
			CaptureZone.RecursiveValidation(base.gameObject, num);
		}

		// Token: 0x06000368 RID: 872 RVA: 0x0001DCF0 File Offset: 0x0001BEF0
		private static void RecursiveValidation(GameObject obj, int layer)
		{
			obj.layer = layer;
			Collider component = obj.GetComponent<Collider>();
			if (component != null)
			{
				component.isTrigger = true;
				MeshCollider meshCollider = component as MeshCollider;
				if (meshCollider != null)
				{
					meshCollider.convex = true;
				}
			}
			for (int i = 0; i < obj.transform.childCount; i++)
			{
				CaptureZone.RecursiveValidation(obj.transform.GetChild(i).gameObject, layer);
			}
		}

		// Token: 0x06000369 RID: 873 RVA: 0x00004B6C File Offset: 0x00002D6C
		internal void UpdateZone(PointInfo info)
		{
			if (string.IsNullOrEmpty(info.PointName) || !string.Equals(this.LocationId, info.PointName))
			{
				return;
			}
			this.UpdateOwner(UIEnums.GetRelativeTeam((Team)info.CurrentTeamOwner));
		}

		// Token: 0x0600036A RID: 874 RVA: 0x0001DD6C File Offset: 0x0001BF6C
		private void UpdateOwner(UITeam owner)
		{
			if (owner == this._owner)
			{
				return;
			}
			this._owner = owner;
			this._targetToRed = 0f;
			this._targetToBlue = 0f;
			if (this._owner == UITeam.Mine)
			{
				this._targetToBlue = 1f;
			}
			else if (this._owner == UITeam.Other)
			{
				this._targetToRed = 1f;
			}
		}

		// Token: 0x0600036B RID: 875 RVA: 0x0001DDD8 File Offset: 0x0001BFD8
		private void UpdateCaptureZoneColors()
		{
			foreach (Renderer renderer2 in this._renderer)
			{
				foreach (Material material in renderer2.materials)
				{
					material.SetFloat(this._propertyBlue, this._slidingToBlue);
					material.SetFloat(this._propertyRed, this._slidingToRed);
				}
			}
		}

		// Token: 0x040005EE RID: 1518
		public string LocationId;

		// Token: 0x040005EF RID: 1519
		public EGameMode GameMode = EGameMode.Conquest;

		// Token: 0x040005F0 RID: 1520
		public GameObject EnvironmentIndication;

		// Token: 0x040005F1 RID: 1521
		private GameModeService _gameModeService;

		// Token: 0x040005F2 RID: 1522
		private const float _captureDelay = 0.5f;

		// Token: 0x040005F3 RID: 1523
		private const float _colorChangeSpeed = 2f;

		// Token: 0x040005F4 RID: 1524
		private int _propertyBlue;

		// Token: 0x040005F5 RID: 1525
		private int _propertyRed;

		// Token: 0x040005F6 RID: 1526
		private float _targetToBlue;

		// Token: 0x040005F7 RID: 1527
		private float _targetToRed;

		// Token: 0x040005F8 RID: 1528
		private float _slidingToBlue;

		// Token: 0x040005F9 RID: 1529
		private float _slidingToRed;

		// Token: 0x040005FA RID: 1530
		private Renderer[] _renderer;

		// Token: 0x040005FB RID: 1531
		private UITeam _owner;

		// Token: 0x040005FC RID: 1532
		private bool _capturing;

		// Token: 0x040005FD RID: 1533
		private float _lastCaptureUpdate;

		// Token: 0x040005FE RID: 1534
		private bool _isEnabled;

		// Token: 0x040005FF RID: 1535
		private ModeCapturePoint _capturePointMode;

		// Token: 0x04000600 RID: 1536
		private static int _playerLayer;
	}
}
