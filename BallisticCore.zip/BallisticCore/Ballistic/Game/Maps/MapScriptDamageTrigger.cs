﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Networking.Events;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Events;
using Aquiris.Ballistic.Network.Transport.Gameplay.Player.Requests;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000CF RID: 207
	public class MapScriptDamageTrigger : MonoBehaviour
	{
		// Token: 0x06000383 RID: 899 RVA: 0x0001E6FC File Offset: 0x0001C8FC
		public void Start()
		{
			this._playerLayer = LayerMask.NameToLayer("FPSPlayer");
			base.gameObject.layer = LayerMask.NameToLayer("CapturePoint");
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			ServiceProvider.GetService<NetworkGameService>().OnDie.AddListener(new Action<DieEvent>(this.OnDie));
		}

		// Token: 0x06000384 RID: 900 RVA: 0x00004C89 File Offset: 0x00002E89
		public void OnDestroy()
		{
			ServiceProvider.GetService<NetworkGameService>().OnDie.RemoveListener(new Action<DieEvent>(this.OnDie));
		}

		// Token: 0x06000385 RID: 901 RVA: 0x00004CA6 File Offset: 0x00002EA6
		public void OnEnable()
		{
			this.m_isColliding = false;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x00004CA6 File Offset: 0x00002EA6
		public void OnDisable()
		{
			this.m_isColliding = false;
		}

		// Token: 0x06000387 RID: 903 RVA: 0x00004CAF File Offset: 0x00002EAF
		private void OnDie(DieEvent dieEvent)
		{
			if (dieEvent.Sender.isMe)
			{
				this.m_isColliding = false;
			}
		}

		// Token: 0x06000388 RID: 904 RVA: 0x0001E754 File Offset: 0x0001C954
		private void Damage()
		{
			if (OfflineInformation.OfflineMode)
			{
				Debug.LogWarning("[DamageTrigger] Player taking " + this.DamageToInflictEachTime + " damage");
			}
			else
			{
				PlayerHitRequest playerHitRequest = new PlayerHitRequest
				{
					BodyPartHit = 0,
					Damage = (double)this.DamageToInflictEachTime,
					ShooterPosition = new List<double>(3) { 0.0, 0.0, 0.0 },
					UserBeingHitId = UserProfile.LocalGameClient.gameClientId,
					VictimPosition = new List<double>(3) { 0.0, 0.0, 0.0 },
					WeaponId = -1,
					DamageType = this.DamageType,
					ShotsFired = 0,
					Team = (sbyte)UserProfile.LocalGameClient.team
				};
				ServiceProvider.GetService<NetworkGameService>().RaiseNetworkEvent(playerHitRequest);
			}
		}

		// Token: 0x06000389 RID: 905 RVA: 0x00004CC8 File Offset: 0x00002EC8
		public void OnTriggerEnter(Collider collider)
		{
			if (collider.gameObject.layer != this._playerLayer)
			{
				return;
			}
			if (this._gameModeService.State != GameModeState.Ready)
			{
				return;
			}
			this.m_lastTime = Time.time;
			this.m_isColliding = true;
		}

		// Token: 0x0600038A RID: 906 RVA: 0x00004D05 File Offset: 0x00002F05
		public void OnTriggerExit(Collider collider)
		{
			if (collider.gameObject.layer != this._playerLayer)
			{
				return;
			}
			if (this._gameModeService.State != GameModeState.Ready)
			{
				return;
			}
			this.m_isColliding = false;
		}

		// Token: 0x0600038B RID: 907 RVA: 0x0001E868 File Offset: 0x0001CA68
		public void Update()
		{
			if (UserProfile.LocalGameClient == null)
			{
				return;
			}
			if (UserProfile.LocalGameClient.ClientCommonMetaData.CurrentState != EPlayerState.ALIVE && UserProfile.LocalGameClient.ClientCommonMetaData.CurrentState != EPlayerState.LAST_STAND)
			{
				this.m_isColliding = false;
			}
			if (this.m_isColliding)
			{
				float num = Time.time - this.m_lastTime;
				this.m_lastTime = Time.time;
				this.m_timeSinceDamage += num;
				while (this.m_timeSinceDamage > this.TimeBetweenDamages)
				{
					this.Damage();
					this.m_timeSinceDamage -= this.TimeBetweenDamages;
				}
			}
		}

		// Token: 0x04000635 RID: 1589
		private int _playerLayer;

		// Token: 0x04000636 RID: 1590
		public float TimeBetweenDamages = 0.1f;

		// Token: 0x04000637 RID: 1591
		public float DamageToInflictEachTime;

		// Token: 0x04000638 RID: 1592
		public EDamageType DamageType;

		// Token: 0x04000639 RID: 1593
		private GameModeService _gameModeService;

		// Token: 0x0400063A RID: 1594
		private bool m_isColliding;

		// Token: 0x0400063B RID: 1595
		private float m_lastTime = -1f;

		// Token: 0x0400063C RID: 1596
		private float m_timeSinceDamage;
	}
}
