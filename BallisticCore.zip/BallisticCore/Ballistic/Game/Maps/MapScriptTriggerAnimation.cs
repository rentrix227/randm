﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000DC RID: 220
	public class MapScriptTriggerAnimation : MonoBehaviour
	{
		// Token: 0x060003C2 RID: 962 RVA: 0x0001F7EC File Offset: 0x0001D9EC
		public void Awake()
		{
			if (this.Target == null)
			{
				Debug.LogWarning(string.Format("[TriggerActivatedAnimation ({0}] Invalid target. Removing myself...", base.gameObject.name));
				Object.Destroy(this);
				return;
			}
			if (string.IsNullOrEmpty(this.TargetAnimationName))
			{
				this.TargetAnimationName = this.Target.name;
			}
			this.m_targetState = this.Target[this.TargetAnimationName];
			if (this.m_targetState == null)
			{
				Debug.LogWarning(string.Format("[TriggerActivatedAnimation ({0}] Invalid target animation({1}). Removing myself...", base.gameObject.name, this.TargetAnimationName));
				Object.Destroy(this);
				return;
			}
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x00004F28 File Offset: 0x00003128
		public void OnTriggerEnter(Collider p_other)
		{
			if (p_other.tag == "fpsPlayer")
			{
				this.m_targetState.wrapMode = 2;
				this.Target.Play(this.m_targetState.name);
			}
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0001F89C File Offset: 0x0001DA9C
		public void OnTriggerExit(Collider p_other)
		{
			if (p_other.tag == "fpsPlayer")
			{
				this.m_targetState.normalizedTime = Mathf.Repeat(this.m_targetState.normalizedTime, 1f);
				this.m_targetState.wrapMode = 1;
			}
		}

		// Token: 0x04000680 RID: 1664
		public Animation Target;

		// Token: 0x04000681 RID: 1665
		public string TargetAnimationName;

		// Token: 0x04000682 RID: 1666
		private AnimationState m_targetState;
	}
}
