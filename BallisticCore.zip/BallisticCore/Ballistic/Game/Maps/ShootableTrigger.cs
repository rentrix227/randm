﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000E0 RID: 224
	[RequireComponent(typeof(Collider))]
	public class ShootableTrigger : MonoBehaviour
	{
		// Token: 0x060003CE RID: 974 RVA: 0x00004F7D File Offset: 0x0000317D
		public void WasShot()
		{
			if (this.OnShot != null)
			{
				this.OnShot();
			}
		}

		// Token: 0x0400068B RID: 1675
		public Action OnShot;
	}
}
