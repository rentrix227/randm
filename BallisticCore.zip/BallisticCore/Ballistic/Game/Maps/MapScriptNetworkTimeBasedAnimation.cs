﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Utility;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.State.Events;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D5 RID: 213
	public class MapScriptNetworkTimeBasedAnimation : MonoBehaviour
	{
		// Token: 0x060003A9 RID: 937 RVA: 0x0001F2D4 File Offset: 0x0001D4D4
		public void Awake()
		{
			if ((this.m_animation = base.GetComponent<Animation>()) == null)
			{
				Object.Destroy(this);
				return;
			}
			if (string.IsNullOrEmpty(this.TargetAnimationName))
			{
				this.TargetAnimationName = this.m_animation.clip.name;
			}
			this.m_state = this.m_animation[this.TargetAnimationName];
			if (this.m_state == null)
			{
				Object.Destroy(this);
				return;
			}
			this.m_timeFilter = new TimeBasedFilter(0.8f, false);
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._networkGameService.OnChangeState.AddListener(new Action<ChangeGameStateEvent>(this.OnChangeState));
			this._networkGameService.OnClientConnectionClosed.AddListener(new Action(this.OnClientConnectionClosed));
			this._isMatchRunning = true;
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00004E31 File Offset: 0x00003031
		private void OnChangeState(ChangeGameStateEvent evt)
		{
			if (evt.GameStateType != EGameState.ENDING && evt.GameStateType != EGameState.MAP_VOTING)
			{
				return;
			}
			this.SetMatchEnded();
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00004E52 File Offset: 0x00003052
		private void OnClientConnectionClosed()
		{
			this.SetMatchEnded();
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0001F3B4 File Offset: 0x0001D5B4
		private void SetMatchEnded()
		{
			this._networkGameService.OnChangeState.RemoveListener(new Action<ChangeGameStateEvent>(this.OnChangeState));
			this._networkGameService.OnClientConnectionClosed.RemoveListener(new Action(this.OnClientConnectionClosed));
			this._isMatchRunning = false;
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0001F400 File Offset: 0x0001D600
		public void Update()
		{
			if (!OfflineInformation.OfflineMode)
			{
				float num = ((!this._isMatchRunning) ? (this._lastMatchTime + Time.deltaTime) : (0.001f * this._networkGameService.MatchTimestamp));
				this._lastMatchTime = num;
				if (this.ForcePlay)
				{
					this.m_animation.Play(this.TargetAnimationName);
				}
				this.m_timeFilter.Add(num);
				this.m_state.time = Mathf.Repeat(this.m_timeFilter.Get(), 2f * this.m_state.length);
			}
		}

		// Token: 0x04000665 RID: 1637
		public string TargetAnimationName;

		// Token: 0x04000666 RID: 1638
		public bool ForcePlay = true;

		// Token: 0x04000667 RID: 1639
		private AnimationState m_state;

		// Token: 0x04000668 RID: 1640
		private TimeBasedFilter m_timeFilter;

		// Token: 0x04000669 RID: 1641
		private Animation m_animation;

		// Token: 0x0400066A RID: 1642
		private float _lastMatchTime;

		// Token: 0x0400066B RID: 1643
		private NetworkGameService _networkGameService;

		// Token: 0x0400066C RID: 1644
		private bool _isMatchRunning;
	}
}
