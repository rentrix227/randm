﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D6 RID: 214
	public class MapScriptPlayAudioTrigger : MonoBehaviour
	{
		// Token: 0x060003AF RID: 943 RVA: 0x00004E5A File Offset: 0x0000305A
		public void Awake()
		{
			this.m_audio = base.GetComponent<AudioSource>();
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00004E68 File Offset: 0x00003068
		public void OnTriggerStay(Collider p_collider)
		{
			this.stillIn = true;
			this.verificationTimer = 0f;
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x0001F4A4 File Offset: 0x0001D6A4
		public void Update()
		{
			if (this.stillIn)
			{
				if (!this.played)
				{
					this.m_audio.Play();
					this.played = true;
				}
				this.verificationTimer += Time.deltaTime;
				if (this.verificationTimer > 0.1f)
				{
					this.verificationTimer = 0f;
					this.stillIn = false;
				}
			}
			else
			{
				this.played = false;
			}
		}

		// Token: 0x0400066D RID: 1645
		private bool played;

		// Token: 0x0400066E RID: 1646
		private bool stillIn;

		// Token: 0x0400066F RID: 1647
		private float verificationTimer;

		// Token: 0x04000670 RID: 1648
		private AudioSource m_audio;
	}
}
