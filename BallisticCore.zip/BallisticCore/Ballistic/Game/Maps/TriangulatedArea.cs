﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000E3 RID: 227
	[ExecuteInEditMode]
	[RequireComponent(typeof(MeshFilter))]
	[RequireComponent(typeof(MeshRenderer))]
	[RequireComponent(typeof(MeshCollider))]
	public class TriangulatedArea : MonoBehaviour
	{
		// Token: 0x060003DA RID: 986 RVA: 0x0002045C File Offset: 0x0001E65C
		public void OnEnable()
		{
			if (this.Points.Length < 3)
			{
				return;
			}
			if (this._mesh == null)
			{
				this._mesh = new Mesh();
				this._mesh.name = "CaptureZoneMesh";
				this._mesh.hideFlags = 52;
			}
			this.Triangulate(this.Points, this._mesh);
			MeshFilter component = base.GetComponent<MeshFilter>();
			if (component)
			{
				component.mesh = this._mesh;
			}
			MeshRenderer component2 = base.GetComponent<MeshRenderer>();
			if (component2)
			{
				component2.sharedMaterials = new Material[]
				{
					Resources.Load<Material>("cp_floor_material"),
					Resources.Load<Material>("cp_wall_material")
				};
			}
			MeshCollider component3 = base.GetComponent<MeshCollider>();
			if (component3)
			{
				component3.sharedMesh = this._mesh;
			}
		}

		// Token: 0x060003DB RID: 987 RVA: 0x00020538 File Offset: 0x0001E738
		public void OnDisable()
		{
			MeshFilter component = base.GetComponent<MeshFilter>();
			if (component)
			{
				component.mesh = null;
			}
			MeshCollider component2 = base.GetComponent<MeshCollider>();
			if (component2)
			{
				component2.sharedMesh = null;
			}
			if (this._mesh != null)
			{
				this._mesh = null;
			}
		}

		// Token: 0x060003DC RID: 988 RVA: 0x00020590 File Offset: 0x0001E790
		private void Triangulate(Vector3[] points, Mesh _mesh)
		{
			Vector3 vector = this.GetMedian(points);
			List<Vector3> list = new List<Vector3>();
			list.Add(vector);
			list.AddRange(points);
			List<Vector2> list2 = new List<Vector2>(list.Select((Vector3 t) => new Vector2(t.x, t.z)));
			List<int> list3 = new List<int>();
			for (int i = 0; i < points.Length; i++)
			{
				list3.Add(0);
				list3.Add(this.Mod(i, points.Length, 1));
				list3.Add(this.Mod(i + 1, points.Length, 1));
			}
			int count = list.Count;
			for (int j = 0; j < points.Length; j++)
			{
				list.Add(points[j]);
				list2.Add(new Vector2(this.DistanceUntil(j, points), 0f));
			}
			list.Add(points[0]);
			list2.Add(new Vector2(this.DistanceUntil(points.Length, points), 0f));
			for (int k = 0; k < points.Length; k++)
			{
				list.Add(points[k] + Vector3.up);
				list2.Add(new Vector2(this.DistanceUntil(k, points), 1f));
			}
			list.Add(points[0] + Vector3.up);
			list2.Add(new Vector2(this.DistanceUntil(points.Length, points), 1f));
			List<int> list4 = new List<int>();
			int num = points.Length + 1;
			for (int l = 0; l < points.Length; l++)
			{
				list4.Add(this.Mod(l, num, points.Length + 1));
				list4.Add(this.Mod(l + 1, num, points.Length + 1));
				list4.Add(this.Mod(l, num, points.Length + num + 1));
				list4.Add(this.Mod(l, num, points.Length + num + 1));
				list4.Add(this.Mod(l + 1, num, points.Length + 1));
				list4.Add(this.Mod(l + 1, num, points.Length + num + 1));
			}
			_mesh.subMeshCount = 2;
			_mesh.SetVertices(list);
			_mesh.SetUVs(0, list2);
			_mesh.SetTriangles(list3, 0, true);
			_mesh.SetTriangles(list4, 1, true);
			_mesh.RecalculateNormals();
		}

		// Token: 0x060003DD RID: 989 RVA: 0x00020818 File Offset: 0x0001EA18
		private float DistanceUntil(int index, Vector3[] points)
		{
			float num = 0f;
			for (int i = 0; i < index; i++)
			{
				num += Vector3.Distance(points[this.Mod(i, points.Length, 0)], points[this.Mod(i + 1, points.Length, 0)]);
			}
			return num;
		}

		// Token: 0x060003DE RID: 990 RVA: 0x00020874 File Offset: 0x0001EA74
		private Vector2 GetMedian(Vector3[] points)
		{
			Vector3 vector = Vector2.zero;
			for (int i = 0; i < points.Length; i++)
			{
				vector += points[i];
			}
			vector /= (float)points.Length;
			return vector;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x00004FC6 File Offset: 0x000031C6
		private int Mod(int i, int mod, int offset = 0)
		{
			return i % mod + offset;
		}

		// Token: 0x0400069C RID: 1692
		public Vector3[] Points = new Vector3[0];

		// Token: 0x0400069D RID: 1693
		private Mesh _mesh;
	}
}
