﻿using System;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D0 RID: 208
	[RequireComponent(typeof(AudioSource))]
	[ExecuteInEditMode]
	public class MapScriptDisableAudioByDistance : MonoBehaviour
	{
		// Token: 0x17000061 RID: 97
		// (get) Token: 0x0600038D RID: 909 RVA: 0x0001E914 File Offset: 0x0001CB14
		private Transform Listener
		{
			get
			{
				if (this._localCharacterService != null && this._localCharacterService.FXCamera != null && (!this._localCharacterService.IsDead || Time.time - this._localCharacterService.IsDeadTimestamp < 2f))
				{
					return this._localCharacterService.FXCamera.transform;
				}
				if (this._cameraService != null && UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER)
				{
					return this._cameraService.GetCurrentCameraTransform();
				}
				if (this._spectatorService != null && UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR)
				{
					return this._spectatorService.GetCurrentCameraTransform();
				}
				return null;
			}
		}

		// Token: 0x0600038E RID: 910 RVA: 0x0001E9CC File Offset: 0x0001CBCC
		public void Start()
		{
			this._audioSource = base.GetComponent<AudioSource>();
			if (this._audioSource == null)
			{
				Object.Destroy(this);
				return;
			}
			this.MaxDistance = this._audioSource.maxDistance;
			if (!Application.isPlaying)
			{
				return;
			}
			this._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
			this._cameraService = ServiceProvider.GetService<CameraService>();
			this._spectatorService = ServiceProvider.GetService<SpectatorService>();
			this._audioSource.outputAudioMixerGroup = ServiceProvider.GetService<MusicService>().GetMixerGroup("Master/MasterSFX/Ambient");
		}

		// Token: 0x0600038F RID: 911 RVA: 0x0001EA54 File Offset: 0x0001CC54
		public void Update()
		{
			if (!Application.isPlaying)
			{
				return;
			}
			this._listener = this.Listener;
			if (this._listener != null)
			{
				float num = Vector3.SqrMagnitude(this.Listener.transform.position - base.transform.position);
				this._audioSource.enabled = num <= this.MaxDistance * this.MaxDistance;
				if (this._audioSource.enabled && this._audioSource.playOnAwake && !this._audioSource.isPlaying && this.PlayOnAwake)
				{
					this._audioSource.Play();
				}
			}
		}

		// Token: 0x0400063D RID: 1597
		public float MaxDistance;

		// Token: 0x0400063E RID: 1598
		public bool PlayOnAwake = true;

		// Token: 0x0400063F RID: 1599
		private AudioSource _audioSource;

		// Token: 0x04000640 RID: 1600
		private LocalCharacterService _localCharacterService;

		// Token: 0x04000641 RID: 1601
		private Transform _listener;

		// Token: 0x04000642 RID: 1602
		private CameraService _cameraService;

		// Token: 0x04000643 RID: 1603
		private SpectatorService _spectatorService;
	}
}
