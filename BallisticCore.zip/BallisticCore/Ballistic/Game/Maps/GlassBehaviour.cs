﻿using System;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000CA RID: 202
	public class GlassBehaviour : MonoBehaviour
	{
		// Token: 0x06000370 RID: 880 RVA: 0x00004BDA File Offset: 0x00002DDA
		public void Awake()
		{
			this.m_shotsTaken = 0;
			this.m_currentState = GlassBehaviour.GlassState.Normal;
			this.m_valueToShatter = 1;
			this.m_valueToBreak = Random.Range(2, 4);
			this.m_thisRenderer = base.GetComponentInChildren<Renderer>();
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00004C0A File Offset: 0x00002E0A
		public void Start()
		{
			if (base.transform.childCount > 0)
			{
				this.m_ParticleEmitter = base.transform.GetChild(0).gameObject;
			}
		}

		// Token: 0x06000372 RID: 882 RVA: 0x00004C34 File Offset: 0x00002E34
		public GlassBehaviour.GlassState GetCurrentState()
		{
			return this.m_currentState;
		}

		// Token: 0x06000373 RID: 883 RVA: 0x0001DEB8 File Offset: 0x0001C0B8
		public void TakeHit(RaycastHit p_hitInfo, bool p_isFirstPerson)
		{
			this.m_shotsTaken++;
			if (this.m_currentState == GlassBehaviour.GlassState.Broken)
			{
				return;
			}
			ServiceProvider.GetService<TransmissionService>().OnBulletHit.Dispatch(new OnBulletHitData
			{
				IsFirstPerson = p_isFirstPerson,
				HitCollider = p_hitInfo.collider,
				HitPoint = p_hitInfo.point,
				HitNormal = p_hitInfo.normal,
				WeaponDecalSize = 0.2f
			});
			if (this.m_shotsTaken < this.m_valueToShatter)
			{
				return;
			}
			if (this.m_currentState == GlassBehaviour.GlassState.Normal)
			{
				this.m_currentState = GlassBehaviour.GlassState.Shattered;
				this.ShatterGlass();
			}
			else if (this.m_shotsTaken == this.m_valueToBreak)
			{
				this.m_currentState = GlassBehaviour.GlassState.Broken;
				this.BreakGlass(p_isFirstPerson);
			}
		}

		// Token: 0x06000374 RID: 884 RVA: 0x0001DF84 File Offset: 0x0001C184
		public void TakeExplosion(bool isFirstPerson)
		{
			if (this.m_currentState == GlassBehaviour.GlassState.Broken)
			{
				return;
			}
			if (this.BreaksOnFirstExplosion)
			{
				this.m_currentState = GlassBehaviour.GlassState.Broken;
				this.BreakGlass(isFirstPerson);
			}
			else if (this.m_currentState == GlassBehaviour.GlassState.Normal)
			{
				this.m_currentState = GlassBehaviour.GlassState.Shattered;
				this.ShatterGlass();
			}
			else
			{
				this.m_currentState = GlassBehaviour.GlassState.Broken;
				this.BreakGlass(isFirstPerson);
			}
		}

		// Token: 0x06000375 RID: 885 RVA: 0x0001DFE8 File Offset: 0x0001C1E8
		private void ShatterGlass()
		{
			if (this.ShatteredMaterial != null)
			{
				this.m_thisRenderer.material = this.ShatteredMaterial;
			}
			ServiceProvider.GetService<TransmissionService>().OnGlassShatter.Dispatch(new OnGlassShatter
			{
				Position = base.transform.position
			});
		}

		// Token: 0x06000376 RID: 886 RVA: 0x0001E044 File Offset: 0x0001C244
		private void BreakGlass(bool isFirstPerson)
		{
			ServiceProvider.GetService<TransmissionService>().OnGlassBreak.Dispatch(new OnGlassBreak
			{
				Position = base.transform.position
			});
			base.GetComponent<Collider>().enabled = false;
			DestroyTheseWithMe component = base.GetComponent<DestroyTheseWithMe>();
			if (component)
			{
				component.SendMessage("OnDestroy");
			}
			if (this.GlassParticles != null)
			{
				this.GlassParticles.Play();
			}
			if (this.BrokenMaterial != null)
			{
				this.m_thisRenderer.material = this.BrokenMaterial;
			}
			if (this.m_ParticleEmitter != null)
			{
				this.m_ParticleEmitter.SetActive(true);
			}
			if (this.OnBreak != null)
			{
				this.OnBreak(isFirstPerson);
			}
		}

		// Token: 0x04000602 RID: 1538
		public ParticleSystem GlassParticles;

		// Token: 0x04000603 RID: 1539
		public Material ShatteredMaterial;

		// Token: 0x04000604 RID: 1540
		public Material BrokenMaterial;

		// Token: 0x04000605 RID: 1541
		public int MinValueToShatter;

		// Token: 0x04000606 RID: 1542
		public int MaxValueToShatter;

		// Token: 0x04000607 RID: 1543
		public int MinValueToBreak;

		// Token: 0x04000608 RID: 1544
		public int MaxValueToBreak;

		// Token: 0x04000609 RID: 1545
		public bool BreaksOnFirstExplosion = true;

		// Token: 0x0400060A RID: 1546
		public Action<bool> OnBreak;

		// Token: 0x0400060B RID: 1547
		private int m_valueToShatter;

		// Token: 0x0400060C RID: 1548
		private int m_valueToBreak;

		// Token: 0x0400060D RID: 1549
		private int m_shotsTaken;

		// Token: 0x0400060E RID: 1550
		private GlassBehaviour.GlassState m_currentState;

		// Token: 0x0400060F RID: 1551
		private Renderer m_thisRenderer;

		// Token: 0x04000610 RID: 1552
		private GameObject m_ParticleEmitter;

		// Token: 0x020000CB RID: 203
		public enum GlassState
		{
			// Token: 0x04000612 RID: 1554
			Normal,
			// Token: 0x04000613 RID: 1555
			Shattered,
			// Token: 0x04000614 RID: 1556
			Broken
		}
	}
}
