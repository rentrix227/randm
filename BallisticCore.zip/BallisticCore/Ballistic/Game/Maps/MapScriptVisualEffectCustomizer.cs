﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Helper;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000DD RID: 221
	public class MapScriptVisualEffectCustomizer : MonoBehaviour
	{
		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060003C6 RID: 966 RVA: 0x00004F62 File Offset: 0x00003162
		public static MapScriptVisualEffectCustomizer.EffectOptions DefaultOptions
		{
			get
			{
				if (MapScriptVisualEffectCustomizer.m_defaultOptions == null)
				{
					MapScriptVisualEffectCustomizer.m_defaultOptions = new MapScriptVisualEffectCustomizer.EffectOptions();
				}
				return MapScriptVisualEffectCustomizer.m_defaultOptions;
			}
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0001F8EC File Offset: 0x0001DAEC
		public void Awake()
		{
			this.m_optionsByType = new Dictionary<FXEffectType, MapScriptVisualEffectCustomizer.EffectOptions>();
			foreach (MapScriptVisualEffectCustomizer.EffectOptions effectOptions in this.CustomizationOptions)
			{
				this.m_optionsByType[effectOptions.EffectType] = effectOptions;
			}
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x0001F960 File Offset: 0x0001DB60
		public MapScriptVisualEffectCustomizer.EffectOptions GetForEffectType(FXEffectType p_type)
		{
			MapScriptVisualEffectCustomizer.EffectOptions defaultOptions = MapScriptVisualEffectCustomizer.DefaultOptions;
			this.m_optionsByType.TryGetValue(p_type, out defaultOptions);
			if (defaultOptions.ParentToObject && defaultOptions.ParentTarget == null)
			{
				defaultOptions.ParentTarget = base.transform;
			}
			return defaultOptions;
		}

		// Token: 0x04000683 RID: 1667
		public List<MapScriptVisualEffectCustomizer.EffectOptions> CustomizationOptions;

		// Token: 0x04000684 RID: 1668
		private static MapScriptVisualEffectCustomizer.EffectOptions m_defaultOptions;

		// Token: 0x04000685 RID: 1669
		private Dictionary<FXEffectType, MapScriptVisualEffectCustomizer.EffectOptions> m_optionsByType;

		// Token: 0x020000DE RID: 222
		[Serializable]
		public class EffectOptions
		{
			// Token: 0x04000686 RID: 1670
			public FXEffectType EffectType;

			// Token: 0x04000687 RID: 1671
			public bool DoNotCreate;

			// Token: 0x04000688 RID: 1672
			public bool ParentToObject;

			// Token: 0x04000689 RID: 1673
			public Transform ParentTarget;
		}
	}
}
