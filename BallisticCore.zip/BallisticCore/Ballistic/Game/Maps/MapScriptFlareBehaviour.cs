﻿using System;
using System.Collections;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Ballistic.Game.Spectator;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D1 RID: 209
	[ExecuteInEditMode]
	public class MapScriptFlareBehaviour : MonoBehaviour
	{
		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000391 RID: 913 RVA: 0x0001EB14 File Offset: 0x0001CD14
		private static Camera CurrentCamera
		{
			get
			{
				if (!Application.isPlaying && Application.isEditor)
				{
					if (MapScriptFlareBehaviour._currentCamera == null)
					{
						float num = float.MinValue;
						for (int i = 0; i < Camera.allCameras.Length; i++)
						{
							Camera camera = Camera.allCameras[i];
							if (camera.depth > num)
							{
								num = camera.depth;
								MapScriptFlareBehaviour._currentCamera = camera;
							}
						}
					}
					return MapScriptFlareBehaviour._currentCamera;
				}
				if (MapScriptFlareBehaviour._localCharacterService != null && (!MapScriptFlareBehaviour._localCharacterService.IsDead || Time.time - MapScriptFlareBehaviour._localCharacterService.IsDeadTimestamp < 2f))
				{
					return MapScriptFlareBehaviour._localCharacterService.FXCamera;
				}
				if (UserProfile.LocalGameClient.clientMode == EClientMode.PLAYER)
				{
					return ServiceProvider.GetService<CameraService>().GetCurrentCamera();
				}
				if (UserProfile.LocalGameClient.clientMode == EClientMode.SPECTATOR)
				{
					return ServiceProvider.GetService<SpectatorService>().GetCurrentCamera();
				}
				return null;
			}
		}

		// Token: 0x06000392 RID: 914 RVA: 0x00004D76 File Offset: 0x00002F76
		public void Start()
		{
			if (this.InitializeComponentData())
			{
				this.InitializeFlareMesh();
				this.InitializeTimer();
			}
			else
			{
				Object.Destroy(this);
			}
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0001EC00 File Offset: 0x0001CE00
		public void Update()
		{
			if (this.isPlayingState != Application.isPlaying)
			{
				this.isPlayingState = Application.isPlaying;
				MapScriptFlareBehaviour._currentCamera = null;
			}
			if (MapScriptFlareBehaviour.CurrentCamera == null)
			{
				return;
			}
			if (this.CheckVisibility())
			{
				this.FaceCamera();
			}
		}

		// Token: 0x06000394 RID: 916 RVA: 0x0001EC50 File Offset: 0x0001CE50
		private bool InitializeComponentData()
		{
			if ((this.m_meshFilter = base.GetComponent<MeshFilter>()) == null)
			{
				Debug.LogWarning(string.Format("[FlareBehaviour] A MeshFilter is required for flares to work. No MeshFilter was found for object {0}. Destroying component.", base.gameObject.name));
				return false;
			}
			if (Application.isPlaying)
			{
				MapScriptFlareBehaviour._localCharacterService = ServiceProvider.GetService<LocalCharacterService>();
				this.m_mesh = this.m_meshFilter.mesh;
			}
			else
			{
				this.m_mesh = this.m_meshFilter.sharedMesh;
			}
			this.m_flareVerticesColor = new List<Color>(this.m_mesh.colors);
			this.m_meshRenderer = base.GetComponent<MeshRenderer>();
			this.m_transform = base.transform;
			this.m_flarePosition = this.m_transform.position;
			return true;
		}

		// Token: 0x06000395 RID: 917 RVA: 0x00004D9A File Offset: 0x00002F9A
		private void InitializeTimer()
		{
			this.m_timerValue = 1f / (float)this.ChecksPerSecond;
			this.m_checkTimer = Random.value * this.m_timerValue;
		}

		// Token: 0x06000396 RID: 918 RVA: 0x00004DC1 File Offset: 0x00002FC1
		private void InitializeFlareMesh()
		{
			this.m_isVisible = false;
			this.m_flareAlpha = 0f;
			this.m_meshRenderer.enabled = false;
			this.UpdateMesh();
		}

		// Token: 0x06000397 RID: 919 RVA: 0x0001ED10 File Offset: 0x0001CF10
		private void UpdateMesh()
		{
			this.FlareColor.a = this.m_flareAlpha;
			for (int i = 0; i < this.m_flareVerticesColor.Count; i++)
			{
				this.m_flareVerticesColor[i] = this.FlareColor;
			}
			this.m_mesh.SetColors(this.m_flareVerticesColor);
			this.m_meshFilter.sharedMesh = this.m_mesh;
		}

		// Token: 0x06000398 RID: 920 RVA: 0x0001ED80 File Offset: 0x0001CF80
		private void SetVisibility(bool p_visible)
		{
			if (Application.isPlaying && p_visible == this.m_isVisible)
			{
				return;
			}
			this.m_isVisible = p_visible;
			base.StopAllCoroutines();
			if (Application.isPlaying)
			{
				if (this.m_isVisible)
				{
					base.StartCoroutine(this.Fade(1f));
				}
				else
				{
					base.StartCoroutine(this.Fade(0f));
				}
			}
			else
			{
				if (this.m_isVisible)
				{
					this.m_flareAlpha = 1f;
					this.UpdateMesh();
				}
				else
				{
					this.m_flareAlpha = 0f;
					this.UpdateMesh();
				}
				this.m_meshRenderer.enabled = this.m_isVisible;
			}
		}

		// Token: 0x06000399 RID: 921 RVA: 0x0001EE38 File Offset: 0x0001D038
		private void FaceCamera()
		{
			if (MapScriptFlareBehaviour.m_lastFrameCalculatedBillboard < Time.frameCount)
			{
				MapScriptFlareBehaviour.m_lastCalculatedBillboardRotation = Quaternion.LookRotation(MapScriptFlareBehaviour.CurrentCamera.transform.up, -MapScriptFlareBehaviour.CurrentCamera.transform.forward);
				MapScriptFlareBehaviour.m_lastFrameCalculatedBillboard = Time.frameCount;
			}
			this.m_transform.rotation = MapScriptFlareBehaviour.m_lastCalculatedBillboardRotation;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x0001EE9C File Offset: 0x0001D09C
		private bool CheckVisibility()
		{
			if (Application.isPlaying)
			{
				this.m_checkTimer -= Time.deltaTime;
				if (this.m_checkTimer > 0f)
				{
					return this.m_isVisible;
				}
				this.m_checkTimer += this.m_timerValue;
				Vector3 vector = MapScriptFlareBehaviour.CurrentCamera.WorldToViewportPoint(this.m_flarePosition);
				if (vector.z < this.MinDistance || vector.z > this.MaxDistance)
				{
					this.SetVisibility(false);
				}
				else if (vector.x < -0.3f || vector.x > 1.3f || vector.y < -0.3f || vector.y > 1.3f)
				{
					this.SetVisibility(false);
				}
				else
				{
					Vector3 vector2 = this.m_flarePosition - MapScriptFlareBehaviour.CurrentCamera.transform.position;
					float num = Vector3.Distance(this.m_flarePosition, MapScriptFlareBehaviour.CurrentCamera.transform.position);
					if (num > this.MaxDistance)
					{
						this.SetVisibility(false);
					}
					else if (Physics.Raycast(MapScriptFlareBehaviour.CurrentCamera.transform.position, vector2, num, this.AffectedLayers))
					{
						this.SetVisibility(false);
					}
					else
					{
						this.SetVisibility(true);
					}
				}
			}
			else
			{
				this.SetVisibility(true);
			}
			return this.m_isVisible;
		}

		// Token: 0x0600039B RID: 923 RVA: 0x0001F01C File Offset: 0x0001D21C
		private IEnumerator Fade(float p_targetAlpha)
		{
			if (this.m_isVisible)
			{
				this.m_meshRenderer.enabled = true;
			}
			while ((this.m_isVisible && this.m_flareAlpha < 1f) || (!this.m_isVisible && this.m_flareAlpha > 0f))
			{
				this.m_flareAlpha = Mathf.Lerp(this.m_flareAlpha, p_targetAlpha, this.FadeSpeed * Time.deltaTime);
				this.UpdateMesh();
				yield return null;
			}
			this.m_flareAlpha = p_targetAlpha;
			this.UpdateMesh();
			if (!this.m_isVisible)
			{
				this.m_meshRenderer.enabled = false;
			}
			yield break;
		}

		// Token: 0x04000644 RID: 1604
		private static LocalCharacterService _localCharacterService;

		// Token: 0x04000645 RID: 1605
		private static int m_lastFrameCalculatedBillboard;

		// Token: 0x04000646 RID: 1606
		private static Quaternion m_lastCalculatedBillboardRotation;

		// Token: 0x04000647 RID: 1607
		private static Camera _currentCamera;

		// Token: 0x04000648 RID: 1608
		public float MaxDistance = 20f;

		// Token: 0x04000649 RID: 1609
		public float MinDistance = 0.3f;

		// Token: 0x0400064A RID: 1610
		public float FadeSpeed = 10f;

		// Token: 0x0400064B RID: 1611
		public int ChecksPerSecond = 4;

		// Token: 0x0400064C RID: 1612
		public LayerMask AffectedLayers;

		// Token: 0x0400064D RID: 1613
		public Color FlareColor;

		// Token: 0x0400064E RID: 1614
		private bool m_isVisible;

		// Token: 0x0400064F RID: 1615
		private float m_checkTimer;

		// Token: 0x04000650 RID: 1616
		private float m_timerValue;

		// Token: 0x04000651 RID: 1617
		private float m_flareAlpha;

		// Token: 0x04000652 RID: 1618
		private Renderer m_meshRenderer;

		// Token: 0x04000653 RID: 1619
		private Transform m_transform;

		// Token: 0x04000654 RID: 1620
		private Vector3 m_flarePosition;

		// Token: 0x04000655 RID: 1621
		private MeshFilter m_meshFilter;

		// Token: 0x04000656 RID: 1622
		private Mesh m_mesh;

		// Token: 0x04000657 RID: 1623
		private List<Color> m_flareVerticesColor;

		// Token: 0x04000658 RID: 1624
		private bool isPlayingState;
	}
}
