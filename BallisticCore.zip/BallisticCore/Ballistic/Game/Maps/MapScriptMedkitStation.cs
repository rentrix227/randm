﻿using System;
using Aquiris.Ballistic.Game.ResupplySystem;
using Aquiris.Ballistic.Game.Utility;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D4 RID: 212
	public class MapScriptMedkitStation : MonoBehaviour
	{
		// Token: 0x060003A6 RID: 934 RVA: 0x0001F1F8 File Offset: 0x0001D3F8
		public void Start()
		{
			if (OfflineInformation.OfflineMode)
			{
				return;
			}
			GameObject gameObject = Object.Instantiate<GameObject>(Resources.Load<GameObject>("medkit_station"), base.transform, false);
			gameObject.GetComponent<MedkitStation>().Initialize(this.MedKitConfigName, this.MedKitLocationName);
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x0001F240 File Offset: 0x0001D440
		public void OnDrawGizmos()
		{
			Gizmos.matrix = base.transform.localToWorldMatrix;
			Gizmos.color = new Color(Color.green.r * 2f, Color.green.g * 2f, Color.green.b * 2f, 0.2f);
			Gizmos.DrawCube(base.transform.up * 1f, new Vector3(1f, 2f, 1f));
		}

		// Token: 0x04000663 RID: 1635
		public string MedKitConfigName;

		// Token: 0x04000664 RID: 1636
		public string MedKitLocationName;
	}
}
