﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000CE RID: 206
	public class MapScriptAnimationAudioRetarget : MonoBehaviour
	{
		// Token: 0x06000380 RID: 896 RVA: 0x0001E614 File Offset: 0x0001C814
		public void Play(string audio)
		{
			bool flag = false;
			for (int i = 0; i < this.definitions.Length; i++)
			{
				if (this.definitions[i].isActiveAndEnabled && this.definitions[i].name.Equals(audio))
				{
					this.definitions[i].Play();
					flag = true;
				}
			}
			if (!flag)
			{
				Debug.LogWarning("Audio:" + audio + " not found. Recheck your settings.");
			}
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0001E690 File Offset: 0x0001C890
		public void Stop(string audio)
		{
			bool flag = false;
			for (int i = 0; i < this.definitions.Length; i++)
			{
				if (this.definitions[i].name.Equals(audio))
				{
					this.definitions[i].Stop();
					flag = true;
				}
			}
			if (!flag)
			{
				Debug.LogWarning("Audio:" + audio + " not found. Recheck your settings.");
			}
		}

		// Token: 0x04000634 RID: 1588
		public AudioSource[] definitions;
	}
}
