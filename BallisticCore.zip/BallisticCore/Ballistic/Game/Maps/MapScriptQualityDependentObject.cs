﻿using System;
using Aquiris.Ballistic.Game.Helper;
using Aquiris.Ballistic.Game.Services;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000D9 RID: 217
	public class MapScriptQualityDependentObject : MonoBehaviour
	{
		// Token: 0x060003B8 RID: 952 RVA: 0x00004EB4 File Offset: 0x000030B4
		public void Awake()
		{
			base.gameObject.SetActive(true);
			this._gameSettingsService = ServiceProvider.GetService<GameSettingsService>();
			this._gameSettingsService.OnQualityChange += this.OnQualityChange;
			this.UpdateObject();
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x00004EEA File Offset: 0x000030EA
		public void OnDestroy()
		{
			this._gameSettingsService.OnQualityChange -= this.OnQualityChange;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x0001F6AC File Offset: 0x0001D8AC
		private void UpdateObject()
		{
			OptionPresetLevel quality = this._gameSettingsService.Container.Quality;
			if (quality != OptionPresetLevel.Low)
			{
				if (quality != OptionPresetLevel.Medium)
				{
					if (quality == OptionPresetLevel.High)
					{
						base.gameObject.SetActive(this.EnableForHigh);
					}
				}
				else
				{
					base.gameObject.SetActive(this.EnableForMedium);
				}
			}
			else
			{
				base.gameObject.SetActive(this.EnableForVeryLow);
			}
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00004F03 File Offset: 0x00003103
		private void OnQualityChange(QualityChangeData data)
		{
			this.UpdateObject();
		}

		// Token: 0x0400067A RID: 1658
		public bool EnableForVeryLow;

		// Token: 0x0400067B RID: 1659
		public bool EnableForMedium;

		// Token: 0x0400067C RID: 1660
		public bool EnableForHigh;

		// Token: 0x0400067D RID: 1661
		private GameSettingsService _gameSettingsService;
	}
}
