﻿using System;
using System.Collections.Generic;
using Aquiris.Ballistic.Game.GameMode;
using Aquiris.Ballistic.Game.GameMode.Helpers;
using Aquiris.Ballistic.Game.Networking;
using Aquiris.Ballistic.Game.Profile;
using Aquiris.Ballistic.Network.Transport.Gameplay.State;
using Aquiris.Ballistic.Network.Transport.Gameplay.Team.Responses;
using Aquiris.Ballistic.Network.Transport.Gameplay.Time.Events;
using Aquiris.Services;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000E1 RID: 225
	[ExecuteInEditMode]
	public class SpawnBlocker : MonoBehaviour
	{
		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060003D0 RID: 976 RVA: 0x00004F95 File Offset: 0x00003195
		// (set) Token: 0x060003D1 RID: 977 RVA: 0x00004F9D File Offset: 0x0000319D
		public Team Team { get; private set; }

		// Token: 0x060003D2 RID: 978 RVA: 0x0001FA84 File Offset: 0x0001DC84
		public void Initialize(Team team)
		{
			this.Team = team;
			this._networkGameService = ServiceProvider.GetService<NetworkGameService>();
			this._gameModeService = ServiceProvider.GetService<GameModeService>();
			EGameMode gameMode = this._gameModeService.GameMode;
			if (gameMode == EGameMode.FreeForAll || gameMode == EGameMode.Juggernaut)
			{
				this.SafeArea.SetActive(false);
				this.Blocker.SetActive(false);
				return;
			}
			if (this._gameModeService.GameMode == EGameMode.TeamDeathMatch && this._gameModeService.Beta)
			{
				this.SafeArea.SetActive(false);
				this.Blocker.SetActive(false);
				return;
			}
			if (this._gameModeService.GameMode == EGameMode.Rounds)
			{
				this.SafeArea.GetComponentInChildren<Collider>().gameObject.layer = 10;
				this.Blocker.GetComponentInChildren<Collider>().gameObject.layer = 10;
			}
			else
			{
				this.SafeArea.GetComponentInChildren<Collider>().gameObject.layer = 29;
				this.Blocker.GetComponentInChildren<Collider>().gameObject.layer = 10;
			}
			this._networkGameService.OnSelectTeam.AddListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnTimeRemaining.AddListener(new Action<TimeRemainingEvent>(this.OnTimeUpdate));
			SpawnBlocker.AllBlockers.Add(this);
			foreach (SpawnBlocker.Panel panel in this.Panels)
			{
				this.UpdateMesh(panel, base.transform.localScale);
			}
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0001FC14 File Offset: 0x0001DE14
		private void OnTimeUpdate(TimeRemainingEvent evt)
		{
			switch (this._gameModeService.GameMode)
			{
			case EGameMode.TeamDeathMatch:
			case EGameMode.Conquest:
			case EGameMode.KingOfTheHill:
				this.safeActive = UserProfile.LocalGameClient.team != this.Team;
				this.blockerActive = !this.safeActive;
				if (this.SafeArea.activeSelf != this.safeActive)
				{
					this.SafeArea.SetActive(this.safeActive);
				}
				if (this.Blocker.activeSelf != this.blockerActive)
				{
					this.Blocker.SetActive(this.blockerActive);
				}
				return;
			case EGameMode.Rounds:
				if (this._networkGameService.GetGameModeMetaData() == null)
				{
					return;
				}
				this.safeActive = UserProfile.LocalGameClient.team != this.Team && this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType == EGameState.ROUNDUP;
				this.blockerActive = !this.safeActive && this._networkGameService.GetGameModeMetaData().GameMetaData.GameStateType == EGameState.ROUNDUP;
				if (this.SafeArea.activeSelf != this.safeActive)
				{
					this.SafeArea.SetActive(this.safeActive);
				}
				if (this.Blocker.activeSelf != this.blockerActive)
				{
					this.Blocker.SetActive(this.blockerActive);
				}
				return;
			case EGameMode.FreeForAll:
			case EGameMode.Juggernaut:
				return;
			default:
				return;
			}
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0001FD90 File Offset: 0x0001DF90
		public void OnDestroy()
		{
			if (!Application.isPlaying)
			{
				return;
			}
			this._networkGameService.OnSelectTeam.RemoveListener(new Action<SelectTeamResponse>(this.OnSelectTeam));
			this._networkGameService.OnTimeRemaining.RemoveListener(new Action<TimeRemainingEvent>(this.OnTimeUpdate));
			SpawnBlocker.AllBlockers.Remove(this);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0001FDEC File Offset: 0x0001DFEC
		private void OnSelectTeam(SelectTeamResponse evt)
		{
			if (!UserProfile.IsMe(evt.User))
			{
				return;
			}
			this.Blocker.SetActive(this.Team != (Team)evt.JoinedTeam);
			this.SafeArea.SetActive(this.Team == (Team)evt.JoinedTeam);
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0001FE44 File Offset: 0x0001E044
		private void UpdateMesh(SpawnBlocker.Panel panel, Vector3 scale)
		{
			if (!panel.meshFilter)
			{
				return;
			}
			if (!panel.meshCollider)
			{
				return;
			}
			if (!panel.pivotUI)
			{
				return;
			}
			if (!panel.worldUI)
			{
				return;
			}
			Mesh mesh = panel.meshFilter.sharedMesh;
			if (mesh == null)
			{
				mesh = new Mesh();
				mesh.name = "Barrier";
				panel.meshFilter.sharedMesh = mesh;
			}
			List<Vector3> list = new List<Vector3>();
			List<Vector2> list2 = new List<Vector2>();
			List<Vector2> list3 = new List<Vector2>();
			List<Vector3> list4 = new List<Vector3>();
			list.Add(new Vector3(-0.5f, 0f, 0f));
			list.Add(new Vector3(-0.5f, 1f, 0f));
			list.Add(new Vector3(0.5f, 1f, 0f));
			list.Add(new Vector3(0.5f, 0f, 0f));
			list4.Add(base.transform.forward);
			list4.Add(base.transform.forward);
			list4.Add(base.transform.forward);
			list4.Add(base.transform.forward);
			list.Add(new Vector3(-0.5f, 0f, 0f));
			list.Add(new Vector3(-0.5f, 1f, 0f));
			list.Add(new Vector3(0.5f, 1f, 0f));
			list.Add(new Vector3(0.5f, 0f, 0f));
			list4.Add(-base.transform.forward);
			list4.Add(-base.transform.forward);
			list4.Add(-base.transform.forward);
			list4.Add(-base.transform.forward);
			Vector2 one = Vector2.one;
			one.x *= base.transform.lossyScale.x * panel.meshFilter.transform.localScale.x;
			one.y *= base.transform.lossyScale.y * panel.meshFilter.transform.localScale.y;
			list2.Add(new Vector2(one.x * -0.5f, one.y * 0f));
			list2.Add(new Vector2(one.x * -0.5f, one.y * 1f));
			list2.Add(new Vector2(one.x * 0.5f, one.y * 1f));
			list2.Add(new Vector2(one.x * 0.5f, one.y * 0f));
			list2.Add(new Vector2(one.x * 0.5f, one.y * 0f));
			list2.Add(new Vector2(one.x * 0.5f, one.y * 1f));
			list2.Add(new Vector2(one.x * -0.5f, one.y * 1f));
			list2.Add(new Vector2(one.x * -0.5f, one.y * 0f));
			list3.Add(new Vector2(0f, one.y * 0f));
			list3.Add(new Vector2(0f, one.y * 1f));
			list3.Add(new Vector2(1f, one.y * 1f));
			list3.Add(new Vector2(1f, one.y * 0f));
			list3.Add(new Vector2(0f, one.y * 0f));
			list3.Add(new Vector2(0f, one.y * 1f));
			list3.Add(new Vector2(1f, one.y * 1f));
			list3.Add(new Vector2(1f, one.y * 0f));
			mesh.vertices = list.ToArray();
			mesh.uv = list2.ToArray();
			mesh.uv2 = list3.ToArray();
			mesh.triangles = new int[]
			{
				0, 1, 2, 2, 3, 0, 6, 5, 4, 4,
				7, 6
			};
			mesh.normals = list4.ToArray();
			panel.meshCollider.sharedMesh = mesh;
			panel.worldUI.localScale = new Vector3(1f / base.transform.lossyScale.x, 1f / base.transform.lossyScale.y, 1f / base.transform.lossyScale.z);
			panel.pivotUI.localPosition = new Vector3(-base.transform.lossyScale.x * 1.125f - 0.6f, panel.pivotUI.localPosition.y, panel.pivotUI.localPosition.z);
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00020400 File Offset: 0x0001E600
		public void Update()
		{
			if (Application.isEditor)
			{
				if (Application.isPlaying)
				{
					return;
				}
				foreach (SpawnBlocker.Panel panel in this.Panels)
				{
					this.UpdateMesh(panel, base.transform.localScale);
				}
			}
		}

		// Token: 0x0400068C RID: 1676
		public Transform HUDPivot;

		// Token: 0x0400068D RID: 1677
		public GameObject SafeArea;

		// Token: 0x0400068E RID: 1678
		public GameObject Blocker;

		// Token: 0x0400068F RID: 1679
		public SpawnBlocker.Panel[] Panels;

		// Token: 0x04000690 RID: 1680
		private NetworkGameService _networkGameService;

		// Token: 0x04000691 RID: 1681
		private GameModeService _gameModeService;

		// Token: 0x04000692 RID: 1682
		private bool safeActive;

		// Token: 0x04000693 RID: 1683
		private bool blockerActive;

		// Token: 0x04000694 RID: 1684
		internal static List<SpawnBlocker> AllBlockers = new List<SpawnBlocker>();

		// Token: 0x04000695 RID: 1685
		private const int layerShootableAndPlayerCollision = 10;

		// Token: 0x04000696 RID: 1686
		private const int layerShootableIgnoreFlares = 29;

		// Token: 0x020000E2 RID: 226
		[Serializable]
		public struct Panel
		{
			// Token: 0x04000698 RID: 1688
			public MeshFilter meshFilter;

			// Token: 0x04000699 RID: 1689
			public MeshCollider meshCollider;

			// Token: 0x0400069A RID: 1690
			public Transform worldUI;

			// Token: 0x0400069B RID: 1691
			public Transform pivotUI;
		}
	}
}
