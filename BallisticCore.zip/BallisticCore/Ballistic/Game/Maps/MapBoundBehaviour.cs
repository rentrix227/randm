﻿using System;
using Aquiris.Ballistic.Utils;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000CC RID: 204
	[ExecuteInEditMode]
	[RequireComponent(typeof(BoxCollider))]
	public class MapBoundBehaviour : MonoBehaviour
	{
		// Token: 0x06000378 RID: 888 RVA: 0x0001E118 File Offset: 0x0001C318
		public void Awake()
		{
			if (this.ColliderReference == null)
			{
				this.ColliderReference = base.GetComponent<BoxCollider>();
				if (this.ColliderReference == null)
				{
					Debug.LogError("ColliderReference must be attached");
					return;
				}
			}
			this.ColliderReference.enabled = false;
		}

		// Token: 0x06000379 RID: 889 RVA: 0x0001E16C File Offset: 0x0001C36C
		public void Update()
		{
			if (Application.isEditor)
			{
				if (Application.isPlaying)
				{
					return;
				}
				if (this.ColliderReference == null)
				{
					this.ColliderReference = base.GetComponent<BoxCollider>();
					if (this.ColliderReference == null)
					{
						Debug.LogError("ColliderReference must be attached");
						return;
					}
				}
				if (base.transform.parent != null)
				{
					base.transform.parent.position = Vector3.zero;
				}
				base.transform.position = Vector3.zero;
				this.ColliderReference.enabled = false;
				this.MapBounds.MinX = this.ColliderReference.bounds.min.x;
				this.MapBounds.MinY = this.ColliderReference.bounds.min.y;
				this.MapBounds.MinZ = this.ColliderReference.bounds.min.z;
				this.MapBounds.MaxX = this.ColliderReference.bounds.max.x;
				this.MapBounds.MaxY = this.ColliderReference.bounds.max.y;
				this.MapBounds.MaxZ = this.ColliderReference.bounds.max.z;
			}
		}

		// Token: 0x04000615 RID: 1557
		public MapBounds MapBounds;

		// Token: 0x04000616 RID: 1558
		public Transform DirectionalLight;

		// Token: 0x04000617 RID: 1559
		public BoxCollider ColliderReference;
	}
}
