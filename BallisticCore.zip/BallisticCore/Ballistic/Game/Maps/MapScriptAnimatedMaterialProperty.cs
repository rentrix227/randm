﻿using System;
using UnityEngine;

namespace Aquiris.Ballistic.Game.Maps
{
	// Token: 0x020000CD RID: 205
	public class MapScriptAnimatedMaterialProperty : MonoBehaviour
	{
		// Token: 0x17000060 RID: 96
		// (get) Token: 0x0600037B RID: 891 RVA: 0x00004C4F File Offset: 0x00002E4F
		private Material m_material
		{
			get
			{
				return this.TargetRenderer.materials[this.MaterialIndex];
			}
		}

		// Token: 0x0600037C RID: 892 RVA: 0x00004C63 File Offset: 0x00002E63
		public void Awake()
		{
			this.RefreshFloatParameters();
		}

		// Token: 0x0600037D RID: 893 RVA: 0x0001E2FC File Offset: 0x0001C4FC
		public void RefreshFloatParameters()
		{
			if (this.TargetRenderer == null)
			{
				this.TargetRenderer = base.GetComponent<Renderer>();
			}
			this.m_colorId = Shader.PropertyToID(this.ColorParameterName);
			if (this.m_material.HasProperty(this.m_colorId))
			{
				this.ColorValue = (this.m_lastColorValue = this.m_material.GetColor(this.m_colorId));
				this.m_animateColor = true;
			}
			else
			{
				this.m_animateColor = false;
			}
			this.m_hasMainTex = this.m_material.HasProperty("_MainTex");
			if (this.m_hasMainTex)
			{
				this.Tiling = (this.m_lastTiling = this.m_material.mainTextureScale);
				this.Offset = (this.m_lastOffset = this.m_material.mainTextureOffset);
			}
			this.m_floatId1 = Shader.PropertyToID(this.FloatParameterName1);
			this.m_floatId2 = Shader.PropertyToID(this.FloatParameterName2);
			this.m_floatId3 = Shader.PropertyToID(this.FloatParameterName3);
			this.m_floatId4 = Shader.PropertyToID(this.FloatParameterName4);
		}

		// Token: 0x0600037E RID: 894 RVA: 0x0001E41C File Offset: 0x0001C61C
		public void Update()
		{
			if (this.m_lastColorValue != this.ColorValue)
			{
				this.m_lastColorValue = this.ColorValue;
				if (this.m_animateColor)
				{
					this.m_material.SetColor(this.m_colorId, this.ColorValue);
				}
			}
			if (this.m_hasMainTex && this.m_lastTiling != this.Tiling)
			{
				this.m_lastTiling = this.Tiling;
				this.m_material.mainTextureScale = this.Tiling;
			}
			if (this.m_hasMainTex && this.m_lastOffset != this.Offset)
			{
				this.m_lastOffset = this.Offset;
				this.m_material.mainTextureOffset = this.Offset;
			}
			if (this.m_lastFloatValue1 != this.FloatValue1)
			{
				this.m_lastFloatValue1 = this.FloatValue1;
				if (this.m_material.HasProperty(this.m_floatId1))
				{
					this.m_material.SetFloat(this.m_floatId1, this.FloatValue1);
				}
			}
			if (this.m_lastFloatValue2 != this.FloatValue2)
			{
				this.m_lastFloatValue2 = this.FloatValue2;
				if (this.m_material.HasProperty(this.m_floatId2))
				{
					this.m_material.SetFloat(this.m_floatId2, this.FloatValue2);
				}
			}
			if (this.m_lastFloatValue3 != this.FloatValue3)
			{
				this.m_lastFloatValue3 = this.FloatValue3;
				if (this.m_material.HasProperty(this.m_floatId3))
				{
					this.m_material.SetFloat(this.m_floatId3, this.FloatValue3);
				}
			}
			if (this.m_lastFloatValue4 != this.FloatValue4)
			{
				this.m_lastFloatValue4 = this.FloatValue4;
				if (this.m_material.HasProperty(this.m_floatId4))
				{
					this.m_material.SetFloat(this.m_floatId4, this.FloatValue4);
				}
			}
		}

		// Token: 0x04000618 RID: 1560
		public Renderer TargetRenderer;

		// Token: 0x04000619 RID: 1561
		public string ColorParameterName = "_Color";

		// Token: 0x0400061A RID: 1562
		public Color ColorValue;

		// Token: 0x0400061B RID: 1563
		private Color m_lastColorValue;

		// Token: 0x0400061C RID: 1564
		private int m_colorId;

		// Token: 0x0400061D RID: 1565
		public Vector2 Tiling;

		// Token: 0x0400061E RID: 1566
		private Vector2 m_lastTiling;

		// Token: 0x0400061F RID: 1567
		public Vector2 Offset;

		// Token: 0x04000620 RID: 1568
		private Vector2 m_lastOffset;

		// Token: 0x04000621 RID: 1569
		public int MaterialIndex;

		// Token: 0x04000622 RID: 1570
		private bool m_animateColor;

		// Token: 0x04000623 RID: 1571
		private bool m_hasMainTex;

		// Token: 0x04000624 RID: 1572
		public string FloatParameterName1;

		// Token: 0x04000625 RID: 1573
		public float FloatValue1;

		// Token: 0x04000626 RID: 1574
		private float m_lastFloatValue1;

		// Token: 0x04000627 RID: 1575
		private int m_floatId1;

		// Token: 0x04000628 RID: 1576
		public string FloatParameterName2;

		// Token: 0x04000629 RID: 1577
		public float FloatValue2;

		// Token: 0x0400062A RID: 1578
		private float m_lastFloatValue2;

		// Token: 0x0400062B RID: 1579
		private int m_floatId2;

		// Token: 0x0400062C RID: 1580
		public string FloatParameterName3;

		// Token: 0x0400062D RID: 1581
		public float FloatValue3;

		// Token: 0x0400062E RID: 1582
		private float m_lastFloatValue3;

		// Token: 0x0400062F RID: 1583
		private int m_floatId3;

		// Token: 0x04000630 RID: 1584
		public string FloatParameterName4;

		// Token: 0x04000631 RID: 1585
		public float FloatValue4;

		// Token: 0x04000632 RID: 1586
		private float m_lastFloatValue4;

		// Token: 0x04000633 RID: 1587
		private int m_floatId4;
	}
}
